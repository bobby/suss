from pathlib import Path
import hashlib,json,subprocess,time,os,gzip
K=Path(__file__).resolve().parent;F=K.parent/'m12-numeric-completion';binary=F.parent/'pattern-compiled-target/debug/suss'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((K/'numeric-symbolic-region-primary/command.json').read_text());assert prior['exit_code']==0
source=prior['forms'][0];out=K/'numeric-symbolic-region-native';out.mkdir(exist_ok=False)
inputs={p:sha(F/p) for p in json.loads((F/'results/m12-num-api/reviewed-core-native-after-symbolic-arities/commands.json').read_text())['inputs']}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip();binary_sha=sha(binary);runner_sha=sha(Path(__file__))
assert os.environ['SUSS_DURABLE_SCOPE'] in Path('/proc/self/cgroup').read_text()
command=[str(binary),'--no-cache','-e',source]
start=time.monotonic();result=subprocess.run(command,cwd=F,capture_output=True,text=True)
(out/'stdout.log').write_text(result.stdout);(out/'stderr.log').write_text(result.stderr)
unchanged=all((F/p).is_file() and sha(F/p)==h for p,h in inputs.items())
assert unchanged and sha(binary)==binary_sha and sha(Path(__file__))==runner_sha
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip()==head
r={'head':head,'inputs':inputs,'inputs_unchanged':True,'command':command,'exit_code':result.returncode,
 'seconds':time.monotonic()-start,'binary_sha256':binary_sha,'runner_sha256':runner_sha,
 'primary_receipt_sha256':sha(K/'numeric-symbolic-region-primary/command.json'),'primary_expected':prior['observations'][0],
 'actual_stdout':result.stdout,'actual_stderr':result.stderr,'complete':True,'scope':os.environ['SUSS_DURABLE_SCOPE']}
(out/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));r['runner_archived']=True
(out/'command.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='inputs'},indent=2))
