use suss_compile::{portable_macros::CompiledMacros, portable_session::Session};
use std::sync::{Arc,Mutex};
fn main() {
 for phase in ["Runtime", "Macro"] {
  let mut session=if phase=="Runtime" {Session::new_repl()} else {Session::new_macro()}.unwrap();
  let mut macros=CompiledMacros::new().unwrap();
  let observed=Arc::new(Mutex::new(Vec::<u64>::new()));let seen=observed.clone();
  macros.install_observation_hook(move |store,_| {seen.lock().unwrap().push(store.get_fuel()?);Ok(0)}).unwrap();
  session.eval_with_macros("(eval '(defmacro context-fuel-marker [] (suss.harness.observation/capture 1) 42))", &mut macros).unwrap();
  let function=session.eval_with_macros("(let [f @(eval '(var context-fuel-marker))] (fn [context] (binding [*math-context* context] (f nil nil))))", &mut macros).unwrap();
  for n in [0usize,256,1024] {
   session.set_operation_fuel(400_000_000);
   let source=if n==0 {"nil".to_string()} else {format!("[{}]", (0..n).map(|i|i.to_string()).collect::<Vec<_>>().join(" "))};
   let context=session.eval(&source).unwrap();
   observed.lock().unwrap().clear();let warm=session.invoke(&function,&[&context]);assert!(warm.is_ok(),"warm {phase} {n}: {warm:?}");
   let mut low=0u64;let mut high=1_000_000u64;
   while high-low>1 {
    let fuel=low+(high-low)/2;session.set_operation_fuel(fuel);observed.lock().unwrap().clear();
    let _=session.invoke(&function,&[&context]);
    if observed.lock().unwrap().is_empty() {low=fuel;} else {high=fuel;}
   }
   session.set_operation_fuel(high);observed.lock().unwrap().clear();let result=session.invoke(&function,&[&context]);let samples=observed.lock().unwrap().clone();
   println!("phase={phase} context_elements={n} supplied_fuel={high} child_fuel_at_effect={samples:?} result={}",match result{Ok(_)=>"ok".to_string(),Err(e)=>e.to_string()});
   if let Some(remaining)=samples.first() {if n>0 && *remaining<(n as u64) {println!("OVERGRANT_WITNESS phase={phase}: child effect with remaining={remaining} below proven caller snapshot read lower bound={n}");}}
  }
 }
}
