(defmacro projected-source-context [] (list 'quote (ns-name *ns*)))

(create-ns 'projected.caller)
(prn [(eval (nth (read-string (slurp "/home/bobby/.codex-workspaces/cleanup/suss-20261123/eval-next-step/macro-root-projection-fresh-primary/expression.sus")) 4))])
