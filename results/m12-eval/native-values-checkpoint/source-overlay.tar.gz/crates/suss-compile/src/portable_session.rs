//! Persistent native execution of portable fragments and source module plans.
//! No source history is replayed. The native command REPL uses this host.
use crate::{
    portable::{
        self, Diagnostic, PreparedFragment,
        modules::{ModuleDiagnostic, ModuleIdentity, PreparedModule},
        resolve::{Environment, Global as CellIdentity, Phase},
    },
    runtime_abi,
};
use std::{
    collections::{BTreeMap, BTreeSet},
    fmt,
    path::PathBuf,
    sync::{
        Arc, Mutex, OnceLock,
        atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering},
    },
};
use wasmtime::{
    AnyRef, AsContextMut, Config, Engine, Func, Global, GlobalType, Instance, Linker, Memory,
    Mutability, OwnedRooted, RefType, RootScope, Store, StoreContextMut, Tag, UpdateDeadline, Val,
    ValType,
};

mod frontend;
pub use frontend::{AsyncDispatch, FutureState, FutureStatus};
mod native_async;
pub use native_async::{NativeRequest, NativeRequestId, NativeRequestQueue};
mod observation;
mod installation;
mod compiler_state;
use compiler_state::{CompilerState, SharedCompiler};
mod store_access;
mod reentry;
pub(crate) mod suspended;
mod evaluation;
pub(crate) use evaluation::EvaluationMathContext;
pub(crate) use reentry::ReentryProfile;
#[cfg(test)]
mod random_tests;

fn input_error(error: portable::modules::InputDiagnostic) -> SessionError {
    match error {
        portable::modules::InputDiagnostic::Compile(error) => SessionError::Compile(error),
        portable::modules::InputDiagnostic::Dependency(error) => SessionError::Module(error),
    }
}

#[derive(Clone, Debug)]
pub struct SessionOptions {
    pub source_paths: Vec<PathBuf>,
    /// One budget for the whole input/load/invocation, including dependencies.
    pub fuel_per_operation: u64,
}
impl Default for SessionOptions {
    fn default() -> Self {
        Self {
            source_paths: vec![PathBuf::from("src")],
            fuel_per_operation: portable::DEFAULT_OPERATION_FUEL,
        }
    }
}

/// Interrupts one session's running operation from any thread (design section 7:
/// explicit cancellation). A request made while the session is idle is discarded
/// when its next operation starts; the handle stays valid across `reset`.
/// Requires an engine with epoch interruption, as the shared session engine has.
#[derive(Clone)]
pub struct InterruptHandle {
    engine: Engine,
    requested: Arc<AtomicBool>,
}
impl InterruptHandle {
    pub(crate) fn has_suspended_parent(&self, parent: &Arc<AtomicBool>) -> bool {
        suspended::observes_interrupt(parent, &self.engine)
    }

    /// Withdraw a request no guest code has consumed yet (#410): a SIGINT
    /// received while the REPL waits for input is that input's interrupt,
    /// not the next guest turn's.
    pub fn clear(&self) {
        self.requested.store(false, Ordering::SeqCst);
    }
    pub fn interrupt(&self) {
        self.requested.store(true, Ordering::SeqCst);
        // Every Store on this engine checks its own request at the next epoch;
        // only the requesting session traps.
        self.engine.increment_epoch();
    }
}
/// Trap for this session or its synchronous suspended ancestors. Consume only
/// this session's request; ancestors consume theirs during their own unwind.
fn install_interrupt(store: &mut Store<()>, requested: &Arc<AtomicBool>) {
    let requested = requested.clone();
    store.set_epoch_deadline(1);
    store.epoch_deadline_callback(move |_| {
        if requested.swap(false, Ordering::SeqCst) || suspended::interrupt_requested() {
            Err(wasmtime::Trap::Interrupt.into())
        } else {
            Ok(UpdateDeadline::Continue(1))
        }
    });
}

#[derive(Debug)]
pub enum SessionError {
    Compile(Diagnostic),
    Module(ModuleDiagnostic),
    Language(SessionValue),
    Trap(wasmtime::Error),
    Host(wasmtime::Error),
    ForeignValue,
    /// Reset requested cancellation but bounded cleanup has not retired yet.
    ResetPending,
}
impl fmt::Display for SessionError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Compile(error) => write!(f, "{error}"),
            Self::Module(error) => write!(f, "{error}"),
            Self::Language(_) => f.write_str("Uncaught language exception"),
            Self::Trap(_) if self.is_interrupt() => f.write_str("Interrupted"),
            Self::Trap(error) => write!(f, "Runtime trap: {error:#}"),
            Self::Host(error) => write!(f, "Host error: {error}"),
            Self::ForeignValue => {
                f.write_str("Value belongs to another session or a previous reset")
            }
            Self::ResetPending => {
                f.write_str("Reset pending: complete outstanding cleanup and retry")
            }
        }
    }
}
impl std::error::Error for SessionError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Compile(error) => Some(error),
            Self::Module(error) => Some(error),
            Self::Trap(error) | Self::Host(error) => Some(error.as_ref()),
            Self::Language(_) | Self::ForeignValue | Self::ResetPending => None,
        }
    }
}
impl SessionError {
    /// The operation was stopped through its session's `InterruptHandle`.
    pub fn is_interrupt(&self) -> bool {
        matches!(self, Self::Trap(error)
            if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::Interrupt))
    }
}
impl From<wasmtime::Error> for SessionError {
    fn from(error: wasmtime::Error) -> Self {
        if error.is::<wasmtime::Trap>() {
            Self::Trap(error)
        } else {
            Self::Host(error)
        }
    }
}

/// An owned GC root. Drop releases the root; reset invalidates its session identity.
#[derive(Debug)]
pub struct SessionValue {
    identity: u64,
    /// `None` is nil, which ABI v3 represents as a null reference.
    value: Option<OwnedRooted<AnyRef>>,
    handles: Arc<AtomicUsize>,
}
impl SessionValue {
    pub(crate) fn rooted(
        &self,
        store: &mut wasmtime::StoreContextMut<'_, ()>,
    ) -> Option<wasmtime::Rooted<AnyRef>> {
        self.value.as_ref().map(|value| value.to_rooted(store))
    }
    /// The referenced object; nil has none.
    pub(crate) fn object(&self) -> wasmtime::Result<&OwnedRooted<AnyRef>> {
        self.value
            .as_ref()
            .ok_or_else(|| wasmtime::Error::msg("Expected a non-nil reference"))
    }
    /// The value as a Wasm argument; nil is a null reference.
    pub(crate) fn val(&self, store: &mut wasmtime::StoreContextMut<'_, ()>) -> Val {
        Val::AnyRef(self.rooted(store))
    }
}
impl Clone for SessionValue {
    fn clone(&self) -> Self {
        self.handles.fetch_add(1, Ordering::Relaxed);
        Self {
            identity: self.identity,
            value: self.value.clone(),
            handles: self.handles.clone(),
        }
    }
}
impl Drop for SessionValue {
    fn drop(&mut self) {
        self.handles.fetch_sub(1, Ordering::Relaxed);
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SessionStats {
    pub resident_fragments: usize,
    /// Input sizes of the shared runtime and its core binding initializer,
    /// separate from subsequently installed fragments; not native JIT memory.
    pub base_runtime_artifact_bytes: usize,
    /// Sum of input artifact sizes for resident instances, not retained raw Wasm
    /// or actual JIT memory usage.
    pub resident_artifact_bytes: usize,
    pub binding_cells: usize,
    pub loaded_modules: usize,
    pub external_value_handles: usize,
    /// Native pending-operation roots, independent of caller-owned handles.
    pub pending_host_requests: usize,
    /// Allocated GC heap capacity; this is not a live-object or leak counter.
    pub gc_heap_capacity: usize,
    /// Private runtime numeric memory capacity (stack/data/scratch), separate
    /// from GC language objects. Scratch retains a high-water capacity until reset.
    pub numeric_memory_capacity: usize,
}

/// An owned persistent host. Borrowed native views use the same implementation.
pub type Session = SessionHost<'static>;
pub struct SessionHost<'store> {
    evaluation: Option<Arc<evaluation::Evaluation>>,
    engine: Engine,
    phase: Phase,
    options: SessionOptions,
    identity: u64,
    handles: Arc<AtomicUsize>,
    interrupt: Arc<AtomicBool>,
    operation_budget_depth: Arc<AtomicUsize>,
    store: store_access::StoreAccess<'store>,
    runtime: Instance,
    numeric_memory: Memory,
    compiler: SharedCompiler,
    base_runtime_artifact_bytes: usize,
    bootstrap_core: bool,
    pending_host_futures: SharedPendingRegistry,
    native_factories: Arc<Mutex<Vec<native_async::FactoryProfile>>>,
    last_async_recovered_owner: Arc<Mutex<Option<OwnedRooted<AnyRef>>>>,
}
// Own the depth rather than borrowing Session, so the closure can use &mut Session
// and unwinding still retires the scope without unsafe pointers or panic catching.
pub(crate) struct OperationBudgetScope(Arc<AtomicUsize>);
impl Drop for OperationBudgetScope {
    fn drop(&mut self) {
        end_operation_budget(&self.0);
    }
}
fn end_operation_budget(depth: &AtomicUsize) {
    depth
        .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |value| value.checked_sub(1))
        .expect("Operation budget scopes must be balanced");
}
struct PendingHostFuture {
    root: OwnedRooted<AnyRef>,
    cancel: Mutex<Option<Box<dyn FnOnce() + Send + 'static>>>,
}
type SharedPendingRegistry = Arc<Mutex<Vec<Arc<PendingHostFuture>>>>;
fn registry_lock<T>(mutex: &Mutex<T>) -> std::sync::MutexGuard<'_, T> {
    mutex
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}
impl PendingHostFuture {
    fn take_cancel(&self) -> Option<Box<dyn FnOnce() + Send + 'static>> {
        registry_lock(&self.cancel).take()
    }
}
/// Binding/catalog transaction only: reachable object effects and resident code are retained.
pub(crate) struct BindingCheckpoint {
    environment: Environment,
    values: BTreeMap<CellIdentity, (Option<OwnedRooted<AnyRef>>, i32)>,
}
/// Owned compiler inputs permit macro expansion to execute in this same phase
/// Store while preparation reads an immutable namespace/module snapshot.
#[derive(Clone)]
pub(crate) struct CompilationSnapshot {
    pub(crate) environment: Environment,
    pub(crate) native_owner: Option<u64>,
    phase: Phase,
    pub(crate) source_paths: Vec<PathBuf>,
    pub(crate) provided: BTreeSet<ModuleIdentity>,
}
/// Declaration journals belong to one preparation through its linking result.
/// The operation excludes other threads without retaining a Macro Store lease.
pub(crate) struct SourcePreparation {
    authority: Option<crate::portable_macros::MacroAuthority>,
    _operation: Option<crate::portable_macros::MacroOperation>,
}
impl CompilationSnapshot {
    pub(crate) fn new(
        environment: Environment,
        phase: Phase,
        source_paths: Vec<PathBuf>,
        provided: BTreeSet<ModuleIdentity>,
    ) -> Self {
        Self {
            environment,
            native_owner: None,
            phase,
            source_paths,
            provided,
        }
    }
    pub(crate) fn prepare_source(&self, source: &str, expander: &mut dyn portable::ExpansionHost) -> Result<portable::modules::PreparedInput, SessionError> {
        let mut request = portable::ExpansionRequest::new(expander, 0..source.len()).map_err(SessionError::Compile)?;
        let forms = suss_reader::forms::read_forms_metered(source, &mut |work| {
            portable::ExpansionHost::charge_expansion_work(&mut request, work, 0..source.len()).map_err(|error| suss_reader::ParseError {
                message: error.message, span: error.span, expected: vec![],
            })
        }).map_err(|error| {
            SessionError::Compile(Diagnostic {
                span: error.span,
                message: error.message,
            })
        })?;
        portable::ExpansionHost::charge_expansion_work(&mut request, source.len() as u64, 0..source.len()).map_err(SessionError::Compile)?;
        let prepared = self.prepare_with_origin(
            forms,
            0..source.len(),
            &mut request,
            Some(&portable::SourceOrigin::new(source, None)),
        )?;
        drop(request);
        Ok(prepared)
    }
    pub(crate) fn phase(&self) -> Phase {
        self.phase
    }
    pub(crate) fn prepare_with_origin(
        &self,
        forms: Vec<suss_reader::forms::Form>,
        span: std::ops::Range<usize>,
        expander: &mut dyn portable::ExpansionHost,
        origin: Option<&portable::SourceOrigin>,
    ) -> Result<portable::modules::PreparedInput, SessionError> {
        portable::modules::prepare_input_forms_with_origin(
            forms,
            span,
            &self.source_paths,
            &self.environment,
            self.phase,
            &self.provided,
            expander,
            origin,
        )
        .map_err(|error| match error {
            portable::modules::InputDiagnostic::Compile(error) => SessionError::Compile(error),
            portable::modules::InputDiagnostic::Dependency(error) => SessionError::Module(error),
        })
    }
}
/// Select wasmtime's GC collector for every Suss engine (ADR-0003,
/// "Collector"): copying by default, set explicitly because
/// `Collector::Auto` may change; `SUSS_GC=null` opts in to the null
/// collector, which never frees and traps when the heap is full, for
/// short-lived runs. Deferred reference counting is not offered: it cannot
/// collect cycles.
pub fn configure_collector(config: &mut Config) -> Result<(), String> {
    let (collector, initial) =
        collector_settings(std::env::var("SUSS_GC"), std::env::var("SUSS_GC_INITIAL_MIB"))?;
    config.collector(collector);
    config.gc_heap_initial_size(initial);
    Ok(())
}
/// The collector and initial heap bytes that `SUSS_GC` and
/// `SUSS_GC_INITIAL_MIB` select.
fn collector_settings(
    gc: Result<String, std::env::VarError>,
    initial: Result<String, std::env::VarError>,
) -> Result<(wasmtime::Collector, u64), String> {
    use std::env::VarError::NotPresent;
    let collector = match gc.as_deref() {
        Err(NotPresent) | Ok("copying") => wasmtime::Collector::Copying,
        Ok("null") => wasmtime::Collector::Null,
        Ok(other) => return Err(format!("SUSS_GC must be copying or null, not {other:?}")),
        Err(_) => return Err("SUSS_GC must be copying or null".into()),
    };
    let initial = match initial.as_deref() {
        Err(NotPresent) => GC_HEAP_INITIAL_SIZE,
        Ok(text) => match text.parse::<u64>() {
            Ok(mib) if mib <= 1 << 20 => mib << 20,
            _ => return Err(format!("SUSS_GC_INITIAL_MIB must be a size in MiB, not {text:?}")),
        },
        Err(_) => return Err("SUSS_GC_INITIAL_MIB must be a size in MiB".into()),
    };
    Ok((collector, initial))
}
/// Each store's initial GC heap, unless `SUSS_GC_INITIAL_MIB` sets it.
/// wasmtime 49 grows the heap only when a collection frees too little, so a
/// heap that live data nearly fills is collected every few allocations;
/// starting larger avoids that up to the initial size, at the cost of peak
/// RSS (ADR-0003).
pub const GC_HEAP_INITIAL_SIZE: u64 = 64 << 20;
fn engine() -> Result<Engine, SessionError> {
    static ENGINE: OnceLock<Result<Engine, String>> = OnceLock::new();
    ENGINE
        .get_or_init(|| {
            let mut config = Config::new();
            configure_collector(&mut config)?;
            config
                .wasm_gc(true)
                .wasm_function_references(true)
                .wasm_tail_call(true)
                .wasm_exceptions(true)
                .consume_fuel(true)
                .epoch_interruption(true);
            Engine::new(&config).map_err(|error| error.to_string())
        })
        .clone()
        .map_err(|message| SessionError::Host(wasmtime::Error::msg(message)))
}
/// The sentinel tag (`runtime_abi::NIL`, `FALSE`, `TRUE` or `UNDEFINED`) of
/// nil, a null reference, or of a false, true or undefined struct; `None` for
/// any other value. A sentinel is the only one-field `i32` struct.
pub fn sentinel_tag(
    mut store: impl AsContextMut,
    value: &Val,
) -> wasmtime::Result<Option<u32>> {
    let Some(reference) = value
        .anyref()
        .ok_or_else(|| wasmtime::Error::msg("Expected a reference Value"))?
    else {
        return Ok(Some(runtime_abi::NIL as u32));
    };
    let Some(structure) = reference.as_struct(&store)? else {
        return Ok(None);
    };
    let ty = structure.ty(&store)?;
    if ty.fields().len() != 1
        || !matches!(
            ty.field(0).map(|field| field.element_type().clone()),
            Some(wasmtime::StorageType::ValType(wasmtime::ValType::I32))
        )
    {
        return Ok(None);
    }
    match structure.field(&mut store, 0)? {
        Val::I32(tag) => Ok(Some(tag as u32)),
        _ => Ok(None),
    }
}
/// A runtime number: a long, held in an i31 or a one-field `i64` struct, or a
/// double, a one-field `f64` struct.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum RuntimeNumber {
    Long(i64),
    Double(f64),
}
impl RuntimeNumber {
    /// The number as a double, rounding a long beyond 2^53.
    pub fn as_f64(self) -> f64 {
        match self {
            Self::Long(value) => value as f64,
            Self::Double(value) => value,
        }
    }
}
/// The long or double `value` holds; `None` for any other value.
pub fn runtime_number(
    mut store: impl AsContextMut,
    value: &Val,
) -> wasmtime::Result<Option<RuntimeNumber>> {
    let Some(Some(reference)) = value.anyref() else {
        return Ok(None);
    };
    if let Some(small) = reference.as_i31(&store)? {
        return Ok(Some(RuntimeNumber::Long(i64::from(small.get_i32()))));
    }
    let Some(structure) = reference.as_struct(&store)? else {
        return Ok(None);
    };
    if structure.ty(&store)?.fields().len() != 1 {
        return Ok(None);
    }
    Ok(match structure.field(&mut store, 0)? {
        Val::I64(value) => Some(RuntimeNumber::Long(value)),
        Val::F64(bits) => Some(RuntimeNumber::Double(f64::from_bits(bits))),
        _ => None,
    })
}
fn own<C: AsContextMut<Data = ()>>(
    scope: &mut RootScope<C>,
    value: Val,
    identity: u64,
    handles: &Arc<AtomicUsize>,
) -> Result<SessionValue, SessionError> {
    let value = match value.anyref() {
        Some(object) => object.map(|object| object.to_owned_rooted(scope)).transpose()?,
        None => return Err(wasmtime::Error::msg("Expected a runtime reference Value").into()),
    };
    handles.fetch_add(1, Ordering::Relaxed);
    Ok(SessionValue {
        identity,
        value,
        handles: handles.clone(),
    })
}
// Either root may be nil (None) when no frame or join is active.
pub(crate) struct DynamicCheckpoint {
    frame: Option<OwnedRooted<AnyRef>>,
}
// Snapshot the caller's rooted dynamic context, including native interop calls.
fn dynamic_checkpoint<C: AsContextMut<Data = ()>>(
    scope: &mut RootScope<C>,
    runtime: Instance,
) -> Result<DynamicCheckpoint, SessionError> {
    let frame = runtime
        .get_global(&mut *scope, "dynamic-frame")
        .ok_or_else(|| wasmtime::Error::msg("Missing dynamic frame root"))?
        .get(&mut *scope);
    let frame = frame
        .anyref()
        .ok_or_else(|| wasmtime::Error::msg("Dynamic frame root is not a reference"))?
        .map(|frame| frame.to_owned_rooted(&mut *scope))
        .transpose()?;
    Ok(DynamicCheckpoint { frame })
}
fn restore_dynamic<C: AsContextMut<Data = ()>>(
    scope: &mut RootScope<C>,
    runtime: Instance,
    checkpoint: &DynamicCheckpoint,
) -> Result<(), SessionError> {
    // Host restoration also covers uncatchable Wasm fuel/cancellation traps.
    let global = runtime
        .get_global(&mut *scope, "dynamic-frame")
        .ok_or_else(|| wasmtime::Error::msg("Missing dynamic frame root"))?;
    let pop = runtime
        .get_func(&mut *scope, "dynamic-pop")
        .ok_or_else(|| wasmtime::Error::msg("Missing dynamic frame restoration"))?;
    let fuel = scope.as_context_mut().get_fuel()?;
    // Restoration executes only finite, checked runtime frame/cell operations,
    // never a source body or finally callback. Preserve the operation's fuel.
    scope.as_context_mut().set_fuel(u64::MAX)?;
    let result = suspended::restoring_dynamic(|| -> wasmtime::Result<()> {
        loop {
            let current = global.get(&mut *scope);
            let current = current
                .anyref()
                .ok_or_else(|| wasmtime::Error::msg("Dynamic frame root is not a reference"))?;
            let expected = checkpoint.frame.as_ref().map(|frame| frame.to_rooted(&mut *scope));
            let Some(current) = current else {
                if expected.is_none() {
                    return Ok(());
                }
                // Reaching nil before the checkpoint means a native callback invalidated it.
                return Err(wasmtime::Error::msg("Dynamic caller context was removed"));
            };
            if let Some(expected) = expected
                && wasmtime::Rooted::ref_eq(&*scope, current, &expected)?
            {
                return Ok(());
            }
            let current = Val::AnyRef(Some(*current));
            pop.call(&mut *scope, &[current], &mut [])?;
        }
    });
    scope.as_context_mut().set_fuel(fuel)?;
    if result.is_err() {
        scope.as_context_mut().take_pending_exception();
    }
    result.map_err(SessionError::Host)
}
fn call<C: AsContextMut<Data = ()>>(
    scope: &mut RootScope<C>,
    runtime: Instance,
    function: Func,
    args: &[Val],
    identity: u64,
    handles: &Arc<AtomicUsize>,
) -> Result<SessionValue, SessionError> {
    let checkpoint = dynamic_checkpoint(scope, runtime)?;
    let mut result = [Val::null_any_ref()];
    let outcome = match function.call(&mut *scope, args, &mut result) {
        Ok(()) => own(scope, result[0].clone(), identity, handles),
        Err(error) => Err(execution_error(scope, runtime, error, identity, handles)),
    };
    restore_dynamic(scope, runtime, &checkpoint)?;
    outcome
}
fn execution_error<C: AsContextMut<Data = ()>>(
    scope: &mut RootScope<C>,
    runtime: Instance,
    error: wasmtime::Error,
    identity: u64,
    handles: &Arc<AtomicUsize>,
) -> SessionError {
    // Wasmtime's epoch hook has read-only Store access. Exhaust the interrupted
    // operation here, once the guest has returned the unique mutable Store
    // borrow, before dynamic restoration temporarily borrows cleanup fuel.
    if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::Interrupt) {
        if let Err(error) = scope.as_context_mut().set_fuel(0) { return error.into(); }
    }
    if !error.is::<wasmtime::ThrownException>() {
        // Native callbacks may translate an exception into an ordinary host error.
        // It must not leave the Store carrying a stale pending exception.
        scope.as_context_mut().take_pending_exception();
        return error.into();
    }
    let payload = (|| -> Result<SessionValue, SessionError> {
        let exception = scope
            .as_context_mut()
            .take_pending_exception()
            .ok_or_else(|| wasmtime::Error::msg("Thrown exception has no pending payload"))?;
        let tag = exception.tag(&mut *scope)?;
        let language_tag = runtime
            .get_tag(&mut *scope, "language-exception")
            .ok_or_else(|| wasmtime::Error::msg("Missing language exception tag"))?;
        if !Tag::eq(&tag, &language_tag, &*scope) {
            return Err(SessionError::Host(wasmtime::Error::msg(
                "Unexpected foreign exception tag",
            )));
        }
        let payload = exception.field(&mut *scope, 0)?;
        own(scope, payload, identity, handles)
    })();
    match payload {
        Ok(value) => SessionError::Language(value),
        Err(error) => error,
    }
}

impl SessionHost<'_> {
    pub(crate) fn execute_expression_artifact<T>(
        &mut self,
        artifact: crate::portable_expression::ExpressionArtifact,
        core_ready: impl FnOnce(&mut Self) -> Result<T, SessionError>,
    ) -> Result<(Option<SessionValue>, T), SessionError> {
        if self.phase != Phase::Runtime || !registry_lock(&self.compiler).resident.is_empty() {
            return Err(SessionError::Host(wasmtime::Error::msg(
                "Expression artifacts require an empty Runtime session",
            )));
        }
        // Preflight the complete bundle before the first initializer. Retain
        // dependency plans instead of flattening away their load-once identities.
        for bytes in artifact.modules() {
            runtime_abi::verify_artifact(bytes, &runtime_abi::Manifest::default())
                .map_err(|message| SessionError::Host(wasmtime::Error::msg(message)))?;
            portable::artifact_identity::verify(
                bytes,
                portable::artifact_identity::Expected {
                    phase: Some(Phase::Runtime),
                    ..Default::default()
                },
            )
            .map_err(|message| SessionError::Host(wasmtime::Error::msg(message)))?;
            crate::portable_module_cache::compile(&self.engine, bytes)?;
        }
        self.eval_prepared(portable::modules::PreparedInput {
            modules: Vec::new(),
            fragment: artifact.core,
        })?;
        self.bootstrap_core = true;
        self.install_evaluation()?;
        let core =
            ModuleIdentity::new(Phase::Runtime, "suss.core").map_err(SessionError::Compile)?;
        registry_lock(&self.compiler).provided.insert(core);
        let identity = self.identity;
        let observation = core_ready(self)?;
        if self.identity != identity {
            return Err(SessionError::ForeignValue);
        }
        let mut result = None;
        for input in artifact.inputs {
            result = Some(self.eval_prepared(input)?);
        }
        Ok((result, observation))
    }
    pub fn new() -> Result<Self, SessionError> {
        Self::with_options(SessionOptions::default())
    }
    /// Compiled core for the native REPL. This is the bounded, provenance-tracked
    /// bootstrap artifact, not complete portable core compatibility.
    pub fn new_repl() -> Result<Self, SessionError> {
        Self::new_repl_with_options(SessionOptions::default())
    }
    /// The shipped compiled core with caller-supplied source roots and fuel,
    /// for embedders that load namespaces from their own directories.
    pub fn new_repl_with_options(options: SessionOptions) -> Result<Self, SessionError> {
        let mut session = Self::with_options(options)?;
        session.provision_core()?;
        Ok(session)
    }
    /// Isolated compiled execution for macro bodies. This owns a separate Store
    /// and phase-qualified cells; it does not yet expand source defmacro forms.
    pub fn new_macro() -> Result<Self, SessionError> {
        Self::new_macro_with_options(SessionOptions::default())
    }
    /// The shipped compiled core in the Macro phase, with caller-supplied
    /// source roots and fuel.
    pub fn new_macro_with_options(options: SessionOptions) -> Result<Self, SessionError> {
        let mut session = Self::with_options_in(options, Phase::Macro)?;
        session.provision_core()?;
        Ok(session)
    }
    fn provision_core(&mut self) -> Result<(), SessionError> {
        let namespace = self.current_namespace().to_owned();
        let fragment = portable::bootstrap::shipped(self.phase)
            .map_err(SessionError::Compile)?
            .clone();
        self.eval_prepared(portable::modules::PreparedInput {
            modules: Vec::new(),
            fragment,
        })?;
        self.enter_namespace(&namespace)?;
        self.bootstrap_core = true;
        self.install_evaluation()?;
        Ok(())
    }
    pub fn with_options(options: SessionOptions) -> Result<Self, SessionError> {
        Self::with_options_in(options, Phase::Runtime)
    }
    /// Create a minimal session whose artifacts and cells use one fixed phase.
    pub fn with_options_in(options: SessionOptions, phase: Phase) -> Result<Self, SessionError> {
        Self::with_engine_in(engine()?, options, phase)
    }
    /// Caller-supplied engines must enable ABI features and fuel consumption;
    /// interruption additionally requires epoch interruption.
    pub fn with_engine(engine: Engine, options: SessionOptions) -> Result<Self, SessionError> {
        Self::with_engine_in(engine, options, Phase::Runtime)
    }
    pub fn with_engine_in(
        engine: Engine,
        options: SessionOptions,
        phase: Phase,
    ) -> Result<Self, SessionError> {
        Self::with_engine_interrupt(engine, options, phase, Arc::new(AtomicBool::new(false)))
    }
    fn with_engine_interrupt(
        engine: Engine,
        options: SessionOptions,
        phase: Phase,
        interrupt: Arc<AtomicBool>,
    ) -> Result<Self, SessionError> {
        static NEXT_ID: AtomicU64 = AtomicU64::new(1);
        let identity = NEXT_ID
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |next| {
                next.checked_add(1)
            })
            .map_err(|_| wasmtime::Error::msg("Session identity exhausted"))?;
        let mut store = Store::new(&engine, ());
        store.set_fuel(u64::MAX)?;
        install_interrupt(&mut store, &interrupt);
        let runtime_bytes = runtime_abi::module();
        runtime_abi::verify_artifact(&runtime_bytes, &runtime_abi::Manifest::default())
            .map_err(|message| SessionError::Host(wasmtime::Error::msg(message)))?;
        let runtime = Instance::new(
            &mut store,
            &crate::portable_module_cache::compile(&engine, &runtime_bytes)?,
            &[],
        )?;
        // Each session uses fresh operating-system entropy at execution time.
        // Failure propagates as a host error; no seed or constant substitutes it.
        let random = Func::wrap(&mut store, || -> wasmtime::Result<i64> {
            let mut bytes = [0; 8];
            getrandom::fill(&mut bytes)
                .map_err(|error| wasmtime::Error::msg(error.to_string()))?;
            Ok(i64::from_ne_bytes(bytes))
        });
        runtime
            .get_func(&mut store, "random-source-install")
            .ok_or_else(|| wasmtime::Error::msg("Missing random capability installer"))?
            .call(&mut store, &[Val::FuncRef(Some(random))], &mut [])?;
        let numeric_memory = runtime
            .get_memory(&mut store, "numeric-scratch-memory")
            .ok_or_else(|| wasmtime::Error::msg("Missing numeric scratch memory"))?;
        let mut linker = Linker::new(&engine);
        linker.instance(&mut store, "suss.runtime", runtime)?;
        let environment = Environment::default();
        let mut cells = BTreeMap::new();
        let bindings = portable::core_bindings::compile(phase).map_err(SessionError::Compile)?;
        runtime_abi::verify_artifact(&bindings.wasm, &runtime_abi::Manifest::default())
            .map_err(|message| SessionError::Host(wasmtime::Error::msg(message)))?;
        portable::artifact_identity::verify(
            &bindings.wasm,
            portable::artifact_identity::Expected {
                phase: Some(phase),
                macro_dependencies: Some(&[]),
                ..Default::default()
            },
        )
        .map_err(|message| SessionError::Host(wasmtime::Error::msg(message)))?;
        let module = crate::portable_module_cache::compile(&engine, &bindings.wasm)?;
        let initialized = linker.instantiate(&mut store, &module)?;
        for identity in bindings.cells {
            let global = initialized
                .get_global(&mut store, &identity.import_name())
                .ok_or_else(|| wasmtime::Error::msg("Missing compiled core binding"))?;
            linker.define(
                &store,
                identity.import_module(),
                &identity.import_name(),
                global,
            )?;
            cells.insert(identity, global);
        }
        let provided = BTreeSet::from([
            ModuleIdentity::new(phase, "suss.core").map_err(SessionError::Compile)?
        ]);
        Ok(Self {
            evaluation: None,
            engine,
            phase,
            options,
            identity,
            handles: Arc::new(AtomicUsize::new(0)),
            interrupt,
            operation_budget_depth: Arc::new(AtomicUsize::new(0)),
            store: store_access::StoreAccess::Owned(store),
            runtime,
            numeric_memory,
            compiler: Arc::new(Mutex::new(CompilerState {
                linker,
                environment,
                cells: Arc::new(cells),
                native_function_cells: Arc::new(BTreeMap::new()),
                provided,
                resident: Vec::new(),
                artifact_bytes: 0,
            })),
            base_runtime_artifact_bytes: runtime_bytes.len() + bindings.wasm.len(),
            bootstrap_core: false,
            pending_host_futures: Arc::new(Mutex::new(Vec::new())),
            native_factories: Arc::new(Mutex::new(Vec::new())),
            last_async_recovered_owner: Arc::new(Mutex::new(None)),
        })
    }
    pub fn phase(&self) -> Phase {
        self.phase
    }
    pub fn options(&self) -> &SessionOptions {
        &self.options
    }
    pub fn set_operation_fuel(&mut self, fuel: u64) {
        self.options.fuel_per_operation = fuel;
    }
    pub(crate) fn operation_fuel_remaining(&self) -> Result<u64, SessionError> {
        self.store.get_fuel().map_err(Into::into)
    }
    pub(crate) fn compilation_work_allowance(&self) -> u64 {
        if self.store.is_borrowed() || self.operation_budget_depth.load(Ordering::SeqCst) > 0 {
            // Reentry inherits the active allowance, including an owned source
            // entry's distinct compilation fuel. Never refill it from options.
            self.operation_fuel_remaining().unwrap_or(0)
        } else {
            self.options.fuel_per_operation
        }
    }
    /// An owned snapshot; native callbacks can publish namespace metadata.
    pub fn current_namespace(&self) -> String {
        registry_lock(&self.compiler).environment.current_namespace(self.phase).to_owned()
    }
    // Use the same binary64 formatter as compiled arithmetic. The REPL never
    // recompiles or re-evaluates the input to print its already-rooted result.
    pub(crate) fn number_text(&mut self, value: &SessionValue) -> Result<String, SessionError> {
        self.check(value)?;
        self.budget()?;
        let runtime = self.runtime;
        self.inspect(value, |mut store, value| {
            let function = runtime
                .get_func(&mut store, "coerce-string")
                .ok_or_else(|| wasmtime::Error::msg("Missing numeric formatter"))?;
            let mut result = [Val::null_any_ref()];
            function.call(&mut store, &[value], &mut result)?;
            let array = result[0]
                .unwrap_anyref()
                .unwrap()
                .as_array(&store)?
                .unwrap();
            let units = array
                .elems(&mut store)?
                .map(|unit| unit.unwrap_i32() as u16)
                .collect::<Vec<_>>();
            String::from_utf16(&units).map_err(wasmtime::Error::from)
        })
    }
    pub fn enter_namespace(&mut self, namespace: &str) -> Result<(), SessionError> {
        registry_lock(&self.compiler).environment
            .enter_namespace(self.phase, namespace)
            .map_err(SessionError::Compile)
    }

    /// A thread-safe handle that interrupts this session's running operation.
    pub fn interrupt_handle(&self) -> InterruptHandle {
        InterruptHandle {
            engine: self.engine.clone(),
            requested: self.interrupt.clone(),
        }
    }
    /// Run at most one queued compiled continuation under the operation budget.
    /// A runtime trap is returned after finite scheduler recovery; source effects
    /// are never replayed by recovery and the original trap remains observable.
    pub fn run_async_turn(&mut self) -> Result<bool, SessionError> {
        *registry_lock(&self.last_async_recovered_owner) = None;
        self.budget()?;
        #[cfg(all(test, not(suss_generator)))]
        let recovery_interrupt = self.interrupt_handle();
        let runtime = self.runtime;
        let mut scope = RootScope::new(&mut self.store);
        let checkpoint = dynamic_checkpoint(&mut scope, runtime)?;
        let runner = runtime
            .get_func(&mut scope, "async-scheduler-run-one")
            .ok_or_else(|| wasmtime::Error::msg("Missing async scheduler"))?;
        let mut result = [Val::I32(0)];
        let outcome = runner.call(&mut scope, &[], &mut result);
        let mut recovered_owner = None;
        let outcome = match outcome {
            Ok(()) => Ok(result[0].unwrap_i32() != 0),
            Err(error) => {
                let original =
                    execution_error(&mut scope, runtime, error, self.identity, &self.handles);
                let recovery = (|| -> wasmtime::Result<()> {
                    let fuel = scope.as_context_mut().get_fuel()?;
                    // Both attempts execute checked runtime retirement only,
                    // never the consumed source continuation or its effects.
                    scope.as_context_mut().set_fuel(u64::MAX)?;
                    // Capture only owners still Pending at the trapped boundary.
                    // Recovery can transition exactly its active owner to the
                    // private marker, excluding unrelated earlier failures.
                    let candidates = native_async::recovery_candidates(&mut scope, runtime);
                    let recovery = (|| -> wasmtime::Result<()> {
                        let function = runtime
                            .get_func(&mut scope, "async-scheduler-recover")
                            .ok_or_else(|| wasmtime::Error::msg("Missing async recovery"))?;
                        #[cfg(all(test, not(suss_generator)))]
                        tests::before_async_recovery(&recovery_interrupt);
                        let result = function.call(&mut scope, &[], &mut []);
                        #[cfg(all(test, not(suss_generator)))]
                        tests::observe_async_recovery(&result);
                        if matches!(&result, Err(error)
                            if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::Interrupt))
                        {
                            scope.as_context_mut().take_pending_exception();
                            self.interrupt.store(false, Ordering::SeqCst);
                            scope.as_context_mut().set_epoch_deadline(1);
                            return function.call(&mut scope, &[], &mut []);
                        }
                        result
                    })();
                    if recovery.is_ok() {
                        if let Ok(candidates) = candidates {
                            recovered_owner =
                                native_async::recovered_owner(&mut scope, runtime, &candidates)
                                    .ok()
                                    .flatten();
                        }
                    }
                    scope.as_context_mut().set_fuel(fuel)?;
                    recovery
                })();
                if recovery.is_err() {
                    recovered_owner = None;
                    // A secondary recovery exception must not poison the Store
                    // or replace the source turn's original execution error.
                    scope.as_context_mut().take_pending_exception();
                }
                Err(original)
            }
        };
        let restoration = restore_dynamic(&mut scope, runtime, &checkpoint);
        if restoration.is_ok() && !scope.as_context_mut().has_pending_exception() {
            *registry_lock(&self.last_async_recovered_owner) = recovered_owner;
        }
        let outcome = match outcome {
            Err(original) => Err(original),
            Ok(value) => restoration.map(|()| value),
        };
        drop(scope);
        let retirement = self.retire_host_futures();
        if retirement.is_err() {
            *registry_lock(&self.last_async_recovered_owner) = None;
        }
        match outcome {
            Err(original) => Err(original),
            Ok(value) => retirement.map(|()| value),
        }
    }
    /// Create rooted pending storage for a host operation. Completion only
    /// publishes its outcome; compiled waiters run on later scheduler turns.
    pub fn pending_future(&mut self) -> Result<SessionValue, SessionError> {
        self.pending_future_with_cancel(|| {})
    }
    /// Root a native pending operation until terminal settlement or reset.
    /// Cancellation hooks must be nonblocking and must not execute Suss source.
    /// Reset invokes each hook at most once, including across reset retries.
    pub fn pending_future_with_cancel(
        &mut self,
        cancel: impl FnOnce() + Send + 'static,
    ) -> Result<SessionValue, SessionError> {
        self.budget()?;
        let mut scope = RootScope::new(&mut self.store);
        let function = self
            .runtime
            .get_func(&mut scope, "future-pending-new")
            .ok_or_else(|| wasmtime::Error::msg("Missing pending future storage"))?;
        let future = call(
            &mut scope,
            self.runtime,
            function,
            &[],
            self.identity,
            &self.handles,
        )?;
        registry_lock(&self.pending_host_futures).push(Arc::new(PendingHostFuture {
            root: future.object()?.clone(),
            cancel: Mutex::new(Some(Box::new(cancel))),
        }));
        Ok(future)
    }
    pub fn resolve_future(
        &mut self,
        future: &SessionValue,
        value: &SessionValue,
    ) -> Result<bool, SessionError> {
        self.complete_host_future(future, value, "future-resolve")
    }
    pub fn reject_future(
        &mut self,
        future: &SessionValue,
        value: &SessionValue,
    ) -> Result<bool, SessionError> {
        self.complete_host_future(future, value, "future-reject")
    }
    fn complete_host_future(
        &mut self,
        future: &SessionValue,
        value: &SessionValue,
        operation: &str,
    ) -> Result<bool, SessionError> {
        self.check(future)?;
        self.check(value)?;
        self.budget()?;
        let ownership = self
            .runtime
            .get_func(&mut self.store, "async-future-task-owned")
            .ok_or_else(|| wasmtime::Error::msg("Missing future ownership guard"))?;
        let stream_ownership = self
            .runtime
            .get_func(&mut self.store, "stream-operation-owned")
            .ok_or_else(|| wasmtime::Error::msg("Missing stream ownership guard"))?;
        let task_owned = self.inspect(future, |mut store, future| {
            let mut result = [Val::I32(0)];
            ownership.call(&mut store, &[future], &mut result)?;
            if result[0].unwrap_i32() != 0 {
                return Ok(true);
            }
            stream_ownership.call(&mut store, &[future], &mut result)?;
            Ok(result[0].unwrap_i32() != 0)
        })?;
        if task_owned {
            let mut scope = RootScope::new(&mut self.store);
            let nil = self
                .runtime
                .get_func(&mut scope, "nil")
                .ok_or_else(|| wasmtime::Error::msg("Missing runtime nil"))?;
            let payload = call(
                &mut scope,
                self.runtime,
                nil,
                &[],
                self.identity,
                &self.handles,
            )?;
            return Err(SessionError::Language(payload));
        }
        let function = self
            .runtime
            .get_func(&mut self.store, operation)
            .ok_or_else(|| wasmtime::Error::msg("Missing future completion"))?;
        {
            // Calling native completion transfers the finished producer, even if
            // Wasm publication later traps. Consume its hook before publication;
            // a retry may publish storage, but must never cancel completed I/O.
            let mut scope = RootScope::new(&mut self.store);
            let target = future.object()?.to_rooted(&mut scope);
            let requests = registry_lock(&self.pending_host_futures).clone();
            for request in requests {
                let candidate = request.root.to_rooted(&mut scope);
                if wasmtime::Rooted::ref_eq(&scope, &target, &candidate)? {
                    request.take_cancel();
                    break;
                }
            }
        }
        let completed = self.inspect(future, |mut store, future| {
            let value = Val::AnyRef(value.rooted(&mut store));
            let mut result = [Val::I32(0)];
            function.call(&mut store, &[future, value], &mut result)?;
            Ok(result[0].unwrap_i32() != 0)
        })?;
        self.retire_host_futures()?;
        Ok(completed)
    }
    /// Request cooperative cancellation. Cleanup may suspend, so acceptance
    /// of the request does not imply that the future is terminal yet.
    pub fn cancel_future(&mut self, future: &SessionValue) -> Result<bool, SessionError> {
        self.check(future)?;
        self.budget()?;
        let function = self
            .runtime
            .get_func(&mut self.store, "async-task-cancel")
            .ok_or_else(|| wasmtime::Error::msg("Missing async cancellation"))?;
        self.inspect(future, |mut store, value| {
            let mut result = [Val::I32(0)];
            function.call(&mut store, &[value], &mut result)?;
            Ok(result[0].unwrap_i32() != 0)
        })
    }
    pub fn collect(&mut self) -> Result<(), SessionError> {
        let _request = self.operation_budget_scope()?;
        self.retire_host_futures()?;
        self.store.gc(None).map_err(Into::into)
    }
    /// Create the replacement before discarding the old Store. No replay or retained
    /// fragment state crosses reset, and old/foreign handles are checked before use.
    pub fn reset(&mut self) -> Result<(), SessionError> {
        if self.store.is_borrowed() {
            return Err(wasmtime::Error::msg("A borrowed phase cannot reset its owner").into());
        }
        let replacement = self.replacement()?;
        self.retire_for_reset()?;
        self.discard_native_requests();
        *self = replacement;
        Ok(())
    }
    fn retire_host_futures(&mut self) -> Result<(), SessionError> {
        self.budget()?;
        let status = self
            .runtime
            .get_func(&mut self.store, "future-status")
            .ok_or_else(|| wasmtime::Error::msg("Missing future status"))?;
        let mut scope = RootScope::new(&mut self.store);
        let requests = registry_lock(&self.pending_host_futures).clone();
        for request in requests {
            let future = request.root.to_rooted(&mut scope);
            let mut result = [Val::I32(0)];
            status.call(&mut scope, &[Val::AnyRef(Some(future))], &mut result)?;
            if result[0].unwrap_i32() != 0 {
                // Consume before invoking native teardown; no lock spans a hook
                // or Wasm call, and retry cannot replay a completed hook.
                if let Some(hook) = request.take_cancel() {
                    hook();
                }
                registry_lock(&self.pending_host_futures)
                    .retain(|candidate| !Arc::ptr_eq(candidate, &request));
            }
        }
        drop(scope);
        self.sweep_native_requests();
        Ok(())
    }
    fn cancel_host_requests(&mut self) -> Result<(), SessionError> {
        self.retire_host_futures()?;
        let cancel = self
            .runtime
            .get_func(&mut self.store, "future-cancel")
            .ok_or_else(|| wasmtime::Error::msg("Missing future cancellation"))?;
        let mut scope = RootScope::new(&mut self.store);
        let requests = registry_lock(&self.pending_host_futures).clone();
        for request in requests {
            // Consume before invocation: interrupted settlement cannot replay a
            // host cancellation hook on the next reset attempt.
            if let Some(hook) = request.take_cancel() {
                hook();
            }
            let future = request.root.to_rooted(&mut scope);
            cancel.call(&mut scope, &[Val::AnyRef(Some(future))], &mut [Val::I32(0)])?;
        }
        drop(scope);
        self.retire_host_futures()
    }
    /// Shared gate for direct Session and two-phase compiled REPL reset.
    /// Cancellation effects persist on ResetPending; the old Store stays usable.
    pub(crate) fn retire_for_reset(&mut self) -> Result<(), SessionError> {
        self.budget()?;
        let cancel_all = self
            .runtime
            .get_func(&mut self.store, "async-scheduler-cancel-all")
            .ok_or_else(|| wasmtime::Error::msg("Missing scheduler cancellation"))?;
        cancel_all.call(&mut self.store, &[], &mut [Val::I32(0)])?;
        self.cancel_host_requests()?;
        for _ in 0..64 {
            let ran = self.run_async_turn()?;
            self.cancel_host_requests()?;
            self.budget()?;
            let pending = self
                .runtime
                .get_func(&mut self.store, "async-scheduler-pending-task-count")
                .ok_or_else(|| wasmtime::Error::msg("Missing scheduler task count"))?;
            let counts = self
                .runtime
                .get_func(&mut self.store, "async-scheduler-counts")
                .ok_or_else(|| wasmtime::Error::msg("Missing scheduler counts"))?;
            let mut tasks = [Val::I32(-1)];
            let mut roots = [Val::I32(-1), Val::I32(-1)];
            pending.call(&mut self.store, &[], &mut tasks)?;
            counts.call(&mut self.store, &[], &mut roots)?;
            let streams = self
                .runtime
                .get_func(&mut self.store, "stream-pending-count")
                .ok_or_else(|| wasmtime::Error::msg("Missing stream operation count"))?;
            let mut operations = [Val::I32(-1)];
            streams.call(&mut self.store, &[], &mut operations)?;
            if operations[0].unwrap_i32() == 0
                && tasks[0].unwrap_i32() == 0
                && roots.iter().all(|v| v.unwrap_i32() == 0)
                && registry_lock(&self.pending_host_futures).is_empty()
            {
                return Ok(());
            }
            if !ran && roots[1].unwrap_i32() == 0 {
                return Err(SessionError::ResetPending);
            }
        }
        Err(SessionError::ResetPending)
    }
    pub(crate) fn replacement(&self) -> Result<Self, SessionError> {
        if self.store.is_borrowed() {
            return Err(wasmtime::Error::msg("A borrowed phase cannot replace its owner").into());
        }
        let mut replacement =
            Self::with_engine_interrupt(self.engine.clone(), self.options.clone(), self.phase, self.interrupt.clone())?;
        if self.bootstrap_core {
            replacement.provision_core()?;
        }
        let profiles = registry_lock(&self.native_factories).clone();
        for profile in profiles {
            replacement.install_native_profile(profile)?;
        }
        Ok(replacement)
    }
    pub(crate) fn resolves_macro_definition(&self, symbol: &suss_reader::Symbol) -> bool {
        registry_lock(&self.compiler).environment
            .resolves_bootstrap_name(self.phase, symbol, "defmacro")
    }
    fn check(&self, value: &SessionValue) -> Result<(), SessionError> {
        if value.identity == self.identity {
            Ok(())
        } else {
            Err(SessionError::ForeignValue)
        }
    }
    /// No refill: callers establish the operation budget before this scan.
    /// Each reached foreign value fails before its own charge; a valid prefix
    /// can exhaust/cancel before a later foreign value is reached.
    fn check_data_input_owners(&mut self, values: &[&SessionValue]) -> Result<(), SessionError> {
        for value in values {
            self.check(value)?;
            self.charge_host_work(1)?;
        }
        Ok(())
    }
    /// Native inspection/interop in a bounded root scope. Do not return raw Rooted
    /// references from the callback; use ordinary observations or owned host data.
    pub fn inspect<R>(
        &mut self,
        value: &SessionValue,
        f: impl FnOnce(StoreContextMut<'_, ()>, Val) -> wasmtime::Result<R>,
    ) -> Result<R, SessionError> {
        self.check(value)?;
        let mut scope = RootScope::new(&mut self.store);
        let checkpoint = dynamic_checkpoint(&mut scope, self.runtime)?;
        let value = Val::AnyRef(value.value.as_ref().map(|value| value.to_rooted(&mut scope)));
        let result = f(scope.as_context_mut(), value);
        let result = match result {
            Ok(_) if scope.as_context_mut().has_pending_exception() => Err(wasmtime::Error::msg(
                "Native callback returned success with a pending exception",
            )),
            result => result,
        };
        let outcome = result.map_err(|error| {
            execution_error(
                &mut scope,
                self.runtime,
                error,
                self.identity,
                &self.handles,
            )
        });
        restore_dynamic(&mut scope, self.runtime, &checkpoint)?;
        outcome
    }
    /// A single fueled operation inside the normal inspection/root/exception
    /// scope. Compiler-data decoding may call a captured source closure without
    /// escaping raw references or replenishing fuel per sequence element.
    pub(crate) fn data_inspect_calls<R>(
        &mut self,
        value: &SessionValue,
        function: &SessionValue,
        f: impl FnOnce(
            StoreContextMut<'_, ()>,
            Val,
            wasmtime::Func,
            wasmtime::Func,
            wasmtime::Func,
            Val,
            Val,
        ) -> wasmtime::Result<R>,
    ) -> Result<R, SessionError> {
        self.check(function)?;
        self.budget()?;
        let args_new = self
            .runtime
            .get_func(&mut self.store, "args-new")
            .expect("runtime args");
        let invoke = self
            .runtime
            .get_func(&mut self.store, "invoke")
            .expect("runtime invoke");
        let closure_new = self
            .runtime
            .get_func(&mut self.store, "closure-new")
            .expect("runtime closure-new");
        let runtime = self.runtime;
        self.inspect(value, |mut store, value| {
            let function = Val::AnyRef(function.rooted(&mut store));
            // The undefined sentinel, which reads in place of a source-array hole.
            let undefined = runtime
                .get_global(&mut store, "sentinel-undefined")
                .expect("runtime undefined")
                .get(&mut store);
            f(store, value, args_new, invoke, closure_new, function, undefined)
        })
    }
    fn budget(&mut self) -> Result<(), SessionError> {
        if self.store.is_borrowed() {
            return Self::consume_host_work(self.store.as_context_mut(), 0, &self.interrupt).map_err(Into::into);
        }
        self.refresh_evaluation_profile();
        if self.operation_budget_depth.load(Ordering::SeqCst) != 0 {
            return Ok(());
        }
        // A request made while idle does not cancel the next operation.
        self.interrupt.store(false, Ordering::SeqCst);
        self.store.set_epoch_deadline(1);
        self.store
            .set_fuel(self.options.fuel_per_operation)
            .map_err(Into::into)
    }
    /// One cumulative budget for host transport and every nested Wasm helper.
    /// Only the outermost scope starts an operation; errors and unwinding retire
    /// its scope, leaving the next operation free to establish its own budget.
    pub(crate) fn with_operation_budget<T>(
        &mut self,
        f: impl FnOnce(&mut Self) -> Result<T, SessionError>,
    ) -> Result<T, SessionError> {
        let _scope = self.operation_budget_scope()?;
        f(self)
    }
    /// Owned request guard with no Session borrow, so a caller can guard an
    /// entire define/load path while continuing to use the host's other fields.
    /// Drop balances this entry on success, error and panic unwinding.
    pub(crate) fn operation_budget_scope(&mut self) -> Result<OperationBudgetScope, SessionError> {
        self.begin_operation_budget()?;
        Ok(OperationBudgetScope(self.operation_budget_depth.clone()))
    }
    /// Begin a compiler request that can include multiple recursive expansions.
    /// The caller must arrange a matching end on success, error and unwinding.
    pub(crate) fn begin_operation_budget(&mut self) -> Result<(), SessionError> {
        let depth = self.operation_budget_depth.load(Ordering::SeqCst);
        let next = depth.checked_add(1).ok_or_else(|| {
            SessionError::Host(wasmtime::Error::msg("Operation budget scope depth exhausted"))
        })?;
        if depth == 0 {
            self.budget()?;
        }
        self.operation_budget_depth.store(next, Ordering::SeqCst);
        Ok(())
    }
    /// End the matching request without refilling fuel or clearing cancellation.
    pub(crate) fn end_operation_budget(&mut self) {
        end_operation_budget(&self.operation_budget_depth);
    }
    pub(crate) fn record_macro_declaration(&mut self, namespace: &str, name: &str) {
        registry_lock(&self.compiler).environment.record_native_macro_definition(self.phase, namespace, name, self.identity);
    }
    pub(crate) fn native_macro_exports(&self, namespace: &str) -> Vec<String> {
        registry_lock(&self.compiler).environment.macro_export_names(self.phase, namespace)
    }
    /// Cap an already-active operation without starting/refilling its budget.
    pub(crate) fn cap_operation_fuel(&mut self, limit: u64) -> Result<u64, SessionError> {
        let remaining = self.operation_fuel_remaining()?.min(limit);
        self.store.set_fuel(remaining)?;
        self.charge_host_work(0)?;
        Ok(remaining)
    }
    /// Settle a suspended parent's budget once. A child can already have spent
    /// fuel by calling this ancestor, so subtracting again from the current
    /// physical balance would charge that same work twice.
    pub(crate) fn settle_nested_fuel(&mut self, saved: u64, spent: u64) -> Result<(), SessionError> {
        let remaining = saved.checked_sub(spent).ok_or_else(|| wasmtime::Error::from(wasmtime::Trap::OutOfFuel))?;
        self.store.set_fuel(remaining)?;
        self.charge_host_work(0)
    }
    /// Capture before borrowing the Store for compiler-data traversal. This is
    /// the same cancellation flag used by this Session's epoch callback.
    pub(crate) fn host_work_interrupt(&self) -> Arc<AtomicBool> {
        self.interrupt.clone()
    }
    /// Debit host work from the current operation, without replenishing fuel.
    pub(crate) fn charge_host_work(&mut self, units: u64) -> Result<(), SessionError> {
        Self::consume_host_work(self.store.as_context_mut(), units, &self.interrupt)
            .map_err(Into::into)
    }
    /// Store-context counterpart for decoders. Callers must pass the cancellation
    /// flag captured from this same Session, not another Store's flag.
    pub(crate) fn consume_host_work(
        mut store: StoreContextMut<'_, ()>,
        units: u64,
        interrupt: &AtomicBool,
    ) -> wasmtime::Result<()> {
        if interrupt.swap(false, Ordering::SeqCst) || suspended::interrupt_requested() {
            // Match the epoch callback's consumed request, but do not let a
            // caller catch cancellation and continue the same fueled operation.
            // Finite dynamic restoration saves/restores this exhausted budget.
            store.set_fuel(0)?;
            return Err(wasmtime::Trap::Interrupt.into());
        }
        let fuel = store.get_fuel()?;
        match fuel.checked_sub(units) {
            Some(remaining) => store.set_fuel(remaining),
            None => {
                store.set_fuel(0)?;
                Err(wasmtime::Trap::OutOfFuel.into())
            }
        }
    }
    /// Validate all artifacts before allocating bindings. Stage cell imports and
    /// instantiate all fragments before publishing declarations or executing eval.
    fn install(
        &mut self,
        bytes: &[&[u8]],
        environment: Environment,
        cells: &[CellIdentity],
    ) -> Result<Vec<Instance>, SessionError> {
        compiler_state::install(
            &self.compiler, self.store.as_context_mut(), &self.engine,
            self.runtime, self.phase, bytes, environment, cells, &self.interrupt, self.evaluation.as_ref(),
        )
    }
    fn eval_instance(&mut self, instance: Instance, input: bool) -> Result<SessionValue, SessionError> {
        let _namespace = self.evaluation_input_scope(input)?;
        let mut scope = RootScope::new(&mut self.store);
        let function = instance
            .get_func(&mut scope, "eval")
            .ok_or_else(|| wasmtime::Error::msg("Missing fragment eval"))?;
        call(
            &mut scope,
            self.runtime,
            function,
            &[],
            self.identity,
            &self.handles,
        )
    }
    /// Read an already-published root through its real live binding cell.
    /// Macro catalogs store the function root, separately from def's Var result.
    pub(crate) fn binding_value(&mut self, identity: &CellIdentity) -> Result<SessionValue, SessionError> {
        let cell = registry_lock(&self.compiler).cells.get(identity).copied()
            .ok_or_else(|| wasmtime::Error::msg("Missing published binding cell"))?;
        let mut roots = RootScope::new(&mut self.store);
        let get = self.runtime.get_func(&mut roots, "binding-get")
            .ok_or_else(|| wasmtime::Error::msg("Missing binding reader"))?;
        let value = cell.get(&mut roots);
        call(&mut roots, self.runtime, get, &[value], self.identity, &self.handles)
    }
    pub(crate) fn binding_root_value(&mut self, identity: &CellIdentity) -> Result<SessionValue, SessionError> {
        let cell = registry_lock(&self.compiler).cells.get(identity).copied()
            .ok_or_else(|| wasmtime::Error::msg("Missing published binding cell"))?;
        let mut roots = RootScope::new(&mut self.store);
        let cell_value = cell.get(&mut roots);
        let reference = cell_value.unwrap_anyref()
            .ok_or_else(|| wasmtime::Error::msg("Missing binding cell storage"))?;
        let structure = reference.as_struct(&roots)?
            .ok_or_else(|| wasmtime::Error::msg("Invalid binding cell storage"))?;
        let value = structure.field(&mut roots, 0)?;
        own(&mut roots, value, self.identity, &self.handles)
    }
    pub(crate) fn identical_values(&mut self, left: &SessionValue, right: &SessionValue) -> Result<bool, SessionError> {
        self.check(left)?;
        self.check(right)?;
        match (&left.value, &right.value) {
            (None, None) => Ok(true),
            (Some(left), Some(right)) => {
                let mut roots = RootScope::new(&mut self.store);
                let left = left.to_rooted(&mut roots);
                let right = right.to_rooted(&mut roots);
                Ok(wasmtime::Rooted::ref_eq(&roots, &left, &right)?)
            }
            _ => Ok(false),
        }
    }
    pub fn eval(&mut self, source: &str) -> Result<SessionValue, SessionError> {
        let snapshot = self.compilation_snapshot();
        let prepared = portable::modules::prepare_input(
            source,
            &self.options.source_paths,
            &snapshot.environment,
            self.phase,
            &snapshot.provided,
        )
        .map_err(input_error)?;
        self.eval_prepared(prepared)
    }
    /// Evaluate host-authored source with access to built-in type internals,
    /// for core-internal structural tests. User input must use [`Self::eval`].
    #[doc(hidden)]
    pub fn eval_privileged(&mut self, source: &str) -> Result<SessionValue, SessionError> {
        let snapshot = self.compilation_snapshot();
        let prepared = portable::modules::prepare_privileged_input(
            source,
            &self.options.source_paths,
            &snapshot.environment,
            self.phase,
            &snapshot.provided,
        )
        .map_err(input_error)?;
        self.eval_prepared(prepared)
    }
    /// Publish only actual compiled macro roots owned by this phase Store.
    pub(crate) fn declare_macro_exports(
        &mut self,
        namespace: &str,
        names: &[String],
    ) -> Result<(), SessionError> {
        registry_lock(&self.compiler).environment
            .declare_macro_exports(self.phase, namespace, names)
            .map_err(SessionError::Compile)
    }
    pub(crate) fn set_source_paths(&mut self, paths: &[PathBuf]) {
        self.options.source_paths = paths.to_vec();
    }
    pub(crate) fn invalidate_source_modules(&mut self, identities: &[ModuleIdentity]) {
        for identity in identities {
            registry_lock(&self.compiler).provided.remove(identity);
        }
    }
    pub(crate) fn has_initialized_source_module(&self, identity: &ModuleIdentity) -> bool {
        registry_lock(&self.compiler).provided.contains(identity)
    }
    /// Called only after every form of this phase module has initialized.
    pub(crate) fn initialized_source_namespace(
        &mut self,
        namespace: &str,
    ) -> Result<(), SessionError> {
        registry_lock(&self.compiler).provided
            .insert(ModuleIdentity::new(self.phase, namespace).map_err(SessionError::Compile)?);
        Ok(())
    }
    pub(crate) fn binding_checkpoint(&mut self) -> Result<BindingCheckpoint, SessionError> {
        let code = registry_lock(&self.compiler);
        let mut values = BTreeMap::new();
        let mut scope = RootScope::new(&mut self.store);
        for (identity, global) in code.cells.iter() {
            let cell = global
                .get(&mut scope)
                .unwrap_anyref()
                .unwrap()
                .as_struct(&scope)?
                .unwrap();
            let value = cell
                .field(&mut scope, 0)?
                .unwrap_anyref()
                .map(|value| value.to_owned_rooted(&mut scope))
                .transpose()?;
            let bound = cell.field(&mut scope, 1)?.unwrap_i32();
            values.insert(identity.clone(), (value, bound));
        }
        Ok(BindingCheckpoint {
            environment: code.environment.clone(),
            values,
        })
    }
    pub(crate) fn restore_bindings(
        &mut self,
        checkpoint: BindingCheckpoint,
        globals: &[CellIdentity],
    ) -> Result<(), SessionError> {
        let mut scope = RootScope::new(&mut self.store);
        for identity in globals {
            if let Some(global) = registry_lock(&self.compiler).cells.get(identity).copied() {
                let cell = global
                    .get(&mut scope)
                    .unwrap_anyref()
                    .unwrap()
                    .as_struct(&scope)?
                    .unwrap();
                // A frame that held the cell since the checkpoint may still be
                // reachable from a saved context, so the cell stays dynamic.
                let dynamic = cell.field(&mut scope, 1)?.unwrap_i32() & crate::runtime_abi::CELL_DYNAMIC;
                if let Some((value, bound)) = checkpoint.values.get(identity) {
                    let value = Val::AnyRef(value.as_ref().map(|value| value.to_rooted(&mut scope)));
                    cell.set_field(&mut scope, 0, value)?;
                    cell.set_field(&mut scope, 1, Val::I32(*bound | dynamic))?;
                } else {
                    cell.set_field(&mut scope, 0, Val::AnyRef(None))?;
                    cell.set_field(&mut scope, 1, Val::I32(dynamic))?;
                }
            }
        }
        registry_lock(&self.compiler).environment
            .restore_declarations(&checkpoint.environment, globals, self.phase);
        // Keep initialized dependency cells/modules and resident code. Unpublished
        // fresh cells remain unbound and reusable under their stable identity.
        Ok(())
    }
    pub(crate) fn compilation_snapshot(&self) -> CompilationSnapshot {
        let code = registry_lock(&self.compiler);
        CompilationSnapshot {
            environment: code.environment.clone(),
            native_owner: Some(self.identity),
            phase: self.phase,
            source_paths: self.options.source_paths.clone(),
            provided: code.provided.clone(),
        }
    }
    pub(crate) fn reserve_source_identities(&mut self, prepared: &Environment) {
        registry_lock(&self.compiler).environment.reserve_prepared_identities(prepared);
    }
    pub(crate) fn publish_source_catalog(&mut self, environment: Environment) {
        registry_lock(&self.compiler).environment = environment;
    }
    pub fn eval_with_macros(
        &mut self,
        source: &str,
        expander: &mut dyn portable::ExpansionHost,
    ) -> Result<SessionValue, SessionError> {
        self.eval_input_with_macros(expander, |snapshot, expander| {
            snapshot.prepare_source(source, expander)
        }).map(|(value, _)| value)
    }
    /// Reader and REPL inputs share the caller's live macro authority while
    /// retaining their own source spans and definition-result presentation.
    pub(crate) fn eval_input_with_macros(
        &mut self,
        expander: &mut dyn portable::ExpansionHost,
        prepare: impl FnOnce(&CompilationSnapshot, &mut dyn portable::ExpansionHost)
            -> Result<portable::modules::PreparedInput, SessionError>,
    ) -> Result<(SessionValue, Option<portable::hir::ResultDefinition>), SessionError> {
        let (prepared, preparation) = self.prepare_source_input(expander, prepare)?;
        let mut preparation = Some(preparation);
        let definition = prepared.fragment.definition.clone();
        let mut linked = false;
        let outcome = self.eval_prepared_with_link(prepared, &mut linked, |session| {
            session.finish_source_input(preparation.take().expect("source preparation"), expander, true)
        });
        let cleanup = match preparation {
            Some(preparation) => self.finish_source_input(preparation, expander, false),
            None => Ok(()),
        };
        match outcome { Err(error) => Err(error), Ok(value) => { cleanup?; Ok((value, definition)) } }
    }
    pub(crate) fn prepare_source_input<T>(
        &mut self,
        expander: &mut dyn portable::ExpansionHost,
        prepare: impl FnOnce(&CompilationSnapshot, &mut dyn portable::ExpansionHost)
            -> Result<T, SessionError>,
    ) -> Result<(T, SourcePreparation), SessionError> {
        self.attach_expander(expander);
        let operation = expander.persistent_macro_context()
            .and_then(|context| context.downcast_ref::<crate::portable_macros::MacroService>())
            .map(crate::portable_macros::MacroService::operation);
        if let Some(authority) = self.local_macro_authority() {
            // Source input retains separate compile and runtime allowances.
            // A borrowed reentrant entry instead inherits its active budget.
            if !self.store.is_borrowed() && self.operation_budget_depth.load(Ordering::SeqCst) == 0 {
                self.budget()?;
                self.store.set_fuel(expander.expansion_work_fuel())?;
            }
            let profile = self.reentry_profile();
            let prepared = {
                let view = profile.bind(self.store.as_context_mut());
                authority.bind(view).prepare_native_input(prepare)?
            };
            return Ok((prepared, SourcePreparation { authority: Some(authority), _operation: operation }));
        }
        expander.begin_declarations().map_err(SessionError::Compile)?;
        match prepare(&self.compilation_snapshot(), expander) {
            Ok(prepared) => Ok((prepared, SourcePreparation { authority: None, _operation: operation })),
            Err(error) => { let _ = expander.end_declarations(false); Err(error) }
        }
    }
    pub(crate) fn finish_source_input(
        &mut self,
        preparation: SourcePreparation,
        expander: &mut dyn portable::ExpansionHost,
        commit: bool,
    ) -> Result<(), SessionError> {
        match &preparation.authority {
            Some(authority) => {
                let profile = self.reentry_profile();
                authority.bind(profile.bind(self.store.as_context_mut())).finish_native_source(commit)
            }
            None => expander.end_declarations(commit).map_err(SessionError::Compile),
        }
    }
    /// Compile reader or expanded forms through the ordinary phase/module pipeline.
    /// No source printing/rereading, initializer replay or host interpretation.
    pub fn eval_forms(
        &mut self,
        forms: Vec<suss_reader::forms::Form>,
        span: std::ops::Range<usize>,
    ) -> Result<SessionValue, SessionError> {
        let snapshot = self.compilation_snapshot();
        let prepared = portable::modules::prepare_input_forms(
            forms,
            span,
            &self.options.source_paths,
            &snapshot.environment,
            self.phase,
            &snapshot.provided,
        )
        .map_err(|error| match error {
            portable::modules::InputDiagnostic::Compile(error) => SessionError::Compile(error),
            portable::modules::InputDiagnostic::Dependency(error) => SessionError::Module(error),
        })?;
        self.eval_prepared(prepared)
    }
    pub(crate) fn eval_prepared(
        &mut self,
        prepared: portable::modules::PreparedInput,
    ) -> Result<SessionValue, SessionError> {
        self.eval_prepared_linked(prepared, &mut false)
    }
    pub(crate) fn eval_prepared_linked(
        &mut self, prepared: portable::modules::PreparedInput, linked: &mut bool,
    ) -> Result<SessionValue, SessionError> {
        self.eval_prepared_with_link(prepared, linked, |_| Ok(()))
    }
    /// Finish source declaration journals at publication, before any dependency
    /// initializer or Runtime work can wait on another compiler operation.
    pub(crate) fn eval_prepared_with_link(
        &mut self,
        prepared: portable::modules::PreparedInput,
        linked: &mut bool,
        on_link: impl FnOnce(&mut Self) -> Result<(), SessionError>,
    ) -> Result<SessionValue, SessionError> {
        let PreparedFragment {
            wasm,
            environment,
            cells,
            ..
        } = prepared.fragment;
        self.budget()?;
        let mut bytes: Vec<_> = prepared
            .modules
            .iter()
            .map(|module| module.wasm.as_slice())
            .collect();
        bytes.push(&wasm);
        let mut instances = self.install(&bytes, environment, &cells)?;
        *linked = true;
        on_link(self)?;
        let input = instances.pop().unwrap();
        self.initialize_modules(prepared.modules, instances)?;
        self.eval_instance(input, true)
    }
    /// Load source once and preserve the caller's namespace scope. Successful
    /// dependencies remain provided if a later module initializer fails.
    pub fn load_namespace(
        &mut self,
        namespace: &str,
    ) -> Result<Option<SessionValue>, SessionError> {
        let provided = registry_lock(&self.compiler).provided.clone();
        self.load_namespace_with_provided(namespace, provided, false, None)
    }
    pub fn load_namespace_with_macros(
        &mut self,
        namespace: &str,
        expander: &mut dyn portable::ExpansionHost,
    ) -> Result<Option<SessionValue>, SessionError> {
        let provided = registry_lock(&self.compiler).provided.clone();
        self.load_namespace_with_provided(namespace, provided, false, Some(expander))
    }
    /// Recompile and initialize a namespace using its existing live cells. When
    /// dependencies is true, reload its reachable dependencies in require order.
    /// The supplied core profile is reprovisioned only by reset, never file reload.
    pub fn reload_namespace(
        &mut self,
        namespace: &str,
        dependencies: bool,
    ) -> Result<Option<SessionValue>, SessionError> {
        self.reload_namespace_using(namespace, dependencies, None)
    }
    pub fn reload_namespace_with_macros(
        &mut self,
        namespace: &str,
        dependencies: bool,
        expander: &mut dyn portable::ExpansionHost,
    ) -> Result<Option<SessionValue>, SessionError> {
        self.reload_namespace_using(namespace, dependencies, Some(expander))
    }
    fn reload_namespace_using(
        &mut self,
        namespace: &str,
        dependencies: bool,
        expander: Option<&mut dyn portable::ExpansionHost>,
    ) -> Result<Option<SessionValue>, SessionError> {
        let identity = ModuleIdentity::new(self.phase, namespace).map_err(SessionError::Compile)?;
        if identity.namespace() == "suss.core" {
            return Err(SessionError::Compile(Diagnostic {
                span: 0..0,
                message: "The supplied core profile is reprovisioned by session reset".into(),
            }));
        }
        let provided = registry_lock(&self.compiler).provided
            .iter()
            .filter(|module| {
                if dependencies {
                    module.namespace() == "suss.core" || module.phase() != self.phase
                } else {
                    **module != identity
                }
            })
            .cloned()
            .collect();
        self.load_namespace_with_provided(namespace, provided, true, expander)
    }
    fn load_namespace_with_provided(
        &mut self,
        namespace: &str,
        provided: BTreeSet<ModuleIdentity>,
        reloading: bool,
        expander: Option<&mut dyn portable::ExpansionHost>,
    ) -> Result<Option<SessionValue>, SessionError> {
        let Some(expander) = expander else {
            return self.load_namespace_plan(namespace, provided, reloading, None, &mut false);
        };
        expander.begin_declarations().map_err(SessionError::Compile)?;
        let mut linked = false;
        let result = self.load_namespace_plan(namespace, provided, reloading, Some(&mut *expander), &mut linked);
        // Initializer failures retain installed state, as before. A preparation
        // or linking error must not publish compiler-only replacements.
        expander.end_declarations(linked).map_err(SessionError::Compile)?;
        result
    }
    fn load_namespace_plan(
        &mut self, namespace: &str, provided: BTreeSet<ModuleIdentity>, reloading: bool,
        expander: Option<&mut dyn portable::ExpansionHost>, linked: &mut bool,
    ) -> Result<Option<SessionValue>, SessionError> {
        let environment = registry_lock(&self.compiler).environment.clone();
        let mut plan = if let Some(expander) = expander {
            portable::modules::prepare_modules_with_expander(
                namespace,
                &self.options.source_paths,
                &environment,
                self.phase,
                &provided,
                expander,
            )
        } else {
            portable::modules::prepare_modules(
                namespace,
                &self.options.source_paths,
                &environment,
                self.phase,
                &provided,
            )
        }
        .map_err(SessionError::Module)?;
        plan.environment
            .enter_namespace(self.phase, &self.current_namespace())
            .map_err(SessionError::Compile)?;
        self.budget()?;
        let bytes: Vec<_> = plan
            .modules
            .iter()
            .map(|module| module.wasm.as_slice())
            .collect();
        let instances = self.install(&bytes, plan.environment, &plan.cells)?;
        *linked = true;
        if reloading {
            // Preparation/linking failed without changing loaded identities. Once
            // execution starts, every selected unit must complete initialization
            // before it can be considered loaded again. Earlier effects remain.
            for module in &plan.modules {
                registry_lock(&self.compiler).provided.remove(&module.identity);
            }
        }
        self.initialize_modules(plan.modules, instances)
    }
    fn initialize_modules(
        &mut self,
        modules: Vec<PreparedModule>,
        instances: Vec<Instance>,
    ) -> Result<Option<SessionValue>, SessionError> {
        let mut result = None;
        for (module, instance) in modules.into_iter().zip(instances) {
            let value = self.eval_instance(instance, false)?;
            registry_lock(&self.compiler).provided.insert(module.identity);
            result = Some(value);
        }
        Ok(result)
    }
    pub(crate) fn data_language_error(&mut self, message: &SessionValue) -> Result<SessionValue, SessionError> {
        self.check(message)?;
        self.charge_host_work(1)?;
        let mut scope = RootScope::new(&mut self.store);
        let function = self.runtime.get_func(&mut scope, "language-error-new")
            .ok_or_else(|| wasmtime::Error::msg("Missing language error constructor"))?;
        let message = message.val(&mut scope.as_context_mut());
        call(&mut scope, self.runtime, function, &[message], self.identity, &self.handles)
    }
    /// Allocate compiler data scalars through the shared runtime without compiling
    /// source, replaying initializers or adding resident fragments.
    pub(crate) fn data_scalar(
        &mut self,
        literal: &portable::hir::Literal,
    ) -> Result<SessionValue, SessionError> {
        use portable::hir::Literal;
        let ratio = if let Literal::Ratio { negative, numerator, denominator } = literal {
            let numerator = self.data_scalar(&Literal::BigInt { negative: *negative, limbs: numerator.clone(), big_integer: false })?;
            let denominator = self.data_scalar(&Literal::BigInt { negative: false, limbs: denominator.clone(), big_integer: false })?;
            Some((numerator, denominator))
        } else { None };
        let decimal = if let Literal::Decimal { negative, unscaled, .. } = literal {
            Some(self.data_scalar(&Literal::BigInt { negative: *negative, limbs: unscaled.clone(), big_integer: true })?)
        } else { None };
        self.budget()?;
        let interrupt = self.host_work_interrupt();
        let mut scope = RootScope::new(&mut self.store);
        match literal {
            Literal::Undefined => Err(SessionError::Host(wasmtime::Error::msg(
                "Compiler data has no undefined source literal",
            ))),
            Literal::Nil => own(&mut scope, Val::AnyRef(None), self.identity, &self.handles),
            Literal::Bool(value) => {
                let name = if *value { "sentinel-true" } else { "sentinel-false" };
                let value = self
                    .runtime
                    .get_global(&mut scope, name)
                    .expect("shared runtime boolean")
                    .get(&mut scope);
                own(&mut scope, value, self.identity, &self.handles)
            }
            Literal::Number(value) => {
                let function = self
                    .runtime
                    .get_func(&mut scope, "number-box")
                    .expect("shared runtime number constructor");
                call(
                    &mut scope,
                    self.runtime,
                    function,
                    &[Val::F64(value.to_bits())],
                    self.identity,
                    &self.handles,
                )
            }
            Literal::Long(value) => {
                let function = self
                    .runtime
                    .get_func(&mut scope, "long-box")
                    .expect("shared runtime long constructor");
                call(
                    &mut scope,
                    self.runtime,
                    function,
                    &[Val::I64(*value)],
                    self.identity,
                    &self.handles,
                )
            }
            Literal::Ratio { .. } => {
                let (numerator, denominator) = ratio.expect("prebuilt Ratio children");
                let arguments = [Val::AnyRef(Some(numerator.object()?.to_rooted(&mut scope))),
                    Val::AnyRef(Some(denominator.object()?.to_rooted(&mut scope)))];
                let function = self.runtime.get_func(&mut scope, "ratio-literal").expect("Ratio literal constructor");
                call(&mut scope, self.runtime, function, &arguments, self.identity, &self.handles)
            }
            Literal::Decimal { scale, .. } => {
                let unscaled = decimal.expect("prebuilt Decimal child");
                let argument = Val::AnyRef(Some(unscaled.object()?.to_rooted(&mut scope)));
                let function = self.runtime.get_func(&mut scope, "decimal-literal").expect("Decimal literal constructor");
                call(&mut scope, self.runtime, function, &[argument, Val::I32(*scale)], self.identity, &self.handles)
            }
            Literal::BigInt { negative, limbs, big_integer } => {
                let length = i32::try_from(limbs.len()).map_err(|_| SessionError::Host(wasmtime::Error::msg("Compiler data BigInt exceeds runtime length")))?;
                let allocate = self.runtime.get_func(&mut scope, "bigint-limbs-new").expect("BigInt limb allocator");
                let value = call(&mut scope, self.runtime, allocate, &[Val::I32(length)], self.identity, &self.handles)?;
                let array = value.object()?.to_rooted(&mut scope).as_array(&scope)?.expect("BigInt magnitude array");
                for (index, limb) in limbs.iter().enumerate() {
                    Self::consume_host_work(scope.as_context_mut(), 1, &interrupt)?;
                    array.set(&mut scope, index as u32, Val::I32(*limb as i32))?;
                }
                let sign = if limbs.is_empty() { 0 } else if *negative { -1 } else { 1 };
                let construct = self.runtime.get_func(&mut scope, "bigint-new").expect("BigInt constructor");
                let argument = Val::AnyRef(Some(value.object()?.to_rooted(&mut scope)));
                let result = call(&mut scope, self.runtime, construct, &[Val::I32(sign), argument, Val::I32(length)], self.identity, &self.handles)?;
                if *big_integer {
                    let convert = self.runtime.get_func(&mut scope, "integer-biginteger").expect("BigInteger constructor");
                    let argument = Val::AnyRef(Some(result.object()?.to_rooted(&mut scope)));
                    call(&mut scope, self.runtime, convert, &[argument], self.identity, &self.handles)
                } else { Ok(result) }
            }
            Literal::String(units) => {
                let length = i32::try_from(units.len()).map_err(|_| {
                    SessionError::Host(wasmtime::Error::msg(
                        "Compiler data string exceeds runtime length",
                    ))
                })?;
                let function = self
                    .runtime
                    .get_func(&mut scope, "string-new")
                    .expect("shared runtime string constructor");
                let value = call(
                    &mut scope,
                    self.runtime,
                    function,
                    &[Val::I32(length)],
                    self.identity,
                    &self.handles,
                )?;
                let array = value
                    .object()?
                    .to_rooted(&mut scope)
                    .as_array(&scope)?
                    .expect("runtime string is a UTF-16 array");
                for (index, unit) in units.iter().enumerate() {
                    Self::consume_host_work(scope.as_context_mut(), 1, &interrupt)?;
                    array.set(&mut scope, index as u32, Val::I32(i32::from(*unit)))?;
                }
                Ok(value)
            }
        }
    }
    /// Build a language array, an object array (#425), from already rooted
    /// values, preserving element identities.
    pub(crate) fn data_array(
        &mut self,
        values: &[&SessionValue],
    ) -> Result<SessionValue, SessionError> {
        self.data_array_of(values, "object-array-new")
    }
    /// An object array (#378) of already rooted values, as vectors hold.
    pub(crate) fn data_object_array(
        &mut self,
        values: &[&SessionValue],
    ) -> Result<SessionValue, SessionError> {
        self.data_array_of(values, "object-array-new")
    }
    fn data_array_of(
        &mut self,
        values: &[&SessionValue],
        constructor: &str,
    ) -> Result<SessionValue, SessionError> {
        let length = i32::try_from(values.len()).map_err(|_| {
            SessionError::Host(wasmtime::Error::msg(
                "Compiler data array exceeds runtime length",
            ))
        })?;
        self.budget()?;
        self.check_data_input_owners(values)?;
        let interrupt = self.host_work_interrupt();
        let mut scope = RootScope::new(&mut self.store);
        let mut result = [Val::null_any_ref()];
        self.runtime
            .get_func(&mut scope, "args-new")
            .expect("shared runtime argument constructor")
            .call(&mut scope, &[Val::I32(length)], &mut result)?;
        let array = result[0]
            .unwrap_anyref()
            .unwrap()
            .as_array(&scope)?
            .expect("runtime argument array");
        for (index, value) in values.iter().enumerate() {
            Self::consume_host_work(scope.as_context_mut(), 1, &interrupt)?;
            let value = Val::AnyRef(value.value.as_ref().map(|value| value.to_rooted(&mut scope)));
            array.set(&mut scope, index as u32, value)?;
        }
        let function = self
            .runtime
            .get_func(&mut scope, constructor)
            .expect("shared runtime array constructor");
        call(
            &mut scope,
            self.runtime,
            function,
            &result,
            self.identity,
            &self.handles,
        )
    }
    /// Follow the compiler's `new` path using a captured canonical class value.
    pub(crate) fn data_construct(
        &mut self,
        class: &SessionValue,
        arguments: &[&SessionValue],
    ) -> Result<SessionValue, SessionError> {
        self.check(class)?;
        self.budget()?;
        self.check_data_input_owners(arguments)?;
        let (_, plan) = self.data_constructor_plan(class)?;
        self.data_construct_from_plan(&plan, arguments)
    }
    /// The interned keyword equal to `keyword`, as guest construction
    /// interns them (#361), so host-built keywords are identical to literals.
    pub(crate) fn data_keyword_intern(&mut self, keyword: &SessionValue) -> Result<SessionValue, SessionError> {
        self.check(keyword)?;
        let mut scope = RootScope::new(&mut self.store);
        let function = self
            .runtime
            .get_func(&mut scope, "keyword-intern")
            .expect("shared runtime keyword interning");
        let value = Val::AnyRef(keyword.value.as_ref().map(|value| value.to_rooted(&mut scope)));
        call(&mut scope, self.runtime, function, &[value], self.identity, &self.handles)
    }
    fn data_constructor_plan(
        &mut self,
        class: &SessionValue,
    ) -> Result<(SessionValue, SessionValue), SessionError> {
        {
            let mut scope = RootScope::new(&mut self.store);
            let function = self
                .runtime
                .get_func(&mut scope, "constructor-descriptor")
                .expect("shared runtime class descriptor");
            let value = Val::AnyRef(class.value.as_ref().map(|value| value.to_rooted(&mut scope)));
            let descriptor = call(
                &mut scope,
                self.runtime,
                function,
                &[value],
                self.identity,
                &self.handles,
            )?;
            let function = self
                .runtime
                .get_func(&mut scope, "source-constructor-plan")
                .expect("shared runtime constructor preflight");
            let value = Val::AnyRef(descriptor.value.as_ref().map(|value| value.to_rooted(&mut scope)));
            let plan = call(
                &mut scope,
                self.runtime,
                function,
                &[value],
                self.identity,
                &self.handles,
            )?;
            Ok((descriptor, plan))
        }
    }
    fn data_construct_from_plan(
        &mut self,
        plan: &SessionValue,
        arguments: &[&SessionValue],
    ) -> Result<SessionValue, SessionError> {
        let length = i32::try_from(arguments.len()).map_err(|_| {
            SessionError::Host(wasmtime::Error::msg("Too many invocation arguments"))
        })?;
        let interrupt = self.host_work_interrupt();
        let mut scope = RootScope::new(&mut self.store);
        let mut values = [Val::null_any_ref()];
        self.runtime
            .get_func(&mut scope, "args-new")
            .unwrap()
            .call(&mut scope, &[Val::I32(length)], &mut values)?;
        let array = values[0]
            .unwrap_anyref()
            .unwrap()
            .as_array(&scope)?
            .unwrap();
        for (index, value) in arguments.iter().enumerate() {
            Self::consume_host_work(scope.as_context_mut(), 1, &interrupt)?;
            let value = Val::AnyRef(value.value.as_ref().map(|value| value.to_rooted(&mut scope)));
            array.set(&mut scope, index as u32, value)?;
        }
        let function = self
            .runtime
            .get_func(&mut scope, "source-construct-from-plan")
            .expect("shared runtime constructor plan invocation");
        let plan = Val::AnyRef(plan.value.as_ref().map(|value| value.to_rooted(&mut scope)));
        call(
            &mut scope,
            self.runtime,
            function,
            &[plan, values[0].clone()],
            self.identity,
            &self.handles,
        )
    }
    pub(crate) fn data_descriptor(
        &mut self,
        value: &SessionValue,
        class: bool,
    ) -> Result<SessionValue, SessionError> {
        self.check(value)?;
        let mut scope = RootScope::new(&mut self.store);
        let value = value.object()?.to_rooted(&mut scope);
        if class {
            let function = self
                .runtime
                .get_func(&mut scope, "constructor-descriptor")
                .expect("shared runtime class descriptor");
            call(
                &mut scope,
                self.runtime,
                function,
                &[Val::AnyRef(Some(value))],
                self.identity,
                &self.handles,
            )
        } else {
            let object = value.as_struct(&scope)?.expect("canonical compiler object");
            let descriptor = object.field(&mut scope, 0)?;
            own(&mut scope, descriptor, self.identity, &self.handles)
        }
    }
    /// Retain the field values of an already checked canonical compiler object.
    pub(crate) fn data_fields(
        &mut self,
        value: &SessionValue,
    ) -> Result<Vec<SessionValue>, SessionError> {
        self.check(value)?;
        let mut scope = RootScope::new(&mut self.store);
        let value = value.object()?.to_rooted(&mut scope);
        let object = value.as_struct(&scope)?.ok_or_else(|| {
            SessionError::Host(wasmtime::Error::msg("Compiler data needs object storage"))
        })?;
        let storage = object
            .field(&mut scope, 1)?
            .unwrap_anyref()
            .unwrap()
            .as_array(&scope)?
            .ok_or_else(|| {
                SessionError::Host(wasmtime::Error::msg("Compiler data needs field storage"))
            })?;
        let fields = storage.elems(&mut scope)?.collect::<Vec<_>>();
        fields
            .into_iter()
            .map(|field| own(&mut scope, field, self.identity, &self.handles))
            .collect()
    }
    pub fn invoke(
        &mut self,
        function: &SessionValue,
        arguments: &[&SessionValue],
    ) -> Result<SessionValue, SessionError> {
        self.invoke_with_export(function, arguments, "invoke")
    }
    /// Native transported functions include canonical metadata wrappers. Use
    /// the ordinary language IFn spread path rather than the closure-only ABI.
    pub(crate) fn invoke_callable(&mut self, function: &SessionValue, arguments: &[&SessionValue]) -> Result<SessionValue, SessionError> {
        self.invoke_with_export(function, arguments, "call-spread")
    }
    fn invoke_with_export(&mut self, function: &SessionValue, arguments: &[&SessionValue], export: &str) -> Result<SessionValue, SessionError> {
        self.check(function)?;
        let length = i32::try_from(arguments.len()).map_err(|_| {
            SessionError::Host(wasmtime::Error::msg("Too many invocation arguments"))
        })?;
        self.budget()?;
        self.check_data_input_owners(arguments)?;
        let interrupt = self.host_work_interrupt();
        let mut scope = RootScope::new(&mut self.store);
        let mut result = [Val::null_any_ref()];
        self.runtime
            .get_func(&mut scope, "args-new")
            .unwrap()
            .call(&mut scope, &[Val::I32(length)], &mut result)?;
        let array = result[0]
            .unwrap_anyref()
            .unwrap()
            .as_array(&scope)?
            .unwrap();
        for (index, value) in arguments.iter().enumerate() {
            Self::consume_host_work(scope.as_context_mut(), 1, &interrupt)?;
            let value = Val::AnyRef(value.value.as_ref().map(|value| value.to_rooted(&mut scope)));
            array.set(&mut scope, index as u32, value)?;
        }
        let function = Val::AnyRef(function.value.as_ref().map(|value| value.to_rooted(&mut scope)));
        let invoke = self.runtime.get_func(&mut scope, export).unwrap();
        call(
            &mut scope,
            self.runtime,
            invoke,
            &[function, result[0].clone()],
            self.identity,
            &self.handles,
        )
    }
}

impl SessionHost<'static> {
    pub fn stats(&self) -> SessionStats {
        let code = registry_lock(&self.compiler);
        SessionStats {
            resident_fragments: code.resident.len(),
            base_runtime_artifact_bytes: self.base_runtime_artifact_bytes,
            resident_artifact_bytes: code.artifact_bytes,
            binding_cells: code.cells.len(),
            loaded_modules: code.provided.len() - 1,
            external_value_handles: self.handles.load(Ordering::Relaxed),
            pending_host_requests: registry_lock(&self.pending_host_futures).len(),
            gc_heap_capacity: self.store.owned().expect("Session stats require an owner").gc_heap_capacity(),
            numeric_memory_capacity: self.numeric_memory.data_size(&self.store),
        }
    }
}

#[cfg(all(test, not(suss_generator)))]
mod tests {
    use super::*;
    #[test]
    fn namespace_local_macros_roll_back_on_real_link_failure() {
        let root = tempfile::tempdir().unwrap();
        std::fs::write(root.path().join("app.sus"),
            "(ns app) (defmacro answer [] 17) (def value (answer))").unwrap();
        let mut session = Session::new_repl_with_options(SessionOptions {
            source_paths: vec![root.path().to_owned()], ..SessionOptions::default()
        }).unwrap();
        let mut macros = crate::portable_macros::CompiledMacros::new().unwrap();
        session.eval("(def keep 41)").unwrap();
        let before = session.stats();
        // Artifacts remain valid and keep their original verified identities.
        // Only the test Store's linker loses its physical imports, so failure
        // occurs during actual instantiation, after declaration preparation.
        let empty = Linker::new(&session.engine);
        let old = std::mem::replace(&mut registry_lock(&session.compiler).linker, empty);
        let result = session.load_namespace_with_macros("app", &mut macros);
        registry_lock(&session.compiler).linker = old;
        let error = result.unwrap_err();
        assert!(format!("{error:?}").contains("unknown import"), "{error:?}");
        assert_eq!(session.stats(), before);
        assert_eq!(session.current_namespace(), "user");
        assert!(session.eval_with_macros("(app/answer)", &mut macros).is_err());
        assert!(session.eval("app/value").is_err());
        let keep = session.eval("keep").unwrap();
        assert_eq!(crate::portable_repl::display(&mut session, &keep).unwrap(), "41");
        session.load_namespace_with_macros("app", &mut macros).unwrap();
        let answer = session.eval_with_macros("[app/value (app/answer)]", &mut macros).unwrap();
        assert_eq!(crate::portable_repl::display(&mut session, &answer).unwrap(), "[17 17]");
    }
    fn legacy_construct(
        session: &mut Session,
        class: &SessionValue,
        arguments: &[&SessionValue],
    ) -> Result<SessionValue, SessionError> {
        session.check(class)?;
        session.budget()?;
        // Apply the same input-validation policy to isolate guest route costs.
        session.check_data_input_owners(arguments)?;
        let constructor = {
            let mut scope = RootScope::new(&mut session.store);
            let function = session
                .runtime
                .get_func(&mut scope, "constructor-descriptor")
                .expect("shared runtime class descriptor");
            let value = Val::AnyRef(class.value.as_ref().map(|value| value.to_rooted(&mut scope)));
            let descriptor = call(
                &mut scope,
                session.runtime,
                function,
                &[value],
                session.identity,
                &session.handles,
            )?;
            let function = session
                .runtime
                .get_func(&mut scope, "source-constructor-new")
                .expect("shared runtime source constructor");
            let value = Val::AnyRef(descriptor.value.as_ref().map(|value| value.to_rooted(&mut scope)));
            call(
                &mut scope,
                session.runtime,
                function,
                &[value],
                session.identity,
                &session.handles,
            )?
        };
        session.invoke(&constructor, arguments)
    }

    fn constructor_runtime_call(
        session: &mut Session,
        name: &str,
        values: &[&SessionValue],
    ) -> SessionValue {
        session.budget().unwrap();
        let mut scope = RootScope::new(&mut session.store);
        let arguments: Vec<_> = values
            .iter()
            .map(|value| Val::AnyRef(value.value.as_ref().map(|value| value.to_rooted(&mut scope))))
            .collect();
        let function = session.runtime.get_func(&mut scope, name).unwrap();
        call(
            &mut scope,
            session.runtime,
            function,
            &arguments,
            session.identity,
            &session.handles,
        )
        .unwrap()
    }
    #[test]
    fn compiler_data_constructor_plan_preserves_argument_buffer_and_reads_live_schema() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = Session::with_options_in(SessionOptions::default(), phase).unwrap();
            session
                .eval("(deftype ConstructorBufferProbe [a c b])")
                .unwrap();
            let class = session.eval("ConstructorBufferProbe").unwrap();
            let descriptor = session.data_descriptor(&class, true).unwrap();
            let plan =
                constructor_runtime_call(&mut session, "source-constructor-plan", &[&descriptor]);
            let mut arguments = Vec::new();
            for number in [7.0, 11.0, 99.0] {
                arguments.push(
                    session
                        .data_scalar(&portable::hir::Literal::Number(number))
                        .unwrap(),
                );
            }
            let buffer = {
                session.budget().unwrap();
                let mut scope = RootScope::new(&mut session.store);
                let function = session.runtime.get_func(&mut scope, "args-new").unwrap();
                call(
                    &mut scope,
                    session.runtime,
                    function,
                    &[Val::I32(3)],
                    session.identity,
                    &session.handles,
                )
                .unwrap()
            };
            session
                .inspect(&buffer, |mut store, value| {
                    let array = value.unwrap_anyref().unwrap().as_array(&store)?.unwrap();
                    for (index, argument) in arguments.iter().enumerate() {
                        let argument = argument.object().unwrap().to_rooted(&mut store);
                        array.set(&mut store, index as u32, Val::AnyRef(Some(argument)))?;
                    }
                    Ok(())
                })
                .unwrap();
            // Mutate after plan creation: plans must not retain an old schema copy.
            session
                .inspect(&descriptor, |mut store, value| {
                    let descriptor = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                    let schema = descriptor
                        .field(&mut store, 1)?
                        .unwrap_anyref()
                        .unwrap()
                        .as_array(&store)?
                        .unwrap();
                    let first = schema.get(&mut store, 0)?;
                    schema.set(&mut store, 1, first)
                })
                .unwrap();
            let object = constructor_runtime_call(
                &mut session,
                "source-construct-from-plan",
                &[&plan, &buffer],
            );
            session.collect().unwrap();
            let fields = session.data_fields(&object).unwrap();
            assert_eq!(fields.len(), 3);
            for (field, expected) in
                fields
                    .iter()
                    .zip([&arguments[1], &arguments[1], &arguments[2]])
            {
                assert!(
                    session
                        .inspect(field, |mut store, value| {
                            let expected = expected.object().unwrap().to_rooted(&mut store);
                            wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(
                                &store,
                                value.unwrap_anyref().unwrap(),
                                &expected,
                            )
                        })
                        .unwrap()
                );
            }
            session
                .inspect(&buffer, |mut store, value| {
                    let array = value.unwrap_anyref().unwrap().as_array(&store)?.unwrap();
                    assert_eq!(array.len(&store)?, 3);
                    for (index, argument) in arguments.iter().enumerate() {
                        let actual = array.get(&mut store, index as u32)?;
                        let expected = argument.object().unwrap().to_rooted(&mut store);
                        assert!(wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(
                            &store,
                            actual.unwrap_anyref().unwrap(),
                            &expected
                        )?);
                    }
                    Ok(())
                })
                .unwrap();
        }
    }
    #[test]
    fn compiler_data_constructor_plan_keeps_padding_duplicates_and_live_schema() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = Session::with_options_in(SessionOptions::default(), phase).unwrap();
            session
                .eval("(deftype ConstructorSchemaProbe [a c b])")
                .unwrap();
            let class = session.eval("ConstructorSchemaProbe").unwrap();
            let a = session
                .data_scalar(&portable::hir::Literal::Number(7.0))
                .unwrap();
            let b = session
                .data_scalar(&portable::hir::Literal::Number(11.0))
                .unwrap();
            let c = session
                .data_scalar(&portable::hir::Literal::Number(99.0))
                .unwrap();
            let descriptor = session.data_descriptor(&class, true).unwrap();
            session
                .inspect(&descriptor, |mut store, value| {
                    let descriptor = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                    let schema = descriptor
                        .field(&mut store, 1)?
                        .unwrap_anyref()
                        .unwrap()
                        .as_array(&store)?
                        .unwrap();
                    let first = schema.get(&mut store, 0)?;
                    schema.set(&mut store, 1, first)
                })
                .unwrap();
            for edited in [false, true] {
                if edited {
                    session
                        .inspect(&descriptor, |mut store, value| {
                            let descriptor =
                                value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                            let schema = descriptor
                                .field(&mut store, 1)?
                                .unwrap_anyref()
                                .unwrap()
                                .as_array(&store)?
                                .unwrap();
                            let first = schema.get(&mut store, 0)?;
                            schema.set(&mut store, 2, first)
                        })
                        .unwrap();
                }
                for arguments in [
                    vec![],
                    vec![&a],
                    vec![&a, &b],
                    vec![&a, &b, &c],
                    vec![&a, &b, &c, &a],
                ] {
                    let old = legacy_construct(&mut session, &class, &arguments).unwrap();
                    let new = session.data_construct(&class, &arguments).unwrap();
                    session.collect().unwrap();
                    let old_fields = session.data_fields(&old).unwrap();
                    let new_fields = session.data_fields(&new).unwrap();
                    assert_eq!(old_fields.len(), 3);
                    assert_eq!(new_fields.len(), 3);
                    for (left, right) in old_fields.iter().zip(&new_fields) {
                        assert!(
                            session
                                .inspect(left, |mut store, value| {
                                    let right = right.object().unwrap().to_rooted(&mut store);
                                    wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(
                                        &store,
                                        value.unwrap_anyref().unwrap(),
                                        &right,
                                    )
                                })
                                .unwrap()
                        );
                    }
                }
            }
            session
                .inspect(&descriptor, |mut store, value| {
                    let descriptor = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                    let schema = descriptor
                        .field(&mut store, 1)?
                        .unwrap_anyref()
                        .unwrap()
                        .as_array(&store)?
                        .unwrap();
                    let invalid = Val::AnyRef(a.value.as_ref().map(|value| value.to_rooted(&mut store)));
                    schema.set(&mut store, 2, invalid)
                })
                .unwrap();
            // Non-string names are not aliases in this internal ABI. Preserve
            // the existing indexed construction behavior instead of inventing
            // a new source-level schema rejection.
            for legacy in [true, false] {
                let value = if legacy {
                    legacy_construct(&mut session, &class, &[&a, &b, &c]).unwrap()
                } else {
                    session.data_construct(&class, &[&a, &b, &c]).unwrap()
                };
                let fields = session.data_fields(&value).unwrap();
                for (field, expected) in fields.iter().zip([&b, &b, &c]) {
                    assert!(
                        session
                            .inspect(field, |mut store, value| {
                                let expected = expected.object().unwrap().to_rooted(&mut store);
                                wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(
                                    &store,
                                    value.unwrap_anyref().unwrap(),
                                    &expected,
                                )
                            })
                            .unwrap()
                    );
                }
            }
            let recovery = session.eval("42").unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &recovery).unwrap(),
                "42"
            );
        }
    }
    #[test]
    fn compiler_data_constructor_plan_keeps_special_constructor_dispatch() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = Session::with_options_in(SessionOptions::default(), phase).unwrap();
            let message = session
                .data_scalar(&portable::hir::Literal::String(
                    "plan-message".encode_utf16().collect(),
                ))
                .unwrap();
            for factory in [
                "error-constructor",
                "range-error-constructor",
                "type-error-constructor",
            ] {
                let class = constructor_runtime_call(&mut session, factory, &[]);
                let descriptor = session.data_descriptor(&class, true).unwrap();
                for legacy in [true, false] {
                    let value = if legacy {
                        legacy_construct(&mut session, &class, &[&message]).unwrap()
                    } else {
                        session.data_construct(&class, &[&message]).unwrap()
                    };
                    session.collect().unwrap();
                    session
                        .inspect(&value, |mut store, value| {
                            let error = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                            let found = error.field(&mut store, 0)?;
                            let expected = descriptor.object().unwrap().to_rooted(&mut store);
                            assert!(wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(
                                &store,
                                found.unwrap_anyref().unwrap(),
                                &expected
                            )?);
                            let message = error
                                .field(&mut store, 1)?
                                .unwrap_anyref()
                                .unwrap()
                                .as_array(&store)?
                                .unwrap();
                            let units: Vec<_> = message
                                .elems(&mut store)?
                                .map(|unit| unit.unwrap_i32() as u16)
                                .collect();
                            assert_eq!(units, "plan-message".encode_utf16().collect::<Vec<_>>());
                            Ok(())
                        })
                        .unwrap();
                }
                if factory != "range-error-constructor" {
                    let replacement = session.eval("(fn [x] 73)").unwrap();
                    session
                        .inspect(&descriptor, |mut store, value| {
                            let descriptor =
                                value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                            let cache = descriptor
                                .field(&mut store, 2)?
                                .unwrap_anyref()
                                .unwrap()
                                .as_array(&store)?
                                .unwrap();
                            let original = class.object().unwrap().to_rooted(&mut store);
                            let mut replaced = false;
                            for index in (1..cache.len(&store)?).step_by(2) {
                                let entry = cache.get(&mut store, index)?;
                                if let Some(entry) = entry.unwrap_anyref() {
                                    if wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(
                                        &store, entry, &original,
                                    )? {
                                        let replacement = replacement.object().unwrap().to_rooted(&mut store);
                                        cache.set(
                                            &mut store,
                                            index,
                                            Val::AnyRef(Some(replacement)),
                                        )?;
                                        replaced = true;
                                        break;
                                    }
                                }
                            }
                            assert!(replaced, "live constructor cache entry");
                            Ok(())
                        })
                        .unwrap();
                    for legacy in [true, false] {
                        let value = if legacy {
                            legacy_construct(&mut session, &class, &[&message]).unwrap()
                        } else {
                            session.data_construct(&class, &[&message]).unwrap()
                        };
                        session.collect().unwrap();
                        assert_eq!(
                            crate::portable_repl::display(&mut session, &value).unwrap(),
                            "73"
                        );
                    }
                    session
                        .inspect(&descriptor, |mut store, value| {
                            let descriptor =
                                value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                            let cache = descriptor
                                .field(&mut store, 2)?
                                .unwrap_anyref()
                                .unwrap()
                                .as_array(&store)?
                                .unwrap();
                            let replaced = replacement.object().unwrap().to_rooted(&mut store);
                            let mut restored = false;
                            for index in (1..cache.len(&store)?).step_by(2) {
                                let entry = cache.get(&mut store, index)?;
                                if let Some(entry) = entry.unwrap_anyref() {
                                    if wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(
                                        &store, entry, &replaced,
                                    )? {
                                        let original = class.object().unwrap().to_rooted(&mut store);
                                        cache.set(
                                            &mut store,
                                            index,
                                            Val::AnyRef(Some(original)),
                                        )?;
                                        restored = true;
                                        break;
                                    }
                                }
                            }
                            assert!(
                                restored,
                                "restore constructor before dependent factory tests"
                            );
                            Ok(())
                        })
                        .unwrap();
                }
            }
            let object = constructor_runtime_call(&mut session, "object-constructor", &[]);
            let input = constructor_runtime_call(&mut session, "native-object-default-new", &[]);
            for legacy in [true, false] {
                let value = if legacy {
                    legacy_construct(&mut session, &object, &[&input]).unwrap()
                } else {
                    session.data_construct(&object, &[&input]).unwrap()
                };
                session.collect().unwrap();
                assert!(
                    session
                        .inspect(&value, |mut store, value| {
                            let input = input.object().unwrap().to_rooted(&mut store);
                            wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(
                                &store,
                                value.unwrap_anyref().unwrap(),
                                &input,
                            )
                        })
                        .unwrap()
                );
            }
        }
    }
    #[test]
    fn compiler_data_constructor_plan_preflight_ownership_fuel_and_interrupt_recovery() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = Session::with_options_in(SessionOptions::default(), phase).unwrap();
            session
                .eval("(deftype ConstructorGuardProbe [a b])")
                .unwrap();
            let class = session.eval("ConstructorGuardProbe").unwrap();
            let a = session
                .data_scalar(&portable::hir::Literal::Number(7.0))
                .unwrap();
            let descriptor = session.data_descriptor(&class, true).unwrap();
            let bad_class = {
                let mut scope = RootScope::new(&mut session.store);
                let original = descriptor
                    .object()
                    .unwrap()
                    .to_rooted(&mut scope)
                    .as_struct(&scope)
                    .unwrap()
                    .unwrap();
                let ty = original.ty(&scope).unwrap();
                let allocator = wasmtime::StructRefPre::new(&mut scope, ty);
                let mut fields = original.fields(&mut scope).unwrap().collect::<Vec<_>>();
                fields[1] = Val::AnyRef(a.value.as_ref().map(|value| value.to_rooted(&mut scope)));
                let invalid = wasmtime::StructRef::new(&mut scope, &allocator, &fields)
                    .unwrap()
                    .to_anyref();
                let original = class
                    .object()
                    .unwrap()
                    .to_rooted(&mut scope)
                    .as_struct(&scope)
                    .unwrap()
                    .unwrap();
                let ty = original.ty(&scope).unwrap();
                let allocator = wasmtime::StructRefPre::new(&mut scope, ty);
                let mut fields = original.fields(&mut scope).unwrap().collect::<Vec<_>>();
                fields[crate::runtime_abi::UNIVERSAL_ENVIRONMENT as usize] = Val::AnyRef(Some(invalid));
                let invalid = wasmtime::StructRef::new(&mut scope, &allocator, &fields)
                    .unwrap()
                    .to_anyref();
                own(
                    &mut scope,
                    Val::AnyRef(Some(invalid)),
                    session.identity,
                    &session.handles,
                )
                .unwrap()
            };
            for legacy in [true, false] {
                let error = if legacy {
                    legacy_construct(&mut session, &bad_class, &[&a, &a])
                } else {
                    session.data_construct(&bad_class, &[&a, &a])
                }
                .unwrap_err();
                assert!(matches!(error, SessionError::Language(_)), "{error:?}");
            }
            let mut costs = Vec::new();
            for legacy in [true, false] {
                let request = session.operation_budget_scope().unwrap();
                let before = session.store.get_fuel().unwrap();
                let error = if legacy {
                    legacy_construct(&mut session, &bad_class, &[&a, &a])
                } else {
                    session.data_construct(&bad_class, &[&a, &a])
                }
                .unwrap_err();
                assert!(matches!(error, SessionError::Language(_)));
                costs.push(before - session.store.get_fuel().unwrap());
                drop(request);
            }
            assert_eq!(
                costs[0], costs[1],
                "invalid-schema preflight must precede argument allocation"
            );
            let mut foreign = Session::new().unwrap();
            let value = foreign
                .data_scalar(&portable::hir::Literal::Number(1.0))
                .unwrap();
            let before = session.stats();
            assert!(matches!(
                session.data_construct(&class, &[&value]),
                Err(SessionError::ForeignValue)
            ));
            assert_eq!(session.stats(), before);
            drop(session.data_construct(&class, &[&a, &a]).unwrap());
            session.set_operation_fuel(1000);
            for interrupt in [false, true] {
                let request = session.operation_budget_scope().unwrap();
                let before = session.stats();
                if interrupt {
                    session.interrupt_handle().interrupt();
                } else {
                    session.store.set_fuel(0).unwrap();
                }
                let error = session.data_construct(&class, &[&a, &a]).unwrap_err();
                if interrupt {
                    assert!(error.is_interrupt(), "{error:?}");
                } else {
                    assert!(
                        matches!(error, SessionError::Trap(ref error) if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel))
                    );
                }
                assert_eq!(session.stats(), before);
                drop(request);
                let value = session
                    .with_operation_budget(|session| session.data_construct(&class, &[&a, &a]))
                    .unwrap();
                assert_eq!(session.data_fields(&value).unwrap().len(), 2);
            }
        }
    }
    #[test]
    fn compiler_data_constructor_plan_preserves_fields_and_reduces_fuel() {
        let mut failures = Vec::new();
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = Session::with_options_in(SessionOptions::default(), phase).unwrap();
            session
                .eval("(deftype ConstructorPlanProbe [a b])")
                .unwrap();
            let class = session.eval("ConstructorPlanProbe").unwrap();
            let a = session
                .data_scalar(&portable::hir::Literal::Number(7.0))
                .unwrap();
            let b = session
                .data_scalar(&portable::hir::Literal::Number(11.0))
                .unwrap();
            drop(legacy_construct(&mut session, &class, &[&a, &b]).unwrap());
            drop(session.data_construct(&class, &[&a, &b]).unwrap());
            let mut costs = Vec::new();
            for legacy in [true, false] {
                let request = session.operation_budget_scope().unwrap();
                let before = session.store.get_fuel().unwrap();
                let mut last = None;
                for _ in 0..1000 {
                    last = Some(if legacy {
                        legacy_construct(&mut session, &class, &[&a, &b]).unwrap()
                    } else {
                        session.data_construct(&class, &[&a, &b]).unwrap()
                    });
                }
                costs.push(before - session.store.get_fuel().unwrap());
                drop(request);
                let value = last.unwrap();
                session.collect().unwrap();
                let fields = session.data_fields(&value).unwrap();
                assert_eq!(fields.len(), 2);
                for (field, expected) in fields.iter().zip([&a, &b]) {
                    assert!(
                        session
                            .inspect(field, |mut store, value| {
                                let expected = expected.object().unwrap().to_rooted(&mut store);
                                wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(
                                    &store,
                                    value.unwrap_anyref().unwrap(),
                                    &expected,
                                )
                            })
                            .unwrap()
                    );
                }
            }
            eprintln!(
                "{phase:?} constructor plan legacy={} planned={}",
                costs[0], costs[1]
            );
            if costs[1] >= costs[0] {
                failures.push(format!("{phase:?}: {costs:?}"));
            }
        }
        assert!(failures.is_empty(), "{}", failures.join("\n"));
    }
    #[test]
    fn operation_budget_host_exhaustion_and_next_request_recovery() {
        let mut session = Session::new().unwrap();
        session.set_operation_fuel(100);
        let error = session.with_operation_budget(|session| {
            for _ in 0..4 {
                session.charge_host_work(25)?;
            }
            assert_eq!(session.store.get_fuel().unwrap(), 0);
            session.charge_host_work(1)
        }).unwrap_err();
        assert!(matches!(error, SessionError::Trap(ref error)
            if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)));
        assert_eq!(session.operation_budget_depth.load(Ordering::SeqCst), 0);
        session.with_operation_budget(|session| {
            assert_eq!(session.store.get_fuel()?, 100);
            session.charge_host_work(17)?;
            assert_eq!(session.store.get_fuel()?, 83);
            Ok(())
        }).unwrap();
    }

    #[test]
    fn operation_budget_request_hooks_and_nested_helpers_share_fuel() {
        let mut session = Session::new().unwrap();
        session.set_operation_fuel(100);
        session.begin_operation_budget().unwrap();
        session.charge_host_work(7).unwrap();
        session.with_operation_budget(|session| {
            assert_eq!(session.operation_budget_depth.load(Ordering::SeqCst), 2);
            session.budget()?;
            session.charge_host_work(11)
        }).unwrap();
        // Separate transformer calls inside the same prepare request cannot reset it.
        session.with_operation_budget(|session| session.charge_host_work(13)).unwrap();
        assert_eq!(session.store.get_fuel().unwrap(), 69);
        assert_eq!(session.operation_budget_depth.load(Ordering::SeqCst), 1);
        session.end_operation_budget();
        assert_eq!(session.store.get_fuel().unwrap(), 69);
        session.begin_operation_budget().unwrap();
        assert_eq!(session.store.get_fuel().unwrap(), 100);
        session.end_operation_budget();
    }

    #[test]
    fn operation_budget_wasm_helpers_and_host_work_share_exhaustion() {
        let mut session = Session::new().unwrap();
        let function = session.eval("(fn [] 17)").unwrap();
        // Measure genuine helper consumption instead of assuming emitted instruction costs.
        let cost = session.with_operation_budget(|session| {
            let before = session.store.get_fuel()?;
            session.invoke(&function, &[])?;
            Ok(before - session.store.get_fuel()?)
        }).unwrap();
        assert!(cost > 0);
        session.set_operation_fuel(cost);
        let error = session.with_operation_budget(|session| {
            session.charge_host_work(cost)?;
            session.invoke(&function, &[])
        }).unwrap_err();
        assert!(matches!(error, SessionError::Trap(ref error)
            if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)));
        assert_eq!(session.store.get_fuel().unwrap(), 0,
            "dynamic restoration must preserve the exhausted operation's fuel");
        session.set_operation_fuel(10_000_000);
        session.with_operation_budget(|session| {
            let before = session.store.get_fuel()?;
            session.invoke(&function, &[])?;
            let after_first = session.store.get_fuel()?;
            session.invoke(&function, &[])?;
            assert!(after_first < before);
            assert!(session.store.get_fuel()? < after_first,
                "a repeated invoke must not replenish helper fuel");
            Ok(())
        }).unwrap();
    }

    #[test]
    fn operation_budget_nested_entry_preserves_interrupt_for_host_decoder() {
        let mut session = Session::new().unwrap();
        session.set_operation_fuel(100);
        let interrupt = session.host_work_interrupt();
        let error = session.with_operation_budget(|session| {
            session.charge_host_work(7)?;
            interrupt.store(true, Ordering::SeqCst);
            session.with_operation_budget(|session| {
                session.budget()?;
                assert!(interrupt.load(Ordering::SeqCst));
                Session::consume_host_work(session.store.as_context_mut(), 1, &interrupt)
                    .map_err(Into::into)
            })
        }).unwrap_err();
        assert!(error.is_interrupt());
        assert_eq!(session.store.get_fuel().unwrap(), 0);
        assert!(!interrupt.load(Ordering::SeqCst));
        assert_eq!(session.operation_budget_depth.load(Ordering::SeqCst), 0);
        session.with_operation_budget(|session| session.charge_host_work(1)).unwrap();
        assert_eq!(session.store.get_fuel().unwrap(), 99);
    }

    #[test]
    fn operation_budget_panic_unwinds_all_nested_scope_depths() {
        let mut session = Session::new().unwrap();
        session.set_operation_fuel(100);
        let panic = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let _: Result<(), SessionError> = session.with_operation_budget(|session| {
                session.charge_host_work(17)?;
                session.with_operation_budget(|session| {
                    session.charge_host_work(19)?;
                    panic!("intentional operation-budget unwind")
                })
            });
        }));
        assert!(panic.is_err());
        assert_eq!(session.operation_budget_depth.load(Ordering::SeqCst), 0);
        assert_eq!(session.store.get_fuel().unwrap(), 64);
        session.with_operation_budget(|session| {
            assert_eq!(session.store.get_fuel()?, 100);
            session.charge_host_work(1)
        }).unwrap();
    }

    std::thread_local! {
        static INTERRUPT_ASYNC_RECOVERY: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
        static OBSERVED_RECOVERY_INTERRUPT: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
    }
    pub(super) fn before_async_recovery(handle: &InterruptHandle) {
        if INTERRUPT_ASYNC_RECOVERY.with(|armed| armed.replace(false)) {
            // This raises the real engine epoch and exercises the Store callback.
            // It runs immediately before the real runtime recovery call.
            handle.interrupt();
        }
    }
    pub(super) fn observe_async_recovery(result: &wasmtime::Result<()>) {
        if matches!(result, Err(error)
            if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::Interrupt))
        {
            OBSERVED_RECOVERY_INTERRUPT.with(|observed| observed.set(true));
        }
    }

    #[test]
    fn session_lifecycle_secondary_interrupt_preserves_async_fuel_trap_and_retires_roots() {
        fn value<C: AsContextMut<Data = ()>>(
            scope: &mut RootScope<C>,
            runtime: Instance,
            name: &str,
            args: &[Val],
        ) -> Val {
            let mut result = [Val::null_any_ref()];
            runtime
                .get_func(&mut *scope, name)
                .unwrap()
                .call(&mut *scope, args, &mut result)
                .unwrap();
            result[0].clone()
        }
        let mut session = Session::new_repl().unwrap();
        session
            .eval("(def effects 0) (def join-effects 0) (def ^:dynamic *value* 1)")
            .unwrap();
        let resume = session.eval(
            "(fn [c] (do (set! effects (+ effects 1)) (binding [*value* 7] (str (reify Object (toString [_] (set! join-effects (+ join-effects 1)) (loop [] (recur))))))))",
        ).unwrap();
        let runtime = session.runtime;
        let (producer, token, caller) = {
            let mut scope = RootScope::new(&mut session.store);
            let caller = dynamic_checkpoint(&mut scope, runtime).unwrap();
            let producer = value(&mut scope, runtime, "future-pending-new", &[]);
            let slots = value(&mut scope, runtime, "args-new", &[Val::I32(0)]);
            let unwind = value(&mut scope, runtime, "args-new", &[Val::I32(0)]);
            let frame = value(&mut scope, runtime, "dynamic-fork", &[]);
            let nil = value(&mut scope, runtime, "nil", &[]);
            // Continuation pc/generation/event fields are raw i31 scalars.
            let zero = Val::AnyRef(Some(wasmtime::AnyRef::from_i31(
                &mut scope,
                wasmtime::I31::wrapping_u32(0),
            )));
            let state = value(&mut scope, runtime, "args-new", &[Val::I32(8)]);
            let array = state
                .unwrap_anyref()
                .unwrap()
                .as_array(&scope)
                .unwrap()
                .unwrap();
            for (index, item) in [
                zero.clone(),
                slots,
                unwind,
                frame,
                producer.clone(),
                zero.clone(),
                zero,
                nil,
            ]
            .into_iter()
            .enumerate()
            {
                array.set(&mut scope, index as u32, item).unwrap();
            }
            let continuation = value(&mut scope, runtime, "async-continuation-new", &[state]);
            let resume = Val::AnyRef(resume.value.as_ref().map(|value| value.to_rooted(&mut scope)));
            let token = value(
                &mut scope,
                runtime,
                "async-task-start",
                &[continuation, resume],
            );
            (
                own(&mut scope, producer, session.identity, &session.handles).unwrap(),
                own(&mut scope, token, session.identity, &session.handles).unwrap(),
                caller,
            )
        };
        session.set_operation_fuel(1_000_000);
        OBSERVED_RECOVERY_INTERRUPT.with(|observed| observed.set(false));
        INTERRUPT_ASYNC_RECOVERY.with(|armed| armed.set(true));
        let error = session.run_async_turn().unwrap_err();
        assert!(
            matches!(&error, SessionError::Trap(error)
            if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)),
            "{error:?}"
        );
        assert!(
            !error.is_interrupt(),
            "secondary interrupt must not replace OutOfFuel"
        );
        assert!(
            OBSERVED_RECOVERY_INTERRUPT.with(|observed| observed.replace(false)),
            "the real recovery call must actually receive Interrupt"
        );
        assert!(!INTERRUPT_ASYNC_RECOVERY.with(|armed| armed.get()));
        assert!(!session.interrupt.load(Ordering::SeqCst));
        assert!(!session.store.has_pending_exception());
        {
            let mut scope = RootScope::new(&mut session.store);
            let current = dynamic_checkpoint(&mut scope, runtime).unwrap();
            // Either root may be nil; two nils are the same root.
            for (current, caller) in [
                (&current.frame, &caller.frame),
            ] {
                let current = current.as_ref().map(|root| root.to_rooted(&mut scope));
                let caller = caller.as_ref().map(|root| root.to_rooted(&mut scope));
                match (current, caller) {
                    (Some(current), Some(caller)) => {
                        assert!(wasmtime::Rooted::ref_eq(&scope, &current, &caller).unwrap())
                    }
                    (current, caller) => assert!(current.is_none() && caller.is_none()),
                }
            }
        }
        session.set_operation_fuel(1_000_000);
        assert!(
            !session.run_async_turn().unwrap(),
            "next turn must finish retirement without replay"
        );
        assert!(
            !session.run_async_turn().unwrap(),
            "retirement is idempotent"
        );
        assert!(!session.store.has_pending_exception());
        let mut counts = [Val::I32(-1), Val::I32(-1)];
        runtime
            .get_func(&mut session.store, "async-scheduler-counts")
            .unwrap()
            .call(&mut session.store, &[], &mut counts)
            .unwrap();
        assert_eq!((counts[0].unwrap_i32(), counts[1].unwrap_i32()), (0, 0));
        // Even with the old token retained by a host root, it cannot reenqueue.
        session
            .inspect(&token, |mut store, token| {
                let mut result = [Val::I32(-1)];
                runtime
                    .get_func(&mut store, "async-registration-enqueue")
                    .unwrap()
                    .call(&mut store, &[token, Val::I32(0)], &mut result)?;
                assert_eq!(result[0].unwrap_i32(), 0);
                Ok(())
            })
            .unwrap();
        session
            .inspect(&producer, |mut store, producer| {
                let mut status = [Val::I32(-1)];
                runtime
                    .get_func(&mut store, "future-status")
                    .unwrap()
                    .call(&mut store, &[producer], &mut status)?;
                assert_eq!(status[0].unwrap_i32(), 2, "trapped producer is failed");
                Ok(())
            })
            .unwrap();
        for (source, expected) in [
            ("effects", "1"),
            ("join-effects", "1"),
            ("*value*", "1"),
            ("(+ 20 22)", "42"),
        ] {
            let result = session.eval(source).unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &result).unwrap(),
                expected
            );
        }
    }

    #[test]
    fn session_lifecycle_reset_unknown_producer_preserves_store_and_retries_cleanup() {
        let mut session = Session::new_repl().unwrap();
        let mut macros = crate::portable_macros::CompiledMacros::new().unwrap();
        session.eval_with_macros(
            "(ns reset-callback-test (:require [suss.async]) (:require-macros [suss.async :refer [future]]))",
            &mut macros,
        ).unwrap();
        session.eval("(def effects 0)").unwrap();
        let make = session.eval_with_macros(
            "(fn [dependency cleanup] (suss.async/future (try (suss.async/await* dependency) (finally (suss.async/await* cleanup) (set! effects (+ effects 1))))))",
            &mut macros,
        ).unwrap();
        let dependency = session.pending_future().unwrap();
        // Source completion has no native cancellation hook/known host producer.
        let cleanup = session.eval("(suss.async/completion)").unwrap();
        let task = session.invoke(&make, &[&dependency, &cleanup]).unwrap();
        assert!(session.run_async_turn().unwrap());
        assert!(
            !session.run_async_turn().unwrap(),
            "task is awaiting host completion"
        );
        assert!(session.cancel_future(&task).unwrap());
        assert!(session.run_async_turn().unwrap());
        assert!(
            !session.run_async_turn().unwrap(),
            "cancellation cleanup is suspended too"
        );
        session.collect().unwrap();

        let identity = session.identity;
        assert!(matches!(session.reset(), Err(SessionError::ResetPending)));
        assert_eq!(session.identity, identity);
        assert!(
            matches!(
                crate::portable_repl::reset_compiled(&mut session, &mut macros),
                Err(SessionError::ResetPending)
            ),
            "compiled REPL cannot bypass retirement"
        );
        assert_eq!(session.identity, identity);
        let effects = session.eval("effects").unwrap();
        assert_eq!(
            crate::portable_repl::display(&mut session, &effects).unwrap(),
            "0"
        );
        let old_payload = session.eval("42").unwrap();
        assert!(
            session.resolve_future(&cleanup, &old_payload).unwrap(),
            "old Store remains available for explicit cleanup completion"
        );
        assert!(session.run_async_turn().unwrap());
        assert!(!session.run_async_turn().unwrap());
        let effects = session.eval("effects").unwrap();
        assert_eq!(
            crate::portable_repl::display(&mut session, &effects).unwrap(),
            "1"
        );
        crate::portable_repl::reset_compiled(&mut session, &mut macros).unwrap();
        assert!(
            !session.run_async_turn().unwrap(),
            "old scheduler work cannot cross reset"
        );
        session.eval("(def effects 0)").unwrap();
        let payload = session.eval("42").unwrap();
        let before = session.stats();
        // A fresh payload avoids rejection merely because the payload is stale:
        // the old pending target itself must fail before runtime settlement.
        for old in [&dependency, &cleanup, &task] {
            assert!(matches!(
                session.resolve_future(old, &payload),
                Err(SessionError::ForeignValue)
            ));
            assert!(matches!(
                session.reject_future(old, &payload),
                Err(SessionError::ForeignValue)
            ));
            assert!(matches!(
                session.cancel_future(old),
                Err(SessionError::ForeignValue)
            ));
            assert_eq!(session.stats(), before);
            assert!(!session.store.has_pending_exception());
        }
        assert!(
            !session.run_async_turn().unwrap(),
            "late callbacks cannot queue an old continuation"
        );
        let effects = session.eval("effects").unwrap();
        assert_eq!(
            crate::portable_repl::display(&mut session, &effects).unwrap(),
            "0"
        );

        session.eval_with_macros(
            "(ns reset-callback-test (:require [suss.async]) (:require-macros [suss.async :refer [future]]))",
            &mut macros,
        ).unwrap();
        let make = session.eval_with_macros(
            "(fn [dependency] (suss.async/future (suss.async/await* dependency) (set! user/effects (+ user/effects 1))))",
            &mut macros,
        ).unwrap();
        let pending = session.pending_future().unwrap();
        let fresh_task = session.invoke(&make, &[&pending]).unwrap();
        assert!(session.run_async_turn().unwrap());
        assert!(!session.run_async_turn().unwrap());
        assert!(session.resolve_future(&pending, &payload).unwrap());
        assert!(!session.reject_future(&pending, &payload).unwrap());
        assert!(session.run_async_turn().unwrap());
        assert!(!session.run_async_turn().unwrap());
        session.collect().unwrap();
        let effects = session.eval("user/effects").unwrap();
        assert_eq!(
            crate::portable_repl::display(&mut session, &effects).unwrap(),
            "1"
        );
        drop(fresh_task);
        // This covers native generation checks, not disposal of real host I/O
        // resources or transport of canonical component callbacks.
    }

    #[test]
    fn session_lifecycle_reset_host_hook_once_and_cleanup_catches_cancellation() {
        struct ReadGuard(Arc<AtomicUsize>);
        impl Drop for ReadGuard {
            fn drop(&mut self) {
                self.0.fetch_add(1, Ordering::SeqCst);
            }
        }
        let calls = Arc::new(AtomicUsize::new(0));
        let drops = Arc::new(AtomicUsize::new(0));
        let mut session = Session::new_repl().unwrap();
        let mut macros = crate::portable_macros::CompiledMacros::new().unwrap();
        session.eval_with_macros(
            "(ns hooked-reset (:require [suss.async]) (:require-macros [suss.async :refer [future]]))",
            &mut macros,
        ).unwrap();
        session.eval("(def effects 0)").unwrap();
        let make = session.eval_with_macros(
            "(fn [dependency cleanup gate] (suss.async/future (try (suss.async/await* dependency) (finally (try (suss.async/await* cleanup) (catch :default cancelled (set! effects (+ effects 10)))) (suss.async/await* gate) (set! effects (+ effects 1))))))",
            &mut macros,
        ).unwrap();
        let dependency = session.pending_future().unwrap();
        let guard = ReadGuard(drops.clone());
        let called = calls.clone();
        let cleanup = session
            .pending_future_with_cancel(move || {
                called.fetch_add(1, Ordering::SeqCst);
                drop(guard);
            })
            .unwrap();
        let gate = session.eval("(suss.async/completion)").unwrap();
        let task = session
            .invoke(&make, &[&dependency, &cleanup, &gate])
            .unwrap();
        assert!(session.run_async_turn().unwrap());
        assert!(!session.run_async_turn().unwrap());
        let identity = session.identity;
        assert!(matches!(session.reset(), Err(SessionError::ResetPending)));
        assert_eq!(session.identity, identity);
        assert_eq!(calls.load(Ordering::SeqCst), 1);
        assert_eq!(
            drops.load(Ordering::SeqCst),
            1,
            "captured host read guard is released"
        );
        assert_eq!(session.stats().pending_host_requests, 0);
        let effects = session.eval("effects").unwrap();
        assert_eq!(
            crate::portable_repl::display(&mut session, &effects).unwrap(),
            "10",
            "cleanup must catch a cancellation event, not a fabricated Ready"
        );
        assert!(matches!(session.reset(), Err(SessionError::ResetPending)));
        assert_eq!(
            calls.load(Ordering::SeqCst),
            1,
            "reset retries never replay host hooks"
        );
        assert_eq!(drops.load(Ordering::SeqCst), 1);
        let payload = session.eval("42").unwrap();
        assert!(
            !session.resolve_future(&cleanup, &payload).unwrap(),
            "cancelled cleanup stays terminal"
        );
        assert!(session.resolve_future(&gate, &payload).unwrap());
        assert!(session.run_async_turn().unwrap());
        assert!(!session.run_async_turn().unwrap());
        let effects = session.eval("effects").unwrap();
        assert_eq!(
            crate::portable_repl::display(&mut session, &effects).unwrap(),
            "11",
            "the old Store executes the remaining cleanup exactly once"
        );
        session.reset().unwrap();
        assert_eq!(calls.load(Ordering::SeqCst), 1);
        assert_eq!(drops.load(Ordering::SeqCst), 1);
        assert!(matches!(
            session.cancel_future(&task),
            Err(SessionError::ForeignValue)
        ));
        assert!(!session.run_async_turn().unwrap());
    }

    #[test]
    fn session_lifecycle_host_registry_roots_are_independent_and_completion_releases_hook() {
        let calls = Arc::new(AtomicUsize::new(0));
        let mut session = Session::new().unwrap();
        let called = calls.clone();
        let settled = session
            .pending_future_with_cancel(move || {
                called.fetch_add(1, Ordering::SeqCst);
            })
            .unwrap();
        assert_eq!(session.stats().pending_host_requests, 1);
        assert_eq!(session.stats().external_value_handles, 1);
        let payload = session.eval("42").unwrap();
        assert!(session.resolve_future(&settled, &payload).unwrap());
        assert_eq!(session.stats().pending_host_requests, 0);
        assert_eq!(
            calls.load(Ordering::SeqCst),
            0,
            "normal completion must not cancel host I/O"
        );
        drop(settled);
        drop(payload);
        let called = calls.clone();
        let pending = session
            .pending_future_with_cancel(move || {
                called.fetch_add(1, Ordering::SeqCst);
            })
            .unwrap();
        drop(pending);
        assert_eq!(session.stats().external_value_handles, 0);
        assert_eq!(
            session.stats().pending_host_requests,
            1,
            "host registry independently owns its root"
        );
        session.collect().unwrap();
        assert_eq!(session.stats().pending_host_requests, 1);
        session.reset().unwrap();
        assert_eq!(session.stats().pending_host_requests, 0);
        assert_eq!(session.stats().external_value_handles, 0);
        assert_eq!(calls.load(Ordering::SeqCst), 1);
        session.reset().unwrap();
        assert_eq!(calls.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn collector_settings_default_to_copying_and_validate_overrides() {
        use std::env::VarError::NotPresent;
        let setting = |value: &str| Ok(value.to_owned());
        assert!(matches!(
            collector_settings(Err(NotPresent), Err(NotPresent)),
            Ok((wasmtime::Collector::Copying, GC_HEAP_INITIAL_SIZE))
        ));
        assert!(matches!(
            collector_settings(setting("null"), setting("0")),
            Ok((wasmtime::Collector::Null, 0))
        ));
        assert!(matches!(
            collector_settings(setting("copying"), setting("256")),
            Ok((wasmtime::Collector::Copying, 268_435_456))
        ));
        for (gc, initial) in [("drc", "1"), ("auto", "1"), ("copying", "-1"), ("copying", "1.5")] {
            assert!(collector_settings(setting(gc), setting(initial)).is_err(), "{gc} {initial}");
        }
    }
    #[test]
    fn session_lifecycle_native_callback_trap_restores_dynamic_context() {
        let mut session = Session::new().unwrap();
        session.eval("(def ^:dynamic *value* 1.0)").unwrap();
        let body = session
            .eval("(fn [] (binding [*value* 7] (loop [] (recur))))")
            .unwrap();
        let invoke = session
            .runtime
            .get_func(&mut session.store, "invoke")
            .unwrap();
        let args_new = session
            .runtime
            .get_func(&mut session.store, "args-new")
            .unwrap();
        session.store.set_fuel(5_000).unwrap();
        let result = session.inspect(&body, |mut store, body| {
            let mut args = [Val::null_any_ref()];
            args_new.call(&mut store, &[Val::I32(0)], &mut args)?;
            invoke.call(
                &mut store,
                &[body, args[0].clone()],
                &mut [Val::null_any_ref()],
            )
        });
        assert!(matches!(result, Err(SessionError::Trap(_))));
        session.set_operation_fuel(50_000);
        let value = session.eval("*value*").unwrap();
        let bits = session
            .inspect(&value, |mut store, value| {
                let number = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                Ok(number.field(&mut store, 0)?.unwrap_f64())
            })
            .unwrap();
        assert_eq!(bits.to_bits(), 1.0f64.to_bits());
    }
    #[test]
    fn session_lifecycle_numeric_helper_trap_resets_interrupted_rust_stack() {
        let mut session = Session::new().unwrap();
        let value = session.eval("\"1.2345678901234567890123456789\"").unwrap();
        let function = session
            .runtime
            .get_func(&mut session.store, "coerce-number")
            .unwrap();
        let stack = session
            .runtime
            .get_global(&mut session.store, "numeric-stack-pointer")
            .unwrap();
        let initial = stack.get(&mut session.store).unwrap_i32();
        let mut interrupted = false;
        for fuel in (64..=4096).step_by(64) {
            stack.set(&mut session.store, Val::I32(initial)).unwrap();
            session.store.set_fuel(fuel).unwrap();
            let result = session.inspect(&value, |mut scope, value| {
                let mut output = [Val::F64(0)];
                function.call(&mut scope, &[value], &mut output)?;
                Ok(output[0].unwrap_f64())
            });
            if matches!(result, Err(SessionError::Trap(ref error)) if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel))
                && stack.get(&mut session.store).unwrap_i32() != initial
            {
                interrupted = true;
                break;
            }
        }
        assert!(
            interrupted,
            "must actually interrupt a Rust helper frame, not just its GC copy loop"
        );
        session.set_operation_fuel(100000);
        // A double, so the string conversion calls the numeric helper.
        let output = session.eval("(suss.bootstrap/value-add 42.5 \"\")").unwrap();
        let units = session
            .inspect(&output, |mut scope, value| {
                let array = value.unwrap_anyref().unwrap().as_array(&scope)?.unwrap();
                Ok(array
                    .elems(&mut scope)?
                    .map(|unit| unit.unwrap_i32() as u16)
                    .collect::<Vec<_>>())
            })
            .unwrap();
        assert_eq!(units, [52, 50, 46, 53]);
        assert_eq!(stack.get(&mut session.store).unwrap_i32(), initial);
    }
    #[test]
    fn session_lifecycle_native_callback_foreign_exception_does_not_poison_the_store() {
        let mut session = Session::new().unwrap();
        let value = session.eval("7").unwrap();
        let error = session
            .inspect(&value, |mut store, _| -> wasmtime::Result<()> {
                let ty = wasmtime::ExnType::new(store.engine(), [ValType::I32])?;
                let tag = Tag::new(&mut store, &ty.tag_type())?;
                let allocator = wasmtime::ExnRefPre::new(&mut store, ty);
                let exception =
                    wasmtime::ExnRef::new(&mut store, &allocator, &tag, &[Val::I32(42)])?;
                store.throw(exception)
            })
            .unwrap_err();
        assert!(matches!(error, SessionError::Host(_)));
        assert!(!session.store.has_pending_exception());
        session.eval("42").unwrap();
    }
    #[test]
    fn session_lifecycle_callback_translated_exception_clears_pending_state() {
        let mut session = Session::new().unwrap();
        let value = session.eval("7").unwrap();
        for translated_success in [false, true] {
            let error = session
                .inspect(&value, |mut store, _| -> wasmtime::Result<()> {
                    let ty = wasmtime::ExnType::new(store.engine(), [ValType::I32])?;
                    let tag = Tag::new(&mut store, &ty.tag_type())?;
                    let allocator = wasmtime::ExnRefPre::new(&mut store, ty);
                    let exception =
                        wasmtime::ExnRef::new(&mut store, &allocator, &tag, &[Val::I32(42)])?;
                    let thrown = store.throw::<()>(exception);
                    if translated_success {
                        let _ = thrown;
                        Ok(())
                    } else {
                        thrown.map_err(|_| {
                            wasmtime::Error::msg("native callback translated exception")
                        })
                    }
                })
                .unwrap_err();
            let SessionError::Host(error) = error else {
                panic!("translated callback exceptions must be host errors")
            };
            assert!(error.to_string().contains(if translated_success {
                "returned success with a pending exception"
            } else {
                "native callback translated exception"
            }));
            assert!(!session.store.has_pending_exception());
            assert_eq!(session.stats().external_value_handles, 1);
            let next = session.eval("42.0").unwrap();
            let bits = session
                .inspect(&next, |mut store, value| {
                    let number = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                    let fields = number.fields(&mut store)?.collect::<Vec<_>>();
                    let [Val::F64(bits)] = fields.as_slice() else {
                        panic!("expected exact Number layout")
                    };
                    Ok(*bits)
                })
                .unwrap();
            assert_eq!(bits, 42.0f64.to_bits());
        }
    }
    #[test]
    fn session_lifecycle_all_artifacts_are_gated_before_allocating_or_publishing_cells() {
        let mut session = Session::new().unwrap();
        let prepared =
            portable::prepare_fragment("(def ghost 7)", &registry_lock(&session.compiler).environment, Phase::Runtime)
                .unwrap();
        let before = session.stats();
        assert!(matches!(
            session.install(
                &[&prepared.wasm, &[]],
                prepared.environment.clone(),
                &prepared.cells
            ),
            Err(SessionError::Host(_))
        ));
        assert_eq!(session.stats(), before);
        assert!(matches!(
            session.eval("ghost"),
            Err(SessionError::Compile(_))
        ));
        // A missing actual cell import also fails linking before publication/eval.
        assert!(matches!(
            session.install(&[&prepared.wasm], prepared.environment, &[]),
            Err(SessionError::Host(_))
        ));
        assert_eq!(session.stats(), before);
        assert!(matches!(
            session.eval("ghost"),
            Err(SessionError::Compile(_))
        ));
    }
    #[test]
    fn session_lifecycle_compiler_build_identity_is_checked_before_any_cells() {
        fn read_uleb(bytes: &[u8], offset: &mut usize) -> usize {
            let mut value = 0usize;
            let mut shift = 0;
            loop {
                let byte = bytes[*offset];
                *offset += 1;
                value |= ((byte & 127) as usize) << shift;
                if byte & 128 == 0 {
                    return value;
                }
                shift += 7;
            }
        }
        fn write_uleb(mut value: usize, bytes: &mut Vec<u8>) {
            loop {
                let mut byte = (value & 127) as u8;
                value >>= 7;
                if value != 0 {
                    byte |= 128;
                }
                bytes.push(byte);
                if value == 0 {
                    break;
                }
            }
        }
        let mut session = Session::new().unwrap();
        session.eval("(def keep 17.0)").unwrap();
        let prepared =
            portable::prepare_fragment("(def ghost 7)", &registry_lock(&session.compiler).environment, Phase::Runtime)
                .unwrap();
        // Remove the source identity section if emitted, keeping every other
        // byte intact. This fixture runs before and after the production gate.
        let mut wasm = prepared.wasm[..8].to_vec();
        let mut offset = 8;
        while offset < prepared.wasm.len() {
            let start = offset;
            let id = prepared.wasm[offset];
            offset += 1;
            let length = read_uleb(&prepared.wasm, &mut offset);
            let end = offset + length;
            let skip = if id == 0 {
                let mut name_offset = offset;
                let name_length = read_uleb(&prepared.wasm, &mut name_offset);
                &prepared.wasm[name_offset..name_offset + name_length] == b"suss.source-artifact"
            } else {
                false
            };
            if !skip {
                wasm.extend_from_slice(&prepared.wasm[start..end]);
            }
            offset = end;
        }
        let abi = runtime_abi::Manifest::default();
        let manifest = portable::artifact_identity::Manifest {
            format_version: 2,
            compiler_source_sha256: "0".repeat(64),
            runtime_abi: abi.runtime_abi,
            compiler: abi.compiler,
            wasm_tools: abi.wasm_tools,
            target: "portable-wasm-gc-shared-abi".into(),
            profile: "default".into(),
            flags: vec![],
            phase: Some("runtime".into()),
            source_sha256: Some(portable::bootstrap::sha256(b"(def ghost 7)")),
            source_path: None,
            macro_dependencies: None,
            wasm_sha256: portable::bootstrap::sha256(&wasm),
        };
        let mut data = Vec::new();
        write_uleb(b"suss.source-artifact".len(), &mut data);
        data.extend_from_slice(b"suss.source-artifact");
        data.extend_from_slice(suss_reader::edn::to_string(&manifest).unwrap().as_bytes());
        wasm.push(0);
        write_uleb(data.len(), &mut wasm);
        wasm.extend_from_slice(&data);
        let before = session.stats();
        let result = session.install(
            &[&prepared.wasm, &wasm],
            prepared.environment,
            &prepared.cells,
        );
        let error = result
            .expect_err("same package version with incompatible compiler bytes must be rejected");
        assert!(
            error.to_string().contains("compiler build identity"),
            "{error}"
        );
        assert_eq!(session.stats(), before);
        assert!(matches!(
            session.eval("ghost"),
            Err(SessionError::Compile(_))
        ));
        let keep = session.eval("keep").unwrap();
        let bits = session
            .inspect(&keep, |mut store, value| {
                let number = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                let fields = number.fields(&mut store)?.collect::<Vec<_>>();
                let [Val::F64(bits)] = fields.as_slice() else {
                    panic!("Expected ordinary number")
                };
                Ok(*bits)
            })
            .unwrap();
        assert_eq!(bits, 17.0f64.to_bits());
    }

    #[test]
    fn session_lifecycle_phase_identity_rejects_entire_batch_before_publication() {
        let mut session = Session::new().unwrap();
        session.eval("(def keep 17)").unwrap();
        let prepared =
            portable::prepare_fragment("(def ghost 7)", &registry_lock(&session.compiler).environment, Phase::Runtime)
                .unwrap();
        let wrong_phase = portable::artifact_identity::annotate_source(
            &prepared.wasm,
            Phase::Macro,
            Some(&portable::SourceOrigin::new("(def ghost 7)", None)),
            Some(&[]),
        )
        .unwrap();
        // These are valid executable bytes with a valid body digest, but belong
        // to the other isolated phase. Even the preceding valid fragment must
        // not allocate or publish its staged bindings on this failure.
        portable::artifact_identity::verify(&wrong_phase, Default::default()).unwrap();
        let before = session.stats();
        let result = session.install(
            &[&prepared.wasm, &wrong_phase],
            prepared.environment,
            &prepared.cells,
        );
        assert!(
            result
                .unwrap_err()
                .to_string()
                .contains("phase identity mismatch")
        );
        assert_eq!(session.stats(), before);
        assert!(matches!(
            session.eval("ghost"),
            Err(SessionError::Compile(_))
        ));
        let keep = session.eval("keep").unwrap();
        assert_eq!(
            crate::portable_repl::display(&mut session, &keep).unwrap(),
            "17"
        );
        // A failed batch must leave the ordinary loader usable.
        let recovered = session.eval("(def ghost 23)").unwrap();
        assert_eq!(
            crate::portable_repl::display(&mut session, &recovered).unwrap(),
            "23"
        );
    }
}
