from pathlib import Path
import copy,gzip,hashlib,importlib.util,json,subprocess,sys
E=Path(__file__).resolve().parent
J=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
out=J/'results/m12-eval/native-after-root-diagnostic-review';c=json.loads((out/'controller.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert c['complete'] and c['inputs_unchanged'] and c['head_unchanged'] and c['binaryen_unchanged']
assert c['native_commands']=={'suite-build':0,'suite-run':0,'suite-lock':0}
assert all((J/n).is_file() and sha((J/n).read_bytes())==h for n,h in c['inputs'].items())
assert all(sha(Path(n).read_bytes())==h for n,h in c['binaryen'].items())
runner=E/'run-root-diagnostic-native.py';assert sha(runner.read_bytes())==c['runner_sha256']
sys.path.insert(0,str(J/'scripts'));import clojure_test_suite as suite
reference=json.loads((J/'tests/oracle/clojure-test-suite-observations.json').read_text())
raw=(out/'complete-capture/suite-capture/suite-observations.json').read_bytes();actual=json.loads(raw)
current=(J/'tests/oracle/clojure-test-suite-known-failures.json').read_bytes()
assert sha(current)=='dea450719d6460a0ef6ad6853a17aacdacd4538d65d75aaec71809196624e72d'
counts,measured=suite.compare(reference,actual);assert measured==json.loads(current)
original=J/'results/m12-eval/eval-broader-after-symbol-and-var-contract/complete-capture'
old=json.loads(gzip.decompress((original/'suite-capture/suite-observations.json.gz').read_bytes()))
assert [(r['test'],r['ordinal']) for r in actual['assertions']]==[(r['test'],r['ordinal']) for r in old['assertions']]
refs={r['id']:r for r in reference['assertions']}
assert all(suite.decide(refs[a['test']+'#'+str(a['ordinal'])],a)==suite.decide(refs[b['test']+'#'+str(b['ordinal'])],b) for a,b in zip(actual['assertions'],old['assertions']))
normalized=copy.deepcopy(actual)
for ns in ['clojure.core-test.add-watch','clojure.core-test.remove-watch']:
 row=next(r for r in normalized['namespaces'] if r['namespace']==ns)
 assert 'Unresolved Runtime name ref at bytes' in row['diagnostic']
 row['diagnostic']=row['diagnostic'].replace('Unresolved Runtime name ref at bytes','Unresolved Runtime name alter-var-root at bytes')
spec=importlib.util.spec_from_file_location('strict',J/'results/m12-eval/review-complete-capture.py');reviewer=importlib.util.module_from_spec(spec);spec.loader.exec_module(reviewer)
prior=gzip.decompress((J/'results/m12-reader-followup/full-suite-after-random-and-assert/suite-capture/suite-observations.json.gz').read_bytes())
report=reviewer.review((J/'tests/oracle/clojure-test-suite-observations.json').read_bytes(),gzip.decompress((original/'parent-random-baseline.json.gz').read_bytes()),prior,json.dumps(normalized).encode())
proposed=report.pop('proposed_baseline')
for ns in ['clojure.core-test.add-watch','clojure.core-test.remove-watch']:proposed['namespaces'][ns]['diagnostic']=proposed['namespaces'][ns]['diagnostic'].replace('Unresolved Runtime name alter-var-root at bytes','Unresolved Runtime name ref at bytes')
assert proposed==json.loads(current) and report['counts']==counts
archive=J/'results/m12-eval/root-diagnostic-native-checkpoint';archive.mkdir(exist_ok=False)
files={}
for p in out.rglob('*'):
 if p.is_file():
  n=str(p.relative_to(out));b=p.read_bytes();target=archive/(n+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(b,mtime=0));files[n]=sha(b)
for n,b in [('runner.py',runner.read_bytes()),('reviewer.py',Path(__file__).read_bytes())]:
 (archive/(n+'.gz')).write_bytes(gzip.compress(b,mtime=0))
overlays={}
for n,h in c['inputs'].items():
 try:b=subprocess.check_output(['git','show',c['head']+':'+n],cwd=J,stderr=subprocess.DEVNULL)
 except subprocess.CalledProcessError:b=None
 if b is None or sha(b)!=h:
  raw_input=(J/n).read_bytes();target=archive/'source-overlay'/(n+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw_input,mtime=0));overlays[n]=h
report.update(head=c['head'],source_overlay=overlays,capture_sha256=sha(raw),baseline_sha256=sha(current),actual_native_exit_code=0,observed_row_decisions_preserved=5564,files=files,qualification='Fresh complete actual native0 with frozen source/HEAD/tools. All5564 ordered decisions and prior successes retained, full34eval and229/200numeric host matches. Only two previously reviewed blocked namespace diagnostics differ from the old ledger; all unrelated failures/count/skip/guest rules remain. Source overlay reconstructs exact executed bytes. Workspace, remaining acceptance, review and final CI are separate.')
(archive/'review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['files','source_overlay']},indent=2))
