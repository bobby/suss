from pathlib import Path
import gzip, hashlib, json, re, sys

E = Path(__file__).resolve().parent
J = Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
P = J / 'results/m12-eval/reviewed-core-public-controls-after-generator-refresh'
r = json.loads((P / 'commands.json').read_text())
assert r['complete'] and r['exit_code'] == 0 and r['inputs_head_runner_tools_jars_conserved']
assert r['runner_archived'] and json.loads((P / 'deleted.json').read_text()) == []
assert hashlib.sha256(gzip.decompress((P / 'runner.py.gz').read_bytes())).hexdigest() == r['runner_sha256']
assert all(c['complete'] and c['exit_code'] == 0 for c in r['commands'])
counts_by_command = {c['name']: sum(map(int, re.findall(r'test result: ok\. (\d+) passed;',
                     (P / (c['name'] + '.log')).read_text()))) for c in r['commands']}
assert counts_by_command == {'complete-public-eval-controls': 90,
    'inherited-core-repair-regressions': 3, 'complete-original-upstream-bodies-and-guards': 22,
    'java-node-free-bootstrap': 4, 'core-import-source-check': 0, 'final-source-provenance': 0}
sys.path.insert(0, str(J / 'scripts'))
import clojure_test_suite as suite
raw = (J / 'tests/oracle/clojure-test-suite-observations.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == '449264ab6bca1dcf761d0204e4a64de4de91562e576615c4e84a63246839f4c7'
reference = json.loads(raw)
expected = json.loads((J / 'tests/oracle/clojure-test-suite-known-failures.json').read_text())
actual = json.loads((P / 'capture/suite-observations.json').read_text())
counts, failures = suite.compare(reference, actual)
assert failures == expected
assert counts == {'pass': 5354, 'guest-judged': 106, 'fail': 105,
                  'not-executed': 1374, 'skipped': 0, 'namespaces-failed': 63}
parent = json.loads((E.parent / 'native-host-var-foundation/results/native-host-foundation/exact-workspace-prepared-var-checkpoint/capture/suite-observations.json').read_text())
key = lambda row: row['test'] + '#' + str(row['ordinal'])
refs = {row['id']: row for row in reference['assertions']}
old = {key(row): row for row in parent['assertions']}
new = {key(row): row for row in actual['assertions']}
assert len(old) == 5530 and len(new) == 5564
assert set(old) <= set(new)
assert [key(row) for row in actual['assertions'] if key(row) in old] == list(old)
assert all(suite.decide(refs[k], v) == suite.decide(refs[k], new[k]) for k, v in old.items())
test = 'clojure.core-test.eval/test-eval'
assert set(new) - set(old) == {test + '#' + str(n) for n in range(1, 35)}
body = json.loads((P / 'capture/eval-observations.json').read_text())
rows = body['assertions']
assert [key(row) for row in rows] == [test + '#' + str(n) for n in range(1, 35)]
assert body['namespaces'] == [{'namespace': 'clojure.core-test.eval', 'status': 'loaded'}]
assert not body['test-failures'] and not body['skips']
guests = [row['ordinal'] for row in rows if suite.decide(refs[key(row)], row)[1]]
assert guests == [15, 16, 17, 18, 19]
assert all(suite.decide(refs[key(row)], row)[0] is None for row in rows)
assert all(suite.decide(refs[test + '#' + str(n)], rows[n - 1]) == (None, False) for n in [5, 6, 7])
assert all(suite.decide(refs[key(row)], row) == suite.decide(refs[key(row)], new[key(row)]) for row in rows)
protected = {'crates/suss-compile/tests/support/pinned_eval_body.rs': '850134f328f985e80db35f684a30077565d926b9a44d4f887fb8b3478d98ea83',
             'vendor/clojure-test-suite/upstream/test/clojure/core_test/eval.cljc': '10e081daf9f51f5859c5bdce9354ebb90c1760aaec2660c6f2018bbe500635e1'}
assert all(hashlib.sha256((J / n).read_bytes()).hexdigest() == h for n, h in protected.items())
out = {'source_head': r['head'], 'phase': r['phase'], 'actual_exit': 0,
       'frozen_inputs': len(r['inputs']), 'inputs_head_runner_tools_jars_conserved': True,
       'runner_archived': True, 'rust_test_executions': sum(counts_by_command.values()),
       'counts_by_command': counts_by_command, 'fresh_primary_controls': 24,
       'fresh_primary_receipt': r['reused_source_primary_validation'],
       'complete_original_eval_body': {'rows': 34, 'host_matches': 29, 'guest_ordinals': guests,
            'unexecuted': 0, 'skips': 0, 'numeric_rows_independent_host_matches': [5, 6, 7]},
       'full_capture_rows': len(new), 'parent_capture_rows': len(old),
       'all_parent_ids_order_and_decisions_preserved': True,
       'only_new_ids_are_the_original_34_eval_rows': True,
       'counts': counts, 'failure_ledger_exact': True, 'protected_original_files': protected,
       'capture_sha256': hashlib.sha256((P / 'capture/suite-observations.json').read_bytes()).hexdigest(),
       'qualification': 'Actual scoped native consumer execution/capture and bootstrap only. Exact consumer workspace, independent promotion review and final published-head CI remain required. Complete numeric criteria/tagged host corpus remain in the numeric consumer.'}
(E / 'eval-reviewed-core-native-audit.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({k: v for k, v in out.items() if k != 'fresh_primary_receipt'}, indent=2))
