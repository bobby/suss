"""Execute the repaired test registration; retain the prior full-run identity."""
from pathlib import Path
import gzip, hashlib, json, os, re, subprocess, sys, time

E = Path(__file__).resolve().parent
J = Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
phase, expected_head = sys.argv[1:]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=J,text=True).strip()
assert head == expected_head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=J,text=True)
assert os.environ['SUSS_DURABLE_SCOPE'] in Path('/proc/self/cgroup').read_text()
full = J/'results/m12-eval/exact-workspace-reviewed-core-eval-disk-tmp'
prior = json.loads((full/'commands.json').read_text())
assert prior['complete'] and prior['exit_code']==0 and prior['inputs_unchanged'] and prior['binaryen_unchanged']
assert (full/'runner.py.gz').is_file() and json.loads((full/'deleted.json').read_text())==[]
assert not Path(f"/proc/{prior['recorder_pid']}").exists()
assert subprocess.check_output(['git','diff','--name-only',prior['head'],head],cwd=J,text=True).splitlines()==['crates/suss-compile/tests/portable_symbol_conversion.rs']
out=J/'results/m12-eval'/phase;out.mkdir(exist_ok=False)
temp=E/'eval-test-temp'/phase;temp.mkdir(parents=True,exist_ok=False,mode=0o700)
tracked=set(subprocess.check_output(['git','ls-files'],cwd=J,text=True).splitlines())
paths=set(subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=J,text=True).splitlines())
paths={p for p in paths if p in tracked or not p.startswith('results/') or ('/overlay/' not in p and '/source-overlay/' not in p and (any('primary' in a for a in Path(p).parts) or p.endswith(('cases.json','reference.json'))))}
inputs={p:sha(J/p) for p in sorted(paths) if (J/p).is_file()}
binaryen=J.parent/'m11-binaryen/binaryen-version_133/bin'
tools={str(binaryen/n):sha(binaryen/n) for n in ['wasm-opt','wasm-merge']}
r={'head':head,'phase':phase,'recorder_pid':os.getpid(),'scope':os.environ['SUSS_DURABLE_SCOPE'],
   'inputs':inputs,'binaryen':tools,'runner_sha256':sha(Path(__file__)),'commands':[],
   'temporary_directory':str(temp),'complete':False,'prior_full_head':prior['head']}
env=os.environ|{'CARGO_TARGET_DIR':str(J.parent/'m12-some-fn-target'),'TMPDIR':str(temp),
   'CARGO_BUILD_JOBS':'1','RUSTUP_TOOLCHAIN':'stable','BINARYEN_CORES':'1','SUSS_WASM_OPT':str(binaryen/'wasm-opt')}
env['PATH']=str(binaryen)+os.pathsep+env['PATH']
def save(): (out/'commands.json').write_text(json.dumps(r,indent=2)+'\n')
def conserved():
    return (head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=J,text=True).strip()
        and all((J/p).is_file() and sha(J/p)==h for p,h in inputs.items())
        and sha(Path(__file__))==r['runner_sha256'])
def run(name,command):
    assert conserved()
    row={'name':name,'command':command,'complete':False};r['commands'].append(row);save()
    start=time.monotonic()
    with (out/(name+'.log')).open('w') as log:
        proc=subprocess.Popen(command,cwd=J,env=env,stdout=log,stderr=subprocess.STDOUT)
        row['pid']=proc.pid;save();code=proc.wait()
    row.update(complete=True,exit_code=code,seconds=time.monotonic()-start);save()
    print(row,flush=True)
    if code:raise RuntimeError(f'{name}: actual exit {code}')
try:
    save()
    run('build-current-symbol-target',['cargo','test','--workspace','--locked','--test','portable_symbol_conversion','--no-run','--message-format=json'])
    artifacts=[]
    for line in (out/'build-current-symbol-target.log').read_text().splitlines():
        try: artifacts.append(json.loads(line))
        except ValueError: pass
    executable=next(a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='portable_symbol_conversion' and a.get('executable'))
    r['test_executable_sha256']=sha(Path(executable));save()
    run('actual-symbol-test-registration',[executable,'--list'])
    names=re.findall(r'^([\w:]+): test$',(out/'actual-symbol-test-registration.log').read_text(),re.M)
    assert len(names)==8
    assert {'retained_var_keeps_thunk_lookup_metadata_equality_hash_and_invocation_arities',
        'retained_identifier_dependency_matches_shared_pinned_corpus_in_both_phases'}<=set(names)
    r['registered_test_names']=names;save()
    run('complete-registered-symbol-and-var-controls',['cargo','test','--workspace','--locked','--test','portable_symbol_conversion','--','--test-threads=2'])
    assert sha(Path(executable))==r['test_executable_sha256']
    assert 'test result: ok. 8 passed; 0 failed; 0 ignored;' in (out/'complete-registered-symbol-and-var-controls.log').read_text()
except Exception as exc:
    r['controller_error']=repr(exc)
finally:
    r.update(complete=True,inputs_unchanged=conserved(),binaryen_unchanged=all(sha(Path(p))==h for p,h in tools.items()))
    r['exit_code']=next((c['exit_code'] for c in r['commands'] if c.get('exit_code')),1 if 'controller_error' in r else 0)
    if not r['inputs_unchanged'] or not r['binaryen_unchanged']:r['exit_code']=r['exit_code'] or 1
    save()
    if r['inputs_unchanged'] and r['binaryen_unchanged']:
        (out/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
        for name in inputs.keys()-tracked:
            q=out/'overlay'/(name+'.gz');q.parent.mkdir(parents=True,exist_ok=True)
            q.write_bytes(gzip.compress((J/name).read_bytes(),mtime=0))
        (out/'deleted.json').write_text('[]\n');r['runner_archived']=True;save()
    print(json.dumps({k:v for k,v in r.items() if k not in ['inputs','commands']},indent=2),flush=True)
sys.exit(r['exit_code'])
