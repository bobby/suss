from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
phase=sys.argv[1]
mode=sys.argv[2]
assert mode in ['build-cache','full']
temp_root=Path(__file__).resolve().parent/'eval-test-temp'/phase
temp_root.mkdir(parents=True,exist_ok=False,mode=0o700)
out=root/'results/m12-eval'/phase
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='052668a3776a64fcc6ce58269ee5d0f524b315a1'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True).strip()
assert os.environ['SUSS_DURABLE_SCOPE'] in Path('/proc/self/cgroup').read_text()
tracked=set(subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines())
paths=set(subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=root,text=True).splitlines())
paths={p for p in paths if p in tracked or not p.startswith('results/') or ('/overlay/' not in p and '/source-overlay/' not in p and (any('primary' in a for a in Path(p).parts) or p.endswith(('cases.json','reference.json'))))}
inputs={p:sha(root/p) for p in sorted(paths) if (root/p).is_file()}
binaryen=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m11-binaryen/binaryen-version_133/bin')
tools={str(binaryen/n):sha(binaryen/n) for n in ['wasm-opt','wasm-merge']}
state={'head':head,'phase':phase,'recorder_pid':os.getpid(),'inputs':inputs,'binaryen':tools,'commands':[],'complete':False,'runner_sha256':sha(Path(__file__)),'temporary_directory':str(temp_root),'mode':mode}
def save():
 (out/'commands.json').write_text(json.dumps(state,indent=2)+'\n')
 (Path(__file__).parent/('eval-workspace-'+phase+'-state.json')).write_text(json.dumps({k:v for k,v in state.items() if k!='inputs'},indent=2)+'\n')
def unchanged():
 return head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() and all((root/p).is_file() and sha(root/p)==h for p,h in inputs.items()) and sha(Path(__file__))==state['runner_sha256']
env=os.environ|{'CARGO_TARGET_DIR':'/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-some-fn-target','CARGO_BUILD_JOBS':'1','RUSTUP_TOOLCHAIN':'stable','BINARYEN_CORES':'1','SUSS_WASM_OPT':str(binaryen/'wasm-opt')}
env['PATH']=str(binaryen)+os.pathsep+env['PATH']
env['TMPDIR']=str(temp_root)
env['SUSS_CLOJURE_TEST_SUITE_CAPTURE']=str(out/'capture')
env['SUSS_EVAL_BODY_CAPTURE']=str(out/'capture')
env['SUSS_NUMERIC_BODY_CAPTURE']=str(out/'capture')
if phase in ['factory-profile-working','shared-identifiers-profile-working','interned-keywords-profile-working','murmur-profile-working','guarded-murmur-profile-working','catalog-repeat-profile-before','catalog-canonical-keys-working']: env['SUSS_NAMESPACE_FUEL_TRACE']='1'
commands=[('exact-two-thread-workspace', ['cargo', 'test', '--workspace', '--locked', '--', '--test-threads=2'])] if mode=='full' else [('complete-original-build-cache-guards',['cargo','test','--workspace','--locked','--test','build_cache','--','--test-threads=2'])]


try:
 save()
 for name,cmd in commands:
  assert unchanged(),'frozen inputs changed before command'
  row={'name':name,'command':cmd,'complete':False};state['commands'].append(row);save()
  start=time.monotonic()
  with (out/(name+'.log')).open('w') as log:
   overrides={'SUSS_MACRO_FUEL_TRACE':'1','SUSS_NAMESPACE_FUEL_TRACE':'1'} if name=='compiler-catalog-cost-trace' else {}
   row['env_overrides']={'TMPDIR':str(temp_root)}|overrides;save()
   proc=subprocess.Popen(cmd,cwd=root,env=env|overrides,stdout=log,stderr=subprocess.STDOUT)
   row['pid']=proc.pid;save();code=proc.wait()
  row.update(complete=True,exit_code=code,seconds=time.monotonic()-start);save();print(row,flush=True)
  if code:break
 state.update(complete=True,inputs_unchanged=unchanged(),binaryen_unchanged=all(sha(Path(p))==h for p,h in tools.items()))
 state['exit_code']=next((r['exit_code'] for r in state['commands'] if r.get('exit_code')),0)
 save()
except Exception as e:
 state.update(complete=True,controller_error=repr(e));save();raise
sys.exit(state['exit_code'])
