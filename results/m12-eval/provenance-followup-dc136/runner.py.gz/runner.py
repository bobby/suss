from pathlib import Path
import datetime, gzip, hashlib, json, platform, subprocess, sys, time

root = Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
out = root / 'results/m12-eval/provenance-followup-dc136'
out.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
def capture():
    paths = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard'], cwd=root, text=True).splitlines()
    return {p: sha((root/p).read_bytes()) for p in sorted(set(paths)) if not p.startswith('results/') and (root/p).is_file()}
inputs = capture()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
commands = [
 ['python3', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_*.py'],
 ['python3', 'scripts/cljs_inventory.py', '--check'],
 ['python3', 'scripts/cljs_reviews.py'],
 ['python3', 'scripts/core_import.py', '--check'],
 ['python3', 'scripts/reader_core_catalog.py', '--check'],
 ['python3', 'scripts/apply_bootstrap.py', '--check'],
 ['python3', 'scripts/sequence_provenance.py'],
 ['python3', 'scripts/check_transducer_provenance.py'],
 ['python3', 'scripts/check_when_let_provenance.py'],
 ['python3', 'scripts/bitwise_provenance.py'],
 ['python3', 'scripts/wasi_lock.py'],
 ['python3', 'scripts/numeric_runtime.py', '--check'],
 ['python3', 'scripts/jvm_array_oracle.py', '--check'],
 ['python3', 'scripts/clojure_test_suite.py'],
 ['python3', 'scripts/clojure_test_suite.py', 'overlap'],
 ['python3', 'scripts/check_record_macro_provenance.py'],
]
runner = Path(__file__).read_bytes()
(out/'runner.py.gz').write_bytes(gzip.compress(runner, mtime=0))
(out/'inputs.json.gz').write_bytes(gzip.compress(json.dumps(inputs, indent=2).encode(), mtime=0))
rows = []
for i, command in enumerate(commands):
    start = time.monotonic()
    proc = subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = f'{i:02d}.log.gz'
    (out/log).write_bytes(gzip.compress(proc.stdout, mtime=0))
    row = {'argv': command, 'exit_code': proc.returncode, 'seconds': time.monotonic()-start, 'log': log, 'output_sha256': sha(proc.stdout)}
    rows.append(row)
    print(json.dumps(row), flush=True)
    if proc.returncode:
        print(proc.stdout.decode(errors='replace')[-6000:], flush=True)
after = capture()
receipt = {'head':head, 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'python':platform.python_version(), 'runner_sha256':sha(runner), 'inputs_unchanged':inputs==after, 'head_unchanged':head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(), 'commands':rows, 'scope':'Exact foundation inventory/scanner step plus named-property provenance check only; no workspace, bootstrap, integration or promotion claim.'}
receipt['archives'] = {p.name:sha(p.read_bytes()) for p in sorted(out.iterdir()) if p.is_file()}
(out/'commands.json').write_text(json.dumps(receipt, indent=2)+'\n')
assert receipt['inputs_unchanged'] and receipt['head_unchanged']
sys.exit(int(any(r['exit_code'] for r in rows)))
