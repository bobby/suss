from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path("/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source");out=Path("/home/bobby/.codex-workspaces/cleanup/suss-20261123/eval-next-step/aot-option-current-source-diagnostic");binary=root.parent/'m12-some-fn-target/debug/deps/portable_aot_options-d655ed5e367de533'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=['crates/suss-compile/tests/portable_aot_options.rs','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','docs/compatibility/patches/expression-symbol.json','crates/suss-compile/src/portable/hir/vars.rs','crates/suss-compile/src/portable/hir.rs']
assert (root/'runtime/core-import/suss/core.sus').read_bytes() in binary.read_bytes()
command=[str(binary),'option_schema_survives_core_function_and_constructor_redefinition','--exact','--nocapture','--test-threads=1']
r={'command':command,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'inputs':{p:sha(root/p) for p in paths},'binary_sha256':sha(binary),'scope':os.environ['SUSS_DURABLE_SCOPE'],'recorder_pid':os.getpid(),'complete':False,'qualification':'Actual unchanged original AOT option test, directly invoked from the freshly workspace-compiled executable embedding the current exact generated core. Diagnostic counterexample/pass for this single case only; no complete target/workspace pass claim.'}
assert r['scope'] in Path('/proc/self/cgroup').read_text()
def save():(out/'command.json').write_text(json.dumps(r,indent=2)+'\n')
save();start=time.time()
with (out/'run.log').open('w') as log:p=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
r.update(complete=True,exit_code=p.returncode,seconds=time.time()-start,head_unchanged=r['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),inputs_unchanged=all(sha(root/p)==digest for p,digest in r['inputs'].items()),binary_unchanged=sha(binary)==r['binary_sha256']);save();print({k:v for k,v in r.items() if k!='inputs'},flush=True)
