from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
phase=sys.argv[1]
out=root/'results/m12-eval'/('namespace-native-values-'+phase)
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
tracked=set(subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines())
paths=set(subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=root,text=True).splitlines())
paths={p for p in paths if p in tracked or not p.startswith('results/') or ('/overlay/' not in p and (any('primary' in a for a in Path(p).parts) or p.endswith('/cases.json')))}
inputs={p:sha(root/p) for p in sorted(paths) if (root/p).is_file()}
binaryen=root.parent/'m11-binaryen/binaryen-version_133/bin'
tools={str(binaryen/n):sha(binaryen/n) for n in ['wasm-opt','wasm-merge']}
state={'head':head,'phase':phase,'recorder_pid':os.getpid(),'inputs':inputs,'binaryen':tools,'commands':[],'complete':False,'runner_sha256':sha(Path(__file__))}
def save():
 (out/'commands.json').write_text(json.dumps(state,indent=2)+'\n')
 (Path(__file__).parent/('namespace-native-values-'+phase+'-state.json')).write_text(json.dumps({k:v for k,v in state.items() if k!='inputs'},indent=2)+'\n')
def unchanged():
 return head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() and all((root/p).is_file() and sha(root/p)==h for p,h in inputs.items()) and sha(Path(__file__))==state['runner_sha256']
env=os.environ|{'CARGO_TARGET_DIR':str(root.parent/'m12-some-fn-target'),'CARGO_BUILD_JOBS':'1','RUSTUP_TOOLCHAIN':'stable','BINARYEN_CORES':'1','SUSS_WASM_OPT':str(binaryen/'wasm-opt')}
env['PATH']=str(binaryen)+os.pathsep+env['PATH']
if phase in ['factory-profile-working','shared-identifiers-profile-working','interned-keywords-profile-working','murmur-profile-working','guarded-murmur-profile-working','catalog-repeat-profile-before','catalog-canonical-keys-working']: env['SUSS_NAMESPACE_FUEL_TRACE']='1'
commands=[('library-typecheck', ['cargo', 'check', '-p', 'suss-compile', '--locked', '--lib', '--tests']), ('complete-public-eval', ['cargo', 'test', '-p', 'suss-cli', '--locked', '--test', 'clojure_eval', '--', '--nocapture', '--test-threads=2']), ('ci-macro-and-stream-targets', ['cargo', 'test', '-p', 'suss-cli', '--locked', '--test', 'compiled_macro_compiler_catalog', '--test', 'native_repl_async_io', '--', '--nocapture', '--test-threads=2']), ('ownership-library', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--lib', 'portable_', '--', '--nocapture', '--test-threads=2']), ('source-frontends', ['cargo', 'test', '-p', 'suss-cli', '--locked', '--test', 'compiled_native_entrypoints', '--test', 'compiled_repl_macros', '--test', 'inline_module_macros', '--test', 'compiled_source_macros', '--test', 'compiled_macro_imports', '--test', 'compiled_macro_reload', '--test', 'compiled_macro_cumulative_fuel', '--', '--nocapture', '--test-threads=2']), ('runtime-abi-and-structural-guards', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'runtime_abi', '--test', 'portable_calling_convention', '--test', 'portable_comparator_foundations', '--test', 'portable_dynamic_bindings', '--', '--nocapture', '--test-threads=2']), ('named-calling-hash-sealing-and-ci-display', ['cargo', 'test', '-p', 'suss-cli', '--locked', '--test', 'portable_named_properties', '--test', 'clojure_calling_convention', '--test', 'portable_string_hash', '--test', 'builtin_internals_sealed', '--test', 'repl_value_display', '--test', 'runtime_namespaces', '--', '--nocapture', '--test-threads=2']), ('python-and-provenance', ['python3', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_*.py']), ('core-import', ['python3', 'scripts/core_import.py', '--check']), ('eval-source-provenance', ['python3', 'results/m12-eval/verify-live-vars.py']), ('original-eval-primary', ['python3', 'results/m12-eval/verify-primary.py']), ('sequence-provenance', ['python3', 'scripts/sequence_provenance.py']), ('java-node-free-bootstrap', ['sh', 'scripts/verify-bootstrap.sh'])]


try:
 save()
 for name,cmd in commands:
  assert unchanged(),'frozen inputs changed before command'
  row={'name':name,'command':cmd,'complete':False};state['commands'].append(row);save()
  start=time.monotonic()
  with (out/(name+'.log')).open('w') as log:
   overrides={'SUSS_MACRO_FUEL_TRACE':'1','SUSS_NAMESPACE_FUEL_TRACE':'1'} if name=='compiler-catalog-cost-trace' else {}
   row['env_overrides']=overrides;save()
   proc=subprocess.Popen(cmd,cwd=root,env=env|overrides,stdout=log,stderr=subprocess.STDOUT)
   row['pid']=proc.pid;save();code=proc.wait()
  row.update(complete=True,exit_code=code,seconds=time.monotonic()-start);save();print(row,flush=True)
  if code:break
 state.update(complete=True,inputs_unchanged=unchanged(),binaryen_unchanged=all(sha(Path(p))==h for p,h in tools.items()))
 state['exit_code']=next((r['exit_code'] for r in state['commands'] if r.get('exit_code')),0)
 save()
except Exception as e:
 state.update(complete=True,controller_error=repr(e));save();raise
sys.exit(state['exit_code'])
