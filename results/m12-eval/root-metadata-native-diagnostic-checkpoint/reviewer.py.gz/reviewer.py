from pathlib import Path
import copy,gzip,hashlib,importlib.util,json,subprocess,sys
E=Path(__file__).resolve().parent
J=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
out=J/'results/m12-eval/native-after-root-metadata-checkpoint'
sha=lambda b:hashlib.sha256(b).hexdigest()
c=json.loads((out/'controller.json').read_text())
assert c['complete'] and c['head_unchanged'] and c['inputs_unchanged'] and c['binaryen_unchanged']
assert c['native_commands']=={'suite-build':0,'suite-run':101,'suite-lock':0}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=J,text=True).strip()==c['head']
assert all((J/n).is_file() and sha((J/n).read_bytes())==h for n,h in c['inputs'].items())
runner=E/'run-root-metadata-native.py';assert sha(runner.read_bytes())==c['runner_sha256']
sys.path.insert(0,str(J/'scripts'));import clojure_test_suite as suite
capture=out/'complete-capture/suite-capture/suite-observations.json'
raw=capture.read_bytes();actual=json.loads(raw)
reference=json.loads((J/'tests/oracle/clojure-test-suite-observations.json').read_text())
ledger_path=J/'tests/oracle/clojure-test-suite-known-failures.json'
before=ledger_path.read_bytes();assert sha(before)=='dea5db93e9548008d91e5c79ee11978920575975ec601f1852139ff063329d7f'
expected=json.loads(before);changes=[]
normalized=copy.deepcopy(actual)
for ns in ['clojure.core-test.add-watch','clojure.core-test.remove-watch']:
 old=expected['namespaces'][ns]['diagnostic'];assert 'Unresolved Runtime name alter-var-root at bytes' in old
 new=old.replace('Unresolved Runtime name alter-var-root at bytes','Unresolved Runtime name ref at bytes')
 row=next(r for r in actual['namespaces'] if r['namespace']==ns)
 assert row['diagnostic']==new and row['status']=='failure',row
 normalized_row=next(r for r in normalized['namespaces'] if r['namespace']==ns)
 normalized_row['diagnostic']=old
 expected['namespaces'][ns]['diagnostic']=new
 changes.append({'namespace':ns,'before':old,'after':new})
counts,measured=suite.compare(reference,actual);assert measured==expected,'No other failure changes allowed'
original=J/'results/m12-eval/eval-broader-after-symbol-and-var-contract/complete-capture'
old=json.loads(gzip.decompress((original/'suite-capture/suite-observations.json.gz').read_bytes()))
assert [(r['test'],r['ordinal']) for r in actual['assertions']]==[(r['test'],r['ordinal']) for r in old['assertions']]
refs={r['id']:r for r in reference['assertions']}
payload_changes=[]
for a,b in zip(actual['assertions'],old['assertions']):
 key=a['test']+'#'+str(a['ordinal'])
 assert suite.decide(refs[key],a)==suite.decide(refs[key],b),key
 if a!=b:
  assert key in suite.RANDOMIZED,key
  payload_changes.append(key)
spec=importlib.util.spec_from_file_location('strict',J/'results/m12-eval/review-complete-capture.py');reviewer=importlib.util.module_from_spec(spec);spec.loader.exec_module(reviewer)
prior=gzip.decompress((J/'results/m12-reader-followup/full-suite-after-random-and-assert/suite-capture/suite-observations.json.gz').read_bytes())
report=reviewer.review((J/'tests/oracle/clojure-test-suite-observations.json').read_bytes(),gzip.decompress((original/'parent-random-baseline.json.gz').read_bytes()),prior,json.dumps(normalized).encode())
assert report.pop('proposed_baseline')==json.loads(before)
assert counts==report['counts']
archive=J/'results/m12-eval/root-metadata-native-diagnostic-checkpoint';archive.mkdir(exist_ok=False)
files={}
for p in out.rglob('*'):
 if p.is_file():
  n=str(p.relative_to(out));b=p.read_bytes();target=archive/(n+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(b,mtime=0));files[n]=sha(b)
(archive/'runner.py.gz').write_bytes(gzip.compress(runner.read_bytes(),mtime=0))
(archive/'known-failures-before.json.gz').write_bytes(gzip.compress(before,mtime=0))
report.update(head=c['head'],capture_sha256=sha(raw),actual_native_exit_code=101,observed_row_decisions_preserved=5564,randomized_payload_changes=payload_changes,diagnostic_changes=changes,files=files,qualification='Actual native101 retained. All5564 ordered assertion decisions, counts, skips, guest judgments and unrelated failures are unchanged. Only two still-blocked namespace diagnostics advance from alter-var-root to ref. Original strict reviewer passes after normalizing only those diagnostics in memory; raw capture remains unchanged. Native rerun/workspace/review/CI remain separate gates.')
(archive/'review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
(archive/'reviewer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
# Archive and authenticate the complete negative run before changing any input.
ledger_path.write_text(json.dumps(expected,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['files','diagnostic_changes']},indent=2))
print('Archived actual native101; changed exactly two measured diagnostic fields. New ledger SHA256:',sha(ledger_path.read_bytes()))
