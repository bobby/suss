from pathlib import Path
import hashlib,json,os,subprocess,time,sys
j=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
out=j/'results/m12-eval/native-after-root-metadata-checkpoint';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=j,text=True).strip()
paths=set(subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=j,text=True).splitlines());tracked=set(subprocess.check_output(['git','ls-files'],cwd=j,text=True).splitlines())
paths={p for p in paths if p in tracked or not p.startswith('results/') or ('/overlay/' not in p and (any('primary' in part for part in Path(p).parts) or p.endswith('/cases.json')))}
inputs={p:sha(j/p) for p in sorted(paths) if (j/p).is_file()}
bin=j.parent/'m11-binaryen/binaryen-version_133/bin';tools={str(bin/n):sha(bin/n) for n in ['wasm-opt','wasm-merge']}
env=os.environ|{'CARGO_TARGET_DIR':str(j.parent/'m12-some-fn-target'),'SUSS_SUITE_TARGET':str(j.parent/'m12-some-fn-target'),'CARGO_BUILD_JOBS':'1','RUSTUP_TOOLCHAIN':'stable','BINARYEN_CORES':'1','SUSS_WASM_OPT':str(bin/'wasm-opt'),'PATH':str(bin)+os.pathsep+os.environ['PATH']}
r={'head':head,'inputs':inputs,'binaryen':tools,'runner_sha256':sha(Path(__file__)),'recorder_pid':os.getpid(),'complete':False,'command':['python3','results/m12-reader-followup/run-suite.py',str(out/'complete-capture')],'qualification':'Fresh complete native capture. Producer exit is not native success; inspect every suite command and retain any comparison failure. Parent J and numeric F have different source-body coverage; measure actual rows rather than asserting5750 from F history.'}
def save():(out/'controller.json').write_text(json.dumps(r,indent=2)+'\n')
save();start=time.monotonic()
with (out/'controller.log').open('w') as log:
 p=subprocess.Popen(r['command'],cwd=j,env=env,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=p.pid;save();code=p.wait()
r.update(producer_exit_code=code,seconds=time.monotonic()-start,complete=True,head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=j,text=True).strip()==head,inputs_unchanged=all((j/n).is_file() and sha(j/n)==h for n,h in inputs.items()),binaryen_unchanged=all(sha(Path(n))==h for n,h in tools.items()))
receipt=out/'complete-capture/suite-commands.json'
if receipt.exists():
 d=json.loads(receipt.read_text());r['native_commands']={row['label']:row['exit_code'] for row in d['commands']};r['suite_receipt_complete']=d['complete']
 r['actual_exit_code']=next((c for c in r['native_commands'].values() if c),code)
else:r['actual_exit_code']=code or 1
save();print({k:v for k,v in r.items() if k not in ['inputs','binaryen']},flush=True)
sys.exit(r['actual_exit_code'])
