from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
phase=sys.argv[1]
out=root/'results/m12-eval'/('nested-native-metadata-'+phase)
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
tracked=set(subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines())
paths=set(subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=root,text=True).splitlines())
paths={p for p in paths if p in tracked or not p.startswith('results/') or any('primary' in a for a in Path(p).parts) or p.endswith('/cases.json')}
inputs={p:sha(root/p) for p in sorted(paths) if (root/p).is_file()}
binaryen=root.parent/'m11-binaryen/binaryen-version_133/bin'
tools={str(binaryen/n):sha(binaryen/n) for n in ['wasm-opt','wasm-merge']}
state={'head':head,'phase':phase,'recorder_pid':os.getpid(),'inputs':inputs,'binaryen':tools,'commands':[],'complete':False,'runner_sha256':sha(Path(__file__))}
def save():
 (out/'commands.json').write_text(json.dumps(state,indent=2)+'\n')
 (Path(__file__).parent/('nested-native-metadata-'+phase+'-state.json')).write_text(json.dumps({k:v for k,v in state.items() if k!='inputs'},indent=2)+'\n')
def unchanged():
 return head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() and all((root/p).is_file() and sha(root/p)==h for p,h in inputs.items()) and sha(Path(__file__))==state['runner_sha256']
env=os.environ|{'CARGO_TARGET_DIR':str(root.parent/'m12-some-fn-target'),'CARGO_BUILD_JOBS':'1','RUSTUP_TOOLCHAIN':'stable','BINARYEN_CORES':'1','SUSS_WASM_OPT':str(binaryen/'wasm-opt')}
env['PATH']=str(binaryen)+os.pathsep+env['PATH']
commands=[('isolated-nested-metadata', ['cargo','test','-p','suss-cli','--locked','--test','clojure_eval','isolated_source_nested_function_metadata_retains_actual_callbacks','--','--nocapture','--test-threads=2'])]
if phase!='before':
 commands.insert(0,('library-typecheck',['cargo','check','-p','suss-compile','--locked','--lib','--tests']))
 commands.append(('private-native-capability',['cargo','test','-p','suss-compile','--locked','--lib','native_function_capability_','--','--nocapture','--test-threads=2']))
 commands.append(('metadata-map-identity',['cargo','test','-p','suss-cli','--locked','--test','clojure_eval','isolated_source_function_metadata_retains_identity_between_macro_requests','--','--nocapture','--test-threads=2']))
if phase in ['root-guarded','cache-evicted']:
 commands.extend([
  ('ownership-library', ['cargo','test','--workspace','--locked','--lib','portable_','--','--nocapture','--test-threads=2']),
  ('strict-self-values-metadata', ['cargo','test','-p','suss-cli','--locked','--test','clojure_eval','eval_preserves_self','--','--nocapture','--test-threads=2']),
  ('typed-callback-interrupt', ['cargo','test','-p','suss-cli','--locked','--test','clojure_eval','isolated_source_callback_preserves_typed_cancellation_and_recovers','--','--nocapture','--test-threads=2']),
  ('source-macro-frontend', ['cargo','test','-p','suss-cli','--locked','--test','compiled_source_macros','--','--nocapture','--test-threads=2'])
 ])
try:
 save()
 for name,cmd in commands:
  assert unchanged(),'frozen inputs changed before command'
  row={'name':name,'command':cmd,'complete':False};state['commands'].append(row);save()
  start=time.monotonic()
  with (out/(name+'.log')).open('w') as log:
   proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
   row['pid']=proc.pid;save();code=proc.wait()
  row.update(complete=True,exit_code=code,seconds=time.monotonic()-start);save();print(row,flush=True)
  if name=='library-typecheck' and code:break
 state.update(complete=True,inputs_unchanged=unchanged(),binaryen_unchanged=all(sha(Path(p))==h for p,h in tools.items()))
 state['exit_code']=next((r['exit_code'] for r in state['commands'] if r.get('exit_code')),0)
 save()
except Exception as e:
 state.update(complete=True,controller_error=repr(e));save();raise
sys.exit(state['exit_code'])
