"""Run existing public-eval controls on the integrated consumer with frozen inputs."""
from pathlib import Path
import datetime, gzip, hashlib, json, os, subprocess, sys, time

E = Path(__file__).resolve().parent
root = Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
phase = sys.argv[1] if len(sys.argv) > 1 else 'reviewed-core-public-controls'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == '41725409c6f4ae29bc4cb56f2fedf6ebc079343b'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=root, text=True).strip()
scope = os.environ['SUSS_DURABLE_SCOPE']
assert scope in Path('/proc/self/cgroup').read_text()
out = root / 'results/m12-eval' / phase
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
tracked = set(subprocess.check_output(['git', 'ls-files'], cwd=root, text=True).splitlines())
paths = set(subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard'], cwd=root, text=True).splitlines())
paths = {p for p in paths if p in tracked or not p.startswith('results/') or
         ('/overlay/' not in p and '/source-overlay/' not in p and
          (any('primary' in a for a in Path(p).parts) or p.endswith(('cases.json', 'reference.json'))))}
inputs = {p: sha(root / p) for p in sorted(paths) if (root / p).is_file()}
binaryen = Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m11-binaryen/binaryen-version_133/bin')
tools = {str(binaryen / n): sha(binaryen / n) for n in ['wasm-opt', 'wasm-merge']}
primary = json.loads((root / 'results/m12-eval/primary/command.json').read_text())
assert all(sha(Path(p)) == h for p, h in primary['jars'].items())
runner = Path(__file__)
runner_sha = sha(runner)
record = {'phase': phase, 'head': head, 'scope': scope, 'recorder_pid': os.getpid(),
          'inputs': inputs, 'binaryen': tools, 'primary_jars': primary['jars'],
          'runner_sha256': runner_sha, 'commands': [], 'complete': False,
          'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'qualification': 'Focused existing native public-eval controls, fresh primary controls, complete original source bodies and bootstrap. Exact consumer workspace, independent consumer review, final-head CI and full numeric acceptance retain separate evidence.'}

def save():
    (out / 'commands.json').write_text(json.dumps(record, indent=2) + '\n')

def conserved():
    return (head == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
            and all((root / p).is_file() and sha(root / p) == h for p, h in inputs.items())
            and sha(runner) == runner_sha
            and all(sha(Path(p)) == h for p, h in tools.items())
            and all(sha(Path(p)) == h for p, h in primary['jars'].items()))

env = os.environ | {'CARGO_TARGET_DIR': '/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-some-fn-target',
                    'CARGO_BUILD_JOBS': '1', 'RUSTUP_TOOLCHAIN': 'stable', 'BINARYEN_CORES': '1',
                    'SUSS_WASM_OPT': str(binaryen / 'wasm-opt'),
                    'SUSS_EVAL_BODY_CAPTURE': str(out / 'capture'),
                    'SUSS_CLOJURE_TEST_SUITE_CAPTURE': str(out / 'capture')}
env['PATH'] = str(binaryen) + os.pathsep + env['PATH']
commands = [
    ('source-provenance', ['python3', 'results/m12-eval/verify-live-vars.py']),
    ('retained-primary-fixtures', ['python3', 'results/m12-eval/verify-primary.py']),
    ('fresh-primary-controls', ['java', '-Xmx512m', '-cp', ':'.join(primary['jars']), 'clojure.main', str(root / 'results/m12-eval/primary/oracle.clj')]),
    ('complete-public-eval-controls', ['cargo', 'test', '--workspace', '--locked', '--test', 'clojure_eval', '--', '--nocapture', '--test-threads=2']),
    ('inherited-core-repair-regressions', ['cargo', 'test', '--workspace', '--locked', '--test', 'native_host_boundary', 'review_regression_', '--', '--nocapture', '--test-threads=2']),
    ('complete-original-upstream-bodies-and-guards', ['cargo', 'test', '--workspace', '--locked', '--test', 'clojure_test_suite', '--', '--nocapture', '--test-threads=2']),
    ('java-node-free-bootstrap', ['sh', 'scripts/verify-bootstrap.sh']),
    ('core-import-source-check', ['python3', 'scripts/core_import.py', '--check']),
    ('final-source-provenance', ['python3', 'results/m12-eval/verify-live-vars.py'])]
if '--reuse-primary' in sys.argv:
    prior_path = root / 'results/m12-eval/reviewed-core-public-controls/commands.json'
    prior = json.loads(prior_path.read_text())
    assert prior['complete'] and prior['head'] == head and prior['inputs_head_runner_tools_jars_conserved']
    assert prior['runner_archived']
    assert hashlib.sha256(gzip.decompress(prior_path.with_name('runner.py.gz').read_bytes())).hexdigest() == prior['runner_sha256']
    assert all((root / p).is_file() and sha(root / p) == h for p, h in prior['inputs'].items())
    assert prior['binaryen'] == tools and prior['primary_jars'] == primary['jars']
    assert [r['name'] for r in prior['commands'][:3]] == [r[0] for r in commands[:3]]
    assert all(r['complete'] and r['exit_code'] == 0 for r in prior['commands'][:3])
    assert prior['commands'][2]['semantic_check_exit_code'] == 0
    assert prior['commands'][2]['primary_controls'] == 24
    assert prior['commands'][2]['ordered_primary_observations_equal']
    record['reused_source_primary_validation'] = {'phase': prior['phase'], 'head': head,
        'receipt_sha256': sha(prior_path), 'commands': prior['commands'][:3],
        'all_prior_source_inputs_still_conserved': True,
        'qualification': 'Prior source/primary commands actually passed on identical source. Only the cached generator build artifact was refreshed; no native test executed in that failed-build attempt.'}
    commands = commands[3:]
code = 0
try:
    save()
    for name, command in commands:
        assert conserved(), 'frozen consumer inputs changed before command'
        row = {'name': name, 'command': command, 'complete': False}
        record['commands'].append(row)
        save()
        start = time.monotonic()
        with (out / (name + '.log')).open('w') as stdout, (out / (name + '.stderr')).open('w') as stderr:
            proc = subprocess.Popen(command, cwd=root, env=env, stdout=stdout,
                                    stderr=stderr if name == 'fresh-primary-controls' else subprocess.STDOUT)
            row['pid'] = proc.pid
            save()
            actual = proc.wait()
        row.update(complete=True, exit_code=actual, seconds=time.monotonic() - start,
                   stdout_sha256=sha(out / (name + '.log')), stderr_sha256=sha(out / (name + '.stderr')))
        code = actual
        if name == 'fresh-primary-controls' and actual == 0:
            try:
                observed = [json.loads(line) for line in (out / (name + '.log')).read_text().splitlines()]
                expected = json.loads((root / 'results/m12-eval/primary/cases.json').read_text())
                assert len(observed) == len(expected) == 24
                assert observed == [r['expected'] for r in expected]
                assert row['stdout_sha256'] == primary['stdout_sha256']
                row.update(primary_controls=24, ordered_primary_observations_equal=True, semantic_check_exit_code=0)
            except Exception as error:
                row.update(semantic_check_exit_code=1, semantic_check_error=repr(error))
                code = 1
        save()
        print(json.dumps(row), flush=True)
        if code:
            break
except Exception as error:
    record['controller_error'] = repr(error)
    code = 1
finally:
    unchanged = conserved()
    record.update(complete=True, exit_code=code or (0 if unchanged else 1),
                  inputs_head_runner_tools_jars_conserved=unchanged,
                  finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (out / 'runner.py.gz').write_bytes(gzip.compress(runner.read_bytes(), mtime=0))
    (out / 'deleted.json').write_text(json.dumps(subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=D'], cwd=root, text=True).splitlines()) + '\n')
    record['runner_archived'] = True
    save()
sys.exit(record['exit_code'])
