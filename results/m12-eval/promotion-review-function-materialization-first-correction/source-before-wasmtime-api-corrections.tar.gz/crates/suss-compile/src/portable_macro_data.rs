//! Bounded native transport between reader forms and real compiled macro values.
//! Macro bodies execute in Wasm; this module constructs and reads nominal data.
use crate::portable::Diagnostic;
use crate::portable_session::{RuntimeNumber, Session, SessionHost, SessionError, SessionValue, runtime_number};
use std::{collections::BTreeMap, ops::Range, sync::Arc};
use suss_reader::forms::{Form, Kind};
use wasmtime::{AnyRef, AsContextMut, Rooted, StoreContextMut, Val};

mod borrowed_reader;
mod exception;
pub(crate) use exception::TransferredException;

pub(crate) fn normalized_reader_metadata(
    session: &mut SessionHost<'_>,
    form: &Form,
) -> Result<Vec<Form>, SessionError> {
    crate::portable::hir::reader_metadata_pairs_metered(form, &mut |work| {
        session.charge_host_work(work).map_err(|error| Diagnostic {
            span: form.span.clone(), message: error.to_string(),
        })
    }).map_err(SessionError::Compile)
}

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum Class {
    Uuid,
    Symbol,
    Keyword,
    List,
    EmptyList,
    Cons,
    IndexedSeq,
    PersistentVector,
    VectorNode,
    PersistentArrayMap,
    PersistentHashMap,
    PersistentHashSet,
    BitmapIndexedNode,
    ArrayNode,
    HashCollisionNode,
    NodeSeq,
    ArrayNodeSeq,
    MapEntry,
    KeySeq,
    PersistentArrayMapSeq,
    ChunkedSeq,
    LazySeq,
    ChunkedCons,
    ArrayChunk,
    PersistentQueue,
}
// One enumeration for bridge construction and initial bootstrap authority.
const SOURCE_CLASSES: [(&str, Class); 25] = [
    ("UUID", Class::Uuid),
    ("Symbol", Class::Symbol),
    ("Keyword", Class::Keyword),
    ("List", Class::List),
    ("EmptyList", Class::EmptyList),
    ("Cons", Class::Cons),
    ("IndexedSeq", Class::IndexedSeq),
    ("PersistentVector", Class::PersistentVector),
    ("VectorNode", Class::VectorNode),
    ("PersistentArrayMap", Class::PersistentArrayMap),
    ("PersistentHashMap", Class::PersistentHashMap),
    ("PersistentHashSet", Class::PersistentHashSet),
    ("BitmapIndexedNode", Class::BitmapIndexedNode),
    ("ArrayNode", Class::ArrayNode),
    ("HashCollisionNode", Class::HashCollisionNode),
    ("NodeSeq", Class::NodeSeq),
    ("ArrayNodeSeq", Class::ArrayNodeSeq),
    ("MapEntry", Class::MapEntry),
    ("KeySeq", Class::KeySeq),
    ("PersistentArrayMapSeq", Class::PersistentArrayMapSeq),
    ("ChunkedSeq", Class::ChunkedSeq),
    ("LazySeq", Class::LazySeq),
    ("ChunkedCons", Class::ChunkedCons),
    ("ArrayChunk", Class::ArrayChunk),
    ("PersistentQueue", Class::PersistentQueue),
];

#[derive(Clone, Copy)]
pub(crate) enum MetadataShape {
    Symbol,
    List { empty: bool },
    Vector,
    Map { large: bool },
    Set,
}

#[derive(Clone, Copy)]
pub(crate) enum DisplayCollection {
    List,
    Vector,
    Map,
    Set,
    Queue,
}
#[derive(Clone, Copy)]
pub(crate) enum DisplayLeaf {
    Future(crate::portable_session::FutureStatus),
    StreamReader,
    StreamWriter,
    StreamEof,
}
impl DisplayLeaf {
    pub(crate) fn text(self) -> &'static str {
        use crate::portable_session::FutureStatus;
        match self {
            Self::Future(FutureStatus::Pending) => "#<future pending>",
            Self::Future(FutureStatus::Ready) => "#<future ready>",
            Self::Future(FutureStatus::Failed) => "#<future failed>",
            Self::Future(FutureStatus::Cancelled) => "#<future cancelled>",
            Self::StreamReader => "#<stream reader>",
            Self::StreamWriter => "#<stream writer>",
            Self::StreamEof => "#<stream eof>",
        }
    }
}
#[derive(Clone, Copy)]
struct DisplayCalls {
    future_is: wasmtime::Func,
    future_status: wasmtime::Func,
    stream_kind: wasmtime::Func,
}
impl DisplayCalls {
    fn read(
        self,
        store: &mut StoreContextMut<'_, ()>,
        value: Val,
    ) -> wasmtime::Result<Option<DisplayLeaf>> {
        let mut result = [Val::I32(0)];
        self.future_is.call(&mut *store, &[value], &mut result)?;
        if result[0].unwrap_i32() != 0 {
            self.future_status
                .call(&mut *store, &[value], &mut result)?;
            use crate::portable_session::FutureStatus;
            return Ok(Some(DisplayLeaf::Future(match result[0].unwrap_i32() {
                0 => FutureStatus::Pending,
                1 => FutureStatus::Ready,
                2 => FutureStatus::Failed,
                3 => FutureStatus::Cancelled,
                _ => return Err(error("Invalid nominal future status in display")),
            })));
        }
        self.stream_kind.call(&mut *store, &[value], &mut result)?;
        Ok(match result[0].unwrap_i32() {
            0 => None,
            1 => Some(DisplayLeaf::StreamReader),
            2 => Some(DisplayLeaf::StreamWriter),
            3 => Some(DisplayLeaf::StreamEof),
            _ => return Err(error("Invalid nominal stream kind in display")),
        })
    }
}
fn display_calls(session: &mut SessionHost<'_>) -> Result<DisplayCalls, SessionError> {
    let (future_is, future_status, stream_kind) = session.display_runtime_exports()?;
    Ok(DisplayCalls {
        future_is,
        future_status,
        stream_kind,
    })
}
pub(crate) fn display_leaf(
    session: &mut SessionHost<'_>,
    value: &SessionValue,
) -> Result<Option<DisplayLeaf>, SessionError> {
    let calls = display_calls(session)?;
    session.inspect(value, |mut store, value| calls.read(&mut store, value))
}
trait DatumTarget: Sized {
    fn plain(form: Form) -> Self;
    fn collection(
        kind: DisplayCollection,
        items: Vec<Self>,
        span: Range<usize>,
        metadata: Vec<Form>,
    ) -> Self;
    fn opaque(leaf: DisplayLeaf) -> wasmtime::Result<Self>;
}
impl DatumTarget for Form {
    fn plain(form: Form) -> Self {
        form
    }
    fn collection(
        kind: DisplayCollection,
        items: Vec<Self>,
        span: Range<usize>,
        metadata: Vec<Form>,
    ) -> Self {
        Self {
            span: span.clone(),
            metadata,
            kind: match kind {
                DisplayCollection::List => Kind::List(items),
                DisplayCollection::Vector => Kind::Vector(items),
                DisplayCollection::Map => Kind::Map(items),
                DisplayCollection::Set => Kind::Set(items),
                // A queue is the `#queue [...]` literal it reads from.
                DisplayCollection::Queue => Kind::Tagged {
                    tag: suss_reader::Symbol::new("queue"),
                    form: Box::new(Self {
                        span,
                        metadata: vec![],
                        kind: Kind::Vector(items),
                    }),
                },
            },
        }
    }
    fn opaque(_: DisplayLeaf) -> wasmtime::Result<Self> {
        Err(error("Opaque runtime values are not macro syntax"))
    }
}
enum DecodedKind<T> {
    Plain(Kind),
    List(Vec<T>),
    Vector(Vec<T>),
    Map(Vec<T>),
    Set(Vec<T>),
    Queue(Vec<T>),
}

/// Captured canonical class roots remain valid through redefinition and GC.
/// A reset or another Store invalidates this bridge; construct a new one there.
// Immutable native containers; their Wasm referents still require live checks.
struct BridgeCore {
    roots: Vec<SessionValue>,
    classes: BTreeMap<i64, (Class, SessionValue)>,
    constructors: BTreeMap<Class, usize>,
    factories: BTreeMap<&'static str, SessionValue>,
}
pub struct FormBridge {
    core: Arc<BridgeCore>,
}

impl FormBridge {
    fn construct(
        &self,
        session: &mut SessionHost<'_>,
        class: Class,
        arguments: &[&SessionValue],
    ) -> Result<SessionValue, SessionError> {
        let keyword = class == Class::Keyword;
        let class = &self.core.roots[self.core.constructors[&class]];
        let value = session.data_construct(class, arguments)?;
        // Keywords are interned, as guest construction interns them (#361).
        if keyword { session.data_keyword_intern(&value) } else { Ok(value) }
    }
    fn array(
        &self,
        session: &mut SessionHost<'_>,
        values: &[&SessionValue],
    ) -> Result<SessionValue, SessionError> {
        session.data_array(values)
    }
    fn object_array(
        &self,
        session: &mut SessionHost<'_>,
        values: &[&SessionValue],
    ) -> Result<SessionValue, SessionError> {
        session.data_object_array(values)
    }
    fn seed(
        &self,
        _session: &mut SessionHost<'_>,
        name: &'static str,
    ) -> Result<SessionValue, SessionError> {
        Ok(self.core.factories[name].clone())
    }
    pub(crate) fn with_form_metadata(
        &self,
        session: &mut SessionHost<'_>,
        shape: MetadataShape,
        value: &SessionValue,
        metadata: &SessionValue,
        set_items: &[SessionValue],
    ) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        let class = match shape {
            MetadataShape::Set => return self.set_with_metadata(session, set_items, metadata),
            MetadataShape::Symbol => Class::Symbol,
            MetadataShape::List { empty: true } => Class::EmptyList,
            MetadataShape::List { empty: false } => Class::List,
            MetadataShape::Vector => Class::PersistentVector,
            MetadataShape::Map { large: false } => Class::PersistentArrayMap,
            MetadataShape::Map { large: true } => Class::PersistentHashMap,
        };
        let mut fields = session.data_fields(value)?;
        fields[if class == Class::Symbol { 4 } else { 0 }] = metadata.clone();
        self.construct(session,
            class,
            &fields.iter().collect::<Vec<_>>(),
        )
    }
    pub fn new(session: &mut SessionHost<'_>) -> Result<Self, SessionError> {
        let mut roots = Vec::new();
        let mut classes = BTreeMap::new();
        let mut constructors = BTreeMap::new();
        for (name, class) in SOURCE_CLASSES {
            let value = session.eval(&format!("suss.core/{name}"))?;
            let id = session.inspect(&value, |mut store, value| {
                // A class constructor is a universal closure (ADR-0004) whose
                // environment is its descriptor.
                let closure = fields(&mut store, &value, 7)?;
                let descriptor = fields(
                    &mut store,
                    &closure[crate::runtime_abi::UNIVERSAL_ENVIRONMENT as usize],
                    6,
                )?;
                match descriptor[0] {
                    Val::I64(id) => Ok(id),
                    _ => Err(error("Invalid class descriptor identity")),
                }
            })?;
            let descriptor = session.data_descriptor(&value, true)?;
            if classes.insert(id, (class, descriptor)).is_some() {
                return Err(SessionError::Host(error(
                    "Duplicate macro data class identity",
                )));
            }
            constructors.insert(class, roots.len());
            roots.push(value);
        }
        let mut factories = BTreeMap::new();
        for (name, source) in [
            ("hash", "suss.core/hash"),
            ("key-test", "suss.core/key-test"),
            ("exception-message", "suss.core/ex-message"),
            ("exception-data", "suss.core/ex-data"),
            ("exception-cause", "suss.core/ex-cause"),
            // Empty literals lower to core's own EMPTY values; class
            // properties of built-in types are private to suss.core.
            ("empty-map", "{}"),
            ("empty-set", "#{}"),
            ("empty-list", "()"),
            ("empty-queue", "#queue []"),
            ("into", "suss.core/into"),
            ("with-meta", "suss.core/with-meta"),
            ("lazy-sval", "(fn* [value] (.sval value))"),
        ] {
            factories.insert(name, session.eval(source)?);
        }
        session.charge_host_work((std::mem::size_of::<BridgeCore>()
            + 2 * std::mem::size_of::<usize>()) as u64)?;
        Ok(Self {
            core: Arc::new(BridgeCore { roots, classes, constructors, factories }),
        })
    }
    fn check(&self, session: &mut SessionHost<'_>) -> Result<(), SessionError> {
        for root in &self.core.roots {
            session.inspect(root, |_, _| Ok(()))?;
        }
        Ok(())
    }
    /// Native canonical data construction preserves sharing in analysis graphs.
    /// Inputs and factories are rooted in this Store; no source is interpreted.
    pub fn scalar(
        &self,
        session: &mut SessionHost<'_>,
        literal: &crate::portable::hir::Literal,
    ) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        session.data_scalar(literal)
    }
    pub fn map_values(
        &self,
        session: &mut SessionHost<'_>,
        entries: &[(SessionValue, SessionValue)],
    ) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        session.with_operation_budget(|session| self.map_values_inner(session, entries))
    }
    fn map_values_inner(
        &self,
        session: &mut SessionHost<'_>,
        entries: &[(SessionValue, SessionValue)],
    ) -> Result<SessionValue, SessionError> {
        if entries.is_empty() {
            return self.seed(session,"empty-map");
        }
        // Bulk construction is original host code. Retained factories resolve
        // public class cells dynamically, so capturing their closures alone is
        // insufficient to keep compiler data canonical after core redefinition.
        let nil = self.scalar(session, &crate::portable::hir::Literal::Nil)?;
        let mut pairs: Vec<(u32, SessionValue, SessionValue)> = Vec::new();
        let mut hashes: BTreeMap<u32, Vec<usize>> = BTreeMap::new();
        let mut nil_value = None;
        let mut nil_index = 0;
        for (key, value) in entries {
            session.charge_host_work(1)?;
            session.inspect(value, |_, _| Ok(()))?;
            let is_nil = session.inspect(key, |mut store, key| Ok(absent(&mut store, &key)?))?;
            if is_nil {
                if nil_value.is_none() {
                    nil_index = pairs.len();
                }
                nil_value = Some(value.clone());
                continue;
            }
            // Array maps compare keys directly and do not call their hash
            // protocols. Preserve that observable behavior at the threshold.
            let hash = if entries.len() <= 8 {
                0
            } else {
                let hash = session.invoke(&self.core.factories["hash"], &[key])?;
                session.inspect(&hash, |mut store, hash| {
                    let Some(value) = number(&mut store, &hash)? else {
                        return Err(error("Compiler map hash requires a numeric scalar"));
                    };
                    // ECMAScript ToUint32: truncation followed by modulo 2^32,
                    // with nonfinite numbers and signed zero mapped to zero.
                    Ok(if value.is_finite() {
                        value.trunc().rem_euclid(4_294_967_296.0) as u32
                    } else {
                        0
                    })
                })?
            };
            let mut existing = None;
            for index in hashes.entry(hash).or_default().iter().copied() {
                session.charge_host_work(1)?;
                let equal = if let Some(identifier) = self.identifier_key(session, key)? {
                    self.identifier_key(session, &pairs[index].1)?
                        .is_some_and(|other| other == identifier)
                } else {
                    let equal =
                        session.invoke(&self.core.factories["key-test"], &[key, &pairs[index].1])?;
                    session.inspect(&equal, |mut store, value| {
                        Ok(sentinel(&mut store, &value)? == Some(4))
                    })?
                };
                if equal {
                    existing = Some(index);
                    break;
                }
            }
            if let Some(index) = existing {
                pairs[index].2 = value.clone();
            } else {
                hashes.get_mut(&hash).unwrap().push(pairs.len());
                pairs.push((hash, key.clone(), value.clone()));
            }
        }
        let count = pairs.len() + usize::from(nil_value.is_some());
        let count = self.scalar(
            session,
            &crate::portable::hir::Literal::Long(count as i64),
        )?;
        if entries.len() <= 8 {
            let mut data = pairs
                .iter()
                .flat_map(|(_, key, value)| [key, value])
                .collect::<Vec<_>>();
            if let Some(value) = &nil_value {
                data.splice(nil_index * 2..nil_index * 2, [&nil, value]);
            }
            let array = self.array(session, &data)?;
            self.construct(session,
                Class::PersistentArrayMap,
                &[&nil, &count, &array, &nil],
            )
        } else {
            let root = self.map_node(session, &pairs, 0, &nil)?;
            let has_nil = self.scalar(
                session,
                &crate::portable::hir::Literal::Bool(nil_value.is_some()),
            )?;
            self.construct(session,
                Class::PersistentHashMap,
                &[
                    &nil,
                    &count,
                    &root,
                    &has_nil,
                    nil_value.as_ref().unwrap_or(&nil),
                    &nil,
                ],
            )
        }
    }
    // Identifier equality is independent of metadata and live constructor
    // globals. Other user values retain the captured observable key-test path.
    fn identifier_key(
        &self,
        session: &mut SessionHost<'_>,
        value: &SessionValue,
    ) -> Result<Option<(Class, Vec<u16>)>, SessionError> {
        let interrupt = session.host_work_interrupt();
        session.inspect(value, |mut store, value| {
            let Some(structure) = reference(&value)?.as_struct(&store)? else {
                return Ok(None);
            };
            let storage = structure.fields(&mut store)?.collect::<Vec<_>>();
            if storage.len() != 4 {
                return Ok(None);
            }
            // A closure with one capture is also four fields (ADR-0004), its
            // first a code struct: only an object's first field is a
            // descriptor.
            let is_descriptor = match storage[0].anyref().flatten() {
                Some(first) => match first.as_struct(&store)? {
                    Some(first) => first.ty(&store)?.fields().len() == 6,
                    None => false,
                },
                None => false,
            };
            if !is_descriptor {
                return Ok(None);
            }
            let descriptor = fields(&mut store, &storage[0], 6)?;
            let Val::I64(id) = descriptor[0] else {
                return Ok(None);
            };
            if !self.core
                .classes
                .get(&id)
                .is_some_and(|(class, _)| matches!(class, Class::Symbol | Class::Keyword))
            {
                return Ok(None);
            }
            let (class, data) = object(&mut store, &value, &self.core.classes)?;
            if data.len() != if class == Class::Symbol { 5 } else { 4 } {
                return Err(error("Invalid compiler identifier key layout"));
            }
            let mut budget = Budget {
                display: None,
                native: None,
                source_valid: None,
                include_metadata: true,
                interrupt,
                calls: None,
                undefined: None,
                active: Vec::new(),
                        profile: std::env::var_os("SUSS_MACRO_FUEL_TRACE").is_some(),
                        host_fuel: std::cell::Cell::new(0),
                        lazy_calls: std::cell::Cell::new(0),
            };
            Ok(Some((class, text(&mut store, &data[2], &mut budget)?)))
        })
    }
    fn map_node(
        &self,
        session: &mut SessionHost<'_>,
        pairs: &[(u32, SessionValue, SessionValue)],
        shift: u32,
        nil: &SessionValue,
    ) -> Result<SessionValue, SessionError> {
        use crate::portable::hir::Literal;
        session.charge_host_work(pairs.len() as u64)?;
        if pairs.is_empty() {
            return Ok(nil.clone());
        }
        if pairs.len() > 1 && pairs.iter().all(|pair| pair.0 == pairs[0].0) {
            let hash = self.scalar(session, &Literal::Long(i64::from(pairs[0].0 as i32)))?;
            let count = self.scalar(session, &Literal::Long(pairs.len() as i64))?;
            let items = pairs
                .iter()
                .flat_map(|(_, key, value)| [key, value])
                .collect::<Vec<_>>();
            let array = self.array(session, &items)?;
            return self.construct(session,
                Class::HashCollisionNode,
                &[nil, &hash, &count, &array],
            );
        }
        if shift > 30 {
            return Err(SessionError::Host(error(
                "Compiler map hash path exceeds 32 bits",
            )));
        }
        let mut groups: BTreeMap<u32, Vec<(u32, SessionValue, SessionValue)>> = BTreeMap::new();
        for pair in pairs {
            groups
                .entry((pair.0 >> shift) & 31)
                .or_default()
                .push(pair.clone());
        }
        let mut bitmap = 0u32;
        let mut items = Vec::new();
        for (bit, group) in groups {
            bitmap |= 1u32 << bit;
            if group.len() == 1 {
                items.push(group[0].1.clone());
                items.push(group[0].2.clone());
            } else {
                items.push(nil.clone());
                items.push(self.map_node(session, &group, shift + 5, nil)?);
            }
        }
        let bitmap = self.scalar(session, &Literal::Long(i64::from(bitmap as i32)))?;
        let array = self.array(session, &items.iter().collect::<Vec<_>>())?;
        self.construct(session,
            Class::BitmapIndexedNode,
            &[nil, &bitmap, &array],
        )
    }

    pub fn set_values(
        &self,
        session: &mut SessionHost<'_>,
        items: &[SessionValue],
    ) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        session.with_operation_budget(|session| self.set_values_inner(session, items))
    }
    fn set_values_inner(
        &self,
        session: &mut SessionHost<'_>,
        items: &[SessionValue],
    ) -> Result<SessionValue, SessionError> {
        session.charge_host_work(items.len() as u64)?;
        if items.is_empty() {
            return self.seed(session,"empty-set");
        }
        let nil = self.scalar(session, &crate::portable::hir::Literal::Nil)?;
        self.set_with_metadata(session, items, &nil)
    }
    fn set_with_metadata(
        &self,
        session: &mut SessionHost<'_>,
        items: &[SessionValue],
        metadata: &SessionValue,
    ) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        let nil = self.scalar(session, &crate::portable::hir::Literal::Nil)?;
        let entries = items
            .iter()
            .map(|item| (item.clone(), nil.clone()))
            .collect::<Vec<_>>();
        let map = self.map_values(session, &entries)?;
        self.construct(session,
            Class::PersistentHashSet,
            &[metadata, &map, &nil],
        )
    }
    /// The queue `#queue [items...]` reads as, with `metadata` unless nil.
    pub fn queue_values(
        &self,
        session: &mut SessionHost<'_>,
        items: &[SessionValue],
        metadata: Option<&SessionValue>,
    ) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        let empty = self.seed(session, "empty-queue")?;
        let mut queue = if items.is_empty() {
            empty
        } else {
            let elements = self.vector_values(session, items)?;
            session.invoke(&self.core.factories["into"], &[&empty, &elements])?
        };
        if let Some(metadata) = metadata {
            queue = session.invoke(&self.core.factories["with-meta"], &[&queue, metadata])?;
        }
        Ok(queue)
    }
    pub fn vector_values(
        &self,
        session: &mut SessionHost<'_>,
        items: &[SessionValue],
    ) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        session.with_operation_budget(|session| self.vector_values_inner(session, items))
    }
    fn vector_values_inner(
        &self,
        session: &mut SessionHost<'_>,
        items: &[SessionValue],
    ) -> Result<SessionValue, SessionError> {
        session.charge_host_work(items.len() as u64)?;
        use crate::portable::hir::Literal;
        let nil = self.scalar(session, &Literal::Nil)?;
        let tail_offset = if items.is_empty() {
            0
        } else {
            ((items.len() - 1) / 32) * 32
        };
        let tail = self.object_array(session, &items[tail_offset..].iter().collect::<Vec<_>>())?;
        let mut shift = 5u32;
        while (tail_offset / 32) > (1usize << shift) {
            shift += 5;
        }
        let root = self.vector_node(session, &items[..tail_offset], shift, &nil)?;
        let count = self.scalar(session, &Literal::Long(items.len() as i64))?;
        let shift = self.scalar(session, &Literal::Long(shift as i64))?;
        self.construct(session,
            Class::PersistentVector,
            &[&nil, &count, &shift, &root, &tail, &nil],
        )
    }
    fn vector_node(
        &self,
        session: &mut SessionHost<'_>,
        items: &[SessionValue],
        shift: u32,
        nil: &SessionValue,
    ) -> Result<SessionValue, SessionError> {
        session.charge_host_work(32)?;
        let mut fields = vec![nil.clone(); 32];
        if shift == 0 {
            for (field, value) in fields.iter_mut().zip(items) {
                *field = value.clone();
            }
        } else {
            for (index, chunk) in items.chunks(1usize << shift).enumerate() {
                fields[index] = self.vector_node(session, chunk, shift - 5, nil)?;
            }
        }
        let array = self.object_array(session, &fields.iter().collect::<Vec<_>>())?;
        self.construct(session,
            Class::VectorNode,
            &[nil, &array],
        )
    }

    pub fn list_values(
        &self,
        session: &mut SessionHost<'_>,
        items: &[SessionValue],
    ) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        session.with_operation_budget(|session| self.list_values_inner(session, items))
    }
    fn list_values_inner(
        &self,
        session: &mut SessionHost<'_>,
        items: &[SessionValue],
    ) -> Result<SessionValue, SessionError> {
        session.charge_host_work(items.len() as u64)?;
        let nil = self.scalar(session, &crate::portable::hir::Literal::Nil)?;
        let mut tail = self.seed(session,"empty-list")?;
        for (index, value) in items.iter().enumerate().rev() {
            let count = self.scalar(
                session,
                &crate::portable::hir::Literal::Long((items.len() - index) as i64),
            )?;
            tail = self.construct(session,
                Class::List,
                &[&nil, value, &tail, &count, &nil],
            )?;
        }
        Ok(tail)
    }
    pub fn identifier(
        &self,
        session: &mut SessionHost<'_>,
        namespace: Option<&str>,
        name: &str,
        keyword: bool,
        metadata: Option<&SessionValue>,
    ) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        let nil = self.scalar(session, &crate::portable::hir::Literal::Nil)?;
        let ns = if let Some(namespace) = namespace {
            self.scalar(
                session,
                &crate::portable::hir::Literal::String(namespace.encode_utf16().collect()),
            )?
        } else {
            nil.clone()
        };
        let name_value = self.scalar(
            session,
            &crate::portable::hir::Literal::String(name.encode_utf16().collect()),
        )?;
        let fqn = namespace.map_or_else(
            || name.to_owned(),
            |namespace| format!("{namespace}/{name}"),
        );
        let fqn = self.scalar(
            session,
            &crate::portable::hir::Literal::String(fqn.encode_utf16().collect()),
        )?;
        // The hash cache is private to core and starts empty; core's own hash
        // fills it on first use (design decision 2026-10-25).
        let memo = nil.clone();
        if keyword {
            if metadata.is_some() {
                return Err(SessionError::Host(error(
                    "Keyword compiler data cannot carry metadata",
                )));
            }
            self.construct(session,
                Class::Keyword,
                &[&ns, &name_value, &fqn, &memo],
            )
        } else {
            self.construct(session,
                Class::Symbol,
                &[&ns, &name_value, &fqn, &nil, metadata.unwrap_or(&nil)],
            )
        }
    }
    pub fn quote(&self, session: &mut SessionHost<'_>, form: Form) -> Result<SessionValue, SessionError> {
        self.quote_ref(session, &form)
    }
    pub(crate) fn quote_ref(
        &self,
        session: &mut SessionHost<'_>,
        form: &Form,
    ) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        session.with_operation_budget(|session| self.form_value(session, &form, None))
    }
    pub(crate) fn quote_evaluation_ref(&self, session: &mut SessionHost<'_>, form: &Form, owner: u64) -> Result<SessionValue, SessionError> {
        self.check(session)?;
        session.with_operation_budget(|session| self.form_value(session, form, Some(owner)))
    }
    fn form_value(&self, session: &mut SessionHost<'_>, form: &Form, native_owner: Option<u64>) -> Result<SessionValue, SessionError> {
        use crate::portable::hir::Literal;
        enum Task<'a> {
            Visit(&'a Form),
            Finish {
                form: &'a Form,
                children: usize,
                has_metadata: bool,
            },
        }
        let failure = |form: &Form, message: &str| {
            SessionError::Compile(Diagnostic {
                span: form.span.clone(),
                message: message.into(),
            })
        };
        let mut tasks = vec![Task::Visit(form)];
        let mut values = Vec::<SessionValue>::new();
        while let Some(task) = tasks.pop() {
            match task {
                Task::Visit(form) => {
                    let work = 1u64.saturating_add(match &form.kind {
                        Kind::String(text) => text.len() as u64,
                        Kind::Symbol(name) => {
                            name.name.encode_utf16().count() as u64
                                + name
                                    .namespace
                                    .as_ref()
                                    .map_or(0, |part| part.encode_utf16().count() as u64 + 1)
                        }
                        Kind::Keyword(name) => {
                            name.name.encode_utf16().count() as u64
                                + name
                                    .namespace
                                    .as_ref()
                                    .map_or(0, |part| part.encode_utf16().count() as u64 + 1)
                        }
                        _ => 0,
                    });
                    session.charge_host_work(work)?;
                    let has_metadata = !form.metadata.is_empty();
                    let children: Vec<&Form> = match &form.kind {
                        Kind::List(items) | Kind::Vector(items) | Kind::Set(items) => {
                            items.iter().collect()
                        }
                        Kind::Tagged { .. } => match form.queue_items() {
                            Some(items) => items.iter().collect(),
                            None => return Err(failure(form, "Unsupported tagged macro data")),
                        },
                        Kind::Map(items) => {
                            if items.len() % 2 != 0 {
                                return Err(failure(
                                    form,
                                    "Macro form map requires paired entries",
                                ));
                            }
                            items.iter().collect()
                        }
                        Kind::Conditional(_)
                        | Kind::SplicingConditional(_)
                        | Kind::Discard(_)
                        | Kind::Prefix { .. } => {
                            return Err(failure(
                                form,
                                "Native macro data requires resolved reader prefixes",
                            ));
                        }
                        _ => Vec::new(),
                    };
                    let is_collection = matches!(
                        form.kind,
                        Kind::Symbol(_)
                            | Kind::List(_)
                            | Kind::Vector(_)
                            | Kind::Map(_)
                            | Kind::Set(_)
                            | Kind::Tagged { .. }
                    );
                    if has_metadata && !is_collection {
                        return Err(failure(form, "Metadata requires a symbol or collection"));
                    }
                    tasks.push(Task::Finish {
                        form,
                        children: children.len(),
                        has_metadata,
                    });
                    for child in children.into_iter().rev() {
                        tasks.push(Task::Visit(child));
                    }
                }
                Task::Finish {
                    form,
                    children,
                    has_metadata,
                } => {
                    let take = children;
                    if values.len() < take {
                        return Err(failure(form, "Invalid macro form construction stack"));
                    }
                    let start = values.len() - take;
                    let built = values.split_off(start);
                    let mut result = match &form.kind {
                        Kind::NativeConstant { owner, index } => {
                            if native_owner != Some(*owner) { return Err(failure(form, "Native constants are not portable macro syntax")); }
                            session.native_constant_value(*owner, *index)?
                        },
                        Kind::Nil => self.scalar(session, &Literal::Nil)?,
                        Kind::Bool(value) => self.scalar(session, &Literal::Bool(*value))?,
                        Kind::Number(value) => self.scalar(session, &Literal::Number(*value))?,
                        Kind::Long(value) => self.scalar(session, &Literal::Long(*value))?,
                        Kind::Exact(value) if matches!(value.value, suss_reader::forms::ExactValue::Integer { .. }) => {
                            let suss_reader::forms::ExactValue::Integer { value, big } = &value.value else { unreachable!() };
                            let (_, limbs) = value.to_u32_digits();
                            self.scalar(session, &Literal::BigInt { negative: num_traits::Signed::is_negative(value), limbs, big_integer: !big })?
                        }
                        Kind::Exact(value) if matches!(value.value, suss_reader::forms::ExactValue::Ratio { .. }) => {
                            let suss_reader::forms::ExactValue::Ratio { numerator, denominator } = &value.value else { unreachable!() };
                            self.scalar(session, &Literal::Ratio { negative: num_traits::Signed::is_negative(numerator), numerator: numerator.to_u32_digits().1, denominator: denominator.to_u32_digits().1 })?
                        }
                        Kind::Exact(value) => {
                            let suss_reader::forms::ExactValue::Decimal { unscaled, scale } = &value.value else { unreachable!() };
                            self.scalar(session, &Literal::Decimal { negative: num_traits::Signed::is_negative(unscaled),
                                unscaled: unscaled.to_u32_digits().1, scale: *scale })?
                        }
                        Kind::Uuid(value) => {
                            let most = self.scalar(session, &Literal::Long(value.most))?;
                            let least = self.scalar(session, &Literal::Long(value.least))?;
                            self.construct(session, Class::Uuid, &[&most, &least])?
                        }
                        Kind::String(value) => {
                            self.scalar(session, &Literal::String(value.clone()))?
                        }
                        Kind::Symbol(value) => self.identifier(
                            session,
                            value.namespace.as_deref(),
                            &value.name,
                            false,
                            None,
                        )?,
                        Kind::Keyword(value) => self.identifier(
                            session,
                            value.namespace.as_deref(),
                            &value.name,
                            true,
                            None,
                        )?,
                        Kind::List(_) => self.list_values(session, &built)?,
                        Kind::Vector(_) => self.vector_values(session, &built)?,
                        Kind::Map(_) => {
                            let entries = built
                                .chunks_exact(2)
                                .map(|pair| (pair[0].clone(), pair[1].clone()))
                                .collect::<Vec<_>>();
                            self.map_values(session, &entries)?
                        }
                        Kind::Set(_) if has_metadata => self.scalar(session, &Literal::Nil)?,
                        Kind::Set(_) => self.set_values(session, &built)?,
                        // Built once, below, with its metadata.
                        Kind::Tagged { .. } if has_metadata => self.scalar(session, &Literal::Nil)?,
                        Kind::Tagged { .. } => self.queue_values(session, &built, None)?,
                        _ => {
                            return Err(failure(
                                form,
                                "Native macro data requires resolved reader prefixes",
                            ));
                        }
                    };
                    if has_metadata {
                        // Preserve quotation order: realize children and the
                        // base collection before evaluating its metadata map.
                        let pairs = normalized_reader_metadata(session, form)?;
                        let metadata_form = Form {
                            span: form.span.clone(),
                            metadata: vec![],
                            kind: Kind::Map(pairs),
                        };
                        let metadata = stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || {
                            self.form_value(session, &metadata_form, native_owner)
                        })?;
                        if matches!(form.kind, Kind::Set(_)) {
                            result = self.set_with_metadata(session, &built, &metadata)?;
                        } else if matches!(form.kind, Kind::Tagged { .. }) {
                            result = self.queue_values(session, &built, Some(&metadata))?;
                        } else {
                            let class = match form.kind {
                                Kind::Symbol(_) => Class::Symbol,
                                Kind::List(ref items) if items.is_empty() => Class::EmptyList,
                                Kind::List(_) => Class::List,
                                Kind::Vector(_) => Class::PersistentVector,
                                Kind::Map(ref items) if items.len() <= 16 => {
                                    Class::PersistentArrayMap
                                }
                                Kind::Map(_) => Class::PersistentHashMap,
                                _ => unreachable!("metadata-bearing datum validated"),
                            };
                            let mut fields = session.data_fields(&result)?;
                            fields[if class == Class::Symbol { 4 } else { 0 }] = metadata;
                            result = self.construct(session,
                                class,
                                &fields.iter().collect::<Vec<_>>(),
                            )?;
                        }
                    }
                    values.push(result);
                }
            }
        }
        if values.len() != 1 {
            return Err(failure(form, "Invalid macro form construction result"));
        }
        Ok(values.pop().unwrap())
    }
    /// Original result locations are not encoded in runtime values. Attribute
    /// expansion data to the supplied macro call site; never invent source bytes.
    pub fn read(
        &self,
        session: &mut SessionHost<'_>,
        value: &SessionValue,
        span: Range<usize>,
    ) -> Result<Form, SessionError> {
        self.read_with_metadata(session, value, span, true)
    }
    fn read_with_metadata(
        &self,
        session: &mut SessionHost<'_>,
        value: &SessionValue,
        span: Range<usize>,
        include_metadata: bool,
    ) -> Result<Form, SessionError> {
        self.read_with_context(session, value, span, include_metadata, None).map(|(form, _)| form)
    }
    pub(crate) fn read_evaluation(
        &self, session: &mut SessionHost<'_>, value: &SessionValue,
        span: Range<usize>, owner: u64, closure_test: wasmtime::Func,
        class_test: wasmtime::Func, instance_test: wasmtime::Func, var_class: wasmtime::OwnedRooted<AnyRef>,
        meta_fn_class: wasmtime::OwnedRooted<AnyRef>,
    ) -> Result<Form, SessionError> {
        let native = NativeRead { owner, closure_test, class_test, instance_test, var_class, meta_fn_class, constants: vec![] };
        let (form, constants) = self.read_with_context(session, value, span, true, Some(native))?;
        for (index, value, function) in constants { session.retain_native_constant(index, value, function)?; }
        Ok(form)
    }
    fn read_with_context(
        &self, session: &mut SessionHost<'_>, value: &SessionValue,
        span: Range<usize>, include_metadata: bool, native: Option<NativeRead>,
    ) -> Result<(Form, Vec<(u64, wasmtime::OwnedRooted<AnyRef>, bool)>), SessionError> {
        self.check(session)?;
        session.with_operation_budget(|session| {
            let interrupt = session.host_work_interrupt();
            session
                .data_inspect_calls(
                    value,
                    &self.core.factories["lazy-sval"],
                    |mut store, value, args_new, invoke, _closure_new, function, undefined| {
                        let mut budget = Budget {
                            display: None,
                native,
                            source_valid: None,
                            include_metadata,
                            interrupt,
                            active: Vec::new(),
                        profile: std::env::var_os("SUSS_MACRO_FUEL_TRACE").is_some(),
                        host_fuel: std::cell::Cell::new(0),
                        lazy_calls: std::cell::Cell::new(0),
                            calls: Some(ReadCalls {
                                args_new,
                                invoke,
                                function,
                            }),
                            undefined: Some(undefined),
                        };
                        let result = decode(&mut store, &value, &self.core.classes, &span, 0, &mut budget);
                        if budget.profile {
                            eprintln!("macro-decode host-fuel={} lazy-calls={} success={}", budget.host_fuel.get(), budget.lazy_calls.get(), result.is_ok());
                        }
                        result.map(|form| (form, budget.native.map(|native| native.constants).unwrap_or_default()))
                    },
                )
                .map_err(|failure| match failure {
                    SessionError::Host(failure) => SessionError::Compile(Diagnostic {
                        span,
                        message: if include_metadata {
                            format!("Invalid or unsupported compiled macro data: {failure}")
                        } else {
                            format!("Invalid or unsupported value display: {failure}")
                        },
                    }),
                    failure => failure,
                })
        })
    }
}
fn error(message: &str) -> wasmtime::Error {
    wasmtime::Error::msg(message.to_owned())
}

fn reference(value: &Val) -> wasmtime::Result<&Rooted<AnyRef>> {
    value
        .anyref()
        .flatten()
        .ok_or_else(|| error("Expected non-null language reference"))
}
fn fields(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    count: usize,
) -> wasmtime::Result<Vec<Val>> {
    let object = reference(value)?
        .as_struct(&*store)?
        .ok_or_else(|| error("Expected typed structure"))?;
    // Reject foreign/wide layouts before rooting/copying their fields.
    if object.ty(&*store)?.fields().len() != count {
        return Err(error("Unexpected structure layout"));
    }
    Ok(object.fields(&mut *store)?.collect())
}
/// A runtime long or double as a double; these fields are bounded integers.
fn number(store: &mut StoreContextMut<'_, ()>, value: &Val) -> wasmtime::Result<Option<f64>> {
    Ok(runtime_number(&mut *store, value)?.map(RuntimeNumber::as_f64))
}
fn array(store: &mut StoreContextMut<'_, ()>, value: &Val) -> wasmtime::Result<Vec<Val>> {
    let array = reference(value)?
        .as_array(&*store)?
        .ok_or_else(|| error("Expected field array"))?;
    // Every array read here is a descriptor owner, nominal field vector, or
    // sparse-array node. Their pinned ABI widths are at most six; source
    // elements are traversed through object_array_elements instead.
    if array.len(&*store)? > 6 {
        return Err(error("Nominal field array exceeds ABI layout"));
    }
    Ok(array.elems(&mut *store)?.collect())
}
/// The sentinel tag of nil (a null reference) or of a false, true or
/// undefined struct; `None` for any other value.
fn sentinel(store: &mut StoreContextMut<'_, ()>, value: &Val) -> wasmtime::Result<Option<u32>> {
    crate::portable_session::sentinel_tag(&mut *store, value)
}
fn nil(store: &mut StoreContextMut<'_, ()>, value: &Val) -> wasmtime::Result<bool> {
    Ok(sentinel(store, value)? == Some(0))
}
fn metadata(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    span: &Range<usize>,
    depth: usize,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<Form>> {
    if !budget.include_metadata {
        return Ok(vec![]);
    }
    if nil(store, value)? {
        return Ok(vec![]);
    }
    let form = decode(store, value, classes, span, depth + 1, budget)?;
    if !matches!(form.kind, Kind::Map(_)) {
        return Err(error(
            "Runtime macro metadata requires a canonical persistent map",
        ));
    }
    Ok(vec![form])
}

fn text(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<u16>> {
    let array = reference(value)?
        .as_array(&*store)?
        .ok_or_else(|| error("Expected UTF16 string"))?;
    if !matches!(
        array.ty(&*store)?.element_type(),
        wasmtime::StorageType::I16
    ) {
        return Err(error("Expected UTF16 element storage"));
    }
    let len = array.len(&*store)?;
    charge_read_work(store, len as u64, budget)?;
    array
        .elems(&mut *store)?
        .map(|unit| match unit {
            Val::I32(unit) => Ok(unit as u16),
            _ => Err(error("Invalid UTF16 element")),
        })
        .collect()
}
fn name(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    budget: &mut Budget,
) -> wasmtime::Result<String> {
    String::from_utf16(&text(store, value, budget)?)
        .map_err(|_| error("Macro identifier contains a lone surrogate"))
}
fn object(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
) -> wasmtime::Result<(Class, Vec<Val>)> {
    let storage = fields(store, value, 4)?;
    let descriptor = fields(store, &storage[0], 6)?;
    let Val::I64(id) = descriptor[0] else {
        return Err(error("Invalid nominal descriptor identity"));
    };
    let (class, canonical) = classes
        .get(&id)
        .ok_or_else(|| error("Unrecognized nominal macro data type"))?;
    let expected = canonical
        .rooted(store)
        .ok_or_else(|| error("Nominal macro data type is nil"))?;
    if !Rooted::ref_eq(&*store, reference(&storage[0])?, &expected)? {
        return Err(error(
            "Macro data descriptor is not the captured canonical identity",
        ));
    }
    Ok((*class, array(store, &storage[1])?))
}
fn absent(store: &mut StoreContextMut<'_, ()>, value: &Val) -> wasmtime::Result<bool> {
    // Nil (0) and undefined (6) both satisfy the pinned nil? storage test.
    Ok(matches!(sentinel(store, value)?, Some(0 | 6)))
}
// Functions, real class values and Vars retain authenticated same-Store roots.
// This authority is installed only for a public native eval read. Ordinary
// macro/display/source readers retain their strict nominal syntax whitelist.
struct NativeRead {
    owner: u64,
    closure_test: wasmtime::Func,
    class_test: wasmtime::Func,
    instance_test: wasmtime::Func,
    var_class: wasmtime::OwnedRooted<AnyRef>,
    meta_fn_class: wasmtime::OwnedRooted<AnyRef>,
    constants: Vec<(u64, wasmtime::OwnedRooted<AnyRef>, bool)>,
}
static NEXT_NATIVE_CONSTANT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
impl NativeRead {
    fn constant(&mut self, store: &mut StoreContextMut<'_, ()>, value: &Val, depth: usize,
        interrupt: &std::sync::atomic::AtomicBool) -> wasmtime::Result<Option<Kind>> {
        let mut result = [Val::I32(0)];
        // Class constructors are represented by closures too. Class identity
        // must win before deciding whether to materialize a function constant.
        self.class_test.call(&mut *store, &[*value], &mut result)?;
        let class = result[0].unwrap_i32() != 0;
        let mut function = false;
        if !class {
            self.closure_test.call(&mut *store, &[*value], &mut result)?;
            function = result[0].unwrap_i32() != 0;
            if !function {
                let class = Val::AnyRef(Some(self.meta_fn_class.to_rooted(&mut *store)));
                self.instance_test.call(&mut *store, &[class, *value], &mut result)?;
                function = result[0].unwrap_i32() != 0;
            }
        }
        if !class && !function {
            let class = Val::AnyRef(Some(self.var_class.to_rooted(&mut *store)));
            self.instance_test.call(&mut *store, &[class, *value], &mut result)?;
            if result[0].unwrap_i32() == 0 { return Ok(None); }
        }
        let materialize = function && depth != 0;
        let root = reference(value)?;
        // Clojure's constant pool preserves repeated source object aliases.
        // Compare actual roots and meter comparisons; no pointer is serialized.
        for (index, previous, mode) in &self.constants {
            Session::consume_host_work(store.as_context_mut(), 1, interrupt)
                .map_err(|failure| match failure {
                    SessionError::Trap(error) | SessionError::Host(error) => error,
                    other => error(&other.to_string()),
                })?;
            let previous = previous.to_rooted(&mut *store);
            if *mode == materialize && wasmtime::Rooted::ref_eq(&*store, &root, &previous)? {
                return Ok(Some(Kind::NativeConstant { owner: self.owner, index: *index }));
            }
        }
        let index = NEXT_NATIVE_CONSTANT.fetch_update(
            std::sync::atomic::Ordering::Relaxed, std::sync::atomic::Ordering::Relaxed,
            |index| index.checked_add(1),
        ).map_err(|_| error("Native constant identity exhausted"))?;
        self.constants.push((index, root.to_owned_rooted(&mut *store)?, materialize));
        Ok(Some(Kind::NativeConstant { owner: self.owner, index }))
    }
}
struct ReadCalls {
    args_new: wasmtime::Func,
    invoke: wasmtime::Func,
    function: Val,
}
struct Budget {
    display: Option<DisplayCalls>,
    native: Option<NativeRead>,
    include_metadata: bool,
    // None for ordinary macro/display reads. Compiler source checks accumulate
    // invariant mismatches without treating them as a new source certificate.
    source_valid: Option<bool>,
    calls: Option<ReadCalls>,
    // The undefined sentinel for source-array holes; None where no source
    // array can be read.
    undefined: Option<Val>,
    interrupt: std::sync::Arc<std::sync::atomic::AtomicBool>,
    active: Vec<Val>,
    profile: bool,
    host_fuel: std::cell::Cell<u64>,
    lazy_calls: std::cell::Cell<u64>,
}
fn unsupported_datum(budget: &Budget, name: &str) -> wasmtime::Error {
    if budget.display.is_some() {
        error(&format!("Value display does not yet support {name}"))
    } else {
        error(&format!("{name} are not macro syntax"))
    }
}
fn charge_read_work(store: &mut StoreContextMut<'_, ()>, units: u64, budget: &Budget) -> wasmtime::Result<()> {
    if !budget.profile {
        return Session::consume_host_work(store.as_context_mut(), units, &budget.interrupt);
    }
    let before = store.get_fuel()?;
    let result = Session::consume_host_work(store.as_context_mut(), units, &budget.interrupt);
    let after = store.get_fuel()?;
    budget.host_fuel.set(budget.host_fuel.get().saturating_add(before.saturating_sub(after)));
    result
}
fn spend(store: &mut StoreContextMut<'_, ()>, budget: &mut Budget) -> wasmtime::Result<()> {
    charge_read_work(store, 1, budget)
}
fn enter_active(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    budget: &mut Budget,
    cycle_message: &str,
    allow_top_alias: bool,
) -> wasmtime::Result<bool> {
    if value.anyref().flatten().is_none() {
        return Ok(false);
    }
    for (index, prior) in budget.active.iter().enumerate() {
        charge_read_work(store, 1, budget)?;
        if Rooted::ref_eq(&*store, reference(prior)?, reference(value)?)? {
            if allow_top_alias && index + 1 == budget.active.len() {
                // `decode_datum` marks a sequence root active before calling
                // `sequence` for that same value. Record this one permitted
                // wrapper alias as its own stack frame: otherwise a nested
                // self-link (for example NodeSeq.s = NodeSeq) is repeatedly
                // mistaken for the same wrapper and recurses until fuel runs
                // out instead of reporting the cycle.
                budget.active.push(value.clone());
                return Ok(true);
            }
            return Err(error(cycle_message));
        }
    }
    budget.active.push(value.clone());
    Ok(true)
}
fn leave_active(budget: &mut Budget, pushed: bool) {
    if pushed {
        budget.active.pop();
    }
}
fn decode(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    span: &Range<usize>,
    depth: usize,
    budget: &mut Budget,
) -> wasmtime::Result<Form> {
    decode_datum::<Form>(store, value, classes, span, depth, budget)
}
fn decode_datum<T: DatumTarget>(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    span: &Range<usize>,
    depth: usize,
    budget: &mut Budget,
) -> wasmtime::Result<T> {
    let pushed = enter_active(
        store,
        value,
        budget,
        "Cyclic runtime value cannot be transported as macro data",
        false,
    )?;
    let result = stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || {
        decode_datum_inner(store, value, classes, span, depth, budget)
    });
    leave_active(budget, pushed);
    result
}
fn decode_datum_inner<T: DatumTarget>(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    span: &Range<usize>,
    depth: usize,
    budget: &mut Budget,
) -> wasmtime::Result<T> {
    spend(store, budget)?;
    if let Some(native) = &mut budget.native {
        if let Some(kind) = native.constant(store, value, depth, &budget.interrupt)? {
            return Ok(T::plain(Form { span: span.clone(), metadata: vec![], kind }));
        }
    }
    if let Some(calls) = budget.display {
        if let Some(leaf) = calls.read(store, *value)? {
            return T::opaque(leaf);
        }
    }
    let mut reader_metadata = vec![];
    let tag = sentinel(store, value)?;
    let long = match runtime_number(&mut *store, value)? {
        Some(RuntimeNumber::Long(long)) => Some(long),
        _ => None,
    };
    // Nil has no reference; other sentinels and an i31 long need none.
    let reference = match (tag, long) {
        (None, None) => Some(reference(value)?),
        _ => None,
    };
    let kind = if let Some(long) = long {
        DecodedKind::Plain(Kind::Long(long))
    } else if let Some(tag) = tag {
        match tag {
            0 => DecodedKind::Plain(Kind::Nil),
            2 => DecodedKind::Plain(Kind::Bool(false)),
            4 => DecodedKind::Plain(Kind::Bool(true)),
            _ => return Err(error("Unknown language sentinel")),
        }
    } else if let Some(reference) = reference
        && reference.as_array(&*store)?.is_some()
    {
        DecodedKind::Plain(Kind::String(text(store, value, budget)?))
    } else {
        let structure = reference
            .expect("a non-sentinel value has a reference")
            .as_struct(&*store)?
            .ok_or_else(|| error("Unsupported macro value"))?;
        // Scalar boxes and nominal objects have fixed ABI widths. Checking
        // metadata first keeps hostile arbitrary-width structs off the copying
        // path; this logical decoder does not admit other representations.
        if !matches!(structure.ty(&*store)?.fields().len(), 1 | 2 | 4) {
            return Err(error("Unexpected structure layout"));
        }
        let values = structure.fields(&mut *store)?.collect::<Vec<_>>();
        if let [Val::F64(bits)] = values.as_slice() {
            DecodedKind::Plain(Kind::Number(f64::from_bits(*bits)))
        } else if let [Val::AnyRef(Some(_)), Val::AnyRef(Some(_))] = values.as_slice() {
            let numerator = decode(store, &values[0], classes, span, depth+1, budget)?;
            let denominator = decode(store, &values[1], classes, span, depth+1, budget)?;
            let integer = |form: Form| match &form.kind {
                Kind::Exact(number) => match &number.value {
                    suss_reader::forms::ExactValue::Integer { value, .. } => Ok(value.clone()),
                    _ => Err(error("Invalid Ratio integer")),
                },
                _ => Err(error("Invalid Ratio integer")),
            };
            let numerator = integer(numerator)?;
            let denominator = integer(denominator)?;
            if num_traits::Zero::is_zero(&numerator) || !num_traits::Signed::is_positive(&denominator) || num_traits::One::is_one(&denominator) {
                return Err(error("Invalid normalized Ratio"));
            }
            DecodedKind::Plain(Kind::Exact(suss_reader::forms::ExactNumber::ratio(num_traits::Signed::is_negative(&numerator), numerator.to_u32_digits().1, denominator.to_u32_digits().1)))
        } else if let [Val::AnyRef(Some(_)), Val::I32(scale)] = values.as_slice() {
            let integer = decode(store, &values[0], classes, span, depth+1, budget)?;
            let Kind::Exact(number) = &integer.kind else { return Err(error("Invalid Decimal unscaled integer")); };
            let suss_reader::forms::ExactValue::Integer { value, .. } = &number.value else { return Err(error("Invalid Decimal unscaled integer")); };
            DecodedKind::Plain(Kind::Exact(suss_reader::forms::ExactNumber::decimal(
                num_traits::Signed::is_negative(value), value.to_u32_digits().1, *scale)))
        } else if let [Val::I32(sign), Val::AnyRef(Some(limbs)), Val::I32(used), Val::I32(display)] = values.as_slice() {
            if !(-1..=1).contains(sign) || *used < 0 || !(0..=1).contains(display) { return Err(error("Invalid BigInt metadata")); }
            let array = limbs.as_array(&*store)?.ok_or_else(|| error("Invalid BigInt magnitude"))?;
            if *used as u32 > array.len(&*store)? { return Err(error("Invalid BigInt length")); }
            let mut digits = Vec::new();
            for index in 0..*used as u32 {
                charge_read_work(store, 1, budget)?;
                digits.push(array.get(&mut *store, index)?.unwrap_i32() as u32);
            }
            DecodedKind::Plain(Kind::Exact(suss_reader::forms::ExactNumber::integer(*sign < 0, digits, *display == 0)))
        } else {
            let (class, data) = object(store, value, classes)?;
            let slot = match class {
                Class::Symbol => Some(4),
                Class::PersistentVector
                | Class::PersistentArrayMap
                | Class::PersistentHashMap
                | Class::PersistentHashSet
                | Class::NodeSeq
                | Class::ArrayNodeSeq
                | Class::List
                | Class::Cons
                | Class::EmptyList
                | Class::LazySeq => Some(0),
                Class::ChunkedCons => Some(2),
                Class::IndexedSeq | Class::PersistentArrayMapSeq => Some(2),
                Class::ChunkedSeq => Some(4),
                Class::KeySeq => Some(1),
                Class::PersistentQueue => Some(0),
                _ => None,
            };
            if let Some(value) = slot.and_then(|index| data.get(index)) {
                reader_metadata = metadata(store, value, classes, span, depth, budget)?;
            }
            match class {
                Class::Uuid => {
                    if data.len() != 2 { return Err(error("Invalid UUID field layout")); }
                    let half = |store: &mut StoreContextMut<'_, ()>, value: &Val| {
                        match runtime_number(store, value)? {
                            Some(RuntimeNumber::Long(value)) => Ok(value),
                            _ => Err(error("Invalid UUID long field")),
                        }
                    };
                    DecodedKind::Plain(Kind::Uuid(suss_reader::uuid::Uuid {
                        most: half(store, &data[0])?, least: half(store, &data[1])?,
                    }))
                }
                Class::Symbol | Class::Keyword => {
                    let count = if matches!(class, Class::Symbol) { 5 } else { 4 };
                    if data.len() != count {
                        return Err(error("Invalid identifier field layout"));
                    }
                    let namespace = if nil(store, &data[0])? {
                        None
                    } else {
                        Some(name(store, &data[0], budget)?)
                    };
                    let name = name(store, &data[1], budget)?;
                    if budget.source_valid.is_some() {
                        let fqn = text(store, &data[2], budget)?;
                        let expected = namespace.as_deref().into_iter()
                            .flat_map(|ns| ns.encode_utf16().chain(std::iter::once(b'/' as u16)))
                            .chain(name.encode_utf16());
                        let mut index = 0;
                        let mut matches = true;
                        for unit in expected {
                            charge_read_work(store, 1, budget)?;
                            if fqn.get(index) != Some(&unit) { matches = false; }
                            index += 1;
                        }
                        charge_read_work(store, 1, budget)?;
                        if index != fqn.len() { matches = false; }
                        if !matches { budget.source_valid = Some(false); }
                    }
                    if count == 5 {
                        match suss_reader::forms::ExactNumber::from_symbol(namespace.as_deref(), &name) {
                            Some(number) => DecodedKind::Plain(Kind::Exact(number)),
                            None => DecodedKind::Plain(Kind::Symbol(suss_reader::Symbol { namespace, name })),
                        }
                    } else {
                        DecodedKind::Plain(Kind::Keyword(suss_reader::Keyword { namespace, name }))
                    }
                }
                Class::PersistentVector => {
                    DecodedKind::Vector(vector(store, &data, classes, span, depth, budget)?)
                }
                Class::PersistentArrayMap => {
                    if data.len() != 4 {
                        return Err(error("Invalid persistent array map field layout"));
                    }
                    let count = integer(store, &data[1])?;
                    let entries = source_elements(store, &data[2], classes, budget)?;
                    if count.checked_mul(2) != Some(entries.len()) {
                        return Err(error("Map count disagrees with pair storage"));
                    }
                    DecodedKind::Map(
                        entries
                            .iter()
                            .map(|entry| {
                                decode_datum(store, entry, classes, span, depth + 1, budget)
                            })
                            .collect::<wasmtime::Result<Vec<_>>>()?,
                    )
                }
                Class::PersistentHashMap => {
                    DecodedKind::Map(hash_map(store, &data, classes, span, depth, budget)?)
                }
                Class::PersistentHashSet => {
                    if data.len() != 3 {
                        return Err(error("Invalid persistent hash set field layout"));
                    }
                    let (map_class, map_data) = object(store, &data[1], classes)?;
                    let entries = match map_class {
                        Class::PersistentHashMap => {
                            hash_map_pairs(store, &map_data, classes, budget)?
                        }
                        Class::PersistentArrayMap => {
                            if map_data.len() != 4 {
                                return Err(error("Invalid set array map layout"));
                            }
                            let count = integer(store, &map_data[1])?;
                            let entries = source_elements(store, &map_data[2], classes, budget)?;
                            if count.checked_mul(2) != Some(entries.len()) {
                                return Err(error("Set count disagrees with array map storage"));
                            }
                            entries
                        }
                        _ => return Err(error("Set needs a canonical persistent backing map")),
                    };
                    if budget.source_valid.is_some() {
                        charge_read_work(store, 1, budget)?;
                        // The compiler's backing maps are constructed with nil
                        // metadata, independently of the enclosing set metadata.
                        if sentinel(store, &map_data[0])? != Some(0) {
                            budget.source_valid = Some(false);
                        }
                    }
                    DecodedKind::Set(
                        entries
                            .chunks_exact(2)
                            .map(|pair| {
                                if budget.source_valid.is_some() {
                                    charge_read_work(store, 1, budget)?;
                                    // Native source set construction stores nil
                                    // values; logical set decoding otherwise
                                    // visits only the keys of its backing map.
                                    if sentinel(store, &pair[1])? != Some(0) {
                                        budget.source_valid = Some(false);
                                    }
                                }
                                decode_datum(store, &pair[0], classes, span, depth + 1, budget)
                            })
                            .collect::<wasmtime::Result<Vec<_>>>()?,
                    )
                }
                Class::BitmapIndexedNode | Class::ArrayNode | Class::HashCollisionNode => {
                    return Err(unsupported_datum(budget, "Hash trie nodes"));
                }
                Class::MapEntry => {
                    if data.len() != 3 {
                        return Err(error("Invalid map entry field layout"));
                    }
                    DecodedKind::Vector(
                        data[..2]
                            .iter()
                            .map(|entry| {
                                decode_datum(store, entry, classes, span, depth + 1, budget)
                            })
                            .collect::<wasmtime::Result<Vec<_>>>()?,
                    )
                }
                Class::PersistentArrayMapSeq
                | Class::ChunkedSeq
                | Class::NodeSeq
                | Class::ArrayNodeSeq => {
                    DecodedKind::List(sequence(store, value, classes, span, depth, budget)?)
                }
                Class::KeySeq => {
                    if data.len() != 2 {
                        return Err(error("Invalid key sequence field layout"));
                    }
                    DecodedKind::List(
                        map_sequence_pairs(store, &data[0], classes, 0, budget)?
                            .chunks_exact(2)
                            .map(|pair| {
                                decode_datum(store, &pair[0], classes, span, depth + 1, budget)
                            })
                            .collect::<wasmtime::Result<Vec<_>>>()?,
                    )
                }
                Class::ArrayChunk => return Err(unsupported_datum(budget, "Array chunks")),
                Class::LazySeq | Class::ChunkedCons => {
                    DecodedKind::List(sequence(store, value, classes, span, depth, budget)?)
                }
                Class::VectorNode => return Err(unsupported_datum(budget, "Vector trie nodes")),
                Class::List | Class::Cons | Class::EmptyList | Class::IndexedSeq => {
                    DecodedKind::List(sequence(store, value, classes, span, depth, budget)?)
                }
                Class::PersistentQueue => {
                    // Fields: meta, count, front (a seq or nil), rear (a vector).
                    if data.len() != 5 {
                        return Err(error("Invalid persistent queue field layout"));
                    }
                    budget.source_valid = budget.source_valid.map(|_| false);
                    let mut items = if nil(store, &data[2])? {
                        vec![]
                    } else {
                        sequence(store, &data[2], classes, span, depth, budget)?
                    };
                    let (rear_class, rear) = object(store, &data[3], classes)?;
                    if rear_class != Class::PersistentVector {
                        return Err(error("Queue needs a persistent vector rear"));
                    }
                    items.extend(vector(store, &rear, classes, span, depth, budget)?);
                    if integer(store, &data[1])? != items.len() {
                        return Err(error("Queue count disagrees with its elements"));
                    }
                    DecodedKind::Queue(items)
                }
            }
        }
    };
    Ok(match kind {
        DecodedKind::Plain(kind) => T::plain(Form {
            span: span.clone(),
            metadata: reader_metadata,
            kind,
        }),
        DecodedKind::List(items) => T::collection(
            DisplayCollection::List,
            items,
            span.clone(),
            reader_metadata,
        ),
        DecodedKind::Vector(items) => T::collection(
            DisplayCollection::Vector,
            items,
            span.clone(),
            reader_metadata,
        ),
        DecodedKind::Map(items) => {
            T::collection(DisplayCollection::Map, items, span.clone(), reader_metadata)
        }
        DecodedKind::Set(items) => {
            T::collection(DisplayCollection::Set, items, span.clone(), reader_metadata)
        }
        DecodedKind::Queue(items) => {
            T::collection(DisplayCollection::Queue, items, span.clone(), reader_metadata)
        }
    })
}
fn sequence<T: DatumTarget>(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    span: &Range<usize>,
    depth: usize,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<T>> {
    let pushed = enter_active(
        store,
        value,
        budget,
        "Cyclic runtime sequence cannot be transported as macro data",
        true,
    )?;
    let result = stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || {
        sequence_inner(store, value, classes, span, depth, budget)
    });
    leave_active(budget, pushed);
    result
}
fn sequence_inner<T: DatumTarget>(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    span: &Range<usize>,
    depth: usize,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<T>> {
    let mut cursor = value.clone();
    let mut items = Vec::new();
    let mut counts = Vec::new();
    let mut cursor_roots = Vec::<Val>::new();
    let mut first_segment = true;
    loop {
        if absent(store, &cursor)? {
            break;
        }
        for prior in &cursor_roots {
            charge_read_work(store, 1, budget)?;
            if Rooted::ref_eq(&*store, reference(prior)?, reference(&cursor)?)? {
                return Err(error(
                    "Cyclic runtime sequence cannot be transported as macro data",
                ));
            }
        }
        cursor_roots.push(cursor.clone());
        spend(store, budget)?;
        if reference(&cursor)?.as_array(&*store)?.is_some() {
            for unit in text(store, &cursor, budget)? {
                spend(store, budget)?;
                items.push(T::plain(Form {
                    span: span.clone(),
                    metadata: vec![],
                    kind: Kind::String(vec![unit]),
                }));
            }
            break;
        }
        let (class, data) = object(store, &cursor, classes)?;
        match class {
            Class::LazySeq => {
                if data.len() != 4 {
                    return Err(error("Invalid lazy sequence field layout"));
                }
                if !first_segment {
                    metadata(store, &data[0], classes, span, depth, budget)?;
                }
                // Invoke source sval only for the captured canonical nominal type.
                // It preserves thunk retry/cache behavior; the host normalizes
                // its known sequence storage without mutable class-cell lookups.
                let calls = budget
                    .calls
                    .as_ref()
                    .ok_or_else(|| error("Lazy data needs fueled source realization"))?;
                let mut args = [Val::null_any_ref()];
                calls
                    .args_new
                    .call(&mut *store, &[Val::I32(1)], &mut args)?;
                args[0]
                    .unwrap_anyref()
                    .unwrap()
                    .as_array(&*store)?
                    .ok_or_else(|| error("Invalid invocation arguments"))?
                    .set(&mut *store, 0, cursor.clone())?;
                let mut result = [Val::null_any_ref()];
                budget.lazy_calls.set(budget.lazy_calls.get().saturating_add(1));
                // Observational reads never replace an invocation error. This
                // delta includes callback-triggered host charges, not just Wasm.
                let fuel_before = if budget.profile { store.get_fuel().ok() } else { None };
                if budget.profile {
                    eprintln!("macro-lazy-invoke call={} stage=before fuel={fuel_before:?}",
                        budget.lazy_calls.get());
                }
                let invoked = calls.invoke.call(
                    &mut *store,
                    &[calls.function.clone(), args[0].clone()],
                    &mut result,
                );
                if budget.profile {
                    let fuel_after = store.get_fuel().ok();
                    let delta = fuel_before.zip(fuel_after)
                        .and_then(|(before, after)| before.checked_sub(after));
                    eprintln!("macro-lazy-invoke call={} stage=after fuel={fuel_after:?} delta={delta:?} success={}",
                        budget.lazy_calls.get(), invoked.is_ok());
                }
                invoked?;
                cursor = result[0].clone();
            }
            Class::ChunkedCons => {
                if data.len() != 4 {
                    return Err(error("Invalid chunked cons field layout"));
                }
                if !first_segment {
                    metadata(store, &data[2], classes, span, depth, budget)?;
                }
                let (class, chunk) = object(store, &data[0], classes)?;
                if class != Class::ArrayChunk || chunk.len() != 3 {
                    return Err(error("Chunked cons needs canonical array chunk storage"));
                }
                let entries = source_elements(store, &chunk[0], classes, budget)?;
                let start = integer(store, &chunk[1])?;
                let end = integer(store, &chunk[2])?;
                if start >= end || end > entries.len() {
                    return Err(error("Invalid array chunk cursor"));
                }
                for entry in &entries[start..end] {
                    items.push(decode_datum(
                        store,
                        entry,
                        classes,
                        span,
                        depth + 1,
                        budget,
                    )?);
                }
                cursor = data[1].clone();
            }
            Class::PersistentVector => {
                if !first_segment && !data.is_empty() {
                    metadata(store, &data[0], classes, span, depth, budget)?;
                }
                items.extend(vector(store, &data, classes, span, depth, budget)?);
                break;
            }
            Class::EmptyList => {
                if data.len() != 1 {
                    return Err(error("Invalid empty list layout"));
                }
                if !first_segment {
                    metadata(store, &data[0], classes, span, depth, budget)?;
                }
                break;
            }
            Class::List | Class::Cons => {
                let count = if matches!(class, Class::List) { 5 } else { 4 };
                if data.len() != count {
                    return Err(error("Invalid sequence field layout"));
                }
                if !first_segment {
                    metadata(store, &data[0], classes, span, depth, budget)?;
                }
                if count == 5 {
                    let Some(count) = number(store, &data[3])? else {
                        return Err(error("Invalid list count"));
                    };
                    counts.push((items.len(), count));
                }
                items.push(decode_datum(
                    store,
                    &data[1],
                    classes,
                    span,
                    depth + 1,
                    budget,
                )?);
                cursor = data[2].clone();
            }
            Class::KeySeq => {
                if data.len() != 2 {
                    return Err(error("Invalid key sequence field layout"));
                }
                if !first_segment {
                    metadata(store, &data[1], classes, span, depth, budget)?;
                }
                for pair in map_sequence_pairs(store, &data[0], classes, 0, budget)?.chunks_exact(2)
                {
                    items.push(decode_datum(
                        store,
                        &pair[0],
                        classes,
                        span,
                        depth + 1,
                        budget,
                    )?);
                }
                break;
            }
            Class::NodeSeq | Class::ArrayNodeSeq => {
                if data.len() != 5 {
                    return Err(error("Invalid hash node sequence field layout"));
                }
                if !first_segment {
                    metadata(store, &data[0], classes, span, depth, budget)?;
                }
                let nodes = source_elements(store, &data[1], classes, budget)?;
                let index = integer(store, &data[2])?;
                let is_array = matches!(class, Class::ArrayNodeSeq);
                if index > nodes.len()
                    || (is_array && nodes.len() != 32)
                    || (!is_array && (nodes.len() % 2 != 0 || index % 2 != 0))
                {
                    return Err(error("Invalid bounded hash node sequence cursor"));
                }
                if !absent(store, &data[3])? {
                    let current = sequence(store, &data[3], classes, span, depth + 1, budget)?;
                    if current.is_empty() {
                        return Err(error("Hash node sequence retains an empty child cursor"));
                    }
                    items.extend(current);
                } else if is_array || index == nodes.len() || absent(store, &nodes[index])? {
                    return Err(error("Hash node sequence has no current entry"));
                }
                let mut pairs = Vec::new();
                if is_array {
                    for node in &nodes[index..] {
                        if !absent(store, node)? {
                            hash_node(store, node, classes, 0, budget, &mut pairs)?;
                        }
                    }
                } else {
                    for pair in nodes[index..].chunks_exact(2) {
                        if absent(store, &pair[0])? {
                            if !absent(store, &pair[1])? {
                                hash_node(store, &pair[1], classes, 0, budget, &mut pairs)?;
                            }
                        } else {
                            pairs.extend_from_slice(pair);
                        }
                    }
                }
                for pair in pairs.chunks_exact(2) {
                    spend(store, budget)?;
                    let pair = pair
                        .iter()
                        .map(|entry| decode_datum(store, entry, classes, span, depth + 2, budget))
                        .collect::<wasmtime::Result<Vec<_>>>()?;
                    items.push(T::collection(
                        DisplayCollection::Vector,
                        pair,
                        span.clone(),
                        vec![],
                    ));
                }
                break;
            }
            Class::PersistentArrayMapSeq => {
                if data.len() != 3 {
                    return Err(error("Invalid array map sequence field layout"));
                }
                if !first_segment {
                    metadata(store, &data[2], classes, span, depth, budget)?;
                }
                let index = integer(store, &data[1])?;
                let entries = source_elements(store, &data[0], classes, budget)?;
                if entries.len() % 2 != 0 || index % 2 != 0 || index >= entries.len() {
                    return Err(error("Invalid array map sequence pair storage"));
                }
                for pair in entries[index..].chunks_exact(2) {
                    spend(store, budget)?;
                    let pair = pair
                        .iter()
                        // The generated entry vector is one syntax level below
                        // this sequence; its key/value children are another.
                        .map(|entry| decode_datum(store, entry, classes, span, depth + 2, budget))
                        .collect::<wasmtime::Result<Vec<_>>>()?;
                    items.push(T::collection(
                        DisplayCollection::Vector,
                        pair,
                        span.clone(),
                        vec![],
                    ));
                }
                break;
            }
            Class::ChunkedSeq => {
                if data.len() != 6 {
                    return Err(error("Invalid chunked vector sequence layout"));
                }
                if !first_segment {
                    metadata(store, &data[4], classes, span, depth, budget)?;
                }
                let (owner, vector_data) = object(store, &data[0], classes)?;
                if !matches!(owner, Class::PersistentVector) || vector_data.len() != 6 {
                    return Err(error(
                        "Chunked vector sequence needs canonical vector storage",
                    ));
                }
                let count = integer(store, &vector_data[1])?;
                let mut index = integer(store, &data[2])?;
                let mut offset = integer(store, &data[3])?;
                let mut node = source_elements(store, &data[1], classes, budget)?;
                if index >= count || offset >= node.len() {
                    return Err(error("Invalid chunked vector sequence index"));
                }
                // Validate the backing vector even when the first node exhausts
                // the sequence; use the supplied node for its actual contents.
                vector_leaf(store, &vector_data, index, classes, budget)?;
                loop {
                    if node.is_empty() || node.len() > 32 || index + node.len() > count {
                        return Err(error("Invalid bounded chunked vector sequence node"));
                    }
                    for entry in &node[offset..] {
                        items.push(decode_datum(
                            store,
                            entry,
                            classes,
                            span,
                            depth + 1,
                            budget,
                        )?);
                    }
                    index += node.len();
                    if index == count {
                        break;
                    }
                    node = vector_leaf(store, &vector_data, index, classes, budget)?;
                    offset = 0;
                }
                break;
            }
            Class::IndexedSeq => {
                if !first_segment && data.len() == 3 {
                    metadata(store, &data[2], classes, span, depth, budget)?;
                }
                append_indexed(store, &data, classes, span, depth, budget, &mut items)?;
                break;
            }
            _ => return Err(error("Unsupported macro sequence tail")),
        }
        first_segment = false;
    }
    for (index, count) in counts {
        if count != (items.len() - index) as f64 {
            return Err(error("List count disagrees with sequence storage"));
        }
    }
    Ok(items)
}

fn append_indexed<T: DatumTarget>(
    store: &mut StoreContextMut<'_, ()>,
    data: &[Val],
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    span: &Range<usize>,
    depth: usize,
    budget: &mut Budget,
    items: &mut Vec<T>,
) -> wasmtime::Result<()> {
    if data.len() != 3 {
        return Err(error("Invalid IndexedSeq field layout"));
    }
    let Some(index) = number(store, &data[1])? else {
        return Err(error("Invalid IndexedSeq index"));
    };
    if !index.is_finite() || index < 0.0 || index.fract() != 0.0 {
        return Err(error("Invalid IndexedSeq index"));
    }
    // A packed primitive array: its storage and identity UID (#336).
    let fields = match reference(&data[0])?.as_struct(&*store)? {
        Some(packed) => packed.fields(&mut *store)?.collect::<Vec<_>>(),
        None => Vec::new(),
    };
    let packed = match fields.as_slice() {
        [Val::AnyRef(Some(storage)), _] => storage
            .as_array(&*store)?
            .filter(|storage| !matches!(storage.ty(&*store).map(|ty| ty.element_type()), Ok(wasmtime::StorageType::ValType(wasmtime::ValType::Ref(_))))),
        _ => None,
    };
    if let Some(storage) = packed {
        let element = storage.ty(&*store)?.element_type();
        let length = storage.len(&*store)?;
        if index > f64::from(length) {
            return Err(error("IndexedSeq index exceeds backing storage"));
        }
        let index = index as u32;
        charge_read_work(store, u64::from(length - index), budget)?;
        for offset in index..length {
            let value = storage.get(&mut *store, offset)?;
            spend(store, budget)?;
            let kind = match (&element, value) {
                (wasmtime::StorageType::I8, Val::I32(n)) => Kind::Long(i64::from(n as i8)),
                (wasmtime::StorageType::I16, Val::I32(n)) => Kind::Long(i64::from(n as i16)),
                (_, Val::I32(n)) => Kind::Long(i64::from(n)),
                (_, Val::I64(n)) => Kind::Long(n),
                (_, Val::F32(bits)) => Kind::Number(f64::from(f32::from_bits(bits))),
                (_, Val::F64(bits)) => Kind::Number(f64::from_bits(bits)),
                _ => return Err(error("Invalid packed array element")),
            };
            items.push(T::plain(Form {
                span: span.clone(),
                metadata: vec![],
                kind,
            }));
        }
        return Ok(());
    }
    if reference(&data[0])?.as_array(&*store)?.is_none() {
        if index > f64::from(u32::MAX) {
            return Err(error("IndexedSeq index exceeds source array storage"));
        }
        let values = match object_array_elements(store, &data[0], budget)? {
            Some(elements) if index <= elements.len() as f64 => elements[index as usize..].to_vec(),
            Some(_) => return Err(error("IndexedSeq index exceeds backing storage")),
            None => return Err(error("IndexedSeq needs an object array")),
        };
        for value in values {
            items.push(decode_datum(
                store,
                &value,
                classes,
                span,
                depth + 1,
                budget,
            )?);
        }
        return Ok(());
    }
    let backing = reference(&data[0])?.as_array(&*store)?.unwrap();
    if !matches!(
        backing.ty(&*store)?.element_type(),
        wasmtime::StorageType::I16
    ) {
        return Err(error("IndexedSeq string needs UTF16 storage"));
    }
    let length = backing.len(&*store)?;
    if index > f64::from(length) {
        return Err(error("IndexedSeq index exceeds backing storage"));
    }
    let index = index as u32;
    charge_read_work(store, u64::from(length - index), budget)?;
    for offset in index..length {
        let value = backing.get(&mut *store, offset)?;
        spend(store, budget)?;
        let Val::I32(unit) = value else {
            return Err(error("Invalid UTF16 indexed unit"));
        };
        items.push(T::plain(Form {
            span: span.clone(),
            metadata: vec![],
            kind: Kind::String(vec![unit as u16]),
        }));
    }
    Ok(())
}

fn integer(store: &mut StoreContextMut<'_, ()>, value: &Val) -> wasmtime::Result<usize> {
    let Some(n) = number(store, value)? else {
        return Err(error("Invalid vector integer field"));
    };
    if !n.is_finite() || n < 0.0 || n.fract() != 0.0 || n > f64::from(u32::MAX) {
        return Err(error("Vector integer field exceeds ABI range"));
    }
    Ok(n as usize)
}
fn source_elements(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<Val>> {
    if let Some(elements) = object_array_elements(store, value, budget)? {
        return Ok(elements);
    }
    let _ = classes;
    Err(error("Expected an object array"))
}

/// The elements of an object array (#378): a packed array, `{storage, uid}`,
/// whose storage is an array of references. None for any other value.
fn object_array_elements(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    budget: &mut Budget,
) -> wasmtime::Result<Option<Vec<Val>>> {
    let Some(object) = value.anyref().flatten().map(|value| value.as_struct(&*store)).transpose()?.flatten() else {
        return Ok(None);
    };
    if object.ty(&*store)?.fields().len() != 2 {
        return Ok(None);
    }
    let storage = object.field(&mut *store, 0)?;
    let Some(storage) = storage.anyref().flatten().map(|value| value.as_array(&*store)).transpose()?.flatten() else {
        return Ok(None);
    };
    if !matches!(
        storage.ty(&*store)?.element_type(),
        wasmtime::StorageType::ValType(wasmtime::ValType::Ref(_))
    ) {
        return Ok(None);
    }
    let length = storage.len(&*store)?;
    charge_read_work(store, u64::from(length), budget)?;
    Ok(Some(storage.elems(&mut *store)?.collect()))
}

// Read the current sparse source-array ABI directly. Never execute guest code or
// invent nil for an absent index; undefined remains invalid macro syntax.

fn node_elements(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<Val>> {
    spend(store, budget)?;
    let (class, data) = object(store, value, classes)?;
    if !matches!(class, Class::VectorNode) || data.len() != 2 {
        return Err(error("Invalid persistent vector trie node"));
    }
    let items = source_elements(store, &data[1], classes, budget)?;
    if items.len() != 32 {
        return Err(error("Invalid vector trie array width"));
    }
    Ok(items)
}
fn vector<T: DatumTarget>(
    store: &mut StoreContextMut<'_, ()>,
    data: &[Val],
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    span: &Range<usize>,
    depth: usize,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<T>> {
    if data.len() != 6 {
        return Err(error("Invalid persistent vector layout"));
    }
    let count = integer(store, &data[1])?;
    let shift = integer(store, &data[2])?;
    if shift < 5 || shift > 30 || shift % 5 != 0 {
        return Err(error("Invalid vector trie shift"));
    }
    let tail = source_elements(store, &data[4], classes, budget)?;
    let offset = if count < 32 {
        0
    } else {
        ((count - 1) >> 5) << 5
    };
    if tail.len() != count - offset {
        return Err(error("Vector count disagrees with tail storage"));
    }
    // persistent! clears only the root edit token. Descendant nodes may retain
    // their former token; the pinned persistent trie legitimately shares them.
    let (_, root_data) = object(store, &data[3], classes)?;
    if root_data.len() != 2 || !nil(store, &root_data[0])? {
        return Err(error("Persistent vector root retains an active edit token"));
    }
    let root = node_elements(store, &data[3], classes, budget)?;
    let mut items = Vec::new();
    for base in (0..offset).step_by(32) {
        let mut node = root.clone();
        let mut level = shift;
        while level > 0 {
            node = node_elements(store, &node[(base >> level) & 31], classes, budget)?;
            level -= 5;
        }
        for value in node {
            items.push(decode_datum(
                store,
                &value,
                classes,
                span,
                depth + 1,
                budget,
            )?);
        }
    }
    for value in tail {
        items.push(decode_datum(
            store,
            &value,
            classes,
            span,
            depth + 1,
            budget,
        )?);
    }
    Ok(items)
}

// Read the same canonical trie/tail storage used by unchecked-array-for. This
// adapter decodes syntax; it never invokes arbitrary user collection protocols.
fn vector_leaf(
    store: &mut StoreContextMut<'_, ()>,
    data: &[Val],
    index: usize,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<Val>> {
    let count = integer(store, &data[1])?;
    let shift = integer(store, &data[2])?;
    if shift < 5 || shift > 30 || shift % 5 != 0 || index >= count {
        return Err(error("Invalid chunked vector trie range"));
    }
    let tail_offset = if count < 32 {
        0
    } else {
        ((count - 1) >> 5) << 5
    };
    let (_, root_data) = object(store, &data[3], classes)?;
    if root_data.len() != 2 || !nil(store, &root_data[0])? {
        return Err(error("Persistent vector root retains an active edit token"));
    }
    let mut node = node_elements(store, &data[3], classes, budget)?;
    if index >= tail_offset {
        let tail = source_elements(store, &data[4], classes, budget)?;
        if tail.len() != count - tail_offset {
            return Err(error("Vector count disagrees with tail storage"));
        }
        return Ok(tail);
    }
    let mut level = shift;
    while level > 0 {
        node = node_elements(store, &node[(index >> level) & 31], classes, budget)?;
        level -= 5;
    }
    Ok(node)
}

// Traverse the pinned inode ordering directly, without invoking user protocols.
// Canonical descriptors, logical counts, bounded depth and the shared budget
// guard this transport even when source code mutates a node's physical fields.
fn hash_map<T: DatumTarget>(
    store: &mut StoreContextMut<'_, ()>,
    data: &[Val],
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    span: &Range<usize>,
    depth: usize,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<T>> {
    if data.len() != 6 {
        return Err(error("Invalid persistent hash map field layout"));
    }
    hash_map_pairs(store, data, classes, budget)?
        .iter()
        .map(|entry| decode_datum(store, entry, classes, span, depth + 1, budget))
        .collect()
}
fn hash_map_pairs(
    store: &mut StoreContextMut<'_, ()>,
    data: &[Val],
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<Val>> {
    if data.len() != 6 {
        return Err(error("Invalid persistent hash map field layout"));
    }
    let count = integer(store, &data[1])?;
    let has_nil = match sentinel(store, &data[3])? {
        Some(2) => false,
        Some(4) => true,
        _ => return Err(error("Invalid hash map nil-key flag")),
    };
    let mut pairs = Vec::new();
    if has_nil {
        pairs.push(Val::AnyRef(None));
        pairs.push(data[4].clone());
    }
    if !nil(store, &data[2])? {
        hash_node(store, &data[2], classes, 0, budget, &mut pairs)?;
    }
    if count.checked_mul(2) != Some(pairs.len()) {
        return Err(error("Hash map count disagrees with trie storage"));
    }
    Ok(pairs)
}
// Canonical map cursors expose keys without interpreting discarded values or
// counting their private entry vectors as source nesting. Cursor traversal uses
// the shared operation budget, growable stacks and cycle/layout checks.
fn map_sequence_pairs(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    cursor_depth: usize,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<Val>> {
    let pushed = enter_active(
        store,
        value,
        budget,
        "Cyclic map key cursor cannot be transported as macro data",
        false,
    )?;
    let result = stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || {
        map_sequence_pairs_inner(store, value, classes, cursor_depth, budget)
    });
    leave_active(budget, pushed);
    result
}
fn map_sequence_pairs_inner(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    cursor_depth: usize,
    budget: &mut Budget,
) -> wasmtime::Result<Vec<Val>> {
    if nil(store, value)? {
        return Ok(Vec::new());
    }
    spend(store, budget)?;
    let (class, data) = object(store, value, classes)?;
    let mut pairs = Vec::new();
    match class {
        Class::PersistentArrayMapSeq => {
            if data.len() != 3 {
                return Err(error("Invalid array map key cursor layout"));
            }
            let index = integer(store, &data[1])?;
            let entries = source_elements(store, &data[0], classes, budget)?;
            if entries.len() % 2 != 0 || index % 2 != 0 || index >= entries.len() {
                return Err(error("Invalid array map key cursor range"));
            }
            pairs.extend_from_slice(&entries[index..]);
        }
        Class::NodeSeq | Class::ArrayNodeSeq => {
            if data.len() != 5 {
                return Err(error("Invalid hash key cursor layout"));
            }
            let nodes = source_elements(store, &data[1], classes, budget)?;
            let index = integer(store, &data[2])?;
            let is_array = matches!(class, Class::ArrayNodeSeq);
            if index > nodes.len()
                || (is_array && nodes.len() != 32)
                || (!is_array && (nodes.len() % 2 != 0 || index % 2 != 0))
            {
                return Err(error("Invalid hash key cursor range"));
            }
            if !absent(store, &data[3])? {
                let current =
                    map_sequence_pairs(store, &data[3], classes, cursor_depth + 1, budget)?;
                if current.is_empty() {
                    return Err(error("Hash key cursor retains an empty child"));
                }
                pairs.extend(current);
            } else if is_array || index == nodes.len() || absent(store, &nodes[index])? {
                return Err(error("Hash key cursor has no current entry"));
            }
            if is_array {
                for node in &nodes[index..] {
                    if !absent(store, node)? {
                        hash_node(store, node, classes, 0, budget, &mut pairs)?;
                    }
                }
            } else {
                for pair in nodes[index..].chunks_exact(2) {
                    if absent(store, &pair[0])? {
                        if !absent(store, &pair[1])? {
                            hash_node(store, &pair[1], classes, 0, budget, &mut pairs)?;
                        }
                    } else {
                        pairs.extend_from_slice(pair);
                    }
                }
            }
        }
        Class::List | Class::Cons => {
            let expected = if matches!(class, Class::List) { 5 } else { 4 };
            if data.len() != expected {
                return Err(error("Invalid key cursor list layout"));
            }
            let (entry_class, entry) = object(store, &data[1], classes)?;
            if !matches!(entry_class, Class::MapEntry) || entry.len() != 3 {
                return Err(error("Key cursor list needs canonical map entries"));
            }
            pairs.extend_from_slice(&entry[..2]);
            pairs.extend(map_sequence_pairs(
                store,
                &data[2],
                classes,
                cursor_depth + 1,
                budget,
            )?);
        }
        Class::EmptyList => {
            if data.len() != 1 {
                return Err(error("Invalid empty key cursor layout"));
            }
        }
        _ => return Err(error("Key sequence needs a canonical map cursor")),
    }
    Ok(pairs)
}
fn bitmap(store: &mut StoreContextMut<'_, ()>, value: &Val) -> wasmtime::Result<u32> {
    let Some(n) = number(store, value)? else {
        return Err(error("Invalid hash trie bitmap"));
    };
    if !n.is_finite() || n.fract() != 0.0 || n < i32::MIN as f64 || n > i32::MAX as f64 {
        return Err(error("Invalid signed hash trie bitmap"));
    }
    Ok(n as i32 as u32)
}
fn hash_node(
    store: &mut StoreContextMut<'_, ()>,
    value: &Val,
    classes: &BTreeMap<i64, (Class, SessionValue)>,
    level: usize,
    budget: &mut Budget,
    pairs: &mut Vec<Val>,
) -> wasmtime::Result<()> {
    if level > 7 {
        return Err(error("Hash trie depth exceeds 32-bit hash path"));
    }
    spend(store, budget)?;
    let (class, data) = object(store, value, classes)?;
    match class {
        Class::BitmapIndexedNode => {
            if data.len() != 3 {
                return Err(error("Invalid bitmap node field layout"));
            }
            let count = bitmap(store, &data[1])?.count_ones() as usize;
            let entries = source_elements(store, &data[2], classes, budget)?;
            let Some(occupied_len) = count.checked_mul(2) else {
                return Err(error("Bitmap population overflows pair storage"));
            };
            if entries.len() < occupied_len || entries.len() % 2 != 0 {
                return Err(error("Bitmap population exceeds pair storage"));
            }
            for pair in entries[..occupied_len].chunks_exact(2) {
                if absent(store, &pair[0])? {
                    hash_node(store, &pair[1], classes, level + 1, budget, pairs)?;
                } else {
                    pairs.extend_from_slice(pair);
                }
            }
        }
        Class::ArrayNode => {
            if data.len() != 3 {
                return Err(error("Invalid array node field layout"));
            }
            let count = integer(store, &data[1])?;
            let entries = source_elements(store, &data[2], classes, budget)?;
            if entries.len() != 32 {
                return Err(error("Invalid hash array node width"));
            }
            let mut occupied = 0;
            for entry in entries {
                if !absent(store, &entry)? {
                    occupied += 1;
                    hash_node(store, &entry, classes, level + 1, budget, pairs)?;
                }
            }
            if occupied != count {
                return Err(error("Array node count disagrees with storage"));
            }
        }
        Class::HashCollisionNode => {
            if data.len() != 4 {
                return Err(error("Invalid collision node field layout"));
            }
            bitmap(store, &data[1])?;
            let count = integer(store, &data[2])?;
            let entries = source_elements(store, &data[3], classes, budget)?;
            let Some(occupied_len) = count.checked_mul(2) else {
                return Err(error("Collision count overflows pair storage"));
            };
            if count == 0 || entries.len() < occupied_len || entries.len() % 2 != 0 {
                return Err(error("Collision count exceeds pair storage"));
            }
            for pair in entries[..occupied_len].chunks_exact(2) {
                if absent(store, &pair[0])? {
                    return Err(error("Nil key in hash collision node"));
                }
                pairs.extend_from_slice(pair);
            }
        }
        _ => return Err(error("Hash map needs canonical trie nodes")),
    }
    Ok(())
}
