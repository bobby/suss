//! Phase-specific namespace identities. No runtime values or source replay live here.
use super::{
    Diagnostic,
    hir::{Arithmetic, ArrayOperation, Bitwise, Comparison},
};
use std::{
    collections::{BTreeMap, BTreeSet},
    ops::Range,
    path::{Path, PathBuf},
};
use super::persistent::{PersistentMap, PersistentSet};
use suss_reader::Symbol;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Phase {
    Runtime,
    Macro,
}

/// A stable language identity; Wasm import indices are deliberately absent.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub struct Global {
    phase: Phase,
    // Shared, since snapshots of a namespace copy every global in it (#319).
    namespace: std::sync::Arc<str>,
    name: std::sync::Arc<str>,
}
impl Global {
    pub(crate) fn native_constant(phase: Phase, owner: u64, index: u64) -> Self {
        Self { phase, namespace: "suss.internal.eval-constants".into(),
            name: format!("{owner:016x}-{index:016x}").into() }
    }
    pub(crate) fn native_value(phase: Phase, owner: u64, index: u64) -> Self {
        Self { phase, namespace: "suss.internal.eval-values".into(), name: format!("{owner:016x}-{index:016x}").into() }
    }
    pub(crate) fn native_function_site(phase: Phase, owner: u64, index: u64, pool: u64) -> Self {
        Self { phase, namespace: "suss.internal.eval-function-sites".into(), name: format!("{owner:016x}-{index:016x}-{pool:016x}").into() }
    }
    pub(crate) fn native_site_initializer(&self) -> Self {
        Self { phase: self.phase, namespace: "suss.internal.eval-function-initializers".into(), name: self.name.clone() }
    }
    pub(crate) fn native_site_import(phase: Phase, name: &str) -> Option<(Self, Self)> {
        let name = name.strip_prefix("suss.internal.eval-function-sites/")
            .or_else(|| name.strip_prefix("suss.internal.eval-function-initializers/"))?;
        let parts = name.split('-').collect::<Vec<_>>();
        if parts.len()!=3 || parts.iter().any(|part| part.len()!=16) { return None; }
        let owner=u64::from_str_radix(parts[0],16).ok()?;
        let index=u64::from_str_radix(parts[1],16).ok()?;
        let pool=u64::from_str_radix(parts[2],16).ok()?;
        Some((Self::native_function_site(phase,owner,index,pool), Self::native_constant(phase,owner,index)))
    }
    /// The `suss.core` var a core link cell stands for (#360).
    pub(crate) fn core_var_of_link(&self) -> Option<Global> {
        (&*self.namespace == "suss.internal.core-link").then(|| Global {
            phase: self.phase,
            namespace: "suss.core".into(),
            name: self.name.clone(),
        })
    }
    pub fn phase(&self) -> Phase {
        self.phase
    }
    pub fn namespace(&self) -> &str {
        &self.namespace
    }
    pub fn name(&self) -> &str {
        &self.name
    }
    pub fn import_module(&self) -> &'static str {
        match self.phase {
            Phase::Runtime => "suss.bindings.runtime",
            Phase::Macro => "suss.bindings.macro",
        }
    }
    pub fn import_name(&self) -> String {
        format!("{}/{}", self.namespace, self.name)
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NominalForm {
    Deftype,
    DeftypeInternal,
    DefrecordInternal,
    Defprotocol,
    ExtendType,
    Instance,
    Satisfies,
    Implements,
    Reify,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ControlForm {
    When,
    WhenNot,
    IfNot,
    IfLet,
    And,
    Or,
    Cond,
    Case,
    Declare,
    CachingHash,
    ThreadFirst,
    AsThread,
    Zero,
    Positive,
    Negative,
    Increment,
    Decrement,
    UncheckedGet,
    UncheckedSet,
}
impl ControlForm {
    fn from_name(name: &str) -> Option<Self> {
        Some(match name {
            "when" => Self::When,
            "when-not" => Self::WhenNot,
            "if-not" => Self::IfNot,
            "if-let" => Self::IfLet,
            "and" => Self::And,
            "or" => Self::Or,
            "cond" => Self::Cond,
            "case" => Self::Case,
            "declare" => Self::Declare,
            "caching-hash" => Self::CachingHash,
            "->" => Self::ThreadFirst,
            "as->" => Self::AsThread,
            "zero?" => Self::Zero,
            "pos?" => Self::Positive,
            "neg?" => Self::Negative,
            "inc" => Self::Increment,
            "dec" => Self::Decrement,
            "unchecked-get" => Self::UncheckedGet,
            "unchecked-set" => Self::UncheckedSet,
            _ => return None,
        })
    }
}
#[derive(Debug, Clone)]
pub(crate) struct ProtocolMethod {
    pub name: String,
    pub signatures: Vec<(usize, usize)>, // argument arity, bundle key index
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Binding {
    NumericClass { global: Global, kind: u8 },
    BootstrapBitwise {
        global: Global,
        operation: Bitwise,
    },
    BootstrapControl {
        global: Global,
        operation: ControlForm,
    },
    BootstrapComparison {
        global: Global,
        operation: Comparison,
    },
    BootstrapArray {
        global: Global,
        operation: ArrayOperation,
    },
    Core {
        global: Global,
        export: &'static str,
    },
    Cell(Global),
    InternalCell(Global),
    /// Unbound reader reservation sharing a future public definition identity.
    ReaderCell(Global),
    Arithmetic {
        global: Global,
        operator: Arithmetic,
    },
    BootstrapLet(Global),
    BootstrapLoop(Global),
    BootstrapFn(Global),
    BootstrapDefonce(Global),
    BootstrapBinding(Global),
    Nominal {
        global: Global,
        form: NominalForm,
    },
}
impl Binding {
    pub fn global(&self) -> &Global {
        match self {
            Self::NumericClass { global: g, .. }
            | Self::BootstrapBitwise { global: g, .. }
            | Self::BootstrapControl { global: g, .. }
            | Self::BootstrapComparison { global: g, .. }
            | Self::BootstrapArray { global: g, .. }
            | Self::Core { global: g, .. }
            | Self::Cell(g)
            | Self::InternalCell(g)
            | Self::ReaderCell(g)
            | Self::BootstrapLoop(g)
            | Self::BootstrapLet(g)
            | Self::BootstrapFn(g)
            | Self::BootstrapDefonce(g)
            | Self::BootstrapBinding(g)
            | Self::Arithmetic { global: g, .. }
            | Self::Nominal { global: g, .. } => g,
        }
    }
}
#[derive(Debug, Clone)]
struct Scope {
    namespace: String,
    aliases: BTreeMap<String, String>,
    refers: BTreeMap<String, Global>,
    used_refers: BTreeSet<String>,
    renamed_refers: BTreeSet<String>,
    excluded_core: BTreeSet<String>,
    macro_aliases: BTreeMap<String, String>,
    macro_refers: BTreeMap<String, (String, String)>,
    used_macro_refers: BTreeSet<String>,
    renamed_macro_refers: BTreeSet<String>,
}
impl Scope {
    fn new(namespace: &str) -> Self {
        Self {
            namespace: namespace.into(),
            aliases: BTreeMap::new(),
            refers: BTreeMap::new(),
            used_refers: BTreeSet::new(),
            renamed_refers: BTreeSet::new(),
            excluded_core: BTreeSet::new(),
            macro_aliases: BTreeMap::new(),
            macro_refers: BTreeMap::new(),
            used_macro_refers: BTreeSet::new(),
            renamed_macro_refers: BTreeSet::new(),
        }
    }
}
/// Compiler declaration facts, distinct from initialized runtime cell metadata.
#[derive(Debug, Clone)]
pub struct DefinitionInfo {
    /// Actual definition syntax, retained before initializer analysis.
    pub definition_form: suss_reader::forms::Form,
    /// Analysis completion is distinct from presence or runtime evaluation of an initializer.
    pub analysis_completed: bool,
    pub declaration: suss_reader::forms::Form,
    pub docstring: Option<Vec<u16>>,
    pub origin: Option<super::SourceOrigin>,
    /// Actual initializer syntax, available before its body is analyzed.
    pub initializer_form: Option<suss_reader::forms::Form>,
    pub initializer: Option<std::sync::Arc<super::hir::Hir>>,
    /// Genuine deftype declaration facts, captured before method analysis.
    /// None is an ordinary def, not a zero-field source type.
    pub type_fields: Option<usize>,
    /// The intrinsic declaration kind, independent of user metadata overrides.
    pub type_is_record: bool,
    pub once: bool,
    /// Compiler-private cell retaining this initialized scalar constant revision.
    pub constant: Option<Global>,
}
impl DefinitionInfo {
    /// Normalized def-AST export name for target selection, distinct from the raw
    /// :export metadata in namespace declaration records. The pinned def rule keeps
    /// false/nil absent, maps true to the qualified var, and retains other values.
    /// Reference: cljs/analyzer.cljc def export-as at c4295f303100bbf5afac449242d30bca1126f1a1.
    pub fn export_as(
        &self,
        global: &Global,
    ) -> Result<Option<suss_reader::forms::Form>, Diagnostic> {
        use suss_reader::forms::{Form, Kind};
        let pairs = super::hir::reader_metadata_pairs(&self.declaration)?;
        let Some(value) = pairs.chunks_exact(2).find_map(|pair| {
            matches!(&pair[0].kind, Kind::Keyword(key)
                if key.namespace.is_none() && key.name == "export")
            .then(|| pair[1].clone())
        }) else {
            return Ok(None);
        };
        Ok(match value.kind {
            Kind::Nil | Kind::Bool(false) => None,
            Kind::Bool(true) => Some(Form {
                span: value.span.clone(),
                metadata: vec![],
                kind: Kind::Symbol(Symbol {
                    namespace: Some(if global.namespace() == "suss.core" {
                        "cljs.core".to_owned()
                    } else {
                        global.namespace().to_owned()
                    }),
                    name: global.name().to_owned(),
                }),
            }),
            _ => Some(value),
        })
    }
}

/// Declaration revisions at one top-level form boundary. Per-namespace maps
/// share their immutable nodes, so nested provisional declarations cannot
/// change what a constant read sees while the enclosing form is compiled.
#[derive(Clone, Default)]
pub(crate) struct DeclarationSnapshot(
    BTreeMap<(Phase, std::sync::Arc<str>), PersistentMap<Global, std::sync::Arc<DefinitionInfo>>>,
);
impl DeclarationSnapshot {
    pub(crate) fn get(&self, global: &Global) -> Option<&std::sync::Arc<DefinitionInfo>> {
        self.0.get(&(global.phase, global.namespace.clone()))?.get(global)
    }
}

/// Borrowed phase-specific source scope. Catalog entries do not certify loading.
pub struct NamespaceScope<'a> {
    pub namespace: &'a str,
    pub aliases: &'a BTreeMap<String, String>,
    pub refers: &'a BTreeMap<String, Global>,
    pub used_refers: &'a BTreeSet<String>,
    pub renamed_refers: &'a BTreeSet<String>,
    pub excluded_core: &'a BTreeSet<String>,
    pub macro_aliases: &'a BTreeMap<String, String>,
    pub macro_refers: &'a BTreeMap<String, (String, String)>,
    pub used_macro_refers: &'a BTreeSet<String>,
    pub renamed_macro_refers: &'a BTreeSet<String>,
    pub declarations: Vec<(&'a Global, &'a DefinitionInfo)>,
}
/// Explicit input to analysis, shared by future AOT, REPL and macro-session callers.
/// Configuration is checked before mutation. Source analysis borrows it immutably.
#[derive(Debug, Clone)]
pub struct Environment {
    pub(crate) reader_state: super::syntax_quote::ReaderState,
    namespaces: BTreeSet<(Phase, String)>,
    bindings: BTreeMap<Global, Binding>,
    /// Per namespace, persistent so a snapshot shares it (#319).
    definitions: BTreeMap<(Phase, std::sync::Arc<str>), PersistentMap<Global, std::sync::Arc<DefinitionInfo>>>,
    source_generation: u64,
    scopes: BTreeMap<(Phase, String), Scope>,
    current: BTreeMap<Phase, String>,
    materialized_bootstrap: BTreeSet<Global>,
    /// Per namespace, the cells other code can see: `Cell` bindings, and
    /// materialized bootstrap cells other than reader and internal cells.
    /// `bind`, `unbind` and `materialize_bootstrap` keep it (#319).
    identities: BTreeMap<(Phase, std::sync::Arc<str>), PersistentSet<Global>>,
    macro_exports: BTreeSet<(Phase, String, String)>,
    // The ordinary declaration revision present at an explicit defmacro. A
    // later ordinary def hides that transformer; namespace imports do not
    // silently turn it back into a macro. Persistent snapshots share revisions.
    macro_declarations: PersistentMap<Global, Option<std::sync::Arc<DefinitionInfo>>>,
    // Actual Var metadata for one native eval analysis only. Never publish this
    // live observation as declaration history or source-analysis authority.
    native_macro_status: BTreeMap<Global, bool>,
    macro_namespaces: BTreeSet<(Phase, String)>,
    pub(crate) protocols: BTreeMap<Global, Vec<ProtocolMethod>>,
    /// Protocols whose current definition is shipped core's (#279).
    pub(crate) core_protocols: BTreeSet<Global>,
    /// Direct linking of user code (#360): set for AOT builds, off for the
    /// REPL and source sessions, whose calls read live cells.
    pub(crate) direct_linking: bool,
    /// AOT initializes every prepared Runtime fragment in order, aborting on
    /// failure. A later fragment can rely on an earlier namespace publication.
    /// Sessions leave this off: preparation does not imply execution there.
    /// This policy is transient; published catalogs clear it and AOT artifacts
    /// carry their own sealed load-scope requirement.
    pub(crate) ordered_namespace_initialization: bool,
    /// Only the root native eval form inherits its caller's dynamic namespace
    /// frame. Dependencies keep ordinary load frames; published catalogs clear it.
    pub(crate) native_evaluation_namespace: bool,
    /// Analyzing the shipped core image itself, whose capture-free functions
    /// call each other directly (#360, #361). Only the bootstrap catalog sets
    /// it: privileged code compiled elsewhere, such as a session's core
    /// fragments or the analyzer's record of core, links nothing.
    pub(crate) core_image_links: bool,
    /// Each direct-linked var's current definition (#360). A call compiled
    /// while it holds calls that definition's entry, as Clojure's
    /// direct-linked call sites call the function compiled at the time.
    pub(crate) direct_links: BTreeMap<Global, (usize, usize)>,
    /// Each direct-linked var's slot (#360): the id of its first linked
    /// definition, whose fragment owns the global every later linked
    /// definition writes its closure to.
    direct_slots: BTreeMap<Global, usize>,
    direct_link_count: usize,
    /// Each keyword cell's number (#387): a fragment caches the interned
    /// keyword its literals read in one global per number.
    keyword_caches: BTreeMap<Global, usize>,
    /// A WIT export's numeric parameters (#385), by its var's namespace and
    /// name: per parameter, Some(true) for an integer, Some(false) for a
    /// float. Its single-arity fn treats them as `^long` and `^double`.
    export_param_hints: BTreeMap<(String, String), Vec<Option<bool>>>,
}
/// Namespace of a qualified symbol, as the pinned analyzer's resolve-var and
/// resolve-macro-var resolve it: `clojure.core` names `cljs.core` (`suss.core`)
/// before any alias is consulted; otherwise an alias wins. Namespace
/// declarations themselves keep their own names.
fn symbol_namespace<'a>(alias: Option<&'a String>, namespace: &'a str) -> &'a str {
    if namespace == "clojure.core" {
        return "suss.core";
    }
    alias.map_or_else(|| canonical(namespace), |alias| canonical(alias))
}
/// The namespace a require of `namespace` names: requiring clojure.core names
/// core, which is always loaded, as in Clojure; ClojureScript also resolves it
/// to cljs.core (#30). Other spellings, including cljs.core, are unchanged.
pub(crate) fn required(namespace: &str) -> &str {
    if namespace == "clojure.core" { "cljs.core" } else { namespace }
}
pub(crate) fn canonical(namespace: &str) -> &str {
    if namespace == "cljs.core" {
        "suss.core"
    } else {
        namespace
    }
}
fn error(message: impl Into<String>) -> Diagnostic {
    Diagnostic {
        span: 0..0,
        message: message.into(),
    }
}
pub(crate) fn valid_namespace(namespace: &str) -> Result<(), Diagnostic> {
    if namespace == "suss.bootstrap" {
        return Err(error("Compiler bootstrap namespace is reserved"));
    }
    if namespace.is_empty()
        || namespace.split('.').any(|part| {
            part.is_empty()
                || part
                    .chars()
                    .any(|c| !c.is_alphanumeric() && c != '-' && c != '_')
        })
    {
        return Err(error("Invalid namespace name"));
    }
    Ok(())
}
fn valid_name(name: &str) -> Result<(), Diagnostic> {
    use suss_reader::forms::{Kind, read_forms};
    match read_forms(name).ok().as_deref() {
        Some([form])
            if form.metadata.is_empty()
                && matches!(&form.kind, Kind::Symbol(symbol) if symbol.namespace.is_none() && symbol.name == name) =>
        {
            Ok(())
        }
        _ => Err(error("Binding name must be an unqualified symbol")),
    }
}
impl Default for Environment {
    fn default() -> Self {
        Self::new("user").expect("valid bootstrap namespace")
    }
}
/// Core macros the bootstrap expander provides before core source loads.
pub(crate) const BOOTSTRAP_MACROS: &[&str] = &[
    "let",
    "letfn",
    "loop",
    "fn",
    "defonce",
    "binding",
    "with-redefs",
    "deftype",
    "deftype*",
    "defrecord*",
    "defprotocol",
    "extend-type",
    "instance?",
    "satisfies?",
    "implements?",
    "array",
    "make-array",
    "alength",
    "aget",
    "aset",
    "<",
    "<=",
    ">",
    ">=",
    "==",
    "when",
    "when-not",
    "if-not",
    "if-let",
    "and",
    "or",
    "cond",
    "case",
    "declare",
    "caching-hash",
    "->",
    "as->",
    "zero?",
    "pos?",
    "neg?",
    "inc",
    "dec",
    "int",
    "bit-and",
    "bit-or",
    "bit-xor",
    "bit-and-not",
    "bit-not",
    "bit-clear",
    "bit-flip",
    "bit-set",
    "bit-test",
    "bit-shift-left",
    "bit-shift-right",
    "unsigned-bit-shift-right",
    "bit-shift-right-zero-fill",
    // Shipped core's private 32-bit multiply; not public (#336).
    "imul",
];
impl Environment {
    pub fn new(namespace: &str) -> Result<Self, Diagnostic> {
        valid_namespace(namespace)?;
        let mut env = Self {
            reader_state: super::syntax_quote::ReaderState::default(),
            namespaces: BTreeSet::new(),
            bindings: BTreeMap::new(),
            definitions: BTreeMap::new(),
            source_generation: 0,
            scopes: BTreeMap::new(),
            current: BTreeMap::new(),
            materialized_bootstrap: BTreeSet::new(),
            identities: BTreeMap::new(),
            macro_exports: BTreeSet::new(),
            macro_declarations: PersistentMap::default(),
            native_macro_status: BTreeMap::new(),
            macro_namespaces: BTreeSet::new(),
            protocols: BTreeMap::new(),
            core_protocols: BTreeSet::new(),
            direct_linking: false,
            ordered_namespace_initialization: false,
            native_evaluation_namespace: false,
            core_image_links: false,
            direct_links: BTreeMap::new(),
            direct_slots: BTreeMap::new(),
            direct_link_count: 0,
            keyword_caches: BTreeMap::new(),
            export_param_hints: BTreeMap::new(),
        };
        for phase in [Phase::Runtime, Phase::Macro] {
            env.scopes.insert(
                (phase, canonical(namespace).into()),
                Scope::new(canonical(namespace)),
            );
            env.current.insert(phase, canonical(namespace).into());
            env.namespaces.insert((phase, canonical(namespace).into()));
            env.namespaces.insert((phase, "suss.core".into()));
            for (name, operator) in [
                ("+", Arithmetic::Add),
                ("-", Arithmetic::Subtract),
                ("*", Arithmetic::Multiply),
                ("/", Arithmetic::Divide),
            ] {
                let global = Global {
                    phase,
                    namespace: "suss.core".into(),
                    name: name.into(),
                };
                env.bind(global.clone(), Binding::Arithmetic { global, operator });
            }
            for (name, export) in [
                ("int", "primitive-int-function"),
                ("bit-and", "primitive-bit-and-function"),
                ("bit-or", "primitive-bit-or-function"),
                ("bit-xor", "primitive-bit-xor-function"),
                ("bit-and-not", "primitive-bit-and-not-function"),
                ("bit-not", "primitive-bit-not-function"),
                ("bit-clear", "primitive-bit-clear-function"),
                ("bit-flip", "primitive-bit-flip-function"),
                ("bit-set", "primitive-bit-set-function"),
                ("bit-test", "primitive-bit-test-function"),
                ("bit-shift-left", "primitive-bit-shift-left-function"),
                ("bit-shift-right", "primitive-bit-shift-right-function"),
                (
                    "unsigned-bit-shift-right",
                    "primitive-unsigned-bit-shift-right-function",
                ),
                (
                    "bit-shift-right-zero-fill",
                    "primitive-unsigned-bit-shift-right-function",
                ),
                ("<", "comparison-less-function"),
                ("<=", "comparison-less-equal-function"),
                (">", "comparison-greater-function"),
                (">=", "comparison-greater-equal-function"),
                ("==", "comparison-strict-equal-function"),
                ("array", "array-function"),
                ("array?", "array-predicate-function"),
                ("make-array", "array-make-function"),
                ("aclone", "array-clone-function"),
                ("aget", "array-get-function"),
                ("aset", "array-set-function"),
                ("js-delete", "js-delete-function"),
                ("alength", "array-length-function"),
                ("native-satisfies?", "native-satisfies-function"),
                ("nil?", "predicate-nil"),
                ("false?", "predicate-false"),
                ("true?", "predicate-true"),
                ("undefined?", "predicate-undefined"),
                ("number?", "predicate-number"),
                ("string?", "predicate-string"),
                ("js-fn?", "predicate-function"),
                ("identical?", "predicate-identical"),
                ("ExceptionInfo", "core-exception-info-class"),
                ("ex-info", "core-ex-info"),
                ("ex-data", "core-ex-data"),
                ("ex-message", "core-ex-message"),
                ("ex-cause", "core-ex-cause"),
            ] {
                let global = Global {
                    phase,
                    namespace: "suss.core".into(),
                    name: name.into(),
                };
                env.bind(global.clone(), Binding::Core { global, export });
            }
            // Explicit owned host bindings, not declarations of a loaded JS namespace.
            for (name, export) in [
                ("Error", "error-constructor"),
                ("RangeError", "range-error-constructor"),
                ("undefined", "undefined-value"),
                ("TypeError", "type-error-constructor"),
                ("Object", "object-constructor"),
                ("NaN", "nan-value"),
            ] {
                let global = Global {
                    phase,
                    namespace: "js".into(),
                    name: name.into(),
                };
                env.bind(global.clone(), Binding::Core { global, export });
            }
            // Private callable adapters used by the bundled compiled async library.
            for (name, export) in [
                ("pending", "async-source-pending-function"),
                ("resolve!", "async-source-resolve!-function"),
                ("reject!", "async-source-reject!-function"),
                ("cancel!", "async-source-cancel!-function"),
                ("status", "async-source-status-function"),
                ("result", "async-source-result-function"),
                ("stream-pair", "async-source-stream-pair-function"),
                (
                    "stream-pair-reader",
                    "async-source-stream-pair-reader-function",
                ),
                (
                    "stream-pair-writer",
                    "async-source-stream-pair-writer-function",
                ),
                (
                    "stream-read-limit",
                    "async-source-stream-read-limit-function",
                ),
                (
                    "stream-write-limit",
                    "async-source-stream-write-limit-function",
                ),
                (
                    "stream-begin-read",
                    "async-source-stream-begin-read-function",
                ),
                (
                    "stream-begin-write",
                    "async-source-stream-begin-write-function",
                ),
                (
                    "stream-operation-future",
                    "async-source-stream-operation-future-function",
                ),
                (
                    "stream-operation-retire",
                    "async-source-stream-operation-retire-function",
                ),
                ("stream-chunk-new", "async-source-stream-chunk-new-function"),
                ("stream-chunk-set", "async-source-stream-chunk-set-function"),
                (
                    "stream-chunk-count",
                    "async-source-stream-chunk-count-function",
                ),
                ("stream-chunk-nth", "async-source-stream-chunk-nth-function"),
                ("stream-eof?", "async-source-stream-eof?-function"),
                ("stream-close!", "async-source-stream-close!-function"),
                ("stream-fail!", "async-source-stream-fail!-function"),
            ] {
                let global = Global {
                    phase,
                    namespace: "suss.internal.async".into(),
                    name: name.into(),
                };
                env.bind(global.clone(), Binding::Core { global, export });
            }
            for (name, form) in [
                ("deftype", NominalForm::Deftype),
                ("deftype*", NominalForm::DeftypeInternal),
                ("defrecord*", NominalForm::DefrecordInternal),
                ("defprotocol", NominalForm::Defprotocol),
                ("extend-type", NominalForm::ExtendType),
                ("instance?", NominalForm::Instance),
                ("satisfies?", NominalForm::Satisfies),
                ("implements?", NominalForm::Implements),
                ("reify", NominalForm::Reify),
            ] {
                let global = Global {
                    phase,
                    namespace: "suss.core".into(),
                    name: name.into(),
                };
                env.bind(global.clone(), Binding::Nominal { global, form });
            }
            for name in [
                "when",
                "when-not",
                "if-not",
                "if-let",
                "and",
                "or",
                "cond",
                "case",
                "declare",
                "caching-hash",
                "unchecked-get",
                "unchecked-set",
            ] {
                let global = Global {
                    phase,
                    namespace: "suss.core".into(),
                    name: name.into(),
                };
                env.bind(
                    global.clone(),
                    Binding::BootstrapControl {
                        global,
                        operation: ControlForm::from_name(name).unwrap(),
                    },
                );
            }
            for name in ["let", "letfn", "loop", "fn", "defonce", "binding", "with-redefs"] {
                let global = Global {
                    phase,
                    namespace: "suss.core".into(),
                    name: name.into(),
                };
                let binding = if name == "let" || name == "letfn" {
                    Binding::BootstrapLet(global.clone())
                } else if name == "loop" {
                    Binding::BootstrapLoop(global.clone())
                } else if name == "fn" {
                    Binding::BootstrapFn(global.clone())
                } else if name == "binding" || name == "with-redefs" {
                    Binding::BootstrapBinding(global.clone())
                } else {
                    Binding::BootstrapDefonce(global.clone())
                };
                env.bind(global, binding);
            }
        }
        Ok(env)
    }
    fn scope(&self, phase: Phase) -> &Scope {
        &self.scopes[&(phase, self.current[&phase].clone())]
    }
    /// The namespace `alias` names in the current namespace, for `::alias/name`.
    pub(crate) fn aliased_namespace(&self, phase: Phase, alias: &str) -> Option<&str> {
        self.scope(phase).aliases.get(alias).map(String::as_str)
    }
    fn source_changed(&mut self) {
        self.source_generation = self
            .source_generation
            .checked_add(1)
            .expect("compiler source generation exhausted");
    }
    pub(crate) fn source_generation(&self) -> u64 {
        self.source_generation
    }
    fn scope_mut(&mut self, phase: Phase) -> &mut Scope {
        self.source_changed();
        let namespace = self.current[&phase].clone();
        self.scopes
            .get_mut(&(phase, namespace))
            .expect("declared current scope")
    }
    /// Undo staged declaration publication without reverting unrelated macro effects/dependencies.
    pub fn restore_declarations(&mut self, before: &Self, globals: &[Global], phase: Phase) {
        for global in globals {
            match before.bindings.get(global) {
                Some(value) => self.bind(global.clone(), value.clone()),
                None => self.unbind(global),
            }
            let definitions = self.definitions.entry((global.phase, global.namespace.clone())).or_default();
            match before.shared_definition_info(global) {
                Some(value) => definitions.insert(global.clone(), value.clone()),
                None => {
                    definitions.remove(global);
                }
            }
            match before.macro_declarations.get(global) {
                Some(revision) => { self.macro_declarations.insert(global.clone(), revision.clone()); }
                None => { self.macro_declarations.remove(global); }
            }
            let export = (phase, global.namespace.to_string(), global.name.to_string());
            if before.macro_exports.contains(&export) {
                self.macro_exports.insert(export);
            } else {
                self.macro_exports.remove(&export);
            }
        }
        if let Some(namespace) = before.current.get(&phase) {
            self.current.insert(phase, namespace.clone());
        }
        self.source_changed();
    }
    pub fn current_namespace(&self, phase: Phase) -> &str {
        &self.current[&phase]
    }
    pub fn namespace_scope(&self, phase: Phase) -> NamespaceScope<'_> {
        self.namespace_scope_for(phase, self.current_namespace(phase))
            .expect("declared current scope")
    }
    /// Read an actual declared scope without changing the current namespace or
    /// source generation. A missing scope stays missing, never a fallback def.
    pub fn namespace_scope_for(&self, phase: Phase, namespace: &str) -> Option<NamespaceScope<'_>> {
        let scope = self.scopes.get(&(phase, canonical(namespace).into()))?;
        Some(NamespaceScope {
            namespace: &scope.namespace, aliases: &scope.aliases,
            refers: &scope.refers, excluded_core: &scope.excluded_core,
            used_refers: &scope.used_refers, renamed_refers: &scope.renamed_refers,
            macro_aliases: &scope.macro_aliases, macro_refers: &scope.macro_refers,
            used_macro_refers: &scope.used_macro_refers, renamed_macro_refers: &scope.renamed_macro_refers,
            declarations: self.definitions.get(&(phase, scope.namespace.as_str().into())).into_iter()
                .flat_map(PersistentMap::iter).map(|(global, info)| (global, info.as_ref())).collect(),
        })
    }
    /// A snapshot of one namespace for source facts. Its declarations and
    /// identities are that namespace's persistent maps, shared rather than
    /// copied (#319).
    pub(crate) fn source_namespace(&self, phase: Phase, namespace: &str) -> Option<super::hir::SourceNamespace> {
        let scope = self.scopes.get(&(phase, canonical(namespace).into()))?;
        let key = (phase, std::sync::Arc::<str>::from(scope.namespace.as_str()));
        let declarations = self.definitions.get(&key).cloned().unwrap_or_default();
        let identities = self.identities.get(&key).cloned().unwrap_or_default();
        Some(super::hir::SourceNamespace {
            namespace: scope.namespace.clone(),
            aliases: scope.aliases.clone(),
            refers: scope.refers.clone(),
            used_refers: scope.used_refers.clone(),
            renamed_refers: scope.renamed_refers.clone(),
            excluded_core: scope.excluded_core.clone(),
            macro_aliases: scope.macro_aliases.clone(),
            macro_refers: scope.macro_refers.clone(),
            used_macro_refers: scope.used_macro_refers.clone(),
            renamed_macro_refers: scope.renamed_macro_refers.clone(),
            declarations,
            identities,
        })
    }
    /// Phase-specific declared namespaces; declaration does not certify loading.
    pub fn declared_namespaces(&self, phase: Phase) -> impl Iterator<Item = &str> {
        self.namespaces.iter().filter_map(move |(entry_phase, namespace)|
            (*entry_phase == phase).then_some(namespace.as_str()))
    }
    pub(crate) fn declaration_snapshot(&self) -> DeclarationSnapshot {
        DeclarationSnapshot(self.definitions.clone())
    }
    pub fn definition_info(&self, global: &Global) -> Option<&DefinitionInfo> {
        self.shared_definition_info(global).map(std::sync::Arc::as_ref)
    }
    /// Immutable declaration revisions retain identity through Environment clones
    /// and source snapshots. Reanalysis installs a fresh revision instead.
    pub(crate) fn shared_definition_info(
        &self,
        global: &Global,
    ) -> Option<&std::sync::Arc<DefinitionInfo>> {
        self.definitions.get(&(global.phase, global.namespace.clone()))?.get(global)
    }
    pub(crate) fn record_definition(&mut self, global: Global, info: DefinitionInfo) {
        self.source_changed();
        self.definitions
            .entry((global.phase, global.namespace.clone()))
            .or_default()
            .insert(global, std::sync::Arc::new(info));
    }
    /// Explicit declarations, not evidence that any source file has loaded.
    pub fn has_namespace(&self, phase: Phase, namespace: &str) -> bool {
        self.namespaces
            .contains(&(phase, canonical(namespace).into()))
    }
    pub fn cells(&self) -> Vec<Global> {
        self.bindings
            .values()
            .filter_map(|binding| match binding {
                Binding::Cell(global)
                | Binding::InternalCell(global)
                | Binding::ReaderCell(global) => Some(global.clone()),
                _ => None,
            })
            .chain(self.materialized_bootstrap.iter().cloned())
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect()
    }
    pub(crate) fn materialize_bootstrap(&mut self, global: Global) {
        if self.materialized_bootstrap.insert(global.clone()) {
            self.refresh_identity(&global);
            self.source_changed();
        }
    }
    /// Panics unless every namespace's identities equal a full recomputation
    /// from the bindings and materialized bootstrap cells.
    #[cfg(all(test, not(suss_generator)))]
    pub(crate) fn check_identities(&self) {
        let mut expected = BTreeMap::<(Phase, std::sync::Arc<str>), Vec<Global>>::new();
        let visible = self
            .bindings
            .iter()
            .filter_map(|(global, binding)| matches!(binding, Binding::Cell(_)).then_some(global))
            .chain(self.materialized_bootstrap.iter().filter(|global| {
                !matches!(self.bindings.get(global), Some(Binding::ReaderCell(_) | Binding::InternalCell(_)))
            }))
            .collect::<BTreeSet<_>>();
        for global in visible {
            expected.entry((global.phase, global.namespace.clone())).or_default().push(global.clone());
        }
        let actual = self
            .identities
            .iter()
            .filter(|(_, identities)| !identities.is_empty())
            .map(|(key, identities)| (key.clone(), identities.iter().cloned().collect::<Vec<_>>()))
            .collect::<BTreeMap<_, _>>();
        assert_eq!(actual, expected);
    }
    fn bind(&mut self, global: Global, binding: Binding) {
        self.bindings.insert(global.clone(), binding);
        self.refresh_identity(&global);
    }
    fn unbind(&mut self, global: &Global) {
        self.bindings.remove(global);
        self.refresh_identity(global);
    }
    fn refresh_identity(&mut self, global: &Global) {
        let visible = match self.bindings.get(global) {
            Some(Binding::Cell(_)) => true,
            Some(Binding::ReaderCell(_) | Binding::InternalCell(_)) => false,
            _ => self.materialized_bootstrap.contains(global),
        };
        let key = (global.phase, global.namespace.clone());
        if visible {
            self.identities.entry(key).or_default().insert(global.clone());
        } else if let Some(identities) = self.identities.get_mut(&key) {
            identities.remove(global);
        }
    }
    /// Bootstrap cell initializers for native hosts; source values share these
    /// canonical identities and later declarations may replace their contents.
    pub fn core_bindings(&self, phase: Phase) -> Vec<(Global, &'static str)> {
        self.bindings
            .values()
            .filter_map(|binding| match binding {
                Binding::Core { global, export } if global.phase == phase => {
                    Some((global.clone(), *export))
                }
                _ => None,
            })
            .collect()
    }
    pub fn arithmetic_bindings(&self, phase: Phase) -> Vec<(Global, Arithmetic)> {
        self.bindings
            .values()
            .filter_map(|binding| match binding {
                Binding::Arithmetic { global, operator } if global.phase == phase => {
                    Some((global.clone(), *operator))
                }
                _ => None,
            })
            .collect()
    }
    pub fn declare_namespace(&mut self, phase: Phase, namespace: &str) -> Result<(), Diagnostic> {
        valid_namespace(namespace)?;
        let namespace = canonical(namespace);
        if self.scopes.iter().any(|((scope_phase, _), scope)| {
            *scope_phase == phase
                && scope
                    .aliases
                    .get(namespace)
                    .is_some_and(|target| target != namespace)
        }) {
            return Err(error(format!("Ambiguous namespace alias {namespace}")));
        }
        self.namespaces.insert((phase, namespace.into()));
        Ok(())
    }
    pub fn enter_namespace(&mut self, phase: Phase, namespace: &str) -> Result<(), Diagnostic> {
        self.declare_namespace(phase, namespace)?;
        let namespace = canonical(namespace);
        self.scopes
            .entry((phase, namespace.into()))
            .or_insert_with(|| Scope::new(namespace));
        self.current.insert(phase, namespace.into());
        self.source_changed();
        Ok(())
    }
    /// An ns declaration replaces imports; entering a REPL namespace preserves them.
    pub(crate) fn reset_namespace(
        &mut self,
        phase: Phase,
        namespace: &str,
    ) -> Result<(), Diagnostic> {
        self.enter_namespace(phase, namespace)?;
        let namespace = self.current[&phase].clone();
        self.scopes
            .insert((phase, namespace.clone()), Scope::new(&namespace));
        self.source_changed();
        Ok(())
    }
    pub fn declare_cell(
        &mut self,
        phase: Phase,
        namespace: &str,
        name: &str,
    ) -> Result<Global, Diagnostic> {
        valid_namespace(namespace)?;
        valid_name(name)?;
        let global = Global {
            phase,
            namespace: canonical(namespace).into(),
            name: name.into(),
        };
        if self
            .scopes
            .get(&(phase, global.namespace.to_string()))
            .is_some_and(|scope| {
                scope
                    .refers
                    .get(name)
                    .is_some_and(|target| *target != global)
            })
        {
            return Err(error(format!("Ambiguous binding {name}")));
        }
        if matches!(self.bindings.get(&global), Some(Binding::InternalCell(_))) {
            return Err(error("Cannot redefine a compiler-owned binding"));
        }
        self.declare_namespace(phase, &global.namespace)?;
        self.bind(global.clone(), Binding::Cell(global.clone()));
        self.source_changed();
        Ok(global)
    }
    pub(crate) fn is_hidden_cell(&self, phase: Phase, namespace: &str, name: &str) -> bool {
        let global = Global {
            phase,
            namespace: canonical(namespace).into(),
            name: name.into(),
        };
        matches!(
            self.bindings.get(&global),
            Some(Binding::ReaderCell(_) | Binding::InternalCell(_))
        )
    }
    pub(crate) fn reader_sequence_cells(&mut self, phase: Phase) -> (Global, Global, bool) {
        let global = Global {
            phase,
            namespace: "suss.core".into(),
            name: "sequence".into(),
        };
        let fallback = Global {
            phase,
            namespace: "suss.internal.reader".into(),
            name: "sequence".into(),
        };
        if !self.bindings.contains_key(&global) {
            self.bind(global.clone(), Binding::ReaderCell(global.clone()));
        }
        let fresh = !self.bindings.contains_key(&fallback);
        if fresh {
            self.bind(fallback.clone(), Binding::InternalCell(fallback.clone()));
            self.source_changed();
        }
        (global, fallback, fresh)
    }
    /// The internal cell holding `namespace`'s runtime namespace object (#309),
    /// and whether this call registered it.
    pub(crate) fn namespace_cell(&mut self, phase: Phase, namespace: &str) -> (Global, bool) {
        let global = Global {
            phase,
            namespace: "suss.internal.namespaces".into(),
            name: canonical(namespace).into(),
        };
        let fresh = !self.bindings.contains_key(&global);
        if fresh {
            self.bind(global.clone(), Binding::InternalCell(global.clone()));
            self.source_changed();
        }
        (global, fresh)
    }
    /// Per-analysis anonymous reify site class publication cell. The pinned
    /// macro gensyms one internal type per macro expansion and publishes it
    /// behind an exists? guard; analysis identity takes the expansion's place.
    /// A fresh registration advances the source generation so the same source
    /// analyzed again publishes a distinct anonymous class, like a new gensym.
    pub(crate) fn reify_class_key(&mut self, phase: Phase, generation: u64, site: usize) -> Global {
        let global = Global {
            phase,
            namespace: "suss.internal.reify".into(),
            name: format!("t-reify-{generation}-{site}").into(),
        };
        if !self.bindings.contains_key(&global) {
            self.bind(global.clone(), Binding::InternalCell(global.clone()));
            self.source_changed();
        }
        global
    }
    pub(crate) fn native_constant(&mut self, phase: Phase, owner: u64, index: u64) -> Global {
        let cell = Global::native_constant(phase, owner, index);
        if !self.bindings.contains_key(&cell) {
            self.bind(cell.clone(), Binding::InternalCell(cell.clone()));
            self.source_changed();
        }
        cell
    }
    pub(crate) fn native_value(&mut self, phase: Phase, owner: u64, index: u64) -> Global {
        let cell=Global::native_value(phase,owner,index);
        if !self.bindings.contains_key(&cell) { self.bind(cell.clone(),Binding::InternalCell(cell.clone())); self.source_changed(); }
        cell
    }
    pub(crate) fn native_function_site(&mut self, phase: Phase, owner: u64, index: u64, pool: u64) -> Global {
        let cell=Global::native_function_site(phase,owner,index,pool);
        if !self.bindings.contains_key(&cell) { self.bind(cell.clone(),Binding::InternalCell(cell.clone())); self.source_changed(); }
        cell
    }
    pub(crate) fn native_function_initializer(&mut self, site: &Global) -> Global {
        let cell=site.native_site_initializer();
        if !self.bindings.contains_key(&cell) { self.bind(cell.clone(),Binding::InternalCell(cell.clone())); self.source_changed(); }
        cell
    }
    pub(crate) fn native_function_pool(&mut self) -> u64 {
        self.source_changed(); self.source_generation
    }
    /// A fresh, unresolvable cell for one constant declaration revision.
    pub(crate) fn constant_cell(&mut self, phase: Phase) -> Global {
        let cell = Global {
            phase,
            namespace: "suss.internal.constants".into(),
            name: format!("constant-{}", self.source_generation).into(),
        };
        self.bind(cell.clone(), Binding::InternalCell(cell.clone()));
        self.source_changed();
        cell
    }
    /// The direct-link cell of a shipped core definition (design decision
    /// 2026-10-25): core's own references read it, so user redefinition or
    /// with-redefs of the public var changes only user call sites, as with
    /// Clojure's direct linking. It is internal and unresolvable by user code.
    pub(crate) fn core_link_cell(&mut self, global: &Global) -> Global {
        let link = Global {
            phase: global.phase,
            namespace: "suss.internal.core-link".into(),
            name: global.name.clone(),
        };
        if !self.bindings.contains_key(&link) {
            self.bind(link.clone(), Binding::InternalCell(link.clone()));
            self.source_changed();
        }
        link
    }
    /// The direct-link cell of a runtime-provided bootstrap binding (`nil?`,
    /// `aclone`, ...), initialized with the public cell by the core bindings
    /// module so shipped core never calls a user redefinition.
    pub(crate) fn bootstrap_link_global(global: &Global) -> Global {
        Global {
            phase: global.phase,
            namespace: "suss.internal.bootstrap-link".into(),
            name: global.name.clone(),
        }
    }
    pub(crate) fn bootstrap_link(&mut self, global: &Global) -> Global {
        let link = Self::bootstrap_link_global(global);
        if !self.bindings.contains_key(&link) {
            self.bind(link.clone(), Binding::InternalCell(link.clone()));
            self.source_changed();
        }
        link
    }
    /// The direct-link cell, only if that definition registered one.
    pub(crate) fn existing_core_link(&self, global: &Global) -> Option<Global> {
        let link = Global {
            phase: global.phase,
            namespace: "suss.internal.core-link".into(),
            name: global.name.clone(),
        };
        matches!(self.bindings.get(&link), Some(Binding::InternalCell(_))).then_some(link)
    }
    /// The protocol's own value (`method` None) or a method's original wrapper,
    /// as defined by its defprotocol. Native extension tables and markers live
    /// on these values, so rebinding or aliasing the public vars cannot redirect
    /// another protocol's dispatch (#279). Shipped core's protocols keep cells
    /// apart from user definitions reusing their names, so a user defprotocol
    /// in suss.core cannot replace core's tables. Internal and unresolvable.
    pub(crate) fn protocol_native(
        &mut self,
        protocol: &Global,
        method: Option<&str>,
        privileged: bool,
    ) -> Global {
        let identity = format!(
            "{}/{}/{}",
            protocol.namespace,
            protocol.name,
            method.unwrap_or("")
        );
        let name = identity
            .as_bytes()
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect::<String>();
        let global = Global {
            phase: protocol.phase,
            namespace: if privileged {
                "suss.internal.core-protocol-natives".into()
            } else {
                "suss.internal.protocol-natives".into()
            },
            name: format!("native-{name}").into(),
        };
        if !self.bindings.contains_key(&global) {
            self.bind(global.clone(), Binding::InternalCell(global.clone()));
            self.source_changed();
        }
        global
    }
    /// One nominal Var per actual persistent source binding, phase-local and
    /// unresolvable by user source. The getter closes over the original cell.
    fn var_identity(target: &Global) -> Global {
        let identity = format!("{}/{}", target.namespace(), target.name());
        let name = identity.as_bytes().iter().map(|byte| format!("{byte:02x}")).collect::<String>();
        Global { phase: target.phase, namespace: "suss.internal.vars".into(), name: format!("var-{name}").into() }
    }
    pub(crate) fn existing_var_cell(&self, target: &Global) -> Option<Global> {
        let global = Self::var_identity(target);
        matches!(self.bindings.get(&global), Some(Binding::InternalCell(_))).then_some(global)
    }
    pub(crate) fn native_macro_declarations(&self) -> impl Iterator<Item = Global> + '_ {
        self.macro_declarations.keys().cloned()
    }
    pub(crate) fn var_cell(&mut self, target: &Global) -> Result<Global, Diagnostic> {
        let global = Self::var_identity(target);
        match self.bindings.get(&global) {
            Some(Binding::InternalCell(_)) => {},
            Some(_) => return Err(error("Var identity collides with a source binding")),
            None => { self.bind(global.clone(), Binding::InternalCell(global.clone())); self.source_changed(); },
        }
        Ok(global)
    }
    /// The hidden cell that holds the interned keyword `fqn` for literals
    /// (#361): every literal site of a keyword reads the same keyword.
    pub(crate) fn keyword_cell(&mut self, phase: Phase, fqn: &str) -> Global {
        let name = fqn.as_bytes().iter().map(|byte| format!("{byte:02x}")).collect::<String>();
        let global = Global {
            phase,
            namespace: "suss.internal.keywords".into(),
            name: format!("keyword-{name}").into(),
        };
        if !self.bindings.contains_key(&global) {
            self.bind(global.clone(), Binding::InternalCell(global.clone()));
        }
        global
    }
    /// Records the AOT build's exported functions' numeric parameters (#385).
    pub(crate) fn set_export_param_hints(&mut self, hints: BTreeMap<(String, String), Vec<Option<bool>>>) {
        self.export_param_hints = hints;
    }
    pub(crate) fn export_param_hints(&self, namespace: &str, name: &str) -> Option<&Vec<Option<bool>>> {
        self.export_param_hints.get(&(namespace.to_owned(), name.to_owned()))
    }
    /// The number of a keyword cell's per-fragment cache (#387).
    pub(crate) fn keyword_cache(&mut self, cell: &Global) -> usize {
        let next = self.keyword_caches.len();
        *self.keyword_caches.entry(cell.clone()).or_insert(next)
    }
    /// Link the shipped core image's calls to its own functions (#360).
    pub(crate) fn set_core_image_links(&mut self, enabled: bool) {
        self.core_image_links = enabled;
    }
    /// Turn on direct linking of user code, as an AOT build does (#360).
    pub fn set_direct_linking(&mut self, enabled: bool) {
        self.direct_linking = enabled;
    }
    /// A fresh link identity for a new direct-linked definition of `global`,
    /// which becomes its current one. The identity names the defining
    /// fragment's exports and the module callers import them from.
    /// A new linked definition of `global`: (its var's slot, the definition).
    pub(crate) fn define_direct_link(&mut self, global: &Global) -> (usize, usize) {
        self.direct_link_count += 1;
        let definition = self.direct_link_count;
        let slot = *self.direct_slots.entry(global.clone()).or_insert(definition);
        self.direct_links.insert(global.clone(), (slot, definition));
        (slot, definition)
    }
    /// A direct-linked var's slot, which `set!` also writes (#360).
    pub(crate) fn direct_slot(&self, global: &Global) -> Option<usize> {
        self.direct_slots.get(global).copied()
    }
    /// A var that is no longer direct-linkable, such as one redefined to a
    /// non-function, stops linking new calls.
    pub(crate) fn end_direct_link(&mut self, global: &Global) {
        self.direct_links.remove(global);
    }
    pub(crate) fn protocol_key(&mut self, protocol: &Global, method: &str, arity: usize) -> Global {
        let identity = format!(
            "{}/{}/{}/{}",
            protocol.namespace, protocol.name, method, arity
        );
        let name = identity
            .as_bytes()
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect::<String>();
        let global = Global {
            phase: protocol.phase,
            namespace: "suss.internal.protocol-keys".into(),
            name: format!("key-{name}").into(),
        };
        self.bind(global.clone(), Binding::InternalCell(global.clone()));
        global
    }
    /// Retain the explicit source require edge, including imports without aliases.
    /// This is a compiler catalog fact; it does not certify initialized code.
    pub(crate) fn record_requirement(
        &mut self,
        phase: Phase,
        namespace: &str,
        macros: bool,
    ) -> Result<(), Diagnostic> {
        valid_namespace(namespace)?;
        let target = canonical(namespace);
        let catalog = if macros {
            &self.macro_namespaces
        } else {
            &self.namespaces
        };
        if !catalog.contains(&(phase, target.into())) {
            return Err(error(format!(
                "Unknown {phase:?} required namespace {namespace}"
            )));
        }
        let scope = self.scope_mut(phase);
        let aliases = if macros {
            &mut scope.macro_aliases
        } else {
            &mut scope.aliases
        };
        if aliases.get(namespace).is_some_and(|old| old != target) {
            return Err(error(format!(
                "Ambiguous required namespace alias {namespace}"
            )));
        }
        aliases.insert(namespace.into(), target.into());
        Ok(())
    }
    /// Native eval takes aliases from the caller's actual Namespace object.
    /// These are already admitted Symbol keys; unlike ns :as they may be empty
    /// or qualified. Replacing this snapshot retains every other scope fact.
    pub(crate) fn replace_evaluation_aliases(&mut self, phase: Phase, aliases: BTreeMap<String, String>) {
        if self.scope(phase).aliases != aliases {
            self.scope_mut(phase).aliases = aliases;
        }
    }
    pub fn alias(&mut self, phase: Phase, alias: &str, namespace: &str) -> Result<(), Diagnostic> {
        valid_namespace(alias)?;
        valid_namespace(namespace)?;
        let namespace = canonical(namespace);
        if matches!(alias, "suss.core" | "cljs.core") {
            return Err(error("Canonical core namespaces cannot be aliased away"));
        }
        if !self.namespaces.contains(&(phase, namespace.into())) {
            return Err(error(format!("Unknown {phase:?} namespace {namespace}")));
        }
        let scope = self.scope(phase);
        if scope
            .aliases
            .get(alias)
            .is_some_and(|target| target != namespace)
            || (self.namespaces.contains(&(phase, alias.into())) && alias != namespace)
        {
            return Err(error(format!("Ambiguous namespace alias {alias}")));
        }
        self.scope_mut(phase)
            .aliases
            .insert(alias.into(), namespace.into());
        Ok(())
    }
    pub fn refer(
        &mut self,
        phase: Phase,
        local: &str,
        namespace: &str,
        name: &str,
    ) -> Result<(), Diagnostic> {
        self.refer_with_role(phase, local, namespace, name, local != name)
    }
    pub(crate) fn has_binding(&self, phase: Phase, namespace: &str, name: &str) -> bool {
        self.bindings.contains_key(&Global {
            phase,
            namespace: canonical(namespace).into(),
            name: name.into(),
        })
    }
    pub(crate) fn refer_with_role(
        &mut self,
        phase: Phase,
        local: &str,
        namespace: &str,
        name: &str,
        renamed: bool,
    ) -> Result<(), Diagnostic> {
        valid_name(local)?;
        valid_namespace(namespace)?;
        valid_name(name)?;
        let global = Global {
            phase,
            namespace: canonical(namespace).into(),
            name: name.into(),
        };
        if !self.bindings.contains_key(&global) {
            return Err(error(format!(
                "Unknown {phase:?} binding {}",
                global.import_name()
            )));
        }
        let scope = self.scope(phase);
        let own = Global {
            phase,
            namespace: scope.namespace.as_str().into(),
            name: local.into(),
        };
        if scope
            .refers
            .get(local)
            .is_some_and(|target| *target != global)
            || (self.bindings.contains_key(&own) && own != global)
        {
            return Err(error(format!("Ambiguous binding {local}")));
        }
        let scope = self.scope_mut(phase);
        scope.refers.insert(local.into(), global);
        if renamed {
            &mut scope.renamed_refers
        } else {
            &mut scope.used_refers
        }
        .insert(local.into());
        Ok(())
    }
    pub fn exclude_core(&mut self, phase: Phase, name: &str) -> Result<(), Diagnostic> {
        valid_name(name)?;
        self.scope_mut(phase).excluded_core.insert(name.into());
        Ok(())
    }
    pub(crate) fn record_native_macro_source(&mut self, phase: Phase, namespace: &str, name: &str,
        source: suss_reader::forms::Form,
    ) {
        let global = Global { phase, namespace: canonical(namespace).into(), name: name.into() };
        if let Some(info) = self.definition_info(&global) {
            let mut info = info.clone();
            info.definition_form = source;
            info.initializer_form = None;
            info.initializer = None;
            self.record_definition(global, info);
        }
    }
    pub(crate) fn inherit_native_macro_status(&mut self, caller: &Self) {
        self.native_macro_status = caller.native_macro_status.clone();
    }
    pub(crate) fn clear_native_macro_status(&mut self) {
        self.native_macro_status.clear();
    }
    pub(crate) fn record_native_macro_status(&mut self, global: Global, enabled: bool) {
        self.native_macro_status.insert(global, enabled);
        self.source_changed();
    }
    pub(crate) fn record_macro_declaration(&mut self, phase: Phase, namespace: &str, name: &str) {
        let global = Global { phase, namespace: canonical(namespace).into(), name: name.into() };
        let revision = self.shared_definition_info(&global).cloned();
        self.native_macro_status.remove(&global);
        self.macro_declarations.insert(global, revision);
        self.source_changed();
    }
    pub(crate) fn source_macro_overridden(&self, phase: Phase, namespace: &str, name: &str) -> bool {
        let global = Global { phase, namespace: canonical(namespace).into(), name: name.into() };
        if let Some(enabled) = self.native_macro_status.get(&global) { return !enabled; }
        let Some(declared) = self.macro_declarations.get(&global) else { return false };
        match (declared, self.shared_definition_info(&global)) {
            (None, None) => false,
            (Some(declared), Some(current)) => !std::sync::Arc::ptr_eq(declared, current),
            _ => true,
        }
    }
    /// Macro catalogs describe functions in the isolated host, never Runtime cells.
    pub fn declare_macro_exports(
        &mut self,
        phase: Phase,
        namespace: &str,
        names: &[String],
    ) -> Result<(), Diagnostic> {
        valid_namespace(namespace)?;
        for name in names {
            valid_name(name)?;
        }
        let namespace = canonical(namespace);
        self.macro_namespaces.insert((phase, namespace.into()));
        self.macro_exports
            .retain(|(p, ns, _)| *p != phase || ns != namespace);
        self.macro_exports.extend(
            names
                .iter()
                .map(|name| (phase, namespace.into(), name.clone())),
        );
        Ok(())
    }
    pub fn macro_alias(
        &mut self,
        phase: Phase,
        alias: &str,
        namespace: &str,
    ) -> Result<(), Diagnostic> {
        valid_namespace(alias)?;
        if matches!(alias, "suss.core" | "cljs.core") {
            return Err(error("Canonical core namespaces cannot be aliased away"));
        }
        valid_namespace(namespace)?;
        let namespace = canonical(namespace);
        if !self.macro_namespaces.contains(&(phase, namespace.into())) {
            return Err(error(format!("Unknown macro namespace {namespace}")));
        }
        if self.macro_namespaces.contains(&(phase, alias.into())) && alias != namespace {
            return Err(error(format!("Ambiguous macro namespace alias {alias}")));
        }
        let scope = self.scope_mut(phase);
        if scope
            .macro_aliases
            .get(alias)
            .is_some_and(|old| old != namespace)
        {
            return Err(error(format!("Ambiguous macro namespace alias {alias}")));
        }
        scope.macro_aliases.insert(alias.into(), namespace.into());
        Ok(())
    }
    pub fn macro_refer(
        &mut self,
        phase: Phase,
        local: &str,
        namespace: &str,
        name: &str,
    ) -> Result<(), Diagnostic> {
        self.macro_refer_with_role(phase, local, namespace, name, local != name)
    }
    pub(crate) fn macro_refer_with_role(
        &mut self,
        phase: Phase,
        local: &str,
        namespace: &str,
        name: &str,
        renamed: bool,
    ) -> Result<(), Diagnostic> {
        valid_name(local)?;
        let namespace = canonical(namespace);
        if !self
            .macro_exports
            .contains(&(phase, namespace.into(), name.into()))
        {
            return Err(error(format!("Unknown macro binding {namespace}/{name}")));
        }
        let target = (namespace.into(), name.into());
        let scope = self.scope_mut(phase);
        if scope
            .macro_refers
            .get(local)
            .is_some_and(|old| *old != target)
        {
            return Err(error(format!("Ambiguous macro binding {local}")));
        }
        scope.macro_refers.insert(local.into(), target);
        if renamed {
            &mut scope.renamed_macro_refers
        } else {
            &mut scope.used_macro_refers
        }
        .insert(local.into());
        Ok(())
    }
    pub fn resolve_source_macro(&self, phase: Phase, symbol: &Symbol) -> Option<(String, String)> {
        let scope = self.scope(phase);
        let target = if let Some(namespace) = &symbol.namespace {
            (
                symbol_namespace(
                    scope
                        .macro_aliases
                        .get(namespace)
                        .or_else(|| scope.aliases.get(namespace)),
                    namespace,
                )
                .into(),
                symbol.name.clone(),
            )
        } else if let Some(target) = scope.macro_refers.get(&symbol.name) {
            target.clone()
        } else if phase == Phase::Macro
            && let Some(target) = scope.refers.get(&symbol.name)
        {
            // Ordinary dependencies of compiled macro source live in this same
            // phase. Only a real registered macro export can pass the check below.
            (target.namespace.to_string(), target.name.to_string())
        } else {
            (scope.namespace.clone(), symbol.name.clone())
        };
        self.macro_exports
            .contains(&(phase, target.0.clone(), target.1.clone()))
            .then_some(target)
    }
    /// Identify a bounded core macro before its complete source bootstrap exists.
    /// This supplies no runtime binding/value: excluded, shadowed or non-core
    /// names continue through ordinary lookup and its diagnostics.
    pub fn resolves_bootstrap_name(&self, phase: Phase, symbol: &Symbol, name: &str) -> bool {
        let scope = self.scope(phase);
        if let Some(namespace) = &symbol.namespace {
            return symbol_namespace(scope.aliases.get(namespace), namespace) == "suss.core"
                && symbol.name == name;
        }
        if let Some(target) = scope.refers.get(&symbol.name) {
            return &*target.namespace == "suss.core" && &*target.name == name;
        }
        let own = Global {
            phase,
            namespace: scope.namespace.as_str().into(),
            name: symbol.name.as_str().into(),
        };
        symbol.name == name
            && !scope.excluded_core.contains(name)
            && !self.bindings.contains_key(&own)
    }
    /// Names `resolve` finds as `namespace`'s own bindings in `phase`, the
    /// declarations runtime namespaces publish (#309).
    pub(crate) fn declared_names(&self, phase: Phase, namespace: &str) -> BTreeSet<String> {
        let start = Global { phase, namespace: namespace.into(), name: "".into() };
        self.bindings
            .range(start..)
            .take_while(|(global, _)| global.phase == phase && &*global.namespace == namespace)
            .filter(|(_, binding)| !matches!(binding, Binding::InternalCell(_) | Binding::ReaderCell(_)))
            .map(|(global, _)| global.name.to_string())
            .collect()
    }
    /// Whether `resolve` finds `name` as one of `namespace`'s own bindings.
    pub(crate) fn declares(&self, phase: Phase, namespace: &str, name: &str) -> bool {
        let global = Global { phase, namespace: namespace.into(), name: name.into() };
        self.bindings
            .get(&global)
            .is_some_and(|binding| !matches!(binding, Binding::InternalCell(_) | Binding::ReaderCell(_)))
    }
    /// The bounded bootstrap macro lookup is separate from ordinary var lookup:
    /// lexical locals (handled by HIR) hide macros. User runtime definitions also
    /// hide automatic core bootstrap macros, as observed in the pinned compiler.
    /// General compiled macro imports/expansion remain a later integration.
    pub fn resolve_bootstrap_macro(&self, phase: Phase, symbol: &Symbol) -> Option<Binding> {
        let scope = self.scope(phase);
        let name = if let Some(namespace) = &symbol.namespace {
            (symbol_namespace(scope.aliases.get(namespace), namespace) == "suss.core"
                && BOOTSTRAP_MACROS.contains(&symbol.name.as_str()))
            .then_some(symbol.name.as_str())
        } else if let Some(global) = scope.refers.get(&symbol.name) {
            if &*global.namespace == "suss.core"
                && BOOTSTRAP_MACROS.contains(&&*global.name)
            {
                Some(&*global.name)
            } else {
                (BOOTSTRAP_MACROS.contains(&symbol.name.as_str()) && !scope.excluded_core.contains(&symbol.name))
                .then_some(symbol.name.as_str())
            }
        } else {
            (BOOTSTRAP_MACROS.contains(&symbol.name.as_str()) && !scope.excluded_core.contains(&symbol.name))
            .then_some(symbol.name.as_str())
        }?;
        if name == "imul" && scope.namespace != "suss.core" {
            return None;
        }
        // A new runtime definition hides these automatic core bootstrap macros;
        // explicit core qualification remains independent of that user var.
        if symbol.namespace.is_none()
            && scope.namespace != "suss.core"
            && matches!(
                name,
                "implements?"
                    | "array"
                    | "make-array"
                    | "alength"
                    | "aget"
                    | "aset"
                    | "<"
                    | "<="
                    | ">"
                    | ">="
                    | "=="
                    | "when"
                    | "when-not"
                    | "if-not"
                    | "if-let"
                    | "and"
                    | "or"
                    | "cond"
                    | "case"
                    | "declare"
                    | "caching-hash"
                    | "->"
                    | "as->"
                    | "zero?"
                    | "pos?"
                    | "neg?"
                    | "inc"
                    | "dec"
                    | "int"
                    | "bit-and"
                    | "bit-or"
                    | "bit-xor"
                    | "bit-and-not"
                    | "bit-not"
                    | "bit-clear"
                    | "bit-flip"
                    | "bit-set"
                    | "bit-test"
                    | "bit-shift-left"
                    | "bit-shift-right"
                    | "unsigned-bit-shift-right"
                    | "bit-shift-right-zero-fill"
            )
            && self.bindings.contains_key(&Global {
                phase,
                namespace: scope.namespace.as_str().into(),
                name: symbol.name.as_str().into(),
            })
        {
            return None;
        }
        let global = Global {
            phase,
            namespace: "suss.core".into(),
            name: name.into(),
        };
        Some(if let Some(operation) = ControlForm::from_name(name) {
            Binding::BootstrapControl { global, operation }
        } else if let Some(operation) = Bitwise::from_name(name) {
            Binding::BootstrapBitwise { global, operation }
        } else if let Some(operation) = match name {
            "<" => Some(Comparison::Less),
            "<=" => Some(Comparison::LessEqual),
            ">" => Some(Comparison::Greater),
            ">=" => Some(Comparison::GreaterEqual),
            "==" => Some(Comparison::StrictEqual),
            _ => None,
        } {
            Binding::BootstrapComparison { global, operation }
        } else if let Some(operation) = match name {
            "array" => Some(ArrayOperation::Literal),
            "make-array" => Some(ArrayOperation::Make),
            "alength" => Some(ArrayOperation::Length),
            "aget" => Some(ArrayOperation::Get),
            "aset" => Some(ArrayOperation::Set),
            _ => None,
        } {
            Binding::BootstrapArray { global, operation }
        } else if name == "let" || name == "letfn" {
            Binding::BootstrapLet(global)
        } else if name == "loop" {
            Binding::BootstrapLoop(global.clone())
        } else if name == "fn" {
            Binding::BootstrapFn(global)
        } else if name == "defonce" {
            Binding::BootstrapDefonce(global)
        } else if name == "binding" || name == "with-redefs" {
            Binding::BootstrapBinding(global)
        } else {
            Binding::Nominal {
                global,
                form: match name {
                    "deftype" => NominalForm::Deftype,
                    "deftype*" => NominalForm::DeftypeInternal,
                    "defrecord*" => NominalForm::DefrecordInternal,
                    "defprotocol" => NominalForm::Defprotocol,
                    "instance?" => NominalForm::Instance,
                    "satisfies?" => NominalForm::Satisfies,
                    "implements?" => NominalForm::Implements,
                    _ => NominalForm::ExtendType,
                },
            }
        })
    }
    pub fn resolve(
        &self,
        phase: Phase,
        symbol: &Symbol,
        span: Range<usize>,
    ) -> Result<Binding, Diagnostic> {
        let scope = self.scope(phase);
        let global = if let Some(namespace) = &symbol.namespace {
            let namespace = if namespace == "js" {
                "js"
            } else if matches!(namespace.as_str(), "suss.core" | "cljs.core") {
                canonical(namespace)
            } else {
                symbol_namespace(scope.aliases.get(namespace), namespace)
            };
            Global {
                phase,
                namespace: namespace.into(),
                name: symbol.name.as_str().into(),
            }
        } else if let Some(global) = scope.refers.get(&symbol.name) {
            global.clone()
        } else {
            let own = Global {
                phase,
                namespace: scope.namespace.as_str().into(),
                name: symbol.name.as_str().into(),
            };
            if self.bindings.contains_key(&own) {
                own
            } else if !scope.excluded_core.contains(&symbol.name) {
                Global {
                    phase,
                    namespace: "suss.core".into(),
                    name: symbol.name.as_str().into(),
                }
            } else {
                own
            }
        };
        self.bindings
            .get(&global)
            .filter(|binding| !matches!(binding, Binding::InternalCell(_) | Binding::ReaderCell(_)))
            .cloned()
            .or_else(|| {
                if symbol.namespace.is_some() { return None; }
                let kind = crate::runtime_abi::numeric_classes::resolve(&symbol.name)?;
                let (namespace, name) = crate::runtime_abi::numeric_classes::NAMES[kind as usize].rsplit_once('.')?;
                Some(Binding::NumericClass { global: Global { phase, namespace: namespace.into(), name: name.into() }, kind })
            })
            .ok_or_else(|| Diagnostic {
                span,
                message: format!("Unresolved {phase:?} name {symbol}"),
            })
    }
}

/// Locate one source across all supported extensions/roots. Never pick by search order.
/// Canonical paths deduplicate the same file reached through multiple roots.
pub fn locate_source(
    namespace: &str,
    roots: &[impl AsRef<Path>],
    span: Range<usize>,
) -> Result<PathBuf, Diagnostic> {
    locate_source_if_present(namespace, roots, span.clone())?.ok_or_else(|| Diagnostic {
        span,
        message: format!("No source for namespace {}", canonical(namespace)),
    })
}

/// Absence alone permits an embedded-library fallback. Ambiguity, invalid names
/// and filesystem failures remain errors rather than becoming library successes.
pub(crate) fn locate_source_if_present(
    namespace: &str,
    roots: &[impl AsRef<Path>],
    span: Range<usize>,
) -> Result<Option<PathBuf>, Diagnostic> {
    valid_namespace(namespace).map_err(|mut error| {
        error.span = span.clone();
        error
    })?;
    let namespace = canonical(namespace);
    let relative = namespace.replace('.', "/").replace('-', "_");
    let mut matches = BTreeSet::new();
    for root in roots {
        for extension in ["sus", "cljs", "cljc"] {
            let path = root.as_ref().join(format!("{relative}.{extension}"));
            crate::build_cache::inputs::probe(&path);
            match path.canonicalize() {
                Ok(path) if path.is_file() => {
                    matches.insert(path);
                }
                Ok(path) => {
                    return Err(Diagnostic {
                        span,
                        message: format!("Namespace source is not a file: {}", path.display()),
                    });
                }
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                    match std::fs::symlink_metadata(&path) {
                        Err(missing) if missing.kind() == std::io::ErrorKind::NotFound => {
                            // A missing leaf beneath a broken directory link is
                            // a configured source error, not absent source.
                            for ancestor in path.ancestors().skip(1) {
                                if let Ok(metadata) = std::fs::symlink_metadata(ancestor) {
                                    if metadata.file_type().is_symlink() {
                                        crate::build_cache::inputs::probe(ancestor);
                                        if let Err(error) = ancestor.canonicalize() {
                                            return Err(Diagnostic {
                                                span,
                                                message: format!(
                                                    "Cannot resolve namespace source: {error}"
                                                ),
                                            });
                                        }
                                    }
                                }
                            }
                        }
                        _ => {
                            return Err(Diagnostic {
                                span,
                                message: format!("Cannot resolve namespace source: {error}"),
                            });
                        }
                    }
                }
                Err(error) => {
                    return Err(Diagnostic {
                        span,
                        message: format!("Cannot resolve namespace source: {error}"),
                    });
                }
            }
        }
    }
    match matches.len() {
        1 => Ok(Some(matches.into_iter().next().unwrap())),
        0 => Ok(None),
        _ => Err(Diagnostic {
            span,
            message: format!(
                "Ambiguous source for namespace {namespace}: {}",
                matches
                    .iter()
                    .map(|p| p.display().to_string())
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
        }),
    }
}
