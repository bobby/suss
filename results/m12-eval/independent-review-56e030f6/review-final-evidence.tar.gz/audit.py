import sys,json,hashlib,re,subprocess,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent
j=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
sys.path.insert(0,str(j/'scripts'));import clojure_test_suite as s
r={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=j,text=True).strip(),'review_base':'ac0b485ef0ff3f6dbd8364a6eb8fdb808440a613'}
assert r['head']=='56e030f6e139951f50640e8371a7a0ebc862f4e3'
ref=json.load(open(j/'tests/oracle/clojure-test-suite-observations.json'));capdir=j/'results/m12-eval/exact-workspace-reviewed-core-eval-disk-tmp/capture';cap=json.load(open(capdir/'suite-observations.json'))
r['fixture_sha256']=sha(j/'tests/oracle/clojure-test-suite-observations.json');assert r['fixture_sha256']=='449264ab6bca1dcf761d0204e4a64de4de91562e576615c4e84a63246839f4c7'
r['capture_sha256']=sha(capdir/'suite-observations.json')
r['suite_counts'],_=s.compare(ref,cap)
test='clojure.core-test.eval/test-eval';a=[x for x in cap['assertions'] if x['test']==test];w=[x for x in ref['assertions'] if x['test']==test]
assert [(x['test'],x['ordinal']) for x in a]==[(test,n) for n in range(1,35)]
assert [(x['test'],x['ordinal']) for x in a]==[(x['test'],x['ordinal']) for x in w]
d=[s.decide(x,y) for x,y in zip(w,a)];assert [i+1 for i,x in enumerate(d) if x[1]]==[15,16,17,18,19];assert all(x[0] is None for x in d)
r['eval']={'rows':34,'host_matches':29,'guest_ordinals':[15,16,17,18,19],'numeric_actual_rows':[x for x in a if x['ordinal'] in [5,6,7]]}
old=json.load(open(j/'results/native-host-foundation/exact-workspace-prepared-var-checkpoint/capture/suite-observations.json'))
rmap={(x['test'],x['ordinal']):x for x in ref['assertions']};new=[x for x in cap['assertions'] if x['test']!=test]
ids=lambda rows:[(x['test'],x['ordinal']) for x in rows]
assert len(old['assertions'])==len(new)==5530;assert ids(old['assertions'])==ids(new)
assert [s.decide(rmap[(x['test'],x['ordinal'])],x) for x in old['assertions']]==[s.decide(rmap[(x['test'],x['ordinal'])],x) for x in new]
r['prior_5530_ordered_ids_and_decisions_preserved']=True
assert subprocess.check_output(['git','diff','ac0b485e','HEAD','--','vendor/clojure-test-suite/upstream/test/clojure/core_test/eval.cljc'],cwd=j)==b''
r['original_eval_source_unchanged']=True
log=(j/'results/m12-eval/exact-workspace-reviewed-core-eval-disk-tmp/exact-two-thread-workspace.log').read_text();groups=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log,re.M)
r['raw_workspace_totals']={'groups':len(groups),'passed':sum(int(g[1]) for g in groups),'failed':sum(int(g[2]) for g in groups),'ignored':sum(int(g[3]) for g in groups)}
assert set(g[0] for g in groups)=={'ok'} and r['raw_workspace_totals']=={'groups':378,'passed':2694,'failed':0,'ignored':15}
r['baseline_head']='052668a3776a64fcc6ce58269ee5d0f524b315a1'
r['registration_repair']=json.load(open(j/'results/m12-eval/symbol-registration-repair-audit.json'))
assert r['registration_repair']['focused_passes']==8 and r['registration_repair']['focused_actual_exit']==0
primary={line.split('\t',1)[0]:line.split('\t',1)[1] for line in (p/'fresh-primary.stdout').read_text().splitlines()}
native=[line.split('\t',2) for line in (p/'native-probe.stdout').read_text().splitlines()]
assert len(primary)==15;assert len(native)==32
for phase,name,value in native:
 if name in primary: assert value==primary[name],(phase,name,value,primary[name])
 else: assert name=='host-rooted-live-var-and-old-closure' and value=='PASS'
r['independent_refined_probe']={'primary_controls':15,'phase_matches':30,'host_root_checks':2,'retained_values_after_gc':30,'comparison':'exact printed observations; host live-root checks use actual held SessionValues and runtime_number/sentinel inspection'}
receipts=json.load(open(p/'commands.json'));r['independent_actual_commands']=[{k:c[k] for k in ['name','exit_code','seconds']} for c in receipts['commands']]
assert receipts['complete'] and all(c['exit_code']==0 for c in receipts['commands'])
r['changed_frozen_probe_inputs']=[path for path,before in receipts['frozen_inputs'].items() if sha(path)!=before];assert not r['changed_frozen_probe_inputs']
r['probe_input_count']=len(receipts['frozen_inputs'])
r['source_baseline_differences']=receipts['baseline_differences'];assert r['source_baseline_differences']==['crates/suss-compile/tests/portable_symbol_conversion.rs','docs/roadmap/handoff.md']
r['complete']=True
(p/'independent-audit.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k not in ['registration_repair','eval']},indent=2))
