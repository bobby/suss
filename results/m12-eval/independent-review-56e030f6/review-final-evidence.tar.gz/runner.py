import hashlib,json,os,subprocess,time,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent
j=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
t=j.parent/'m12-some-fn-target/debug/deps'
b=j.parent/'m11-binaryen/binaryen-version_133/bin'
sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
head=lambda:subprocess.check_output(['git','rev-parse','HEAD'],cwd=j,text=True).strip()
inputs=json.load(open(j/'results/m12-eval/registered-public-var-symbol-controls/commands.json'))['inputs']
paths=[j/name for name in inputs]+[p/name for name in ['runner.py','probe.rs','primary.clj','cases.tsv']]
jarroot=Path('/home/bobby/.m2/repository/org/clojure')
jars=[jarroot/'clojure/1.12.6/clojure-1.12.6.jar',jarroot/'spec.alpha/0.5.238/spec.alpha-0.5.238.jar',jarroot/'core.specs.alpha/0.4.74/core.specs.alpha-0.4.74.jar']
paths += jars+[b/'wasm-opt',b/'wasm-merge',t/'libsuss_compile-d24d0e8fe0a40796.rlib',t.parent/'suss',t.parent/'.fingerprint/suss-compile-d24d0e8fe0a40796/lib-suss_compile.json']
r={'head_before':head(),'scope':'suss-review-516-refined-56e030f6','frozen_inputs':{str(x):sha(x) for x in paths},'commands':[]}
# Compare current production/tool inputs to the exact executed baseline; keep all differences explicit.
prior=json.load(open(j/'results/m12-eval/exact-workspace-reviewed-core-eval-disk-tmp/commands.json'))['inputs']
r['baseline_differences']=[name for name in inputs if name in prior and sha(j/name)!=prior[name]]
def save(): (p/'commands.json').write_text(json.dumps(r,indent=2)+'\n')
def run(name,args,timeout=500):
 item={'name':name,'command':list(map(str,args)),'start':time.time()};r['commands'].append(item);save()
 with (p/(name+'.stdout')).open('w') as out,(p/(name+'.stderr')).open('w') as err:
  process=subprocess.Popen(args,cwd=j,stdout=out,stderr=err);item['pid']=process.pid;save()
  try:item['exit_code']=process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:process.kill();item['exit_code']=process.wait();item['timeout']=True
 item['seconds']=time.time()-item['start'];save();print(name,item['exit_code'],item['seconds'],flush=True)
 return item['exit_code']
assert r['head_before']=='56e030f6e139951f50640e8371a7a0ebc862f4e3'
run('rustc-version',['rustc','+stable','--version'])
if run('compile-probe',['rustc','+stable','--edition=2024',p/'probe.rs','-L',f'dependency={t}','--extern',f'suss_compile={t}/libsuss_compile-d24d0e8fe0a40796.rlib','-o',p/'probe'])==0:
 r['compiled_probe_sha256']=sha(p/'probe');save()
 run('native-probe',[p/'probe',p/'cases.tsv'])
run('fresh-primary',['java','-Xmx512m','-cp',':'.join(map(str,jars)),'clojure.main',p/'primary.clj',p/'cases.tsv'])
r['head_after']=head();r['changed_inputs']=[str(x) for x in paths if sha(x)!=r['frozen_inputs'][str(x)]];r['complete']=True;save()
with tarfile.open(p/'inputs-and-receipts.tar.gz','w:gz') as ar:
 for name in ['runner.py','probe.rs','primary.clj','cases.tsv','commands.json','rustc-version.stdout','rustc-version.stderr','compile-probe.stdout','compile-probe.stderr','native-probe.stdout','native-probe.stderr','fresh-primary.stdout','fresh-primary.stderr']:
  file=p/name
  if file.exists():ar.add(file,arcname=name)
 for name in ['AGENTS.md','docs/design/suss-0.3.1.md','docs/runtime/host-macro-boundary.md','runtime/core-import/suss/core.sus','docs/compatibility/bootstrap/exact-integers.sus','crates/suss-compile/src/portable_session/evaluation.rs','crates/suss-compile/src/portable_macros/evaluation.rs','crates/suss-compile/src/runtime_abi/evaluation.rs','crates/suss-compile/src/portable_session/store_access.rs']:
  ar.add(j/name,arcname='frozen-source/'+name)
print('complete; conserved inputs:',not r['changed_inputs'],flush=True)
