(require '[clojure.string :as str])
(doseq [line (str/split-lines (slurp (first *command-line-args*)))] (let [[n source] (str/split line #"\t" 2)] (try (let [value (eval (read-string source))] (println (str n "\t" (pr-str value)))) (catch Throwable e (println (str n "\tERROR " (.getMessage e)))))))
