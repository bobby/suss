use suss_compile::{portable_session::{Session, runtime_number, RuntimeNumber, sentinel_tag},portable_macros::CompiledMacros,portable_repl};
fn main(){
 let inputs=std::fs::read_to_string(std::env::args().nth(1).unwrap()).unwrap();
 for mut session in [Session::new_repl().unwrap(), Session::new_macro().unwrap()] {
  let phase=format!("{:?}",session.phase());
  let mut macros=CompiledMacros::new().unwrap();
  let mut retained=Vec::new();
  for line in inputs.lines(){let (name,source)=line.split_once('\t').unwrap();
   let source=source.replace("(catch Throwable ","(catch :default ");
   match session.eval_with_macros(&source,&mut macros){
    Ok(v)=>{ session.collect().unwrap(); let text=portable_repl::display(&mut session,&v).unwrap(); println!("{phase}\t{name}\t{text}");retained.push((name.to_owned(),text,v)); },
    Err(e)=>println!("{phase}\t{name}\tERROR {}",portable_repl::error_display(&mut session,&e)),
   }
  }
  session.collect().unwrap();
  for (name,text,v) in retained{assert_eq!(portable_repl::display(&mut session,&v).unwrap(),text,"{phase} {name} retained after GC");}
  let original=session.eval_with_macros("(eval '(def review-host-held 11))",&mut macros).unwrap();
  let read=session.eval_with_macros("(eval '(fn [] review-host-held))",&mut macros).unwrap();
  session.eval_with_macros("(eval '(def review-host-held 42))",&mut macros).unwrap();
  let returned=session.eval_with_macros("(eval '(var review-host-held))",&mut macros).unwrap();
  let same=session.eval("(fn [a b] (identical? a b))").unwrap();
  drop(macros);session.collect().unwrap();
  let number=session.invoke(&read,&[]).unwrap();
  assert_eq!(session.inspect(&number,|mut s,v|runtime_number(&mut s,&v)).unwrap(),Some(RuntimeNumber::Long(42)));
  let identity=session.invoke(&same,&[&original,&returned]).unwrap();
  assert_eq!(session.inspect(&identity,|mut s,v|sentinel_tag(&mut s,&v)).unwrap(),Some(suss_compile::runtime_abi::TRUE as u32));
  println!("{phase}\thost-rooted-live-var-and-old-closure\tPASS");
 }
}
