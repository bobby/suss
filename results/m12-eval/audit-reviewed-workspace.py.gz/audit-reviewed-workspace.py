"""Audit the existing eval full run only after actual success and archival."""
from pathlib import Path
import gzip, hashlib, json, re, subprocess, sys

E = Path(__file__).resolve().parent
J = Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
C = E.parent / 'native-host-var-foundation'
phase = sys.argv[1] if len(sys.argv)>1 else 'exact-workspace-reviewed-core-eval-disk-tmp'
P = J / 'results/m12-eval' / phase
r = json.loads((P / 'commands.json').read_text())
assert r['complete'] and r['exit_code'] == 0, 'actual successful terminal required'
assert r['head'] == '052668a3776a64fcc6ce58269ee5d0f524b315a1'
assert r['inputs_unchanged'] and r['binaryen_unchanged']
assert len(r['commands']) == 1
command = r['commands'][0]
assert command['complete'] and command['exit_code'] == 0
assert command['command'] == ['cargo', 'test', '--workspace', '--locked', '--', '--test-threads=2']
assert hashlib.sha256(gzip.decompress((P / 'runner.py.gz').read_bytes())).hexdigest() == r['runner_sha256']
assert json.loads((P / 'deleted.json').read_text()) == []
def totals(p):
    text = p.read_text()
    rows = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    assert rows and not re.search(r'^test result: FAILED', text, re.M)
    assert not any(int(row[1]) for row in rows)
    return {'passed': sum(int(x[0]) for x in rows), 'ignored': sum(int(x[2]) for x in rows), 'groups': len(rows)}
baseline = C / 'results/native-host-foundation/exact-workspace-prepared-var-checkpoint'
br = json.loads((baseline / 'commands.json').read_text())
assert br['complete'] and br['exit_code'] == 0 and br['inputs_unchanged'] and br['binaryen_unchanged']
before = totals(baseline / 'exact-two-thread-workspace.log')
after = totals(P / 'exact-two-thread-workspace.log')
# The consumer adds these test declarations; the new eval target also includes
# two existing shared decoder guards. Existing target ignores remain unchanged.
files = ['crates/suss-cli/tests/clojure_eval.rs',
    'crates/suss-cli/tests/compiled_native_entrypoints.rs',
    'crates/suss-cli/tests/compiled_repl_macros.rs',
    'crates/suss-compile/tests/portable_symbol_conversion.rs',
    'crates/suss-compile/tests/support/pinned_eval_body.rs',
    'crates/suss-compile/src/portable_macros/facade.rs',
    'crates/suss-compile/src/portable_macros/native_invocation.rs',
    'crates/suss-compile/src/portable_session/evaluation/native_values.rs']
added = {}
for name in files:
    old = subprocess.run(['git', 'show', br['head'] + ':' + name], cwd=J, capture_output=True)
    assert old.returncode == 0 or name in [files[0], files[4]]
    current = subprocess.check_output(['git', 'show', r['head'] + ':' + name], cwd=J, text=True)
    old_names = set(re.findall(r'#\[test\]\s*fn (\w+)\(', old.stdout.decode())) if old.returncode == 0 else set()
    current_names = set(re.findall(r'#\[test\]\s*fn (\w+)\(', current))
    assert old_names <= current_names
    added[name] = sorted(current_names - old_names)
assert [len(added[n]) for n in files] == [88, 5, 2, 2, 3, 1, 1, 1]
full_log = (P / 'exact-two-thread-workspace.log').read_text()
unregistered = [name for names in added.values() for name in names
    if not re.search(r'^test (?:\w+::)*' + re.escape(name) + r' \.\.\. ok$', full_log, re.M)]
assert sorted(unregistered) == sorted([
    'retained_var_keeps_thunk_lookup_metadata_equality_hash_and_invocation_arities',
    'retained_identifier_dependency_matches_shared_pinned_corpus_in_both_phases'])
assert full_log.count('warning: cannot test inner items') == 2
assert after == {'passed': before['passed'] + sum(map(len, added.values())) - len(unregistered) + 2,
                 'ignored': before['ignored'], 'groups': before['groups'] + 1}, (before, after)
# Reuse the strict body/capture audit against this fresh full-run output. Only
# its phase/output destination change; the exact same comparator and invariants run.
auditor = (E / 'audit-eval-reviewed-core-native.py').read_text()
start = auditor.index("assert r['complete']")
stop = auditor.index('sys.path.insert')
auditor = auditor[:start] + auditor[stop:]
auditor = auditor.replace("reviewed-core-public-controls-after-generator-refresh", phase)
auditor = auditor[:auditor.index("out = {'source_head'")]
scope = {'__file__': str(E / 'audit-eval-reviewed-core-native.py')}
exec(compile(auditor, str(E / 'audit-eval-reviewed-core-native.py'), 'exec'), scope)
out = {'head': r['head'], 'phase': r['phase'], 'actual_exit': 0,
    'auditor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'command': command['command'], 'seconds': command['seconds'],
    'frozen_input_count': len(r['inputs']), 'inputs_head_runner_binaryen_conserved': True,
    'runner_archive_verified': True, 'deleted_inputs': [],
    'foundation_totals': before, 'current_totals': after,
    'additional_test_declarations': added, 'additional_shared_decoder_executions': 2,
    'declared_but_unregistered_regressions': unregistered,
    'capture_sha256': hashlib.sha256((P / 'capture/suite-observations.json').read_bytes()).hexdigest(),
    'prior_5530_ordered_decisions_preserved': True,
    'original_eval_body': {'rows': 34, 'host_matches': 29, 'original_guest_ordinals': [15,16,17,18,19], 'numeric_independent_host_matches': [5,6,7]},
    'counts': scope['counts'], 'failure_ledger_exact': True,
    'qualification': 'Exact successful baseline on052668a3 and fresh capture only. Two added nested test functions were not registered in this binary and require a separately executed registration repair before review. Full-command passes are2694, not2696. Independent promotion review and final published-head CI require separate evidence. Numeric acceptance remains in its own consumer.'}
(E / 'eval-reviewed-exact-workspace-audit.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({k:v for k,v in out.items() if k != 'additional_test_declarations'}, indent=2))
