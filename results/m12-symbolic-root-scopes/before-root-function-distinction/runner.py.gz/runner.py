"""Record actual negative/positive targeted executions with frozen sources."""
from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,time
K=Path(__file__).resolve().parent;F=K.parent/'m12-numeric-completion'
head,phase,mode=sys.argv[1:];assert mode in ['before','after']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=F,text=True)
scope=os.environ['SUSS_DURABLE_SCOPE'];assert scope in Path('/proc/self/cgroup').read_text()
prior=json.loads((F/'results/m12-symbolic-regions/after-enclosing-function-pool/commands.json').read_text())
assert prior['complete'] and prior['exit_code']==0 and prior['runner_archived']
assert prior['inputs_unchanged'] and prior['head_unchanged']
assert not Path('/proc/'+str(prior['recorder_pid'])).exists()
tracked=set(subprocess.check_output(['git','ls-files'],cwd=F,text=True).splitlines())
paths=set(subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=F,text=True).splitlines())
paths={p for p in paths if p in tracked or not p.startswith('results/') or ('/overlay/' not in p and '/source-overlay/' not in p and (any('primary' in a for a in Path(p).parts) or p.endswith(('cases.json','reference.json'))))}
inputs={p:sha(F/p) for p in sorted(paths) if (F/p).is_file()}
binaryen=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m11-binaryen/binaryen-version_133/bin')
tools={str(binaryen/n):sha(binaryen/n) for n in ['wasm-opt','wasm-merge']}
out=F/'results/m12-symbolic-root-scopes'/phase;out.mkdir(exist_ok=False)
temp=K/'numeric-test-temp'/phase;temp.mkdir(exist_ok=False,mode=0o700)
r={'head':head,'phase':phase,'mode':mode,'scope':scope,'recorder_pid':os.getpid(),'inputs':inputs,'binaryen':tools,'runner_sha256':sha(Path(__file__)),'commands':[],'complete':False}
env=os.environ|{'CARGO_TARGET_DIR':str(F.parent/'pattern-compiled-target'),'TMPDIR':str(temp),'CARGO_BUILD_JOBS':'1','RUSTUP_TOOLCHAIN':'stable','BINARYEN_CORES':'1','SUSS_WASM_OPT':str(binaryen/'wasm-opt')};env['PATH']=str(binaryen)+os.pathsep+env['PATH']
def conserved():
 return subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip()==head and all((F/p).is_file() and sha(F/p)==h for p,h in inputs.items()) and sha(Path(__file__))==r['runner_sha256']
def save():(out/'commands.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,command):
 assert conserved()
 row={'name':label,'command':command,'complete':False};r['commands'].append(row);save();start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:
  proc=subprocess.Popen(command,cwd=F,env=env,stdout=log,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
 row.update(complete=True,exit_code=code,seconds=time.monotonic()-start);save()
 if code and mode=='after':raise RuntimeError(f'{label} actual exit {code}')
try:
 save()
 targets=['clojure_symbolic_numeric_root_scopes'] if mode=='before' else ['clojure_symbolic_numeric_root_scopes','clojure_symbolic_numeric_regions','clojure_symbolic_numeric_arities','clojure_numeric_literal_identity','clojure_number_source_objects','clojure_num_api','compiled_macro_cumulative_fuel','compiled_macro_fuel_stages','clojure_eval','portable_symbol_conversion']
 command=['cargo','test','--workspace','--locked']
 for target in targets:command+=['--test',target]
 run('symbolic-arity-and-source-contexts',command+['--','--nocapture','--test-threads=2'])
 run('async-root-scope-guard',['cargo','test','--workspace','--locked','--test','portable_async_execution','source_constant_pools_distinguish_async_root_replacement_and_thread_binding','--','--nocapture','--test-threads=2'])
 if mode=='after':run('literal-alias-partition-cache',['cargo','test','--workspace','--locked','--lib','source_cache_distinguishes_literal_site_alias_partitions_without_pointer_keys','--','--nocapture','--test-threads=2'])
except Exception as exc:r['controller_error']=repr(exc)
finally:
 r.update(complete=True,inputs_unchanged=conserved(),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip()==head,binaryen_unchanged=all(sha(Path(p))==h for p,h in tools.items()))
 r['exit_code']=next((c['exit_code'] for c in r['commands'] if c.get('exit_code')),1 if 'controller_error' in r else 0)
 if not r['inputs_unchanged'] or not r['binaryen_unchanged']:r['exit_code']=r['exit_code'] or 1
 save()
 if r['inputs_unchanged'] and r['binaryen_unchanged']:
  (out/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
  for p in inputs.keys()-tracked:
   dest=out/'source-overlay'/(p+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress((F/p).read_bytes(),mtime=0))
  (out/'deleted.json').write_text('[]\n');r['runner_archived']=True;save()
 print(json.dumps({k:v for k,v in r.items() if k not in ['inputs']},indent=2),flush=True)
sys.exit(r['exit_code'])
