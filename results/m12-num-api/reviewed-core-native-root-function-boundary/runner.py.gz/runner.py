"""Run numeric acceptance serially after the active eval full run terminates."""
from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys, time

E = Path(__file__).resolve().parent
F = E.parent / 'm12-numeric-completion'
J = Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
expected_head, phase = sys.argv[1:]
prior = J / 'results/m12-eval/exact-workspace-reviewed-core-eval-disk-tmp'
jr = json.loads((prior / 'commands.json').read_text())
assert jr['complete'] and jr['exit_code'] == 0, 'Finish the existing eval full run; never start a second heavy job.'
assert (prior / 'runner.py.gz').is_file() and (prior / 'deleted.json').is_file()
assert not Path(f"/proc/{jr['recorder_pid']}").exists(), 'Prior recorder must actually terminate.'
registration = J / 'results/m12-eval/registered-public-var-symbol-controls'
rr = json.loads((registration / 'commands.json').read_text())
assert rr['complete'] and rr['exit_code'] == 0 and rr['inputs_unchanged'] and rr['binaryen_unchanged']
assert rr['runner_archived'] and len(rr['registered_test_names']) == 8
assert not Path(f"/proc/{rr['recorder_pid']}").exists()
assert hashlib.sha256(gzip.decompress((registration / 'runner.py.gz').read_bytes())).hexdigest() == rr['runner_sha256']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=F, text=True).strip()
assert head == expected_head
assert subprocess.run(['git','merge-base','--is-ancestor',rr['head'],head],cwd=F).returncode == 0, 'Integrate the actually tested registration repair before numeric validation.'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=F, text=True)
admission_path = E / 'numeric-reviewed-core-current-source-admission.json'
admission = json.loads(admission_path.read_text())
assert admission['head'] == head and [len(i['requirements']) for i in admission['issues']] == [9,6]
assert admission['all_case_file_blobs_conserved']
assert admission['symbolic_arity_regression']['pinned_primary_controls'] == 10
assert len(admission['symbolic_arity_regression']['declared_test_names']) == 2
assert admission['symbolic_region_regression']['pinned_primary_controls'] == 9
assert len(admission['symbolic_region_regression']['declared_test_names']) == 2
assert admission['symbolic_root_scope_regression']['pinned_primary_controls'] == 3
assert len(admission['symbolic_root_scope_regression']['declared_test_names']) == 2
assert admission['symbolic_root_scope_regression']['original_async_target_conserved']
assert len(admission['published_ci_regression_sources']) == 2
assert admission['new_macro_stage_regression']['declared_test_names'] == ['exhausted_transformer_lookup_retains_expansion_stage_effects_and_recovery']
affected_path = F/'results/m12-symbolic-root-scopes/after-root-function-distinction/commands.json'
affected = json.loads(affected_path.read_text())
assert affected['head'] == head and affected['complete'] and affected['exit_code'] == 0
assert affected['inputs_unchanged'] and affected['head_unchanged'] and affected['binaryen_unchanged'] and affected['runner_archived']
assert all(c['complete'] and c['exit_code'] == 0 for c in affected['commands'])
assert not Path(f"/proc/{affected['recorder_pid']}").exists()
assert hashlib.sha256(gzip.decompress((affected_path.parent/'runner.py.gz').read_bytes())).hexdigest() == affected['runner_sha256']
assert all((F/p).is_file() and hashlib.sha256((F/p).read_bytes()).hexdigest() == h for p,h in affected['inputs'].items())
scope = os.environ['SUSS_DURABLE_SCOPE']
assert scope in Path('/proc/self/cgroup').read_text()
temp_root = E / 'numeric-test-temp' / phase
temp_root.mkdir(parents=True,exist_ok=False,mode=0o700)
out = F / 'results/m12-num-api' / phase
out.mkdir(exist_ok=False)
capture = out / 'complete-capture'
capture.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
tracked = set(subprocess.check_output(['git','ls-files'], cwd=F, text=True).splitlines())
paths = set(subprocess.check_output(['git','ls-files','-co','--exclude-standard'], cwd=F, text=True).splitlines())
paths = {p for p in paths if p in tracked or not p.startswith('results/') or
    ('/overlay/' not in p and '/source-overlay/' not in p and
     (any('primary' in a for a in Path(p).parts) or p.endswith(('cases.json','reference.json'))))}
inputs = {p: sha(F/p) for p in sorted(paths) if (F/p).is_file()}
binaryen = J.parent / 'm11-binaryen/binaryen-version_133/bin'
tools = {str(binaryen/n):sha(binaryen/n) for n in ['wasm-opt','wasm-merge']}
external = {str(admission_path):sha(admission_path), str(affected_path):sha(affected_path)}
r = {'head':head, 'phase':phase, 'scope':scope, 'recorder_pid':os.getpid(),
    'temporary_directory':str(temp_root),
    'inputs':inputs, 'binaryen':tools, 'external_tools':external,
    'runner_sha256':sha(Path(__file__)), 'commands':[], 'complete':False}
env = os.environ | {'CARGO_TARGET_DIR':str(E.parent/'pattern-compiled-target'),
    'TMPDIR':str(temp_root),
    'CARGO_BUILD_JOBS':'1', 'RUSTUP_TOOLCHAIN':'stable', 'BINARYEN_CORES':'1',
    'SUSS_WASM_OPT':str(binaryen/'wasm-opt'),
    'SUSS_CLOJURE_TEST_SUITE_CAPTURE':str(capture/'suite-capture'),
    'SUSS_NUMERIC_BODY_CAPTURE':str(capture/'suite-capture'),
    'SUSS_EVAL_BODY_CAPTURE':str(capture/'suite-capture')}
env['PATH'] = str(binaryen) + os.pathsep + env['PATH']
env.pop('SUSS_CLOJURE_TEST_SUITE_WRITE', None)
suite_receipt = {'head':head, 'inputs':inputs, 'commands':[], 'complete':False}
def save():
    (out/'commands.json').write_text(json.dumps(r,indent=2)+'\n')
def conserved():
    return (subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip()==head
        and all((F/p).is_file() and sha(F/p)==h for p,h in inputs.items())
        and sha(Path(__file__))==r['runner_sha256']
        and all(sha(Path(p))==h for p,h in external.items()))
def save_suite():
    (capture/'suite-commands.json').write_text(json.dumps(suite_receipt,indent=2)+'\n')
def run(name, command, suite=False):
    assert conserved(), 'Frozen inputs changed before command.'
    log_dir = capture if suite else out
    row = {'name':name, 'command':command, 'complete':False,
        'env_overrides':{'TMPDIR':str(temp_root)},
        'log':str((log_dir/(name+'.log')).relative_to(out))}
    r['commands'].append(row); save(); start=time.monotonic()
    with (log_dir/(name+'.log')).open('w') as log:
        proc=subprocess.Popen(command,cwd=F,env=env,stdout=log,stderr=subprocess.STDOUT)
        row['pid']=proc.pid;save();code=proc.wait()
    row.update(complete=True,exit_code=code,seconds=time.monotonic()-start);save()
    if suite:
        suite_receipt['commands'].append({'label':name,'command':command,
            'exit_code':code,'seconds':row['seconds']});save_suite()
    print({k:v for k,v in row.items() if k!='command'},flush=True)
    if code: raise RuntimeError(f'{name} failed with actual exit {code}')
try:
    save()
    # Reproduce the actual older published-head failure before the broad
    # numeric controls; retain both failing tests and their original budgets.
    run('published-ci-macro-fuel-regressions',
        ['cargo','test','--workspace','--locked','--test','compiled_macro_cumulative_fuel',
         '--test','compiled_macro_fuel_stages',
         '--','--nocapture','--test-threads=2'])
    targets = sorted({Path(n).stem for n in admission['mapped_declared_test_names']}
        | {Path(n).stem for n in admission['supplemental_numeric_api_and_reader_targets']}
        | {'decimal_values','numeric_operand_types','clojure_numeric_literal_identity',
           'clojure_numeric_box_reuse','native_host_boundary','portable_symbol_conversion','clojure_symbolic_numeric_arities','clojure_symbolic_numeric_regions','clojure_symbolic_numeric_root_scopes'})
    command=['cargo','test','--workspace','--locked']
    for target in targets: command += ['--test',target]
    run('complete-numeric-criteria-and-core-regressions',command+['--','--nocapture','--test-threads=2'])
    run('host-library-ownership-and-transport',['cargo','test','--workspace','--locked','--lib','portable_','--','--nocapture','--test-threads=2'])
    run('optimized-random-effect-guard',['cargo','test','--workspace','--locked','--test','portable_random','optimized_selected_random_import_preserves_draws','--','--include-ignored','--nocapture','--test-threads=2'])
    run('suite-build',['cargo','test','--workspace','--locked','--test','clojure_test_suite','--no-run','--message-format=json'],suite=True)
    artifacts=[]
    for line in (capture/'suite-build.log').read_text().splitlines():
        try: artifacts.append(json.loads(line))
        except ValueError: pass
    executable=next(a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='clojure_test_suite' and a.get('executable'))
    suite_receipt['executable_sha256']=sha(Path(executable));save_suite()
    run('suite-run',[executable,'--nocapture','--test-threads=2'],suite=True)
    assert sha(Path(executable))==suite_receipt['executable_sha256']
    run('suite-lock',['python3','scripts/clojure_test_suite.py'],suite=True)
    suite_receipt.update(complete=True,inputs_unchanged=conserved());save_suite()
    run('strict-integrated-capture',['python3','results/m12-num-api/review-integrated-capture.py',str(capture)])
    run('java-node-free-bootstrap',['sh','scripts/verify-bootstrap.sh'])
    run('eval-source-provenance',['python3','results/m12-eval/verify-live-vars.py'])
    run('core-import-source-provenance',['python3','scripts/core_import.py','--check'])
except Exception as exc:
    r['controller_error']=repr(exc)
finally:
    r.update(complete=True,inputs_unchanged=conserved(),
        head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip()==head,
        binaryen_unchanged=all(sha(Path(p))==h for p,h in tools.items()),
        external_tools_unchanged=all(sha(Path(p))==h for p,h in external.items()))
    r['exit_code']=next((c['exit_code'] for c in r['commands'] if c.get('exit_code')),1 if 'controller_error' in r else 0)
    if not suite_receipt['complete']:
        suite_receipt.update(complete=True,inputs_unchanged=conserved());save_suite()
    save()
    # Archive actual terminal inputs before a caller can edit the worktree.
    if r['inputs_unchanged'] and r['binaryen_unchanged'] and r['external_tools_unchanged']:
        (out/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
        (out/'source-admission.json.gz').write_bytes(gzip.compress(admission_path.read_bytes(),mtime=0))
        for name in inputs.keys() - tracked:
            assert sha(F/name)==inputs[name]
            archived=out/'source-overlay'/(name+'.gz')
            archived.parent.mkdir(parents=True,exist_ok=True)
            archived.write_bytes(gzip.compress((F/name).read_bytes(),mtime=0))
        (out/'deleted.json').write_text('[]\n')
        r['runner_archived']=True;save()
    print(json.dumps({k:v for k,v in r.items() if k not in ['inputs','commands']},indent=2),flush=True)
sys.exit(r['exit_code'])
