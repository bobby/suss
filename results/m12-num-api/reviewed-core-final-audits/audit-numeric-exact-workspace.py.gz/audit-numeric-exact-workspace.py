"""Audit the actual terminal numeric workspace run and its fresh full capture.

Reads the genuine cargo workspace receipt directly. Never invents a suite-only
producer receipt or converts an observer timeout into terminal success.
"""
from pathlib import Path
import collections, gzip, hashlib, json, re, subprocess, sys
K=Path(__file__).resolve().parent
F=K.parent/'m12-numeric-completion'
phase=F/'results/m12-num-api'/sys.argv[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((phase/'commands.json').read_text())
assert r['complete'] and r['exit_code']==0 and r['runner_archived']
assert all(r[k] for k in ['inputs_unchanged','head_unchanged','binaryen_unchanged','external_tools_unchanged'])
assert not Path(f"/proc/{r['recorder_pid']}").exists()
assert len(r['commands'])==1
command=r['commands'][0]
assert command['complete'] and command['exit_code']==0
assert command['command']==['cargo','test','--workspace','--locked','--','--test-threads=2']
assert not Path(f"/proc/{command['pid']}").exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip()
assert head==r['head']
assert all((F/p).is_file() and sha(F/p)==h for p,h in r['inputs'].items())
assert all(Path(p).is_file() and sha(Path(p))==h for p,h in (r['binaryen']|r['external_tools']).items())
assert hashlib.sha256(gzip.decompress((phase/'runner.py.gz').read_bytes())).hexdigest()==r['runner_sha256']
assert json.loads((phase/'deleted.json').read_text())==[]
log=phase/'exact-two-thread-workspace.log';text=log.read_text()
assert 'cannot test inner items' not in text
summaries=[tuple(map(int,m)) for m in re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)]
assert summaries and all(failed==0 for _,failed,_ in summaries)
assert 'test result: FAILED' not in text
# Check actual target registration and execution for the acceptance maps.
# Cargo can execute identically named integration targets in different crates.
# Preserve each execution separately; acceptance targets must be unambiguous.
groups=collections.defaultdict(list);current=None
for line in text.splitlines():
 m=re.match(r'\s*Running tests/(\w+)\.rs \(',line)
 if m:
  current={'passed':[],'ignored':[]};groups[m[1]].append(current)
 elif re.match(r'\s*(Running unittests|Doc-tests)',line):current=None
 m=re.match(r'test ([\w:]+) \.\.\. (ok|ignored)(?:$|,)',line)
 if m and current is not None:current['passed' if m[2]=='ok' else 'ignored'].append(m[1])
 m=re.match(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)
 if m and current is not None:current['summary']=list(map(int,m.groups()))
def unique_group(name):
 executions=groups[name]
 assert len(executions)==1,(name,len(executions))
 return executions[0]
admission=json.loads((K/'numeric-reviewed-core-current-source-admission.json').read_text())
assert admission['head']==head
mapped={}
for issue in admission['issues']:
 for criterion in issue['requirements']:
  for target in criterion['mapped_target_sources']:
   name=target['source'];g=unique_group(Path(name).stem)
   assert sha(F/name)==target['sha256']==r['inputs'][name]
   assert set(target['declared_test_names'])<=set(g['passed']),name
   mapped[name]={'source_sha256':target['sha256'],'declared_tests_actually_passed':target['declared_test_names']}
for target,count in {'native_host_boundary':51,'runtime_namespaces':10,'portable_symbol_conversion':8,'clojure_eval':90,'clojure_test_suite':24,'compiled_macro_cumulative_fuel':8,'compiled_macro_fuel_stages':1,'clojure_symbolic_numeric_arities':2,'clojure_symbolic_numeric_regions':2,'clojure_symbolic_numeric_root_scopes':2}.items():
 g=unique_group(target)
 assert g['summary']==[count,0,0],(target,g)
assert 'exhausted_expansion_preserves_effects_already_executed_in_the_macro_store' in unique_group('compiled_macro_cumulative_fuel')['passed']
assert 'completed_macro_work::cumulative_exhaustion_follows_multiple_completed_guest_helpers_and_recovers' in unique_group('compiled_macro_cumulative_fuel')['passed']
# Fresh full capture: exact original ordering, prior successful judgments,
# original comparison and reviewed failures, plus every numeric tagged row.
sys.path.insert(0,str(F/'scripts'));import clojure_test_suite as suite
sys.path.insert(0,str(F/'results/m12-num-api'));from reviewed_root_diagnostics import advance_root_diagnostics
capture=phase/'capture/suite-observations.json'
observed=json.loads(capture.read_bytes())
primary_path=F/'tests/oracle/clojure-test-suite-observations.json'
primary=json.loads(primary_path.read_bytes())
assert sha(primary_path)=='449264ab6bca1dcf761d0204e4a64de4de91562e576615c4e84a63246839f4c7'
assert sha(F/'scripts/clojure_test_suite.py')=='197166b70c16a1bc5e7a82d5061b069b5ba7a45453056a014704b1c345de617b'
old_path=F/'results/m12-num-api/full-suite-after-source-inline/capture/suite-capture/suite-observations.json'
old=json.loads(old_path.read_bytes() if old_path.exists() else gzip.decompress(old_path.with_name(old_path.name+'.gz').read_bytes()))
assert [(x['test'],x['ordinal']) for x in observed['assertions']]==[(x['test'],x['ordinal']) for x in old['assertions']]
counts,failures=suite.compare(primary,observed)
old_counts,old_failures=suite.compare(primary,old)
assert counts==old_counts and failures==advance_root_diagnostics(old_failures)
assert failures==json.loads((F/'tests/oracle/clojure-test-suite-known-failures.json').read_bytes())
assert len(observed['assertions'])==5750
reference={x['id']:x for x in primary['assertions']}
actual={x['test']+'#'+str(x['ordinal']):x for x in observed['assertions']}
preserved=0
for row in old['assertions']:
 identity=row['test']+'#'+str(row['ordinal'])
 if identity in reference:
  decision=suite.decide(reference[identity],row)
  if decision[0] is None:
   assert suite.decide(reference[identity],actual[identity])==decision,identity
   preserved+=1
def tagged(node,tags):
 if isinstance(node,dict):return node.get('tag') in tags or any(tagged(v,tags) for v in node.values())
 return isinstance(node,list) and any(tagged(v,tags) for v in node)
matches={}
for name,tags,total in [('bigint-ratio',{'bigint','biginteger','ratio'},229),('decimal',{'decimal'},200)]:
 selected=[x for x in primary['assertions'] if tagged(x,tags)]
 assert len(selected)==total and all(suite.decide(x,actual[x['id']])==(None,False) for x in selected)
 matches[name]=total
out=K/('numeric-'+phase.name+'-audit');out.mkdir(exist_ok=False)
# Apply the exact committed independent default26 checker to a view of the
# full capture, with its three explicit narrow-number class distinctions.
checker=F/'crates/suss-compile/tests/support/pinned_numeric_source_bodies.rs'
s=checker.read_text();a=s.index('fn complete_default_num_body_retains_numeric_rows_and_explicit_narrow_platform_differences()');a=s.index('arg(r#"',a)+len('arg(r#"');b=s.index('"#)',a);code=s[a:b]
test='clojure.core-test.num/test-num';namespace='clojure.core-test.num'
view={**observed,'assertions':[x for x in observed['assertions'] if x['test']==test],
 'namespaces':[x for x in observed['namespaces'] if x['namespace']==namespace],
 'test-failures':[x for x in observed['test-failures'] if x['test']==test],
 'skips':[x for x in observed['skips'] if x['namespace']==namespace]}
view_path=out/'actual-full-capture-num-view.json';view_path.write_text(json.dumps(view,indent=2)+'\n')
(out/'exact-committed-default26-checker.py').write_text(code)
checked=subprocess.run(['python3','-c',code,str(F),str(view_path)],cwd=F,capture_output=True,text=True)
(out/'default26-stdout.log').write_text(checked.stdout);(out/'default26-stderr.log').write_text(checked.stderr)
assert checked.returncode==0,checked.stderr
# Supplemental lexical audit conserves the entire existing candidate set and
# every prior nonhost observation; it does not manufacture host judgments.
pat=re.compile(r'(?<![A-Za-z_])(?:[-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?[NM]\b|[-+]?\d+/\d+\b)|(?<![\w-])(?:bigint|biginteger|bigdec|decimal\?|ratio\?|rational\?|rationalize|numerator|denominator|with-precision|BigInt|BigInteger|BigDecimal|Ratio)(?![\w-])')
selected=[x for x in primary['assertions'] if pat.search(x['form'])]
tally=collections.Counter();attention=[]
for row in selected:
 got=actual.get(row['id']);decision=None
 if got is None:kind='unexecuted'
 else:
  reason,guest=suite.decide(row,got);decision=(reason,guest);kind='failure' if reason is not None else 'guest' if guest else 'host'
 tally[kind]+=1
 if kind!='host':attention.append({'id':row['id'],'kind':kind,'form':row['form'],'decision':decision})
legacy=json.loads((K.parent/'numeric-source-form-acceptance-audit-v2.json').read_bytes())
assert [x['id'] for x in selected]==legacy['selected_ids']
assert len(selected)==1250 and dict(tally)=={'host':1240,'guest':8,'failure':2}
assert json.loads(json.dumps(attention))==legacy['attention']
report={'head':head,'actual_workspace_exit':0,'command':command['command'],'seconds':command['seconds'],
 'receipt_sha256':sha(phase/'commands.json'),'log_sha256':sha(log),'runner_sha256':r['runner_sha256'],
 'passing_test_executions':sum(x[0] for x in summaries),'successful_test_groups':len(summaries),
 'ignored_executions':sum(x[2] for x in summaries),'frozen_input_count':len(r['inputs']),
 'parsed_integration_target_executions':sum(map(len,groups.values())),
 'repeated_integration_target_names':{name:len(rows) for name,rows in groups.items() if len(rows)>1},
 'mapped_acceptance_target_executions':mapped,'capture_sha256':sha(capture),'ordered_observations':5750,
 'counts':counts,'preserved_prior_successful_decisions':preserved,'numeric_tagged_host_matches':matches,
 'default26_exact_checker_exit':checked.returncode,'default26_checker_source_sha256':sha(checker),
 'default26_projected_view_sha256':sha(view_path),'default26_qualification':'23 host matches and three explicit existing narrow-number class distinctions at ordinals7/8/9. Original global JVM/clj18 comparison unchanged.',
 'supplemental_lexical_candidates':1250,'lexical_classification':dict(tally),'lexical_attention':attention,
 'qualification':'Actual complete workspace terminal0 on this head and frozen source, plus fresh complete capture preserving all original identities and judgments. Residual132 global failures, guest judgments, unexecuted dependencies and profile differences remain explicit. Independent review and final published-head CI remain required.',
 'auditor_sha256':sha(Path(__file__))}
assert all(sha(F/p)==h for p,h in r['inputs'].items())
(out/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['mapped_acceptance_target_executions','lexical_attention']},indent=2))
