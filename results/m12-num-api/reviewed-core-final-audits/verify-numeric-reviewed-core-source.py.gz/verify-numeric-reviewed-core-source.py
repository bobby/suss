"""Admit the current numeric source without reusing a stale-head test claim."""
from pathlib import Path
import copy, datetime, hashlib, json, re, subprocess, sys

E = Path(__file__).resolve().parent
F = E.parent / 'm12-numeric-completion'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=F, text=True).strip()
expected_head = sys.argv[1] if len(sys.argv) == 2 else 'af007facae80f96e325106a2e4db322396204719'
assert head == expected_head
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=F, text=True)
old = json.loads((E.parent / 'numeric-869abf42-scope-audit.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
protected = {'primary': 'tests/oracle/clojure-test-suite-observations.json',
             'baseline': 'tests/oracle/clojure-test-suite-known-failures.json',
             'comparator': 'scripts/clojure_test_suite.py'}
for key, name in protected.items():
    assert sha((F / name).read_bytes()) == old['protected'][key], name
issues = copy.deepcopy(old['issues'])
targets = {}
for issue in issues:
    fresh = json.loads(subprocess.check_output(['gh', 'issue', 'view', str(issue['number']), '--repo', 'bobby/suss', '--json', 'body,title,state,url'], text=True))
    assert fresh['body'] == issue['issue']['body'], 'Original acceptance criteria changed; inspect before using this map.'
    issue['issue'] = fresh
    for requirement in issue['requirements']:
        assert not requirement['criterion_complete_claim']
        for target in requirement.get('mapped_target_sources', []):
            raw = (F / target['source']).read_bytes()
            assert sha(raw) == target['sha256'], target['source']
            names = set(re.findall(r'#\[test\]\s*fn (\w+)\(', raw.decode()))
            assert set(target['declared_test_names']) <= names, target['source']
            target['current_head_execution_claim'] = False
            targets[target['source']] = target
assert [len(i['requirements']) for i in issues] == [9, 6]
supplemental = {}
for name in ['crates/suss-cli/tests/clojure_num_api.rs',
             'crates/suss-cli/tests/clojure_pattern_literals.rs',
             'crates/suss-cli/tests/read_string.rs',
             'crates/suss-cli/tests/analyzer_edn.rs',
             'crates/suss-reader/tests/pattern_admission.rs',
             'crates/suss-reader/tests/tooling_decimals.rs',
             'crates/suss-reader/tests/edn.rs']:
    raw = (F/name).read_bytes()
    original = subprocess.check_output(['git','show','5ad621b40574a00e0771ca63e2c6c92e6e37bc6b:'+name],cwd=F)
    assert raw == original, name
    supplemental[name] = {'sha256':sha(raw),
        'declared_test_names':re.findall(r'#\[test\]\s*fn (\w+)\(',raw.decode()),
        'current_head_execution_claim':False}
ci_regressions = {}
for name in ['crates/suss-cli/tests/compiled_macro_cumulative_fuel.rs',
             'crates/suss-cli/tests/support/completed_macro_work.rs']:
    raw = (F/name).read_bytes()
    published = subprocess.check_output(['git','show','5ad621b40574a00e0771ca63e2c6c92e6e37bc6b:'+name],cwd=F)
    assert raw == published, name
    ci_regressions[name] = {'sha256':sha(raw),
        'declared_test_names':re.findall(r'#\[test\]\s*fn (\w+)\(',raw.decode()),
        'published_failing_head_source_conserved':True,
        'current_head_execution_claim':False}
stage_regression = 'crates/suss-cli/tests/compiled_macro_fuel_stages.rs'
stage_raw = (F/stage_regression).read_bytes()
stage_names = re.findall(r'#\[test\]\s*fn (\w+)\(',stage_raw.decode())
assert stage_names == ['exhausted_transformer_lookup_retains_expansion_stage_effects_and_recovery']
symbolic_regression = 'crates/suss-cli/tests/clojure_symbolic_numeric_arities.rs'
symbolic_raw = (F/symbolic_regression).read_bytes()
symbolic_names = re.findall(r'#\[test\]\s*fn (\w+)\(', symbolic_raw.decode())
assert symbolic_names == ['symbolic_numeric_constants_share_function_arities_and_keep_nested_boundaries', 'actual_aot_symbolic_constants_share_arities_without_merging_function_definitions']
symbolic_base = F/'results/m12-symbolic-arities'
symbolic_primary = json.loads((symbolic_base/'primary-command.json').read_text())
symbolic_controls = json.loads((symbolic_base/'primary-controls.json').read_text())
assert symbolic_primary['exit_code'] == 0 and symbolic_primary['controls'] == len(symbolic_controls) == 10
assert sha((symbolic_base/'oracle.clj').read_bytes()) == symbolic_primary['source_sha256']
assert sha((symbolic_base/'stdout.log').read_bytes()) == symbolic_primary['stdout_sha256']
assert (symbolic_base/'stdout.log').read_text().splitlines() == [r['observed_edn'] for r in symbolic_controls]
assert all(sha(Path(p).read_bytes()) == h for p,h in symbolic_primary['jars'].items())
assert all('(prn '+r['expression']+')' in (symbolic_base/'oracle.clj').read_text() for r in symbolic_controls)
region_source='crates/suss-cli/tests/clojure_symbolic_numeric_regions.rs'
region_raw=(F/region_source).read_bytes()
region_names=re.findall(r'#\[test\]\s*fn (\w+)\(',region_raw.decode())
assert region_names == ['symbolic_numeric_constants_retain_enclosing_try_binding_and_cleanup_regions','actual_aot_symbolic_constants_retain_enclosing_function_through_regions']
region_base=F/'results/m12-symbolic-regions'
region_primary=json.loads((region_base/'numeric-symbolic-region-primary/command.json').read_text())
region_controls=json.loads((region_base/'primary-controls.json').read_text())
assert region_primary['exit_code']==0 and len(region_controls)==len(region_primary['forms'])==9
assert sha((region_base/'numeric-symbolic-region-primary/oracle.clj').read_bytes())==region_primary['source_sha256']
assert (region_base/'numeric-symbolic-region-primary/stdout.log').read_text().splitlines()==region_primary['observations']
assert [r['expression'] for r in region_controls]==region_primary['forms']
assert [r['observed_edn'] for r in region_controls]==region_primary['observations']
assert all(r['native_expression']==r['expression'].replace('(catch Throwable ','(catch :default ') for r in region_controls)
assert all(sha(Path(p).read_bytes())==h for p,h in region_primary['jars'].items())
root_source='crates/suss-cli/tests/clojure_symbolic_numeric_root_scopes.rs'
root_raw=(F/root_source).read_bytes()
root_names=re.findall(r'#\[test\]\s*fn (\w+)\(',root_raw.decode())
assert root_names == ['root_replacement_keeps_implicit_function_pool_and_thread_binding_inherits','actual_aot_distinguishes_root_function_pool_from_thread_binding']
root_base=F/'results/m12-symbolic-root-scopes'
root_primary=json.loads((root_base/'numeric-symbolic-root-region-primary/command.json').read_text())
root_controls=json.loads((root_base/'primary-controls.json').read_text())
assert root_primary['exit_code']==0 and len(root_controls)==len(root_primary['forms'])==3
assert sha((root_base/'numeric-symbolic-root-region-primary/oracle.clj').read_bytes())==root_primary['source_sha256']
assert (root_base/'numeric-symbolic-root-region-primary/stdout.log').read_text().splitlines()==root_primary['observations']
assert [r['expression'] for r in root_controls]==root_primary['forms']
assert [r['observed_edn'] for r in root_controls]==root_primary['observations']==['false','true','true']
assert all(sha(Path(p).read_bytes())==h for p,h in root_primary['jars'].items())
async_source='crates/suss-compile/tests/portable_async_execution.rs'
assert (F/async_source).read_bytes()==subprocess.check_output(['git','show','9c33e2277bd36ce5b778d60ea926cc8bad34918a:'+async_source],cwd=F)
def cases(revision):
    rows = {}
    for line in subprocess.check_output(['git', 'ls-tree', '-r', revision], cwd=F, text=True).splitlines():
        metadata, name = line.split('\t', 1)
        if name.endswith('cases.json'):
            rows[name] = metadata.split()[2]
    return rows
original_cases = cases('5ad621b40574a00e0771ca63e2c6c92e6e37bc6b')
assert len(original_cases) == 261
current_cases = cases(head)
assert original_cases == current_cases
assert subprocess.run(['git', 'merge-base', '--is-ancestor', '5d8a608d5a7a02415973fef537090a749fae0ddf', head], cwd=F).returncode == 0
assert subprocess.run(['git', 'merge-base', '--is-ancestor', '052668a3776a64fcc6ce58269ee5d0f524b315a1', head], cwd=F).returncode == 0
assert subprocess.run(['git', 'merge-base', '--is-ancestor', '2ab330b8c906d3d1c23cce6a286dc11a44e791d7', head], cwd=F).returncode == 0
out = {'head': head, 'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'issues': issues, 'mapped_target_count': len(targets),
    'mapped_declared_test_names': {n: t['declared_test_names'] for n,t in targets.items()},
    'supplemental_numeric_api_and_reader_targets':supplemental,
    'published_ci_regression_sources':ci_regressions,
    'new_macro_stage_regression':{'source':stage_regression,'sha256':sha(stage_raw),
        'declared_test_names':stage_names,'current_head_execution_claim':False},
    'symbolic_arity_regression':{'source':symbolic_regression,'sha256':sha(symbolic_raw),'declared_test_names':symbolic_names,'primary_controls_sha256':sha((symbolic_base/'primary-controls.json').read_bytes()),'pinned_primary_controls':10,'current_head_execution_claim':False},
    'symbolic_region_regression':{'source':region_source,'sha256':sha(region_raw),'declared_test_names':region_names,'primary_controls_sha256':sha((region_base/'primary-controls.json').read_bytes()),'pinned_primary_controls':9,'catch_adapter':'Owned :default catch for the sole explicit ex-info throw; all other source unchanged.','current_head_execution_claim':False},
    'symbolic_root_scope_regression':{'source':root_source,'sha256':sha(root_raw),'declared_test_names':root_names,'primary_controls_sha256':sha((root_base/'primary-controls.json').read_bytes()),'pinned_primary_controls':3,'original_async_target_conserved':True,'current_head_execution_claim':False},
    'protected': old['protected'], 'original_case_file_count': len(original_cases),
    'all_case_file_blobs_conserved': True,
    'reviewed_core_and_native_eval_evidence_are_ancestors': True,
    'historical_before_regressions': old['before_regressions'],
    'historical_measurement_qualification': old['measured_placement_proof']['qualification'],
    'native_execution_claim': False, 'promotion_eligible': False,
    'qualification': 'Current-source admission and all15 original criterion maps only. Actual numeric/native corpus, raw/boxed/GC/AOT/WIT/bootstrap, full baseline, independent review and final-head CI remain separate required gates.'}
(E / 'numeric-reviewed-core-current-source-admission.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'head': head, 'criteria': sum(len(i['requirements']) for i in issues),
    'mapped_target_sources_conserved': len(targets), 'supplemental_sources_conserved':len(supplemental),
    'published_ci_regression_sources_conserved':len(ci_regressions), 'case_files_conserved': len(original_cases),
    'protected_primary_comparator_and_ledger_conserved': True, 'native_execution_claim': False}, indent=2))
