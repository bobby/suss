"""Authenticate retained before/primary observations without rerunning old code."""
from pathlib import Path
import hashlib,json,subprocess
K=Path(__file__).resolve().parent;F=K.parent/'m12-numeric-completion'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports=[]
for directory in ['m12-bigint-integers','m12-ratio-values']:
 p=F/'results'/directory
 primary=json.loads((p/'oracle-command.json').read_text());assert primary['exit_code']==0
 assert sha(p/'oracle.clj')==primary['source_sha256']
 assert '(assert (= "1.12.6" (clojure-version)))' in (p/'oracle.clj').read_text()
 assert all(sha(Path(path))==digest for path,digest in primary['jars'].items())
 cases=json.loads((p/'cases.json').read_text())
 assert [json.loads(line) for line in (p/'oracle.log').read_text().splitlines()]==[r[1] for r in cases]
 before=json.loads((p/'before-execution.json').read_text())
 if directory=='m12-bigint-integers':
  assert sha(p/'before.sus')==before['files']['before.sus']
  assert sha(p/'before.wit')==before['files']['before.wit']
  assert (p/'before.sus').read_text().strip()=='(ns before)\n(def check (fn [unused] (if (= 1 1N) 1 0)))'
  assert [c['exit_code'] for c in before['records']]==[0,0]
  assert before['records'][1]['stdout']=='0\n'
  assert ['(pr-str (try (= 1 1N) (catch :default e :error)))','true'] in cases
  discrepancy={'actual_old_command_exit':0,'actual_old_stdout':'0\n','primary_expected_truth':True,'expected_check_stdout':'1\n','comparison_matches':False,
    'qualification':'Old component invocation succeeded but computed false for (=1 1N), contradicting the independent pinned primary. Command0 is retained and is not described as a failing process exit.'}
 else:
  assert sha(p/'before.sus')==before['source_sha256'] and sha(p/'before.wit')==before['wit_sha256']
  assert '(pr-str (/ 1 3))' in (p/'before.sus').read_text() and '(pr-str 1/3)' in (p/'before.sus').read_text()
  assert [c['exit_code'] for c in before['commands']]==[0,0,1]
  assert before['commands'][1]['stdout']=='0.3333333333333333\n'
  assert ['(pr-str (try [(/ 1 3) (/ 6 3) (/ 6N 3) (/ -9223372036854775808 1) (/ -9223372036854775808 -9223372036854775808)] (catch :default e :error)))','[1/3 2 2N -9223372036854775808N 1N]'] in cases
  discrepancy={'actual_old_division_exit':0,'actual_old_division_stdout':'0.3333333333333333\n','pinned_primary_exact_division':'1/3','actual_old_literal_exit':1,'comparison_matches':False,
    'qualification':'Old ordinary integer division returned a binary64 approximation; the actual Ratio-literal invocation failed. The old CLI did not expose a stable language diagnostic; none is invented.'}
 reports.append({'directory':str(p.relative_to(F)),'before_receipt_sha256':sha(p/'before-execution.json'),
  'before_source_sha256':sha(p/'before.sus'),'before_wit_sha256':sha(p/'before.wit'),
  'primary_receipt_sha256':sha(p/'oracle-command.json'),'primary_cases_sha256':sha(p/'cases.json'),
  'primary_observation_count':len(cases),'primary_source_output_jars_verified':True,'discrepancy':discrepancy})
# Retain the actual earlier Cargo regression log as additional direct evidence.
# It has no separate exit-code receipt; do not infer a numeric process exit.
negative_log=F/'results/m12-bigint-values/language-before.log'
negative_text=negative_log.read_text()
case_path=F/'results/m12-bigint-values/cases.json'
old_matrix=json.loads(case_path.read_text())
first_form='(pr-str [0N 1N -1N 9223372036854775808 -9223372036854775809])'
assert first_form in negative_text and 'Uncaught language exception' in negative_text
assert 'test bigint_literals_and_signed_arithmetic_execute_in_both_phases ... FAILED' in negative_text
assert 'test result: FAILED. 0 passed; 1 failed; 0 ignored;' in negative_text
current_test=F/'crates/suss-cli/tests/clojure_bigints.rs'
assert 'fn bigint_literals_and_signed_arithmetic_execute_in_both_phases()' in current_test.read_text()
assert 'results/m12-bigint-values/cases.json' in current_test.read_text()
assert any(first_form in str(row) for row in old_matrix)
reports[0]['actual_earlier_cargo_regression']={'log_sha256':sha(negative_log),
 'test':'bigint_literals_and_signed_arithmetic_execute_in_both_phases',
 'observed_summary':'FAILED. 0 passed; 1 failed; 0 ignored',
 'current_fixture_contains_failing_form':True,'fixture_sha256':sha(case_path),
 'current_test_sha256':sha(current_test),'recorded_failing_form':first_form,
 'qualification':'Actual retained Cargo negative log; no separate producer exit-code/source-freeze receipt accompanies this log, so no invented exit101 or full frozen-input claim. The independent equality before receipt and pinned primary checks retain their separate stronger source qualification.'}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip()
report={'head':head,'auditor_sha256':sha(Path(__file__)),'historical_negatives':reports,
 'qualification':'Retained historical actual observations with source/WIT hashes and independent pinned primary observations. Historical compiler/artifact hashes are retained in the original receipts; unavailable old executables are not claimed freshly rehashed or rerun. The complete current native/AOT targets passing216 are separate positive evidence; own workspace, independent review and CI remain distinct gates.'}
(K/'numeric-reviewed-core-bigint-ratio-before-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('BigInt false equality and Ratio approximate division/literal failure authenticated against conserved source and pinned primary output/JARs; actual historical process exits retained.')
