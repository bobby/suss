"""Check preserved Decimal semantic failures separately from old setup failures."""
from pathlib import Path
import gzip,hashlib,json,subprocess,time,sys
E=Path(__file__).resolve().parent.parent
F=E/'m12-numeric-completion'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip()
expected_head=sys.argv[1] if len(sys.argv)==2 else 'af007facae80f96e325106a2e4db322396204719'
assert head==expected_head
root=F/'results/m12-decimal-integration'
source=F/'crates/suss-cli/tests/clojure_decimal_arithmetic.rs'
rows=[]
for before,fixture,primary,test in [
 ('before-subtraction-overload-fix','subtraction-dispatch-cases','subtraction-dispatch-oracle','decimal_subtraction_preserves_source_and_boxed_overloads'),
 ('before-bigdec-and-additional-precision','bigdec-cases','bigdec-oracle','decimal_bigdec_conversions_match_clojure'),
]:
 receipt_path=root/(before+'.json.gz');receipt=json.loads(gzip.decompress(receipt_path.read_bytes()))
 assert receipt['complete'] and receipt['exit_code']==101 and receipt['inputs_unchanged']
 cases_path=root/(fixture+'.json');cases=json.loads(cases_path.read_bytes())
 assert receipt['inputs'][str(cases_path.relative_to(F))]==sha(cases_path)
 primary_path=root/(primary+'-command.json');oracle=json.loads(primary_path.read_bytes())
 assert oracle['exit_code']==0
 assert oracle['source_sha256']==sha(root/(primary+'.clj'))
 assert '(assert (= "1.12.6" (clojure-version)))' in (root/(primary+'.clj')).read_text()
 for path,digest in oracle['jars'].items():assert sha(Path(path))==digest
 values=[json.loads(line) for line in (root/(primary+'.log')).read_text().splitlines()]
 assert values==[row[1] for row in cases]
 assert all(expression in (root/(primary+'.clj')).read_text() for expression,_ in cases)
 log=(root/(before+'.log')).read_text()
 assert f'test {test} ... FAILED' in log and 'test result: FAILED.' in log
 assert 'Runtime case0: '+cases[0][0] in log
 assert 'expected '+cases[0][1] in log
 assert 'actual Ok(' in log
 assert f'fn {test}()' in source.read_text() and fixture+'.json' in source.read_text()
 rows.append({'test':test,'historical_base':receipt['base'],'actual_negative_exit':101,'actual_negative_seconds':receipt['seconds'],'historical_inputs_unchanged':True,'fixture':str(cases_path.relative_to(F)),'fixture_sha256':sha(cases_path),'fixture_conserved_from_actual_negative_execution':True,'first_failing_form':cases[0][0],'primary_expected':cases[0][1],'primary_exit':0,'primary_receipt':str(primary_path.relative_to(F)),'primary_receipt_sha256':sha(primary_path),'negative_receipt':str(receipt_path.relative_to(F)),'negative_receipt_sha256':sha(receipt_path),'negative_log_sha256':sha(root/(before+'.log')),'retained_current_test':str(source.relative_to(F))})
report={'head':head,'at':time.time(),'qualification':'Historical actual semantic negative executions with frozen inputs and conserved current fixtures, checked against their pinned primary source/output/JAR receipts. Separate from the older missing-formatter/literal-link setup failures. This audit neither reruns historical binaries nor claims current positive execution, full criteria completion, review, CI or promotion eligibility. Current exact workspace must actually execute these retained tests successfully.','semantic_negative_controls':rows,'current_test_source_sha256':sha(source),'current_execution_claim':False,'promotion_eligible':False}
(E/'core-boundary-foundation/numeric-reviewed-core-semantic-before-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('Two actual Decimal semantic101 regressions verified with conserved fixtures and pinned primary outputs. Current positive execution remains separate.')
