"""Audit only after one identified actual full-workspace recorder exits."""
from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,time
K=Path(__file__).resolve().parent
F=K.parent/'m12-numeric-completion'
pid,started=sys.argv[1:];pid=int(pid)
phase='exact-workspace-reviewed-core-numeric-root-function-boundary'
state_path=K/'numeric-after-exact-audit-state.json'
assert not state_path.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
auditor=K/'audit-numeric-exact-workspace.py'
s={'recorder_pid':os.getpid(),'watched_workspace_pid':pid,'watched_workspace_starttime':started,'auditor_sha256':sha(auditor),'complete':False}
def save():state_path.write_text(json.dumps(s,indent=2)+'\n')
def starttime():
 try:return Path(f'/proc/{pid}/stat').read_text().rsplit(') ',1)[1].split()[19]
 except FileNotFoundError:return None
try:
 assert starttime()==started, 'Identify the live recorder before waiting.'
 save()
 while starttime()==started:time.sleep(5)
 receipt=F/'results/m12-num-api'/phase/'commands.json'
 r=json.loads(receipt.read_text())
 assert r['recorder_pid']==pid and r['complete'] and r['exit_code']==0 and r['runner_archived']
 assert sha(auditor)==s['auditor_sha256']
 s['actual_workspace_exit']=0;s['workspace_receipt_sha256']=sha(receipt);save()
 with (K/'numeric-after-exact-audit.log').open('w') as log:
  proc=subprocess.Popen(['python3',str(auditor),phase],cwd=K,stdout=log,stderr=subprocess.STDOUT)
  s['auditor_pid']=proc.pid;save();code=proc.wait()
 s['actual_auditor_exit']=code;save()
 assert code==0 and sha(auditor)==s['auditor_sha256']
except Exception as exc:s['error']=repr(exc)
finally:
 s['complete']=True;s['exit_code']=s.get('actual_auditor_exit',1 if 'error' in s else 0)
 if 'error' in s:s['exit_code']=s['exit_code'] or 1
 (K/'numeric-after-exact-auditor-controller.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
 save();print(json.dumps(s,indent=2),flush=True)
sys.exit(s['exit_code'])
