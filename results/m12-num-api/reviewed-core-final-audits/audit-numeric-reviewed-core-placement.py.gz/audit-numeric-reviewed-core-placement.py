"""Check the recorded implementation-choice measurements against current kernels."""
from pathlib import Path
import csv,hashlib,json,subprocess,sys
E=Path(__file__).resolve().parent.parent;F=E/'m12-numeric-completion';P=F/'results/m12-helper-multiply-final'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((E/'numeric-fa0da-measured-placement-conservation.json').read_text())
assert sha(F/'crates/suss-compile/src/runtime_abi/bigints.rs')==prior['gc_kernel_and_dispatcher_sha256']
assert sha(F/'runtime/numeric/src/lib.rs')==prior['current_helper_source_sha256']
bench=json.loads((P/'compiled-bench.json').read_text());profile=json.loads((P/'profile.json').read_text());gates=json.loads((P/'commands.json').read_text())
assert gates['complete'] and gates['inputs_unchanged'] and all(c['exit_code']==0 for c in gates['commands'])
assert bench['complete'] and len(bench['commands'])==159 and all(c['exit_code']==0 for c in bench['commands'])
assert profile['complete'] and profile['inputs_unchanged'] and all(c['exit_code']==0 for c in profile['commands'])
rows=list(csv.DictReader((P/'compiled-bench.csv').open(newline='')))
assert len(rows)==9
expected={'balanced-small':(2433.953521111111,72.4992),'balanced-large':(95123.80473333334,674.752),'one-limb-wide':(36298.047321875,2090.176),'two-limb-wide':(56493.621546153845,2098.752)}
for r in rows:
 if r['case'] in expected:
  assert tuple(float(r[k]) for k in ['instructions_with_control','bytes_measured'])==expected[r['case']]
 else:assert r['bytes_measured']==''
assert all(r['bytes_net_if_both_measured']=='' for r in rows)
choices=list(csv.DictReader((P/'instructions.csv').open(newline='')))
selected=[r for r in choices if (int(r['limbs_a']),int(r['limbs_b'])) in [(0,0),(1,512),(2,8),(2,9),(3,5),(4,4),(512,512)]]
assert any(r['candidate']=='gc' for r in selected) and any(r['candidate']=='helper' for r in selected)
report={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip(),'criterion':'338 implementation: select WasmGC/no_std arbitrary precision by measured instruction and byte columns, considering GC reads/copying costs.','historical_measurement_receipt':str((P/'commands.json').relative_to(F)),'receipt_sha256':sha(P/'commands.json'),'recorded_compiled_bench_commands_all0':159,'recorded_instruction_and_byte_columns':rows,'wrapper_crossover_selected_rows':selected,'allocation_rule':'Measured GC full value/array slopes approximately40+4*capacity bytes; complete measurements and collector validation retained. No invented net-byte measurements where controls were below RSS resolution.','recorded_choice':'GC for zero/one-limb and small products; copied no_std helper only if both logical lengths>=2 and (la-1)*(lb-1)>=8. Existing kernel/dispatcher and helper sources remain exact against the prior conservation proof.','protected_current_sources':{'crates/suss-compile/src/runtime_abi/bigints.rs':sha(F/'crates/suss-compile/src/runtime_abi/bigints.rs'),'runtime/numeric/src/lib.rs':sha(F/'runtime/numeric/src/lib.rs')},'measurement_files':{str(p.relative_to(F)):sha(p) for p in [P/'compiled-bench.json',P/'compiled-bench.csv',P/'profile.json',P/'instructions.csv',P/'bytes.csv']},'qualification':'Historical measurement establishes the recorded implementation-choice rationale. Current kernel/dispatcher and helper bytes are conserved. No fresh whole-compiler performance, current execution, workspace, review or full numeric acceptance claim.'}
# Publish only after direct current-source conservation checks pass.

# Authenticate the historical source against the original profile, then compare
# the current production arithmetic directly, independently of older navigation.
historical='1f6ab921cb490ee38fda1278c5478311e8a11a54'
def git_bytes(name):
 return subprocess.check_output(['git','show',historical+':'+name],cwd=F)
current_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=F,text=True).strip()
expected_head=sys.argv[1] if len(sys.argv)==2 else 'af007facae80f96e325106a2e4db322396204719'
assert current_head==expected_head
for name in ['crates/suss-compile/src/runtime_abi/bigints.rs','crates/suss-compile/examples/bigint_runtime.rs']:
 raw=git_bytes(name)
 assert hashlib.sha256(raw).hexdigest()==profile['inputs'][name]
 assert raw==(F/name).read_bytes(),name
name='runtime/numeric/src/lib.rs';old_helper=git_bytes(name);current_helper=(F/name).read_bytes()
assert hashlib.sha256(old_helper).hexdigest()==profile['inputs'][name]
def function(raw,name):
 start=raw.index(('fn '+name+'(').encode());brace=raw.index(b'{',start);depth=0
 for i in range(brace,len(raw)):
  depth+=(raw[i]==ord('{'))-(raw[i]==ord('}'))
  if not depth:return raw[start:i+1]
 raise AssertionError('unclosed function '+name)
functions={}
for name in ['suss_bigint_multiply','trim']:
 old_body=function(old_helper,name);current_body=function(current_helper,name)
 assert old_body==current_body,name
 functions[name]={'sha256':hashlib.sha256(current_body).hexdigest(),'historical_and_current_byte_equal':True}
assert len(profile['verification'])==320 and len(profile['commands'])==854
assert len(profile['instructions'])==128 and len(profile['bytes'])==5
assert all(len(x['slopes'])==2 for x in profile['instructions']+profile['bytes'])
report['direct_current_source_conservation']={'head':current_head,'historical_commit':historical,
 'historical_helper_profile_hash_authenticated':True,
 'whole_gc_kernel_and_dispatcher_equal':True,'whole_production_wrapper_equal':True,
 'helper_functions':functions,'whole_helper_changed':old_helper!=current_helper}
report['auditor_sha256']=sha(Path(__file__))
report['profile_shape']={'commands_actual_exit0':854,'complete_verifications':320,
 'instruction_pairs':128,'instruction_raw_commands':512,'allocation_raw_commands':20}
report['qualification']='Historical measurement justifies the selected production GC/helper placement. Current complete GC kernel/dispatcher and wrapper bytes equal the authenticated measured source; helper multiply/trim bodies are identical. Whole helper/ABI/compiler evolved, so this is not fresh performance, native correctness, workspace, review or complete numeric acceptance evidence.'
(E/'core-boundary-foundation/numeric-reviewed-core-measured-placement-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('Direct current-source arithmetic conservation verified against authenticated measured1f6: complete GC/dispatcher+wrapper and helper multiply/trim bodies identical; no fresh-performance claim.')
