mod support;
#[path = "support/portable_decode.rs"]
mod portable_decode;
use suss_compile::{
    portable,
    portable_session::{RuntimeNumber, runtime_number, sentinel_tag},
    runtime_abi,
};
use wasmtime::{AsContextMut, Instance, Linker, Module, Store, Val};

fn execute(source: &str) -> (Store<()>, Val) {
    try_execute(source).unwrap_or_else(|error| panic!("{source}: {error:?}"))
}

/// True when the source throws a language exception, not a trap or other failure.
fn throws_language_exception(source: &str) -> bool {
    match try_execute(source) {
        Ok(_) => false,
        Err(error) => {
            error.downcast_ref::<wasmtime::Trap>().is_none()
                && format!("{error:?}").contains("thrown Wasm exception")
        }
    }
}

/// Execute a source fragment, returning a thrown language exception as an error.
fn try_execute(source: &str) -> wasmtime::Result<(Store<()>, Val)> {
    let fragment = portable::prepare_fragment(
        source,
        &portable::resolve::Environment::default(),
        portable::resolve::Phase::Runtime,
    )
    .unwrap();
    try_execute_fragment(fragment.wasm, fragment.cells)
}

fn execute_bytes(bytes: Vec<u8>) -> (Store<()>, Val) {
    execute_fragment(bytes, Vec::new())
}
fn execute_fragment(bytes: Vec<u8>, cells: Vec<portable::resolve::Global>) -> (Store<()>, Val) {
    try_execute_fragment(bytes, cells).unwrap()
}
fn try_execute_fragment(
    bytes: Vec<u8>,
    cells: Vec<portable::resolve::Global>,
) -> wasmtime::Result<(Store<()>, Val)> {
    runtime_abi::verify_artifact(&bytes, &runtime_abi::Manifest::default()).unwrap();
    let engine = support::engine();
    let mut store = Store::new(&engine, ());
    let runtime = Instance::new(
        &mut store,
        &Module::new(&engine, runtime_abi::module()).unwrap(),
        &[],
    )
    .unwrap();
    let mut linker = Linker::new(&engine);
    linker
        .instance(&mut store, "suss.runtime", runtime)
        .unwrap();
    let mut class = [Val::null_any_ref()];
    runtime
        .get_func(&mut store, "core-exception-info-class")
        .unwrap()
        .call(&mut store, &[], &mut class)
        .unwrap();
    let mut class_cell = [Val::null_any_ref()];
    runtime
        .get_func(&mut store, "binding-new")
        .unwrap()
        .call(&mut store, &class, &mut class_cell)
        .unwrap();
    for identity in cells {
        let mut value = [Val::null_any_ref()];
        let arithmetic = if identity.namespace() == "suss.core" {
            match identity.name() {
                "+" => Some("add"),
                "-" => Some("subtract"),
                "*" => Some("multiply"),
                "/" => Some("divide"),
                _ => None,
            }
        } else {
            None
        };
        let core_export = if identity.namespace() == "suss.core" {
            match identity.name() {
                "<" => Some("comparison-less-function"),
                "<=" => Some("comparison-less-equal-function"),
                ">" => Some("comparison-greater-function"),
                ">=" => Some("comparison-greater-equal-function"),
                "==" => Some("comparison-strict-equal-function"),
                "array" => Some("array-function"),
                "array?" => Some("array-predicate-function"),
                "make-array" => Some("array-make-function"),
                "aclone" => Some("array-clone-function"),
                "aget" => Some("array-get-function"),
                "aset" => Some("array-set-function"),
                "alength" => Some("array-length-function"),
                "native-satisfies?" => Some("native-satisfies-function"),
                "nil?" => Some("predicate-nil"),
                "false?" => Some("predicate-false"),
                "true?" => Some("predicate-true"),
                "undefined?" => Some("predicate-undefined"),
                "number?" => Some("predicate-number"),
                "string?" => Some("predicate-string"),
                "identical?" => Some("predicate-identical"),
                "ExceptionInfo" => Some("core-exception-info-class"),
                "ex-info" => Some("core-ex-info"),
                "ex-data" => Some("core-ex-data"),
                "ex-message" => Some("core-ex-message"),
                "ex-cause" => Some("core-ex-cause"),
                _ => None,
            }
        } else {
            None
        };
        if identity.namespace() == "suss.core" && identity.name() == "ExceptionInfo" {
            value = class_cell.clone();
        } else if let Some(export) = core_export {
            let mut function = [Val::null_any_ref()];
            if export == "core-ex-info" {
                let nil = runtime.get_func(&mut store, "nil").unwrap();
                nil.call(&mut store, &[], &mut value).unwrap();
                let mut cell = [Val::null_any_ref()];
                runtime
                    .get_func(&mut store, "binding-new")
                    .unwrap()
                    .call(&mut store, &value, &mut cell)
                    .unwrap();
                runtime
                    .get_func(&mut store, export)
                    .unwrap()
                    .call(
                        &mut store,
                        &[class_cell[0].clone(), cell[0].clone()],
                        &mut function,
                    )
                    .unwrap();
                runtime
                    .get_func(&mut store, "binding-set")
                    .unwrap()
                    .call(&mut store, &[cell[0].clone(), function[0].clone()], &mut [])
                    .unwrap();
                value = cell;
            } else {
                runtime
                    .get_func(&mut store, export)
                    .unwrap()
                    .call(
                        &mut store,
                        if export.starts_with("predicate-")
                            || export.starts_with("array-")
                            || export.starts_with("comparison-")
                            || export == "native-satisfies-function"
                        {
                            &[]
                        } else {
                            &class_cell
                        },
                        &mut function,
                    )
                    .unwrap();
                runtime
                    .get_func(&mut store, "binding-new")
                    .unwrap()
                    .call(&mut store, &function, &mut value)
                    .unwrap();
            }
        } else if let Some(name) = arithmetic {
            let mut function = [Val::null_any_ref()];
            runtime
                .get_func(&mut store, &format!("arithmetic-{name}"))
                .unwrap()
                .call(&mut store, &[], &mut function)
                .unwrap();
            runtime
                .get_func(&mut store, "binding-new")
                .unwrap()
                .call(&mut store, &function, &mut value)
                .unwrap();
        } else {
            runtime
                .get_func(&mut store, "binding-unbound")
                .unwrap()
                .call(&mut store, &[], &mut value)
                .unwrap();
        }
        let ty = value[0]
            .unwrap_anyref()
            .unwrap()
            .as_struct(&store)
            .unwrap()
            .unwrap()
            .ty(&store)
            .unwrap();
        let global = wasmtime::Global::new(
            &mut store,
            wasmtime::GlobalType::new(
                wasmtime::ValType::Ref(wasmtime::RefType::new(false, ty.into())),
                wasmtime::Mutability::Const,
            ),
            value[0].clone(),
        )
        .unwrap();
        linker
            .define(
                &store,
                identity.import_module(),
                &identity.import_name(),
                global,
            )
            .unwrap();
    }
    let fragment = linker
        .instantiate(&mut store, &Module::new(&engine, bytes).unwrap())
        .unwrap();
    let mut result = [Val::null_any_ref()];
    fragment
        .get_func(&mut store, "eval")
        .unwrap()
        .call(&mut store, &[], &mut result)?;
    store.gc(None).unwrap();
    Ok((store, result[0].clone()))
}

#[test]
fn compiled_literal_uses_shared_abi_and_binary64_rounding() {
    let (mut store, value) = execute("9007199254740993.0");
    let object = value
        .unwrap_anyref()
        .unwrap()
        .as_struct(&store)
        .unwrap()
        .unwrap();
    assert_eq!(
        object.field(&mut store, 0).unwrap().unwrap_f64().to_bits(),
        9007199254740992.0f64.to_bits()
    );
}

fn number(source: &str) -> RuntimeNumber {
    let (mut store, value) = execute(source);
    runtime_number(&mut store, &value)
        .unwrap()
        .unwrap_or_else(|| panic!("{source}: not a number"))
}
fn long(source: &str) -> i64 {
    match number(source) {
        RuntimeNumber::Long(value) => value,
        other => panic!("{source}: expected a long, observed {other:?}"),
    }
}
fn double(source: &str) -> f64 {
    match number(source) {
        RuntimeNumber::Double(value) => value,
        other => panic!("{source}: expected a double, observed {other:?}"),
    }
}
/// A pinned ClojureScript expectation as Clojure's: an integral, finite,
/// non-negative-zero binary64 from source without double literals or
/// double primitives is a long.
fn clojure_expected(expected: &serde_json::Value, source: &str) -> serde_json::Value {
    let doubles = source.contains("##")
        || source.contains("f64-")
        // The JavaScript-coercing addition intrinsic gives a double.
        || source.contains("suss.bootstrap/value-add")
        || source
            .as_bytes()
            .windows(2)
            .any(|pair| pair[0].is_ascii_digit() && matches!(pair[1], b'.' | b'e' | b'E'));
    clojure_value(expected, doubles)
}
fn clojure_value(expected: &serde_json::Value, doubles: bool) -> serde_json::Value {
    match expected["tag"].as_str() {
        Some("f64") if !doubles => {
            let bits = u64::from_str_radix(expected["bits"].as_str().unwrap(), 16).unwrap();
            let value = f64::from_bits(bits);
            if value.is_finite() && value.fract() == 0.0 && bits != (-0.0f64).to_bits() {
                serde_json::json!({"tag":"long","value":(value as i64).to_string()})
            } else {
                expected.clone()
            }
        }
        _ => expected.clone(),
    }
}
#[test]
fn empty_let_body_returns_nil() {
    let (mut store, value) = execute("(let [x 1])");
    assert_eq!(
        sentinel_tag(&mut store, &value).unwrap(),
        Some(runtime_abi::NIL as u32)
    );
}
#[test]
fn compiled_scalars_match_the_pinned_reader_observations() {
    let corpus: serde_json::Value =
        serde_json::from_str(include_str!("../../../tests/oracle/reader-cases.json")).unwrap();
    assert_eq!(
        corpus["upstream"],
        "c4295f303100bbf5afac449242d30bca1126f1a1"
    );
    let mut ids = std::collections::HashSet::new();
    for case in corpus["cases"].as_array().unwrap() {
        assert!(ids.insert(case["id"].as_str().unwrap()));
        let (mut store, value) = execute(case["source"].as_str().unwrap());
        let reference = value.unwrap_anyref().unwrap();
        let actual = match case["expected"]["tag"].as_str().unwrap() {
            "f64" => {
                let _ = reference;
                tagged(&mut store, &value)
            }
            "string" => {
                let array = reference.as_array(&store).unwrap().unwrap();
                let units = array
                    .elems(&mut store)
                    .unwrap()
                    .map(|unit| unit.unwrap_i32() as u16)
                    .collect::<Vec<_>>();
                serde_json::json!({"tag":"string","units":units})
            }
            _ => panic!("unknown oracle tag"),
        };
        let source = case["source"].as_str().unwrap();
        assert_eq!(actual, clojure_expected(&case["expected"], source), "{source}");
    }
    assert_eq!(ids.len(), 14);
}
#[test]
fn numeric_calls_and_truthiness_execute_with_portable_bits() {
    use RuntimeNumber::{Double, Long};
    for (source, expected) in [
        ("(+ 9007199254740992 1)", Long(9007199254740993)),
        ("(- 0)", Long(0)),
        ("(+ -0.0)", Double(-0.0)),
        ("(/ 4.0)", Double(0.25)),
        ("(+)", Long(0)),
        ("(*)", Long(1)),
        ("(- 10 3 2)", Long(5)),
        ("(/ 20 2 5)", Long(2)),
        ("(if 0 1 2)", Long(1)),
        ("(if \"\" 1 2)", Long(1)),
        ("(if nil 1 2)", Long(2)),
        ("(if false 1 2)", Long(2)),
        ("(if true 1 2)", Long(1)),
        ("(let [x 2 x (+ x 3)] (let [x 7] x) (* x 4))", Long(20)),
        ("(+ (if false (* 3 4) (/ 8 2)) (if true 2 9))", Long(6)),
        ("#?(:jvm 1 :default (suss.core/+ 1 (cljs.core/* 2 3)))", Long(7)),
    ] {
        match (number(source), expected) {
            (Double(found), Double(expected)) => assert_eq!(found.to_bits(), expected.to_bits(), "{source}"),
            (found, expected) => assert_eq!(found, expected, "{source}"),
        }
    }
    // Decode the normalized exact pair, never its binary64 approximation.
    let (mut store, value) = execute("(/ 4)");
    assert_eq!(tagged(&mut store, &value),
        serde_json::json!({"tag":"ratio","numerator":"1","denominator":"4"}));
    // Integer division by zero throws in Clojure; double division doesn't.
    assert!(throws_language_exception("(/ 0 0)"));
    assert!(throws_language_exception("(/ 1 0)"));
    assert!(double("(/ 0.0 0)").is_nan());
    assert_eq!(double("(/ 1.0 0)"), f64::INFINITY);
}
#[test]
fn unary_sum_and_product_check_operands_and_return_numbers_unchanged() {
    use portable::hir::Type;
    // Clojure (#286): unary + and * are Numbers. A Number operand is returned
    // with its exact bits; any other operand throws instead of passing through.
    for source in [
        "(+ nil)",
        "(* false)",
        "(+ \"\\uD800\")",
        "(* (fn [x] x))",
        "(+ (if false 1 nil))",
        "(+ (+ \"x\") 1)",
        "(- (+ (fn [] 1)))",
    ] {
        let forms = suss_reader::forms::read_forms(source).unwrap();
        let hir = portable::hir::analyze(&forms, 0..source.len()).unwrap();
        assert_eq!(hir.ty, Type::Number, "{source}");
        assert!(throws_language_exception(source), "{source} must throw");
    }
    for (source, bits) in [
        ("(+ -0.0)", (-0.0f64).to_bits()),
        ("(* -0.0)", (-0.0f64).to_bits()),
        ("(+ (if true 7.0 nil))", 7.0f64.to_bits()),
        ("(* (if true ##Inf nil))", f64::INFINITY.to_bits()),
    ] {
        let (mut store, value) = execute(source);
        let expected = serde_json::json!({"tag": "f64", "bits": format!("{bits:016x}")});
        assert_eq!(tagged(&mut store, &value), expected, "{source}");
    }
    assert!(double("(* ##NaN)").is_nan());
    assert_eq!(long("(+ (if true 7 nil))"), 7);
}
#[test]
fn arithmetic_import_trace_observes_once_only_source_order_and_short_circuit() {
    use wasmtime::Func;
    let engine = support::engine();
    let mut store = Store::new(&engine, Vec::<String>::new());
    let runtime = Instance::new(
        &mut store,
        &Module::new(&engine, runtime_abi::module()).unwrap(),
        &[],
    )
    .unwrap();
    let mut linker = Linker::new(&engine);
    linker
        .instance(&mut store, "suss.runtime", runtime)
        .unwrap();
    linker.allow_shadowing(true);
    for name in ["number-add", "number-multiply", "checked-divide"] {
        let function = runtime.get_func(&mut store, name).unwrap();
        let ty = function.ty(&store);
        let wrapper = Func::new(&mut store, ty, move |mut caller, args, results| {
            caller.data_mut().push(name.into());
            function.call(&mut caller, args, results)
        });
        linker
            .define(&store, "suss.runtime", name, wrapper)
            .unwrap();
    }
    // Unary identities must return each already-evaluated operand without
    // replaying it. The ordered import trace catches duplicate evaluation;
    // assigning an identical literal to a binding twice would not.
    // Quotients of longs stay boxed runtime calls (#337), so the trace sees
    // each evaluated operation and not the untaken branch's. The outer sum of
    // two i31 longs runs inline (#361), so it calls no import.
    let bytes = portable::compile("(+ (+ (if (/ 6 3) (/ 8 4) (/ 81 9))) (/ (/ 24 2) 1))").unwrap();
    let fragment = linker
        .instantiate(&mut store, &Module::new(&engine, bytes).unwrap())
        .unwrap();
    let mut result = [Val::null_any_ref()];
    fragment
        .get_func(&mut store, "eval")
        .unwrap()
        .call(&mut store, &[], &mut result)
        .unwrap();
    assert_eq!(
        store.data(),
        &[
            "checked-divide",
            "checked-divide",
            "checked-divide",
            "checked-divide",
        ]
    );
    store.gc(None).unwrap();
    assert_eq!(
        runtime_number(&mut store, &result[0]).unwrap(),
        Some(RuntimeNumber::Long(14))
    );
}
#[test]
fn hir_retains_binding_identity_metadata_and_located_diagnostics() {
    use portable::hir::Expression;
    let source = "(let [^:first x 1] (let [x 2] x) ^:last x)";
    let hir = portable::analyze(source).unwrap();
    let Expression::Do(top) = &*hir.kind else {
        panic!()
    };
    let Expression::Let { bindings, body } = &*top[0].kind else {
        panic!()
    };
    assert_eq!(bindings[0].metadata.len(), 1);
    let outer = bindings[0].id;
    let Expression::Do(items) = &*body.kind else {
        panic!()
    };
    let Expression::Let {
        bindings: inner, ..
    } = &*items[0].kind
    else {
        panic!()
    };
    assert_ne!(outer, inner[0].id);
    assert!(matches!(*items[1].kind,Expression::Local(id) if id==outer));
    assert_eq!(items[1].metadata.len(), 1);
    assert_eq!(&source[items[1].span.clone()], "^:last x");
    for (source, needle) in [
        ("(let [x missing] x)", "missing"),
        ("(other.core/+ 1 2)", "other.core/+"),
    ] {
        let error = portable::compile(source).unwrap_err();
        assert_eq!(&source[error.span], needle);
    }
    // A known closure called with another count compiles, as in Clojure, and
    // throws its arity error at run time (ADR-0004).
    assert!(portable::compile("(let [+ (fn [x] x)] (+ 2 3))").is_ok());
    for source in ["(/)", "(-)"] {
        assert!(portable::compile(source).is_ok(), "{source}");
        assert!(throws_language_exception(source), "{source} must throw its runtime arity error");
    }
    for source in ["(if 1)", "(let [x] x)", "(recur 1)"] {
        assert!(portable::compile(source).is_err(), "{source}");
    }
}
#[test]
fn verifier_rejects_undefined_non_dominating_wrong_type_and_arity_values() {
    use portable::{
        hir::Type,
        ir::{self, Operation, Terminator, ValueId},
    };
    let source = "(+ (if true 1 2) 3)";
    let function = ir::lower(&portable::analyze(source).unwrap()).unwrap();
    ir::verify(&function).unwrap();
    let mut bad = function.clone();
    if let Terminator::Branch { condition, .. } = &mut bad.blocks[0].terminator {
        *condition = ValueId(usize::MAX);
    }
    assert!(
        ir::verify(&bad)
            .unwrap_err()
            .message
            .contains("no definition")
    );
    let mut bad = function.clone();
    let then_value = bad.blocks[1].instructions[0].result;
    if let Terminator::Branch { condition, .. } = &mut bad.blocks[0].terminator {
        *condition = then_value;
    }
    assert!(ir::verify(&bad).unwrap_err().message.contains("dominate"));
    let mut bad = function.clone();
    bad.values[then_value.0].ty = Type::String;
    assert!(
        ir::verify(&bad)
            .unwrap_err()
            .message
            .contains("literal result")
    );
    let mut bad = function.clone();
    if let Terminator::Jump { arguments, .. } = &mut bad.blocks[1].terminator {
        arguments.clear();
    }
    assert!(ir::verify(&bad).unwrap_err().message.contains("edge arity"));
    let mut bad = function.clone();
    for block in &mut bad.blocks {
        for instruction in &mut block.instructions {
            if let Operation::Arithmetic { arguments, .. } = &mut instruction.operation {
                arguments.clear();
            }
        }
    }
    assert!(
        ir::verify(&bad)
            .unwrap_err()
            .message
            .contains("intrinsic arity")
    );
    assert!(portable::compile_ir(&bad).is_err());

    // Checked arithmetic always yields a Number (#286); a forged non-Number
    // result type must be rejected rather than trusted by later intrinsics.
    for source in ["(+ \"1\" 2)", "(+ (if true 1 nil) 2)"] {
        let mut bad = ir::lower(&portable::analyze(source).unwrap()).unwrap();
        ir::verify(&bad).unwrap();
        let result = bad
            .blocks
            .iter()
            .flat_map(|block| &block.instructions)
            .find(|instruction| matches!(instruction.operation, Operation::Arithmetic { .. }))
            .unwrap()
            .result;
        assert_eq!(bad.values[result.0].ty, Type::Number);
        bad.values[result.0].ty = Type::String;
        assert!(
            ir::verify(&bad)
                .unwrap_err()
                .message
                .contains("arithmetic operand/result type mismatch"),
            "{source}"
        );
        assert!(portable::compile_ir(&bad).is_err(), "{source}");
    }
}

#[test]
fn malformed_hir_returns_a_located_lowering_diagnostic() {
    use portable::hir::{BindingId, Expression, Hir, Type};
    let hir = Hir {
        source: None,
        span: 3..9,
        metadata: Vec::new(),
        ty: Type::Number,
        kind: std::sync::Arc::new(Expression::Local(BindingId(99))),
    };
    let error = portable::ir::lower(&hir).unwrap_err();
    assert_eq!(error.span, 3..9);
    assert!(error.message.contains("undefined binding"));
}
#[test]
fn edge_parameter_replacements_are_parallel_in_executed_ir() {
    use portable::{
        hir::{Arithmetic, Literal, Type},
        ir::{Block, Function, Instruction, Operation, Terminator, Value, ValueId},
    };
    let types = [
        Type::Number,
        Type::Number,
        Type::Bool,
        Type::Number,
        Type::Number,
        Type::Bool,
        Type::Bool,
        Type::Number,
    ];
    let literal = |result, value| Instruction {
        literal_site: None,
        result: ValueId(result),
        operation: Operation::Literal(value),
        span: 0..1,
    };
    let function = Function {
        span: 0..1,
        values: types
            .into_iter()
            .map(|ty| Value { ty, span: 0..1 })
            .collect(),
        blocks: vec![
            Block {
                parameters: vec![],
                instructions: vec![
                    literal(0, Literal::Number(10.0)),
                    literal(1, Literal::Number(20.0)),
                    literal(2, Literal::Bool(true)),
                ],
                terminator: Terminator::Jump {
                    target: 1,
                    arguments: vec![ValueId(0), ValueId(1), ValueId(2)],
                },
            },
            Block {
                parameters: vec![ValueId(3), ValueId(4), ValueId(5)],
                instructions: vec![],
                terminator: Terminator::Branch {
                    condition: ValueId(5),
                    consequent: 2,
                    alternative: 3,
                },
            },
            Block {
                parameters: vec![],
                instructions: vec![literal(6, Literal::Bool(false))],
                terminator: Terminator::Jump {
                    target: 1,
                    arguments: vec![ValueId(4), ValueId(3), ValueId(6)],
                },
            },
            Block {
                parameters: vec![],
                instructions: vec![Instruction {
                    literal_site: None,
                    result: ValueId(7),
                    operation: Operation::Arithmetic {
                        operator: Arithmetic::Subtract,
                        arguments: vec![ValueId(3), ValueId(4)],
                        coercing: false,
                        primitive_overload: false,
                    },
                    span: 0..1,
                }],
                terminator: Terminator::Return(ValueId(7)),
            },
        ],
    };
    let (mut store, value) = execute_bytes(portable::compile_ir(&function).unwrap());
    let result = value
        .unwrap_anyref()
        .unwrap()
        .as_struct(&store)
        .unwrap()
        .unwrap()
        .field(&mut store, 0)
        .unwrap()
        .unwrap_f64();
    assert_eq!(result, 10.0); // sequential replacement would incorrectly produce zero
}
fn tagged(store: &mut Store<()>, value: &Val) -> serde_json::Value {
    if let Some(tag) = sentinel_tag(&mut *store, value).unwrap() {
        return match tag {
            0 | 6 => serde_json::json!({"tag":"nil"}),
            2 => serde_json::json!({"tag":"bool","value":false}),
            4 => serde_json::json!({"tag":"bool","value":true}),
            _ => panic!("unknown runtime sentinel"),
        };
    }
    let reference = value
        .unwrap_anyref()
        .expect("a non-sentinel runtime value is a reference");
    match runtime_number(&mut *store, value).unwrap() {
        Some(RuntimeNumber::Double(value)) => {
            return serde_json::json!({"tag":"f64","bits":format!("{:016x}", value.to_bits())});
        }
        Some(RuntimeNumber::Long(value)) => {
            return serde_json::json!({"tag":"long","value":value.to_string()});
        }
        None if reference.as_struct(&*store).unwrap().is_some() => {
            // Capture the canonical shared numeric types in this same engine.
            // The observer then reads actual GC limbs without guest arithmetic,
            // printing or normalization; unknown layouts still fail.
            static MODULE: std::sync::OnceLock<Module> = std::sync::OnceLock::new();
            let module = MODULE.get_or_init(|| Module::new(&support::engine(), runtime_abi::module()).unwrap());
            let runtime = Instance::new(&mut *store, module, &[]).unwrap();
            let mut decoder = portable_decode::Decoder::capture_runtime_numeric(
                &mut store.as_context_mut(), &runtime, 1_000_000,
            ).unwrap();
            return match decoder.decode(&mut store.as_context_mut(), value).unwrap() {
                portable_decode::Observation::BigInt(value) => serde_json::json!({"tag":"bigint","value":value}),
                portable_decode::Observation::Decimal { unscaled, scale } => serde_json::json!({"tag":"decimal","unscaled":unscaled,"scale":scale}),
                portable_decode::Observation::Ratio(numerator, denominator) =>
                    serde_json::json!({"tag":"ratio","numerator":numerator,"denominator":denominator}),
                other => panic!("unknown numeric GC object layout: {other:?}"),
            };
        }
        None => {},
    }
    let array = reference
        .as_array(&*store)
        .unwrap()
        .expect("unknown GC value");
    assert!(matches!(
        array.ty(&*store).unwrap().element_type(),
        wasmtime::StorageType::I16
    ));
    let units = array
        .elems(&mut *store)
        .unwrap()
        .map(|unit| unit.unwrap_i32() as u16)
        .collect::<Vec<_>>();
    serde_json::json!({"tag":"string","units":units})
}
#[test]
fn compiled_exact_numbers_match_primary_clojure_storage_observations() {
    let cases: serde_json::Value = serde_json::from_str(include_str!(
        "../../../results/m12-ratio-pipeline/cases.json"
    )).unwrap();
    assert_eq!(cases.as_array().unwrap().len(), 12);
    for case in cases.as_array().unwrap() {
        let source = case["source"].as_str().unwrap();
        let (mut store, value) = execute(source);
        assert_eq!(tagged(&mut store, &value), case["expected"], "{source}");
    }
}

#[test]
fn compiled_source_cases_match_the_pinned_compiler_observations() {
    let corpus: serde_json::Value =
        serde_json::from_str(include_str!("../../../tests/oracle/portable-cases.json")).unwrap();
    assert_eq!(corpus["schema"], 1);
    assert_eq!(
        corpus["upstream"],
        "c4295f303100bbf5afac449242d30bca1126f1a1"
    );
    let mut ids = std::collections::HashSet::new();
    let mut corrected = 0;
    let mut failing = Vec::new();
    for case in corpus["cases"].as_array().unwrap() {
        let id = case["id"].as_str().unwrap();
        assert!(ids.insert(id));
        let source = case["source"].as_str().unwrap();
        let source = match clojure_correction(id, source) {
            None => source.to_owned(),
            Some(retarget) => {
                corrected += 1;
                assert!(throws_language_exception(source), "{id}: {source} must throw");
                let Some(retarget) = retarget else { continue };
                retarget
            }
        };
        let observed = try_execute(&source)
            .map(|(mut store, value)| tagged(&mut store, &value))
            .map_err(|error| format!("{error:?}"));
        let expected = clojure_override(id).unwrap_or_else(|| clojure_expected(&case["expected"], &source));
        if observed.as_ref() != Ok(&expected) {
            failing.push(format!("{id}: {source}: {observed:?}"));
        }
    }
    assert!(failing.is_empty(), "{failing:#?}");
    assert_eq!(ids.len(), 397);
    assert_eq!(corrected, 142);
}

/// Where Clojure's result differs from the pinned ClojureScript one beyond
/// long-versus-double (#335): exact long arithmetic, a long's zero, Java's
/// double formatting and long/double identity.
fn clojure_override(id: &str) -> Option<serde_json::Value> {
    let string = |text: &str| serde_json::json!({"tag":"string","units":text.encode_utf16().collect::<Vec<_>>()});
    Some(match id {
        "rounding" => serde_json::json!({"tag":"long","value":"9007199254740993"}),
        "unary-divide" => serde_json::json!({"tag":"ratio","numerator":"1","denominator":"4"}),
        "negative-zero" => serde_json::json!({"tag":"long","value":"0"}),
        "predicate-identical-signed-zero" => serde_json::json!({"tag":"bool","value":false}),
        "number-to-string-2" => string("-0.0"),
        "number-to-string-4" => string("1.0E-7"),
        "number-to-string-5" => string("1.0E-6"),
        "number-to-string-6" => string("1.0E-5"),
        "number-to-string-7" => string("1.0E20"),
        "number-to-string-8" => string("1.0E21"),
        "number-to-string-9" => string("1.0E22"),
        "number-to-string-10" => string("1.0000000000000001E18"),
        "number-to-string-11" => string("1.2345678901234567E19"),
        "number-to-string-12" => string("4.9E-324"),
        "number-to-string-13" => string("1.7976931348623157E308"),
        _ => return None,
    })
}

/// Clojure governs (#286): pinned ClojureScript coerces these non-number
/// arithmetic operands, and Suss throws. Where the case measures conversion,
/// the same JavaScript conversion is retargeted to the coercing intrinsics
/// (`value-add` for +, `f64-coerce` for ToNumber), keeping its recorded value.
fn clojure_correction(id: &str, source: &str) -> Option<Option<String>> {
    let add = |operands: &str| Some(Some(format!("(suss.bootstrap/value-add {operands})")));
    let number = |operand: &str| format!("(suss.bootstrap/f64-coerce {operand})");
    if id.starts_with("number-to-string-") {
        return add(source.strip_prefix("(+ ")?.strip_suffix(')')?);
    }
    if id.starts_with("string-to-number-") {
        return Some(Some(number(source.strip_prefix("(* ")?.strip_suffix(" 1)")?)));
    }
    match id {
        "unary-plus-nil" | "unary-product-false" | "unary-plus-true"
        | "unary-product-surrogate" | "unary-plus-closure" | "unary-product-closure"
        | "unary-plus-branch" | "unary-product-nested" | "unary-plus-parameter"
        | "unary-product-parameter" | "unary-plus-global" | "unary-product-global"
        | "primitive-coercion-12" | "primitive-coercion-13" | "primitive-concat-dynamic-fold"
        | "function-add-identity-nil" | "function-multiply-identity-string"
        | "function-subtract-negative-zero" | "function-divide-unary" | "function-add-coercion"
        | "function-add-string-fold" | "function-multiply-fold" | "function-subtract-fold"
        | "function-divide-fold" | "function-qualified-alias" | "function-higher-order"
        | "function-computed-callee" | "function-returned-callee" | "function-closure-identity"
        | "function-invalid-numeric-string" | "function-negative-zero-string"
        | "loop-changing-type-arithmetic" => Some(None),
        // Number formatting and undefined field values, through the final +.
        // Clojure's integer division by zero throws; a double operand measures the format.
        "primitive-format-infinity" => add("(/ 1.0 0) \"\""),
        "primitive-format-neg-infinity" => add("(/ -1.0 0) \"\""),
        "primitive-format-nan" => add("(/ 0.0 0) \"\""),
        "nominal-undefined-number" | "nominal-ordinary-undefined-number"
        | "nominal-undefined-string" | "nominal-defprotocol-number-coercion"
        | "nominal-defprotocol-string-coercion" => {
            let at = source.rfind("(+ ")?;
            Some(Some(format!("{}(suss.bootstrap/value-add {}", &source[..at], &source[at + 3..])))
        }
        "primitive-coercion-1" => add("nil 1"),
        "primitive-coercion-2" => add("false 2"),
        "primitive-coercion-3" => add("true 2"),
        "primitive-coercion-4" => add("\"\" 2"),
        "primitive-coercion-5" => add("2 \"x\""),
        "primitive-coercion-6" => Some(Some(format!("(- {})", number("nil")))),
        "primitive-coercion-7" => Some(Some(format!("(- {} 1)", number("\" 2 \"")))),
        "primitive-coercion-8" => Some(Some(format!("(* {} 3)", number("\"2\"")))),
        "primitive-coercion-9" => Some(Some(format!("(* {} 3)", number("false")))),
        // The pinned case is IEEE reciprocal after ToNumber(nil). Unary
        // Clojure / is generic and checks zero; a literal double numerator
        // explicitly selects the primitive source overload for this retarget.
        "primitive-coercion-10" => Some(Some(format!("(/ 1.0 {})", number("nil")))),
        "primitive-coercion-11" => Some(Some(format!("(- {} 1)", number("\"bogus\"")))),
        "primitive-concat-surrogates" => add("\"\\uD800\" \"😀\""),
        "primitive-concat-null" => add("nil \"x\""),
        "primitive-concat-bools" => add("(suss.bootstrap/value-add \"\" false) true"),
        "primitive-concat-left-fold" => {
            add("(suss.bootstrap/value-add (suss.bootstrap/value-add 1 2) \"s\") 4")
        }
        "primitive-concat-branch" => add("(if true \"x\" 1) 2"),
        "primitive-arithmetic-branch" => add("(if false 1 nil) 2"),
        "exception-info-missing-constructor-cause" => {
            add("(ex-cause (ExceptionInfo. \"message\" 7)) 1")
        }
        "exception-info-missing-constructor-data" => {
            add("(ex-data (ExceptionInfo. \"message\")) 1")
        }
        "predicate-identical-strings" => Some(Some(
            "(identical? \"same\" (suss.bootstrap/value-add \"sa\" \"me\"))".into(),
        )),
        "predicate-identical-utf16" => Some(Some(
            "(identical? \"\\uD800😀\" (suss.bootstrap/value-add \"\\uD800\" \"😀\"))".into(),
        )),
        _ => None,
    }
}
#[test]
fn independently_compiled_fragment_values_remain_live_across_gc() {
    let engine = support::engine();
    let mut store = Store::new(&engine, ());
    let runtime = Instance::new(
        &mut store,
        &Module::new(&engine, runtime_abi::module()).unwrap(),
        &[],
    )
    .unwrap();
    let mut linker = Linker::new(&engine);
    linker
        .instance(&mut store, "suss.runtime", runtime)
        .unwrap();
    let run = |store: &mut Store<()>, source: &str| {
        let bytes = portable::compile(source).unwrap();
        runtime_abi::verify_artifact(&bytes, &runtime_abi::Manifest::default()).unwrap();
        let module = Module::new(&engine, bytes).unwrap();
        let instance = linker.instantiate(&mut *store, &module).unwrap();
        let mut result = [Val::null_any_ref()];
        instance
            .get_func(&mut *store, "eval")
            .unwrap()
            .call(&mut *store, &[], &mut result)
            .unwrap();
        result[0].clone()
    };
    let old = run(&mut store, r#""\uD800😀""#);
    store.gc(None).unwrap();
    let new = run(&mut store, "(let [x 9007199254740992] (+ x 1))");
    store.gc(None).unwrap();
    assert_eq!(
        tagged(&mut store, &old),
        serde_json::json!({"tag":"string","units":[0xd800,0xd83d,0xde00]})
    );
    assert_eq!(
        tagged(&mut store, &new),
        serde_json::json!({"tag":"long","value":"9007199254740993"})
    );
}

#[test]
fn lexical_bindings_hide_the_bootstrap_let_macro() {
    // The local callee now lowers to a universal call rather than a bootstrap macro.
    assert_eq!(long("(let [let (fn [x] x)] (let 7))"), 7);
    // True special forms remain special even when their names are locals.
    assert_eq!(long("(let [if 7 do 8] (if true (do 1 2) 3))"), 2);
    // A nested local hiding let does not escape its lexical scope.
    assert_eq!(long("(do (let [let 7] let) (let [x 3] x))"), 3);
}

#[test]
fn primitive_let_star_keeps_sequential_bindings_and_special_form_identity() {
    // Pinned analyzer.cljc parse let*2594: primitive lexical binding syntax.
    // These tests are original; no upstream implementation is copied.
    assert_eq!(long("(let* [base 40 copy (+ base 2)] copy)"), 42);
    assert_eq!(
        long("(let [let* 99] (let* [base 40 copy (+ base 2)] copy))"),
        42
    );
    let (mut store, value) = execute("(let* [copy 42])");
    assert_eq!(
        sentinel_tag(&mut store, &value).unwrap(),
        Some(runtime_abi::NIL as u32)
    );
}

#[test]
fn public_hir_negation_executes_and_malformed_arithmetic_is_rejected() {
    use portable::hir::{Arithmetic, Expression, Hir, Literal, Type};
    let make = |operator, count| Hir {
        source: None,
        span: 4..12,
        metadata: Vec::new(),
        ty: Type::Number,
        kind: std::sync::Arc::new(Expression::Arithmetic {
            operator,
            arguments: (0..count)
                .map(|_| Hir {
                    source: None,
                    span: 7..8,
                    metadata: Vec::new(),
                    ty: Type::Number,
                    kind: Expression::Literal(Literal::Number(0.0)).into(),
                })
                .collect(),
            coercing: false,
            primitive_overloads: vec![],
        }),
    };
    let ir = portable::ir::lower(&make(Arithmetic::Negate, 1)).unwrap();
    let (mut store, value) = execute_bytes(portable::compile_ir(&ir).unwrap());
    assert_eq!(
        tagged(&mut store, &value),
        serde_json::json!({"tag":"f64","bits":"8000000000000000"})
    );
    for (operator, count) in [
        (Arithmetic::Negate, 0),
        (Arithmetic::Negate, 2),
        (Arithmetic::Subtract, 0),
        (Arithmetic::Divide, 0),
    ] {
        let error = portable::ir::lower(&make(operator, count)).unwrap_err();
        assert_eq!(error.span, 4..12);
        assert!(error.message.contains("arity"));
    }
}

#[test]
fn recurrence_rejects_non_tail_wrong_arity_and_cross_function_targets_with_spans() {
    for (source, message) in [
        ("(recur)", "enclosing"),
        ("(loop [x 1] (recur))", "arity"),
        ("(loop [x 1] (+ (recur 2) 1))", "tail position"),
        ("(loop [x 1] (if (recur 2) x x))", "tail position"),
        ("(loop [x 1] (do (recur 2) x))", "tail position"),
        ("(loop [x 1] (let [y (recur 2)] y))", "tail position"),
        ("(loop [x 1] (fn [] (recur 2)))", "arity"),
        ("(loop [x 1] ((recur 2)))", "tail position"),
        ("(loop [x 1] (recur (recur 2)))", "tail position"),
    ] {
        let errors = portable::compile(source).unwrap_err();
        assert!(errors.message.contains(message), "{source}: {errors:?}");
        assert!(
            source[errors.span.clone()].starts_with("(recur"),
            "{source}: {errors:?}"
        );
    }
    assert_eq!(long("(let [loop (fn [x] x)] (loop 7))"), 7);
    assert_eq!(
        long("(cljs.core/loop [flag true x 1] (if flag (recur false 2) x))"),
        2
    );
    assert_eq!(long("(loop* [x 3] x)"), 3);
}

#[test]
fn malformed_public_hir_cannot_recur_from_operands_or_to_outer_targets() {
    use portable::hir::{Expression, Hir, LoopId, Type};
    let recur = Hir {
        source: None,
        span: 8..15,
        metadata: vec![],
        ty: Type::Value,
        kind: std::sync::Arc::new(Expression::Recur {
            target: LoopId(0),
            arguments: vec![],
        }),
    };
    let mut root = Hir {
        source: None,
        span: 0..20,
        metadata: vec![],
        ty: Type::Value,
        kind: std::sync::Arc::new(Expression::Loop {
            target: LoopId(0),
            bindings: vec![],
            body: Box::new(recur.clone()),
        }),
    };
    let graph = portable::ir::lower(&root).unwrap();
    portable::ir::verify(&graph).unwrap();
    if let Expression::Loop { body, .. } = root.kind_mut() {
        *body = Box::new(Hir {
            source: None,
            span: 8..18,
            metadata: vec![],
            ty: Type::Value,
            kind: std::sync::Arc::new(Expression::Do(vec![recur.clone(), recur.clone()])),
        });
    }
    assert!(
        portable::ir::lower(&root)
            .unwrap_err()
            .message
            .contains("tail position")
    );
    if let Expression::Loop { body, .. } = root.kind_mut() {
        *body = Box::new(Hir {
            source: None,
            span: 8..18,
            metadata: vec![],
            ty: Type::Value,
            kind: std::sync::Arc::new(Expression::Loop {
                target: LoopId(1),
                bindings: vec![],
                body: Box::new(recur),
            }),
        });
    }
    assert!(
        portable::ir::lower(&root)
            .unwrap_err()
            .message
            .contains("target or arity")
    );
}

#[test]
fn nil_test_verifier_checks_result_type_and_operand_definition() {
    use portable::{
        hir::Type,
        ir::{self, Operation, ValueId},
    };
    let hir = portable::analyze("(suss.bootstrap/nil? nil)").unwrap();
    let function = ir::lower(&hir).unwrap();
    ir::verify(&function).unwrap();
    let instruction = function
        .blocks
        .iter()
        .flat_map(|b| &b.instructions)
        .find(|i| matches!(i.operation, Operation::NilTest(_)))
        .unwrap();
    let mut bad = function.clone();
    bad.values[instruction.result.0].ty = Type::Number;
    assert!(ir::verify(&bad).unwrap_err().message.contains("nil-test"));
    let mut bad = function.clone();
    let operation = bad
        .blocks
        .iter_mut()
        .flat_map(|b| &mut b.instructions)
        .find(|i| matches!(i.operation, Operation::NilTest(_)))
        .unwrap();
    operation.operation = Operation::NilTest(ValueId(usize::MAX));
    assert!(
        ir::verify(&bad)
            .unwrap_err()
            .message
            .contains("no definition")
    );
    let mut bad = function.clone();
    let instruction = bad
        .blocks
        .iter_mut()
        .flat_map(|b| &mut b.instructions)
        .find(|i| matches!(i.operation, Operation::NilTest(_)))
        .unwrap();
    instruction.operation = Operation::NilTest(instruction.result);
    assert!(
        ir::verify(&bad)
            .unwrap_err()
            .message
            .contains("does not dominate")
    );
    let mut bad_hir = hir;
    let portable::hir::Expression::Do(items) = bad_hir.kind_mut() else {
        panic!("top-level forms")
    };
    items[0].ty = Type::Number;
    assert!(
        ir::lower(&bad_hir)
            .unwrap_err()
            .message
            .contains("nil-test HIR")
    );
}

#[test]
fn closures_beyond_the_old_verifier_depth_execute() {
    let mut source = "42".to_owned();
    for _ in 0..80 { source = format!("(fn* [] {source})"); }
    for _ in 0..80 { source = format!("({source})"); }
    assert_eq!(long(&source), 42);
}
