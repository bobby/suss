"""Run the exact numeric workspace baseline after native acceptance closes."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess
import sys
import time

E = Path(__file__).resolve().parent
F = E.parent / 'm12-numeric-completion'
J = Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-case-budget-source')
expected_head, native_phase, phase = sys.argv[1:]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=F, text=True).strip()
assert head == expected_head
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=F, text=True)
scope = os.environ['SUSS_DURABLE_SCOPE']
assert scope in Path('/proc/self/cgroup').read_text()

# Both actual prerequisite recorders must have terminated successfully and
# archived their frozen sources. Observation timeouts and interrupted runs
# cannot satisfy this gate.
prerequisites = [
    J / 'results/m12-eval/exact-workspace-reviewed-core-eval-disk-tmp',
    F / 'results/m12-num-api' / native_phase,
]
prior_receipts = {}
for prior in prerequisites:
    receipt_path = prior / 'commands.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['complete'] and receipt['exit_code'] == 0, str(prior)
    assert receipt['inputs_unchanged'] and receipt['binaryen_unchanged']
    if prior == prerequisites[0]:
        # This specific older runner's unchanged() includes HEAD, input bytes,
        # and its own source. Authenticate that exact archived implementation.
        assert receipt['head'] == '052668a3776a64fcc6ce58269ee5d0f524b315a1'
        assert receipt['runner_sha256'] == '74ff92780e2a6d470fc44f1d4f1bbfb056b2acd0e6941ce740929648a78963e1'
    else:
        assert receipt['head_unchanged']
    assert all(c['complete'] and c['exit_code'] == 0 for c in receipt['commands'])
    assert not Path(f"/proc/{receipt['recorder_pid']}").exists()
    assert hashlib.sha256(gzip.decompress((prior / 'runner.py.gz').read_bytes())).hexdigest() == receipt['runner_sha256']
    assert json.loads((prior / 'deleted.json').read_text()) == []
    prior_receipts[str(receipt_path)] = sha(receipt_path)
native = json.loads((prerequisites[1] / 'commands.json').read_text())
assert native['head'] == head
assert native['external_tools_unchanged'] and native['runner_archived']
assert all(Path(p).is_file() and sha(Path(p)) == h for p,h in native['external_tools'].items())
assert all((F / p).is_file() and sha(F / p) == h for p,h in native['inputs'].items())
admission_path = E / 'numeric-reviewed-core-current-source-admission.json'
admission = json.loads(admission_path.read_text())
assert admission['head'] == head
assert [len(i['requirements']) for i in admission['issues']] == [9, 6]
assert admission['all_case_file_blobs_conserved']
assert admission['symbolic_arity_regression']['pinned_primary_controls'] == 10
assert admission['symbolic_region_regression']['pinned_primary_controls'] == 9
assert admission['symbolic_root_scope_regression']['pinned_primary_controls'] == 3
assert sha(admission_path) == native['external_tools'][str(admission_path)]

temp_root = E / 'numeric-test-temp' / phase
temp_root.mkdir(parents=True, exist_ok=False, mode=0o700)
out = F / 'results/m12-num-api' / phase
out.mkdir(exist_ok=False)
tracked = set(subprocess.check_output(['git', 'ls-files'], cwd=F, text=True).splitlines())
paths = set(subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard'], cwd=F, text=True).splitlines())
paths = {p for p in paths if p in tracked or not p.startswith('results/') or
    ('/overlay/' not in p and '/source-overlay/' not in p and
     (any('primary' in a for a in Path(p).parts) or p.endswith(('cases.json', 'reference.json'))))}
inputs = {p: sha(F / p) for p in sorted(paths) if (F / p).is_file()}
binaryen = J.parent / 'm11-binaryen/binaryen-version_133/bin'
tools = {str(binaryen / n): sha(binaryen / n) for n in ['wasm-opt', 'wasm-merge']}
external = prior_receipts | native['external_tools'] | {str(admission_path): sha(admission_path)}
state = {'head': head, 'phase': phase, 'scope': scope, 'recorder_pid': os.getpid(),
    'inputs': inputs, 'binaryen': tools, 'external_tools': external,
    'runner_sha256': sha(Path(__file__)), 'temporary_directory': str(temp_root),
    'native_acceptance_phase': native_phase, 'native_outer_actual_exit': 0, 'commands': [], 'complete': False}

def save():
    (out / 'commands.json').write_text(json.dumps(state, indent=2) + '\n')

def conserved():
    return (subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=F, text=True).strip() == head
        and all((F / p).is_file() and sha(F / p) == h for p, h in inputs.items())
        and sha(Path(__file__)) == state['runner_sha256'])

def external_conserved():
    return all(Path(p).is_file() and sha(Path(p)) == h for p, h in external.items())

def tools_conserved():
    return all(Path(p).is_file() and sha(Path(p)) == h for p, h in tools.items())

env = os.environ | {'CARGO_TARGET_DIR': str(E.parent / 'pattern-compiled-target'),
    'TMPDIR': str(temp_root), 'CARGO_BUILD_JOBS': '1', 'RUSTUP_TOOLCHAIN': 'stable',
    'BINARYEN_CORES': '1', 'SUSS_WASM_OPT': str(binaryen / 'wasm-opt'),
    'SUSS_CLOJURE_TEST_SUITE_CAPTURE': str(out / 'capture'),
    'SUSS_NUMERIC_BODY_CAPTURE': str(out / 'capture'),
    'SUSS_EVAL_BODY_CAPTURE': str(out / 'capture')}
env['PATH'] = str(binaryen) + os.pathsep + env['PATH']
env.pop('SUSS_CLOJURE_TEST_SUITE_WRITE', None)
try:
    save()
    assert conserved() and tools_conserved() and external_conserved()
    command = ['cargo', 'test', '--workspace', '--locked', '--', '--test-threads=2']
    row = {'name': 'exact-two-thread-workspace', 'command': command,
        'env_overrides': {'TMPDIR': str(temp_root)}, 'complete': False}
    state['commands'].append(row)
    save()
    start = time.monotonic()
    with (out / 'exact-two-thread-workspace.log').open('w') as log:
        proc = subprocess.Popen(command, cwd=F, env=env, stdout=log, stderr=subprocess.STDOUT)
        row['pid'] = proc.pid
        save()
        code = proc.wait()
    row.update(complete=True, exit_code=code, seconds=time.monotonic() - start)
except Exception as exc:
    state['controller_error'] = repr(exc)
finally:
    state.update(complete=True, inputs_unchanged=conserved(),
        head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=F, text=True).strip() == head,
        binaryen_unchanged=tools_conserved(), external_tools_unchanged=external_conserved())
    state['exit_code'] = next((c['exit_code'] for c in state['commands'] if c.get('exit_code')), 0)
    if ('controller_error' in state or len(state['commands']) != 1
            or any(not c['complete'] or 'exit_code' not in c for c in state['commands'])
            or not all(state[k] for k in
            ['inputs_unchanged', 'head_unchanged', 'binaryen_unchanged', 'external_tools_unchanged'])):
        state['exit_code'] = state['exit_code'] or 1
    save()
    if state['inputs_unchanged'] and state['binaryen_unchanged'] and state['external_tools_unchanged']:
        (out / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
        (out / 'source-admission.json.gz').write_bytes(gzip.compress(admission_path.read_bytes(), mtime=0))
        for name in inputs.keys() - tracked:
            assert sha(F / name) == inputs[name]
            archived = out / 'source-overlay' / (name + '.gz')
            archived.parent.mkdir(parents=True, exist_ok=True)
            archived.write_bytes(gzip.compress((F / name).read_bytes(), mtime=0))
        (out / 'deleted.json').write_text('[]\n')
        state['runner_archived'] = True
        save()
    print(json.dumps({k: v for k, v in state.items() if k not in ['inputs', 'commands']}, indent=2), flush=True)
sys.exit(state['exit_code'])
