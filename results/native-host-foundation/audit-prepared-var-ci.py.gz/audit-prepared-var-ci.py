"""Verify archived current-head job evidence without changing the checkout."""
from pathlib import Path
import hashlib, json

E = Path(__file__).resolve().parent
P = E / 'ci-a97bfaac'
head = 'a97bfaac7fe72bb2366297a263108fb347fb74aa'
record = json.loads((P / 'workflow.json').read_text())
run = record['run']
assert run['headSha'] == head
jobs = record['completed_job_evidence']
for job in jobs:
    raw = (P / (job['id'] + '.log')).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == job['log_sha256']
    meta = json.loads((P / (job['id'] + '.json')).read_text())
    assert meta['head_sha'] == head and str(meta['id']) == job['id']
    assert meta['status'] == 'completed' and meta['conclusion'] == job['conclusion']
required = {'foundation', 'test'} | {f'integration ({i})' for i in range(8)}
success = (run['status'] == 'completed' and run['conclusion'] == 'success'
           and {j['job'] for j in jobs} == required
           and all(j['conclusion'] == 'success' for j in jobs))
shards = sorted(int(j['job'].split('(')[1].split(')')[0]) for j in jobs
                if j['job'].startswith('integration (') and j['conclusion'] == 'success')
out = {'head': head, 'run': 45956702088,
       'url': 'https://github.com/bobby/suss/actions/runs/45956702088',
       'status': run['status'], 'conclusion': run['conclusion'],
       'all_ten_jobs_actual_success': success, 'completed_successful_shards': shards,
       'completed_job_evidence': jobs,
       'passed_test_executions_in_completed_jobs': sum(j['passed_test_executions'] for j in jobs),
       'qualification': 'Archived job logs and metadata are hash/head verified. Exact local workspace and independent follow-up review remain separate gates.'}
(E / 'prepared-var-ci-audit.json').write_text(json.dumps(out, indent=2) + '\n')
p = E / 'session-state.json'
state = json.loads(p.read_text())
state['completed_ci_shards'] = shards
state['prepared_var_ci_audit'] = 'core-boundary-foundation/prepared-var-ci-audit.json'
state['ci_current_source_qualification'] = (
    'Currenta97 all10jobs actualsuccess, archived/head/hashverified; exactlocalfull and follow-upreview stillseparate.'
    if success else f'Currenta97 {len(shards)}/8integrations actualsuccess, archived/head/hashverified; wholeCI incomplete.')
state['ci_integrations'] = f'Currenta97 successfulshards{shards}; actualrunstatus={run["status"]}, conclusion={run["conclusion"]!r}. See prepared-var-ci-audit.json; no localfull/review/promotion claim.'
p.write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps({k: v for k, v in out.items() if k != 'completed_job_evidence'}, indent=2))
