//! Remove eval locals that are never read, retaining all evaluated operands.
use wasm_encoder::{Function, Instruction, ValType};
use wasmparser::{BinaryReader, FunctionBody, Operator};

pub(super) fn compact(
    function: Function,
    declarations: &[(u32, ValType)],
    parameters: u32,
) -> Result<Function, String> {
    let total = declarations.iter().try_fold(parameters, |n, (count, _)| n.checked_add(*count))
        .ok_or("Too many emitted locals")?;
    let bytes = function.into_raw_body();
    let body = FunctionBody::new(BinaryReader::new(&bytes, 0));
    let mut needed = vec![false; total as usize];
    needed[..parameters as usize].fill(true);
    let mut reader = body.get_operators_reader().map_err(|e| e.to_string())?;
    while !reader.eof() {
        if let Operator::LocalGet { local_index } = reader.read().map_err(|e| e.to_string())? {
            *needed.get_mut(local_index as usize).ok_or("Invalid emitted local read")? = true;
        }
    }
    let mut mapping = vec![None; total as usize];
    for i in 0..parameters { mapping[i as usize] = Some(i); }
    let mut kept: Vec<(u32, ValType)> = Vec::new();
    let mut old = parameters;
    let mut next = parameters;
    for &(count, ty) in declarations {
        for _ in 0..count {
            if needed[old as usize] {
                mapping[old as usize] = Some(next);
                next += 1;
                match kept.last_mut() {
                    Some((count, previous)) if *previous == ty => *count += 1,
                    _ => kept.push((1, ty)),
                }
            }
            old += 1;
        }
    }
    let mut result = Function::new(kept);
    let mut reader = body.get_operators_reader().map_err(|e| e.to_string())?;
    while !reader.eof() {
        let start = reader.original_position();
        let operation = reader.read().map_err(|e| e.to_string())?;
        let end = reader.original_position();
        match operation {
            Operator::LocalGet { local_index } => {
                let index = mapping.get(local_index as usize).copied().flatten()
                    .ok_or("Missing emitted local read")?;
                result.instruction(&Instruction::LocalGet(index));
            }
            Operator::LocalSet { local_index } | Operator::LocalTee { local_index } => {
                let index = mapping.get(local_index as usize).ok_or("Invalid emitted local write")?;
                match (index, operation) {
                    (Some(index), Operator::LocalSet { .. }) => { result.instruction(&Instruction::LocalSet(*index)); }
                    (Some(index), _) => { result.instruction(&Instruction::LocalTee(*index)); }
                    (None, Operator::LocalSet { .. }) => { result.instruction(&Instruction::Drop); }
                    // A tee leaves its operand on the stack even when nobody
                    // later reads the local; omit only the redundant store.
                    (None, _) => {}
                }
            }
            // Preserve all other opcodes and immediates byte for byte,
            // including calls, branches, reference types and numeric bits.
            _ => { result.raw(bytes[start..end].iter().copied()); }
        }
    }
    Ok(result)
}

#[cfg(all(test, not(suss_generator)))]
mod tests {
    use super::*;
    use wasm_encoder::{BlockType, CodeSection, EntityType, ExportKind, ExportSection,
        FunctionSection, ImportSection, Module, TypeSection};

    #[test]
    fn unused_locals_keep_parameters_tee_values_branches_and_effects() {
        let declarations = [(3, ValType::I32)];
        let mut function = Function::new(declarations);
        for instruction in [Instruction::LocalGet(0), Instruction::LocalTee(2),
            Instruction::LocalSet(1), Instruction::Call(0), Instruction::LocalSet(3),
            Instruction::LocalGet(0), Instruction::I32Eqz, Instruction::If(BlockType::Empty),
            Instruction::I32Const(99), Instruction::LocalSet(1), Instruction::End,
            Instruction::LocalGet(1), Instruction::End] {
            function.instruction(&instruction);
        }
        let function = compact(function, &declarations, 1).unwrap();
        let raw = function.clone().into_raw_body();
        let body = FunctionBody::new(BinaryReader::new(&raw, 0));
        assert_eq!(body.get_locals_reader().unwrap().into_iter().collect::<Result<Vec<_>, _>>().unwrap(),
            vec![(1, wasmparser::ValType::I32)]);
        let mut module = Module::new();
        let mut types = TypeSection::new();
        types.ty().function([], [ValType::I32]);
        types.ty().function([ValType::I32], [ValType::I32]);
        module.section(&types);
        let mut imports = ImportSection::new();
        imports.import("host", "effect", EntityType::Function(0));
        module.section(&imports);
        let mut functions = FunctionSection::new();
        functions.function(1);
        module.section(&functions);
        let mut exports = ExportSection::new();
        exports.export("f", ExportKind::Func, 1);
        module.section(&exports);
        let mut code = CodeSection::new();
        code.function(&function);
        module.section(&code);
        let engine = wasmtime::Engine::default();
        let module = wasmtime::Module::new(&engine, module.finish()).unwrap();
        let mut store = wasmtime::Store::new(&engine, 0u32);
        let effect = wasmtime::Func::wrap(&mut store, |mut caller: wasmtime::Caller<'_, u32>| {
            *caller.data_mut() += 1;
            9i32
        });
        let instance = wasmtime::Instance::new(&mut store, &module, &[effect.into()]).unwrap();
        let f = instance.get_typed_func::<i32, i32>(&mut store, "f").unwrap();
        assert_eq!(f.call(&mut store, 7).unwrap(), 7);
        assert_eq!(f.call(&mut store, 0).unwrap(), 99);
        assert_eq!(*store.data(), 2);
    }
}
