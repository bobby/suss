from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/home/bobby/.codex-workspaces/cleanup/suss-20261123/eval-next-step/native-host-var-foundation')
phase=sys.argv[1]
out=root/'results/native-host-foundation'/phase
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
tracked=set(subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines())
paths=set(subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=root,text=True).splitlines())
paths={p for p in paths if p in tracked or not p.startswith('results/') or ('/overlay/' not in p and (any('primary' in a for a in Path(p).parts) or p.endswith('/cases.json')))}
inputs={p:sha(root/p) for p in sorted(paths) if (root/p).is_file()}
binaryen=Path('/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m11-binaryen/binaryen-version_133/bin')
tools={str(binaryen/n):sha(binaryen/n) for n in ['wasm-opt','wasm-merge']}
state={'head':head,'phase':phase,'recorder_pid':os.getpid(),'inputs':inputs,'binaryen':tools,'commands':[],'complete':False,'runner_sha256':sha(Path(__file__))}
def save():
 (out/'commands.json').write_text(json.dumps(state,indent=2)+'\n')
 (Path(__file__).parent/('namespace-native-values-'+phase+'-state.json')).write_text(json.dumps({k:v for k,v in state.items() if k!='inputs'},indent=2)+'\n')
def unchanged():
 return head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() and all((root/p).is_file() and sha(root/p)==h for p,h in inputs.items()) and sha(Path(__file__))==state['runner_sha256']
env=os.environ|{'CARGO_TARGET_DIR':'/home/bobby/.codex-workspaces/worktrees/ios-cd7ccbc9-1c87-43fe-95e7-2b6b71168849/suss/target/probe/m12-some-fn-target','CARGO_BUILD_JOBS':'1','RUSTUP_TOOLCHAIN':'stable','BINARYEN_CORES':'1','SUSS_WASM_OPT':str(binaryen/'wasm-opt')}
env['PATH']=str(binaryen)+os.pathsep+env['PATH']
env['SUSS_CLOJURE_TEST_SUITE_CAPTURE']=str(out/'capture')
if phase in ['factory-profile-working','shared-identifiers-profile-working','interned-keywords-profile-working','murmur-profile-working','guarded-murmur-profile-working','catalog-repeat-profile-before','catalog-canonical-keys-working']: env['SUSS_NAMESPACE_FUEL_TRACE']='1'
commands=[('original-aot-metadata-constructor-control', ['cargo', 'test', '--workspace', '--locked', '--test', 'portable_aot_options', 'option_schema_survives_core_function_and_constructor_redefinition', '--', '--nocapture', '--test-threads=2']), ('runtime-capability-contract', ['cargo', 'test', '--workspace', '--locked', '--test', 'runtime_evaluation', '--', '--nocapture', '--test-threads=2']), ('var-and-symbol-primary-controls', ['cargo', 'test', '--workspace', '--locked', '--test', 'portable_symbol_conversion', '--', '--nocapture', '--test-threads=2']), ('all-original-suite-guards', ['cargo', 'test', '--workspace', '--locked', '--test', 'clojure_test_suite', '--', '--nocapture', '--test-threads=2']), ('java-node-free-bootstrap', ['sh', 'scripts/verify-bootstrap.sh']), ('core-import-source-verification', ['python3', 'scripts/core_import.py', '--check']), ('live-var-provenance-verification', ['python3', 'results/m12-eval/verify-live-vars.py']), ('original-metadata-and-source-projections', ['cargo', 'test', '--workspace', '--locked', '--test', 'compiled_export_metadata', '--test', 'compiled_macro_constructor_source_asts', '--test', 'compiled_macro_source_hint_boundaries', '--test', 'compiled_macro_binding_records', '--test', 'compiled_macro_field_records', '--', '--nocapture', '--test-threads=2']), ('python-script-tests', ['python3', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_*.py'])]


try:
 save()
 for name,cmd in commands:
  assert unchanged(),'frozen inputs changed before command'
  row={'name':name,'command':cmd,'complete':False};state['commands'].append(row);save()
  start=time.monotonic()
  with (out/(name+'.log')).open('w') as log:
   overrides={'SUSS_MACRO_FUEL_TRACE':'1','SUSS_NAMESPACE_FUEL_TRACE':'1'} if name=='compiler-catalog-cost-trace' else {}
   row['env_overrides']=overrides;save()
   proc=subprocess.Popen(cmd,cwd=root,env=env|overrides,stdout=log,stderr=subprocess.STDOUT)
   row['pid']=proc.pid;save();code=proc.wait()
  row.update(complete=True,exit_code=code,seconds=time.monotonic()-start);save();print(row,flush=True)
  if code:break
 state.update(complete=True,inputs_unchanged=unchanged(),binaryen_unchanged=all(sha(Path(p))==h for p,h in tools.items()))
 state['exit_code']=next((r['exit_code'] for r in state['commands'] if r.get('exit_code')),0)
 save()
except Exception as e:
 state.update(complete=True,controller_error=repr(e));save();raise
sys.exit(state['exit_code'])
