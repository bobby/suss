from pathlib import Path
import gzip,hashlib,json,sys
E=Path(__file__).resolve().parent; C=E.parent/'native-host-var-foundation'; R=C/'results/native-host-foundation'; phase='exact-workspace-prepared-var-checkpoint'
receipt=json.loads((R/phase/'commands.json').read_text()); assert receipt['complete'] and receipt['exit_code']==0 and receipt['inputs_unchanged'] and receipt['binaryen_unchanged']; assert (R/phase/'runner.py.gz').exists()
sys.path.insert(0,str(C/'scripts')); import clojure_test_suite as suite
read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
new=R/phase/'capture/suite-observations.json'; old=R/'exact-workspace-artifact-publication/capture/suite-observations.json'
if not old.exists():old=old.with_suffix('.json.gz')
actual=read(new);prior=read(old);reference=read(C/'tests/oracle/clojure-test-suite-observations.json'); expected=read(C/'tests/oracle/clojure-test-suite-known-failures.json')
key=lambda r:r['test']+'#'+str(r['ordinal']); refs={r['id']:r for r in reference['assertions']}
assert [key(r) for r in actual['assertions']]==[key(r) for r in prior['assertions']]
assert len(actual['assertions'])==5530
for a,b in zip(actual['assertions'],prior['assertions']):assert suite.decide(refs[key(a)],a)==suite.decide(refs[key(b)],b),key(a)
counts,failures=suite.compare(reference,actual);assert failures==expected
assert counts=={'pass':5325,'guest-judged':101,'fail':105,'namespaces-failed':64,'not-executed':1408,'skipped':0},counts
assert not any(r['test'].startswith('clojure.core-test.eval/') for r in actual['assertions'])
out={'phase':phase,'capture_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'counts':counts,'raw_rows':5530,'ordered_ids_and_decisions_equal_to_prior_scoped_run':True,'failures_equal_to_reviewed_baseline':True,'public_eval_absent':True}
(E/'prepared-var-workspace-capture-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
