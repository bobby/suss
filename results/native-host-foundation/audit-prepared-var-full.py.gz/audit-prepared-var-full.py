"""Audit a completed exact baseline; never interpret a live run as success."""
from pathlib import Path
import gzip, hashlib, json, re

E = Path(__file__).resolve().parent
C = E.parent / 'native-host-var-foundation'
R = C / 'results/native-host-foundation'
phase = 'exact-workspace-prepared-var-checkpoint'
current = R / phase
receipt = json.loads((current / 'commands.json').read_text())
assert receipt['complete'] and receipt['exit_code'] == 0
assert receipt['inputs_unchanged'] and receipt['binaryen_unchanged']
assert receipt['head'] == 'a97bfaac7fe72bb2366297a263108fb347fb74aa'
assert len(receipt['commands']) == 1
command = receipt['commands'][0]
assert command['complete'] and command['exit_code'] == 0
assert command['command'] == ['cargo', 'test', '--workspace', '--locked', '--', '--test-threads=2']
runner = gzip.decompress((current / 'runner.py.gz').read_bytes())
assert hashlib.sha256(runner).hexdigest() == receipt['runner_sha256']
assert json.loads((current / 'deleted.json').read_text()) == []

def read_log(directory):
    p = directory / 'exact-two-thread-workspace.log'
    return p.read_text() if p.exists() else gzip.decompress(p.with_suffix('.log.gz').read_bytes()).decode()

def totals(text):
    groups = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    assert groups and not any(int(row[1]) for row in groups)
    return {'passed': sum(int(row[0]) for row in groups),
            'ignored': sum(int(row[2]) for row in groups), 'groups': len(groups)}

historical = R / 'exact-workspace-artifact-publication'
old = json.loads((historical / 'commands.json').read_text())
assert old['complete'] and old['exit_code'] == 0 and old['inputs_unchanged'] and old['binaryen_unchanged']
before = totals(read_log(historical))
after = totals(read_log(current))
# The implementation added three regressions to an existing test target.
# All original test bodies and the complete exact command are conserved.
assert after == {'passed': before['passed'] + 3, 'ignored': before['ignored'], 'groups': before['groups']}, (before, after)
out = {'phase': phase, 'head': receipt['head'], 'actual_exit': 0,
       'command': command['command'], 'seconds': command['seconds'],
       'frozen_input_count': len(receipt['inputs']), 'inputs_head_runner_binaryen_conserved': True,
       'runner_archive_verified': True, 'deleted_inputs': [],
       'historical_source': old['head'], 'historical_totals': before,
       'current_totals': after, 'additional_regressions': 3,
       'qualification': 'Actual complete exact workspace execution only. Capture audit, independent follow-up review and final-head CI require their own evidence.'}
(E / 'prepared-var-exact-workspace-audit.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
