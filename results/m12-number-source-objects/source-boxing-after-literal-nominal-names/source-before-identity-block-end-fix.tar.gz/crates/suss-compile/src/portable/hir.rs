//! Source-aware HIR for the replacement pipeline. No EDN conversion occurs.
mod arrays;
mod letfn;
mod local_bindings;
pub use local_bindings::{FieldBinding, FunctionScope, LocalBinding, LocalKind, SourceRole};
mod function_parameters;
mod destructuring;
pub use function_parameters::{SourceFunctionParameters, SourceParameterMethod};
mod bitwise;
mod callable_signatures;
mod cases;
mod collections;
mod comparisons;
mod controls;
mod division_overloads;
mod object_context;
mod extrema;
mod local_hints;
mod dynamic;
mod namespaces;
mod exceptions;
mod nominal;
mod quotes;
mod vars;
mod primitive_returns;
mod source_tags;
use super::{
    Diagnostic,
    resolve::{Binding as ResolvedBinding, Environment, Global, Phase},
};
pub use quotes::{identifier_hash, reader_metadata_pairs, reader_metadata_pairs_metered};
pub use source_tags::{SourceTags, declaration_tag, local_tag};
pub(crate) use source_tags::{declaration_tag_metered, local_tag_metered};
use std::{
    collections::{BTreeMap, BTreeSet, HashMap},
    ops::Range,
};
use suss_reader::forms::{Form, Kind};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Type {
    Nil,
    Bool,
    Number,
    String,
    Value,
    Closure(usize),
}
impl Type {
    pub(crate) fn accepts(self, other: Self) -> bool {
        self == Self::Value || self == other
    }
}
#[derive(Debug, Clone)]
pub enum Literal {
    Nil,
    /// Internal bootstrap result; there is no undefined source literal.
    Undefined,
    Bool(bool),
    /// A double.
    Number(f64),
    /// A source double literal consumed as an Object constant.
    ObjectNumber(f64),
    Long(i64),
    BigInt { negative: bool, limbs: Vec<u32>, big_integer: bool },
    Ratio { negative: bool, numerator: Vec<u32>, denominator: Vec<u32> },
    Decimal { negative: bool, unscaled: Vec<u32>, scale: i32 },
    String(Vec<u16>),
}
impl Literal {
    pub fn ty(&self) -> Type {
        match self {
            Self::Nil => Type::Nil,
            Self::Undefined => Type::Value,
            Self::Bool(_) => Type::Bool,
            Self::Number(_) | Self::ObjectNumber(_) | Self::Long(_) | Self::BigInt { .. } | Self::Ratio { .. } | Self::Decimal { .. } => Type::Number,
            Self::String(_) => Type::String,
        }
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Arithmetic {
    Add,
    Subtract,
    Multiply,
    Divide,
    Negate,
}
/// Primitive result information. Checked operands throw unless they are
/// Numbers, as in Clojure (#286), so every checked result is a Number. Shipped
/// core's coercing arithmetic keeps JavaScript results; object conversions
/// remain an explicit unsupported boundary there, not Number casts.
pub(crate) fn arithmetic_type(
    operator: Arithmetic,
    arguments: &[Type],
    coercing: bool,
) -> Option<Type> {
    if !coercing {
        return Some(Type::Number);
    }
    if arguments.len() == 1 && matches!(operator, Arithmetic::Add | Arithmetic::Multiply) {
        return Some(arguments[0]);
    }
    if arguments.iter().any(|ty| matches!(ty, Type::Closure(_))) {
        return None;
    }
    if operator != Arithmetic::Add || arguments.is_empty() {
        return Some(Type::Number);
    }
    Some(arguments[1..].iter().fold(arguments[0], |left, &right| {
        if left == Type::String || right == Type::String {
            Type::String
        } else if [left, right]
            .iter()
            .all(|ty| matches!(ty, Type::Nil | Type::Bool | Type::Number))
        {
            Type::Number
        } else {
            Type::Value
        }
    }))
}
/// Primitive receiver kinds used only by the native protocol bootstrap.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NativeKind {
    Nil,
    Boolean,
    Number,
    String,
    Function,
    Object,
    Array,
    Default,
}
impl NativeKind {
    pub(crate) fn index(self) -> i32 {
        self as i32
    }
    pub(crate) fn from_form(form: &Form) -> Option<Self> {
        match &form.kind {
            Kind::Nil => Some(Self::Nil),
            Kind::Symbol(symbol) if symbol.namespace.is_none() => match symbol.name.as_str() {
                "boolean" => Some(Self::Boolean),
                "number" => Some(Self::Number),
                "string" => Some(Self::String),
                "function" => Some(Self::Function),
                "object" => Some(Self::Object),
                "array" => Some(Self::Array),
                "default" => Some(Self::Default),
                _ => None,
            },
            _ => None,
        }
    }
}
/// Bounded array macro operations; operands are evaluated once before execution.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ArrayOperation {
    Literal,
    /// A collection literal's elements as an object array (#378).
    Objects,
    Make,
    Length,
    Get,
    Set,
    /// `(aclone a)`, inline as Clojure's :inline aclone (#443).
    Clone,
}
impl ArrayOperation {
    pub(crate) fn export(self) -> &'static str {
        match self {
            // Clojure's object arrays (#425): `(array ...)` wraps its fresh
            // argument array, and `make-array` fills one with nil.
            Self::Literal | Self::Objects => "object-array-new",
            Self::Make => "object-array-make-args",
            Self::Length => "array-length-args",
            Self::Get => "array-get-indices",
            Self::Set => "array-set-indices",
            Self::Clone => "array-clone",
        }
    }
    pub(crate) fn valid(self, count: usize) -> bool {
        count <= i32::MAX as usize
            && match self {
                Self::Literal | Self::Objects => true,
                Self::Make => count >= 1,
                Self::Length => count == 1,
                Self::Get => count >= 2,
                Self::Set => count >= 3,
                Self::Clone => count == 1,
            }
    }
}
/// Original checked binary comparison primitive used after bounded macro expansion.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Comparison {
    Less,
    LessEqual,
    Greater,
    GreaterEqual,
    StrictEqual,
    /// `case`'s test of a scalar constant: numbers match only within their
    /// kind, doubles by their bits.
    CaseEqual,
    /// Clojure numeric comparison: non-Number operands throw (#286). Shipped
    /// core and compiler-generated tests keep the coercing variants above.
    NumberLess,
    NumberLessEqual,
    NumberGreater,
    NumberGreaterEqual,
    NumberEqual,
    /// Inline `zero?`, `pos?` and `neg?` against literal 0, named in errors.
    NumberZero,
    NumberPositive,
    NumberNegative,
}
impl Comparison {
    pub(crate) fn export(self) -> &'static str {
        match self {
            Self::Less => "comparison-less",
            Self::LessEqual => "comparison-less-equal",
            Self::Greater => "comparison-greater",
            Self::GreaterEqual => "comparison-greater-equal",
            Self::StrictEqual => "comparison-strict-equal",
            Self::CaseEqual => "comparison-case-equal",
            Self::NumberLess => "comparison-number-less",
            Self::NumberLessEqual => "comparison-number-less-equal",
            Self::NumberGreater => "comparison-number-greater",
            Self::NumberGreaterEqual => "comparison-number-greater-equal",
            Self::NumberEqual => "comparison-number-equal",
            Self::NumberZero => "comparison-number-zero",
            Self::NumberPositive => "comparison-number-positive",
            Self::NumberNegative => "comparison-number-negative",
        }
    }
    /// The checked public variant of a source comparison.
    pub(crate) fn numeric(self) -> Self {
        match self {
            Self::Less | Self::NumberLess => Self::NumberLess,
            Self::LessEqual | Self::NumberLessEqual => Self::NumberLessEqual,
            Self::Greater | Self::NumberGreater => Self::NumberGreater,
            Self::GreaterEqual | Self::NumberGreaterEqual => Self::NumberGreaterEqual,
            Self::StrictEqual | Self::NumberEqual => Self::NumberEqual,
            Self::NumberZero | Self::NumberPositive | Self::NumberNegative | Self::CaseEqual => self,
        }
    }
}
/// Checked scalar bitwise primitive; direct macro folds retain nested evaluation.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Bitwise {
    Int,
    /// Source-selected primitive overloads; all three retain source int kind.
    IntPrimitive,
    IntFloat,
    And,
    Or,
    Xor,
    AndNot,
    Not,
    Clear,
    Flip,
    Set,
    Test,
    Left,
    Right,
    Unsigned,
    /// Shipped core's private 32-bit operations, as ClojureScript's, which
    /// its hashing and collection tries depend on (#336).
    Int32,
    Int32And,
    Int32Or,
    Int32Xor,
    Int32Left,
    Int32Right,
    Int32Unsigned,
    Imul,
    /// Private Clojure numeric casts: the operand and a `CASTS` index (#336).
    Cast,
    /// Private Java Number.intValue conversion for Clojure comparators.
    IntValue,
    /// Private scalar binary64 storage adapters; never public bitwise macros.
    F64Coerce,
    F64Word0,
    F64Word4,
    F64Floor,
    F64Ceil,
    F64Finite,
    F64SafeInteger,
    F64TimeClip,
    /// Execution-time entropy; never a compiler constant or a pure operation.
    RandomDouble,
    EvaluateForm,
    SafeIntegerRemainder,
    F64Remainder,
    IdentityUid,
    /// Private exact numeric operations behind core's `quot`, `rem`, `abs`,
    /// `unchecked-*`, `integer?` and `double?` (#335).
    Quot,
    Rem,
    Abs,
    UncheckedAdd,
    UncheckedSubtract,
    UncheckedSubtractPrimitive,
    UncheckedMultiply,
    UncheckedNegate,
    PromoteAdd, PromoteSubtract, PromoteSubtractPrimitive, PromoteMultiply, PromoteNegate,
    ToBigInt, ToBigInteger, MakeRatio, RatioNumerator, RatioDenominator, RatioInteger,
    /// Source max/min distinguish primitive double/double Math operations,
    /// primitive long/long results, and Object-returning overloads (#337).
    Max,
    Min,
    LongMax,
    LongMin,
    DoubleMax,
    DoubleMin,
    LongTest,
    DoubleTest,
    /// Private Java `(long)` narrowing of a number, for counts computed with
    /// doubles, as in `drop`'s `Math/ceil`.
    ToLong,
    /// Private exact count of an integer range, without overflow.
    RangeCount,
    /// Private exact integer parsing for core's reader.
    ParseLong,
    /// Private Clojure `hasheq` of a number, for core's `hash` (#336).
    HashNumber,
    /// Private Java hashCode for case dispatch; deliberately distinct from hasheq.
    CaseNumberHash,
    /// Private Clojure `=` of scalars: numbers equal only within a category
    /// (#336).
    Equiv,
    /// Private packed primitive arrays for core's constructors: a new zeroed
    /// array of an element kind and length, and an unchecked element store
    /// (#336).
    PackedNew,
    PackedStore,
    PackedTest,
    /// Whether a value is an object array (#378).
    ObjectsTest,
    /// Register PersistentVector's type, by its empty vector (#378).
    VectorType,
    ArrayMapType,
    /// A PersistentVector's count, or undefined for anything else (#378).
    VectorCount,
    /// Copy a range between packed arrays of one element kind (#350).
    PackedCopy,
    /// The set bits of a value's int32, as core's `bit-count` (#443).
    BitCount,
}
impl Bitwise {
    pub(crate) fn from_name(name: &str) -> Option<Self> {
        Some(match name {
            "int" => Self::Int,
            "bit-and" => Self::And,
            "bit-or" => Self::Or,
            "bit-xor" => Self::Xor,
            "bit-and-not" => Self::AndNot,
            "bit-not" => Self::Not,
            "bit-clear" => Self::Clear,
            "bit-flip" => Self::Flip,
            "bit-set" => Self::Set,
            "bit-test" => Self::Test,
            "bit-shift-left" => Self::Left,
            "bit-shift-right" => Self::Right,
            "unsigned-bit-shift-right" => Self::Unsigned,
            "bit-shift-right-zero-fill" => Self::Unsigned,
            "imul" => Self::Imul,
            _ => return None,
        })
    }
    /// A raw result from the same checked/coercing boxed operand helper.
    pub(crate) fn raw_export(self) -> Option<&'static str> {
        Some(match self {
            Self::And => "primitive-bit-and-raw",
            Self::Or => "primitive-bit-or-raw",
            Self::Xor => "primitive-bit-xor-raw",
            Self::AndNot => "primitive-bit-and-not-raw",
            Self::Not => "primitive-bit-not-raw",
            Self::Clear => "primitive-bit-clear-raw",
            Self::Flip => "primitive-bit-flip-raw",
            Self::Set => "primitive-bit-set-raw",
            Self::Test => "primitive-bit-test-raw",
            Self::Left => "primitive-bit-shift-left-raw",
            Self::Right => "primitive-bit-shift-right-raw",
            Self::Unsigned => "primitive-unsigned-bit-shift-right-raw",
            Self::Int32 => "int32-int-raw",
            Self::Int32And => "int32-bit-and-raw",
            Self::Int32Or => "int32-bit-or-raw",
            Self::Int32Xor => "int32-bit-xor-raw",
            Self::Int32Left => "int32-bit-shift-left-raw",
            Self::Int32Right => "int32-bit-shift-right-raw",
            Self::Int32Unsigned => "int32-unsigned-bit-shift-right-raw",
            Self::Imul => "int32-imul-raw",
            Self::BitCount => "int32-bit-count-raw",
            _ => return None,
        })
    }
    /// Shipped core's 32-bit form of an inline bit operation.
    pub(crate) fn int32(self) -> Self {
        match self {
            Self::Int | Self::IntPrimitive | Self::IntFloat => Self::Int32,
            Self::And => Self::Int32And,
            Self::Or => Self::Int32Or,
            Self::Xor => Self::Int32Xor,
            Self::Left => Self::Int32Left,
            Self::Right => Self::Int32Right,
            Self::Unsigned => Self::Int32Unsigned,
            other => other,
        }
    }
    pub(crate) fn export(self) -> &'static str {
        match self {
            Self::Int => "primitive-int",
            Self::IntPrimitive => "number-cast-int",
            Self::IntFloat => "number-cast-int-float",
            Self::And => "primitive-bit-and",
            Self::Or => "primitive-bit-or",
            Self::Xor => "primitive-bit-xor",
            Self::AndNot => "primitive-bit-and-not",
            Self::Not => "primitive-bit-not",
            Self::Clear => "primitive-bit-clear",
            Self::Flip => "primitive-bit-flip",
            Self::Set => "primitive-bit-set",
            Self::Test => "primitive-bit-test",
            Self::Left => "primitive-bit-shift-left",
            Self::Right => "primitive-bit-shift-right",
            Self::Unsigned => "primitive-unsigned-bit-shift-right",
            Self::Int32 => "int32-int",
            Self::Int32And => "int32-bit-and",
            Self::Int32Or => "int32-bit-or",
            Self::Int32Xor => "int32-bit-xor",
            Self::Int32Left => "int32-bit-shift-left",
            Self::Int32Right => "int32-bit-shift-right",
            Self::Int32Unsigned => "int32-unsigned-bit-shift-right",
            Self::Imul => "int32-imul",
            Self::Cast => "number-cast",
            Self::IntValue => "number-int-value",
            Self::F64Coerce => "primitive-f64-coerce",
            Self::F64Word0 => "primitive-f64-word0",
            Self::F64Word4 => "primitive-f64-word4",
            Self::F64Floor => "primitive-f64-floor",
            Self::F64Ceil => "primitive-f64-ceil",
            Self::F64Finite => "primitive-f64-finite",
            Self::F64SafeInteger => "primitive-f64-safe-integer",
            Self::F64TimeClip => "primitive-f64-time-clip",
            Self::RandomDouble => "random-double",
            Self::EvaluateForm => "evaluate-form",
            Self::SafeIntegerRemainder => "primitive-safe-integer-remainder",
            Self::F64Remainder => "primitive-f64-remainder",
            Self::IdentityUid => "identity-uid",
            Self::Quot => "number-quot",
            Self::Rem => "number-rem",
            Self::Abs => "number-abs",
            Self::UncheckedAdd => "number-unchecked-add",
            Self::UncheckedSubtract => "number-unchecked-subtract",
            Self::UncheckedSubtractPrimitive => "number-unchecked-subtract-primitive",
            Self::UncheckedMultiply => "number-unchecked-multiply",
            Self::UncheckedNegate => "number-unchecked-negate",
            Self::PromoteAdd => "number-promote-add",
            Self::PromoteSubtract => "number-promote-subtract",
            Self::PromoteSubtractPrimitive => "number-promote-subtract-primitive",
            Self::PromoteMultiply => "number-promote-multiply",
            Self::PromoteNegate => "number-promote-negate",
            Self::MakeRatio => "ratio-new",
            Self::RatioNumerator => "ratio-numerator",
            Self::RatioDenominator => "ratio-denominator",
            Self::RatioInteger => "ratio-integer",
            Self::ToBigInt => "integer-bigint",
            Self::ToBigInteger => "integer-biginteger",
            Self::Max | Self::LongMax => "number-max",
            Self::Min | Self::LongMin => "number-min",
            Self::DoubleMax => "number-double-max",
            Self::DoubleMin => "number-double-min",
            Self::LongTest => "number-long?",
            Self::DoubleTest => "number-double?",
            Self::ToLong => "number-to-long",
            Self::RangeCount => "number-range-count",
            Self::ParseLong => "number-parse-long",
            Self::HashNumber => "number-hash",
            Self::CaseNumberHash => "case-number-hash",
            Self::Equiv => "number-equiv",
            Self::PackedNew => "packed-array-new",
            Self::PackedStore => "packed-array-store",
            Self::PackedTest => "packed-array-test",
            Self::ObjectsTest => "object-array-test",
            Self::VectorType => "vector-type-register",
            Self::ArrayMapType => "array-map-type-register",
            Self::VectorCount => "vector-count",
            Self::PackedCopy => "packed-array-copy",
            Self::BitCount => "int32-bit-count",
        }
    }
    pub(crate) fn arity(self) -> usize {
        match self {
            Self::RandomDouble => 0,
            Self::EvaluateForm => 1,
            Self::Int | Self::IntPrimitive | Self::IntFloat
            | Self::Int32
            | Self::Not
            | Self::F64Coerce
            | Self::F64Word0
            | Self::F64Word4
            | Self::F64Floor
            | Self::F64Ceil
            | Self::F64Finite
            | Self::F64SafeInteger
            | Self::F64TimeClip
            | Self::IdentityUid
            | Self::Abs
            | Self::UncheckedNegate
            | Self::PromoteNegate | Self::ToBigInt | Self::ToBigInteger | Self::RatioNumerator | Self::RatioDenominator | Self::RatioInteger
            | Self::LongTest
            | Self::DoubleTest
            | Self::ToLong
            | Self::IntValue
            | Self::HashNumber
            | Self::CaseNumberHash
            | Self::PackedTest
            | Self::ObjectsTest
            | Self::VectorType
            | Self::ArrayMapType
            | Self::VectorCount
            | Self::BitCount => 1,
            Self::PackedCopy => 5,
            Self::ParseLong => 4,
            Self::RangeCount | Self::PackedStore => 3,
            _ => 2,
        }
    }
    pub(crate) fn variadic(self) -> bool {
        matches!(
            self,
            Self::And
                | Self::Or
                | Self::Xor
                | Self::AndNot
                | Self::Int32And
                | Self::Int32Or
                | Self::Int32Xor
        )
    }
    pub(crate) fn result(self) -> Type {
        if matches!(
            self,
            Self::Test
                | Self::F64Finite
                | Self::F64SafeInteger
                | Self::LongTest
                | Self::DoubleTest
                | Self::Equiv
                | Self::PackedTest
                | Self::ObjectsTest
        ) {
            Type::Bool
        } else if matches!(self, Self::ParseLong | Self::RangeCount | Self::PackedNew | Self::PackedStore | Self::PackedCopy | Self::VectorType | Self::VectorCount) {
            Type::Value
        } else {
            Type::Number
        }
    }
}
/// Original private nominal lowering operations. Arrays here are internal
/// construction storage, never source-language persistent collections.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Nominal {
    /// Immutable private tests; public predicate cells remain live.
    IsNumber,
    IsBigInt,
    IsRatio,
    IsDecimal,
    IsMathContext,
    DecimalNew,
    DecimalCoerce,
    DecimalContextNew,
    DecimalContextGetter,
    IsBigInteger,
    /// Whether the operand is a long: an i31 or a boxed long (#388).
    IsLongValue,
    /// `(aget a i)` of an array tagged with a packed element type, its kind
    /// in `packed_arrays::KINDS` order (#389): the element read inline when
    /// `a` is such an array and `i` an i31 in range, else the generic path.
    PackedGet(usize),
    /// `(aset a i v)` likewise, for int, long and double arrays (#389).
    PackedSet(usize),
    /// Copy a valid object-array range when bulk copying preserves core's
    /// loop direction, otherwise return undefined for the original loop.
    ObjectArrayCopy(bool),
    /// `hash` of a string (#409): Murmur3's `hashInt` of its Java
    /// `hashCode`, `h = 31h + unit` over its UTF-16 units in int32
    /// arithmetic, as ClojureScript's `(m3-hash-int (hash-string* s))`.
    StringHash,
    /// Element n of a PersistentVector, walked by the runtime, or undefined
    /// for the general path (#378).
    VectorNth,
    /// Internal precondition for virtual literal-vector storage.
    ScalarVectorGuard,
    /// Canonical MapEntry admission/registration (#351).
    ScalarMapEntryGuard,
    MapEntryType,
    /// `map-get(m, k)` (#442): a map's value for a key only its reference
    /// equals, nil when absent, or undefined.
    ArrayMapGet,
    /// `map-contains(m, k)` (#442): true or false, or undefined.
    MapContains,
    /// `map-get-or(m, k, not-found)` (#442): as map-get, not-found when absent.
    MapGetOr,
    /// `map-assoc(m, k, v)` (#443): a hash map with k's value replaced, or
    /// undefined.
    MapAssoc,
    /// `hash-map-types!(m, bitmap-node, array-node, set)` (#442).
    HashMapTypes,
    /// Canonical core chunk witnesses and guarded indexed read/append (#482).
    ChunkTypes,
    ChunkNth,
    ChunkAppend,
    ChunkArray,
    ChunkOffset,
    ChunkSeq,
    /// Owned transient-vector/root/edit witnesses and a guarded tail append.
    TransientVectorTypes,
    TransientVectorAppend,
    TransientMapTypes,
    TransientMapAssoc,
    TransientMapConj,
    /// A `^long` or `^double` parameter's value (#385): Clojure's checked
    /// longCast or doubleCast of the argument, kept as a raw i64 or f64.
    LongCast,
    /// Private addition after an owned loop proves its counters/offsets bounded.
    ChunkIndexAdd,
    /// Owned canonical + over a checked Object[] chunk, or undefined.
    ChunkLongSum,
    DoubleCast,
    /// Fresh Object boxing of a source primitive floating expression.
    BoxDoubleObject,
    /// Core's `unchecked-long` (#448): a raw i64 as LongCast, through its own
    /// cast for anything but a long.
    UncheckedLongCast,
    /// A string, the first operand, followed by the digits of a long, the
    /// second (#388).
    StringAppendLong,
    /// `suss.bootstrap/keyword?` (#361): an object with the interned keywords'
    /// descriptor. Needs no Keyword class, so core can test before defining it.
    IsKeyword,
    IsString,
    IsBoolean,
    /// The runtime's undefined, a fast path's "not here" answer (#442).
    IsUndefined,
    /// Inline `identical?` (#356): a reference test, with the runtime's test
    /// only for two boxed or string operands that aren't the same reference.
    Identical,
    /// Whether every operand is an i31: a long in i31 range, whose value is
    /// its identity (#387).
    AllSmallIntegers,
    /// `number-hash` (#387): Clojure's hash of a number, for an operand
    /// already known to be one.
    NumberHash,
    /// Whether the operand is an object with a descriptor (a deftype,
    /// defrecord or other nominal instance), whose protocol methods are in
    /// its descriptor's method table (#378).
    IsObject,
    /// Whether the two operands are the same reference (#387): `identical?`
    /// for an operand that is never a boxed double, such as a keyword.
    SameReference,
    /// Whether the operand is a descriptor: a bound protocol method key (#378).
    IsDescriptor,
    IsClosure,
    BindCallable,
    /// A direct-linked definition (#360), its var's slot and the definition
    /// packed by `link_pair`: write its closure, the argument, to the slot.
    DirectLinkDefine(usize),
    /// The interned keyword equal to the constructed one, the argument: the
    /// first keyword made with its name (#361), as Clojure interns keywords.
    KeywordIntern,
    /// A fragment's cache of the interned keyword for the numbered keyword
    /// cell (#387): nil until `KeywordCacheSet` stores the keyword, the
    /// argument, which it returns. A keyword cell never changes once defined.
    KeywordCacheGet(usize),
    KeywordCacheSet(usize),
    /// Whether that cache is still empty.
    KeywordCacheEmpty(usize),
    /// `set!` of a direct-linked var also writes its slot, the slot number
    /// here, so its direct calls reach the new value, as a redefinition (#360).
    DirectLinkSet(usize),
    /// A direct-linked var's slot, the callee of a call compiled while the
    /// packed definition was the var's (#360).
    DirectLinkRead(usize),
    /// Registers IFn's `-invoke` key for a signature arity with the runtime's
    /// out-of-line call path (ADR-0004): an arity long and the key.
    CallableKeyRegister,
    /// Private selected binding-cell presence, not value truthiness.
    BindingDefined,
    /// Compiler-only construction of the shared Wasm getter for a native Var.
    BindingGetter,
    ObjectDescriptor,
    MethodGet,
    /// A non-object receiver's native or default implementation of a
    /// protocol method (#445): the protocol fn read at the site and the
    /// receiver; the implementation, or nil.
    NativeMethodGet,
    LiveDispatcher,
    IFnLiveDispatcher,
    NativeMarker(NativeKind),
    NativeSet(NativeKind),
    Array,
    /// A user type descriptor: field names, then the given number of trailing
    /// names of its `^:mutable` fields.
    Descriptor(usize),
    Class,
    Protocol,
    Construct,
    Instance,
    SameNominalType,
    Field(usize),
    FieldSet(usize),
    /// Unprivileged named access: owner, name, then the class value of the
    /// type whose inline method body contains the access, or nil.
    NamedGet,
    CallableGet,
    /// Owner, name, enclosing class value or nil, assigned value.
    NamedSet,
    /// Privileged forms emitted only for the shipped `suss.core` bootstrap: core
    /// type descriptors whose internals are private, and named access to them.
    CoreDescriptor,
    /// A core collection class whose whitelisted statics user code may read.
    CoreStaticsDescriptor,
    /// A core type with public fields that is still closed to extension.
    CoreClosedDescriptor,
    /// A core type with private internals whose constructor user code may call
    /// (MapEntry, LazySeq, ...), as in Clojure; hash caches stay unforgeable.
    CoreConstructibleDescriptor,
    CoreNamedGet,
    CoreNamedSet,
    /// Rejects a built-in core class before user code extends a core protocol
    /// or Object methods onto it, whatever form produced the class value.
    BuiltinClassGuard,
    /// Instance -> instance after unprivileged construction: rejects core types
    /// with private internals and forged hash caches of public-field core types.
    BuiltinConstructGuard,
    NativeObjectFactory,
    IsNativeObject,
    /// `suss.bootstrap/fixed-arity-fn?` (#466): a fn whose arities are all
    /// fixed, as its code struct's maximum arity says.
    FixedArityFn,
    /// Private core sequence callbacks and the native apply boundary (#466).
    ApplySequenceOps,
    ListFunction,
    ApplyCallee,
    ApplySpread,
    ApplyToSeq,
    ApplyFixed,
    IsTypeConstructor,
    ValueConstructor,
    NumericClass(u8),
    /// Reject a numeric Class callee before evaluating its call arguments.
    CheckNumericCallee,
    /// Type value -> its name string, or nil (#304).
    TypeName,
    /// Future or stream -> its display text, or nil (#288).
    DisplayLeaf,
    SourceFunctionName,
    NativeObjectDefaultPrototype,
    /// Dynamically scoped JavaScript receiver for the original `this-as` form.
    CurrentThis,
    NativeObjectGet,
    NativeObjectSet,
    NativeObjectStrictSet,
    CoerceString,
    ObjectCoerceString,
    ConcatString,
    /// The concatenation of an object array's strings, in one allocation
    /// (#446): `str`'s variadic arity.
    JoinStrings,
    ValueAdd,
    StringIndexOf,
    StringSlice,
    StringFromUnit,
    LanguageError,
    IsLanguageError,
    ObjectSet,
    ObjectInvoke,
    Key(usize),
    Dispatcher,
    Set,
    Marker,
    Satisfies,
    NativeSatisfies,
}
impl Nominal {
    pub fn result(self) -> Type {
        match self {
            Self::CoerceString | Self::ObjectCoerceString | Self::ConcatString | Self::JoinStrings | Self::StringSlice | Self::StringFromUnit => Type::String,
            Self::StringIndexOf | Self::ChunkIndexAdd | Self::BoxDoubleObject => Type::Number,
            Self::BindingDefined
            | Self::IsNumber
            | Self::IsRatio
            | Self::IsBigInt
            | Self::IsRatio
            | Self::IsBigInteger
            | Self::IsDecimal | Self::IsMathContext
            | Self::IsKeyword
            | Self::IsString
            | Self::IsBoolean
            | Self::IsUndefined
            | Self::Identical
            | Self::SameReference
            | Self::AllSmallIntegers
            | Self::IsObject
            | Self::IsDescriptor
            | Self::IsClosure
            | Self::IsNativeObject
            | Self::FixedArityFn
            | Self::IsTypeConstructor
            | Self::IsLanguageError
            | Self::Instance
            | Self::SameNominalType
            | Self::Satisfies
            | Self::NativeSatisfies
            | Self::IsLongValue
            | Self::ScalarVectorGuard
            | Self::ScalarMapEntryGuard
            | Self::NativeMarker(_)
            | Self::KeywordCacheEmpty(_) => Type::Bool,
            _ => Type::Value,
        }
    }
    pub(crate) fn valid(self, arguments: &[Type]) -> bool {
        let count = arguments.len();
        count <= i32::MAX as usize
            && match self {
                Self::Array => true,
                Self::ApplySequenceOps => count == 10,
                Self::ListFunction => count == 5,
                Self::ApplyCallee => count == 1,
                Self::DecimalNew => count == 2,
                Self::DecimalCoerce => count == 1,
                Self::ApplySpread => count >= 2,
                Self::ApplyToSeq | Self::ApplyFixed => count == 2,
                Self::NativeObjectFactory | Self::NativeObjectDefaultPrototype => count == 0,
                Self::CurrentThis => count == 0,
                Self::NumericClass(kind) => count == 0 && usize::from(kind) < crate::runtime_abi::numeric_classes::NAMES.len(),
                Self::Identical | Self::SameReference | Self::ChunkIndexAdd => count == 2,
                Self::AllSmallIntegers => count >= 1,
                Self::NumberHash => count == 1,
                Self::DecimalContextNew => count == 2,
                Self::DecimalContextGetter => count == 1,
                Self::IsObject | Self::IsDescriptor | Self::ScalarVectorGuard
            | Self::ScalarMapEntryGuard | Self::MapEntryType => count == 1,
                Self::IsLongValue | Self::StringHash | Self::LongCast | Self::DoubleCast | Self::BoxDoubleObject | Self::UncheckedLongCast => count == 1,
                Self::PackedGet(_) | Self::VectorNth | Self::ArrayMapGet | Self::MapContains => count == 2,
                Self::ObjectArrayCopy(_) => count == 5,
                Self::HashMapTypes => count == 4,
                Self::TransientMapTypes => count == 5,
                Self::TransientMapAssoc => count == 3,
                Self::TransientMapConj => count == 2,
                Self::ChunkTypes | Self::TransientVectorTypes => count == 3,
                Self::ChunkNth | Self::ChunkAppend | Self::TransientVectorAppend => count == 2,
                Self::ChunkLongSum => count == 6,
                Self::ChunkArray | Self::ChunkOffset | Self::ChunkSeq => count == 1,
                Self::MapGetOr | Self::MapAssoc => count == 3,
                Self::PackedSet(_) => count == 3,
                Self::StringAppendLong => count == 2,
                Self::IsNumber | Self::IsRatio | Self::IsDecimal | Self::IsMathContext | Self::IsBigInt | Self::IsBigInteger | Self::IsKeyword | Self::IsString | Self::IsBoolean | Self::IsUndefined | Self::LanguageError | Self::IsLanguageError | Self::IsClosure | Self::IsNativeObject | Self::FixedArityFn | Self::IsTypeConstructor | Self::ValueConstructor | Self::CheckNumericCallee | Self::TypeName | Self::DisplayLeaf | Self::SourceFunctionName => count == 1,
                Self::BindingDefined | Self::BindingGetter | Self::CoerceString | Self::ObjectCoerceString | Self::ObjectDescriptor | Self::StringFromUnit | Self::JoinStrings => count == 1,
                Self::ConcatString | Self::ValueAdd | Self::StringIndexOf => count == 2,
                Self::StringSlice => count == 3,
                Self::BindCallable | Self::MethodGet | Self::NativeMethodGet | Self::CallableKeyRegister => count == 2,
                Self::DirectLinkDefine(_) | Self::DirectLinkSet(_) | Self::KeywordIntern | Self::KeywordCacheSet(_) => count == 1,
                Self::DirectLinkRead(_) | Self::KeywordCacheGet(_) | Self::KeywordCacheEmpty(_) => count == 0,
                Self::NativeObjectGet => count == 2,
                Self::NativeObjectSet | Self::NativeObjectStrictSet => count == 3,
                Self::NamedGet => count == 3 && arguments[1] == Type::String,
                Self::CoreNamedGet => count == 2 && arguments[1] == Type::String,
                // Unprivileged callable reads also carry the caller (#278).
                Self::CallableGet => matches!(count, 3 | 4) && arguments[1] == Type::String,
                Self::NamedSet => count == 4 && arguments[1] == Type::String,
                Self::CoreNamedSet | Self::ObjectSet => count == 3 && arguments[1] == Type::String,
                Self::ObjectInvoke => count >= 2,
                Self::LiveDispatcher | Self::NativeSet(_) => count == 2,
                Self::IFnLiveDispatcher => count == 3,
                Self::NativeMarker(_) => count == 1,
                Self::Descriptor(mutable) => mutable < count && arguments.iter().all(|ty| *ty == Type::String),
                Self::CoreDescriptor | Self::CoreStaticsDescriptor | Self::CoreClosedDescriptor | Self::CoreConstructibleDescriptor => count >= 1 && arguments.iter().all(|ty| *ty == Type::String),
                Self::Construct => count >= 1,
                Self::Instance | Self::SameNominalType | Self::Satisfies | Self::NativeSatisfies | Self::Marker => {
                    count == 2
                }
                Self::Set => count == 3,
                Self::Field(index) | Self::Key(index) => count == 1 && index <= i32::MAX as usize,
                Self::FieldSet(index) => count == 2 && index <= i32::MAX as usize,
                Self::Class | Self::Protocol | Self::Dispatcher | Self::BuiltinClassGuard | Self::BuiltinConstructGuard => count == 1,
            }
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct BindingId(pub usize);
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct LoopId(pub usize);
#[derive(Debug, Clone)]
pub struct Binding {
    pub id: BindingId,
    pub name: String,
    pub metadata: Vec<Form>,
    pub span: Range<usize>,
    pub value: Hir,
}
#[derive(Debug, Clone)]
pub struct Parameter {
    pub id: BindingId,
    pub name: String,
    pub metadata: Vec<Form>,
    pub span: Range<usize>,
}
#[derive(Debug, Clone)]
pub struct Method {
    pub variadic: bool,
    pub parameters: Vec<Parameter>,
    pub body: Box<Hir>,
}
/// Reader/expansion syntax actually analyzed for this expression. Compiler-only
/// lowering nodes have no source record; their syntax must never be fabricated.
/// Immutable namespace facts at the actual source analysis boundary.
#[derive(Debug, Clone)]
pub struct SourceNamespace {
    pub namespace: String,
    pub aliases: BTreeMap<String, String>,
    pub refers: BTreeMap<String, Global>,
    pub used_refers: BTreeSet<String>,
    pub renamed_refers: BTreeSet<String>,
    pub excluded_core: BTreeSet<String>,
    pub macro_aliases: BTreeMap<String, String>,
    pub macro_refers: BTreeMap<String, (String, String)>,
    pub used_macro_refers: BTreeSet<String>,
    pub renamed_macro_refers: BTreeSet<String>,
    pub declarations: super::persistent::PersistentMap<Global, std::sync::Arc<super::resolve::DefinitionInfo>>,
    pub identities: super::persistent::PersistentSet<Global>,
}
impl SourceNamespace {
    pub fn capture(environment: &Environment, phase: Phase) -> Self {
        Self::capture_namespace(environment, phase, environment.current_namespace(phase))
            .expect("declared current namespace")
    }
    /// Capture an actual namespace revision without installing it as current.
    pub fn capture_namespace(environment: &Environment, phase: Phase, namespace: &str) -> Option<Self> {
        environment.source_namespace(phase, namespace)
    }
}
#[derive(Debug, Clone)]
pub enum SourceBinding {
    /// Actual bounded owned JS host reference, not a source namespace var.
    JavaScript {
        global: Global,
    },
    Local(std::sync::Arc<LocalBinding>),
    Field(std::sync::Arc<FieldBinding>),
    Global {
        global: Global,
        declaration: Option<std::sync::Arc<super::resolve::DefinitionInfo>>,
    },
}
/// Actual analyzed source methods, before runtime signature wrappers or duplicate
/// arity elimination. These are compiler facts, not portable inferred tags.
#[derive(Debug, Clone)]
pub struct SourceCallable {
    /// Genuine source name scope, including declaration hints without lexical IDs.
    pub name: Option<std::sync::Arc<FunctionScope>>,
    pub methods: Vec<SourceMethod>,
}
/// Actual method-entry environment, captured before parameter allocation.
#[derive(Debug, Clone)]
pub struct SourceMethodEnvironment {
    pub scope: std::sync::Arc<SourceNamespace>,
    pub namespace_snapshot: std::sync::Arc<SourceNamespace>,
    pub locals: std::sync::Arc<HashMap<String, LocalBinding>>,
    pub fields: std::sync::Arc<HashMap<String, FieldBinding>>,
    pub function_scopes: std::sync::Arc<[std::sync::Arc<FunctionScope>]>,
    pub context: super::AnalysisContext,
}
#[derive(Debug, Clone)]
pub struct SourceMethod {
    pub form: Form,
    pub environment: SourceMethodEnvironment,
    pub declarations: Vec<LocalBinding>,
    pub parameters: Vec<Parameter>,
    pub variadic: bool,
    /// Whether analysis accepted a recur targeting this method (nil otherwise).
    pub recurs: Option<bool>,
    pub body: std::sync::Arc<Hir>,
}
impl SourceCallable {
    pub fn variadic(&self) -> bool {
        self.methods.iter().any(|method| method.variadic)
    }
    pub fn max_fixed_arity(&self) -> Option<usize> {
        if self.methods.is_empty() {
            return None;
        }
        self.methods.iter().try_fold(0, |maximum, method| {
            method
                .parameters
                .len()
                .checked_sub(usize::from(method.variadic))
                .map(|arity| maximum.max(arity))
        })
    }
}
/// Original analyzed operands and declarations retained before lowering.
/// Quoted data constructors do not create expression child records.
#[derive(Debug, Clone)]
pub enum SourceNode {
    Future(std::sync::Arc<Hir>),
    Await(std::sync::Arc<Hir>),
    Vector(std::sync::Arc<[Hir]>),
    Map(std::sync::Arc<[Hir]>),
    Set(std::sync::Arc<[Hir]>),
    Do {
        statements: std::sync::Arc<[Hir]>,
        result: std::sync::Arc<Hir>,
    },
    If {
        condition: std::sync::Arc<Hir>,
        consequent: std::sync::Arc<Hir>,
        alternative: std::sync::Arc<Hir>,
    },
    Bindings {
        is_loop: bool,
        is_letfn: bool,
        bindings: std::sync::Arc<[LocalBinding]>,
        body: std::sync::Arc<Hir>,
    },
    Recur(std::sync::Arc<[Hir]>),
    Throw(std::sync::Arc<Hir>),
    Try {
        body: std::sync::Arc<Hir>,
        handler: std::sync::Arc<Hir>,
        cleanup: Option<std::sync::Arc<Hir>>,
        payload: Option<std::sync::Arc<LocalBinding>>,
    },
    Assign {
        target: std::sync::Arc<Hir>,
        value: std::sync::Arc<Hir>,
    },
    Invoke {
        callee: std::sync::Arc<Hir>,
        arguments: std::sync::Arc<[Hir]>,
    },
    Construct {
        class: std::sync::Arc<Hir>,
        arguments: std::sync::Arc<[Hir]>,
    },
    WithMeta {
        expression: std::sync::Arc<Hir>,
        metadata: std::sync::Arc<Hir>,
        inner: Option<std::sync::Arc<SourceNode>>,
    },
}
#[derive(Debug, Clone)]
pub struct SourceAnalysis {
    /// Set only for analyzer-generated body regions, before runtime lowering.
    pub is_body: bool,
    pub tags: SourceTags,
    pub form: Form,
    pub resolved: Option<SourceBinding>,
    pub name_hint: Option<Form>,
    /// Live resolution catalog at the time this source node was entered.
    pub scope: std::sync::Arc<SourceNamespace>,
    /// Namespace supplied to macro &env at enclosing top-level form entry.
    pub namespace_snapshot: std::sync::Arc<SourceNamespace>,
    pub callable: Option<std::sync::Arc<SourceCallable>>,
    pub node: Option<std::sync::Arc<SourceNode>>,
    pub locals: std::sync::Arc<HashMap<String, LocalBinding>>,
    pub fields: std::sync::Arc<HashMap<String, FieldBinding>>,
    pub function_scopes: std::sync::Arc<[std::sync::Arc<FunctionScope>]>,
    pub context: super::AnalysisContext,
    pub phase: Phase,
    pub namespace: String,
    pub origin: Option<super::SourceOrigin>,
}
#[derive(Debug)]
pub struct Hir {
    pub source: Option<std::sync::Arc<SourceAnalysis>>,
    pub span: Range<usize>,
    pub metadata: Vec<Form>,
    pub ty: Type,
    /// Shared, so source facts and copies of a subtree don't copy it (#319).
    /// Change it through `kind_mut`, which copies one level when shared.
    pub kind: std::sync::Arc<Expression>,
}
impl Clone for Hir {
    fn clone(&self) -> Self {
        Self {
            source: self.source.clone(),
            span: self.span.clone(),
            metadata: self.metadata.clone(),
            ty: self.ty,
            kind: self.kind.clone(),
        }
    }
}
impl Hir {
    /// Extract an owned expression without bypassing stack-safe cleanup of the
    /// remaining source facts and metadata. A shared expression is copied
    /// one level.
    pub fn take_kind(&mut self) -> Expression {
        let kind = std::mem::replace(&mut self.kind, std::sync::Arc::new(Expression::Literal(Literal::Nil)));
        std::sync::Arc::try_unwrap(kind).unwrap_or_else(|shared| {
            // The copy shares its child HIR; only its own fields are copied.
            stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || (*shared).clone())
        })
    }
    /// The expression, for changing in place; a shared one is copied first.
    pub fn kind_mut(&mut self) -> &mut Expression {
        std::sync::Arc::make_mut(&mut self.kind)
    }
}
impl Drop for Hir {
    fn drop(&mut self) {
        // Only the last owner of the expression takes it apart.
        let kind = std::sync::Arc::get_mut(&mut self.kind)
            .map(|kind| std::mem::replace(kind, Expression::Literal(Literal::Nil)));
        let metadata = std::mem::take(&mut self.metadata);
        let source = self.source.take();
        // Every boxed HIR child enters this guard, including partial trees
        // discarded after analysis errors. Cleanup must finish even when the
        // request has no fuel left; it executes no user code.
        stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || {
            drop((kind, metadata, source));
        });
    }
}
#[derive(Debug, Clone)]
pub enum Expression {
    /// Deferred executable body and its lexical captures; never a body value.
    Future {
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    Await {
        value: Box<Hir>,
    },
    /// Suspension-aware executable regions, before closure packaging.
    AsyncTry {
        body: Box<Hir>,
        handler: Option<Box<Hir>>,
        cleanup: Option<Box<Hir>>,
        payload: Option<Parameter>,
    },
    AsyncDynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Bitwise {
        operation: Bitwise,
        arguments: Vec<Hir>,
    },
    Comparison {
        operation: Comparison,
        arguments: Vec<Hir>,
    },
    /// Compiler bootstrap primitive, independent of mutable core vars.
    NilTest(Box<Hir>),
    Array {
        operation: ArrayOperation,
        arguments: Vec<Hir>,
    },
    DynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Assign {
        global: Global,
        value: Box<Hir>,
        /// Shipped core's direct-link cell, written with the same value.
        linked: Option<Global>,
    },
    /// A terminal language throw of an evaluated portable value.
    Throw(Box<Hir>),
    /// Private compiled regions: body/cleanup arity0, handler arity1 or nil.
    Try {
        regions: [Box<Hir>; 3],
    },
    Nominal {
        operation: Nominal,
        arguments: Vec<Hir>,
    },
    Literal(Literal),
    Local(BindingId),
    /// Read a live cell by resolved language identity, never by a Wasm index.
    Global(Global),
    /// Reader calls use a live public value only after successful initialization.
    GlobalOrFallback {
        global: Global,
        fallback: Global,
    },
    /// Private cell identity for a captured live protocol fallback.
    GlobalCell(Global),
    Definition {
        /// Native Var result after a successful write; absent during bootstrap.
        result: Option<Box<Hir>>,
        /// An initialized scalar constant revision, published with its live var.
        constant: Option<Global>,
        global: Global,
        name_metadata: Vec<Form>,
        name_span: Range<usize>,
        docstring: Option<Vec<u16>>,
        initializer: Option<Box<Hir>>,
        once: bool,
        /// Shipped core's direct-link cell, written with the same value.
        linked: Option<Global>,
    },
    Let {
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    /// All names are in scope for every function initializer and the body.
    LetFn {
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Loop {
        target: LoopId,
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Recur {
        target: LoopId,
        arguments: Vec<Hir>,
    },
    If {
        condition: Box<Hir>,
        consequent: Box<Hir>,
        alternative: Box<Hir>,
    },
    Do(Vec<Hir>),
    Function {
        parameters: Vec<Parameter>,
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    GeneralFunction {
        methods: Vec<Method>,
        captures: Vec<BindingId>,
        self_binding: Option<Parameter>,
        rest_class: Option<Global>,
    },
    Call {
        callee: Box<Hir>,
        arguments: Vec<Hir>,
    },
    /// Resolved bootstrap intrinsic identity, never an unresolved name.
    Arithmetic {
        operator: Arithmetic,
        arguments: Vec<Hir>,
        /// Shipped core keeps JavaScript coercion internally; source arithmetic
        /// rejects non-numbers as Clojure does (#286).
        coercing: bool,
        /// Source overload for each binary division or subtraction in the left fold. This
        /// is independent of the backend's raw/boxed storage inference.
        primitive_overloads: Vec<bool>,
    },
}
fn fail(span: Range<usize>, message: impl Into<String>) -> Diagnostic {
    Diagnostic {
        span,
        message: message.into(),
    }
}
struct Analyzer<'a> {
    suspendable: bool,
    /// The next fixed fn's WIT export parameter hints (#385), taken by it.
    pending_param_hints: Option<Vec<Option<bool>>>,
    /// The current function declaration's default primitive return tag.
    /// Each fn shadows it, including an anonymous fn without a tag.
    pending_return_hint: Option<Nominal>,
    /// Analyzing compiler-authored source, which may access built-in type
    /// internals (design decision 2026-10-25).
    privileged: bool,
    expander: &'a mut dyn super::ExpansionHost,
    origin: Option<super::SourceOrigin>,
    environment: Environment,
    phase: Phase,
    /// Shared with the source facts captured at each node; changed by copy
    /// on write (#319).
    locals: std::sync::Arc<HashMap<String, LocalBinding>>,
    /// Definitions linked in this fragment (#360). Privileged code links only
    /// to these: other modules don't export core's links.
    fragment_links: BTreeSet<usize>,
    fields: std::sync::Arc<HashMap<String, FieldBinding>>,
    /// Field declarations in an intrinsic type body, before methods bind a receiver.
    type_body_fields: Vec<(Global, Form, Vec<Form>, BindingId)>,
    /// The class value of the type whose inline method bodies (and closures
    /// created in them) are being analyzed: only those may access its mutable
    /// fields by name.
    field_owner: Option<BindingId>,
    function_scopes: std::sync::Arc<[std::sync::Arc<FunctionScope>]>,
    next: usize,
    next_loop: usize,
    analysis_depth: usize,
    analysis_contexts: Vec<super::AnalysisContext>,
    source_namespace: Option<(u64, Phase, String, std::sync::Arc<SourceNamespace>)>,
    namespace_snapshot: Option<std::sync::Arc<SourceNamespace>>,
    constant_definitions: super::resolve::DeclarationSnapshot,
    source_callables: Vec<Option<std::sync::Arc<SourceCallable>>>,
    source_nodes: Vec<Option<std::sync::Arc<SourceNode>>>,
    callable_keys: BTreeMap<Global, Hir>,
    pattern_sites: Vec<(suss_reader::pattern::PatternLiteral, Global)>,
    catch_aliases: Vec<(Form, std::sync::Arc<LocalBinding>)>,
    target: Option<(LoopId, usize)>,
    method_recurrence: Vec<(LoopId, bool)>,
    primitive_methods: HashMap<LoopId, primitive_returns::Method>,
}
impl Analyzer<'_> {
    fn capture_source_namespace(&mut self) -> std::sync::Arc<SourceNamespace> {
        let namespace = self.environment.current_namespace(self.phase).to_owned();
        let generation = self.environment.source_generation();
        match &self.source_namespace {
            Some((version, phase, name, scope))
                if *version == generation && *phase == self.phase && *name == namespace =>
            {
                scope.clone()
            }
            _ => {
                let scope =
                    std::sync::Arc::new(SourceNamespace::capture(&self.environment, self.phase));
                self.source_namespace = Some((generation, self.phase, namespace, scope.clone()));
                scope
            }
        }
    }
    fn body(
        &mut self,
        forms: &[Form],
        span: Range<usize>,
        context: super::AnalysisContext,
        tail: bool,
    ) -> Result<Hir, Diagnostic> {
        // Intermediate forms discard their result; only the final form inherits
        // its caller context. A fragment itself is a sequence of statements.
        let items = forms
            .iter()
            .enumerate()
            .map(|(index, form)| {
                self.form_in(
                    form,
                    if index + 1 < forms.len() {
                        super::AnalysisContext::Statement
                    } else if forms.len() > 1 {
                        context.returning()
                    } else {
                        context
                    },
                    tail && index + 1 == forms.len(),
                )
            })
            .collect::<Result<Vec<_>, _>>()?;
        let ty = items.last().map_or(Type::Nil, |item| item.ty);
        Ok(Hir {
            source: None,
            span,
            metadata: Vec::new(),
            ty,
            kind: std::sync::Arc::new(Expression::Do(items)),
        })
    }
    /// Construct a nominal UUID through the captured, compiler-owned core cell.
    fn uuid_literal(&mut self, form: &Form, value: suss_reader::uuid::Uuid) -> Result<Hir, Diagnostic> {
        let binding = self.environment.resolve(self.phase,
            &suss_reader::Symbol::namespaced("suss.core", "uuid-from-parts"), form.span.clone())?;
        let global = self.environment.existing_core_link(binding.global())
            .ok_or_else(|| fail(form.span.clone(), "UUID literal requires shipped core"))?;
        let callee = Hir { source: None, span: form.span.clone(), metadata: vec![], ty: Type::Value,
            kind: std::sync::Arc::new(Expression::Global(global)) };
        let arguments = [value.most, value.least].into_iter().map(|part| Hir {
            source: None, span: form.span.clone(), metadata: vec![], ty: Type::Number,
            kind: std::sync::Arc::new(Expression::Literal(Literal::Long(part))),
        }).collect();
        Ok(Hir { source: None, span: form.span.clone(), metadata: form.metadata.clone(), ty: Type::Value,
            kind: std::sync::Arc::new(Expression::Call { callee: Box::new(callee), arguments }) })
    }
    /// Hoist an immutable Pattern to a private rooted cell. Every read site
    /// owns one object across loops and closures; subsequent compilations use
    /// fresh deterministic environment cells, never a process address.
    fn pattern_literal(&mut self, form: &Form, value: &suss_reader::pattern::PatternLiteral) -> Result<Hir, Diagnostic> {
        self.expander.charge_expansion_work(self.pattern_sites.len() as u64 + 1, form.span.clone())?;
        let node = |kind| Hir { source: None, span: form.span.clone(), metadata: vec![], ty: Type::Value,
            kind: std::sync::Arc::new(kind) };
        if let Some((_, cell)) = self.pattern_sites.iter().find(|(site, _)| site == value) {
            return Ok(node(Expression::Global(cell.clone())));
        }
        let binding = self.environment.resolve(self.phase,
            &suss_reader::Symbol::namespaced("suss.core", "pattern-from-source"), form.span.clone())?;
        let helper = self.environment.existing_core_link(binding.global())
            .ok_or_else(|| fail(form.span.clone(), "Pattern literal requires shipped core"))?;
        let arguments = vec![self.literal_form(form, Literal::String(value.source().units().to_vec())),
            self.literal_form(form, Literal::Long(i64::from(value.source().flags())))];
        let construction = node(Expression::Call { callee: Box::new(node(Expression::Global(helper))), arguments });
        let cell = self.environment.constant_cell(self.phase);
        self.pattern_sites.push((value.clone(), cell.clone()));
        let initialize = node(Expression::Definition { result: None, constant: None, global: cell.clone(),
            name_metadata: vec![], name_span: form.span.clone(), docstring: None,
            initializer: Some(Box::new(construction)), once: true, linked: None });
        self.callable_keys.insert(cell.clone(), initialize);
        Ok(node(Expression::Global(cell)))
    }
    /// Exact literals retain their integer fields and Decimal's signed scale.
    fn exact_literal(&mut self, form: &Form, number: &suss_reader::forms::ExactNumber) -> Result<Hir, Diagnostic> {
        if let suss_reader::forms::ExactValue::Integer { value, big } = &number.value {
            let (_, limbs) = value.to_u32_digits();
            return Ok(Hir { source: None, span: form.span.clone(), metadata: form.metadata.clone(),
                ty: Type::Number, kind: std::sync::Arc::new(Expression::Literal(Literal::BigInt {
                    negative: num_traits::Signed::is_negative(value), limbs, big_integer: !big,
                })) });
        }
        if let suss_reader::forms::ExactValue::Ratio { numerator, denominator } = &number.value {
            return Ok(Hir { source: None, span: form.span.clone(), metadata: form.metadata.clone(),
                ty: Type::Number, kind: std::sync::Arc::new(Expression::Literal(Literal::Ratio {
                    negative: num_traits::Signed::is_negative(numerator), numerator: numerator.to_u32_digits().1,
                    denominator: denominator.to_u32_digits().1,
                })) });
        }
        let suss_reader::forms::ExactValue::Decimal { unscaled, scale } = &number.value else { unreachable!() };
        Ok(Hir { source: None, span: form.span.clone(), metadata: form.metadata.clone(),
            ty: Type::Number, kind: std::sync::Arc::new(Expression::Literal(Literal::Decimal {
                negative: num_traits::Signed::is_negative(unscaled), unscaled: unscaled.to_u32_digits().1, scale: *scale,
            })) })
    }
    fn form(&mut self, form: &Form) -> Result<Hir, Diagnostic> {
        self.form_in(form, super::AnalysisContext::Expression, false)
    }
    fn analyzed_body(
        &mut self,
        forms: &[Form],
        span: Range<usize>,
        context: super::AnalysisContext,
        tail: bool,
    ) -> Result<Hir, Diagnostic> {
        // Analyzer-generated do syntax has genuine source facts and context,
        // while its children retain their ordinary bounded analysis frames.
        // Do not charge an additional source nesting level for this wrapper.
        let mut body_forms = vec![Form {
            kind: Kind::Symbol(suss_reader::Symbol {
                namespace: None,
                name: "do".into(),
            }),
            span: span.clone(),
            metadata: vec![],
        }];
        body_forms.extend_from_slice(forms);
        let body_form = Form {
            kind: Kind::List(body_forms),
            span,
            metadata: vec![],
        };
        self.analysis_contexts.push(context);
        let result = stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || {
            self.expand_or_analyze(&body_form, context, tail, None)
        });
        self.analysis_contexts.pop();
        result.map(|mut body| {
            let source = body.source.as_mut().expect("analyzed source body");
            std::sync::Arc::make_mut(source).is_body = true;
            body
        })
    }
    fn form_in(
        &mut self,
        form: &Form,
        context: super::AnalysisContext,
        tail: bool,
    ) -> Result<Hir, Diagnostic> {
        self.form_in_named(form, context, tail, None)
    }
    fn form_in_named(
        &mut self,
        form: &Form,
        context: super::AnalysisContext,
        tail: bool,
        name_hint: Option<&Form>,
    ) -> Result<Hir, Diagnostic> {
        // Recursive re-expansion consumes the enclosing request budget. The
        // growable stack below protects native analysis without imposing a
        // fixed language-level nesting ceiling.
        self.expander.charge_expansion_work(1, form.span.clone())?;
        let previous_origin = self.origin.clone();
        let has_template = self.analysis_depth == 0 && super::syntax_quote::has_template_metered(
            form, &mut |work| self.expander.charge_expansion_work(work, form.span.clone()),
        )?;
        let reader_form = if has_template {
            let expander = &mut *self.expander;
            let mut meter = |work| expander.charge_expansion_work(work, form.span.clone());
            let mut reader = self.environment.reader_state.clone();
            let raw = reader.expand_with_origin_metered(
                form,
                &self.environment,
                self.phase,
                self.origin.as_ref(),
                &mut meter,
            )?;
            // Replay the same initial counter against verified indexing data;
            // this does not allocate another set of observable generated IDs.
            let mut replay = self.environment.reader_state.clone();
            let located = if let Some(origin) = &self.origin {
                origin.reader_tree_metered(form, &mut meter)?
            } else {
                super::clone_form_metered(form, &mut meter)?
            };
            let located = replay.expand_with_origin_metered(&located, &self.environment, self.phase, None, &mut meter)?;
            if reader != replay {
                return Err(fail(
                    form.span.clone(),
                    "Reader provenance generated IDs diverged",
                ));
            }
            let lowered = super::syntax_quote::lower_generated_metered(&raw, &mut meter)?;
            let origin = self
                .origin
                .clone()
                .unwrap_or_else(|| super::SourceOrigin::new("", None));
            let lowered_source = super::clone_form_metered(&lowered, &mut meter)?;
            self.origin = Some(origin.with_reader_expansion(lowered_source, located));
            self.environment.reader_state = reader;
            Some(lowered)
        } else {
            None
        };
        let form = reader_form.as_ref().unwrap_or(form);
        if self.analysis_depth == 0 {
            // The pinned analyzer refreshes &env's namespace between top-level
            // forms, not after each nested def. Keep resolution's live catalog
            // separate so recursive definitions still resolve provisionally.
            self.namespace_snapshot = Some(self.capture_source_namespace());
            self.constant_definitions = self.environment.declaration_snapshot();
        }
        self.analysis_depth += 1;
        self.analysis_contexts.push(context);
        let result = stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || {
            self.expand_or_analyze(form, context, tail, name_hint)
        });
        self.analysis_depth -= 1;
        self.analysis_contexts.pop();
        self.origin = previous_origin;
        result
    }
    fn expand_or_analyze(
        &mut self,
        form: &Form,
        context: super::AnalysisContext,
        tail: bool,
        name_hint: Option<&Form>,
    ) -> Result<Hir, Diagnostic> {
        if let Kind::List(items) = &form.kind {
            if let Some(Form {
                kind: Kind::Symbol(symbol),
                ..
            }) = items.first()
            {
                let shadowed = symbol.namespace.is_none()
                    && (self.locals.contains_key(&symbol.name)
                        || self.fields.contains_key(&symbol.name));
                if !shadowed {
                    let expansion_context = super::ExpansionContext {
                        environment: &self.environment,
                        namespace_snapshot: self
                            .namespace_snapshot
                            .as_ref()
                            .expect("top-level source snapshot"),
                        origin: self.origin.as_ref(),
                        phase: self.phase,
                        context,
                        locals: &self.locals,
                        fields: &self.fields,
                        function_scopes: &self.function_scopes,
                    };
                    if let Some(expanded) = self.expander.expand(form, expansion_context)? {
                        if self.environment.resolves_bootstrap_name(self.phase, symbol, "defmacro") {
                            let namespace = self.environment.current_namespace(self.phase).to_owned();
                            if let Some(names) = self.expander.declared_macro_exports(&namespace) {
                                self.environment.declare_macro_exports(self.phase, &namespace, &names)?;
                                if let Some(Form { kind: Kind::Symbol(name), .. }) = items.get(1) {
                                    self.environment.record_macro_declaration(self.phase, &namespace, &name.name);
                                }
                            }
                        }
                        return self.form_in_named(&expanded, context, tail, name_hint);
                    }
                    // Bootstrap binding forms lower before source facts are
                    // recorded. let shares the pinned function-pattern binder;
                    // loop keeps its existing primitive lowering.
                    // Pinned EPL-1.0 core.cljc772–813 expands let/loop to their
                    // primitive forms. Analyze that actual expansion before
                    // recording source facts; lexical callees stay untouched.
                    let primitive =
                        match self.environment.resolve_bootstrap_macro(self.phase, symbol) {
                            Some(ResolvedBinding::BootstrapLet(global)) => Some(if global.name() == "letfn" { "letfn*" } else { "let*" }),
                            Some(ResolvedBinding::BootstrapLoop(_)) => Some("loop*"),
                            _ => None,
                        };
                    if let Some(primitive) = primitive {
                        let mut expanded = if primitive == "let*" {
                            self.destructured_let(form)?
                        } else if primitive == "letfn*" {
                            self.letfn_expansion(form)?
                        } else {
                            form.clone()
                        };
                        let Kind::List(items) = &mut expanded.kind else {
                            unreachable!()
                        };
                        items[0].kind = Kind::Symbol(suss_reader::Symbol {
                            namespace: None,
                            name: primitive.into(),
                        });
                        // The fixed primitive rewrite is analyzed in this
                        // frame; it cannot form a recursive bootstrap chain.
                        return stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || {
                            self.expand_or_analyze(&expanded, context, tail, name_hint)
                        });
                    }
                }
            }
        }
        let coerced = {
            let expander = &mut *self.expander;
            super::syntax_quote::reader_sequence_initializer(
                form, &self.environment, self.phase, self.origin.as_ref(),
                &mut |work| expander.charge_expansion_work(work, form.span.clone()),
            )?
        };
        let namespace = self.environment.current_namespace(self.phase).to_owned();
        let scope = self.capture_source_namespace();
        let locals = self.locals.clone();
        let fields = self.fields.clone();
        let function_scopes = self.function_scopes.clone();
        let symbol = match &form.kind {
            Kind::Symbol(symbol) => Some(symbol),
            Kind::List(items) => items.first().and_then(|head| {
                if let Kind::Symbol(symbol) = &head.kind {
                    Some(symbol)
                } else {
                    None
                }
            }),
            _ => None,
        };
        let resolved = symbol.and_then(|symbol| {
            if symbol.namespace.is_none() || symbol.namespace.as_deref() == Some("js") {
                if let Some(binding) = self.locals.get(&symbol.name) {
                    return Some(SourceBinding::Local(std::sync::Arc::new(binding.clone())));
                }
                if let Some(field) = self.fields.get(&symbol.name) {
                    return Some(SourceBinding::Field(std::sync::Arc::new(field.clone())));
                }
            }
            self.environment
                .resolve(self.phase, symbol, form.span.clone())
                .ok()
                .map(|binding| {
                    let global = binding.global().clone();
                    if global.namespace() == "js" && matches!(binding, ResolvedBinding::Core { .. })
                    {
                        return SourceBinding::JavaScript { global };
                    }
                    let declaration = self.constant_definitions.get(&global)
                        .filter(|info| info.constant.is_some()).cloned()
                        .or_else(|| self.environment.shared_definition_info(&global).cloned());
                    SourceBinding::Global {
                        global,
                        declaration,
                    }
                })
        });
        // A nested source function gets its own fact slot. Compiler-only
        // wrappers never become the evidence for a source function's methods.
        self.source_callables.push(None);
        self.source_nodes.push(None);
        let result = match coerced {
            Some(coerced) => self.reader_sequence_call(form, coerced),
            None => self.form_inner(form, context, tail, name_hint),
        };
        let callable = self
            .source_callables
            .pop()
            .expect("source callable fact slot");
        let node = self.source_nodes.pop().expect("source node fact slot");
        result.and_then(|mut expression| {
            // A bootstrap/source expansion may already have returned its actual
            // analyzed node. Preserve that record instead of attributing the
            // original macro call to the expanded expression.
            if expression.source.is_none() {
                let tags = source_tags::source_tags_metered(
                    form,
                    resolved.as_ref(),
                    callable.as_deref(),
                    &expression,
                    &mut |work| self.expander.charge_expansion_work(work, form.span.clone()),
                )?;
                let mut source = SourceAnalysis {
                    is_body: false,
                    tags,
                    form: form.clone(),
                    resolved,
                    name_hint: name_hint.cloned(),
                    scope,
                    namespace_snapshot: self
                        .namespace_snapshot
                        .as_ref()
                        .expect("top-level source snapshot")
                        .clone(),
                    callable,
                    node,
                    locals,
                    fields,
                    function_scopes,
                    context,
                    phase: self.phase,
                    namespace,
                    origin: self.origin.clone(),
                };
                if let Some(node) = &source.node
                    && let SourceNode::WithMeta {
                        expression: value,
                        metadata,
                        inner,
                    } = node.as_ref()
                {
                    // The child uses the original entry snapshot and form,
                    // but the expression context of analyze-wrap-meta.
                    let mut value = value.as_ref().clone();
                    let mut child = source.clone();
                    child.context = super::AnalysisContext::Expression;
                    child.node = inner.clone();
                    value.source = Some(std::sync::Arc::new(child));
                    source.tags = source_tags::metadata_wrapper_tags_metered(
                        form,
                        &mut |work| self.expander.charge_expansion_work(work, form.span.clone()),
                    )?;
                    source.node = Some(std::sync::Arc::new(SourceNode::WithMeta {
                        expression: std::sync::Arc::new(value),
                        metadata: metadata.clone(),
                        inner: inner.clone(),
                    }));
                }
                expression.source = Some(std::sync::Arc::new(source));
            }
            Ok(expression)
        })
    }
    /// A syntax quote's `(sequence ...)` call, which reads core's sequence
    /// through a private fallback cell.
    fn reader_sequence_call(&mut self, form: &Form, coerced: Form) -> Result<Hir, Diagnostic> {
        let (global, fallback, fresh) = self.environment.reader_sequence_cells(self.phase);
        if fresh {
            let initializer = self.form(&coerced)?;
            self.callable_keys.insert(
                fallback.clone(),
                Hir {
                    source: None,
                    span: form.span.clone(),
                    metadata: Vec::new(),
                    ty: Type::Value,
                    kind: std::sync::Arc::new(Expression::Definition {
                result: None,
                constant: None,
                        global: fallback.clone(),
                        name_metadata: Vec::new(),
                        name_span: form.span.clone(),
                        docstring: None,
                        initializer: Some(Box::new(initializer)),
                        once: true,
                        linked: None,
                    }),
                },
            );
        }
        let Kind::List(items) = &form.kind else {
            unreachable!()
        };
        // Shipped core's own syntax quotes read its direct-linked sequence.
        let global = self.core_reference_link(&global).unwrap_or(global);
        let argument = self.form(&items[1])?;
        // The call has the source facts of an ordinary call of sequence,
        // so tooling and macro environments see an invocation (#299). In
        // core, sequence may not be declared yet: the call then has none.
        let declared = matches!(&items[0].kind, Kind::Symbol(symbol)
            if self.environment.resolve(self.phase, symbol, items[0].span.clone()).is_ok());
        if declared {
            let callee = self.form(&items[0])?;
            *self.source_nodes.last_mut().expect("source node fact slot") =
                Some(std::sync::Arc::new(SourceNode::Invoke {
                    callee: std::sync::Arc::new(callee),
                    arguments: vec![argument.clone()].into(),
                }));
        }
        Ok(Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty: Type::Value,
            kind: std::sync::Arc::new(Expression::Call {
                callee: Box::new(Hir {
                    source: None,
                    span: items[0].span.clone(),
                    metadata: Vec::new(),
                    ty: Type::Value,
                    kind: std::sync::Arc::new(Expression::GlobalOrFallback { global, fallback }),
                }),
                arguments: vec![argument],
            }),
        })
    }
    fn form_inner(
        &mut self,
        form: &Form,
        context: super::AnalysisContext,
        tail: bool,
        name_hint: Option<&Form>,
    ) -> Result<Hir, Diagnostic> {
        let kind = match &form.kind {
            Kind::NativeConstant { owner, index } => return self.native_constant(form, *owner, *index),
            Kind::Nil => Expression::Literal(Literal::Nil),
            Kind::Bool(value) => Expression::Literal(Literal::Bool(*value)),
            Kind::Number(value) => Expression::Literal(Literal::Number(*value)),
            Kind::Long(value) => Expression::Literal(Literal::Long(*value)),
            Kind::Uuid(value) => return self.uuid_literal(form, *value),
            Kind::Pattern(value) => return self.pattern_literal(form, value),
            Kind::Exact(number) => return self.exact_literal(form, number),
            Kind::String(value) => Expression::Literal(Literal::String(value.clone())),
            Kind::Keyword(value) => {
                return self.identifier_literal(
                    form,
                    value.namespace.as_deref(),
                    &value.name,
                    true,
                );
            }
            Kind::Vector(items) => {
                let value = self.vector_literal(form, items)?;
                return self.attach_literal_metadata(form, value);
            }
            Kind::Map(items) => {
                let value = self.map_literal(form, items)?;
                return self.attach_literal_metadata(form, value);
            }
            Kind::Set(items) => {
                let value = self.set_literal(form, items)?;
                return self.attach_literal_metadata(form, value);
            }
            // A tagged literal is the constant it reads as, as in Clojure:
            // `#queue [(f)]` holds the list `(f)`, and its metadata is data.
            Kind::Tagged { .. } => return self.quote_data(form, 0),
            Kind::List(items) if items.is_empty() => {
                // The pinned emitter reads List.EMPTY for each empty-list literal.
                // Resolve the canonical core binding, never a lexical/user List.
                let symbol = suss_reader::Symbol {
                    namespace: Some("suss.core".into()),
                    name: "List".into(),
                };
                let (kind, ty) = self.global_value(&symbol, form.span.clone())?;
                let owner = Hir {
                    source: None,
                    span: form.span.clone(),
                    metadata: Vec::new(),
                    ty,
                    kind: std::sync::Arc::new(kind),
                };
                let key =
                    self.literal_form(form, Literal::String("EMPTY".encode_utf16().collect()));
                // Compiler lowering, not user field access: core's own List.EMPTY.
                let value = self.nominal(form, Nominal::CoreNamedGet, vec![owner, key]);
                return self.attach_constant_metadata(form, value);
            }
            Kind::Symbol(symbol) => {
                let (kind, ty) =
                    if symbol.namespace.is_none() || symbol.namespace.as_deref() == Some("js") {
                        if let Some(binding) = self.locals.get(&symbol.name) {
                            (Expression::Local(binding.id), binding.ty)
                        } else if let Some(field) = self.fields.get(&symbol.name) {
                            (Expression::clone(&field.access.kind), field.access.ty)
                        } else {
                            self.global_value(symbol, form.span.clone())?
                        }
                    } else {
                        self.global_value(symbol, form.span.clone())?
                    };
                return Ok(Hir {
                    source: None,
                    span: form.span.clone(),
                    metadata: form.metadata.clone(),
                    ty,
                    kind: kind.into(),
                });
            }
            Kind::List(items) if !items.is_empty() => {
                return self.list(form, items, context, tail, name_hint);
            }
            _ => {
                return Err(fail(
                    form.span.clone(),
                    "Form requires namespace, macro, collection or closure lowering not yet implemented",
                ));
            }
        };
        let ty = match &kind {
            Expression::Literal(value) => value.ty(),
            _ => unreachable!(),
        };
        Ok(Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty,
            kind: std::sync::Arc::new(kind),
        })
    }
    fn global_value(
        &mut self,
        symbol: &suss_reader::Symbol,
        span: Range<usize>,
    ) -> Result<(Expression, Type), Diagnostic> {
        let binding = self.environment.resolve(self.phase, symbol, span.clone())?;
        let global = binding.global();
        if !self.privileged && super::bootstrap::is_core_private(global.name()) && self.privileged_definition(global) {
            return Err(fail(span, format!("{} is private to suss.core", global.name())));
        }
        if let Some(info) = self.constant_definitions.get(global)
            && let Some(constant) = &info.constant
            && let Some(initializer) = info.initializer.as_deref()
        {
            // Read the initialized revision preceding this top-level form.
            // Copying its literal would allocate distinct BigInt/Ratio objects
            // on every use and lose the constant's observable identity.
            return Ok((Expression::Global(constant.clone()), initializer.ty));
        }
        match binding {
            ResolvedBinding::NumericClass { kind, .. } => Ok((Expression::Nominal { operation: Nominal::NumericClass(kind), arguments: vec![] }, Type::Value)),
            ResolvedBinding::Cell(global) => {
                let global = self.core_reference_link(&global).unwrap_or(global);
                Ok((Expression::Global(global), Type::Value))
            }
            ResolvedBinding::Arithmetic { global, .. } | ResolvedBinding::Core { global, .. } => {
                if self.privileged {
                    // Shipped core reads its own copy, never a user redefinition.
                    let link = self.environment.bootstrap_link(&global);
                    return Ok((Expression::Global(link), Type::Value));
                }
                self.environment.materialize_bootstrap(global.clone());
                Ok((Expression::Global(global), Type::Value))
            }
            _ => Err(fail(
                span,
                "Bootstrap core function/macro values are not materialized yet",
            )),
        }
    }
    fn constant_metadata(name: &Form) -> Result<bool, Diagnostic> {
        Ok(reader_metadata_pairs(name)?.chunks_exact(2).any(|pair| {
            matches!(&pair[0].kind, Kind::Keyword(key)
                if key.namespace.is_none() && key.name == "const")
                && !matches!(pair[1].kind, Kind::Nil | Kind::Bool(false))
        }))
    }
    fn dynamic_metadata(name: &Form) -> bool {
        name.metadata.iter().any(|metadata| match &metadata.kind {
            Kind::Map(entries) => entries.chunks(2).any(|pair| {
                matches!(&pair[0].kind, Kind::Keyword(key) if key.namespace.is_none() && matches!(key.name.as_str(), "dynamic" | "redef"))
                    && !matches!(pair.get(1).map(|value| &value.kind), Some(Kind::Nil | Kind::Bool(false)) | None)
            }),
            Kind::Keyword(key) => key.namespace.is_none() && matches!(key.name.as_str(), "dynamic" | "redef"),
            _ => false,
        })
    }
    /// The direct-link callee for a call of `global`, in an AOT build (#360).
    fn direct_link(&self, global: &Global) -> Option<usize> {
        // Core calls its own definitions, which it reads through their core
        // link cells; user AOT code calls user definitions.
        let global = if self.privileged {
            if !self.environment.core_image_links {
                return None;
            }
            global.core_var_of_link()?
        } else if self.environment.direct_linking && global.namespace() != "suss.core" {
            global.clone()
        } else {
            return None;
        };
        self.environment.direct_links.get(&global)
            .filter(|&&(_, definition)| !self.privileged || self.fragment_links.contains(&definition))
            .map(|&(slot, definition)| link_pair(slot, definition))
    }
    /// Shipped core's own definitions are direct-linked, except dynamic and
    /// `^:redef` vars (as in Clojure), including ones a later form redeclares.
    fn core_link(&mut self, global: &Global, dynamic: bool) -> Option<Global> {
        (self.privileged && !dynamic && global.namespace() == "suss.core")
            .then(|| self.environment.core_link_cell(global))
    }
    /// A privileged reference to a direct-linked core definition: only when
    /// that definition (or its declaration) registered a link cell.
    fn core_reference_link(&mut self, global: &Global) -> Option<Global> {
        if !self.privileged || global.namespace() != "suss.core" {
            return None;
        }
        self.environment.existing_core_link(global)
    }
    /// The current binding was defined by compiler-authored source, such as
    /// the shipped core, rather than by user code reusing a core name.
    /// Whether arithmetic and comparisons keep the coercing primitives that
    /// core's pinned source relies on (#286). Source in `suss.core` keeps
    /// them, whether shipped or loaded directly, so core behaves the same
    /// either way; every other namespace gets Clojure's number-only operands.
    pub(super) fn coercing_operands(&self) -> bool {
        self.privileged || self.environment.current_namespace(self.phase) == "suss.core"
    }
    pub(super) fn privileged_definition(&self, global: &Global) -> bool {
        self.environment
            .definition_info(global)
            .and_then(|info| info.origin.as_ref())
            .is_some_and(|origin| origin.is_privileged())
    }
    /// Whether `resolved` is core's `name`, called where it can't be
    /// redefined: from direct-linked user code (#360), or from core through
    /// its link cell.
    fn linked_core_call(&self, resolved: &Option<ResolvedBinding>, name: &str) -> bool {
        let Some(ResolvedBinding::Cell(global)) = resolved else { return false };
        if global.namespace() != "suss.core" || global.name() != name {
            return false;
        }
        if self.privileged {
            self.direct_link(global).is_some()
        } else {
            self.environment.direct_linking
        }
    }
    /// The protocol whose method `resolved` is, for a call with `count`
    /// operands (the receiver first), when the call may dispatch at its site:
    /// from core, or from direct-linked user code, as Clojure's call sites
    /// test the receiver's class whatever the var later holds. IFn's -invoke
    /// keeps its own dispatcher.
    fn protocol_call_site(&self, resolved: &Option<ResolvedBinding>, count: usize) -> Option<Global> {
        let Some(ResolvedBinding::Cell(global)) = resolved else { return None };
        if count == 0 || count > crate::runtime_abi::MAX_FIXED as usize {
            return None;
        }
        let allowed = if self.privileged {
            global.namespace() == "suss.core"
        } else {
            self.environment.direct_linking
        };
        if !allowed {
            return None;
        }
        self.environment
            .protocols
            .iter()
            .find(|(protocol, methods)| {
                protocol.phase() == self.phase
                    && protocol.namespace() == global.namespace()
                    && !(protocol.namespace() == "suss.core" && protocol.name() == "IFn")
                    && methods.iter().any(|method| {
                        method.name == global.name() && method.signatures.iter().any(|(n, _)| *n == count)
                    })
            })
            .map(|(protocol, _)| protocol.clone())
    }
    /// `(m x a …)` for protocol method m (#378): an object receiver whose
    /// descriptor has the method calls it directly, through the site's cached
    /// method lookup and closure call; anything else calls m, whose
    /// dispatcher also tries native and default implementations and raises
    /// the protocol's error. Operands are evaluated once, in order.
    fn protocol_site_call(&mut self, form: &Form, items: &[Form], protocol: &Global) -> Result<Hir, Diagnostic> {
        let Kind::Symbol(symbol) = &items[0].kind else { unreachable!("protocol call by symbol") };
        let mut bindings = Vec::with_capacity(items.len() - 1);
        for item in &items[1..] {
            let value = self.form(item)?;
            bindings.push(self.fresh_binding(item, value));
        }
        let locals = bindings
            .iter()
            .map(|binding| {
                let mut local = self.local(form, binding.id);
                local.ty = binding.value.ty;
                local
            })
            .collect::<Vec<_>>();
        let callee = self.form(&items[0])?;
        let callee = match &*callee.kind {
            Expression::Global(global) => match self.direct_link(global) {
                Some(link) => self.nominal(&items[0], Nominal::DirectLinkRead(link), vec![]),
                None => callee,
            },
            _ => callee,
        };
        *self.source_nodes.last_mut().expect("source node fact slot") =
            Some(std::sync::Arc::new(SourceNode::Invoke {
                callee: std::sync::Arc::new(callee.clone()),
                arguments: bindings.iter().map(|binding| binding.value.clone()).collect::<Vec<_>>().into(),
            }));
        let call = |this: &mut Self, callee: Hir| -> Result<Hir, Diagnostic> {
            Ok(Hir {
                source: None,
                span: form.span.clone(),
                metadata: form.metadata.clone(),
                ty: Type::Value,
                kind: std::sync::Arc::new(Expression::Call {
                    callee: Box::new(this.prepare_source_callee(form, callee, locals.len())?),
                    arguments: locals.clone(),
                }),
            })
        };
        let native = self.nominal(form, Nominal::NativeMethodGet, vec![callee.clone(), locals[0].clone()]);
        let slow = call(self, callee)?;
        let node = |kind: Expression, ty: Type| Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty,
            kind: std::sync::Arc::new(kind),
        };
        // The method: an object's, from its descriptor through the site's
        // cache; any other receiver's native or default one, through the
        // protocol fn's tables and a second cache (#445); or nil. The protocol
        // fn is called in one place, for nil, to raise its error.
        // The site reads the method's key without creating it: only a method
        // definition creates a key (`stable_key`), so while it is unbound no
        // type has the method, and a definition bumps the protocol epoch.
        let key = self.environment.protocol_key(protocol, &symbol.name, locals.len());
        let key = node(Expression::Global(key), Type::Value);
        let key = self.fresh_binding(form, key);
        let key_read = self.local(form, key.id);
        let descriptor = self.nominal(form, Nominal::ObjectDescriptor, vec![locals[0].clone()]);
        let lookup = self.nominal(form, Nominal::MethodGet, vec![descriptor, key_read.clone()]);
        let bound = self.nominal(form, Nominal::IsDescriptor, vec![key_read]);
        let nil = || node(Expression::Literal(Literal::Nil), Type::Value);
        let lookup = node(
            Expression::If { condition: Box::new(bound), consequent: Box::new(lookup), alternative: Box::new(nil()) },
            Type::Value,
        );
        let lookup = node(Expression::Let { bindings: vec![key], body: Box::new(lookup) }, Type::Value);
        let test = self.nominal(form, Nominal::IsObject, vec![locals[0].clone()]);
        let lookup = node(
            Expression::If {
                condition: Box::new(test),
                consequent: Box::new(lookup),
                alternative: Box::new(native),
            },
            Type::Value,
        );
        let method = self.fresh_binding(form, lookup);
        let method_read = self.local(form, method.id);
        let direct = node(Expression::Call { callee: Box::new(method_read.clone()), arguments: locals.clone() }, Type::Value);
        let absent = node(Expression::NilTest(Box::new(method_read)), Type::Bool);
        let found = node(
            Expression::If { condition: Box::new(absent), consequent: Box::new(slow), alternative: Box::new(direct) },
            Type::Value,
        );
        let body = node(Expression::Let { bindings: vec![method], body: Box::new(found) }, Type::Value);
        Ok(node(Expression::Let { bindings, body: Box::new(body) }, Type::Value))
    }
    /// `(str a b …)` with 2 to 8 operands (#388): each operand's `(str x)`,
    /// in order, concatenated, which is what str's variadic arity computes,
    /// without its rest seq. Operands are evaluated once, in order, before
    /// any is converted, as for the call.
    fn str_call(&mut self, form: &Form, items: &[Form]) -> Result<Hir, Diagnostic> {
        let mut bindings = Vec::with_capacity(items.len() - 1);
        for item in &items[1..] {
            let value = self.form(item)?;
            bindings.push(self.fresh_binding(item, value));
        }
        let locals = bindings
            .iter()
            .map(|binding| {
                let mut local = self.local(form, binding.id);
                local.ty = binding.value.ty;
                local
            })
            .collect::<Vec<_>>();
        let source_callee = self.form(&items[0])?;
        let mut callee = source_callee.clone();
        // This specialization is selected only for a fixed core call. An
        // AOT user's multi-argument str must keep that same original function
        // for each unary conversion, rather than invoking a rebound public
        // function once per operand. Value uses/aliases still read the var.
        if !self.privileged && self.environment.direct_linking {
            if let Expression::Global(global) = &*callee.kind {
                if global.namespace() == "suss.core" && global.name() == "str"
                    && self.privileged_definition(global)
                {
                    if let Some(link) = self.environment.existing_core_link(global) {
                        callee.kind = std::sync::Arc::new(Expression::Global(link));
                    }
                }
            }
        }
        let callee = match &*callee.kind {
            Expression::Global(global) => match self.direct_link(global) {
                Some(link) => self.nominal(&items[0], Nominal::DirectLinkRead(link), vec![]),
                None => callee,
            },
            _ => callee,
        };
        *self.source_nodes.last_mut().expect("source node fact slot") =
            Some(std::sync::Arc::new(SourceNode::Invoke {
                callee: std::sync::Arc::new(source_callee),
                arguments: bindings.iter().map(|binding| binding.value.clone()).collect::<Vec<_>>().into(),
            }));
        let node = |kind: Expression, ty: Type| Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty,
            kind: std::sync::Arc::new(kind),
        };
        // The text so far, bound once; a later long operand's digits are
        // appended to it directly, with no intermediate digit string.
        let mut text: Option<Hir> = None;
        for local in locals {
            let converted = node(
                Expression::Call {
                    callee: Box::new(self.prepare_source_callee(form, callee.clone(), 1)?),
                    arguments: vec![local.clone()],
                },
                Type::Value,
            );
            text = Some(match text {
                None => converted,
                Some(left) => {
                    let left = self.fresh_binding(form, left);
                    let read = self.local(form, left.id);
                    let test = self.nominal(form, Nominal::IsLongValue, vec![local.clone()]);
                    let append = self.nominal(form, Nominal::StringAppendLong, vec![read.clone(), local]);
                    let concat = self.nominal(form, Nominal::ConcatString, vec![read, converted]);
                    let choice = node(
                        Expression::If { condition: Box::new(test), consequent: Box::new(append), alternative: Box::new(concat) },
                        Type::Value,
                    );
                    node(Expression::Let { bindings: vec![left], body: Box::new(choice) }, Type::Value)
                }
            });
        }
        Ok(node(Expression::Let { bindings, body: Box::new(text.expect("operands")) }, Type::Value))
    }
    /// `(f a …)` where every operand is an i31 runs `fast` on the operands,
    /// and otherwise calls f (#387). Operands are evaluated once, in order.
    fn small_integer_call(
        &mut self,
        form: &Form,
        items: &[Form],
        fast: impl FnOnce(&mut Self, &Form, Vec<Hir>) -> Hir,
    ) -> Result<Hir, Diagnostic> {
        self.typed_small_integer_call(form, items, fast, None)
    }
    /// The same, with the call's result through `cast`, for a callee whose
    /// result is always of the cast's kind, so both branches join raw (#387).
    fn typed_small_integer_call(
        &mut self,
        form: &Form,
        items: &[Form],
        fast: impl FnOnce(&mut Self, &Form, Vec<Hir>) -> Hir,
        cast: Option<Nominal>,
    ) -> Result<Hir, Diagnostic> {
        let mut bindings = Vec::with_capacity(items.len() - 1);
        for item in &items[1..] {
            let value = self.form(item)?;
            bindings.push(self.fresh_binding(item, value));
        }
        let locals = bindings
            .iter()
            .map(|binding| {
                let mut local = self.local(form, binding.id);
                local.ty = binding.value.ty;
                local
            })
            .collect::<Vec<_>>();
        let callee = self.form(&items[0])?;
        let callee = match &*callee.kind {
            Expression::Global(global) => match self.direct_link(global) {
                Some(link) => self.nominal(&items[0], Nominal::DirectLinkRead(link), vec![]),
                None => callee,
            },
            _ => callee,
        };
        *self.source_nodes.last_mut().expect("source node fact slot") =
            Some(std::sync::Arc::new(SourceNode::Invoke {
                callee: std::sync::Arc::new(callee.clone()),
                arguments: bindings.iter().map(|binding| binding.value.clone()).collect::<Vec<_>>().into(),
            }));
        let call = Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty: Type::Value,
            kind: std::sync::Arc::new(Expression::Call {
                callee: Box::new(self.prepare_source_callee(form, callee, locals.len())?),
                arguments: locals.clone(),
            }),
        };
        let call = match cast {
            Some(cast) => self.nominal(form, cast, vec![call]),
            None => call,
        };
        let test = self.nominal(form, Nominal::AllSmallIntegers, locals.clone());
        let fast = fast(self, form, locals);
        Ok(Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty: Type::Value,
            kind: std::sync::Arc::new(Expression::Let {
                bindings,
                body: Box::new(Hir {
                    source: None,
                    span: form.span.clone(),
                    metadata: form.metadata.clone(),
                    ty: Type::Value,
                    kind: std::sync::Arc::new(Expression::If {
                        condition: Box::new(test),
                        consequent: Box::new(fast),
                        alternative: Box::new(call),
                    }),
                }),
            }),
        })
    }
    /// A call of core's `get`, `contains?`, `nth` or `first` in direct-linked
    /// code (#442, #433): the runtime's `operation` answers for the
    /// collections and keys it reads directly, and its undefined answer, for
    /// anything else, calls core's function. The operation takes the call's
    /// first `taken` operands, then `extra`, a constant (first's index 0).
    /// Operands evaluate once, in order.
    fn lookup_call(
        &mut self,
        form: &Form,
        items: &[Form],
        operation: Nominal,
        taken: usize,
        extra: Option<Form>,
    ) -> Result<Hir, Diagnostic> {
        let count = items.len() - 1;
        let mut bindings = Vec::with_capacity(items.len());
        for item in items[1..].iter().chain(extra.as_ref()) {
            let value = self.form(item)?;
            bindings.push(self.fresh_binding(item, value));
        }
        let locals = bindings
            .iter()
            .map(|binding| {
                let mut local = self.local(form, binding.id);
                local.ty = binding.value.ty;
                local
            })
            .collect::<Vec<_>>();
        let mut callee = self.form(&items[0])?;
        let mut source_callee = None;
        // Clojure's inline nth also ignores root replacement on a native miss
        // (lists, strings, out-of-bounds indices, ...). Use the owned core body
        // there, preserving the public var in the source AST. Unknown/user
        // definitions and lexical shadows never enter this path.
        if operation == Nominal::VectorNth {
            if let Expression::Global(global) = &*callee.kind
                && global.namespace() == "suss.core" && global.name() == "nth"
                && self.privileged_definition(global)
                && let Some(link) = self.environment.existing_core_link(global)
            {
                source_callee = Some(callee.clone());
                callee.kind = std::sync::Arc::new(Expression::Global(link));
            }
        }
        let callee = match &*callee.kind {
            Expression::Global(global) => match self.direct_link(global) {
                Some(link) => self.nominal(&items[0], Nominal::DirectLinkRead(link), vec![]),
                None => callee,
            },
            _ => callee,
        };
        *self.source_nodes.last_mut().expect("source node fact slot") =
            Some(std::sync::Arc::new(SourceNode::Invoke {
                callee: std::sync::Arc::new(source_callee.unwrap_or_else(|| callee.clone())),
                arguments: bindings[..count].iter().map(|binding| binding.value.clone()).collect::<Vec<_>>().into(),
            }));
        let node = |kind: Expression, ty: Type| Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty,
            kind: std::sync::Arc::new(kind),
        };
        let call = node(
            Expression::Call {
                callee: Box::new(self.prepare_source_callee(form, callee, count)?),
                arguments: locals[..count].to_vec(),
            },
            Type::Value,
        );
        let operands = locals[..taken].iter().chain(&locals[count..]).cloned().collect();
        let fast = self.nominal(form, operation, operands);
        let answer = self.fresh_binding(form, fast);
        let read = self.local(form, answer.id);
        let missing = self.nominal(form, Nominal::IsUndefined, vec![read.clone()]);
        let choose = node(
            Expression::If { condition: Box::new(missing), consequent: Box::new(call), alternative: Box::new(read) },
            Type::Value,
        );
        bindings.push(answer);
        Ok(node(Expression::Let { bindings, body: Box::new(choose) }, Type::Value))
    }
    fn call(&mut self, form: &Form, items: &[Form]) -> Result<Hir, Diagnostic> {
        let mut callee = Box::new(self.form(&items[0])?);
        // A call of a direct-linked var calls its current definition (#360).
        if let Expression::Global(global) = &*callee.kind
            && let Some(link) = self.direct_link(global)
        {
            callee = Box::new(self.nominal(&items[0], Nominal::DirectLinkRead(link), vec![]));
        }
        let arguments = items[1..]
            .iter()
            .map(|arg| self.form(arg))
            .collect::<Result<Vec<_>, _>>()?;
        // A known closure called with another count compiles, as in Clojure:
        // the call reaches the definition's arity-error entry, which throws
        // Clojure's arity error when it runs (ADR-0004).
        *self.source_nodes.last_mut().expect("source node fact slot") =
            Some(std::sync::Arc::new(SourceNode::Invoke {
                callee: std::sync::Arc::new(callee.as_ref().clone()),
                arguments: arguments.clone().into(),
            }));
        Ok(Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty: Type::Value,
            kind: std::sync::Arc::new(Expression::Call {
                callee: Box::new(self.prepare_source_callee(form, *callee, arguments.len())?),
                arguments,
            }),
        })
    }
    fn definition(&mut self, form: &Form, args: &[Form], once: bool) -> Result<Hir, Diagnostic> {
        if (once && args.len() != 2) || (!once && !(1..=3).contains(&args.len())) {
            return Err(fail(
                form.span.clone(),
                "Definition requires a name and optional initializer; defonce requires both",
            ));
        }
        let Kind::Symbol(name) = &args[0].kind else {
            return Err(fail(
                args[0].span.clone(),
                "Definition name must be a symbol",
            ));
        };
        // ClojureScript :private is retained declaration metadata. Qualified
        // cross-namespace access remains callable (the pinned analyzer emits a
        // warning, not an access error). Warning emission/namespace filtering
        // remain separate unfinished namespace acceptance requirements.
        for metadata in &args[0].metadata {
            let unsupported = |form: &Form| {
                matches!(&form.kind, Kind::Keyword(key)
                if key.namespace.is_none() && key.name == "macro")
            };
            if !self.origin.as_ref().is_some_and(|origin| origin.is_macro_definition())
                && (unsupported(metadata)
                || matches!(&metadata.kind, Kind::Map(entries)
                if entries.chunks_exact(2).any(|entry| unsupported(&entry[0]))))
            {
                return Err(fail(
                    args[0].span.clone(),
                    "Definition const/macro attributes are not implemented yet",
                ));
            }
        }
        let namespace = self.environment.current_namespace(self.phase).to_owned();
        if name
            .namespace
            .as_deref()
            .is_some_and(|ns| ns != namespace && !(namespace == "suss.core" && ns == "cljs.core"))
        {
            return Err(fail(
                args[0].span.clone(),
                "Cannot define a name in another namespace",
            ));
        }
        let global = self
            .environment
            .declare_cell(self.phase, &namespace, &name.name)
            .map_err(|mut error| {
                error.span = args[0].span.clone();
                error
            })?;
        let constant = Self::constant_metadata(&args[0])?;
        let prior_constant = self.constant_definitions.get(&global)
            .map(|info| Self::constant_metadata(&info.declaration))
            .transpose()?.unwrap_or(false);
        // Runtime execution of a conditional/nested def is not established by
        // analyzing it. Until that boundary can publish initialized constant
        // values, diagnose it instead of freezing an unexecuted initializer.
        if self.analysis_depth != 1 && (constant || prior_constant) {
            return Err(fail(args[0].span.clone(),
                "Nested definitions involving :const are not implemented yet"));
        }
        let init = if args.len() == 3 {
            if !matches!(args[1].kind, Kind::String(_)) {
                return Err(fail(
                    args[1].span.clone(),
                    "Definition docstring must be a string",
                ));
            }
            Some(&args[2])
        } else {
            args.get(1)
        };
        // Pinned ClojureScript analyzer.cljc2092–2172 (c4295f3) preserves
        // existing declaration data for a truthy :declared def without an
        // initializer. Initializer-bearing defs still publish their new
        // provisional record before analysis. This original implementation
        // retains the existing immutable revision, including source functions.
        let preserve_declaration = init.is_none()
            && self.environment.definition_info(&global).is_some()
            && reader_metadata_pairs(&args[0])?
                .chunks_exact(2)
                .any(|pair| {
                    matches!(&pair[0].kind, Kind::Keyword(key)
                    if key.namespace.is_none() && key.name == "declared")
                        && !matches!(pair[1].kind, Kind::Nil | Kind::Bool(false))
                });
        let mut definition = super::resolve::DefinitionInfo {
            definition_form: form.clone(),
            analysis_completed: false,
            declaration: args[0].clone(),
            docstring: if args.len() == 3 {
                match &args[1].kind {
                    Kind::String(units) => Some(units.clone()),
                    _ => unreachable!(),
                }
            } else {
                None
            },
            origin: self.origin.clone(),
            initializer_form: init.cloned(),
            initializer: None,
            type_fields: None,
            type_is_record: false,
            once,
            constant: None,
        };
        // A var first defined dynamic (or ^:redef) stays live when redefined.
        let prior_dynamic = self.environment.definition_info(&global)
            .is_some_and(|info| Self::dynamic_metadata(&info.declaration));
        if !preserve_declaration {
            self.environment
                .record_definition(global.clone(), definition.clone());
        }
        // Register shipped core's direct link before analyzing the initializer,
        // so a self-recursive core function also calls its own definition.
        let dynamic = Self::dynamic_metadata(&args[0]) || prior_dynamic;
        if dynamic && self.privileged && self.environment.existing_core_link(&global).is_some() {
            // Earlier core references were direct-linked; a dynamic var must be live.
            return Err(fail(args[0].span.clone(), "A dynamic core var cannot be declared before its definition"));
        }
        let linked = self.core_link(&global, dynamic);
        // A top-level `fn` initializer links before its analysis, so the
        // function's own calls of the var are direct too (#360).
        // Shipped core is direct-linked by design, in every build (#360);
        // user code is in AOT builds.
        let link_base = !dynamic
            && if self.privileged {
                self.environment.core_image_links && global.namespace() == "suss.core"
            } else {
                self.environment.direct_linking && global.namespace() != "suss.core"
            };
        let early_link = (link_base && self.locals.is_empty() && init.is_some_and(fn_form))
            .then(|| self.environment.define_direct_link(&global));
        if let Some((_, definition)) = early_link {
            self.fragment_links.insert(definition);
        }
        let initializer = init
            .map(|init| {
                self.form_in_named(
                    init,
                    super::AnalysisContext::Expression,
                    false,
                    Some(&args[0]),
                )
                .map(Box::new)
            })
            .transpose()?;
        if constant && !initializer.as_deref().is_some_and(|value| match &*value.kind {
            Expression::Literal(_) => true,
            Expression::Global(global) => global.namespace() == "suss.internal.constants",
            _ => false,
        }) {
            return Err(fail(args[0].span.clone(),
                "Only scalar literal :const initializers are implemented yet"));
        }
        let constant_cell = constant.then(|| self.environment.constant_cell(self.phase));
        definition.constant = constant_cell.clone();
        // A nested initializer can declare this same global. Publish the outer
        // declaration and its initializer together when its analysis completes.
        definition.initializer = initializer.as_deref().cloned().map(std::sync::Arc::new);
        definition.analysis_completed = true;
        if let Some(cell) = &constant_cell {
            // Private source typing retains the initializer's original class
            // even after the public var receives a differently typed value.
            let mut revision = definition.clone();
            revision.constant = None;
            self.environment.record_definition(cell.clone(), revision);
        }
        if !preserve_declaration {
            self.environment
                .record_definition(global.clone(), definition);
        }
        // Direct linking (#360): in an AOT build, a user var defined as a
        // function with no captures publishes its closure as a new link, and
        // later calls of the var call that definition, as Clojure's
        // direct-linked calls do. Dynamic and ^:redef vars stay live.
        let capture_free = initializer.as_deref().is_some_and(capture_free_function);
        if early_link.is_some() && !capture_free {
            return Err(fail(form.span.clone(), "A top-level fn initializer captured a local"));
        }
        let initializer = if link_base && capture_free {
            let (slot, definition) = match early_link {
                Some(link) => link,
                None => self.environment.define_direct_link(&global),
            };
            self.fragment_links.insert(definition);
            let link = link_pair(slot, definition);
            initializer.map(|initializer| {
                let value = self.fresh_binding(form, *initializer);
                let publish = self.nominal(form, Nominal::DirectLinkDefine(link), vec![self.local(form, value.id)]);
                let result = self.local(form, value.id);
                let body = self.do_hir(form, vec![publish, result]);
                Box::new(Hir {
                    source: None,
                    span: form.span.clone(),
                    metadata: vec![],
                    ty: Type::Value,
                    kind: std::sync::Arc::new(Expression::Let { bindings: vec![value], body: Box::new(body) }),
                })
            })
        } else {
            self.environment.end_direct_link(&global);
            initializer
        };
        let native_vars = self.environment.resolve(self.phase, &suss_reader::Symbol::namespaced("suss.core", "make-binding-var"), form.span.clone())
            .ok().and_then(|binding| self.environment.existing_core_link(binding.global())).is_some();
        let result = if !self.privileged && native_vars {
            Some(Box::new(self.binding_var(form, &global, true)?))
        } else { None };
        Ok(Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty: Type::Value,
            kind: std::sync::Arc::new(Expression::Definition {
                result,
                constant: constant_cell,
                global,
                name_metadata: args[0].metadata.clone(),
                name_span: args[0].span.clone(),
                docstring: if args.len() == 3 {
                    match &args[1].kind {
                        Kind::String(units) => Some(units.clone()),
                        _ => unreachable!(),
                    }
                } else {
                    None
                },
                initializer,
                once,
                linked,
            }),
        })
    }
    fn function(
        &mut self,
        form: &Form,
        args: &[Form],
        bootstrap_macro: bool,
        name_hint: Option<&Form>,
    ) -> Result<Hir, Diagnostic> {
        let expanded;
        let args = if bootstrap_macro {
            expanded = self.destructured_function_arguments(form, args)?;
            expanded.as_slice()
        } else {
            args
        };
        let outer_scope_count = self.function_scopes.len();
        let suspendable = std::mem::replace(&mut self.suspendable, false);
        // A WIT export's numeric parameters are primitive (#385): its method
        // of that arity takes the hints; nested fns never see them.
        let outer_hints = self.pending_param_hints.take();
        self.pending_param_hints = name_hint.and_then(|hint| match &hint.kind {
            Kind::Symbol(symbol) if symbol.namespace.is_none() && !self.privileged => self
                .environment
                .export_param_hints(self.environment.current_namespace(self.phase), &symbol.name)
                .cloned(),
            _ => None,
        });
        // defn carries its declaration's return tag on the fn form, as
        // Clojure's :rettag. A plain def's :tag describes the var value and
        // must not change an initializer function's return behavior.
        let return_hint = primitive_tag_key(form, "rettag")?;
        let outer_return_hint = std::mem::replace(&mut self.pending_return_hint, return_hint);
        let result = self.function_inner(form, args, bootstrap_macro, name_hint);
        self.pending_return_hint = outer_return_hint;
        self.pending_param_hints = outer_hints;
        self.suspendable = suspendable;
        if result.is_ok() {
            let name = self.function_scopes.get(outer_scope_count).cloned();
            if let Some(callable) = self.source_callables.last_mut().and_then(Option::as_mut) {
                std::sync::Arc::make_mut(callable).name = name;
            }
        }
        if self.function_scopes.len() > outer_scope_count {
            self.function_scopes = self.function_scopes[..outer_scope_count].into();
        }
        result
    }
    fn function_inner(
        &mut self,
        form: &Form,
        args: &[Form],
        bootstrap_macro: bool,
        name_hint: Option<&Form>,
    ) -> Result<Hir, Diagnostic> {
        if args
            .first()
            .is_some_and(|arg| matches!(&arg.kind, Kind::Vector(names)
                if !names.iter().any(|name| matches!(&name.kind, Kind::Symbol(symbol) if symbol.namespace.is_none() && symbol.name == "&"))))
        {
            self.enter_function_scope(form, name_hint, None);
            let (function, source_method) = self.fixed_function(form, args, bootstrap_macro)?;
            *self.source_callables.last_mut().expect("source function fact slot") = Some(std::sync::Arc::new(SourceCallable {
                name: None,
                methods: vec![source_method],
            }));
            return Ok(function);
        }
        let outer = self.locals.clone();
        let (self_binding, signatures) = if let Some(Form {
            kind: Kind::Symbol(name),
            ..
        }) = args.first()
        {
            if name.namespace.is_some() || name.name == "&" {
                return Err(fail(
                    args[0].span.clone(),
                    "Function name must be unqualified",
                ));
            }
            let id = BindingId(self.next);
            self.next += 1;
            self.insert_local(&args[0], id, Type::Value, LocalKind::FunctionName, None);
            (
                Some(Parameter {
                    id,
                    name: name.name.clone(),
                    metadata: args[0].metadata.clone(),
                    span: args[0].span.clone(),
                }),
                &args[1..],
            )
        } else {
            (None, args)
        };
        if let Some(parameter) = &self_binding {
            // These signatures are actual source declarations, before body analysis.
            let variadic = if let Some(Form {
                kind: Kind::Vector(names),
                ..
            }) = signatures.first()
            {
                names.iter().any(|name| matches!(&name.kind, Kind::Symbol(name) if name.namespace.is_none() && name.name == "&"))
            } else {
                signatures.iter().any(|signature| matches!(&signature.kind, Kind::List(parts) if matches!(parts.first().map(|part| &part.kind), Some(Kind::Vector(names)) if names.iter().any(|name| matches!(&name.kind, Kind::Symbol(name) if name.namespace.is_none() && name.name == "&")))))
            };
            std::sync::Arc::make_mut(&mut self.locals).get_mut(&parameter.name).unwrap().source_role = SourceRole::FunctionName {
                variadic,
                methods: None,
            };
        }
        let declaration = if self_binding.is_some() {
            args.first()
        } else {
            name_hint
        };
        let local = self_binding
            .as_ref()
            .map(|binding| self.locals[&binding.name].clone());
        self.enter_function_scope(form, declaration, local);
        if let Some(parameter) = &self_binding {
            let staged = std::sync::Arc::new(self.stage_function_parameters(form, signatures)?);
            let variadic = staged.methods.iter().any(|method| method.variadic);
            std::sync::Arc::make_mut(&mut self.locals)
                .get_mut(&parameter.name)
                .expect("self binding")
                .source_role = SourceRole::FunctionName {
                variadic,
                methods: Some(staged),
            };
        }
        let mut methods = Vec::new();
        let mut source_methods = Vec::new();
        let mut captures = BTreeSet::new();
        if signatures
            .first()
            .is_some_and(|arg| matches!(arg.kind, Kind::Vector(_)))
        {
            let (method, free, source_method) =
                self.general_method(form, signatures, bootstrap_macro)?;
            source_methods.push(source_method);
            captures.extend(free);
            methods.push(method);
        } else {
            for signature in signatures {
                let Kind::List(items) = &signature.kind else {
                    return Err(fail(
                        signature.span.clone(),
                        "Function signature requires a parameter vector and body",
                    ));
                };
                let multi = signatures.len() > 1;
                if multi {
                    self.analysis_contexts
                        .push(super::AnalysisContext::Expression);
                }
                let result = self.general_method(signature, items, bootstrap_macro);
                if multi {
                    self.analysis_contexts.pop();
                }
                let (method, free, source_method) = result?;
                source_methods.push(source_method);
                captures.extend(free);
                methods.push(method);
            }
        }
        // The pinned compiler warns on duplicate fixed arities and executes the last body.
        methods.reverse();
        let mut arities = BTreeSet::new();
        methods.retain(|method| arities.insert((method.parameters.len(), method.variadic)));
        methods.reverse();
        let variadic: Vec<_> = methods.iter().filter(|method| method.variadic).collect();
        if variadic.len() > 1
            || variadic.first().is_some_and(|method| {
                methods.iter().any(|fixed| {
                    !fixed.variadic && fixed.parameters.len() > method.parameters.len() - 1
                })
            })
        {
            return Err(fail(
                form.span.clone(),
                "Function requires one variadic signature with no larger fixed arity",
            ));
        }
        let rest_class = if variadic.is_empty() {
            None
        } else {
            Some(
                self.environment
                    .resolve(
                        self.phase,
                        &suss_reader::Symbol {
                            namespace: Some("suss.core".into()),
                            name: "IndexedSeq".into(),
                        },
                        form.span.clone(),
                    )?
                    .global()
                    .clone(),
            )
        };
        captures.clear();
        for method in &methods {
            let mut bound: BTreeSet<_> = method
                .parameters
                .iter()
                .map(|parameter| parameter.id)
                .collect();
            if let Some(parameter) = &self_binding {
                bound.insert(parameter.id);
            }
            free_bindings(&method.body, &bound, &mut captures);
        }
        self.locals = outer;
        if methods.is_empty() {
            return Err(fail(
                form.span.clone(),
                "Function requires at least one signature",
            ));
        }
        if let Some(parameter) = &self_binding {
            captures.remove(&parameter.id);
        }
        let function = Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty: Type::Value,
            kind: std::sync::Arc::new(Expression::GeneralFunction {
                methods,
                captures: captures.into_iter().collect(),
                self_binding,
                rest_class,
            }),
        };
        let function = self.attach_callable_signatures(form, function)?;
        *self
            .source_callables
            .last_mut()
            .expect("source function fact slot") = Some(std::sync::Arc::new(SourceCallable {
            name: None,
            methods: source_methods,
        }));
        Ok(function)
    }
    fn general_method(
        &mut self,
        form: &Form,
        args: &[Form],
        bootstrap_macro: bool,
    ) -> Result<(Method, Vec<BindingId>, SourceMethod), Diagnostic> {
        let method_form = if matches!(&form.kind, Kind::List(parts)
            if matches!(parts.first().map(|part| &part.kind), Some(Kind::Vector(_))))
        {
            form.clone()
        } else {
            Form {
                kind: Kind::List(args.to_vec()),
                span: form.span.clone(),
                metadata: vec![],
            }
        };
        let (args, variadic, rest_parameter) = Self::normalize_function_method(form, args)?;
        let (mut method, mut source_method) = self.fixed_function_fields(
            form,
            &args,
            bootstrap_macro,
            &[],
            false,
            false,
            rest_parameter,
            None,
        )?;
        source_method.form = method_form;
        source_method.variadic = variadic;
        let Expression::Function {
            parameters,
            body,
            captures,
        } = method.take_kind()
        else {
            unreachable!()
        };
        Ok((
            Method {
                parameters,
                body,
                variadic,
            },
            captures,
            source_method,
        ))
    }
    fn fixed_function(
        &mut self,
        form: &Form,
        args: &[Form],
        bootstrap_macro: bool,
    ) -> Result<(Hir, SourceMethod), Diagnostic> {
        self.fixed_function_fields(form, args, bootstrap_macro, &[], false, false, None, None)
    }
    fn fixed_function_fields(
        &mut self,
        form: &Form,
        args: &[Form],
        bootstrap_macro: bool,
        fields: &[Form],
        method_receiver: bool,
        object_method: bool,
        rest_parameter: Option<usize>,
        receiver_type: Option<&Form>,
    ) -> Result<(Hir, SourceMethod), Diagnostic> {
        // Object and protocol methods also enter through this boundary rather
        // than the ordinary function wrapper. Their bodies are synchronous;
        // only a nested future may introduce a new suspendable context.
        let expanded;
        let args = if bootstrap_macro {
            expanded = self.destructured_function_arguments(form, args)?;
            expanded.as_slice()
        } else {
            args
        };
        let suspendable = std::mem::replace(&mut self.suspendable, false);
        let result = self.fixed_function_fields_inner(
            form,
            args,
            bootstrap_macro,
            fields,
            method_receiver,
            object_method,
            rest_parameter,
            receiver_type,
        );
        self.suspendable = suspendable;
        result
    }
    fn fixed_function_fields_inner(
        &mut self,
        form: &Form,
        args: &[Form],
        bootstrap_macro: bool,
        fields: &[Form],
        method_receiver: bool,
        object_method: bool,
        rest_parameter: Option<usize>,
        receiver_type: Option<&Form>,
    ) -> Result<(Hir, SourceMethod), Diagnostic> {
        let Some(params) = args.first() else {
            return Err(fail(form.span.clone(), "fn requires a parameter vector"));
        };
        let Kind::Vector(names) = &params.kind else {
            return Err(fail(
                params.span.clone(),
                "Function signature requires a parameter vector",
            ));
        };
        if object_method && names.is_empty() {
            return Err(fail(
                params.span.clone(),
                "Object method requires a receiver",
            ));
        }
        // Pinned cljs.core/fn reads conditions from signature metadata as well
        // as a leading body map. fn* receives already-expanded syntax instead.
        if bootstrap_macro {
            for metadata in &params.metadata {
                let condition_key = |form: &Form| {
                    matches!(&form.kind, Kind::Keyword(key)
                        if key.namespace.is_none() && matches!(key.name.as_str(), "pre" | "post"))
                };
                if condition_key(metadata)
                    || matches!(&metadata.kind, Kind::Map(entries)
                        if entries.chunks_exact(2).any(|entry| condition_key(&entry[0])))
                {
                    return Err(fail(
                        params.span.clone(),
                        "Function pre/post conditions are not lowered yet",
                    ));
                }
            }
        }
        let method_environment = SourceMethodEnvironment {
            scope: self.capture_source_namespace(),
            namespace_snapshot: self
                .namespace_snapshot
                .as_ref()
                .expect("top-level source snapshot")
                .clone(),
            locals: self.locals.clone(),
            fields: self.fields.clone(),
            function_scopes: self.function_scopes.clone(),
            context: *self
                .analysis_contexts
                .last()
                .expect("method analysis context"),
        };
        let outer = self.locals.clone();
        let outer_fields = self.fields.clone();
        let (parameters, declarations) =
            self.allocate_function_parameters(names, rest_parameter, receiver_type.is_some())?;
        let target = LoopId(self.next_loop);
        self.next_loop += 1;
        let outer_target = self
            .target
            .replace((target, parameters.len() - usize::from(object_method)));
        let mut bindings = Vec::new();
        for parameter in parameters.iter().skip(usize::from(object_method)) {
            let id = BindingId(self.next);
            self.next += 1;
            bindings.push(Binding {
                id,
                name: parameter.name.clone(),
                metadata: parameter.metadata.clone(),
                span: parameter.span.clone(),
                value: Hir {
                    source: None,
                    span: parameter.span.clone(),
                    metadata: Vec::new(),
                    ty: Type::Value,
                    kind: std::sync::Arc::new(Expression::Local(parameter.id)),
                },
            });
            self.remap_local(&parameter.name, id, Type::Value);
        }
        if !fields.is_empty() {
            let receiver = parameters
                .first()
                .ok_or_else(|| fail(form.span.clone(), "Protocol method requires a receiver"))?
                .id;
            for (source_index, field) in fields.iter().enumerate() {
                // JS constructor assignments alias fields with the same munged name;
                // the last declaration supplies their shared physical storage slot.
                let Kind::Symbol(field_symbol) = &field.kind else { unreachable!() };
                let storage_name = crate::portable::compiler_names::munge_name(
                    &field_symbol.name.encode_utf16().collect::<Vec<_>>());
                let index = fields.iter().rposition(|candidate| {
                    let Kind::Symbol(symbol) = &candidate.kind else { unreachable!() };
                    crate::portable::compiler_names::munge_name(
                        &symbol.name.encode_utf16().collect::<Vec<_>>()) == storage_name
                }).expect("field has its own storage declaration");
                let Kind::Symbol(symbol) = &field.kind else {
                    unreachable!()
                };
                let parameter = parameters
                    .iter()
                    .any(|parameter| parameter.name == symbol.name);
                if !parameter {
                    std::sync::Arc::make_mut(&mut self.locals).remove(&symbol.name);
                }
                let value = if object_method {
                    let key = self
                        .literal_form(field, Literal::String(storage_name));
                    self.nominal(
                        field,
                        Nominal::NamedGet,
                        vec![self.local(field, receiver), key],
                    )
                } else {
                    self.nominal(
                        field,
                        Nominal::Field(index),
                        vec![self.local(field, receiver)],
                    )
                };
                let record = FieldBinding {
                    identity: std::sync::Arc::new(()),
                    declaration: field.clone(),
                    origin: self.origin.clone(),
                    // Analyzer facts retain the original declaration order;
                    // only executable access uses the canonical storage slot.
                    index: source_index,
                    mutable: Self::field_mutable(field)?,
                    access: value,
                };
                if parameter {
                    let binding = std::sync::Arc::make_mut(&mut self.locals).get_mut(&symbol.name).expect("method parameter");
                    binding.shadow = None;
                    binding.shadow_field = Some(std::sync::Arc::new(record.clone()));
                }
                std::sync::Arc::make_mut(&mut self.fields).insert(symbol.name.clone(), record);
            }
        }
        // Retain the visible argument before this-as anchors the receiver.
        // Repeated names are legal: the last formal can shadow the receiver.
        let receiver_argument = if receiver_type.is_some() {
            parameters
                .first()
                .and_then(|parameter| self.locals.get(&parameter.name))
                .cloned()
        } else {
            None
        };
        if method_receiver {
            let parameter = parameters
                .first()
                .ok_or_else(|| fail(form.span.clone(), "Protocol method requires a receiver"))?;
            // The pin anchors a method's physical receiver across recur. The
            // first recur operand still evaluates, but does not replace `this`.
            self.remap_local(&parameter.name, parameter.id, Type::Value);
        }
        if let Some(receiver_type) = receiver_type {
            self.record_method_roles(
                &parameters,
                names,
                receiver_type,
                object_method,
                receiver_argument,
            );
        }
        // Field reads occur at the original use, including in nested closures;
        // unreferenced fields must not introduce checks or effects before a body.
        // A `^long` or `^double` parameter (#385), as Clojure's primitive
        // fns: its name in the body is the checked cast of the argument, a
        // raw i64 or f64, so arithmetic and loops seeded from it stay raw.
        let mut casts = Vec::new();
        let mut source_casts = Vec::new();
        let mut source_parameters = vec![None; parameters.len()];
        let return_hint = primitive_tag(&args[0])?
            .or(if receiver_type.is_none() { self.pending_return_hint } else { None });
        // An exported fn's numeric WIT parameters, when its arity matches. The
        // body's own fns don't see them; another arity still can.
        let pending = self.pending_param_hints.take();
        let exported = pending.clone().filter(|hints| receiver_type.is_none() && rest_parameter.is_none() && hints.len() == parameters.len());
        for (position, parameter) in parameters.iter().enumerate().skip(usize::from(receiver_type.is_some())) {
            let export = exported.as_ref().and_then(|hints| hints[position]).map(|long| if long { Nominal::LongCast } else { Nominal::DoubleCast });
            let declared = primitive_hint(parameter)?;
            let Some(cast) = declared.or(export) else { continue };
            // The name's current binding: the method's loop binding, which
            // recur rebinds, not the entry parameter.
            let current = self.locals.get(&parameter.name).map_or(parameter.id, |binding| binding.id);
            let read = self.local(form, current);
            let value = self.nominal(form, cast, vec![read]);
            let binding = self.fresh_binding(form, value);
            let primitive = declared.map(|cast| if cast == Nominal::LongCast {
                primitive_returns::Primitive::Long
            } else { primitive_returns::Primitive::Double });
            source_parameters[position] = primitive;
            // A WIT-only conversion changes storage, not the source type.
            source_casts.push((binding.id, primitive.unwrap_or(primitive_returns::Primitive::Boxed)));
            self.remap_local(&parameter.name, binding.id, Type::Value);
            casts.push(binding);
        }
        self.method_recurrence.push((target, false));
        let inner_body = self.analyzed_body(
            &args[1..],
            form.span.clone(),
            super::AnalysisContext::Return,
            true,
        )?;
        if return_hint.is_some() || !source_casts.is_empty() {
            // Validate after lexical source facts are available, including
            // captures. Keep the genuine body before parameter conversions.
            self.primitive_methods.insert(target, primitive_returns::Method {
                body: inner_body.clone(), return_hint, casts: source_casts,
                parameters: parameters.iter().zip(source_parameters).skip(usize::from(object_method))
                    .map(|(parameter, primitive)| (parameter.name.clone(), primitive)).collect(),
            });
        }
        if exported.is_none() {
            self.pending_param_hints = pending;
        }
        // Tooling and macro source facts describe the caller's body, not the
        // storage-only parameter conversions inserted around executable HIR.
        let source_body = std::sync::Arc::new(inner_body.clone());
        let inner_body = if casts.is_empty() {
            inner_body
        } else {
            Hir {
                source: None,
                span: inner_body.span.clone(),
                metadata: Vec::new(),
                ty: inner_body.ty,
                kind: std::sync::Arc::new(Expression::Let { bindings: casts, body: Box::new(inner_body) }),
            }
        };
        let (method_target, recurred) = self
            .method_recurrence
            .pop()
            .expect("method recurrence frame");
        debug_assert_eq!(method_target, target);
        let source_method = SourceMethod {
            environment: method_environment,
            form: Form {
                kind: Kind::List(args.to_vec()),
                span: form.span.clone(),
                metadata: vec![],
            },
            declarations,
            parameters: parameters.clone(),
            variadic: rest_parameter.is_some(),
            recurs: recurred.then_some(true),
            body: source_body,
        };
        self.target = outer_target;
        let body = Box::new(Hir {
            source: None,
            span: form.span.clone(),
            metadata: Vec::new(),
            ty: inner_body.ty,
            kind: std::sync::Arc::new(Expression::Loop {
                target,
                bindings,
                body: Box::new(inner_body),
            }),
        });
        // Clojure's boxed invoke delegates to invokePrim: a primitive return
        // tag converts the completed body on either entry. Keep this outside
        // the recurrence loop so recur remains a tail transfer and does not
        // convert intermediate values.
        let body = match return_hint {
            // Compiler primitive return unboxing uses Number.longValue,
            // unlike the checked RT.longCast used for parameters.
            Some(Nominal::LongCast) => Box::new(self.nominal(form, Nominal::UncheckedLongCast, vec![*body])),
            Some(cast) => Box::new(self.nominal(form, cast, vec![*body])),
            None => body,
        };
        self.locals = outer;
        self.fields = outer_fields;
        let bound = parameters.iter().map(|parameter| parameter.id).collect();
        let mut captures = BTreeSet::new();
        free_bindings(&body, &bound, &mut captures);
        Ok((
            Hir {
                source: None,
                span: form.span.clone(),
                metadata: form.metadata.clone(),
                ty: Type::Closure(parameters.len()),
                kind: std::sync::Arc::new(Expression::Function {
                    parameters,
                    captures: captures.into_iter().collect(),
                    body,
                }),
            },
            source_method,
        ))
    }
    // Object method names use the pinned hyphen-to-underscore munging.
    // Raw named property reads/writes deliberately retain their current boundary.
    // Other munging characters still receive the existing explicit diagnostic.
    fn object_method_name(form: &Form, name: &str) -> Result<String, Diagnostic> {
        Self::property_name(form, &format!(".-{}", name.replace('-', "_")))
    }
    fn property_name(form: &Form, operator: &str) -> Result<String, Diagnostic> {
        // Host field/method spellings use the pinned compiler's empty-reserved
        // munge policy; source type declarations use its default reserved set.
        let units = crate::portable::compiler_names::munge_name_with_reserved(
            &operator[2..].encode_utf16().collect::<Vec<_>>(), |_| false);
        let name = String::from_utf16(&units).map_err(|_| fail(
            form.span.clone(), "Property name contains invalid UTF16"))?;
        if !name
            .bytes()
            .next()
            .is_some_and(|c| c.is_ascii_alphabetic() || c == b'_' || c == b'$')
            || !name
                .bytes()
                .all(|c| c.is_ascii_alphanumeric() || c == b'_' || c == b'$')
        {
            return Err(fail(
                form.span.clone(),
                "Computed or munged property names are not implemented yet",
            ));
        }
        Ok(name)
    }
    fn list(
        &mut self,
        form: &Form,
        items: &[Form],
        context: super::AnalysisContext,
        tail: bool,
        name_hint: Option<&Form>,
    ) -> Result<Hir, Diagnostic> {
        let Kind::Symbol(symbol) = &items[0].kind else {
            // `(:k m)` and `(:k m not-found)` are core's `get`, as Clojure's
            // Keyword.invoke is (#442): the keyword is a constant, so the
            // operands still evaluate once, in order. Core itself keeps the
            // keyword call, since it may invoke keywords before get exists.
            if !self.privileged
                && matches!(items[0].kind, Kind::Keyword(_) | Kind::AutoKeyword(_))
                && (2..=3).contains(&items.len())
            {
                let mut call = form.clone();
                let get = Form {
                    span: items[0].span.clone(),
                    metadata: vec![],
                    kind: Kind::Symbol(suss_reader::Symbol { namespace: Some("suss.core".into()), name: "get".into() }),
                };
                let mut rewritten = vec![get, items[1].clone(), items[0].clone()];
                rewritten.extend(items[2..].iter().cloned());
                call.kind = Kind::List(rewritten);
                let Kind::List(rewritten) = &call.kind else { unreachable!() };
                return self.list(&call, rewritten, context, tail, name_hint);
            }
            return self.call(form, items);
        };
        let args = &items[1..];
        let bare = symbol.namespace.is_none();
        if bare
            && symbol.name == "this-as"
            && !self.locals.contains_key("this-as")
            && !self.fields.contains_key("this-as")
        {
            if args.len() < 2 {
                return Err(fail(form.span.clone(), "this-as requires a binding and body"));
            }
            let Kind::Symbol(name) = &args[0].kind else {
                return Err(fail(args[0].span.clone(), "this-as binding must be a symbol"));
            };
            if name.namespace.is_some() || name.name == "&" {
                return Err(fail(args[0].span.clone(), "this-as binding must be unqualified"));
            }
            let outer = self.locals.clone();
            let current = self.nominal(form, Nominal::CurrentThis, Vec::new());
            let id = BindingId(self.next);
            self.next += 1;
            self.insert_local(
                &args[0],
                id,
                Type::Value,
                LocalKind::Let,
                Some(current.clone()),
            );
            let source_binding = self.locals[&name.name].clone();
            let body = self.analyzed_body(
                &args[1..],
                form.span.clone(),
                context.returning(),
                tail,
            );
            self.locals = outer;
            let body = Box::new(body?);
            *self.source_nodes.last_mut().expect("source node fact slot") = Some(
                std::sync::Arc::new(SourceNode::Bindings {
                    is_loop: false,
                    is_letfn: false,
                    bindings: vec![source_binding].into(),
                    body: std::sync::Arc::new(body.as_ref().clone()),
                }),
            );
            return Ok(Hir {
                source: None,
                span: form.span.clone(),
                metadata: form.metadata.clone(),
                ty: body.ty,
                kind: std::sync::Arc::new(Expression::Let {
                    bindings: vec![Binding {
                        id,
                        name: name.name.clone(),
                        metadata: args[0].metadata.clone(),
                        span: args[0].span.clone(),
                        value: current,
                    }],
                    body,
                }),
            });
        }
        if symbol.namespace.as_deref() == Some("suss.bootstrap")
            && symbol.name == "direct-protocol-call"
        {
            return self.direct_protocol_call(form, args);
        }
        if symbol.namespace.as_deref() == Some("suss.async") {
            if symbol.name == "future*" {
                let suspendable = std::mem::replace(&mut self.suspendable, true);
                let target = self.target.take();
                let locals = self.locals.clone();
                let body = self.analyzed_body(
                    args,
                    form.span.clone(),
                    super::AnalysisContext::Return,
                    false,
                );
                self.suspendable = suspendable;
                self.target = target;
                self.locals = locals;
                let body = body?;
                let mut captures = BTreeSet::new();
                free_bindings(&body, &BTreeSet::new(), &mut captures);
                *self.source_nodes.last_mut().expect("source node fact slot") = Some(
                    std::sync::Arc::new(SourceNode::Future(std::sync::Arc::new(body.clone()))),
                );
                return Ok(Hir {
                    source: None,
                    span: form.span.clone(),
                    metadata: form.metadata.clone(),
                    ty: Type::Value,
                    kind: std::sync::Arc::new(Expression::Future {
                        captures: captures.into_iter().collect(),
                        body: Box::new(body),
                    }),
                });
            }
            if symbol.name == "await*" {
                if !self.suspendable {
                    return Err(fail(
                        form.span.clone(),
                        "await is legal only inside a future body",
                    ));
                }
                if args.len() != 1 {
                    return Err(fail(
                        form.span.clone(),
                        "await requires exactly one operand",
                    ));
                }
                let value = self.form(&args[0])?;
                *self.source_nodes.last_mut().expect("source node fact slot") = Some(
                    std::sync::Arc::new(SourceNode::Await(std::sync::Arc::new(value.clone()))),
                );
                return Ok(Hir {
                    source: None,
                    span: form.span.clone(),
                    metadata: form.metadata.clone(),
                    ty: Type::Value,
                    kind: std::sync::Arc::new(Expression::Await {
                        value: Box::new(value),
                    }),
                });
            }
        }
        if symbol.namespace.as_deref() == Some("suss.compiler") && symbol.name == "cell-defined?" {
            if args.len() != 1 {
                return Err(fail(
                    form.span.clone(),
                    "Compiler cell-defined? requires one qualified symbol",
                ));
            }
            let Kind::Symbol(target) = &args[0].kind else {
                return Err(fail(
                    args[0].span.clone(),
                    "Compiler cell-defined? requires a qualified symbol, not an evaluated value",
                ));
            };
            let Some(namespace) = target.namespace.as_deref() else {
                return Err(fail(
                    args[0].span.clone(),
                    "Compiler cell-defined? requires an explicit namespace identity",
                ));
            };
            // resolve filters reader/internal reservations. Reject before the
            // fallback can promote a ReaderCell through declare_cell; only an
            // actual source declaration may make that identity public.
            if self
                .environment
                .is_hidden_cell(self.phase, namespace, &target.name)
            {
                return Err(fail(
                    args[0].span.clone(),
                    "Compiler-owned cells are not source publication targets",
                ));
            }
            // Existing aliases/refers resolve through the ordinary phase catalog.
            // A fresh generated type can query a real unbound cell only in the
            // current, already declared namespace; no arbitrary namespace or
            // source declaration facts are fabricated for an existence probe.
            let global = match self
                .environment
                .resolve(self.phase, target, args[0].span.clone())
            {
                Ok(ResolvedBinding::Cell(global)) => global,
                Ok(_) => {
                    return Err(fail(
                        args[0].span.clone(),
                        "Compiler cell-defined? requires a source cell, not a compiler bootstrap binding",
                    ));
                }
                Err(_) if namespace == self.environment.current_namespace(self.phase) => self
                    .environment
                    .declare_cell(self.phase, namespace, &target.name)?,
                Err(error) => return Err(error),
            };
            if self
                .environment
                .is_hidden_cell(self.phase, global.namespace(), global.name())
            {
                return Err(fail(
                    args[0].span.clone(),
                    "Compiler-owned cells are not source publication targets",
                ));
            }
            let cell = Hir {
                source: None,
                span: args[0].span.clone(),
                metadata: Vec::new(),
                ty: Type::Value,
                kind: std::sync::Arc::new(Expression::GlobalCell(global)),
            };
            return Ok(self.nominal(form, Nominal::BindingDefined, vec![cell]));
        }
        if symbol.namespace.as_deref() == Some("suss.bootstrap") {
            if symbol.name=="decimal-context-getter-install" && !self.privileged
                && self.environment.current_namespace(self.phase)!="suss.core" {
                return Err(fail(form.span.clone(),"Math context installation requires compiled core"));
            }
            let long_bits = match symbol.name.as_str() {
                "long-bit-and" => Some(Bitwise::And),
                "long-bit-or" => Some(Bitwise::Or),
                "long-bit-xor" => Some(Bitwise::Xor),
                "long-bit-shift-left" => Some(Bitwise::Left),
                "long-unsigned-bit-shift-right" => Some(Bitwise::Unsigned),
                _ => None,
            };
            if let Some(operation) = long_bits {
                if !self.privileged && self.environment.current_namespace(self.phase) != "suss.core" {
                    return Err(fail(form.span.clone(), "Private long bit adapters require compiled core"));
                }
                return self.selected_bitwise_form(form, args, operation);
            }
            if matches!(symbol.name.as_str(), "long-add" | "long-less" | "chunk-index-add") {
                if !self.privileged && self.environment.current_namespace(self.phase) != "suss.core" {
                    return Err(fail(form.span.clone(), "Private chunk adapters require compiled core"));
                }
                if args.len() != 2 {
                    return Err(fail(form.span.clone(), format!("{} requires two operands", symbol.name)));
                }
                // These core loop counters and offsets are longs. Keep their
                // addition and comparison in the existing checked raw route,
                // rather than core's legacy coercing/boxed operations.
                let mut arguments = Vec::new();
                for argument in args {
                    let value = self.form(argument)?;
                    arguments.push(self.nominal(argument, Nominal::LongCast, vec![value]));
                }
                if symbol.name == "chunk-index-add" && self.privileged {
                    // Only owned chunk loops use this: i starts at zero and
                    // advances while i<size; a compacted output j<=i. Admitted
                    // chunk offsets plus i are bounded by immutable storage.
                    // Ordinary source-core loading keeps checked addition.
                    return Ok(self.nominal(form, Nominal::ChunkIndexAdd, arguments));
                }
                if symbol.name == "long-less" {
                    return Ok(Hir { source: None, span: form.span.clone(),
                        metadata: form.metadata.clone(), ty: Type::Bool,
                        kind: std::sync::Arc::new(Expression::Comparison {
                            operation: Comparison::NumberLess, arguments,
                        }) });
                }
                return Ok(Hir { source: None, span: form.span.clone(),
                    metadata: form.metadata.clone(), ty: Type::Number,
                    kind: std::sync::Arc::new(Expression::Arithmetic {
                        operator: Arithmetic::Add, arguments, coercing: false,
                        primitive_overloads: vec![],
                    }) });
            }
            let operation = match symbol.name.as_str() {
                "apply-sequence-ops!" => Some(Nominal::ApplySequenceOps),
                "list-function" => Some(Nominal::ListFunction),
                "apply-callee" => Some(Nominal::ApplyCallee),
                "apply-spread" => Some(Nominal::ApplySpread),
                "apply-to-seq" => Some(Nominal::ApplyToSeq),
                "apply-fixed" => Some(Nominal::ApplyFixed),
                "number?" => Some(Nominal::IsNumber),
                "ratio?" => Some(Nominal::IsRatio),
                "decimal?" => Some(Nominal::IsDecimal),
                "math-context?" => Some(Nominal::IsMathContext),
                "decimal-from-integer" => Some(Nominal::DecimalNew),
                "as-decimal" => Some(Nominal::DecimalCoerce),
                "math-context-new" => Some(Nominal::DecimalContextNew),
                "decimal-context-getter-install" => Some(Nominal::DecimalContextGetter),
                "bigint?" => Some(Nominal::IsBigInt),
                "biginteger?" => Some(Nominal::IsBigInteger),
                "keyword?" => Some(Nominal::IsKeyword),
                // Reference identity alone, as for interned keywords (#442).
                "same-reference?" => Some(Nominal::SameReference),
                "string?" => Some(Nominal::IsString),
                "boolean?" => Some(Nominal::IsBoolean),
                "undefined?" => Some(Nominal::IsUndefined),
                "value-add" => Some(Nominal::ValueAdd),
                "object-factory" => Some(Nominal::NativeObjectFactory),
                "native-object?" => Some(Nominal::IsNativeObject),
                "fixed-arity-fn?" => Some(Nominal::FixedArityFn),
                "same-nominal-type?" => Some(Nominal::SameNominalType),
                "type-constructor?" => Some(Nominal::IsTypeConstructor),
                "value-constructor" => Some(Nominal::ValueConstructor),
                "type-name" => Some(Nominal::TypeName),
                "display-leaf" => Some(Nominal::DisplayLeaf),
                "function-name" => Some(Nominal::SourceFunctionName),
                "object-default-prototype" => Some(Nominal::NativeObjectDefaultPrototype),
                "coerce-string" => Some(Nominal::CoerceString),
                "object-coerce-string" => Some(Nominal::ObjectCoerceString),
                "concat-string" => Some(Nominal::ConcatString),
                "join-strings" => Some(Nominal::JoinStrings),
                "string-hash" => Some(Nominal::StringHash),
                "vector-nth" => Some(Nominal::VectorNth),
                "object-array-copy-forward" => Some(Nominal::ObjectArrayCopy(false)),
                "object-array-copy-backward" => Some(Nominal::ObjectArrayCopy(true)),
                "map-get" => Some(Nominal::ArrayMapGet),
                "map-contains" => Some(Nominal::MapContains),
                "map-get-or" => Some(Nominal::MapGetOr),
                "map-entry-type!" => Some(Nominal::MapEntryType),
                "hash-map-types!" => Some(Nominal::HashMapTypes),
                "chunk-types!" => Some(Nominal::ChunkTypes),
                "chunk-long-sum" => Some(Nominal::ChunkLongSum),
                "transient-vector-types!" => Some(Nominal::TransientVectorTypes),
                "transient-map-types!" => Some(Nominal::TransientMapTypes),
                "transient-map-assoc" => Some(Nominal::TransientMapAssoc),
                "transient-map-conj" => Some(Nominal::TransientMapConj),
                "transient-vector-append" => Some(Nominal::TransientVectorAppend),
                "chunk-nth" => Some(Nominal::ChunkNth),
                "chunk-append" => Some(Nominal::ChunkAppend),
                "chunk-array" => Some(Nominal::ChunkArray),
                "chunk-offset" => Some(Nominal::ChunkOffset),
                "chunk-seq" => Some(Nominal::ChunkSeq),
                // Core's early definitions precede its public long var.
                "long-cast" => Some(Nominal::LongCast),
                "string-index-of" => Some(Nominal::StringIndexOf),
                "string-slice" => Some(Nominal::StringSlice),
                "string-from-unit" => Some(Nominal::StringFromUnit),
                "error" => Some(Nominal::LanguageError),
                "error?" => Some(Nominal::IsLanguageError),
                "object-get" => Some(Nominal::NativeObjectGet),
                "object-set" => Some(Nominal::NativeObjectSet),
                "object-set-strict" => Some(Nominal::NativeObjectStrictSet),
                _ => None,
            };
            if let Some(operation) = operation {
                let chunk = matches!(operation, Nominal::ChunkLongSum | Nominal::ChunkTypes | Nominal::ChunkNth | Nominal::ChunkAppend
                    | Nominal::ChunkArray | Nominal::ChunkOffset | Nominal::ChunkSeq);
                let ordinary_core = !self.privileged
                    && self.environment.current_namespace(self.phase) == "suss.core";
                let transient_vector = matches!(operation, Nominal::TransientVectorTypes | Nominal::TransientVectorAppend);
                let transient_map = matches!(operation, Nominal::TransientMapTypes | Nominal::TransientMapAssoc | Nominal::TransientMapConj);
                if transient_map && !self.privileged && !ordinary_core {
                    return Err(fail(form.span.clone(), "Private transient map adapters require compiled core"));
                }
                if transient_vector && !self.privileged && !ordinary_core {
                    return Err(fail(form.span.clone(), "Private transient vector adapters require compiled core"));
                }
                if (chunk || operation == Nominal::LongCast) && !self.privileged && !ordinary_core {
                    return Err(fail(form.span.clone(), "Private chunk adapters require compiled core"));
                }
                if matches!(operation, Nominal::ApplySequenceOps | Nominal::ApplyCallee
                    | Nominal::ApplySpread | Nominal::ApplyToSeq | Nominal::ApplyFixed | Nominal::ListFunction)
                    && !self.privileged && self.environment.current_namespace(self.phase) != "suss.core" {
                    return Err(fail(form.span.clone(), "Private apply adapters require compiled core"));
                }
                if !operation.valid(&vec![Type::Value; args.len()]) {
                    return Err(fail(
                        form.span.clone(),
                        "Invalid private native object adapter arity",
                    ));
                }
                let mut operands = args
                    .iter()
                    .map(|argument| self.form(argument))
                    .collect::<Result<Vec<_>, _>>()?;
                if (chunk || transient_vector || transient_map) && ordinary_core {
                    // Direct source loading keeps user-extensible descriptors.
                    // It cannot register them as canonical or access native
                    // storage, even when its namespace is suss.core. Evaluate
                    // operands in order, then take the existing source fallback.
                    let value = if matches!(operation, Nominal::ChunkTypes | Nominal::TransientVectorTypes | Nominal::TransientMapTypes) { Literal::Nil } else { Literal::Undefined };
                    operands.push(self.literal_form(form, value));
                    return Ok(Hir { source: None, span: form.span.clone(),
                        metadata: form.metadata.clone(), ty: Type::Value,
                        kind: std::sync::Arc::new(Expression::Do(operands)) });
                }
                return Ok(self.nominal(form, operation, operands));
            }
        }
        if symbol.namespace.as_deref() == Some("suss.bootstrap") {
            let operation = match symbol.name.as_str() {
                "f64-coerce" => Some(Bitwise::F64Coerce),
                "f64-word0" => Some(Bitwise::F64Word0),
                "f64-word4" => Some(Bitwise::F64Word4),
                "f64-floor" => Some(Bitwise::F64Floor),
                "f64-ceil" => Some(Bitwise::F64Ceil),
                "f64-finite" => Some(Bitwise::F64Finite),
                "f64-safe-integer" => Some(Bitwise::F64SafeInteger),
                "f64-time-clip" => Some(Bitwise::F64TimeClip),
                "random-double" => Some(Bitwise::RandomDouble),
                "evaluate-form" => Some(Bitwise::EvaluateForm),
                "safe-integer-remainder" => Some(Bitwise::SafeIntegerRemainder),
                "f64-remainder" => Some(Bitwise::F64Remainder),
                "identity-uid" => Some(Bitwise::IdentityUid),
                "quot" => Some(Bitwise::Quot),
                "rem" => Some(Bitwise::Rem),
                "abs" => Some(Bitwise::Abs),
                "unchecked-add" => Some(Bitwise::UncheckedAdd),
                "unchecked-subtract" => Some(Bitwise::UncheckedSubtract),
                "unchecked-multiply" => Some(Bitwise::UncheckedMultiply),
                "unchecked-negate" => Some(Bitwise::UncheckedNegate),
                "promote-add" => Some(Bitwise::PromoteAdd),
                "promote-subtract" => Some(Bitwise::PromoteSubtract),
                "promote-multiply" => Some(Bitwise::PromoteMultiply),
                "promote-negate" => Some(Bitwise::PromoteNegate),
                "ratio" => Some(Bitwise::MakeRatio),
                "ratio-numerator" => Some(Bitwise::RatioNumerator),
                "ratio-denominator" => Some(Bitwise::RatioDenominator),
                "ratio-integer" => Some(Bitwise::RatioInteger),
                "as-bigint" => Some(Bitwise::ToBigInt),
                "as-biginteger" => Some(Bitwise::ToBigInteger),
                "max" => Some(Bitwise::Max),
                "min" => Some(Bitwise::Min),
                "long?" => Some(Bitwise::LongTest),
                "double?" => Some(Bitwise::DoubleTest),
                "to-long" => Some(Bitwise::ToLong),
                "range-count" => Some(Bitwise::RangeCount),
                "parse-long" => Some(Bitwise::ParseLong),
                "hash-number" => Some(Bitwise::HashNumber),
                "case-number-hash" => Some(Bitwise::CaseNumberHash),
                "equiv" => Some(Bitwise::Equiv),
                "cast" => Some(Bitwise::Cast),
                "int-value" => Some(Bitwise::IntValue),
                "packed-array" => Some(Bitwise::PackedNew),
                "packed-store" => Some(Bitwise::PackedStore),
                "packed-array?" => Some(Bitwise::PackedTest),
                "object-array?" => Some(Bitwise::ObjectsTest),
                "vector-type!" => Some(Bitwise::VectorType),
                "array-map-type!" => Some(Bitwise::ArrayMapType),
                "vector-count" => Some(Bitwise::VectorCount),
                "packed-copy" => Some(Bitwise::PackedCopy),
                "bit-count" => Some(Bitwise::BitCount),
                _ => None,
            };
            if let Some(operation) = operation {
                return self.bitwise_form(form, args, operation);
            }
        }
        if symbol.namespace.as_deref() == Some("suss.bootstrap")
            && matches!(symbol.name.as_str(), "case-hash<" | "case-hash=" | "case-identical")
        {
            if args.len() != 2 { return Err(fail(form.span.clone(), "Wrong private case comparison arity")); }
            let operation = match symbol.name.as_str() {
                "case-hash<" => Comparison::NumberLess,
                "case-hash=" => Comparison::CaseEqual,
                _ => Comparison::StrictEqual,
            };
            // These compiler-authored comparisons keep their selected operation;
            // source numeric rewriting must not turn keyword identity into =.
            let arguments = args.iter().map(|arg| self.form(arg)).collect::<Result<Vec<_>, _>>()?;
            return Ok(Hir { source: None, span: form.span.clone(), metadata: form.metadata.clone(),
                ty: Type::Bool, kind: std::sync::Arc::new(Expression::Comparison { operation, arguments }) });
        }
        if symbol.namespace.as_deref() == Some("suss.bootstrap")
            && matches!(symbol.name.as_str(), "case-hash-code" | "case-equiv")
        {
            let (name, arity) = if symbol.name == "case-equiv" { ("=", 2) } else { ("case-hash-code", 1) };
            if args.len() != arity {
                return Err(fail(form.span.clone(), "Wrong private case helper arity"));
            }
            // A compiler-authored call to shipped core's fixed definition,
            // never a user-resolvable cell or the live public equality var.
            let binding = self.environment.resolve(self.phase,
                &suss_reader::Symbol::namespaced("suss.core", name), form.span.clone())?;
            let global = self.environment.existing_core_link(binding.global())
                .ok_or_else(|| fail(form.span.clone(), "Private case helper requires shipped core"))?;
            let callee = Hir { source: None, span: form.span.clone(), metadata: vec![], ty: Type::Value,
                kind: std::sync::Arc::new(Expression::Global(global)) };
            let arguments = args.iter().map(|arg| self.form(arg)).collect::<Result<Vec<_>, _>>()?;
            return Ok(Hir { source: None, span: form.span.clone(), metadata: form.metadata.clone(),
                ty: Type::Value, kind: std::sync::Arc::new(Expression::Call { callee: Box::new(callee), arguments }) });
        }
        if symbol.namespace.as_deref() == Some("suss.bootstrap") && symbol.name == "nil?" {
            if args.len() != 1 {
                return Err(fail(
                    form.span.clone(),
                    "Bootstrap nil? requires one operand",
                ));
            }
            return Ok(Hir {
                source: None,
                span: form.span.clone(),
                metadata: form.metadata.clone(),
                ty: Type::Bool,
                kind: std::sync::Arc::new(Expression::NilTest(Box::new(self.form(&args[0])?))),
            });
        }
        if bare && symbol.name.starts_with(".-") {
            if args.len() != 1 || matches!(args[0].kind, Kind::Nil) {
                return Err(fail(
                    form.span.clone(),
                    "Named property read requires one non-literal-nil owner",
                ));
            }
            let key = Self::property_name(form, &symbol.name)?;
            let owner = self.form(&args[0])?;
            let key = self.literal_form(form, Literal::String(key.encode_utf16().collect()));
            return self.callable_named_get(form, owner, key, &symbol.name[2..]);
        }
        if bare && symbol.name.starts_with('.') && !symbol.name.starts_with(".-") {
            let Some(owner) = args.first() else {
                return Err(fail(form.span.clone(), "Method call requires a receiver"));
            };
            let key = Self::object_method_name(form, &symbol.name[1..])?;
            let owner_value = self.form(owner)?;
            let owner_binding = self.fresh_binding(owner, owner_value);
            let owner_read = self.local(owner, owner_binding.id);
            let key = self.literal_form(form, Literal::String(key.encode_utf16().collect()));
            let lookup =
                self.callable_named_get(form, owner_read.clone(), key, &symbol.name[1..])?;
            let method_binding = self.fresh_binding(form, lookup);
            let mut arguments = vec![self.local(form, method_binding.id), owner_read];
            for arg in &args[1..] {
                arguments.push(self.form(arg)?);
            }
            let body = self.nominal(form, Nominal::ObjectInvoke, arguments);
            return Ok(Hir {
                source: None,
                span: form.span.clone(),
                metadata: form.metadata.clone(),
                ty: Type::Value,
                kind: std::sync::Arc::new(Expression::Let {
                    bindings: vec![owner_binding, method_binding],
                    body: Box::new(body),
                }),
            });
        }
        if symbol.name.ends_with('.') && symbol.name.len() > 1 {
            let mut constructor = items[0].clone();
            let Kind::Symbol(name) = &mut constructor.kind else {
                unreachable!()
            };
            name.name.pop();
            // Pinned macroexpand-1 rewrites Foo. to genuine (new Foo ...)
            // syntax before analysis. Keep that source record, not the lowered
            // descriptor call or the original shorthand invocation.
            constructor.metadata.clear();
            let mut parts = vec![
                Form {
                    kind: Kind::Symbol(suss_reader::Symbol::new("new")),
                    span: items[0].span.clone(),
                    metadata: vec![],
                },
                constructor,
            ];
            parts.extend_from_slice(args);
            let mut expanded = form.clone();
            expanded.kind = Kind::List(parts);
            // This fixed rewrite cannot recurse through another trailing dot;
            // preserve the existing source-depth bound like let/loop rewrites.
            return stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || {
                self.expand_or_analyze(&expanded, context, tail, name_hint)
            });
        }
        if bare && symbol.name == "new" {
            if args.is_empty() {
                return Err(fail(form.span.clone(), "new requires a constructor"));
            }
            let arguments = args
                .iter()
                .map(|argument| self.form(argument))
                .collect::<Result<Vec<_>, _>>()?;
            *self.source_nodes.last_mut().expect("source node fact slot") =
                Some(std::sync::Arc::new(SourceNode::Construct {
                    class: std::sync::Arc::new(arguments[0].clone()),
                    arguments: arguments[1..].to_vec().into(),
                }));
            // A keyword is interned: constructing one gives the keyword of
            // that name (#361).
            // Core reads the type through its direct-link cell.
            let keyword = matches!(&*arguments[0].kind, Expression::Global(global)
                if matches!(global.namespace(), "suss.core" | "suss.internal.core-link") && global.name() == "Keyword");
            let mut construction = self.nominal(form, Nominal::Construct, arguments);
            if keyword {
                construction = self.nominal(form, Nominal::KeywordIntern, vec![construction]);
            }
            if self.privileged {
                return Ok(construction);
            }
            return Ok(self.nominal(form, Nominal::BuiltinConstructGuard, vec![construction]));
        }
        if symbol.namespace.as_deref() == Some("suss.bootstrap") && symbol.name == "quote-form" {
            if args.len() != 1 {
                return Err(fail(
                    form.span.clone(),
                    "quote-form requires exactly one operand",
                ));
            }
            return self.quote_form_data(&args[0]);
        }
        if bare && symbol.name == "quote" {
            if args.len() != 1 {
                return Err(fail(
                    form.span.clone(),
                    "quote requires exactly one operand",
                ));
            }
            return self.quote_data(&args[0], 0);
        }
        // Only true special forms bypass lexical and namespace resolution.
        let resolved = if bare
            && matches!(
                symbol.name.as_str(),
                "if" | "do" | "fn*" | "def" | "var" | "let*" | "letfn*" | "loop*" | "recur" | "throw" | "try" | "set!"
            ) {
            None
        } else {
            if bare
                && (self.locals.contains_key(&symbol.name)
                    || self.fields.contains_key(&symbol.name))
            {
                return self.call(form, items);
            }
            Some(
                if let Some(binding) = self.environment.resolve_bootstrap_macro(self.phase, symbol)
                {
                    binding
                } else {
                    self.environment
                        .resolve(self.phase, symbol, items[0].span.clone())?
                },
            )
        };
        if let Some(ResolvedBinding::BootstrapControl { operation, .. }) = &resolved {
            return self.control_form(form, args, *operation, context, tail);
        }
        if (2..=3).contains(&args.len()) && self.linked_core_call(&resolved, "get") {
            let operation = if args.len() == 3 { Nominal::MapGetOr } else { Nominal::ArrayMapGet };
            return self.lookup_call(form, items, operation, args.len(), None);
        }
        // assoc replaces a hash map's value inline (#443); a new key, or
        // anything else, is core's.
        if args.len() == 3 && self.linked_core_call(&resolved, "assoc") {
            return self.lookup_call(form, items, Nominal::MapAssoc, 3, None);
        }
        if args.len() == 2 && self.linked_core_call(&resolved, "contains?") {
            return self.lookup_call(form, items, Nominal::MapContains, 2, None);
        }
        // nth and first read a vector's element inline (#433); its undefined
        // answer, out of range or not a vector, is core's to give.
        // Clojure's nth has :inline metadata: a vector hit ignores root
        // rebinding in sessions too. Admit the shipped core definition, while
        // unknown/user definitions and lexical shadows retain their live call.
        let inline_nth = self.linked_core_call(&resolved, "nth")
            || matches!(&resolved, Some(ResolvedBinding::Cell(global))
                if global.namespace() == "suss.core" && global.name() == "nth"
                    && self.privileged_definition(global));
        if (2..=3).contains(&args.len()) && inline_nth {
            return self.lookup_call(form, items, Nominal::VectorNth, 2, None);
        }
        if args.len() == 1 && self.linked_core_call(&resolved, "first") {
            let zero = Form { span: form.span.clone(), metadata: vec![], kind: Kind::Long(0) };
            return self.lookup_call(form, items, Nominal::VectorNth, 1, Some(zero));
        }
        // `(= :k y)` in direct-linked user code (#360, #361): core's `=`
        // answers `(identical? x y)` when x is a keyword, as Clojure's
        // Keyword equality is identity, so a keyword literal first operand
        // compiles to that test. Only the first: `(= y :k)` asks y.
        if self.environment.direct_linking
            && !self.privileged
            && args.len() == 2
            && matches!(args[0].kind, Kind::Keyword(_) | Kind::AutoKeyword(_))
            && matches!(&resolved, Some(ResolvedBinding::Cell(global))
                if global.namespace() == "suss.core" && global.name() == "=")
        {
            let callee = self.form(&items[0])?;
            let arguments = args.iter().map(|arg| self.form(arg)).collect::<Result<Vec<_>, _>>()?;
            *self.source_nodes.last_mut().expect("source node fact slot") =
                Some(std::sync::Arc::new(SourceNode::Invoke {
                    callee: std::sync::Arc::new(callee),
                    arguments: arguments.clone().into(),
                }));
            return Ok(self.nominal(form, Nominal::SameReference, arguments));
        }
        // JVM core's promoting arithmetic is inline at arity >=2, unary -',
        // and inc'/dec'. Zero/unary +'/ *' remain ordinary function calls.
        // Resolve the actual core cell so lexical/user shadowing stays live.
        let inline_core = |name: &str| self.linked_core_call(&resolved, name)
            || matches!(&resolved, Some(ResolvedBinding::Cell(global))
                if global.namespace() == "suss.core" && global.name() == name && self.privileged_definition(global));
        let promoting = if inline_core("+'") && args.len() >= 2 { Some(Bitwise::PromoteAdd) }
            else if inline_core("*'") && args.len() >= 2 { Some(Bitwise::PromoteMultiply) }
            else if inline_core("-'") && !args.is_empty() {
                Some(if args.len() == 1 { Bitwise::PromoteNegate } else { Bitwise::PromoteSubtract })
            } else if inline_core("inc'") && args.len() == 1 { Some(Bitwise::PromoteAdd) }
            else if inline_core("dec'") && args.len() == 1 { Some(Bitwise::PromoteSubtract) }
            else { None };
        if let Some(operation) = promoting {
            if args.len() > 256 { return Err(fail(form.span.clone(), "Promoting arithmetic expansion limit exceeded")); }
            let callee = self.form(&items[0])?;
            let arguments = args.iter().map(|arg| self.form(arg)).collect::<Result<Vec<_>,_>>()?;
            *self.source_nodes.last_mut().expect("source node fact slot") = Some(std::sync::Arc::new(SourceNode::Invoke {
                callee: std::sync::Arc::new(callee), arguments: arguments.clone().into(),
            }));
            // Clojure's nary-inline nests the operations. A failure in an
            // earlier pair precedes evaluation of later arguments; aliases
            // remain ordinary calls and evaluate all their operands first.
            let mut operands = arguments;
            if args.len() == 1 && operation != Bitwise::PromoteNegate {
                operands.push(self.literal_form(form, Literal::Long(1)));
            }
            let mut values = operands.into_iter();
            let first = values.next().expect("nonempty promoting operation");
            let body = if operation == Bitwise::PromoteNegate {
                Hir { source: None, span: form.span.clone(), metadata: vec![], ty: Type::Number,
                    kind: std::sync::Arc::new(Expression::Bitwise { operation, arguments: vec![first] }) }
            } else {
                values.fold(first, |left, right| Hir { source: None, span: form.span.clone(), metadata: vec![], ty: Type::Number,
                    kind: std::sync::Arc::new(Expression::Bitwise { operation, arguments: vec![left, right] }) })
            };
            return Ok(Hir { source: None, span: form.span.clone(), metadata: form.metadata.clone(), ty: Type::Number,
                kind: body.kind.clone() });
        }
        // `(= x y)` and `(hash x)` on longs in i31 range (#387). Core's `=`
        // answers equiv for two numbers, and two i31 longs are equiv exactly
        // when identical; core's `hash` of a number is `number-hash`, as `=`
        // ignores IEquiv on numbers. So both test their operands inline and
        // call core only for anything else.
        if args.len() == 2 && self.linked_core_call(&resolved, "=") {
            // Two i31s are equal exactly when they're the same reference.
            return self.small_integer_call(form, items, |this, form, locals| this.nominal(form, Nominal::SameReference, locals));
        }
        if (2..=8).contains(&args.len()) && self.linked_core_call(&resolved, "str") {
            return self.str_call(form, items);
        }
        if args.len() == 1 && self.linked_core_call(&resolved, "hash") {
            // Core's `hash` always returns an integer (`hash-combine`'s
            // `bit-xor`s, literals or `number-hash`), so its result is cast
            // to a long and the hash joins raw.
            return self.typed_small_integer_call(
                form,
                items,
                |this, form, locals| this.nominal(form, Nominal::NumberHash, locals),
                Some(Nominal::LongCast),
            );
        }
        // A protocol method call dispatches at its own site (#378), as
        // Clojure's compiler emits a class test and an interface call at each
        // protocol call site rather than relying on the protocol fn's cache.
        if let Some(protocol) = self.protocol_call_site(&resolved, args.len()) {
            return self.protocol_site_call(form, items, &protocol);
        }
        if let Some(ResolvedBinding::BootstrapBitwise { operation, .. }) = &resolved {
            if !self.privileged && matches!(operation, Bitwise::Clear | Bitwise::Flip | Bitwise::Set | Bitwise::Test) {
                let callee = self.form(&items[0])?;
                let arguments = args.iter().map(|arg| self.form(arg)).collect::<Result<Vec<_>, _>>()?;
                *self.source_nodes.last_mut().expect("source node fact slot") =
                    Some(std::sync::Arc::new(SourceNode::Invoke {
                        callee: std::sync::Arc::new(callee.clone()), arguments: arguments.clone().into(),
                    }));
                return Ok(Hir { source: None, span: form.span.clone(), metadata: form.metadata.clone(),
                    ty: Type::Value, kind: std::sync::Arc::new(Expression::Call { callee: Box::new(callee), arguments }) });
            }
            return self.bitwise_form(form, args, *operation);
        }
        if let Some(ResolvedBinding::BootstrapComparison { operation, .. }) = &resolved {
            return self.comparison_form(form, args, *operation);
        }
        if let Some(ResolvedBinding::BootstrapArray { operation, .. }) = &resolved {
            return self.array_form(form, args, *operation);
        }
        if let Some(ResolvedBinding::Nominal {
            form: nominal_form, ..
        }) = &resolved
        {
            return self.nominal_form(form, args, *nominal_form);
        }
        if bare && symbol.name == "set!" {
            if args.len() != 2 {
                return Err(fail(form.span.clone(), "set! requires a var and value"));
            }
            if let Kind::List(target) = &args[0].kind {
                if let Some(Form {
                    kind: Kind::Symbol(name),
                    ..
                }) = target.first()
                {
                    if name.namespace.is_none() && name.name.starts_with(".-") {
                        if target.len() != 2 || matches!(target[1].kind, Kind::Nil) {
                            return Err(fail(
                                args[0].span.clone(),
                                "Named property assignment requires one non-literal-nil owner",
                            ));
                        }
                        let key = Self::property_name(&args[0], &name.name)?;
                        let owner = self.form(&target[1])?;
                        let key = self
                            .literal_form(&args[0], Literal::String(key.encode_utf16().collect()));
                        let value = self.form(&args[1])?;
                        return Ok(self.nominal(form, Nominal::NamedSet, vec![owner, key, value]));
                    }
                }
            }
            if let Kind::Symbol(name) = &args[0].kind {
                if name.namespace.is_none() && !self.locals.contains_key(&name.name) {
                    if let Some(mut field) = self.fields.get(&name.name).cloned() {
                        if !field.mutable {
                            return Err(fail(
                                args[0].span.clone(),
                                "Cannot assign a local or immutable field",
                            ));
                        }
                        let Expression::Nominal {
                            operation,
                            mut arguments,
                        } = field.access.take_kind()
                        else {
                            unreachable!()
                        };
                        arguments.push(self.form(&args[1])?);
                        let setter = match operation {
                            Nominal::Field(index) => Nominal::FieldSet(index),
                            Nominal::NamedGet => Nominal::NamedSet,
                            Nominal::CoreNamedGet => Nominal::CoreNamedSet,
                            _ => unreachable!(),
                        };
                        return Ok(self.nominal(form, setter, arguments));
                    }
                }
            }
            let global = self.assignment_target(&args[0])?;
            let target = self.form(&args[0])?;
            let value = self.form(&args[1])?;
            *self.source_nodes.last_mut().expect("source node fact slot") =
                Some(std::sync::Arc::new(SourceNode::Assign {
                    target: std::sync::Arc::new(target),
                    value: std::sync::Arc::new(value.clone()),
                }));
            let linked = self.core_reference_link(&global);
            // `set!` of a direct-linked var writes its slot too (#360).
            let value = match self.environment.direct_slot(&global)
                .filter(|_| self.environment.direct_linking && !self.privileged && global.namespace() != "suss.core")
            {
                Some(slot) => {
                    let binding = self.fresh_binding(form, value);
                    let write = self.nominal(form, Nominal::DirectLinkSet(slot), vec![self.local(form, binding.id)]);
                    let result = self.local(form, binding.id);
                    let body = self.do_hir(form, vec![write, result]);
                    Hir {
                        source: None,
                        span: form.span.clone(),
                        metadata: vec![],
                        ty: Type::Value,
                        kind: std::sync::Arc::new(Expression::Let { bindings: vec![binding], body: Box::new(body) }),
                    }
                }
                None => value,
            };
            return Ok(Hir {
                source: None,
                span: form.span.clone(),
                metadata: form.metadata.clone(),
                ty: Type::Value,
                kind: std::sync::Arc::new(Expression::Assign {
                    global,
                    value: Box::new(value),
                    linked,
                }),
            });
        }
        if matches!(resolved, Some(ResolvedBinding::BootstrapBinding(_))) {
            return self.dynamic_scope(form, args, context);
        }
        if bare && symbol.name == "throw" {
            if args.len() != 1 {
                return Err(fail(
                    form.span.clone(),
                    "throw requires exactly one operand",
                ));
            }
            let exception = self.form(&args[0])?;
            *self.source_nodes.last_mut().expect("source node fact slot") = Some(
                std::sync::Arc::new(SourceNode::Throw(std::sync::Arc::new(exception.clone()))),
            );
            return Ok(Hir {
                source: None,
                span: form.span.clone(),
                metadata: form.metadata.clone(),
                ty: Type::Value,
                kind: std::sync::Arc::new(Expression::Throw(Box::new(exception))),
            });
        }
        if bare && symbol.name == "try" {
            return self.try_form(form, args, context);
        }
        if bare && symbol.name == "recur" {
            let Some((target, arity)) = self.target else {
                return Err(fail(
                    form.span.clone(),
                    "recur requires an enclosing loop or function",
                ));
            };
            if !tail {
                return Err(fail(form.span.clone(), "recur must be in tail position"));
            }
            if args.len() != arity {
                return Err(fail(
                    form.span.clone(),
                    format!(
                        "recur arity mismatch: expected {arity}, received {}",
                        args.len()
                    ),
                ));
            }
            let arguments = args
                .iter()
                .map(|arg| self.form(arg))
                .collect::<Result<Vec<_>, _>>()?;
            if let Some((_, recurred)) = self
                .method_recurrence
                .iter_mut()
                .rev()
                .find(|(id, _)| *id == target)
            {
                *recurred = true;
            }
            *self.source_nodes.last_mut().expect("source node fact slot") = Some(
                std::sync::Arc::new(SourceNode::Recur(arguments.clone().into())),
            );
            return Ok(Hir {
                source: None,
                span: form.span.clone(),
                metadata: form.metadata.clone(),
                ty: Type::Value,
                kind: std::sync::Arc::new(Expression::Recur { target, arguments }),
            });
        }
        if bare && symbol.name == "var" {
            if args.len() != 1 { return Err(fail(form.span.clone(), "var requires exactly one symbol")); }
            let Kind::Symbol(target) = &args[0].kind else { return Err(fail(args[0].span.clone(), "var requires a symbol")); };
            let binding = self.environment.resolve(self.phase, target, args[0].span.clone())?;
            let global = binding.global().clone();
            return self.binding_var(form, &global, false);
        }
        if bare && symbol.name == "def" {
            if args.len() == 1 && context != super::AnalysisContext::Statement
                && self.environment.resolve(self.phase, &suss_reader::Symbol::namespaced("suss.core", "make-binding-var"), form.span.clone()).is_err() {
                return Err(fail(
                    form.span.clone(),
                    "Initializerless def expression results are not certified yet; use a declaration statement",
                ));
            }
            return self.definition(form, args, false);
        }
        if matches!(resolved, Some(ResolvedBinding::BootstrapDefonce(_))) {
            return self.definition(form, args, true);
        }
        if (bare && symbol.name == "fn*")
            || matches!(resolved, Some(ResolvedBinding::BootstrapFn(_)))
        {
            let value = self.function(
                form,
                args,
                matches!(resolved, Some(ResolvedBinding::BootstrapFn(_))),
                name_hint,
            )?;
            return self.attach_function_metadata(form, value);
        }
        let (kind, ty) = match (bare, symbol.name.as_str()) {
            (true, "letfn*") => return self.recursive_functions(form, args, context, tail),
            (true, "do") => {
                let mut body = self.body(args, form.span.clone(), context, tail)?;
                let Expression::Do(children) = &*body.kind else {
                    unreachable!()
                };
                let (statements, result) = if let Some((result, statements)) = children.split_last()
                {
                    (statements.to_vec(), result.clone())
                } else {
                    let nil = Form {
                        kind: Kind::Nil,
                        span: form.span.clone(),
                        metadata: vec![],
                    };
                    (vec![], self.form_in(&nil, context, tail)?)
                };
                *self.source_nodes.last_mut().expect("source node fact slot") =
                    Some(std::sync::Arc::new(SourceNode::Do {
                        statements: statements.into(),
                        result: std::sync::Arc::new(result),
                    }));
                (body.take_kind(), body.ty)
            }
            (true, "if") => {
                if !(2..=3).contains(&args.len()) {
                    return Err(fail(form.span.clone(), "if requires two or three operands"));
                }
                let condition = Box::new(self.form(&args[0])?);
                let consequent = Box::new(self.form_in(&args[1], context, tail)?);
                let alternative = Box::new(if args.len() == 3 {
                    self.form_in(&args[2], context, tail)?
                } else {
                    let nil = Form {
                        kind: Kind::Nil,
                        span: form.span.clone(),
                        metadata: vec![],
                    };
                    self.form_in(&nil, context, tail)?
                });
                let ty = if consequent.ty == alternative.ty {
                    consequent.ty
                } else {
                    Type::Value
                };
                *self.source_nodes.last_mut().expect("source node fact slot") =
                    Some(std::sync::Arc::new(SourceNode::If {
                        condition: std::sync::Arc::new(condition.as_ref().clone()),
                        consequent: std::sync::Arc::new(consequent.as_ref().clone()),
                        alternative: std::sync::Arc::new(alternative.as_ref().clone()),
                    }));
                (
                    Expression::If {
                        condition,
                        consequent,
                        alternative,
                    },
                    ty,
                )
            }
            _ if bare && matches!(symbol.name.as_str(), "let*" | "loop*") => {
                let is_loop = symbol.name == "loop*";
                if args.is_empty() {
                    return Err(fail(form.span.clone(), "let requires a binding vector"));
                }
                let Kind::Vector(entries) = &args[0].kind else {
                    return Err(fail(args[0].span.clone(), "let bindings must be a vector"));
                };
                if entries.len() % 2 != 0 {
                    return Err(fail(args[0].span.clone(), "let binding has no initializer"));
                }
                let outer = self.locals.clone();
                let mut bindings = Vec::new();
                let mut source_bindings = Vec::new();
                for pair in entries.chunks_exact(2) {
                    let Kind::Symbol(name) = &pair[0].kind else {
                        return Err(fail(
                            pair[0].span.clone(),
                            "Binding destructuring is not lowered yet",
                        ));
                    };
                    if name.namespace.is_some() || name.name == "&" {
                        return Err(fail(
                            pair[0].span.clone(),
                            "Binding name must be unqualified",
                        ));
                    }
                    // Only the pending compiler-generated catch alias may share
                    // its physical payload ID. Consume the original declaration
                    // before entering the body; ordinary nested lets stay distinct.
                    let alias = if !is_loop {
                        self.catch_aliases
                            .iter()
                            .position(|(declaration, hidden)| {
                                declaration == &pair[0] && pair[1].kind == hidden.declaration.kind
                            })
                            .map(|index| self.catch_aliases.remove(index).1)
                    } else {
                        None
                    };
                    let value = self.form(&pair[1])?;
                    let id = if let Some(hidden) = &alias {
                        hidden.id
                    } else {
                        let id = BindingId(self.next);
                        self.next += 1;
                        id
                    };
                    self.insert_local(
                        &pair[0],
                        id,
                        if is_loop { Type::Value } else { value.ty },
                        if alias.is_some() {
                            LocalKind::Catch
                        } else if is_loop {
                            LocalKind::Loop
                        } else {
                            LocalKind::Let
                        },
                        Some(value.clone()),
                    );
                    if let Some(hidden) = &alias {
                        std::sync::Arc::make_mut(&mut self.locals)
                            .get_mut(&name.name)
                            .expect("catch alias")
                            .source_role = SourceRole::CatchBinding {
                            hidden: hidden.clone(),
                            access: self.local(&pair[1], hidden.id),
                        };
                    }
                    source_bindings.push(self.locals[&name.name].clone());
                    if alias.is_none() {
                        bindings.push(Binding {
                            id,
                            name: name.name.clone(),
                            metadata: pair[0].metadata.clone(),
                            span: pair[0].span.clone(),
                            value,
                        });
                    }
                }
                let target = LoopId(self.next_loop);
                let outer_target = self.target;
                if is_loop {
                    self.next_loop += 1;
                    self.target = Some((target, bindings.len()));
                }
                // Pinned analyze-let-body explicitly analyzes a synthetic do
                // in this lexical scope. This is its genuine source analysis,
                // not a body reconstructed from the physical Do expression.
                let body = Box::new(self.analyzed_body(
                    &args[1..],
                    form.span.clone(),
                    context.returning(),
                    is_loop || tail,
                )?);
                *self.source_nodes.last_mut().expect("source node fact slot") =
                    Some(std::sync::Arc::new(SourceNode::Bindings {
                        is_loop,
                        is_letfn: false,
                        bindings: source_bindings.into(),
                        body: std::sync::Arc::new(body.as_ref().clone()),
                    }));
                self.target = outer_target;
                self.locals = outer;
                let ty = body.ty;
                (
                    if is_loop {
                        Expression::Loop {
                            target,
                            bindings,
                            body,
                        }
                    } else {
                        Expression::Let { bindings, body }
                    },
                    ty,
                )
            }
            _ => {
                // `reduced?` compiles inline, as its Clojure :inline definition
                // does (#457): an `instance?` site on core's Reduced, so a
                // reduction step tests its result without a call. Another
                // arity stays a call, which raises the arity error.
                let core_var = match &resolved {
                    Some(ResolvedBinding::Cell(global)) if args.len() == 1 => {
                        let var = global.core_var_of_link().unwrap_or_else(|| global.clone());
                        (var.namespace() == "suss.core").then(|| var.name().to_string())
                    }
                    _ => None,
                };
                // So do core's numeric coercions, which are :inline in Clojure
                // too (#448): a raw long or double, with the checks of each
                // one's cast.
                let cast = match core_var.as_deref() {
                    Some("long") => Some(Nominal::LongCast),
                    Some("double" | "unchecked-double") => Some(Nominal::DoubleCast),
                    Some("unchecked-long") => Some(Nominal::UncheckedLongCast),
                    _ => None,
                };
                if core_var.as_deref() == Some("char") {
                    let argument = self.form(&args[0])?;
                    let selector = self.literal_form(form, Literal::Long(16));
                    let unit = Hir { source: None, span: form.span.clone(), metadata: Vec::new(),
                        ty: Bitwise::Cast.result(), kind: std::sync::Arc::new(Expression::Bitwise {
                            operation: Bitwise::Cast, arguments: vec![argument, selector],
                        }) };
                    return Ok(self.nominal(form, Nominal::StringFromUnit, vec![unit]));
                }
                if let Some(cast) = cast {
                    let argument = self.form(&args[0])?;
                    return Ok(self.nominal(form, cast, vec![argument]));
                }
                if core_var.as_deref() == Some("reduced?") {
                    let reduced = Form {
                        kind: Kind::Symbol(suss_reader::Symbol {
                            namespace: Some("suss.core".into()),
                            name: "Reduced".into(),
                        }),
                        span: items[0].span.clone(),
                        metadata: vec![],
                    };
                    let arguments = vec![self.form(&reduced)?, self.form(&args[0])?];
                    return Ok(self.nominal(form, Nominal::Instance, arguments));
                }
                if let Some(ResolvedBinding::Core { export, .. }) = &resolved {
                    // `nil?` and `identical?` compile inline (#356), as their
                    // Clojure :inline definitions do, so a call compiled before
                    // a redefinition of the var keeps the core test. Clojure
                    // inlines no other predicate; `true?`, `number?` and the
                    // like stay live calls. Another arity stays a call, which
                    // raises the arity error.
                    // The shipped core image is direct-linked (#360), so its own
                    // calls of `number?` and `string?` take the core test
                    // inline too, as a static call would (#361).
                    let core_image = self.privileged && self.environment.core_image_links;
                    let predicate = match (*export, args.len()) {
                        ("predicate-nil", 1) => Some(None),
                        ("predicate-identical", 2) => Some(Some(Nominal::Identical)),
                        ("predicate-number", 1) if core_image => Some(Some(Nominal::IsNumber)),
                        ("predicate-string", 1) if core_image => Some(Some(Nominal::IsString)),
                        _ => None,
                    };
                    // aclone is :inline in Clojure, so one array's copy is
                    // the runtime's directly, not a call of its closure (#443).
                    if *export == "array-clone-function" && args.len() == 1 {
                        return Ok(Hir {
                            source: None,
                            span: form.span.clone(),
                            metadata: form.metadata.clone(),
                            ty: Type::Value,
                            kind: std::sync::Arc::new(Expression::Array {
                                operation: ArrayOperation::Clone,
                                arguments: vec![self.form(&args[0])?],
                            }),
                        });
                    }
                    if let Some(predicate) = predicate {
                        let callee = self.form(&items[0])?;
                        let arguments = args
                            .iter()
                            .map(|arg| self.form(arg))
                            .collect::<Result<Vec<_>, _>>()?;
                        *self.source_nodes.last_mut().expect("source node fact slot") =
                            Some(std::sync::Arc::new(SourceNode::Invoke {
                                callee: std::sync::Arc::new(callee),
                                arguments: arguments.clone().into(),
                            }));
                        return Ok(match predicate {
                            Some(operation) => self.nominal(form, operation, arguments),
                            None => Hir {
                                source: None,
                                span: form.span.clone(),
                                metadata: form.metadata.clone(),
                                ty: Type::Bool,
                                kind: std::sync::Arc::new(Expression::NilTest(Box::new(
                                    arguments.into_iter().next().expect("one operand"),
                                ))),
                            },
                        });
                    }
                }
                let Some(ResolvedBinding::Arithmetic { operator, .. }) = resolved else {
                    return self.call(form, items);
                };
                if args.is_empty() && matches!(operator, Arithmetic::Subtract | Arithmetic::Divide)
                {
                    // No inline method exists for this arity. Keep a call,
                    // whose shared arity-error entry runs when invoked, as
                    // in Clojure (including inside a primitive-return fn).
                    return self.call(form, items);
                }
                let callee = self.form(&items[0])?;
                let arguments = args
                    .iter()
                    .map(|arg| self.form(arg))
                    .collect::<Result<Vec<_>, _>>()?;
                *self.source_nodes.last_mut().expect("source node fact slot") =
                    Some(std::sync::Arc::new(SourceNode::Invoke {
                        callee: std::sync::Arc::new(callee),
                        arguments: arguments.clone().into(),
                    }));
                let types = arguments.iter().map(|arg| arg.ty).collect::<Vec<_>>();
                let ty = arithmetic_type(operator, &types, self.coercing_operands()).ok_or_else(|| {
                    let operand = arguments
                        .iter()
                        .find(|arg| matches!(arg.ty, Type::Closure(_)))
                        .unwrap();
                    fail(
                        operand.span.clone(),
                        "Arithmetic object coercions are not lowered yet",
                    )
                })?;
                (
                    Expression::Arithmetic {
                        operator,
                        arguments,
                        coercing: self.coercing_operands(),
                        primitive_overloads: vec![],
                    },
                    ty,
                )
            }
        };
        Ok(Hir {
            source: None,
            span: form.span.clone(),
            metadata: form.metadata.clone(),
            ty,
            kind: std::sync::Arc::new(kind),
        })
    }
}
fn free_bindings(hir: &Hir, bound: &BTreeSet<BindingId>, free: &mut BTreeSet<BindingId>) {
    match &*hir.kind {
        Expression::Assign { value, .. } => free_bindings(value, bound, free),
        Expression::DynamicScope { bindings, body }
        | Expression::AsyncDynamicScope { bindings, body } => {
            for (_, value) in bindings {
                free_bindings(value, bound, free);
            }
            free_bindings(body, bound, free);
        }
        Expression::Throw(value) | Expression::NilTest(value) | Expression::Await { value } => {
            free_bindings(value, bound, free)
        }
        Expression::AsyncTry {
            body,
            handler,
            cleanup,
            payload,
        } => {
            free_bindings(body, bound, free);
            if let Some(handler) = handler {
                let mut bound = bound.clone();
                if let Some(payload) = payload {
                    bound.insert(payload.id);
                }
                free_bindings(handler, &bound, free);
            }
            if let Some(cleanup) = cleanup {
                free_bindings(cleanup, bound, free);
            }
        }
        Expression::Try { regions } => {
            for region in regions {
                free_bindings(region, bound, free);
            }
        }
        Expression::Definition {
            initializer: Some(value),
            ..
        } => free_bindings(value, bound, free),
        Expression::Local(id) => {
            if !bound.contains(id) {
                free.insert(*id);
            }
        }
        Expression::Function { captures, .. }
        | Expression::GeneralFunction { captures, .. }
        | Expression::Future { captures, .. } => {
            for id in captures {
                if !bound.contains(id) {
                    free.insert(*id);
                }
            }
        }
        Expression::LetFn { bindings, body } => {
            let mut bound = bound.clone();
            bound.extend(bindings.iter().map(|binding| binding.id));
            for binding in bindings { free_bindings(&binding.value, &bound, free); }
            free_bindings(body, &bound, free);
        }
        Expression::Let { bindings, body } | Expression::Loop { bindings, body, .. } => {
            let mut bound = bound.clone();
            for binding in bindings {
                free_bindings(&binding.value, &bound, free);
                bound.insert(binding.id);
            }
            free_bindings(body, &bound, free);
        }
        Expression::If {
            condition,
            consequent,
            alternative,
        } => {
            for item in [condition, consequent, alternative] {
                free_bindings(item, bound, free);
            }
        }
        Expression::Recur {
            arguments: items, ..
        }
        | Expression::Do(items)
        | Expression::Arithmetic {
            arguments: items, ..
        }
        | Expression::Bitwise {
            arguments: items, ..
        }
        | Expression::Comparison {
            arguments: items, ..
        }
        | Expression::Array {
            arguments: items, ..
        }
        | Expression::Nominal {
            arguments: items, ..
        } => {
            for item in items {
                free_bindings(item, bound, free);
            }
        }
        Expression::Call { callee, arguments } => {
            free_bindings(callee, bound, free);
            for arg in arguments {
                free_bindings(arg, bound, free);
            }
        }
        _ => {}
    }
}
/// Analyze selected forms using an explicit phase-specific namespace environment.
/// The var a REPL displays for an input whose value is a `def`'s, as Clojure's
/// `def` returns its var (#288).
#[derive(Debug, Clone)]
pub struct ResultDefinition {
    pub global: Global,
    /// The `def` is a `defonce`, or one branch of an `if` whose other branch
    /// is nil, as in `defmulti`'s expansion, so a nil value means it did not
    /// run.
    pub conditional: bool,
}
/// Find it through `do`, `let` and `binding` bodies, such as the scope each
/// input runs in.
pub(crate) fn result_definition(hir: &Hir) -> Option<ResultDefinition> {
    match &*hir.kind {
        // A repeated defonce returns nil without defining, as Clojure's does.
        Expression::Definition { global, once, .. } => Some(ResultDefinition {
            global: global.clone(),
            conditional: *once,
        }),
        Expression::Do(items) => items.last().and_then(result_definition),
        Expression::Let { body, .. } => result_definition(body),
        // A `binding` body is a thunk the scope calls.
        Expression::DynamicScope { body, .. } => match &*body.kind {
            Expression::Function { parameters, body, .. } if parameters.is_empty() => {
                result_definition(body)
            }
            _ => result_definition(body),
        },
        Expression::If {
            consequent,
            alternative,
            ..
        } => {
            let nil = |hir: &Hir| matches!(&*hir.kind, Expression::Literal(Literal::Nil));
            let branch = if nil(alternative) {
                consequent
            } else if nil(consequent) {
                alternative
            } else {
                return None;
            };
            result_definition(branch).map(|definition| ResultDefinition {
                conditional: true,
                ..definition
            })
        }
        _ => None,
    }
}
pub fn analyze(forms: &[Form], span: Range<usize>) -> Result<Hir, Diagnostic> {
    analyze_in(forms, span, &Environment::default(), Phase::Runtime)
}
pub fn analyze_in(
    forms: &[Form],
    span: Range<usize>,
    environment: &Environment,
    phase: Phase,
) -> Result<Hir, Diagnostic> {
    Ok(prepare(forms, span, environment, phase)?.0)
}
/// Analyze with a private environment snapshot; failure cannot mutate caller state.
pub(crate) fn prepare(
    forms: &[Form],
    span: Range<usize>,
    environment: &Environment,
    phase: Phase,
) -> Result<(Hir, Environment), Diagnostic> {
    prepare_with_expander(forms, span, environment, phase, &mut super::NoExpansion)
}
pub(crate) fn prepare_with_expander(
    forms: &[Form],
    span: Range<usize>,
    environment: &Environment,
    phase: Phase,
    expander: &mut dyn super::ExpansionHost,
) -> Result<(Hir, Environment), Diagnostic> {
    prepare_with_origin(forms, span, environment, environment, phase, expander, None)
}
pub(crate) fn prepare_with_origin(
    forms: &[Form],
    span: Range<usize>,
    before: &Environment,
    environment: &Environment,
    phase: Phase,
    expander: &mut dyn super::ExpansionHost,
    origin: Option<&super::SourceOrigin>,
) -> Result<(Hir, Environment), Diagnostic> {
    let mut analyzer = Analyzer {
        suspendable: false,
        pending_param_hints: None,
        pending_return_hint: None,
        privileged: origin.is_some_and(|origin| origin.is_privileged()),
        expander,
        origin: origin.cloned(),
        environment: environment.clone(),
        phase,
        locals: Default::default(),
        fields: Default::default(),
        type_body_fields: Vec::new(),
        field_owner: None,
        function_scopes: Vec::new().into(),
        next: 0,
        next_loop: 0,
        analysis_depth: 0,
        analysis_contexts: Vec::new(),
        source_namespace: None,
        fragment_links: BTreeSet::new(),
        namespace_snapshot: None,
        constant_definitions: Default::default(),
        source_callables: Vec::new(),
        source_nodes: Vec::new(),
        callable_keys: BTreeMap::new(),
        pattern_sites: Vec::new(),
        catch_aliases: Vec::new(),
        target: None,
        method_recurrence: Vec::new(),
        primitive_methods: HashMap::new(),
    };
    // The frame's own forms take the fragment's extent, not the source's, so
    // a fragment's IR and cache key do not change with the rest of its file.
    let extent = match (forms.first(), forms.last()) {
        (Some(first), Some(last)) => first.span.start..last.span.end,
        _ => span.clone(),
    };
    let mut hir = analyzer.body(forms, span, super::AnalysisContext::Statement, false)?;
    let source_span = hir.span.clone();
    division_overloads::annotate(&mut hir, &analyzer.primitive_methods,
        &mut |work| analyzer.expander.charge_expansion_work(work, source_span.clone()))?;
    if let Expression::Do(items) = &*hir.kind {
        super::analysis_record::analyzed_forms(origin, items);
    }
    let mut hir = analyzer.namespace_frame(before, extent, hir)?;
    if !analyzer.callable_keys.is_empty() {
        let mut initializers = analyzer.callable_keys.into_values().collect::<Vec<_>>();
        let ty = hir.ty;
        let span = hir.span.clone();
        let metadata = hir.metadata.clone();
        initializers.push(hir);
        hir = Hir {
            source: None,
            span,
            metadata,
            ty,
            kind: std::sync::Arc::new(Expression::Do(initializers)),
        };
    }
    Ok((hir, analyzer.environment))
}

/// A function expression with no captures, as a top-level `fn` is, also
/// inside the callable-signature wrapper: a direct-linkable definition (#360).
fn capture_free_function(hir: &Hir) -> bool {
    capture_free_result(hir, &[])
}
/// Whether `hir`'s value is a capture-free fn, made there or bound by one of
/// the enclosing lets in `scope`, as a named or multi-arity fn's lowering
/// answers one of its bindings. A fn that captures a binding (#460), as in
/// `(let [g (fn …)] (fn [x] (g x)))`, isn't one: callers' links can't call it.
fn capture_free_result<'a>(hir: &'a Hir, scope: &[&'a Binding]) -> bool {
    match &*hir.kind {
        Expression::Function { captures, .. } | Expression::GeneralFunction { captures, .. } => captures.is_empty(),
        Expression::Local(id) => scope.iter().rev().find(|binding| binding.id == *id)
            .is_some_and(|binding| capture_free_result(&binding.value, &[])),
        Expression::Do(items) => items.last().is_some_and(|last| capture_free_result(last, scope)),
        Expression::Let { bindings, body } => {
            let mut inner = scope.to_vec();
            inner.extend(bindings.iter());
            capture_free_result(body, &inner)
        }
        _ => false,
    }
}
/// A `fn` form: `fn`, `fn*` or core's `fn`, before analysis (#360).
fn fn_form(form: &Form) -> bool {
    let Kind::List(items) = &form.kind else { return false };
    matches!(items.first().map(|item| &item.kind), Some(Kind::Symbol(symbol))
        if matches!(symbol.name.as_str(), "fn" | "fn*")
            && symbol.namespace.as_deref().is_none_or(|namespace| matches!(namespace, "suss.core" | "cljs.core" | "clojure.core")))
}
/// A direct link's var slot and definition, packed into one operand (#360).
pub(crate) fn link_pair(slot: usize, definition: usize) -> usize {
    (slot << 32) | definition
}
pub(crate) fn link_parts(link: usize) -> (usize, usize) {
    (link >> 32, link & 0xffff_ffff)
}

/// The cast a parameter's `^long` or `^double` tag asks for (#385).
fn primitive_hint(parameter: &Parameter) -> Result<Option<Nominal>, Diagnostic> {
    primitive_tag(&Form { span: parameter.span.clone(), metadata: parameter.metadata.clone(), kind: Kind::Nil })
}
fn primitive_tag(carrier: &Form) -> Result<Option<Nominal>, Diagnostic> {
    primitive_tag_key(carrier, "tag")
}
fn primitive_tag_key(carrier: &Form, metadata_key: &str) -> Result<Option<Nominal>, Diagnostic> {
    if carrier.metadata.is_empty() {
        return Ok(None);
    }
    let pairs = quotes::reader_metadata_pairs(carrier)?;
    for index in (0..pairs.len()).step_by(2) {
        if matches!(&pairs[index].kind, Kind::Keyword(key) if key.namespace.is_none() && key.name == metadata_key) {
            if let Kind::Symbol(tag) = &pairs[index + 1].kind {
                if tag.namespace.is_none() {
                    return Ok(match tag.name.as_str() {
                        "long" => Some(Nominal::LongCast),
                        "double" => Some(Nominal::DoubleCast),
                        _ => None,
                    });
                }
            }
        }
    }
    Ok(None)
}
