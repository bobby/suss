//! Original portable primitive predicate intrinsics; no upstream code is copied.
use super::*;

fn argument(body: &mut Vec<Instruction<'static>>, index: i32) {
    body.extend([
        Instruction::LocalGet(1),
        Instruction::I32Const(index),
        Instruction::ArrayGet(ARGS),
    ]);
}
fn sentinel(body: &mut Vec<Instruction<'static>>, value: i32) {
    body.extend([sentinel_value(value)]);
}
fn boolean(body: &mut Vec<Instruction<'static>>) {
    // A comparison produces 0/1; language booleans are sentinel globals.
    body.extend(super::boolean());
}
fn callback(b: &mut Builder, locals: &[(u32, ValType)], body: &[Instruction<'static>]) -> u32 {
    let index = b.count;
    b.functions.function(INVOKE);
    let mut code = Function::new(locals.iter().copied());
    for instruction in body {
        code.instruction(instruction);
    }
    code.instruction(&Instruction::End);
    b.code.function(&code);
    b.count += 1;
    index
}
fn factory(
    b: &mut Builder,
    name: &str,
    arity: i32,
    locals: &[(u32, ValType)],
    body: &[Instruction<'static>],
) -> u32 {
    use Instruction::*;
    let function = callback(b, locals, body);
    b.function(
        name,
        &[],
        &[VALUE],
        &[
            sentinel_value(NIL),
            RefFunc(function),
            I32Const(arity),
            I32Const(arity),
            Call(b.names["closure-new"]),
        ],
    );
    function
}

pub(super) fn functions(b: &mut Builder) -> Vec<u32> {
    use Instruction::*;
    let mut declared = Vec::new();
    for (name, value) in [
        ("predicate-false", FALSE),
        ("predicate-true", TRUE),
        ("predicate-undefined", UNDEFINED),
    ] {
        let mut body = vec![];
        argument(&mut body, 0);
        sentinel(&mut body, value);
        body.push(RefEq);
        boolean(&mut body);
        declared.push(factory(b, name, 1, &[], &body));
    }
    let mut body = vec![];
    argument(&mut body, 0);
    sentinel(&mut body, NIL);
    body.push(RefEq);
    argument(&mut body, 0);
    sentinel(&mut body, UNDEFINED);
    body.extend([RefEq, I32Or]);
    boolean(&mut body);
    declared.push(factory(b, "predicate-nil", 1, &[], &body));
    let mut body = vec![];
    argument(&mut body, 0);
    body.push(Call(b.names["number-test"]));
    boolean(&mut body);
    declared.push(factory(b, "predicate-number", 1, &[], &body));
    for (name, ty) in [
        ("predicate-string", STRING),
        ("predicate-function", 4),
    ] {
        let mut body = vec![];
        argument(&mut body, 0);
        body.push(RefTestNonNull(HeapType::Concrete(ty)));
        boolean(&mut body);
        declared.push(factory(b, name, 1, &[], &body));
    }

    // Scalar integral/UTF-16 identity follows their platform representation.
    // Floating Objects retain their actual references; source primitive boxing
    // is selected before IR, rather than inferred from raw storage here.
    let mut body = vec![LocalGet(0), LocalSet(2), LocalGet(1), LocalSet(3)];
    // Canonical long identity remains value based; a long is never a double.
    let long_test = b.names["long-test"];
    let long_unbox = b.names["long-unbox"];
    body.extend([
        LocalGet(2),
        Call(long_test),
        LocalGet(3),
        Call(long_test),
        I32And,
        If(BlockType::Empty),
        LocalGet(2),
        Call(long_unbox),
        LocalGet(3),
        Call(long_unbox),
        I64Eq,
    ]);
    boolean(&mut body);
    body.extend([
        Return,
        End,
        LocalGet(2),
        RefTestNonNull(HeapType::Concrete(NUMBER)),
        LocalGet(3),
        RefTestNonNull(HeapType::Concrete(NUMBER)),
        I32And,
        If(BlockType::Empty),
        LocalGet(2),
        LocalGet(3),
        RefEq,
    ]);
    boolean(&mut body);
    body.extend([
        Return,
        End,
        LocalGet(2),
        RefTestNonNull(HeapType::Concrete(STRING)),
        LocalGet(3),
        RefTestNonNull(HeapType::Concrete(STRING)),
        I32And,
        If(BlockType::Empty),
        LocalGet(2),
        RefCastNonNull(HeapType::Concrete(STRING)),
        ArrayLen,
        LocalGet(3),
        RefCastNonNull(HeapType::Concrete(STRING)),
        ArrayLen,
        I32Ne,
        If(BlockType::Empty),
        sentinel_value(FALSE),
        Return,
        End,
        I32Const(0),
        LocalSet(4),
        Block(BlockType::Empty),
        Loop(BlockType::Empty),
        LocalGet(4),
        LocalGet(2),
        RefCastNonNull(HeapType::Concrete(STRING)),
        ArrayLen,
        I32GeU,
        BrIf(1),
        LocalGet(2),
        RefCastNonNull(HeapType::Concrete(STRING)),
        LocalGet(4),
        ArrayGetU(STRING),
        LocalGet(3),
        RefCastNonNull(HeapType::Concrete(STRING)),
        LocalGet(4),
        ArrayGetU(STRING),
        I32Ne,
        If(BlockType::Empty),
        sentinel_value(FALSE),
        Return,
        End,
        LocalGet(4),
        I32Const(1),
        I32Add,
        LocalSet(4),
        Br(0),
        End,
        End,
        sentinel_value(TRUE),
        Return,
        End,
        LocalGet(2),
        LocalGet(3),
        RefEq,
    ]);
    boolean(&mut body);
    let identical = b.function_with_locals(
        "identical-value",
        &[VALUE, VALUE],
        &[VALUE],
        &[(2, VALUE), (1, ValType::I32)],
        &body,
    );
    let mut body = vec![];
    argument(&mut body, 0);
    argument(&mut body, 1);
    body.push(Call(identical));
    declared.push(factory(b, "predicate-identical", 2, &[], &body));
    declared
}
