from pathlib import Path
import subprocess,time,os,json,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-native-memo-leaf-evidence');c=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'native-memo-leaf-target')
result={'base':'107a736','stages':[],'current':None};out=c/'native-memo-leaf-result.json'
for name,cmd in [('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('native',['cargo','test','-p','suss-compile','--lib','--locked','native_memo_leaf_','--','--test-threads=2','--nocapture'])]:
 if name=='native':
  paths=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.sus')]+list((r/'runtime/bootstrap').glob('*'))
  result['freeze']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 result['current']=name;out.write_text(json.dumps(result,indent=2));start=time.time()
 with (c/f'native-memo-leaf-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 result['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start});result['current']=None
 if 'freeze' in result:result['source_unchanged']=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in result['freeze'].items())
 out.write_text(json.dumps(result,indent=2))
 if p.returncode and name=='bootstrap':raise SystemExit(p.returncode)
rows=[]
for line in (c/'native-memo-leaf-native.log').read_text().splitlines():
 if line.startswith('NATIVE_MEMO_LEAF '):rows.append(json.loads(line[len('NATIVE_MEMO_LEAF '):]))
(c/'native-memo-leaf-observations.json').write_text(json.dumps({'rows':rows,'completed_rows':len(rows),'expected_rows':48,'limits':'Two &env identity views only; CLJS resolved/AST views unexecuted natively. Expected-red evidence; inspect raw exit and execution errors.'},indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='freeze'},indent=2));print('completed rows',len(rows))
raise SystemExit(p.returncode)
