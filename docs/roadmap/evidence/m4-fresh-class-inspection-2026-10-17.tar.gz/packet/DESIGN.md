# Fresh class inspection with checked ordinal selection

Base: fe8f0ffe918e6beb9a5f5e1d7a89e4859ab92fbb, isolated worktree
/home/bobby/Work/code/bobby/suss-m4-class-audit-ordinals.
Only three Rust files changed. No primary/when-let edits, no Cargo or bootstrap
execution, no generated artifact changes, no quota/tariff change.

## Choice and actual removed work

Do not build another class-result cache. ConstructionRecords already computes
an exact canonical position while checking complete class-name coverage. Pass
that Option<usize> to a fresh class inspection. Registry .get(index) is followed
by a metered exact owner-name comparison. Wrong/out-of-range hints fall back to
the original metered owner scan. No ordinal confers source authority.

Every valid-name input still checks Session/registry ownership, supplied
constructor/descriptor exact references, the CURRENT constructor-descriptor,
descriptor field 1 and the initial full schema StorageSnapshot. No class result
(true or false) is cached. Class name hashing, class AVL lookup/insertion,
class Entry/root Vec allocations/growth/relocation and retained query-root
cleanup disappear because those operations no longer execute. Prototype query
cache and lifetime/collision algorithm are unchanged. Its empty Vec/index
initialization still executes and retains its existing fee. Existing general
query collision/staging tests remain, even though production class queries no
longer use that generic mechanism.

The old24 cold model (on48, not this new source) partitions21883 staging +9143
validator, with6900 linear owner lookup in the validator. The suggested149-call
model predicts ~1.63M gross before replacement costs. This is NOT executed
candidate savings or proof of closing the ~3.276M historical default gap.
fe8 already includes later field-helper changes: compare to matched fe8, not48.

## Ownership, completeness, errors

ConstructionRecords coverage/name scan, seen duplicate bits, unknown/missing
checks, SourceArray membership and nonshortcircuit valid &= order are unchanged.
position is merely the existing checked lookup hint. Reordered catalogs work.
Registry expected.owner == supplied.name is independently checked before using
its schema. Unknown name still returns false after full owner scan; foreign
supplied roots, malformed constructor layout, fuel and IRQ remain errors.
class_at retains audit identity and registry-pointer checks, then original
supplied-root check order (constructor then descriptor), before calling the
shared validator. That validator retains its own descriptor/constructor checks
and its original per-input early-return order. No cached-false short circuit can
suppress a later input's error. No newly staged state can be partially published.
Definition/source owner identity is not substituted for current storage proof.

## Transitive effect audit

canonical_methods.rs source_class_matches_at after lookup is the exact previous
source_class_matches tail: same_reference checks, runtime constructor-descriptor,
descriptor_field(1), Session.storage_matches.

runtime_abi/nominal.rs constructor-descriptor (around522): guard closure type4,
call closure-environment, guard descriptor type, return. The only called native
helper is closure_properties.rs closure-environment (around60-87): checked
StructGet, wrapper tag RefEq, checked ARGS length3 and ArrayGet0; otherwise return
original environment. Neither success path has a user CallRef, dispatcher,
setter, ArraySet/StructSet/global write or constructor invocation. Nominal guard
errors allocate a native error string/struct and Throw(0), not user code.

canonical_methods.rs descriptor_field is direct typed field access plus owned
root conversion. storage_snapshot.rs Session.storage_matches -> matches ->
matches_with_slots validates exact root, all recorded types/lengths/fields/atoms
using native Wasmtime reads and ref_eq. The only mismatch adapter here is the
private literal closure returning false. No memo authentication callback or
source-body call occurs on this schema-only path.

portable_session.rs call checkpoints dynamic-frame and array-join-active,
executes the sealed native export, converts result/error and restores the
checkpoint. The success helper cannot alter these globals or dynamic cells.
restore_dynamic writes the same array-join-active root, compares the same frame,
and therefore does not call dynamic-pop. The same holds for nominal guard
failure: it allocates/throws without entering frames. Pending exception extraction
is the existing exact error conversion; no new error normalization is introduced.
Thus this bookkeeping is idempotent for these helpers. Existing restoration's
preserved-balance cleanup mechanism is unchanged, not a new operation refill.
GC during native allocation is allowed: inputs, registry witnesses and returned
values retain owned roots; no moving raw identity index survives any call.
Prototype cache remains forbidden across potential guest callback/construction
boundaries, as before. Fresh class reads do not authorize relaxing that lifetime.

## Meter audit

No new heap table/Vec, ordinal catalog, owner allocation, publication or deferred
cleanup is introduced. class_at pays existing query-scope3 for Session/registry
checks, plus1 per supplied root before its identity check. Session initial helper
pays1 including its bounded registry Arc retain (same original helper pattern).
Registry lookup pays1 for mode/selection control, another1 for an ordinal array
probe and owner.len + expected.owner.len +1 for its exact name comparison.
Wrong hints/unknown names additionally execute/pay every original linear owner
comparison. The existing no-hint validator also pays the new selection control1.
No surviving comparison/read/schema fee is removed. Existing validator runtime
argument collection, root ownership and storage matching use unchanged original
fees/helpers; this candidate does not claim to fix unrelated general accounting
limitations in those wrappers or RAII. Prototype cache charging is unchanged.

## Focused regressions (unexecuted)

Keep six original tests and their functional negative/error assertions; two
names change to describe fresh rather than cached class checks. Only obsolete
class-entry-count expectations change to no retained class entries. The generic
forced-collision and fuel-staging tests are byte-unchanged.

Add three tests:
- ordinal_catalog_reordering_coverage_and_wrong_hints_preserve_authority:
  all24, reversed order, GC, wrong/out-of-range hints, SourceArray forbidden
  constructor, duplicate/missing/unknown names, restore, no class publication.
- fresh_ordinal_checks_observe_schema_changes_and_restore_without_new_audit:
  List ordinal2 fast path, repeated poison false, owned original across GC,
  restored schema; identical constructor closure with changed descriptor owner,
  malformed owner Language error, restored owner and retry.
- fresh_ordinal_every_fuel_boundary_and_irq_preserve_recovery_and_late_errors:
  each balance0..measured full fresh List check cost, no retained handles/entries,
  recovery; unknown false then IRQ before later valid input must propagate.

The original exact binding/GC test retains four distinct false bindings, repeat
false checks, and unknown followed by foreign input through real records.
The original scope/error test retains final-fuel failure, active IRQ, changed
registry and retry. Fresh complete24 catalog retains its original5000 finite
fuel bound and GC, now exercises the production ordinal path each time.

## Next execution (only after independent review and target lease check)

Use exclusively /home/bobby/.cache/suss-m4-work/memo-proof-cost-target;
CARGO_BUILD_JOBS=1 RAYON_NUM_THREADS=1, test-threads=1; never set RUSTFLAGS.
Freeze all actual inputs (expected2915 but enumerate, do not assume).
Compile lib no-run; normal bootstrap regeneration BEFORE Session tests; run all
certification_audit::tests (expected9), then canonical_methods::tests, recorded
construction/prototype coverage. Fail-fast on unexpected new semantic failures.
Retain every attempt/source freeze/error. Then unchanged DEFAULT10M sourcechild,
compare actual phase markers to matched fe8. If diagnostic30M full-cost rerun is
needed, require a separately reviewed test-only tuple; never silently alter the
production fixture/default quota. CORE17/unchanged map + independent host compare
are subsequent bounded gates if candidate results justify them, not credited
in advance. No new PR/issue; eventual integration remains a separately reviewed
PR268 checkpoint referencing252/264/270, with no acceptance inferred.
