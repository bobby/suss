from pathlib import Path
import json,hashlib,subprocess,tarfile,io,shutil
cache=Path('/home/bobby/.cache/suss-m4-work');root=Path('/home/bobby/Work/code/bobby/suss-m4-class-audit-ordinals');packet=Path(__file__).parent;run=cache/'native-class-audit-fresh-inspection';out=cache/'class-audit-fresh-inspection-package';out.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='812b7257e3031cf1db5790a2e0d02d7128b53363'
frozen=json.loads((run/'after-freeze.json').read_text());receipt=json.loads((run/'receipt.json').read_text());assert receipt['current'] is None and not receipt['final_changed'] and len(receipt['stages'])==9
assert sum(int(s[1]) for stage in receipt['stages'] for s in stage['summaries'])==53
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in frozen.items())
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE);matched=[]
for p,h in frozen.items():
 proc.stdin.write((head+':'+p+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().strip();row={'path':p,'sha256':h}
 if header.endswith(' missing'):
  assert p.startswith('clojurescript/'),p;pin=subprocess.check_output(['git','rev-parse',head+':clojurescript'],cwd=root,text=True).strip();data=subprocess.check_output(['git','show',pin+':'+p[len('clojurescript/'):]],cwd=root/'clojurescript');row.update(gitlink='clojurescript',pin=pin)
 else:
  size=int(header.split()[2]);data=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n'
 assert hashlib.sha256(data).hexdigest()==h,p;matched.append(row)
proc.stdin.close();assert proc.wait()==0
(out/'committed-binding.json').write_text(json.dumps({'checkpoint':head,'count':len(matched),'missing':[],'matches':matched},indent=2)+'\n')
foundation=json.loads((cache/'native-class-audit-fresh-inspection-foundation/source-correspondence.json').read_text());assert foundation['all_exit0'] and foundation['inputs_unchanged'] and foundation['commands']==13
comparison=json.loads((run/'map-independent-comparison.json').read_text());assert comparison['counts']=={'pass':62,'guest-judged':7,'fail':0,'not-executed':0,'skipped':0,'namespaces-failed':0} and comparison['ordered_ids_match']
strict=json.loads((run/'root-sourcechild-comparison.json').read_text());assert strict['verified_actual_out_of_fuel'] and strict['actual_panic_trap'] and not strict['zero_fuel_error_marker']
# Include every parent input byte too; old three Rust blobs are in reviewed packet.
parent=json.loads((cache/'native-named-field-loop-v4/after-bootstrap-freeze.json').read_text())
for p,h in parent.items():
 dest=run/'frozen/sha256'/h
 if not dest.exists():
  data=(packet/'before'/p).read_bytes();assert hashlib.sha256(data).hexdigest()==h,p;dest.write_bytes(data)
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==h
summary={'source_head':head,'base':receipt['head'],'rust_passing_executions':53,'rust_failures':1,'ignored':0,'stages':9,'input_count':len(frozen),'foundation':foundation,'sourcechild':'Explicit typed OutOfFuel at950 recording bridge; no terminal zero marker; physicalinputs nowOk813814; finalparent incomplete and Macro source unexecuted','prefix_gain_before_physical_inputs':838191,'physical_child_interval_removed':327611,'fresh_catalog_actual2962':'Excludes records coverage; not directly comparable with old2517','whole_phase_saving':'UNMEASURED','map_counts':comparison['counts'],'reviews':'Carver source/effect/meter840fdf4 approved; required typedOutOfFuel test correction final802c1e65 executed; final committed-head/artifact review pending','limits':['No new fullworkspace/CI result or acceptance/issue closure','Keep weak driver, root strict failed/corrected postprocessor and own initial changed-outcome matcher/correction','Artifact-only ordered noncustom section correspondence bothphases equalfe8','No optimization experiment beyond this checkpoint']};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
def add(path,prefix):
 if path.is_file():files[prefix]=path
 elif path.is_dir():
  for p in sorted(path.rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:files[prefix+'/'+str(p.relative_to(path))]=p
add(run,'run');add(cache/'native-class-audit-fresh-inspection-foundation','foundation');add(packet,'packet');add(cache/'class-audit-fresh-inspection-reviewed-840fdf4','reviewed-840fdf4')
for name in ['source-child.log','map.log','after-bootstrap-freeze.json','receipt.json','map-independent-comparison.json']:
 add(cache/'native-named-field-loop-v4'/name,'parent-v4/'+name)
for name in ['model.rs','partition.json','stdout.txt']:add(cache/'class-audit-charge-model-48'/name,'historical48-model/'+name)
add(cache/'compare-fresh-class-prefix.py','drivers/root-compare-fresh-class-prefix.py')
for p in out.glob('*.json'):add(p,'final/'+p.name)
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+name+'\n' for name,p in sorted(files.items())).encode();archive=root/'docs/roadmap/evidence/m4-fresh-class-inspection-2026-10-17.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=5) as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('SHA256SUMS');info.size=len(manifest);t.addfile(info,io.BytesIO(manifest))
# Re-read all members and verify the actual persisted archive independently.
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(files)+1;assert len({m.name for m in members})==len(members)
 for line in t.extractfile('SHA256SUMS').read().decode().splitlines():
  h,name=line.split('  ',1);assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h,name
result={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files)+1,'manifested_payloads':len(files),'bytes':archive.stat().st_size,'source_head':head,'binding_count':len(matched)};(packet/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');shutil.copyfile(packet/'REPORT.md',root/'docs/roadmap/evidence/m4-fresh-class-inspection-2026-10-17.md');print(json.dumps(result))
