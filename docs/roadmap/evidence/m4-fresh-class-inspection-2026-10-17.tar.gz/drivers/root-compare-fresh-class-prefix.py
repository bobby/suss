import collections, hashlib, json, re
from pathlib import Path
cache=Path('/home/bobby/.cache/suss-m4-work')
run=cache/'native-class-audit-fresh-inspection'
receipt=json.loads((run/'receipt.json').read_text())
stage=next(x for x in receipt['stages'] if x['name']=='source-child')
assert stage.get('exit') is not None, 'source-child is still running'
paths=[cache/'native-named-field-loop-v4/source-child.log',run/'source-child.log']
raw=[p.read_bytes() for p in paths]
texts=[b.decode() for b in raw]
pattern=re.compile(r'^source-child-fuel source=(\w+) variant=(.*?) stage=(.*?) remaining=Some\((\d+)\)$',re.M)
def parse(text):
    rows=[]; seen=collections.Counter()
    for source,variant,event,fuel in pattern.findall(text):
        label,sep,result=event.partition(' result=')
        base=(source,variant,label,bool(sep)); occurrence=seen[base];seen[base]+=1
        rows.append({'key':[*base,occurrence],'result':result if sep else None,'fuel':int(fuel)})
    return rows
before,after=map(parse,texts)
old={tuple(x['key']):x for x in before};matched=[];changed=[];new=[]
for row in after:
    prev=old.get(tuple(row['key']))
    if prev is None:new.append(row)
    elif prev['result']!=row['result']:changed.append({'before':prev,'after':row})
    else:matched.append({'key':row['key'],'before':prev['fuel'],'after':row['fuel'],'delta':row['fuel']-prev['fuel']})
panic=texts[1].split('panicked at',1)[1] if 'panicked at' in texts[1] else ''
trap='Trap(wasm trap: all fuel consumed by WebAssembly)' in panic
zero_error=any(x['fuel']==0 and x['result'] and 'Err("Runtime trap: wasm trap: all fuel consumed by WebAssembly")'==x['result'] for x in after)
failed_summary='test result: FAILED. 0 passed; 1 failed; 0 ignored;' in texts[1]
verified_fuel=stage['exit']==101 and failed_summary and trap
result={'raw_paths':[str(p)for p in paths],'raw_sha256':[hashlib.sha256(b).hexdigest()for b in raw],
        'source_child_exit':stage['exit'],'verified_actual_out_of_fuel':verified_fuel,
        'actual_panic_trap':trap,'zero_fuel_error_marker':zero_error,
        'matched_same_outcome_balances':matched,'changed_outcomes_not_numeric_savings':changed,
        'newly_reached_markers':new,'last_markers':after[-8:],
        'limitations':['Original driver substring classifier is insufficient because trace lines contain fuel.',
        'Actual panic Trap(OutOfFuel) plus terminal failed summary verifies the failure class. A zero-fuel stage marker is optional evidence; this newly reached panic path emits no terminal source-stage balance.',
        'Balances compare identical reached stages/outcomes; newly reached stages have no old cost estimate.',
        'This is default10M prefix evidence, not a completed whole-operation cost or acceptance proof.']}
(run/'root-sourcechild-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'exit':stage['exit'],'verified_actual_out_of_fuel':verified_fuel,'last_markers':after[-5:],'changed_outcomes':changed,'matched_balances':matched[-5:]},indent=2))
assert stage['exit']==0 or verified_fuel, 'Unexpected/unclassified source-child failure; investigate raw panic'
