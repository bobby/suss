#![allow(dead_code)]
#[path="/home/bobby/Work/code/bobby/suss-m4-native-validation-cost/crates/suss-compile/src/portable/metered_map.rs"] mod original;
use original::{TryOrderedMap,Context};
use std::{cmp::Ordering,collections::BTreeMap};
#[derive(Default)] struct Meter { phase: &'static str, sums:BTreeMap<&'static str,u64>, compares:BTreeMap<&'static str,u64>, events:Vec<(&'static str,u64)> }
impl Context<u64> for Meter {type Error=(); fn charge(&mut self,w:u64)->Result<(),()> { *self.sums.entry(self.phase).or_default()+=w; self.events.push((self.phase,w));Ok(()) } fn compare(&mut self,a:&u64,b:&u64)->Result<Ordering,()> { *self.compares.entry(self.phase).or_default()+=1;self.charge(1)?;Ok(a.cmp(b)) }}
struct LayoutEntry { name:Option<&'static str>, roots:Vec<[usize;5]>, valid:bool,next:Option<usize> }
fn main(){
let names:[&str; 24]=["Symbol", "Keyword", "List", "EmptyList", "Cons", "IndexedSeq", "PersistentVector", "VectorNode", "PersistentArrayMap", "PersistentHashMap", "PersistentHashSet", "BitmapIndexedNode", "ArrayNode", "HashCollisionNode", "NodeSeq", "ArrayNodeSeq", "MapEntry", "KeySeq", "PersistentArrayMapSeq", "ChunkedSeq", "LazySeq", "ChunkedCons", "ArrayChunk", "SourceArray"];
let mut heads=TryOrderedMap::default();let mut meter=Meter::default();let mut entry_cap=0;let mut entry_bytes=0;let mut root_bytes=0;let mut hash_units=0;
for (i,name) in names.iter().enumerate(){ let mut hash=0xcbf29ce484222325u64;for b in name.bytes(){hash=(hash^u64::from(b)).wrapping_mul(0x100000001b3);}hash_units+=1+3*name.len() as u64;
meter.phase="cold_get";assert!(heads.get(&hash,&mut meter).unwrap().is_none());meter.phase="cold_insert";heads.get_or_insert(hash,i,&mut meter).unwrap();
if i+1>entry_cap {entry_cap=(entry_cap*2).max(i+1);entry_bytes+=(entry_cap+i)*std::mem::size_of::<LayoutEntry>();}
let count=if *name=="SourceArray" {1}else{2};root_bytes+=count*40;
}
for name in names {let mut hash=0xcbf29ce484222325u64;for b in name.bytes(){hash=(hash^u64::from(b)).wrapping_mul(0x100000001b3);}meter.phase="warm_get";assert!(heads.get(&hash,&mut meter).unwrap().is_some());}
println!("entry_layout_bytes={} root_value_model_bytes=40 entry_backing_plus_relocation={} roots_backing={} hash_units={}",std::mem::size_of::<LayoutEntry>(),entry_bytes,root_bytes,hash_units);
println!("map_units={:?} comparisons={:?}",meter.sums,meter.compares);
let cold_search=2*(meter.compares["cold_get"]+meter.compares["cold_insert"]);let plans=meter.events.iter().filter(|(p,w)|*p=="cold_insert"&&*w==32).count() as u64*32;
println!("cold_map_search={} plan_units={} map_rest_including_write_and_backing={}",cold_search,plans,meter.sums["cold_get"]+meter.sums["cold_insert"]-cold_search-plans);
}
