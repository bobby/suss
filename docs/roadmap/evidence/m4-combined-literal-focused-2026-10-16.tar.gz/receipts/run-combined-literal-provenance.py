from pathlib import Path
import json,subprocess,time,hashlib,os
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-literal-memos')
parent=json.loads((c/'combined-literal-focused-result.json').read_text());assert parent['current'] is None and parent['source_unchanged'];freeze=parent['freeze']
assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items())
state={'current':None,'stages':[],'freeze':freeze};out=c/'combined-literal-provenance-result.json'
def save():out.write_text(json.dumps(state,indent=2)+'\n')
commands=[('python-tests',['python3','-m','unittest','discover','-s','scripts','-p','test_*.py'])]
for name,args in [('inventory',['cljs_inventory.py','--check']),('reviews',['cljs_reviews.py']),('core-import',['core_import.py','--check']),('reader-catalog',['reader_core_catalog.py','--check']),('apply-bootstrap',['apply_bootstrap.py','--check']),('sequences',['sequence_provenance.py']),('records',['check_record_macro_provenance.py']),('transducers',['check_transducer_provenance.py']),('bitwise',['bitwise_provenance.py']),('wasi',['wasi_lock.py']),('numeric',['numeric_runtime.py','--check']),('jank',['clojure_test_suite.py']),('jank-overlap',['clojure_test_suite.py','overlap'])]:commands.append((name,['python3','scripts/'+args[0]]+args[1:]))
for name,cmd in commands:
 state['current']=name;stage={'name':name,'command':cmd};state['stages'].append(stage);save();start=time.time()
 with (c/('combined-literal-provenance-'+name+'.log')).open('w') as log:result=subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT)
 stage.update(exit=result.returncode,seconds=time.time()-start);save()
state.update(current=None,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items()));save();print(json.dumps({k:v for k,v in state.items() if k!='freeze'},indent=2))
