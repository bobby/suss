from pathlib import Path
import os,json,time,hashlib,subprocess
r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-literal-memos');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'))
env['SUSS_KEYWORD_CONFORMANCE_CAPTURE']=str(c/'combined-literal-keyword-observations')
state={'base':'a3c158c+reviewed-literals','stages':[],'current':None};out=c/'combined-literal-preservation-result.json'
def save():out.write_text(json.dumps(state,indent=2)+'\n')
def run(name,cmd):
 state['current']=name;entry={'name':name,'command':cmd};state['stages'].append(entry);save();start=time.time()
 with (c/f'combined-literal-preservation-{name}.log').open('w') as f:x=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 entry.update(exit=x.returncode,seconds=time.time()-start);save();return x.returncode
parent=json.loads((c/'combined-literal-focused-result.json').read_text())
assert parent['current'] is None and parent['source_unchanged']
state['freeze']=parent['freeze']
assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in state['freeze'].items())
save()
for name,args in [('collections', ['-p', 'suss-cli', '--locked', '--test', 'compiled_macro_collection_source_asts']), ('control', ['-p', 'suss-cli', '--locked', '--test', 'compiled_macro_control_source_asts']), ('constructors', ['-p', 'suss-cli', '--locked', '--test', 'compiled_macro_constructor_source_asts']), ('global', ['-p', 'suss-cli', '--locked', '--test', 'compiled_macro_global_reference_asts']), ('core', ['-p', 'suss-cli', '--locked', '--test', 'compiled_macro_core_environment']), ('map', ['-p', 'suss-compile', '--locked', '--test', 'clojure_test_suite', 'pinned_map_declaration_executes_without_transport_loss'])]:
 run(name,['cargo','test']+args+['--','--test-threads=2','--nocapture'])
state.update(current=None,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in state['freeze'].items()));save();print(json.dumps({k:v for k,v in state.items() if k!='freeze'},indent=2))
