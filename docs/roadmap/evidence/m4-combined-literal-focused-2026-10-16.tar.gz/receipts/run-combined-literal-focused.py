from pathlib import Path
import os,json,time,hashlib,subprocess
r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-literal-memos');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'))
env['SUSS_KEYWORD_CONFORMANCE_CAPTURE']=str(c/'combined-literal-keyword-observations')
state={'base':'a3c158c','stages':[],'current':None};out=c/'combined-literal-focused-result.json'
def save():out.write_text(json.dumps(state,indent=2)+'\n')
def run(name,cmd):
 state['current']=name;entry={'name':name,'command':cmd};state['stages'].append(entry);save();start=time.time()
 with (c/f'combined-literal-focused-{name}.log').open('w') as f:x=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 entry.update(exit=x.returncode,seconds=time.time()-start);save();return x.returncode
if run('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']):
 state['current']=None;save();raise SystemExit(1)
files=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']]+[p for p in (r/'runtime/bootstrap').glob('*') if p.is_file()]
state['freeze']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};save()
for name,args,stop in [('native',['-p','suss-compile','--locked','--lib','analyzer_literal'],True),('env',['-p','suss-cli','--locked','--test','compiled_macro_analyzer_literal_memos'],True),('keyword',['-p','suss-compile','--locked','--test','clojure_test_suite','pinned_keyword_namespace_keeps_values'],True),('source-tags',['-p','suss-cli','--locked','--test','compiled_macro_source_tags'],False)]:
 exitcode=run(name,['cargo','test']+args+['--','--test-threads=2','--nocapture'])
 if stop and exitcode:state['stopped_on_unexpected_focused_failure']=name;break
state.update(current=None,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in state['freeze'].items()));save();print(json.dumps({k:v for k,v in state.items() if k!='freeze'},indent=2))
