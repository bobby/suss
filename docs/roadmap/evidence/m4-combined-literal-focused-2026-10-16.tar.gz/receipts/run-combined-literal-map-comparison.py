from pathlib import Path
import os,json,hashlib,subprocess,time,sys
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-literal-memos')
parent=json.loads((c/'combined-literal-preservation-result.json').read_text());assert parent['current'] is None and parent['source_unchanged']
freeze=parent['freeze'];assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items())
observations=c/'combined-literal-map-observations';env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',SUSS_CLOJURE_TEST_SUITE_CAPTURE=str(observations))
cmd=['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--test-threads=2','--nocapture']
s={'command':cmd,'reason':'Retain actual operand observations and independent comparison; earlier preservation map gate did not configure capture.','current':'map','freeze':freeze};out=c/'combined-literal-map-result.json';out.write_text(json.dumps(s,indent=2));start=time.time()
with (c/'combined-literal-map.log').open('w') as log:result=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
s.update(exit=result.returncode,seconds=time.time()-start,current=None,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items()))
sys.path.insert(0,str(r/'scripts'));import clojure_test_suite as suite
f=observations/'map-transport-observations.json'
if f.exists():
 reference=json.loads((r/'tests/oracle/clojure-test-suite-observations.json').read_text());names=['clojure.core-test.map'];tests=['clojure.core-test.map/test-map']
 reference.update(namespaces=names,tests=tests,assertions=[x for x in reference['assertions'] if x['test'] in tests],skips=[x for x in reference['skips'] if x['namespace'] in names])
 observed=json.loads(f.read_text());counts,failures=suite.compare(reference,observed)
 expected=[(x['test'],x['ordinal']) for x in reference['assertions']];actual=[(x['test'],x['ordinal']) for x in observed['assertions']]
 comparison={'counts':counts,'failures':failures,'ordered_ids_match':actual==expected,'expected_ids':expected,'actual_ids':actual,'test_failures':observed['test-failures'],'skips':observed['skips']}
 (c/'combined-literal-map-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
 s['comparison_counts']=counts;s['ordered_ids_match']=actual==expected
else:s['observations']='missing; no comparison available'
out.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='freeze'},indent=2))
