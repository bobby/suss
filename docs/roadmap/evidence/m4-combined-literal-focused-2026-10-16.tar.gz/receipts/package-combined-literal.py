from pathlib import Path
import hashlib,json,subprocess,tarfile,io
r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-literal-memos');c=Path('/home/bobby/.cache/suss-m4-work');s=json.loads((c/'combined-literal-focused-result.json').read_text());assert s['current'] is None and s['source_unchanged'];payload={}
for f,h in s['freeze'].items():
 b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+f]=b
extra=['Cargo.toml','Cargo.lock','crates/suss-core/Cargo.toml','crates/suss-reader/Cargo.toml','crates/suss-compile/Cargo.toml','crates/suss-cli/Cargo.toml','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','runtime/core-import/LICENSE','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json','vendor/wasi/wasi-wit-0.3.1/cli/cli.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit']
for f in extra:assert (r/f).is_file();payload['snapshot/'+f]=(r/f).read_bytes()
paths=[f for f in s['freeze'] if f=='crates/suss-compile/build.rs' or any(f.startswith('crates/'+n+'/src/') and f.endswith(('.rs','.sus')) for n in ['suss-core','suss-reader','suss-compile'])]+extra[:5]+extra[9:];h=hashlib.sha256()
for f in sorted(set(paths),key=lambda p:tuple(p.split('/'))):
 b=payload['snapshot/'+f];n=f.encode();h.update(len(n).to_bytes(8,'little'));h.update(n);h.update(len(b).to_bytes(8,'little'));h.update(b)
checks={}
for phase in ['macro','runtime']:
 m=json.loads(payload[f'snapshot/runtime/bootstrap/{phase}.json']);checks[phase]={'compiler':h.hexdigest()==m['compiler_source_sha256'],'core':hashlib.sha256(payload['snapshot/runtime/core-import/suss/core.sus']).hexdigest()==m['source_sha256'],'dependencies':hashlib.sha256(payload['snapshot/runtime/core-import/manifest.json']).hexdigest()==m['dependency_graph_sha256'],'wasm':hashlib.sha256(payload[f'snapshot/runtime/bootstrap/{phase}.wasm']).hexdigest()==m['wasm_sha256']}
assert all(all(v.values()) for v in checks.values()),checks
preservation=json.loads((c/'combined-literal-preservation-result.json').read_text())
assert preservation['current'] is None and preservation['source_unchanged']
assert preservation['freeze']==s['freeze']
provenance=json.loads((c/'combined-literal-provenance-corrected-result.json').read_text())
assert provenance['current'] is None and provenance['source_unchanged'] and provenance['freeze']==s['freeze']
map_receipt=json.loads((c/'combined-literal-map-result.json').read_text())
assert map_receipt['current'] is None and map_receipt['source_unchanged'] and map_receipt['freeze']==s['freeze']
for p in c.glob('combined-literal-*'):
 if p.is_file() and 'package-result' not in p.name:payload['receipts/'+p.name]=p.read_bytes()
for directory in ['combined-literal-keyword-observations','combined-literal-map-observations']:
 for p in (c/directory).glob('*'):
  if p.is_file():payload['observations/'+directory+'/'+p.name]=p.read_bytes()
for name in ['run-combined-literal-focused.py','run-combined-literal-preservation.py','package-combined-literal.py','run-combined-literal-map-comparison.py','run-combined-literal-provenance.py','run-combined-literal-provenance-corrected.py']:
 payload['receipts/'+name]=(c/name).read_bytes()
for f in ['scripts/clojure_test_suite.py','tests/oracle/clojure-test-suite-observations.json','vendor/clojure-test-suite/upstream/test/clojure/core_test/keyword.cljc','vendor/clojure-test-suite/upstream/test/clojure/core_test/map.cljc']:
 payload['support/'+f]=(r/f).read_bytes()
payload['change.patch']=subprocess.check_output(['git','diff','a3c158c','--','crates'],cwd=r)
# Include new files, which git diff does not enumerate before staging.
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','crates'],cwd=r,text=True).splitlines()
for f in new:assert 'snapshot/'+f in payload,f
payload['audit.json']=json.dumps({'base':'a3c158ceb942fefd559f90d4b8e25405f971a954','semantic_source':'f1ab36c..be6a219 source-only crates delta','keyword_test_source':'ec0eea2..1f034b4 test-only gate','freeze_count':len(s['freeze']),'fingerprints':checks,'focused_stages':s['stages'],'preservation_stages':preservation['stages'],'provenance_stages':provenance['stages'],'captured_map':{k:v for k,v in map_receipt.items() if k!='freeze'},'authority':'Audited explicit literal provenance; no spelling-based eligibility. Reader/source symbols and metadata values and Suss-only fields cold. Existing nil-transition and source/storage authority unchanged. Current a3 raw/paged canonical entries preserved.','review':'Independent source-integration review found no blockers. Final artifact/committed-head review pending.','limits':'Both unchanged source-tag tests still default-fuel fail. No issue closure, full workspace baseline or final-head CI claim. Supporting fingerprint/oracle inputs captured after tests, not independently pre-frozen. Raw failures preserved; started or absent outcomes never inferred passing.','next':'Actual namespace constructor provenance audit and actual-env custom-IHash regression remain separate work.'},indent=2).encode()
manifest={f:hashlib.sha256(b).hexdigest() for f,b in sorted(payload.items())}
payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=r/'docs/roadmap/evidence/m4-combined-literal-focused-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f,b in sorted(payload.items()):
  info=tarfile.TarInfo(f);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:
 for f,h in manifest.items():assert hashlib.sha256(t.extractfile(f).read()).hexdigest()==h,f
result={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'freeze_count':len(s['freeze']),'fingerprints':checks}
(c/'combined-literal-package-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
