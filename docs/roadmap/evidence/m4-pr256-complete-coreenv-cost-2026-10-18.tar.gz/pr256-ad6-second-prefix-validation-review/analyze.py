#!/usr/bin/env python3
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,re,collections,hashlib,subprocess
K=Path('/home/bobby/.cache/suss-m4-work');P=Path(__file__).resolve().parent
RAW=K/'pr256-ad6-materialization-scratch-probe/coreenv-2B-scratch.log';rows=RAW.read_text().splitlines();H=lambda b:hashlib.sha256(b).hexdigest()
starts=[i for i,l in enumerate(rows) if re.search(r'macro-fuel user/declaration-facts start: \d+$',l)];assert len(starts)==2
start=starts[1];part=rows[start:];STAGES=['start','logical','direct','inputs','classes','prototypes'];complete=[];pending=None;totals=collections.Counter();fresh=collections.Counter();freshrows=[];scratch=[]
for lineno,line in enumerate(part,start+1):
 m=re.search(r'metadata-fuel (\S+) (start|logical|direct|inputs|classes|prototypes): (\d+)$',line)
 if m:
  owner,stage,fuel=m.groups();fuel=int(fuel)
  if stage=='start':assert pending is None;pending={'owner':owner,'lines':[],'fuels':[]}
  assert pending is not None and owner==pending['owner'] and stage==STAGES[len(pending['fuels'])]
  pending['lines'].append(lineno);pending['fuels'].append(fuel)
  if stage=='prototypes':
   costs={name:pending['fuels'][i]-pending['fuels'][i+1] for i,name in enumerate(STAGES[1:])};assert min(costs.values())>=0
   pending['costs']=costs;totals.update(costs);complete.append(pending);pending=None
 f=re.search(r'metadata-fresh (\d+) (\S+): (\d+)$',line)
 if f:fresh[f[2]]+=1;freshrows.append({'line':lineno,'index':int(f[1]),'stage':f[2],'fuel':int(f[3])})
 if 'metadata-scratch ' in line:scratch.append({'line':lineno,'text':line})
assert len(complete)==658 and pending is None
assert dict(fresh)=={'start':1}
checks=sum(totals.values());gaps=[]
for a,b in zip(complete,complete[1:]):
 cost=a['fuels'][-1]-b['fuels'][0];assert cost>=0
 gaps.append({'previous':a['owner'],'next':b['owner'],'from_line':a['lines'][-1],'to_line':b['lines'][0],'observed_units':cost})
gapcost=sum(x['observed_units'] for x in gaps);between=complete[0]['fuels'][0]-complete[-1]['fuels'][-1];assert checks+gapcost==between
callerform=next((i+start+1,int(l.rsplit(': ',1)[1])) for i,l in enumerate(part) if 'macro-fuel user/declaration-facts caller-form:' in l)
lastouter=next(x for x in reversed(scratch) if 'controlled=true' in x['text'] and 'event=exit' in x['text']);assert 'outcome=err fuel=Some(0)' in lastouter['text']
pre=callerform[1]-complete[0]['fuels'][0];prefix=callerform[1]-complete[-1]['fuels'][-1];assert pre+checks+gapcost==prefix
plain=[x for x in scratch if 'event=exit' in x['text'] and 'controlled=false' in x['text']];assert len(plain)==1 and 'outcome=ok' in plain[0]['text']
# Validate unchanged source boundaries, not just matching function names.
R=Path('/home/bobby/Work/code/bobby/suss');ad6='ad6bbcc3c1687f717c6638b127673a0bc83baac8';c59='c59b6237a2eb9fe6bf353304cd1efe0ac2e40901'
def git(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=R)
source_identity={}
for p in ['crates/suss-compile/src/portable_macro_graph/reuse.rs','crates/suss-compile/src/portable_macro_graph/metadata_expectations.rs','crates/suss-compile/src/portable_macro_graph/source_facts.rs']:
 a=git(ad6,p);b=git(c59,p);assert a==b;source_identity[p]={'byte_identical':True,'sha256':H(a)}
p='crates/suss-compile/src/portable_macro_graph/construction.rs'
def check_body(s):
 s=s.decode();i=s.index('    fn check_recorded_source(');return s[i:s.index('\n}\n',i)+3].encode()
a=check_body(git(ad6,p));b=check_body(git(c59,p));assert a==b;source_identity[p+'::check_recorded_source']={'byte_identical':True,'sha256':H(a)}
result={'raw_path':str(RAW),'raw_sha256':H(RAW.read_bytes()),'scope':'SECOND Runtime user/declaration-facts request, ad6 observer+2B diagnostic; completed prefix ONLY, not c59 totals',
 'request_start_line':start+1,'complete_validation_checks':len(complete),'stage_order':STAGES,'component_observed_costs':dict(totals),'complete_six_stage_total':checks,
 'validation_component_percent':{k:100*v/checks for k,v in totals.items()},
 'disjoint_completed_prefix':{'caller_form_fuel':callerform[1],'last_completed_validation_fuel':complete[-1]['fuels'][-1],'total':prefix,'before_first_validation':pre,'six_stage_checks':checks,'between_validation_gaps':gapcost},
 'between_first_start_and_last_prototypes':{'total':between,'validation':checks,'unattributed_gaps':gapcost,'validation_percent':100*checks/between,'gaps_percent':100*gapcost/between},
 'largest_gaps':sorted(gaps,key=lambda x:x['observed_units'],reverse=True)[:20],
 'fresh_stage_counts':dict(fresh),'fresh_markers':freshrows,'completed_fresh_recordings':0,
 'plain_fallback_exit':plain[0],'finish_stage_reached':any('metadata-finish ' in l for l in part),
 'failed_tail':{'after_line':complete[-1]['lines'][-1],'last_completed_owner':complete[-1]['owner'],'last_completed_fuel':complete[-1]['fuels'][-1],'outer_error_marker':lastouter,'observed_remaining_to_zero':complete[-1]['fuels'][-1],'interpretation':'observed error tail only; failed operation/component/needed remainder unknown; not another completed validation interval'},
 'old_fresh_inference':{'no_boolean_hit_markers':True,'completed_old_checks':658,'followed_by_next_validation':657,'bounded_inference':'In Build::produce, a failed candidate/current predicate with current Some would call fresh and emit expected/bridge; neither occurs in this prefix. First657 candidate checks are followed by another owner check, without completed fresh recording. Last candidate progress after prototypes is unknown. One fresh-start-only source is a deliberate None expectation followed by normal fallback, not proof of a reconstruction. Do not extrapolate to all825 roots, later recheck/publication or c59.'},
 'source_identity_to_c59':source_identity,
 'next_source_backed_target':'The1.832B disjoint unlabelled inter-check gaps, not the25.26M bracketed validation total. Build::produce captures a new per-graph metadata_expectation before checking each old candidate and performs a second expected.matches_logical_source after the traced full-record check; outer recipe construction also shares these gaps. Existing trace does not separate these. First bracket capture_metadata_expectation(project + from_normalized_source) vs second expected logical check vs outer materializer; no guard removal or implementation chosen.',
 'getter_priority':'No completed fresh recording observed here; post-factory data_construct_with_inputs getter is not an evidenced explanation of this prefix. Prototype component here is fresh origin VALIDATION, distinct from initial post-factory getter.',
 'limitations':['No completed whole second environment at ad6; failed at caller&env0..36 under diagnostic2B','No c59 whole second-request/new counts projected from this trace','No claim all prior cache entries declined or all reused/published','Fuel balances are observed debits, not complete cost of failed tail or unperformed work','No Cargo/root/branch/controller writes or runtime execution by reviewer']}
(P/'partition.json').write_text(json.dumps(result,indent=2)+'\n');(P/'completed-checks.json').write_text(json.dumps(complete,indent=2)+'\n');(P/'intercheck-gaps.json').write_text(json.dumps(gaps,indent=2)+'\n')
print(json.dumps({'complete_checks':len(complete),'components':dict(totals),'six_stage_total':checks,'gaps':gapcost,'fresh_completed':0,'prefix':prefix}))
if __name__=='__main__':pass
