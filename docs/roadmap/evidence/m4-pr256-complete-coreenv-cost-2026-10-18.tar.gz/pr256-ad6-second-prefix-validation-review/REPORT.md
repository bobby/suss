# Second ad6 request: completed-prefix validation partition

Raw source-bound trace: pr256-ad6-materialization-scratch-probe/coreenv-2B-scratch.log. This is the prior ad6 + observer + diagnostic2B tuple, not current c59. The second Runtime request fails in caller&env0..36; no finalization marker or complete second environment exists here.

658 complete start→logical→direct→inputs→classes→prototypes checks:

| Disjoint component | Observed units |
|---|---:|
| logical | 862,548 |
| direct | 364,248 |
| inputs | 2,292,204 |
| classes | 6,443,136 |
| prototypes | 15,299,336 |
| **All traced checks** | **25,261,472** |

Prototypes dominate this **25.26M traced subset**, not the request. Between the first validation start and last completed prototypes checkpoint, observed cost is1,857,667,728: traced checks25,261,472 plus **1,832,406,256 unlabelled gaps**. Including the caller-form→first-validation prefix126,562,422 gives a disjoint completed observed prefix1,984,230,150. The remaining15,766,185 to the outer materializer's reported0 belongs to a failing/partial tail; its completing cost and operation are unknown.

Only one metadata-fresh start appears in request2, with no expected/bridge/constructed/recorded markers. It is followed by a successful ordinary fallback materialization. Source record_metadata caches a deliberate None expectation before that early return. No complete fresh recording or finish/recheck/publication phase is observed. In produce, candidate rejection with current Some would emit expected/bridge for fresh recording; those are absent. Thus the trace does not support “all old cache declined/rebuilt.” At least657 checks progress to the next owner's validation without a fresh recording; the last candidate's post-check progress remains unknown. Booleans/old-hit flags are not explicitly logged; do not claim825 hits or final retained publication.

The strongest measured target is the **unattributed inter-check gap**, not the unmeasured initial constructor prototype getter. Build::produce calls metadata_expectation before the next old-record check and performs a separate expected.matches_logical_source after the traced check; outer parent construction also occurs in these gaps. The native capture_metadata_expectation project walks dependencies per occurrence and builds owned Forms before normalized-source witness capture, but its individual cost is not isolated here. Do not assign all1.832B to projection or the second logical read without narrower brackets. No guard omission or native accessor implementation is justified by this census.

The prototype stage is a fresh private-origin VALIDATION query, distinct from the initial post-factory owned-descriptor-prototype getter proposed earlier. With no completed fresh recording in this second prefix, that initial getter is not an evidenced explanation for its large cost. reuse.rs, metadata_expectations.rs and source_facts.rs are byte-identical ad6→c59, as is production check_recorded_source; partition.json binds exact hashes. Scratch routing differs and current request counts/full costs cannot be projected.

analyze.py reproduces totals and completed-check/intercheck tables. No Cargo, source/controller edits, signals, quota changes or new execution. No whole-request saving, c59 cache-hit rate, readiness or acceptance claim.
