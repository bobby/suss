"""One-shot measurement; restore owned files only after the owned process group drains."""
from pathlib import Path
import argparse,fcntl,hashlib,json,os,signal,subprocess,time,traceback
P=Path(__file__).resolve().parent;ROOT=Path('/home/bobby/Work/code/bobby/suss')
H=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def hashes(names):return {n:H((ROOT/n).read_bytes()) for n in names}
def group_live(pgid):
 return any(parts[0]==str(pgid) and not parts[1].startswith('Z') for line in subprocess.check_output(['ps','-eo','pgid=,stat='],text=True).splitlines() if len(parts:=line.split())==2)
def drain(child):
 if group_live(child.pid):
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 try:child.wait(timeout=10)
 except subprocess.TimeoutExpired:
  if group_live(child.pid):os.killpg(child.pid,signal.SIGKILL)
  child.wait()
 if group_live(child.pid):os.killpg(child.pid,signal.SIGKILL)
 for _ in range(100):
  if not group_live(child.pid):return
  time.sleep(.02)
 raise RuntimeError('Owned group failed to drain')
def interrupt(s,f):raise KeyboardInterrupt('controller signal '+str(s))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');args=ap.parse_args();assert args.execute
 m=json.loads((P/'manifest.json').read_text());assert not (P/'receipt.json').exists(),'One shot; never overwrite previous evidence'
 lock=(P/'controller.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 r={'base':m['base'],'terminal':False,'diagnostic_only':True,'macro_allowance':10000000000,'caller_defaults_unchanged':True,'controller_pid':os.getpid(),'stages':[]}
 def save():
  q=P/'receipt.tmp';q.write_text(json.dumps(r,indent=2)+'\n');q.replace(P/'receipt.json')
 def cache(name,obj):(P/name).write_text(json.dumps(obj,indent=2)+'\n')
 def snapshot(label):
  for n in m['owned']:
   q=P/'snapshots'/label/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((ROOT/n).read_bytes())
 child=None;installed=False;expected_owned={};freeze={};names=[];safe=True
 signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt);save()
 try:
  assert git('rev-parse','HEAD').decode().strip()==m['base']
  assert not git('diff','--name-only','HEAD').strip(),'Tracked changes before install'
  assert hashes(m['owned'])==m['owned']
  for n,h in m['owned'].items():assert H((P/'original'/n).read_bytes())==h
  for n,h in m['overlay'].items():assert H((P/'overlay'/n).read_bytes())==h
  names=[n for n in git('ls-files').decode().splitlines() if (ROOT/n).is_file()]
  r['gitlink']=git('ls-tree','HEAD','clojurescript').decode().strip()
  cache('before-overlay-freeze.json',hashes(names));snapshot('before-overlay')
  installed=True
  for n in m['overlay']:(ROOT/n).write_bytes((P/'overlay'/n).read_bytes())
  expected_owned=dict(m['owned']);expected_owned.update(m['overlay']);assert hashes(m['owned'])==expected_owned;freeze=hashes(names);cache('before-first-cargo-freeze.json',freeze);snapshot('before-bootstrap')
  assert not any(k.startswith('SUSS_') for k in os.environ),'Unknown inherited SUSS environment'
  env=os.environ.copy();env.update(m['environment'])
  for stage in m['stages']:
   assert git('rev-parse','HEAD').decode().strip()==m['base'];assert hashes(names)==freeze
   row={'name':stage['name'],'argv':stage['argv'],'environment_overrides':m['environment'],'terminal':False,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())};r['stages'].append(row);r['current']=stage['name'];save();start=time.monotonic()
   with (P/(stage['name']+'.log')).open('w') as out:
    child=subprocess.Popen(stage['argv'],cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=child.pid;r['cargo_pid']=child.pid;save();code=child.wait()
    if group_live(child.pid):drain(child)
    assert not group_live(child.pid);child=None
   after=hashes(names);changed=[n for n in names if after[n]!=freeze[n]];row.update(terminal=True,exit=code,seconds=time.monotonic()-start,changed=changed);cache(stage['name']+'-after-freeze.json',after);save()
   if stage['name']=='bootstrap':
    assert code==0,'Bootstrap failure';assert set(changed)<=set(m['boot']),'Generation changed nonBOOT input';assert all(after[n]==h for n,h in m['overlay'].items()),'Unknown source overlay';expected_owned.update({n:after[n] for n in m['boot']});freeze=after;cache('executed-source-freeze.json',freeze);snapshot('after-bootstrap');assert code==0,'Bootstrap failure'
   else:
    assert not changed,'Source drift during validation'
    if stage['name']=='identity':assert code==0,'Identity failure'
    else:assert code in (0,101),'Unexpected test process failure'
  r['all_stages_executed']=True
 except BaseException:r['error']=traceback.format_exc();raise
 finally:
  signal.signal(signal.SIGTERM,signal.SIG_IGN);signal.signal(signal.SIGINT,signal.SIG_IGN)
  if child is not None:
   try:
    drain(child);child=None
    # Interrupted bootstrap output remains untrusted; refuse automatic overwrite.
   except BaseException:r['drain_error']=traceback.format_exc();safe=False
  r['owned_group_drained']=safe
  if installed and safe:
   for n in m['overlay']:expected_owned.setdefault(n,m['overlay'][n])
   for n in m['boot']:expected_owned.setdefault(n,m['owned'][n])
   observed=hashes(m['owned']);r['owned_before_restore']=observed
   if git('rev-parse','HEAD').decode().strip()==m['base'] and observed==expected_owned:
    snapshot('before-restore')
    for n in m['owned']:(ROOT/n).write_bytes((P/'original'/n).read_bytes())
    r['production_restored']=hashes(m['owned'])==m['owned']
   else:r['manual_restore_required']='Unexpected HEAD or owned bytes; no overwrite'
  if names:cache('terminal-restored-freeze.json',hashes(names))
  r['unexecuted']=[s['name'] for s in m['stages'] if not any(t['name']==s['name'] and t['terminal'] for t in r['stages'])];r.update(terminal=True,current=None);save()
 print(json.dumps(r),flush=True)
if __name__=='__main__':main()
