# Command compiler allowance evidence

suite-complete/ contains the preceding terminal12PASS upstream harness on
8921f86 native/test source, before the command API/native bootstrap changes.
base-ci/ retains both actual failed source-tree CI jobs with completed and
unexecuted scope. candidate-review/ retains independent review and exact fixture
preservation evidence. focused/ binds this follow-up source/bootstrap snapshot,
normal bootstrap regeneration/identity and two complete focused targets5+6PASS.
No incomplete or failed run is credited a full pass. The final unfiltered
workspace command and final committed-head CI are separate required gates.
