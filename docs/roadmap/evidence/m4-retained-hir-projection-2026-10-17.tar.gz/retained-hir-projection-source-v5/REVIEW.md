Retained HIR / flat lowering projection v2 — frozen source review packet

Base 3a3898c; two Rust files, including NEW hir_projection.rs. Exact before/after
bytes, complete patch and hashes are in manifest.json/candidate.patch. SSA full
baseline leaf untouched. No Cargo/rustc/bootstrap/commit/push. Both files parsed
with rustfmt --emit stdout, without rewriting; git diff --check passes.

Ownership and entry routes
- Callable SourceMethod.body and LocalBinding.initializer use actual Arc<Hir>.
- SourceNode scalar children use their actual Arc<Hir>; collections/statements
  and argument lists retain actual Arc<[Hir]> plus checked index.
- Field/role access roots use their actual Arc<Hir>.
- Borrowed/synthetic ast(&Hir) remains a metered clone_hir fallback. It allocates
  a charged Arc owner afterward; its one enqueue HIR copy regression remains.
- A private arena retains the complete selected root (including unexported
  metadata, syntax, globals, captures, spans and source facts). Its node records
  contain ONLY the previously exported lowering operation/detail and original
  SourceAnalysis Arc plus direct child node-ID range. Executable children are enumerated
  in exactly old lowering_record order, including optional async and all methods.
- Forward child ordinals refer to private nodes. No pointer lookup/interning,
  unsafe reference, cross-pass cache or source authority from an ordinal. Node
  resolution is O(1); no chained owner/path traversal or O(depth^2) path replay.

Queue and first-seen semantics
Ast/Lowering Task variants now carry a View. AST source memo lookup remains
before creating a new task. No source memo is populated by arena traversal.
The same SourceArc with different lowered HIR still returns the original queued
AST/lowering winner. ast_record retains exact source, performs the same existing
form/environment work, then MOVES its view into a Lowering task at the old queue
position. lower children call ast_view in their original order. Source-node
children still select original source HIR, never substitute executable children.
All existing source_boundary Owner variants, constructors, live method/prototype
checks and guest hash callbacks remain in place. No callback in projection build.

All exported lowering fields retained
suss/operation; suss/value or suss/undefined; suss/id; suss/native-operator;
suss/loop-id; suss/children. Operation names and all Expression child order are
copied from the old lowering_record match. Global/source binding facts stay in
source AST fields as before; no unexported HIR field is removed from its owner.

Guard audit: old copy vs validation
clone_hir_metered -> cow_hir (hir/local_bindings.rs) recursively constructs owned
HIR, copies metadata via cow_forms/clone_form_metered, clones actual UTF16/text,
retains immutable owners and checks requested allocation arithmetic/failure.
clone_form_metered reconstructs even Conditional/Prefix/Discard forms: it is
NOT validate_form_data and supplies no reader-prefix/schema/equality/cycle
certificate. Those copying/allocation operations are genuinely absent on retained
routes; their old allocation-overflow paths are replaced with checked new arena
allocation paths, not a successful decline after errors.
No validate_form_data call was removed. In particular declaration definition_form
AND declaration guards still precede origin/recipe lookup; ast_record source.form
and quote/datum guards, source metadata normalization, original-form provenance,
Form/raw-key validation and graph cycle checks remain. No new duplicate semantic
validator was invented for immutable unexported HIR payloads. New arena edges are
forward-only by construction; graph/source cycles still use original handling.

Meter and allocation accounting
Every new arena/header/stack-metadata/backing allocation is prepaid; reserve uses
checked requested capacity plus relocation and fallible try_reserve_exact. Every
push prepays entry initialization/release. Every SourceArc/owner/View retain pays
release at acquisition; cleanup is NOT first charged at successful build end.
Early meter failures therefore drop only already prepaid private acquisition.
Projection literal UTF16 makes ONE explicit metered buffer copy. Passing that
literal to scalar makes ANOTHER explicitly metered copy; scalar's preexisting
kind/key work remains unchanged. Retaining the original HIR buffer is NOT a
claim that these two payload copies disappear. The fallback test's old 'no second
copy' wording is qualified accordingly, and new tests check distinct buffers.
Lowering child result backing is now exact/fallible/prepaid before pushes.
No quota/rate change, refill or suppressed error. General historical graph
Vec/BTree publication/drop accounting outside these new stores is not repaired
or claimed globally complete. Owner-retain accounting does not purport to solve
all preexisting final-Arc native-fact destruction accounting.

Cost/complexity qualifications
One selected root arena traverses executable HIR once, with constant-time child
selection, checked growth and direct child ranges. Separate genuine owners may still
project overlapping lowered trees: this is NOT a global linearity/all-copy-removal
claim. New projection backing, retained sources and literal copies can offset
removed HIR/metadata/capture copies. No 6.6M historical interval is attributed to
cloning, no actual runtime/cost saving yet. Tests print node/edge/layout/charge
counts and compare actual metered old-copy work for one metadata-heavy fixture;
that fixture assertion is not evidence until executed and not a whole-CoreEnv
cost model. Eager private projection work can change fuel exhaustion position;
no new guest operation, source/schema decision, or silent error normalization.

Regressions (all UNEXECUTED)
1. retained_projection_preserves_real_owner_and_all_ordered_lowering_children:
   real owner/metadata buffer preserved, independent equal owner not interned,
   callee/argument order incl NaN/-0, four nodes/three logical child slots, old/new copy charges.
2. flat_projection_handles_deep_and_wide_executable_trees_without_path_replay:
   depth/width 16 and 64, all child ordinals/literal values retained, cost prints.
3. projection_every_charge_failure_releases_private_storage_and_retry_pays_full_work:
   each observed charge fails with actual typed OOF or ForeignValue; no leaked
   owner; full identical retry charges and UTF16/surrogate bytes. Separate
   original/projection/scalar-input buffers explicitly checked.
4. retained_ast_root_keeps_original_buffers_first_seen_revision_and_decoded_lowering:
   roots on/off, genuine HIR buffer at enqueue, same SourceArc changed lowering
   preserves first queued task, complete decoded AST equals fallback after GC,
   owner release and actual Session IRQ propagation.
Existing graph_ast_moves_owned_hir_buffer_to_lowering_and_keeps_source_metadata
still checks one fallback enqueue HIR copy, the SAME HIR buffer moved to lowering,
exact source/spans/metadata and mandatory exported lowering/capture roots. Updated
strong count explicitly accounts the new projection SourceArc retain.

Root/Carver review required before producer. Recommended first compile + these
five focused gates after normal bootstrap, then existing source/namespace/callback/
malformed/memo/domain suites before performance witnesses. No acceptance claim.

V2 bounded storage revision (v1 packet preserved separately)
Pass 1 builds only the metered borrowed BFS queue. No deduplication means each
parent's children are contiguous in that queue. Pass 2 recounts children through
the same immutable bounded iterator and assigns the next consecutive child IDs,
with checked range/end consistency. Final nodes reserve EXACT requested queue
length once, so no Node relocation/growth; the redundant edge backing and all
edge append/copy work are removed. Both passes' node/child visits are metered.
Pending queue growth remains charged. Every node/owner/entry/drop is still paid
before acquisition. No graph AST memo or job is published during either pass.
Private child lookup remains O(1). Test logical child counts do not imply an
allocated edge table. No global linearity across independent root arenas claim.
V2 changed only arena storage; V3 additionally changes root memo admission. New module hash and complete
patch are in v2 manifest. No execution; possible source/API/test failures still
require focused compilation and actual default-fuel measurement after review.

V3 memo admission revision (v1/v2 packet bytes retained)
All root paths check the existing source memo ONCE before any owner retain or
fallback copying. On a miss, pure private projection cannot mutate graph memos
or run guest callbacks; enqueue_unobserved_view therefore does not look up again.
Projected-child ast_view still performs its own first-seen lookup at original
scheduling time. Source-less lowering still queues as before. Slice selection
has a prepaid bounds read before memo lookup; no source pointer authority added.
New existing-test assertion measures one charge and unchanged owner/job counts
on retained-root memo hit. Same SourceArc with different lowered HIR continues
to preserve original queued lowering. Exact three source versions are retained;
this V3 is the candidate frozen for root/Carver review before any producer.

V4 final TEST-ONLY readiness strengthening; no further algorithm expansion
The graph regression now measures actual queue work for shared vs borrowed
fallback routes (BOTH include projection costs), asserts shared queue costs less,
and verifies shared retains original HIR while fallback owns an actual copy.
The pure metadata-heavy fixture independently compares original clone_hir work
with new projection work. These are bounded fixture assertions, not a historical
whole-pipeline saving claim. Deep/wide measured charges now assert <5x growth
for 4x depth/width, in addition to exact child values/counts and printed costs.

Borrowed fallback DOES add arena and explicit literal-payload copies on top of
its old HIR clone. No claim it improves. Shared routes remove genuine recursive
HIR/metadata/capture cloning only; projection/scalar payload copies remain paid.
Production paths select retained actual Arc/slice owners; all gates UNEXECUTED.
Source now frozen; root owns normal bootstrap, compilation, focused regressions,
unchanged default CoreEnv and three original witnesses. No additional profiles
or cap probes requested. Earlier V1/V2/V3 attempts remain in separate cache paths.

V5 bounded compile corrections (v4 failed attempt retained)
FieldBinding.access is owned Hir: route it to restored lowering(&Hir) fallback,
which uses the existing clone_hir meter, then charged Arc ownership/projection,
and queues Lowering directly. No fake shared ownership, changed FieldBinding
shape or new AST source boundary. Arc-backed role access routes stay shared.
Fallback therefore retains its real HIR copy plus projection cost; no gain claim.
Error messages are static literals; invalid now explicitly takes &'static str,
matching wasmtime::Error::msg's required lifetime without new String allocation.
No tests/criteria changed. V4-to-V5.patch isolates these bounded corrections.
V4 bootstrap compile101 and all tests unexecuted remain factual; V5 is unbuilt.
