from pathlib import Path
import json,hashlib,tarfile,io,re
c=Path('/home/bobby/.cache/suss-m4-work');o=c/'primitive-string-root-success';payload={};rows={};limits=[]
for name in ['before','candidate']:
 s=json.loads((o/(name+'-result.json')).read_text());assert s['current'] is None and s['source_unchanged'];r=Path(s['worktree'])
 for f,h in s['freeze'].items():
  b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+name+'/'+f]=b
 inputs=['Cargo.toml','Cargo.lock','crates/suss-compile/build.rs','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json']+['vendor/wasi/wasi-wit-0.3.1/cli/'+f for f in ['cli.wit','deps/clocks.wit','deps/filesystem.wit','deps/random.wit','deps/sockets.wit']]
 for n in ['suss-core','suss-reader','suss-compile']:
  inputs.append('crates/'+n+'/Cargo.toml');inputs.extend(str(p.relative_to(r)) for p in (r/'crates'/n/'src').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus'])
 h=hashlib.sha256();input_hashes={}
 for f in sorted(inputs,key=lambda p:tuple(p.split('/'))):
  b=(r/f).read_bytes();n=f.encode();h.update(len(n).to_bytes(8,'little')+n+len(b).to_bytes(8,'little')+b);input_hashes[f]=hashlib.sha256(b).hexdigest();payload['support/'+name+'/'+f]=b
 assert h.hexdigest()==s['compiler_fingerprint'];(o/(name+'-end-fingerprint.json')).write_text(json.dumps({'start_aggregate':s['compiler_fingerprint'],'end_aggregate':h.hexdigest(),'equal':True,'critical_input_end_hashes':input_hashes,'qualification':'Critical-input aggregate recomputed before launch and after terminal; individual critical support bytes captured after execution. Rust/Suss/CLJS/bootstrap paths individually frozen before/after.'},indent=2)+'\n')
 raw=(o/(name+'.log')).read_text();items=re.findall(r'root-success-probe (runtime|macro): (\[[^\n]+)',raw);assert [x[0] for x in items]==['runtime','macro'];rows[name]=dict(items);assert s['exit']==0
expected='[66 17 true 66 [1 2 3 4]]';assert all(row==expected for pair in rows.values() for row in pair.values());comparison={'guest_sha256':'33fde62f0f7eea4377c1b642afbb2d7370a0fb961b11989a6dacc299c17e6f53','pinned_expected':expected,'observed':rows,'all_four_phase_rows_match':True,'scope':'One ordinary custom-field mutation during argument evaluation. Original failed reserved-root test and caught-write control remain unchanged and are not rerun here. No full baseline/CI/complete String contract claim.'};(o/'comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
for p in o.iterdir():
 if p.is_file() and not p.name.endswith('.tar.gz'):payload['raw/'+p.name]=p.read_bytes()
for f in ['run-primitive-string-root-success.py','package-primitive-string-root-success.py']:payload['runners/'+f]=(c/f).read_bytes()
oracle=c/'m4-primitive-string-root-success-oracle-2026-10-16.tar.gz';b=oracle.read_bytes();assert hashlib.sha256(b).hexdigest()=='f3d3cb48235a393fa66ce8b54d962d5700c713fbcdd308c59a5659e257bfa988';payload['oracle/'+oracle.name]=b
m={n:hashlib.sha256(b).hexdigest() for n,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(m,indent=2).encode();out=o/'m4-primitive-string-root-success-matched-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,b in sorted(payload.items()):
  info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
result={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(m),'freeze_each':{name:len(json.loads((o/(name+'-result.json')).read_text())['freeze']) for name in ['before','candidate']}};(c/'primitive-string-root-success-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
