from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-cold-reader-identifiers');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'cold-reader-identifiers-target'),RAYON_NUM_THREADS='2')
state={'base':'d58e693','production_fix':False,'stages':[]};receipt=c/'cold-reader-before-result.json'
commands=[('compile',['cargo','test','-p','suss-compile','--lib','--locked','native_memo_leaf_','--no-run']),('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('native',['cargo','test','-p','suss-compile','--lib','--locked','native_memo_leaf_','--','--test-threads=2','--nocapture'])]
for name,cmd in commands:
 state['current']=name;receipt.write_text(json.dumps(state,indent=2)+'\n');start=time.time()
 if name=='native':
  files=[p for p in (r/'crates').rglob('*') if p.suffix in ['.rs','.sus']]+list((r/'runtime/bootstrap').glob('*'));state['freeze']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
 with (c/('cold-reader-before-'+name+'.log')).open('w') as log:child=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 state['stages'].append({'name':name,'command':cmd,'exit':child.returncode,'seconds':time.time()-start})
 if child.returncode and name!='native':break
state['current']=None
if 'freeze'in state:state['source_unchanged']=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in state['freeze'].items())
receipt.write_text(json.dumps(state,indent=2)+'\n')
