from pathlib import Path
import subprocess,os,json,hashlib,time,fcntl,re,signal
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss-m4-pr268-sparse-setter');T=C/'m4-cost-diagnostic-target';O=C/'native-field-plan-view-focused-v1';P=C/'native-field-plan-view-combined-source-v2';BOOT={f'runtime/bootstrap/{p}.{e}' for p in ('macro','runtime') for e in ('wasm','json')}
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def git(*a,root=R):return subprocess.check_output(['git','-C',str(root),*a])
manifest=json.loads((P/'manifest.json').read_text())
assert git('rev-parse','HEAD').decode().strip()==manifest['base']
assert git('rev-parse','HEAD',root=R/'clojurescript').decode().strip()=='c4295f303100bbf5afac449242d30bca1126f1a1'
assert not git('status','--porcelain',root=R/'clojurescript').strip()
assert not git('diff','--cached','--name-only').strip()
for f,h in manifest['files'].items():assert sha((R/f).read_bytes())==h
tracked=set(git('diff','--name-only').decode().splitlines());untracked=set(git('ls-files','--others','--exclude-standard').decode().splitlines())
assert tracked|untracked==set(manifest['files'])|BOOT,(tracked,untracked)
approval={'root_execution':'Compile-only gate passed. Test-only native codec/prefix; no shipping field admission or runtime-win claim.'}
stages=[{'name': 'bootstrap', 'command': ['cargo', 'run', '--profile', 'test', '-p', 'suss-cli', '--bin', 'suss-bootstrap', '--locked', '--', 'runtime/bootstrap'], 'selected_names': []}, {'name': 'native-field-plans', 'command': ['cargo', 'test', '--locked', '-p', 'suss-compile', '--lib', 'portable_macro_graph::raw_keys::', '--', '--test-threads=1', '--nocapture'], 'selected_names': ['portable_macro_graph::raw_keys::tests::scratch_hits_retain_allocation_and_misses_transfer_exact_bytes', 'portable_macro_graph::raw_keys::tests::repeated_plans_preserve_every_canonical_byte_and_id', 'portable_macro_graph::raw_keys::tests::compact_sizes_keep_adjacent_integer_boundaries_exact', 'portable_macro_graph::raw_keys::tests::raw_ids_match_legacy_exact_equivalence_pairwise', 'portable_macro_graph::raw_keys::tests::comparator_bills_only_inspected_bytes_and_polls_empty_input', 'portable_macro_graph::raw_keys::tests::forced_collision_chain_is_exact_and_failure_atomic', 'portable_macro_graph::raw_keys::tests::every_intern_failure_point_preserves_table_and_next_id', 'portable_macro_graph::raw_keys::tests::collision_comparison_fuel_and_chain_growth_preserve_ids', 'portable_macro_graph::raw_keys::tests::fuel_exhaustion_in_hashing_does_not_publish', 'portable_macro_graph::raw_keys::tests::deep_plan_has_linear_direct_edges_and_flat_key_storage', 'portable_macro_graph::raw_keys::tests::failed_plan_discards_incomplete_nodes_and_recovers', 'portable_macro_graph::raw_keys::tests::binding_failure_does_not_publish_and_sparse_ids_recover', 'portable_macro_graph::raw_keys::tests::paged_entry_boundary_collision_publication_is_atomic_at_all_fuel_irq_cuts', 'portable_macro_graph::raw_keys::raw_heads::tests::placement_collisions_growth_existing_heads_and_absence', 'portable_macro_graph::raw_keys::raw_heads::tests::every_insufficient_growth_allowance_preserves_old_heads_then_recovers', 'portable_macro_graph::raw_keys::raw_heads::tests::every_growth_charge_irq_cut_preserves_old_heads_then_recovers', 'portable_macro_graph::raw_keys::raw_heads::tests::first_allocation_no_growth_and_hit_preserve_heads_at_every_stop', 'portable_macro_graph::raw_keys::raw_heads::tests::checked_capacity_rejects_native_layout_overflow', 'portable_macro_graph::raw_keys::raw_heads::tests::compact_encoding_bounds_are_explicit_and_full_hashes_remain_unrestricted', 'portable_macro_graph::raw_keys::raw_heads::tests::compact_slots_match_legacy_heads_and_remove_real_backing_work', 'portable_macro_graph::raw_keys::canonical_entries::tests::pages_preserve_all_ids_links_payloads_and_old_page_addresses', 'portable_macro_graph::raw_keys::canonical_entries::tests::every_prepare_fuel_irq_cut_preserves_logical_entries_and_retry', 'portable_macro_graph::raw_keys::canonical_entries::tests::native_overflow_is_explicit_before_any_entry_publication', 'portable_macro_graph::raw_keys::canonical_entries::tests::prepared_heads_preserve_actual_owner_index_and_cancel_before_publication', 'portable_macro_graph::raw_keys::native_prefix::prefix_and_dynamic_suffix_match_original_plan_rows_and_global_ids', 'portable_macro_graph::raw_keys::native_prefix::prefix_and_suffix_forced_collisions_still_require_full_byte_equality', 'portable_macro_graph::raw_keys::native_prefix::prefix_failure_cuts_leave_private_plan_empty_and_original_ids_retryable', 'portable_macro_graph::raw_keys::native_prefix::borrowed_prefix_and_local_suffix_match_original_byte_plans_without_key_copies', 'portable_macro_graph::raw_keys::native_prefix::borrowed_prefix_collisions_reject_duplicates_and_preserve_suffix_identity', 'portable_macro_graph::raw_keys::native_prefix::borrowed_prefix_build_faults_publish_no_table_and_retries_match', 'portable_macro_graph::raw_keys::field_plan_artifact::completed_catalog_field_artifact_roundtrip_and_owner_binding', 'portable_macro_graph::raw_keys::field_plan_artifact::artifact_decoder_rejects_shape_identity_and_occurrence_corruption', 'portable_macro_graph::raw_keys::field_plan_artifact::original_byte_equality_survives_forced_bucket_collisions', 'portable_macro_graph::raw_keys::field_plan_artifact::artifact_bound_lookup_rejects_equal_copies_revisions_fields_phases_and_public_restore', 'portable_macro_graph::raw_keys::field_plan_artifact::artifact_decode_bind_and_publication_fault_cuts_leave_no_partial_install_and_retry', 'portable_macro_graph::raw_keys::field_plan_artifact::field_plan_view::streamed_view_all_catalog_fields_match_original_and_owned_with_separate_startup_costs', 'portable_macro_graph::raw_keys::field_plan_artifact::field_plan_view::streamed_view_rejects_owned_negative_corpus_and_forced_collision_duplicates', 'portable_macro_graph::raw_keys::field_plan_artifact::field_plan_view::streamed_view_native_fault_cuts_retry_and_checked_access_domains']}]
if '--execute' not in __import__('sys').argv:print(json.dumps(stages,indent=2));raise SystemExit()
assert not O.exists()
leases=[]
assert T.is_dir()
h=(T/'.sparse-array-set-repair.lease').open('a+');fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(h)
for p in sorted(T.iterdir()):
 if p.is_file() and p.name.endswith(('.lease','.lock')) and p.name not in ('.cargo-lock','.sparse-array-set-repair.lease'):
  h=p.open('a+');fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(h)
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=str((p/'exe').resolve());cmd=(p/'cmdline').read_bytes()
 except (OSError,PermissionError):continue
 assert not exe.startswith(str(T)+'/'),f'target process {p.name}'
 if Path(exe).name in ('cargo','rustc'):
  assert str(T).encode() not in cmd
  try:process_env=(p/'environ').read_bytes()
  except (OSError,PermissionError):process_env=b''
  assert b'CARGO_TARGET_DIR='+str(T).encode()+b'\0' not in process_env

def freeze():
 paths=set()
 for prefix,repo in [('',R),('clojurescript/',R/'clojurescript')]:
  for x in git('ls-files','-z','--cached','--others','--exclude-standard',root=repo).split(b'\0'):
   if not x:continue
   f=os.fsdecode(x)
   if not prefix and f=='clojurescript':continue
   paths.add(prefix+f)
 for folder in (R/'crates',R/'runtime'):
  for base,dirs,files in os.walk(folder):
   dirs[:]=[x for x in dirs if x not in ('target','.git','out','node_modules','__pycache__')]
   paths.update(str((Path(base)/f).relative_to(R)) for f in files if Path(f).suffix in ('.rs','.sus'))
 return {f:sha((R/f).read_bytes()) for f in sorted(paths)}
expected=freeze();O.mkdir();dump(O/'before.json',expected);(O/'driver.py').write_bytes(Path(__file__).read_bytes());(O/'source-manifest.json').write_bytes((P/'manifest.json').read_bytes());(O/'source-approval.json').write_text(json.dumps(approval,indent=2));dump(O/'selection.json',stages)
for f in BOOT:
 dst=O/'before-bootstrap'/f;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((R/f).read_bytes())
state={'driver_pid':os.getpid(),'head':manifest['base'],'input_count':len(expected),'target':str(T),'current':None,'stages':[],'limits':'38 source-derived native tests:24existing+6prefix+5owned-artifact+3views. Normal bootstrap regenerated for current compiler fingerprint. No Graph prefix/field admission or actual default-request success claim. Native injected fault surrogates are not Session IRQ evidence.'}
code=0
proc=None
controller_error=None
try:
 for stage in stages:
  assert freeze()==expected
  row=dict(stage);row['execution']='UNEXECUTED';state['stages'].append(row);state['current']=stage['name'];dump(O/'receipt.json',state)
  env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(T))
  for k in list(env):
   if k.startswith('SUSS_') and (k.endswith('TRACE') or 'CAPTURE' in k):env.pop(k)
  if stage['name']=='unordered-profile':env.update(SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1',SUSS_SOURCE_MATERIALIZE_FUEL_TRACE='1',SUSS_RAW_KEY_TRACE='1')
  start=time.monotonic()
  with (O/(stage['name']+'.log')).open('wb') as log:
   proc=subprocess.Popen(stage['command'],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row.update(pid=proc.pid,pgid=proc.pid,execution='RUNNING');dump(O/'receipt.json',state);code=proc.wait()
  after=freeze();changed=[f for f in sorted(expected.keys()|after.keys()) if expected.get(f)!=after.get(f)];row.update(exit=code,seconds=time.monotonic()-start,changed=changed)
  if stage['name']=='bootstrap':
   row['execution']='PASS' if code==0 else 'FAIL'
   assert set(changed)<=BOOT
   if code==0:
    expected=after;dump(O/'after-bootstrap.json',after)
    for f in BOOT:
     dst=O/'bootstrap'/f;dst.parent.mkdir(parents=True,exist_ok=True);b=(R/f).read_bytes();assert sha(b)==expected[f];dst.write_bytes(b)
  else:
   assert not changed
   text=(O/(stage['name']+'.log')).read_text(errors='replace')
   found=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
   names=re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\.',text,re.M)
   row['actual_test_starts']=names
   counts=tuple(map(int,found[0])) if len(found)==1 else None
   established=counts is not None and sum(counts)==len(stage['selected_names']) and counts[2]==0 and sorted(names)==sorted(stage['selected_names'])
   row['selection_established']=established
   if counts is not None:row['counts']=dict(zip(('pass','fail','ignore'),counts))
   if established:row['execution']='PASS' if code==0 and counts[1]==0 else 'FAIL'
   else:row['execution']='UNESTABLISHED: compile/setup/zero-test/incomplete exact selection; no probe execution credit'
   dump(O/'receipt.json',state)
   if not established and code==0:raise RuntimeError('Zero or incomplete exact test selection despite exit0')
  dump(O/'receipt.json',state)
  if code:break
except BaseException as error:
 controller_error=repr(error);state['controller_error']=controller_error;code=code or 1
 if state['stages'] and state['stages'][-1]['execution']=='RUNNING':state['stages'][-1]['execution']='UNESTABLISHED: controller interrupted; raw partial log retained'
finally:
 # Observation timeouts never terminate this producer. Only an actual controller
 # exception/interruption cleans its own new-session child group before release.
 if controller_error is not None and proc is not None:
  try:
   os.killpg(proc.pid,signal.SIGTERM);state['own_group_cleanup']='SIGTERM'
  except ProcessLookupError:pass
  if proc.poll() is None:
   try:proc.wait(timeout=30)
   except subprocess.TimeoutExpired:
    try:os.killpg(proc.pid,signal.SIGKILL);state['own_group_cleanup']='SIGKILL after30s'
    except ProcessLookupError:pass
    proc.wait()
  state['own_child_terminal_exit']=proc.returncode
  def own_group_live():
   for entry in Path('/proc').iterdir():
    if not entry.name.isdigit():continue
    try:parts=(entry/'stat').read_text().rsplit(') ',1)[1].split()
    except (OSError,IndexError):continue
    if parts[0] not in ('Z','X') and int(parts[2])==proc.pid and int(parts[3])==proc.pid:return True
   return False
  deadline=time.monotonic()+10
  while own_group_live() and time.monotonic()<deadline:time.sleep(.1)
  if own_group_live():
   try:os.killpg(proc.pid,signal.SIGKILL);state['own_group_cleanup']='SIGKILL remaining own descendants'
   except ProcessLookupError:pass
   deadline=time.monotonic()+10
   while own_group_live() and time.monotonic()<deadline:time.sleep(.1)
  state['own_group_live_after_cleanup']=own_group_live()
 try:
  terminal=freeze();state['final_changed']=[f for f in sorted(expected.keys()|terminal.keys()) if expected.get(f)!=terminal.get(f)];dump(O/'terminal.json',terminal)
 except BaseException as error:state['terminal_freeze_error']=repr(error)
 state['current']=None
 state['unexecuted_stages']=[s['name'] for s in stages[len(state['stages']):]]
 dump(O/'receipt.json',state)
print(json.dumps({'head':state['head'],'stages':[{k:v for k,v in r.items() if k in ('name','exit','execution','seconds','counts')} for r in state['stages']],'unexecuted':state['unexecuted_stages'],'final_changed':state.get('final_changed'),'controller_error':state.get('controller_error')}));raise SystemExit(code)
