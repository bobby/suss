from pathlib import Path,PurePosixPath
import argparse,os,json,hashlib,subprocess,tarfile
ap=argparse.ArgumentParser();ap.add_argument('--package',type=Path,required=True);ap.add_argument('--ref',required=True);ap.add_argument('--parent',required=True);ap.add_argument('--report-name',required=True);ap.add_argument('--title',required=True);ap.add_argument('--body',required=True);args=ap.parse_args()
R=Path('/home/bobby/Work/code/bobby/suss');P=args.package;assert P.is_relative_to('/home/bobby/.cache/suss-m4-work');assert args.ref.startswith('refs/heads/experiment/')
d=json.loads((P/'package-result.json').read_text());a=Path(d['archive']);assert hashlib.sha256(a.read_bytes()).hexdigest()==d['sha256'];idx=P/'snapshot.index';assert not idx.exists();env=os.environ.copy();env['GIT_INDEX_FILE']=str(idx)
def git(*xs,data=None):return subprocess.check_output(['git','-C',str(R),*xs],env=env,input=data)
def add(path,b):
 assert not PurePosixPath(path).is_absolute() and '..' not in PurePosixPath(path).parts
 blob=git('hash-object','-w','--stdin',data=b).decode().strip();git('update-index','--add','--cacheinfo',f'100644,{blob},{path}')
assert git('rev-parse',args.ref).decode().strip()==args.parent;git('read-tree',args.parent)
with tarfile.open(a) as t:
 ms=t.getmembers();names=[m.name for m in ms];assert len(names)==len(set(names)) and all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in ms);m=json.load(t.extractfile('MANIFEST.json'));m=m.get('files',m);assert set(names)==set(m)|{'MANIFEST.json'}
 for name,h in m.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==(h['sha256'] if isinstance(h,dict) else h)
 for f,b in d['snapshot_paths'].items():
  data=t.extractfile(b['payload']).read();assert hashlib.sha256(data).hexdigest()==b['sha256'];add(f,data)
report=(P/'REPORT.md').read_bytes();assert hashlib.sha256(report).hexdigest()==d['report_sha256'];add('docs/roadmap/evidence/'+args.report_name,report);add('docs/roadmap/evidence/'+a.name,a.read_bytes())
tree=git('write-tree').decode().strip();commit=git('commit-tree',tree,'-p',args.parent,data=(args.title+'\n\n'+args.body+'\n').encode()).decode().strip();git('update-ref',args.ref,commit,args.parent)
result={'commit':commit,'parent':args.parent,'tree':tree,'ref':args.ref,'archive_sha256':d['sha256'],'root_review':f'{len(ms)}safe members/{len(m)}allhashes verified;{len(d["snapshot_paths"])}exact snapshot payloads'};(P/'snapshot-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
