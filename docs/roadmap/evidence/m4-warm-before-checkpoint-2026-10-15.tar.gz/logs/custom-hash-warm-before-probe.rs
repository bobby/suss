use suss_cli::{portable_session::Session, portable_macros::CompiledMacros};
// OUTSIDE-REPO DRAFT; uncompiled/unexecuted.
// Insert in compiled_macro_cumulative_fuel.rs, using existing Session and
// CompiledMacros imports. No quota changes or weakening of forgery tests.
// Reference: metadata_custom_hash_order.cljs warm-before-replacement probe.
// CLJS delegates original; this supplemental Suss case uses equivalent public
// manual body. Warm-hit returns the existing memo; constant91 returns91.
// Both successful paths leave the old memo unchanged.
#[test]
fn source_metadata_keeps_canonically_warmed_identity_after_hash_replacement() {
    const OBSERVE: &str = r#"
      (defmacro prime-before-replacement []
        (def warm-before-dispatches 0)
        (let [m (:meta (get (:defs (:ns &env)) 'warm-before-target))
              a (:audit m)
              before (.-__hash a)
              h (hash a)
              after (.-__hash a)]
          (def saved-warm-before-metadata m)
          (def saved-warm-before-audit a)
          (def saved-warm-before-memo after)
          (list 'quote [(nil? before) (number? after)
                        (= h after) (= 17 (:x a))])))
      (defmacro inspect-warm-before [hit expected-hash]
        (let [m (:meta (get (:defs (:ns &env)) 'warm-before-target))
              a (:audit m)
              old-before (.-__hash saved-warm-before-audit)
              actual-before (.-__hash a)
              calls-before warm-before-dispatches
              h (if hit (hash a) nil)
              calls-after warm-before-dispatches
              old-after (.-__hash saved-warm-before-audit)
              actual-after (.-__hash a)]
          (list 'quote
            [(identical? saved-warm-before-metadata m)
             (identical? saved-warm-before-audit a)
             (number? old-before)
             (number? actual-before)
             (identical? old-before saved-warm-before-memo)
             (identical? actual-before saved-warm-before-memo)
             (= 17 (:x saved-warm-before-audit))
             (= 17 (:x a))
             (if hit (= h (if (nil? expected-hash) saved-warm-before-memo expected-hash)) true)
             (identical? old-after old-before)
             (identical? actual-after actual-before)
             (= calls-after (if hit (inc calls-before) calls-before))
             (if hit (if (nil? expected-hash) (identical? h actual-before) (= h expected-hash)) true)])))
    "#;
    const INSTALL: &str = r#"
      (defmacro install-warm-before [constant]
        (extend-type PersistentArrayMap IHash
          (-hash [self]
            (do
              (if (identical? self saved-warm-before-audit)
                (set! warm-before-dispatches (inc warm-before-dispatches)) nil)
              (if constant 91
                (let [memo (.-__hash self)]
                  (if (nil? memo)
                    (let [h (hash-unordered-coll self)]
                      (set! (.-__hash self) h) h)
                    memo)))))) nil)
    "#;
    let all_true = |n| format!("[{}]", vec!["true"; n].join(" "));
    // Preserve completed rows even if a later setup/evaluation stage errors.
    let mut observations: Vec<(String, String, String, String)> = Vec::new();
    let mut errors = Vec::new();
    for constant in [false, true] {
      for macro_caller in [false, true] {
        let phase = format!("{} / {}",
            if macro_caller { "Macro" } else { "Runtime" },
            if constant { "constant91" } else { "manual-warm-hit" });
        let mut stage = "create";
        let run = (|| -> Result<(), String> {
            let mut caller = if macro_caller { Session::new_macro() }
                             else { Session::new_repl() }
                .map_err(|e| e.to_string())?;
            stage = "declare";
            caller.eval("(def ^{:audit {:x 17}} warm-before-target 17)")
                .map_err(|e| e.to_string())?;
            let mut macros = CompiledMacros::new().map_err(|e| e.to_string())?;
            let observer_start = OBSERVE.find("(defmacro inspect-warm-before").unwrap();
            stage = "define-prime";
            macros.define(&OBSERVE[..observer_start]).map_err(|e| e.to_string())?;
            let expected_hash = if constant { "91" } else { "nil" };
            let before = format!("(do (inspect-warm-before false {expected_hash}))");
            let hit = format!("(inspect-warm-before true {expected_hash})");
            let after = format!("(let [] (inspect-warm-before false {expected_hash}))");
            for (label, source, count) in [
                ("canonical-warm", "(prime-before-replacement)", 4),
                ("canonical-next-call", "(inspect-warm-before false nil)", 13),
                ("custom-before-hit", before.as_str(), 13),
                ("custom-hit", hit.as_str(), 13),
                ("custom-after-hit", after.as_str(), 13),
            ] {
                stage = label;
                if label == "canonical-next-call" {
                    stage = "define-observer";
                    macros.define(&OBSERVE[observer_start..]).map_err(|e| e.to_string())?;
                    stage = label;
                }
                if label == "custom-before-hit" {
                    stage = "install";
                    macros.define(INSTALL).map_err(|e| e.to_string())?;
                    caller.eval_with_macros(
                        if constant { "(install-warm-before true)" }
                        else { "(install-warm-before false)" }, &mut macros)
                        .map_err(|e| e.to_string())?;
                    stage = label;
                }
                caller.collect().map_err(|e| e.to_string())?;
                let value = caller.eval_with_macros(source, &mut macros)
                    .map_err(|e| e.to_string())?;
                let actual = suss_cli::portable_repl::display(&mut caller, &value)
                    .map_err(|e| e.to_string())?;
                observations.push((phase.clone(), label.into(), actual, all_true(count)));
            }
            Ok(())
        })();
        if let Err(error) = run { errors.push(format!("{phase} {stage}: {error}")); }
      }
    }
    // No identity assertion stops remaining observations or the other phase.
    for (phase, stage, actual, expected) in &observations {
        if actual != expected {
            errors.push(format!("{phase} {stage}: {actual}; expected {expected}"));
        }
    }
    assert!(errors.is_empty(), "observations={observations:?}\n{}", errors.join("\n"));
}

// Interpretation:
// canonical-next-call isolates preexisting canonical receipt retention before
// any replacement. custom-before-hit isolates invalidation by installation alone.
// custom-hit hashes the CURRENT audit: rebuilt roots cannot fake saved-receiver
// counter increments, and a miss cannot masquerade as preserving the old memo.
// The miss branch remains legitimate executable user behavior but the intended
// successful path is exclusively an already-warm hit, avoiding new custom-write
// authorization as a prerequisite for this separate regression.
// Counter differences bracket only explicit hash inside macro execution; do not
// infer a zero-transport-callback policy. Both phases use independent macrohosts.

// Constant91 checks current hash result91 without treating the old memo as the
// hash result. The saved and current memo boxes must remain identical throughout.
// Each (variant, caller phase) creates a fresh Session and CompiledMacros host.
