from pathlib import Path
import subprocess,os,json,hashlib,time,sys,datetime
root=Path('/home/bobby/Work/code/bobby/suss-m4-pr268-capture-index');out=Path('/home/bobby/.cache/suss-m4-work/pr268-capture-index-acceptance-v1');out.mkdir(exist_ok=False)
manifest=json.loads(Path('/home/bobby/.cache/suss-m4-work/pr268-capture-index-candidate-v1/source-manifest.json').read_text())
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
cargo=['cargo','test','--locked'];tail=['--','--test-threads=1','--nocapture'];stages=[
('source-child',cargo+['-p','suss-compile','--lib','portable_macro_graph::source_roots::tests::source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo','--','--exact','--test-threads=1','--nocapture'],{'SUSS_SOURCE_CHILD_FUEL_TRACE':'1'}),
('core-import',cargo+['-p','suss-cli','--test','core_import']+tail,{}),
('collection-source',cargo+['-p','suss-cli','--test','compiled_macro_collection_source_asts']+tail,{'SUSS_MACRO_FUEL_TRACE':'1','SUSS_METADATA_FUEL_TRACE':'1'}),
('cljs-value-effects',cargo+['-p','suss-cli','--test','portable_short_property_observations']+tail,{}),
('pinned-map',cargo+['-p','suss-compile','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--exact','--test-threads=1','--nocapture'],{'SUSS_CLOJURE_TEST_SUITE_CAPTURE':str(out/'map-capture')})]
receipt={'root':str(root),'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':[],'current':None,'terminal':False}
def changed():return [r['path'] for r in manifest['files'] if hashlib.sha256((root/r['path']).read_bytes()).hexdigest()!=r['sha256']]
def save(): (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name,cmd,extra in stages:
 assert not changed();receipt['current']=name;save();stage_env=env.copy();stage_env.update(extra);started=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  process=subprocess.Popen(cmd,cwd=root,env=stage_env,stdout=log,stderr=subprocess.STDOUT);receipt['current_pid']=process.pid;save();code=process.wait()
 result={'name':name,'argv':cmd,'env_overrides':extra,'pid':process.pid,'exit':code,'seconds':round(time.monotonic()-started,3),'changed':changed()};receipt['stages'].append(result);receipt['current']=None;save();print(json.dumps(result),flush=True);assert not result['changed']
# Only independently decoded assertion comparisons can count as value evidence.
try:
 sys.path.insert(0,str(root/'scripts'));import clojure_test_suite as suite
 ref=json.loads((root/'tests/oracle/clojure-test-suite-observations.json').read_text());name='clojure.core-test.map/test-map';ns='clojure.core-test.map';ref.update(namespaces=[ns],tests=[name],assertions=[a for a in ref['assertions'] if a['test']==name],skips=[s for s in ref['skips'] if s['namespace']==ns]);capture=out/'map-capture/map-transport-observations.json';obs=json.loads(capture.read_text());counts,failures=suite.compare(ref,obs);ids=[[a['test'],a['ordinal']] for a in obs['assertions']];comparison={'counts':counts,'failures':failures,'ordered_ids_match':ids==[[name,i] for i in range(1,70)],'capture_sha256':hashlib.sha256(capture.read_bytes()).hexdigest()};(out/'map-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');receipt['map_comparison']=comparison['counts'];print(json.dumps({'map_comparison':comparison}),flush=True)
except Exception as failure:
 receipt['map_comparison_error']=repr(failure);print(json.dumps({'map_comparison_error':repr(failure)}),flush=True)
receipt['terminal']=True;receipt['current']=None;receipt['final_changed']=changed();receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
