from pathlib import Path
import subprocess,os,json,hashlib,time,datetime
root=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');out=Path('/home/bobby/.cache/suss-m4-work/shared-native-witness-acceptance-v1');out.mkdir(exist_ok=False)
paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0');files=[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths if p and (root/p).is_file()];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();(out/'source-manifest.json').write_text(json.dumps({'head':head,'files':files},indent=2)+'\n')
changed_paths=subprocess.check_output(['git','diff','--name-only','0e82cef','--','crates/suss-compile/src','runtime/bootstrap'],cwd=root,text=True).splitlines()
for rel in changed_paths:
 if (root/rel).is_file():
  dest=out/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((root/rel).read_bytes())
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','0e82cef','--','crates/suss-compile/src','runtime/bootstrap'],cwd=root))
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',SUSS_METADATA_FUEL_TRACE='1',SUSS_MACRO_FUEL_TRACE='1')
cargo=['cargo','test','--locked'];tail=['--','--exact','--test-threads=1','--nocapture'];stages=[('callable',cargo+['-p','suss-cli','--test','compiled_macro_namespace_identity','resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations']+tail),('namespace',cargo+['-p','suss-cli','--test','compiled_macro_namespace_identity','compiler_namespace_and_declaration_aliases_match_pinned_five_call_observations']+tail),('guards',cargo+['-p','suss-compile','--lib','source_roots::coherent::tests::','--','--test-threads=1','--nocapture'])]
r={'head':head,'inputs':len(files),'stages':[],'terminal':False,'current':None}
def changed():return [x['path'] for x in files if hashlib.sha256((root/x['path']).read_bytes()).hexdigest()!=x['sha256']]
def save():(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
for name,cmd in stages:
 assert not changed();r['current']=name;save();stage_env=env.copy();stage_env['SUSS_NAMESPACE_IDENTITY_OUTPUT']=str(out/(name+'.json'));start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  proc=subprocess.Popen(cmd,cwd=root,env=stage_env,stdout=log,stderr=subprocess.STDOUT);r['pid']=proc.pid;save();code=proc.wait()
 row={'name':name,'argv':cmd,'env_overrides':{k:stage_env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS','SUSS_METADATA_FUEL_TRACE','SUSS_MACRO_FUEL_TRACE','SUSS_NAMESPACE_IDENTITY_OUTPUT']},'exit':code,'seconds':time.monotonic()-start,'changed':changed()};r['stages'].append(row);r['current']=None;save();print(json.dumps(row),flush=True);assert not row['changed']
r['terminal']=True;save()
