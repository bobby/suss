from pathlib import Path
import subprocess,os,time,json,hashlib,shutil,re
cache=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access')
run=cache/'indexed-form-copy-checkpoint'
run.mkdir(exist_ok=False)
paths=set(json.loads((cache/'source-roots-combined-precompile-5-freeze.json').read_text()))
paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snapshot(label,hashes):
 (run/(label+'-freeze.json')).write_text(json.dumps(hashes,indent=2)+'\n')
 for rel in hashes:
  target=run/label/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
expected=freeze();snapshot('before',expected)
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(cache/'analyzer-literal-key-target'));env.pop('SUSS_HIR_COW_TRACE',None)
state={'current':None,'stages':[],'input_count':len(expected),'limits':'No allowance or tariff changes. Native unit tests and bootstrap precede Session proof tests; missing stages remain unexecuted.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
commands=[('compile',['cargo','test','-p','suss-compile','--locked','--lib','--no-run']),('ownership',['cargo','test','-p','suss-compile','--locked','--lib','portable::hir::local_bindings::ownership_tests::','--','--test-threads=2','--nocapture']),('origin',['cargo','test','-p','suss-compile','--locked','--lib','portable::origin::form_metadata::tests::','--','--test-threads=2','--nocapture']),('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('constructor-callback',['cargo','test','-p','suss-compile','--locked','--lib','portable_session::constructor_callback_tests::','--','--test-threads=2','--nocapture']),('deferred',['cargo','test','-p','suss-compile','--locked','--lib','portable_session::deferred_factory::tests::','--','--test-threads=2','--nocapture']),('source-child',['cargo','test','-p','suss-compile','--locked','--lib','portable_macro_graph::source_roots::tests::','--','--test-threads=2','--nocapture'])]
allowed={f'runtime/bootstrap/{phase}.{ext}' for phase in ['macro','runtime'] for ext in ['wasm','json']}
for name,cmd in commands:
 assert freeze()==expected,'Source changed before '+name
 state['current']=name;entry={'name':name,'command':cmd};state['stages'].append(entry);save();print('starting '+name,flush=True);start=time.monotonic()
 with (run/(name+'.log')).open('w') as f:result=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 after=freeze();changed=[p for p in expected if expected[p]!=after[p]]
 entry.update(exit=result.returncode,seconds=time.monotonic()-start,changed=changed)
 entry['summaries']=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', (run/(name+'.log')).read_text())
 if name=='bootstrap' and result.returncode==0 and set(changed)<=allowed:
  expected=after;snapshot('after-bootstrap',expected)
 elif changed:
  entry['unexpected_input_changes']=True;save();break
 save();print(json.dumps(entry),flush=True)
 if result.returncode:break
state['current']=None;final=freeze();state['final_changed']=[p for p,h in expected.items() if final[p]!=h];save();print(json.dumps(state),flush=True)
