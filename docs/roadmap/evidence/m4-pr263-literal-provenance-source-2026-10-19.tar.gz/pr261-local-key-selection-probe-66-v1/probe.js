'use strict';
const path=require('path');
const base='/home/bobby/.cache/suss-m4-work/memo-call-boundary-draft/out';
require(path.join(base,'goog/bootstrap/nodejs.js'));require(path.join(base,'cljs_deps.js'));
goog.global.CLOSURE_UNCOMPILED_DEFINES={'cljs.core._STAR_target_STAR_':'nodejs'};
for(const ns of ['cljs.core','cljs.analyzer','cljs.env','cljs.js','cljs.tools.reader','cljs.nodejs'])goog.require(ns);
cljs.nodejs.enable_util_print_BANG_();
const c=cljs.core,a=cljs.analyzer,kw=s=>c.keyword(s),vec=xs=>c.vec(xs),keys=m=>m==null?[]:c.into_array(c.keys(m));
if(c.NS_CACHE==null)c.NS_CACHE=c.atom(c.PersistentArrayMap.EMPTY);
const oldCache=c.deref(c.NS_CACHE),results=[];
const cases=[['let','(let* [subject 17] (suss-oracle.local-origin-macros/observe subject))'],['loop','(loop* [subject 17] (suss-oracle.local-origin-macros/observe subject))'],['argument','(fn* [subject] (suss-oracle.local-origin-macros/observe subject))'],['named-self','(fn* subject [x] (suss-oracle.local-origin-macros/observe subject))']];
for(const [label,source] of cases){
 const state=cljs.js.empty_state(),target=c.symbol('suss-oracle.local-key-origin'),macroNs=c.symbol('suss-oracle.local-origin-macros$macros');
 const saved=[cljs.env._STAR_compiler_STAR_,a._STAR_cljs_ns_STAR_,a._STAR_analyze_deps_STAR_,a._STAR_load_macros_STAR_];
 const proto=c.Keyword.prototype,slot='cljs$core$IHash$_hash$arity$1',original=proto[slot],events=[],observations=[];
 try{
  cljs.env._STAR_compiler_STAR_=state;a._STAR_cljs_ns_STAR_=target;a._STAR_analyze_deps_STAR_=false;a._STAR_load_macros_STAR_=false;
  c.swap_BANG_(state,c.assoc_in,vec([kw('cljs.analyzer/namespaces'),target]),c.hash_map(kw('name'),target,kw('defs'),c.PersistentArrayMap.EMPTY));
  const observer=function(macroForm,macroEnv,sym){
   const info=c.get_in(macroEnv,vec([kw('locals'),sym]));
   if(!info)throw Error('missing actual local info');
   const infoKeys=keys(info).map(k=>({ref:k,name:k.fqn,memo:k._hash}));
   const start=events.length,ast=a.analyze(macroEnv,sym);
   if(c.str(c.get(ast,kw('op')))!==':local')throw Error('not an actual local AST');
   if(c.get(ast,kw('info'))!==info)throw Error('source local info not retained');
   const selected=keys(ast).filter(k=>['name','local','arg-id','variadic?','init'].includes(k.fqn)).map(k=>({name:k.fqn,memo:k._hash,fromInfo:infoKeys.some(x=>x.ref===k),infoMemo:(infoKeys.find(x=>x.name===k.fqn)||{}).memo,firstHash:(events.slice(start).find(x=>x.ref===k)||{}).memo,hashCount:events.slice(start).filter(x=>x.ref===k).length}));
   observations.push({sourceLocal:c.str(sym),selected,outer:keys(ast).filter(k=>['form','info'].includes(k.fqn)).map(k=>({name:k.fqn,memo:k._hash}))});
   return 17;
  };
  observer.cljs$lang$macro=true;
  c.swap_BANG_(state,c.assoc_in,vec([kw('cljs.analyzer/namespaces'),macroNs]),c.hash_map(kw('name'),macroNs,kw('defs'),c.hash_map(c.symbol('observe'),c.hash_map(kw('name'),c.symbol('suss-oracle.local-origin-macros$macros/observe'),kw('macro'),true,kw('method-params'),vec([vec([c.symbol('&form'),c.symbol('&env'),c.symbol('subject')])]),kw('max-fixed-arity'),3))));
  c.swap_BANG_(c.NS_CACHE,c.assoc,macroNs,c.create_ns(macroNs,{observe:observer}));
  const form=cljs.tools.reader.read_string(source);
  proto[slot]=function(coll){events.push({ref:this,name:this.fqn,memo:this._hash});return this._hash==null?original.call(this,coll):this._hash;};
  a.analyze(c.assoc(a.empty_env(),kw('ns'),a.get_namespace(target)),form);
  if(observations.length===0)throw Error('macro never executed');
  results.push({label,source,actualMacroEntries:observations.length,observations});
 }finally{
  proto[slot]=original;c.reset_BANG_(c.NS_CACHE,oldCache);
  [cljs.env._STAR_compiler_STAR_,a._STAR_cljs_ns_STAR_,a._STAR_analyze_deps_STAR_,a._STAR_load_macros_STAR_]=saved;
  if(proto[slot]!==original||c.deref(c.NS_CACHE)!==oldCache)throw Error('restoration failed');
 }
}
console.log(JSON.stringify({scope:'actual analyzer local-reference construction inside real macro &env; retained generated pinned analyzer, not native Suss',results},null,2));
