# AST literal field-key follow-up — author packet

Base: corrected collection packet `cfe08182b60ce316c93f0c9b762f9630cfd3baad40168bceda0bb4ca180a755d`, composed tree492ed49e5d91130e0b0761fcf1346971de8711e8. Two changed Rust paths, exact pre/post hashes in manifest.json. This is authored cache-only source for main's independent review, not an independent GO or executed acceptance. No worktree/index/ref/remote/Cargo/BOOT/oracle operations.

## Changes and bounds

A1–A13 explicit retained-source control/operand, quote/const, with-meta and function AST field positions become explicit AnalyzerLiteralKeyword. Corresponding declared child names are selected by native SourceNode match, never operation spelling. All parent-local field/evaluation/child order remains unchanged. The shared :form key uses only named proven native variants, or None plus genuine quote/scalar/owned callable/resolved Global-or-JavaScript Symbol proof; fallback remains Cold. L1 arity keys change only inside genuine FunctionName/methods-Some branch. L4 direct info/form overlays use actual resolved Global/JavaScript source proof. Quoted/scalar/source metadata PAYLOADS remain the same cold source data.

Future/Await operands, declared names and children remain Cold, even though their strings overlap pinned constructors. New function-only methods/local/children/inferred-ret-tag require owned callable and SourceNode None. Existing tag, op VALUE keywords and generic lookup-only op/name/ns/tag stay unchanged. No new literal-to-literal alias contract. Existing interning semantics are not changed.

Pending deliberately: L2/L3 copied provenance and their outer form; D1–D4 declaration merges; A14 body?. In particular declaration value replacement must preserve FIRST retained key origin, not assign key origin from the final value stage (main's separate pinned probe). No spelling allowlist or blanket source/compiler flag.

## Metering and authority

Existing field_entry_work helpers and all allocation, schema/source/callback/memo authority paths retained. No new production heap buffers, owner retention or cache. Typed static child-name arrays replace static string arrays. Added selection work is prepaid before reads/dispatch: form20, native child-route4, typed-name read2/name, inferred-return5, function-key selections8. These are additional control charges, not lowered tariffs or quotas. Actual cost impact is UNKNOWN. No permission to treat prefueled literals as originally-nil or suppress live IHash.

## Focused regression source — unexecuted

Three appended tests exercise actual macro caller-environment transport, each both Runtime/Macro phases, live nil-aware Keyword IHash and canonical restoration, GC before transport and after returned value before decoding:

- analyzer_literal_control_ast_keys_keep_initial_memos_and_cold_extensions: do/if/throw/loop/recur/try.
- analyzer_literal_quote_metadata_ast_keys_keep_source_payload_cold: quoted const/with-meta and normal function/source children.
- analyzer_literal_dispatch_and_named_fn_keys_preserve_live_hash_restoration: set!/invoke/new plus named fn and nonvacuous FunctionName arity records.

The live observer stores actual receiver and memo at ENTRY before possible delegation. Field expectations use physical receiver matches to select observations, requiring nonempty exact numeric entry memos under custom dispatch, and no new events after restoration. Declared child names have ordered text and exact numeric memos checked BEFORE using them as lookup keys, with no literal-to-literal identity assertion. The actual root Suss lowering key must have a nil first-entry memo; same-text source :form/:expr arguments stay nil. Required operation rows and named-record presence prevent vacuous passes. Old tests remain byte-exact prefix.

Existing pinned analyzer.js constructor clips/hashes are saved with original line numbers and file digest; pinned analyzer.cljc constructor citations are in guard-provenance-ledger.json. No new JS/CLJS run, matched callback-order oracle or per-literal identity reference is claimed. These newly authored programs have not been Suss-parsed, typechecked or executed; source-shape/default-budget feasibility and complete normal-bootstrap integration remain for the approved producer. Missing required rows or fuel errors must be preserved, not converted to success.

## Static checks and next command plan

rustfmt edition2024/skip_children parses both Rust candidates; embedded Suss delimiters balance (not reader validation); git apply --check succeeds against cache-only corrected collection preimages. Retention assertions verify declaration/namespace, copied local/field blocks, binding helper and global lookup keys unchanged; Future/Await cold routes and old tests preserved.

After parent gates, independent source review, application and normal BOOT/source freeze under main's lease, run the three new tests plus existing analyzer_literal native tests and existing compiled_macro_analyzer_literal_memos/source_tags targets. Derive actual selectors from final source; no execution claimed here. Separate native authority/private fixup/scoped guards remain existing acceptance obligations, not replaced by these positives. #261 is not complete with declarations/copied fields/body? still pending.
