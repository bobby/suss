'use strict';
const path = require('path');
const base = '/home/bobby/.cache/suss-m4-work/memo-call-boundary-draft/out';
require(path.join(base,'goog/bootstrap/nodejs.js'));
require(path.join(base,'cljs_deps.js'));
goog.global.CLOSURE_UNCOMPILED_DEFINES = {'cljs.core._STAR_target_STAR_':'nodejs'};
for (const ns of ['cljs.core','cljs.analyzer','cljs.env','cljs.js','cljs.tools.reader','cljs.nodejs']) goog.require(ns);
cljs.nodejs.enable_util_print_BANG_();
const c=cljs.core,a=cljs.analyzer;
const kw=s=>c.keyword(s), vec=xs=>c.vec(xs), keys=m=>m==null?[]:c.into_array(c.keys(m));
const key=(m,name)=>keys(m).find(x=>x.fqn===name);
const cases=[
 ['plain','(def watched 17)'],
 ['source-overrides','(def ^{:name source-name :doc "raw" :meta {:leaf 17}} watched 17)'],
 ['docstring-overrides-source','(def ^{:doc "raw"} watched "docstring" 17)'],
 ['function-raw-flags','(def ^{:fn-var false :variadic? true :max-fixed-arity 9} watched (fn* [x] x))'],
 ['top-fn-overrides','(def ^{:fn-var false :top-fn {:fn-var true :variadic? false :max-fixed-arity 3 :method-params [] :arglists [] :arglists-meta []}} watched (fn* [x] x))']
];
const rows=[];
if(c.NS_CACHE==null)c.NS_CACHE=c.atom(c.PersistentArrayMap.EMPTY);
const originalCache=c.deref(c.NS_CACHE);
for(const [label,source] of cases){
 const state=cljs.js.empty_state(), target=c.symbol('suss-oracle.declaration-key-origin');
 const nsPath=vec([kw('cljs.analyzer/namespaces'),target]);
 c.swap_BANG_(state,c.assoc_in,nsPath,c.hash_map(kw('name'),target,kw('defs'),c.PersistentArrayMap.EMPTY));
 const saved=[cljs.env._STAR_compiler_STAR_,a._STAR_cljs_ns_STAR_,a._STAR_analyze_deps_STAR_,a._STAR_load_macros_STAR_];
 const proto=c.Keyword.prototype,slot='cljs$core$IHash$_hash$arity$1',original=proto[slot],events=[];
 let restored=false;
 try{
  cljs.env._STAR_compiler_STAR_=state;a._STAR_cljs_ns_STAR_=target;a._STAR_analyze_deps_STAR_=false;a._STAR_load_macros_STAR_=false;
  const form=cljs.tools.reader.read_string(source),sym=c.second(form),meta=c.meta(sym);
  const rawKeys=keys(meta).map(k=>({ref:k,name:k.fqn,memo:k._hash}));
  const top=c.get(meta,kw('top-fn')),topKeys=keys(top).map(k=>({ref:k,name:k.fqn,memo:k._hash}));
  proto[slot]=function(coll){events.push({ref:this,name:this.fqn,memo:this._hash});return this._hash==null?original.call(this,coll):this._hash;};
  const env=c.assoc(a.empty_env(),kw('ns'),a.get_namespace(target));
  const ast=a.analyze(env,form);
  const decl=c.get_in(c.deref(state),vec([kw('cljs.analyzer/namespaces'),target,kw('defs'),c.symbol('watched')]));
  if(!decl)throw Error('missing actual declaration');
  const macroNs=c.symbol('suss-oracle.declaration-origin-macros$macros');
  let macroEntries=0,observedDecl=null;
  const observer=function(macroForm,macroEnv){macroEntries++;observedDecl=c.get_in(macroEnv,vec([kw('ns'),kw('defs'),c.symbol('watched')]));return 17;};
  observer.cljs$lang$macro=true;
  c.swap_BANG_(state,c.assoc_in,vec([kw('cljs.analyzer/namespaces'),macroNs]),c.hash_map(kw('name'),macroNs,kw('defs'),c.hash_map(c.symbol('observe'),c.hash_map(kw('name'),c.symbol('suss-oracle.declaration-origin-macros$macros/observe'),kw('macro'),true,kw('method-params'),vec([vec([c.symbol('&form'),c.symbol('&env')])]),kw('max-fixed-arity'),2))));
  c.swap_BANG_(c.NS_CACHE,c.assoc,macroNs,c.create_ns(macroNs,{observe:observer}));
  const analysisEvents=events.slice();
  const macroAst=a.analyze(c.assoc(a.empty_env(),kw('ns'),a.get_namespace(target)),cljs.tools.reader.read_string('(suss-oracle.declaration-origin-macros/observe)'));
  if(macroEntries!==1||observedDecl!==decl||c.get(macroAst,kw('val'))!==17)throw Error('actual macro env/result mismatch');
  const captured=keys(observedDecl).map(k=>({name:k.fqn,memo:k._hash,raw:rawKeys.some(x=>x.ref===k),top:topKeys.some(x=>x.ref===k),rawInitial:(rawKeys.find(x=>x.name===k.fqn)||{}).memo,topInitial:(topKeys.find(x=>x.name===k.fqn)||{}).memo,firstHash:(analysisEvents.find(x=>x.ref===k)||{}).memo,hashCount:analysisEvents.filter(x=>x.ref===k).length,value:['name','doc','fn-var','variadic?','max-fixed-arity','method-params','arglists','arglists-meta'].includes(k.fqn)?c.pr_str(c.get(observedDecl,k)):undefined}));
  rows.push({label,source,macroEntries,actualMacroSameDeclaration:observedDecl===decl,macroResult:c.get(macroAst,kw('val')),astOp:c.str(c.get(ast,kw('op'))),keys:captured});
 }finally{
  proto[slot]=original;restored=proto[slot]===original;
  [cljs.env._STAR_compiler_STAR_,a._STAR_cljs_ns_STAR_,a._STAR_analyze_deps_STAR_,a._STAR_load_macros_STAR_]=saved;
  c.reset_BANG_(c.NS_CACHE,originalCache);
  if(c.deref(c.NS_CACHE)!==originalCache)throw Error('NS cache restore failed');
  if(!restored)throw Error('restore failed');
 }
}
console.log(JSON.stringify({scope:'actual pinned analyzer with live nil-aware Keyword IHash; actual macro &env and exact completed declaration reference; no native Suss acceptance claimed',cases:rows},null,2));
