# Declaration key-origin reference probe

Main-authored development evidence for the pending #261 declaration/metadata provenance repair. Uses the existing compiled ClojureScript analyzer/core under `memo-call-boundary-draft/out`, not a fresh CLJS build. The upstream checkout is clean at `c4295f303100bbf5afac449242d30bca1126f1a1`; the retained generated inputs have their own complete 115-file JS/JSON hash manifest. No Suss source/index/ref/worktree, Cargo producer or bootstrap was modified.

`probe.js` creates a fresh actual analyzer state for each of five source definitions, installs a live nil-aware Keyword IHash method, and records receiver references and memo values before delegation. It reads each source form through the actual pinned reader, retains actual metadata key references, analyzes the declaration, registers an actual macro through the established namespace-cache route, and invokes that macro. Each invocation receives actual `&env`; the probe requires its declaration to be the identical completed analyzer-state object and requires the expansion result 17. No substitute environment map or validator is used.

Two separate fresh Node processes (attempts5/6) exited0 with byte-identical JSON. Exact terminal statuses, stdout/stderr digests, Node version, clean pin, program and generated-input hashes, and unchanged-input verification are in terminal-receipt.json. The outputs contain five actual macro invocations each. Keyword method and namespace cache are restored with explicit checks; analyzer dynamic state is restored in finally. No failed attempt is relabeled: attempt1 was direct completed-state observation, attempt2 introduced actual macro invocation, later attempts added value observations; attempts5/6 are the final reproduced program. Earlier outputs/programs remain separate.

## Observed boundaries

- Base literal `:name` remains a compiler-created key even when source metadata replaces its value with `source-name`; it is distinct from the retained raw metadata `:name` object and has numeric initial memo1843675177.
- Source `:doc` remains the actual raw key, initially nil, when a later docstring replaces its value with `"docstring"`.
- Source `:meta` remains the raw initially-nil key when computed metadata replaces its value.
- Raw initially-nil `:fn-var`, `:variadic?` and `:max-fixed-arity` keys survive computed function value replacements (`fn-var=true`, fixed arity1 in this probe).
- `top-fn` supplies initially-nil arity keys where no earlier key exists, while an earlier raw `:fn-var` key survives the later top-fn value override.

These agree with the pinned primary parse-def merge order and PersistentArrayMap assoc retaining an earlier key object when replacing its value. Persistent map representation and actual hash work are observed rather than assumed from spelling. The final memo may be numeric because actual analysis has hashed a cold source key; the log retains that receiver's initial nil before delegation.

## Repair implication and limits

Do not assign provenance based solely on the stage supplying the final VALUE. Preserve the retained KEY's independent source/literal construction origin through metadata and function overlays. Unproven/Suss-only/source routes keep their required cold default. A blanket output-field name allowlist is unsound.

No native Suss comparison, matched native callback transcript, fresh CLJS compilation, exhaustive metadata-size/callback regimes or issue acceptance is established. Five cases are bounded reference evidence; source/GC/poison/domain/Runtime/low-budget native acceptance remains required. This is not public namespace identity acceptance or #264 closure. Independent review of the authored harness and actual raw evidence is still pending.
