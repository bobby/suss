# Retained declaration keys and reference literals — bounded author candidate

Cache-only on reviewed AST78fe02a8. Three Rust paths (graph, appended effect tests, new retained_field_keys.rs); main independently reviews before any application/compile/BOOT. No source/worktree/index/ref/remote/test/oracle producer mutations by author. Existing AST/collection tests remain exact prefixes; all original parameter-role negative tests and binding_literal_key stay unchanged.

## Correct operation-specific provenance

Declaration merge and select-keys have DIFFERENT key-origin rules. Main's independently reviewed pinned declaration probe records five actual macro-env declarations: literal initial :name remains the retained key through raw value override; raw :doc/:meta/function keys remain raw across computed value changes; top-fn supplies initially absent keys but cannot replace the earlier raw fn-var key. The candidate records first key origin independently of the existing value update list. It never treats the last value writer as key authority.

Pinned core.cljs9289–9301 select-keys, however, uses `(assoc ret key entry)` where key comes from the supplied keyseq. Analyzer4113–4120 passes literal [:name :local :arg-id :variadic? :init]. Genuine resolved Local/Field reference overlays therefore use explicit literal keys (including direct :info/:form), not descriptor-origin transfer. Main's independently reviewed four-role probe supplies12 numeric entry-key observations distinct from descriptor keys. No general literal-literal alias requirement is added to native tests. Descriptor/binding role proofs remain separate. A separate fn-name-var helper covers only form/local/info for exact FunctionName role plus FunctionName kind; it does not weaken the parameter helper or turn adapted source_kind into authority.

## Declaration implementation / deliberate limits

- Enable RetainedFieldKeys only for owned DefinitionInfo, type_fields=None, genuine unqualified def/defonce list head and symbol declaration position, and map/keyword metadata prefixes. No-info catalog/unknown/native type/shorthand-tag routes keep old cold handling. This is deliberately partial, not completion of D1–D4.
- Keep the existing `Vec<(&str,Value)>`, field order, value evaluation and removal/update policy. A private invocation-local sidecar records Literal token or actual guarded source-key recipe. Existing fields are not replaced/reordered by a new policy implementation.
- Original guards, enrichment and normalized metadata evaluation still run first. A separate ORIGINAL declaration metadata normalization identifies genuine source keys without treating origin-added position entries as raw source keys. The new normalization uses preserve_source_error so new Fuel/IRQ errors retain their SessionError type. No extra guest callback runs during native planning.
- Sidecar source entries verify actual unqualified Keyword Form/name correspondence and call the original graph.form full guard/planner. Recipe IDs stay graph-local, with original owned source facts; no guest storage/memo/pointer alone/external seed can mint them. Final map dependency order still follows the original value-field order. Actual source-key recipe sharing across :meta/declaration/top-fn views is an intentional provenance correction required by primary source/reference, not an invented literal-literal alias guarantee.
- Computed-key registration happens at explicit existing constructor sites and retains earlier keys. Field-name lists select transported source data only; they cannot mint a Literal token. Initial :name is Literal only on the enabled native constructor. SourceInfo, meta/doc/function/declared/completed-tag tokens are explicit positions and become keys only if absent earlier. Top-fn source keys arrive after initial fn-var registration; reverse value selection remains unchanged.
- New original-metadata key planning may allocate recipes earlier natively, but materialization follows map dependency/field order, not numerical creation order. Sharing can change identity/redundant construction only for the demonstrated retained source key. No broad effect-order equivalence or matched callback transcript is claimed without execution.

## Metering / ownership

No larger global FieldKey representation. The existing original field buffers/map conversion layout remains unchanged. New sidecar header/init/release, every appended Copy Entry payload initialization (even reused capacity), geometric requested backing acquisition, fixed retirement controls, relocation and all native label scans are prepaid before those operations. Actual size_of<Entry>/Self drives fees; no guessed layout byte constants. New syntax/prefix/conditional controls are charged. Original map conversion Vec replaces its old counterpart; original map/keyword/planning fees and guards remain. No quotas/rates, memo receipts, storage/schema/domain guards or persistent authority are weakened. No expected net work improvement claimed; extra actual work may affect budget and must be measured under main's producer.

## New tests — NOT EXECUTED

Two appended actual transport tests:

1. analyzer_literal_declaration_retained_keys_match_pinned_merge_boundaries mirrors the five pinned definitions (target renamed; public fn rather than oracle fn*), both caller phases, live nil-aware IHash, GC and canonical restoration. Observes actual field receiver entry memos and required source-key sharing with metadata/top-fn; checks overwritten semantic values, literal name and cold same-text source control. No new complete callback-order oracle claimed. Definitions are new regression fixtures, not replacements/reductions of old programs.
2. analyzer_literal_local_reference_select_keys_are_independent_of_binding_role observes genuine argument/catch reference ASTs through public transport, direct info/form/local numeric entry memos and cold source control. It does not claim native field/MethodThis execution or assert arbitrary literal-literal identity.

Four native helper tests cover source-key sharing/first-key retention and actual map materialization after GC; six source entries force backing growth; sampled measured phase-boundary fuel cuts and IRQ-at-entry with graph discard/source preservation/fresh retry; malformed native key kind rejection without publication; independent fn-name-var guard versus unchanged parameter/adapted negative controls. Fuel samples are not exhaustive whole-compiler cuts, and IRQ entry is not an all-boundary interruption sweep.

All runtime results UNKNOWN. Rust syntax/static source checks are not typechecking or execution. Pin/source provenance and source hashes are in ledger.json/manifest.json.

## Still pending / coordination

- Main separately owns A14 HIR/body-origin and graph body? block. This candidate leaves that exact block untouched. is_body+Do cannot prove a pinned body position because Future uses the same body builder; this-as needs its own retained macro-origin proof.
- D4: native type prior-record key history and exact type/default metadata merge remain unimplemented here. Keep type/num-fields/record route cold until that separate proof/patch; no name-based admission.
- Metadata symbol/string shorthand creates synthesized :tag key. Because no actual source keyword key exists, this candidate leaves that whole declaration on the old route pending independent reader-constructor proof. Unknown/macro source forms not native def/defonce also remain old cold.
- Full #261 acceptance remains unproved. Main should review these restrictions as explicit remaining scope, then choose/integrate a complete follow-up; do not claim all declaration semantics covered from five positive cases.

## Intermediate R1/R2 history

Main found two real static defects in the earlier d568b4 packet: source-info registration landed in the general raw-field loop (panic for doc/name), and claimed shorthand fallback lacked the actual prefix guard. Corrected source restores the original raw-field push, registers line/column/file only in its fixed loop, and prepays/enforces the map/keyword-only prefix guard. New extra normalization also preserves typed metering errors. Copy Entry accounting now avoids a fictitious per-element destructor, and a separate fn-name guard control test is included. No code was executed from either snapshot.

Exact rejected patch and all three source files were recovered deterministically, matching both the prior full patch SHA and every postimage SHA independently recorded by main. See history/rejected-d568b4/recovered-source-manifest.json. This is explicit recovery, not a claim that the old packet was originally frozen at review time. The original old manifest's bytes are not independently available and are not invented.

D4 primary correction: analyzer.cljc3630–3645 explicitly constructs :record as well as :name/:tag/:type/:num-fields. Pending status here is due to prior-record key retention and native resets, NOT lack of a literal :record constructor. Native nominal.rs has previous_type_info, but resetting those selected metadata fields can discard the earlier key-origin information; main is reviewing that dataflow separately.
