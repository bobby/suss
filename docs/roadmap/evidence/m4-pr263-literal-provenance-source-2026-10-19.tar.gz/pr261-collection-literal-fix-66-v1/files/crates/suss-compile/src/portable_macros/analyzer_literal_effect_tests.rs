//! Same production macro expansion in both caller phases, with a genuine
//! delegated IHash replacement installed before caller environment transport.
use super::*;
use crate::portable_session::memo_leaf_test_support::Method;
#[test]
fn analyzer_literal_actual_env_pre_dispatch_memo_effects_survive_gc_and_restoration() {
    let mut failures = Vec::new();
    for (phase, mut caller) in [
        ("runtime", Session::new_repl().unwrap()),
        ("macro", Session::new_macro().unwrap()),
    ] {
        let mut macros = CompiledMacros::new().unwrap();
        let run = (|| -> Result<(), String> {
            caller
                .eval("(def ^{:audit-leaf :source-only-leaf} watched 17)")
                .map_err(|e| e.to_string())?;
            macros
                .session
                .eval("(def leaf-original-method nil) (def literal-events [])")
                .map_err(|e| e.to_string())?;
            let original =
                Method::capture(&mut macros.session, "Keyword").map_err(|e| e.to_string())?;
            original
                .bind_delegate(&mut macros.session)
                .map_err(|e| e.to_string())?;
            macros.define(r#"(defmacro inspect-literal-effects [stage source-kw source-sym]
              (let [find-key (fn [m text] (reduce (fn [found key] (if (= (str key) text) key found)) nil (keys m)))
                    descriptor (get (:locals &env) 'local-x)
                    op-key (find-key descriptor ":op")
                    source-meta (:meta (get (:defs (:ns &env)) 'watched))
                    hits (reduce (fn [out row] (if (identical? op-key (first row)) (conj out (second row)) out)) [] literal-events)]
                (list 'quote
                  [(= (.-_hash op-key) -1882987955)
                   (if (= stage 0) (and (pos? (count hits)) (every? false? hits)) (empty? hits))
                   (nil? (.-_hash source-kw)) (nil? (.-_hash source-sym))
                   (nil? (.-_hash (:audit-leaf source-meta)))
                   (= 17 (:val (:init descriptor))) (= source-kw :op)
                   (= "op" (str source-sym))])))"#).map_err(|e|e.to_string())?;
            macros
                .session
                .eval(
                    r#"(extend-type Keyword IHash
              (-hash [self]
                (do (if (= (.-name self) "op")
                      (set! literal-events (conj literal-events [self (nil? (.-_hash self))])) nil)
                    (leaf-original-method self))))"#,
                )
                .map_err(|e| e.to_string())?;
            let observed = (|| -> Result<(), String> {
                for stage in 0..2 {
                    if stage == 1 {
                        original
                            .restore(&mut macros.session)
                            .map_err(|e| e.to_string())?;
                        // The restored stage must observe only its own transport:
                        // retained stage-zero event roots are not new callbacks.
                        macros
                            .session
                            .eval("(set! literal-events [])")
                            .map_err(|e| e.to_string())?;
                    }
                    macros.session.collect().map_err(|e| e.to_string())?;
                    caller.collect().map_err(|e| e.to_string())?;
                    let source = format!(
                        "(let [^number local-x 17] (inspect-literal-effects {stage} :op op))"
                    );
                    let value = caller
                        .eval_with_macros(&source, &mut macros)
                        .map_err(|e| format!("stage{stage}: {e}"))?;
                    let bridge = FormBridge::new(&mut caller).map_err(|e| e.to_string())?;
                    let form = bridge
                        .read(&mut caller, &value, 0..1)
                        .map_err(|e| e.to_string())?;
                    eprintln!(
                        "analyzer-literal-effects {phase}/stage{stage}: {:?}",
                        form.kind
                    );
                    if !matches!(&form.kind,Kind::Vector(values) if values.len()==8 && values.iter().all(|v|v.kind==Kind::Bool(true)))
                    {
                        failures.push(format!("{phase}/stage{stage}: {:?}", form.kind));
                    }
                }
                Ok(())
            })();
            let restored = original
                .restore(&mut macros.session)
                .map_err(|e| e.to_string());
            observed?;
            restored?;
            Ok(())
        })();
        if let Err(error) = run {
            failures.push(format!("{phase}: {error}"));
        }
    }
    assert!(failures.is_empty(), "{}", failures.join("\n"));
}


// Pinned analyzer.cljc4369–4400 and compiler.cljc368–382 establish these
// construction-site hashes; this test exercises Suss transport, not an oracle
// regeneration. Record entry memos BEFORE the nil-aware delegate can warm them.
#[test]
fn analyzer_literal_collection_keys_observe_initial_memos_under_nil_aware_hash() {
    let mut failures = Vec::new();
    for (phase, mut caller) in [
        ("runtime", Session::new_repl().unwrap()),
        ("macro", Session::new_macro().unwrap()),
    ] {
        let mut macros = CompiledMacros::new().unwrap();
        let run = (|| -> Result<(), String> {
            macros.session.eval("(def leaf-original-method nil) (def collection-events [])")
                .map_err(|e| e.to_string())?;
            let original = Method::capture(&mut macros.session, "Keyword")
                .map_err(|e| e.to_string())?;
            original.bind_delegate(&mut macros.session).map_err(|e| e.to_string())?;
            macros.define(r#"(defmacro inspect-collection-literals
                [stage map-name set-name vector-name cold-keys cold-vals cold-items cold-children cold-form]
              (let [find-key (fn [m text]
                               (reduce (fn [found key] (if (= (str key) text) key found)) nil (keys m)))
                    map-ast (:init (get (:locals &env) map-name))
                    set-ast (:init (get (:locals &env) set-name))
                    vector-ast (:init (get (:locals &env) vector-name))
                    check-key (fn [ast text expected]
                                (let [key (find-key ast text)
                                      hits (reduce (fn [out row]
                                                     (if (identical? key (first row))
                                                       (conj out (second row)) out))
                                                   [] collection-events)]
                                  (and (some? key) (= expected (.-_hash key))
                                       (if (= stage 0)
                                         (and (pos? (count hits)) (every? (fn [memo] (= expected memo)) hits))
                                         (empty? hits)))))
                    check-children (fn [ast specs]
                                     (let [names (:children ast)]
                                       (and (= (count names) (count specs))
                                            (every? true? (map (fn [name spec]
                                                                (and (= (str name) (first spec))
                                                                     (= (.-_hash name) (second spec))
                                                                     (not (identical? name (nth spec 2)))))
                                                              names specs)))))]
                (list 'quote
                  [(every? true? [(check-key map-ast ":keys" 1068423698)
                                  (check-key map-ast ":vals" 768058733)
                                  (check-key map-ast ":children" -940561982)
                                  (check-key map-ast ":form" -1624062471)])
                   (every? true? [(check-key set-ast ":items" 1031954938)
                                  (check-key set-ast ":children" -940561982)
                                  (check-key set-ast ":form" -1624062471)])
                   (every? true? [(check-key vector-ast ":items" 1031954938)
                                  (check-key vector-ast ":children" -940561982)
                                  (check-key vector-ast ":form" -1624062471)])
                   (check-children map-ast [[":keys" 1068423698 cold-keys] [":vals" 768058733 cold-vals]])
                   (check-children set-ast [[":items" 1031954938 cold-items]])
                   (check-children vector-ast [[":items" 1031954938 cold-items]])
                   (every? nil? [(.-_hash cold-keys) (.-_hash cold-vals) (.-_hash cold-items)
                                 (.-_hash cold-children) (.-_hash cold-form)])
                   (every? false? [(identical? cold-keys (find-key map-ast ":keys"))
                                   (identical? cold-vals (find-key map-ast ":vals"))
                                   (identical? cold-items (find-key set-ast ":items"))
                                   (identical? cold-children (find-key map-ast ":children"))
                                   (identical? cold-form (find-key vector-ast ":form"))])
                   (= 17 (:val (first (:items vector-ast))))])))"#)
                .map_err(|e| e.to_string())?;
            macros.session.eval(r#"(extend-type Keyword IHash
              (-hash [self]
                (let [memo (.-_hash self)]
                  (do (if (or (= (.-name self) "keys") (= (.-name self) "vals")
                              (= (.-name self) "items") (= (.-name self) "children")
                              (= (.-name self) "form"))
                        (set! collection-events (conj collection-events [self memo])) nil)
                      (if (nil? memo) (leaf-original-method self) memo)))))"#)
                .map_err(|e| e.to_string())?;
            let observed = (|| -> Result<(), String> {
                for stage in 0..2 {
                    if stage == 1 {
                        original.restore(&mut macros.session).map_err(|e| e.to_string())?;
                        macros.session.eval("(set! collection-events [])").map_err(|e| e.to_string())?;
                    }
                    macros.session.collect().map_err(|e| e.to_string())?;
                    caller.collect().map_err(|e| e.to_string())?;
                    let source = format!("(let [collection-m {{:left 17}} collection-s #{{17}} collection-v [17]] (inspect-collection-literals {stage} collection-m collection-s collection-v :keys :vals :items :children :form))");
                    let value = caller.eval_with_macros(&source, &mut macros)
                        .map_err(|e| format!("stage{stage}: {e}"))?;
                    // Retain the result through collection before decoding facts.
                    caller.collect().map_err(|e| e.to_string())?;
                    macros.session.collect().map_err(|e| e.to_string())?;
                    let bridge = FormBridge::new(&mut caller).map_err(|e| e.to_string())?;
                    let form = bridge.read(&mut caller, &value, 0..1).map_err(|e| e.to_string())?;
                    eprintln!("analyzer-collection-literals {phase}/stage{stage}: {:?}", form.kind);
                    if !matches!(&form.kind, Kind::Vector(values) if values.len() == 9 && values.iter().all(|v| v.kind == Kind::Bool(true))) {
                        failures.push(format!("{phase}/stage{stage}: {:?}", form.kind));
                    }
                }
                Ok(())
            })();
            let restored = original.restore(&mut macros.session).map_err(|e| e.to_string());
            observed?;
            restored?;
            Ok(())
        })();
        if let Err(error) = run { failures.push(format!("{phase}: {error}")); }
    }
    assert!(failures.is_empty(), "{}", failures.join("\n"));
}
