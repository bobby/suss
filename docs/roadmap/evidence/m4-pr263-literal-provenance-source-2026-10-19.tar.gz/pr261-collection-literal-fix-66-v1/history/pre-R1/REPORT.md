# Collection literal field-key candidate — composed66

Author packet, not independent approval. Base Git tree 492ed49e5d91130e0b0761fcf1346971de8711e8. Only cache files changed. No Cargo, bootstrap, oracle, source worktree, index, branch or remote writes.

## Exact boundary

- Map schema :keys/:vals and Set :items use explicit AnalyzerLiteralKeyword at their existing genuine SourceNode construction sites.
- All three collection builders use literal :children, and reuse their explicit field-key token for :children vector names. Existing Vector :items behavior stays intact.
- Common AST :form is literal ONLY for genuine Vector/Map/Set SourceNodes. A prepaid three-unit source-node/selection/key-choice debit precedes this new decision; field_entry_work macros still prepay actual entry representation. The enclosing source payload is unchanged.
- Both existing :tag paths remain literal and unchanged. Operation VALUE keywords remain unchanged/cold, despite corresponding pinned literal values; this packet deliberately fixes field-key scope only. Source constants, metadata payloads, noncollection :form and Suss extension fields are not promoted.
- Existing quota/rates, callbacks, traversal/field order, validation, source facts and originally-nil memo authority are unchanged. No new heap representation, cache or source authority is introduced. Removing the vector-only children selector removes actual redundant selection within an already-proven collection branch; no tariff adjustment.

## Regression authored (not executed)

`portable_macros::analyzer_literal_effect_tests::analyzer_literal_collection_keys_observe_initial_memos_under_nil_aware_hash`

Appended to the existing internal effect module because actual Method capture/restoration and macro-session access are intentionally internal. Existing test bytes remain an exact prefix. Both Runtime/Macro callers construct map/set/vector locals through actual compiled macro transport. Live nil-aware Keyword IHash records receiver and initial memo BEFORE any possible delegation, delegates only for nil, and returns existing numeric memo otherwise. Actual transported schema-key identities select events, rejecting missing events or any nonnumeric/wrong initial memo. Checks map keys/vals, set items, collection form/children; child names must be identical to corresponding physical field keys in order. Same-text source keyword arguments remain nil and physically distinct. Nine Boolean facts are decoded after GC; canonical restoration is exercised in a second stage and again attempted on exit. Existing physical/certification negative tests remain intact, not replaced by this positive transport test.

No direct mutation of memo slots, no fabricated expected source forms, no allowance setters. Runtime/compile fuel requirements and whether all source programs are currently supported remain unexecuted until main's approved producer. Rustfmt parses Rust only; embedded Suss delimiter balance is a lightweight static check, not reader/compiler/runtime validation.

## Upstream provenance / oracle limit

Pinned ClojureScript c4295f303100bbf5afac449242d30bca1126f1a1 analyzer.cljc4369–4400 builds these map/set/vector keys and child names as literal keywords; compiler.cljc368–382 emits numeric keyword hashes. Existing analyzer.js clip in ../pr261-literal-provenance-audit-66-v1 shows keys=1068423698, vals=768058733, items=1031954938, children=-940561982, form=-1624062471. No upstream implementation body is copied; fixed expected numeric literals and cited construction positions are reused.

No additional pinned oracle run is needed to justify these exact construction-site numeric expectations: the existing executed JS evidence already supplies them. This new Suss custom callback/GC/restoration program itself has NOT been executed against either Suss or CLJS; it is an authored regression, not a claimed new cross-language ordered-callback oracle. If main requires a matched new-program CLJS callback transcript beyond existing numeric evidence, that is additional development evidence, not present here.

## Static checks / proposed execution

Both changed Rust files parse with rustfmt edition2024/skip_children; cache-original git apply --check succeeds. Original files were read directly from the named composed Git tree. Three path preimages/postimages and patch digest are in manifest.json. No typecheck/execution credit.

After parent gates and main independent review: apply exact candidate, regenerate normal BOOT, run the new exact lib test plus existing analyzer_literal tests and both CLI analyzer-literal/source-tags targets under main's producer lease. Preserve all actual errors and unknowns; no #261 completion claim from this packet.
