#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import hashlib,json,subprocess,tarfile,io
C=Path('/home/bobby/.cache/suss-m4-work');P=Path(__file__).parent;RUN=C/'coherent-private-project-focused-v2';PACK=C/'coherent-private-project-execution-source-v2'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def need(ok,why):
 if not ok:raise RuntimeError(why)
def main():
 out=P/'m4-coherent-private-project-alias-v2-2026-10-18.tar.gz';need(not out.exists(),'output exists')
 r=load(RUN/'receipt.json');m=load(PACK/'manifest.json');root=Path(m['worktree']);need(r['current'] is None and r['final_changed']==[] and r['symlink_changes']=={},'not stable terminal')
 for pid in [r['driver_pid']]+[s['pid'] for s in r['stages']]:
  f=Path(f'/proc/{pid}/stat');need(not f.exists() or f.read_text().split(') ',1)[1].split()[0] in ('Z','X'),'recorded PID still active/reused')
 need(r['unexecuted_stages']==['callable-six-row','remaining-namespace-five-call'],'unexpected plan tail')
 need(r['stages'][0]['exit']==0 and r['stages'][1]['counts']=={'pass':3,'fail':0,'ignore':0} and r['stages'][2]['counts']=={'pass':12,'fail':5,'ignore':0},'unexpected results')
 maps={f:load(RUN/f) for f in ['before-freeze.json','after-bootstrap-freeze.json','terminal-freeze.json']};need(maps['after-bootstrap-freeze.json']==maps['terminal-freeze.json'],'postboot terminal mismatch');need(all(len(v)==4045 for v in maps.values()),'wrong scope')
 need(sha((PACK/'candidate.patch').read_bytes())==m['patch_sha256'],'patch mismatch')
 payload={}
 def tree(folder,prefix):
  for f in sorted(folder.rglob('*')):
   if not f.is_file():continue
   need(not f.is_symlink(),'symlink in payload');payload[prefix+'/'+str(f.relative_to(folder))]=f.read_bytes()
 tree(PACK,'reviewed-source');tree(RUN,'run/focused-v2');tree(C/'coherent-private-project-alias-source-v2','alias-source')
 for n in ['coherent-private-project-alias-source-v2-independent-review.json','coherent-private-project-execution-source-v2-independent-review.json','coherent-private-project-alias-v2-independent-terminal-review.json','coherent-private-project-source-v1-independent-review.json']:
  payload['reviews/'+n]=(C/n).read_bytes()
 payload['REPORT.md']=(P/'REPORT.md').read_bytes();payload['projection-measurements.json']=(P/'projection-measurements.json').read_bytes();payload['packager.py']=Path(__file__).read_bytes()
 boot=[f'runtime/bootstrap/{ph}.{e}' for ph in ['macro','runtime'] for e in ['wasm','json']]
 for f in boot:
  b=(RUN/'bootstrap'/f).read_bytes();need(sha(b)==maps['terminal-freeze.json'][f],'current bootstrap not terminal bytes '+f);payload['bootstrap/'+f]=b
 bindings={};snapshot_paths={}
 for f,h in m['files'].items():
  member='reviewed-source/after/'+f;need(sha(payload[member])==h,'packet payload mismatch');snapshot_paths[f]={'sha256':h,'payload':member}
 for f in boot:snapshot_paths[f]={'sha256':maps['terminal-freeze.json'][f],'payload':'bootstrap/'+f}
 unresolved={}
 for values in maps.values():
  for f,h in values.items():
   key=f+'@'+h
   candidate=snapshot_paths.get(f)
   if candidate and candidate['sha256']==h:bindings[key]={'kind':'archived_payload',**candidate};continue
   sub=f.startswith('clojurescript/');repo=root/'clojurescript' if sub else root;ref='c4295f303100bbf5afac449242d30bca1126f1a1' if sub else ('ce6fafbf4263c75c832b51b479d6df6a6655b24f' if f in boot else m['base']);path=f.removeprefix('clojurescript/') if sub else f
   unresolved[key]=(str(repo),ref,path,h)
 # Stream exact Git bytes, including historical evidence files; no duplicate source payload archive.
 for repo in sorted({v[0] for v in unresolved.values()}):
  keys=[k for k,v in unresolved.items() if v[0]==repo];q=P/('queries-cljs.txt' if repo.endswith('/clojurescript') else 'queries-suss.txt');q.write_text('\n'.join(unresolved[k][1]+':'+unresolved[k][2] for k in keys)+'\n')
  with q.open('rb') as stdin:
   proc=subprocess.Popen(['git','-C',repo,'cat-file','--batch'],stdin=stdin,stdout=subprocess.PIPE)
   for k in keys:
    header=proc.stdout.readline().split();need(len(header)==3 and header[1]==b'blob','unresolved Git blob '+k)
    size=int(header[2]);left=size;h=hashlib.sha256()
    while left:
     b=proc.stdout.read(min(left,1024*1024));need(bool(b),'short Git object');h.update(b);left-=len(b)
    need(proc.stdout.read(1)==b'\n','Git framing');v=unresolved[k];need(h.hexdigest()==v[3],'Git SHA256 mismatch '+k)
    bindings[k]={'kind':'public_git_dependency','repository':'clojure/clojurescript' if repo.endswith('/clojurescript') else 'bobby/suss','commit':v[1],'path':v[2],'blob_oid':header[0].decode(),'sha256':v[3],'bytes':size}
   need(proc.wait()==0,'git cat-file failed')
 resolution={'base':m['base'],'cljs_pin':'c4295f303100bbf5afac449242d30bca1126f1a1','freeze_maps':maps,'bindings':bindings,'snapshot_paths':snapshot_paths,'limits':'Exact Git dependencies plus archived changed files/bootstrap, not standalone full source; eventual snapshot commit/push not claimed.'}
 payload['source-resolution.json']=(json.dumps(resolution,indent=2)+'\n').encode()
 index={n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(payload.items())};payload['MANIFEST.json']=(json.dumps({'schema':1,'files':index},indent=2)+'\n').encode()
 with out.open('xb') as output:
  with tarfile.open(fileobj=output,mode='w:gz') as t:
   for n,b in sorted(payload.items()):
    need(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts,'unsafe member');i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
 # Independent reopen verifies member identity, types, complete manifest/digests.
 with tarfile.open(out) as t:
  members=t.getmembers();need(len(members)==len(payload) and len({x.name for x in members})==len(members),'member count/duplicate');need(all(x.isfile() and not PurePosixPath(x.name).is_absolute() and '..' not in PurePosixPath(x.name).parts for x in members),'unsafe tar member')
  d={x.name:t.extractfile(x).read() for x in members};need(set(d)==set(payload),'member scope')
  for n,v in index.items():need(sha(d[n])==v['sha256'] and len(d[n])==v['bytes'],'payload digest mismatch '+n)
 result={'archive':str(out),'sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'members':len(payload),'hashed_payloads':len(index),'safe_paths_and_all_payload_hashes_verified':True,'source_inputs':4045,'unique_source_bindings':len(bindings),'source_base':m['base'],'source_patch_sha256':m['patch_sha256'],'bootstrap_payloads_exact_terminal':boot,'snapshot_paths':snapshot_paths,'report_sha256':sha((P/'REPORT.md').read_bytes()),'results':'bootstrapPASS;3diffPASS;17guards12PASS5typedfuelFAIL;2CLI stagesUNEXECUTED;projection incremental441520 cumulative2332172 native only','publication':'Experimental backup only; source snapshot commit/push pending root; no repository modification by packager.'}
 (P/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='snapshot_paths'},indent=2))
if __name__=='__main__':main()
