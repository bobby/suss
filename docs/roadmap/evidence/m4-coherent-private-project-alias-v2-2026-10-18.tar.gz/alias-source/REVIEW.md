# V2: remove only alias completion buffers — UNEXECUTED

The valid V1 implementation/run is preserved: 45 exact native projections, 6,500,173 → 4,609,521 proxy units; admitted-boundary gain 1,890,652. V1 still has five fuel failures and CLI gates unexecuted. This packet changes one source file relative to its actual post-bootstrap terminal freeze; all other 4044 inputs remain exact. No further saving is claimed before measurement.

## Grounded work removal

V1 Inputs::push reserves at least four Form slots for an alias's single successful child; finish immediately pops that Form and drops the empty allocation. The new completion loop passes the already-owned Option<Form> through completed alias frames without creating/populating that vector. A None child passes through unchanged, without hiding later siblings of the alias's parent. Real collection and metadata completion paths are unchanged. No exact-sized collection allocation change is included.

This is completion buffering only. Every alias frame is still created and pushed at descent. Each still performs the original frame entry/ancestor cycle scan, checked dependency count and borrowed edge read. Cycles, missing targets and malformed descendants fail before successful completion can bypass a buffer. Diamond occurrences still traverse independently. No graph cache, collapsed alias chain, skipped child, new authority, output cloning or retained Form ownership is introduced.

Fixed alias fees remain four delivery bookkeeping units, one loop-completion unit and two one-input finish units. Only reserve/allocation/relocation fees for work no longer performed disappear. A prepaid one-unit parent-kind read is new for every non-root completion; non-alias delivery retains its existing Inputs::push fee in addition. All charges precede the corresponding reads/pop, and a charge failure cannot publish state. There is no global cut to tariffs or a changed quota. Error/fuel boundaries naturally may change when actual allocation work is removed; complete logical DFS/error ordering is retained. Frames storage size and allocator policy are unchanged.

## Review / root-owned execution

Before/after snapshot all11 integration paths; candidate.patch is the one-file delta; source-freeze includes actual pinned CLJS checkout bytes. All45-output differential assertions, malformed/unsupported/metadata/cycle tests, per-algorithm fuel/IRQ controls, and all17 coherent guards remain byte-identical. Old-reference algorithm remains byte-identical. These existing alias-positive, alias-cycle, missing-target, declined-child and repeated-diamond cases cover the changed path; no fixture reduction.

After independent review, normal four-output bootstrap then unchanged three differential tests and unchanged controller-selected17/conditional CLI gates. Root may compare the new45 printed rows directly to saved V1 rows to assess the incremental benefit, separately from original-algorithm total benefit. No worktree outside the current integration leaf changed. No Cargo or bootstrap executed by author. Legacy callback-control fuel remains separate and unresolved; no allowance or source reduction proposed.
