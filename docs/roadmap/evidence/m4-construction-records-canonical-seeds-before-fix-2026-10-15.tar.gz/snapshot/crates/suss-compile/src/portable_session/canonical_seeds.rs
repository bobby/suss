//! Seed witnesses captured only while the verified shipped bootstrap is private.
//! Exact storage comparison conservatively rejects later descriptor changes too.
use super::{
    Session, SessionError, SessionValue, canonical_methods, storage_snapshot::StorageSnapshot,
};
use crate::portable::{bootstrap, hir::Literal};
use std::sync::{Arc, atomic::AtomicUsize};

type Result<T> = std::result::Result<T, SessionError>;
pub(crate) struct CanonicalSeed {
    storage: StorageSnapshot,
}
pub(super) struct CanonicalSeeds {
    seeds: Vec<(&'static str, Arc<CanonicalSeed>)>,
}
impl CanonicalSeeds {
    pub(super) fn capture(
        session: &mut Session,
        authority: &bootstrap::IntegrityAuthority,
    ) -> Result<Self> {
        if session.bootstrap_core
            || session.canonical_seeds.is_some()
            || !std::ptr::eq(
                authority,
                bootstrap::shipped_authority(session.phase).map_err(SessionError::Compile)?,
            )
        {
            return Err(SessionError::Host(wasmtime::Error::msg(
                "Canonical seeds require initial shipped provisioning",
            )));
        }
        let _request = session.operation_budget_scope()?;
        let handles = Arc::new(AtomicUsize::new(0));
        let key = session.data_scalar(&Literal::String("EMPTY".encode_utf16().collect()))?;
        let mut seeds = Vec::new();
        session.charge_host_work((3 * std::mem::size_of::<(&str, Arc<CanonicalSeed>)>()) as u64)?;
        seeds.try_reserve_exact(3).map_err(|_| {
            SessionError::Host(wasmtime::Error::msg("Canonical seed allocation failed"))
        })?;
        for (name, owner) in [
            ("empty-list", "List"),
            ("empty-map", "PersistentArrayMap"),
            ("empty-set", "PersistentHashSet"),
        ] {
            session.charge_host_work(1)?;
            let class = canonical_methods::binding(session, "suss.core", owner, &handles)?;
            let value = canonical_methods::runtime(
                session,
                "named-property-get",
                &[&class, &key],
                &handles,
            )?;
            let storage = session.capture_storage_accounted(&value, handles.clone())?;
            seeds.push((name, Arc::new(CanonicalSeed { storage })));
        }
        Ok(Self { seeds })
    }
}
impl CanonicalSeed {
    pub(crate) fn matches(&self, session: &mut Session, value: &SessionValue) -> Result<bool> {
        session.storage_matches(value, &self.storage)
    }
}
impl Session {
    pub(crate) fn canonical_seed(&mut self, name: &str) -> Result<Option<Arc<CanonicalSeed>>> {
        self.charge_host_work(1)?;
        let Some(seeds) = self.canonical_seeds.clone() else {
            return Ok(None);
        };
        for (candidate, seed) in &seeds.seeds {
            self.charge_host_work(
                (name.len() as u64)
                    .saturating_add(candidate.len() as u64)
                    .saturating_add(1),
            )?;
            if *candidate == name {
                return Ok(Some(seed.clone()));
            }
        }
        Ok(None)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::portable::resolve::Phase;
    use std::sync::atomic::Ordering;
    fn session(phase: Phase) -> Session {
        match phase {
            Phase::Runtime => Session::new_repl().unwrap(),
            Phase::Macro => Session::new_macro().unwrap(),
        }
    }
    #[test]
    fn canonical_seeds_bind_initial_roots_and_survive_hash_warming_and_gc() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = session(phase);
            let handles = session.handles.load(Ordering::Relaxed);
            for name in ["empty-list", "empty-map", "empty-set", "not-a-seed"] {
                drop(session.canonical_seed(name).unwrap());
            }
            assert_eq!(session.handles.load(Ordering::Relaxed), handles);
            for (name, owner, class) in [
                ("empty-list", "List", "EmptyList"),
                ("empty-map", "PersistentArrayMap", "PersistentArrayMap"),
                ("empty-set", "PersistentHashSet", "PersistentHashSet"),
            ] {
                let value = session
                    .eval(&format!("(.-EMPTY suss.core/{owner})"))
                    .unwrap();
                let witness = session.canonical_seed(name).unwrap().unwrap();
                assert!(witness.matches(&mut session, &value).unwrap());
                let hash = session.eval("suss.core/hash").unwrap();
                drop(session.invoke(&hash, &[&value]).unwrap());
                session.collect().unwrap();
                assert!(witness.matches(&mut session, &value).unwrap());
                let class = session.eval(&format!("suss.core/{class}")).unwrap();
                let fields = session.data_fields(&value).unwrap();
                let clone = session
                    .data_construct(&class, &fields.iter().collect::<Vec<_>>())
                    .unwrap();
                assert!(
                    !witness.matches(&mut session, &clone).unwrap(),
                    "equal contents do not establish bootstrap origin"
                );
            }
            let authority = bootstrap::shipped_authority(phase).unwrap();
            assert!(CanonicalSeeds::capture(&mut session, authority).is_err());
            let witness = session.canonical_seed("empty-map").unwrap().unwrap();
            let old = session
                .eval("(.-EMPTY suss.core/PersistentArrayMap)")
                .unwrap();
            session.reset().unwrap();
            assert!(matches!(
                witness.matches(&mut session, &old),
                Err(SessionError::ForeignValue)
            ));
        }
    }
    #[test]
    fn canonical_seeds_reject_mutation_before_a_bridge_can_observe_it() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = session(phase);
            for (name, owner) in [
                ("empty-list", "List"),
                ("empty-map", "PersistentArrayMap"),
                ("empty-set", "PersistentHashSet"),
            ] {
                let witness = session.canonical_seed(name).unwrap().unwrap();
                session
                    .eval(&format!(
                        "(set! (.-seedPoison (.-EMPTY suss.core/{owner})) 99)"
                    ))
                    .unwrap();
                let value = session
                    .eval(&format!("(.-EMPTY suss.core/{owner})"))
                    .unwrap();
                let post_mutation = session.capture_storage(&value).unwrap();
                session.collect().unwrap();
                assert!(session.storage_matches(&value, &post_mutation).unwrap());
                assert!(!witness.matches(&mut session, &value).unwrap());
                // A later lookup cannot refresh the initial expectation.
                let later = session.canonical_seed(name).unwrap().unwrap();
                assert!(!later.matches(&mut session, &value).unwrap());
            }
        }
    }
}
