from pathlib import Path
import json,hashlib,tarfile,io,re,collections,subprocess
r=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access');c=Path('/home/bobby/.cache/suss-m4-work');s=json.loads((c/'primitive-string-lookup-result.json').read_text());tr=json.loads((c/'primitive-string-lookup-inference-trace-result.json').read_text());old=json.loads((c/'primitive-string-inference-trace-result.json').read_text());assert s['current'] is None and tr['current'] is None and s['source_unchanged'] and tr['source_unchanged'];assert s['freeze']==tr['freeze'];assert len(s['freeze'])==439
payload={}
for f,h in s['freeze'].items():
 b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h,f;payload['snapshot/'+f]=b
assert hashlib.sha256(payload['snapshot/crates/suss-compile/src/portable/emit.rs']).hexdigest()=='cd8b6ba6bcdf0dd4adaa8dae6182b2e6484435c85b444c24a6d65bc70a2f12eb'
assert old['freeze']['crates/suss-compile/src/portable/emit.rs']=='f4af4079fb2716d1d6de7173fc96076622b069eeb720539f071ff8c7fbfb5b9c'
f='crates/suss-cli/tests/compiled_macro_source_tags.rs';assert old['freeze'][f]==s['freeze'][f]
extra=['Cargo.toml','Cargo.lock','crates/suss-core/Cargo.toml','crates/suss-reader/Cargo.toml','crates/suss-compile/Cargo.toml','crates/suss-cli/Cargo.toml','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','runtime/core-import/LICENSE','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json','vendor/wasi/wasi-wit-0.3.1/cli/cli.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit']
for f in extra:payload['snapshot/'+f]=(r/f).read_bytes()
paths=[f for f in s['freeze'] if f=='crates/suss-compile/build.rs' or any(f.startswith('crates/'+n+'/src/') and f.endswith(('.rs','.sus')) for n in ['suss-core','suss-reader','suss-compile'])]+extra[:5]+extra[9:];h=hashlib.sha256()
for f in sorted(set(paths),key=lambda p:tuple(p.split('/'))):
 b=payload['snapshot/'+f];n=f.encode();h.update(len(n).to_bytes(8,'little')+n+len(b).to_bytes(8,'little')+b)
checks={}
for phase in ['macro','runtime']:
 m=json.loads(payload[f'snapshot/runtime/bootstrap/{phase}.json']);checks[phase]={'compiler':h.hexdigest()==m['compiler_source_sha256'],'core':hashlib.sha256(payload['snapshot/runtime/core-import/suss/core.sus']).hexdigest()==m['source_sha256'],'dependencies':hashlib.sha256(payload['snapshot/runtime/core-import/manifest.json']).hexdigest()==m['dependency_graph_sha256'],'wasm':hashlib.sha256(payload[f'snapshot/runtime/bootstrap/{phase}.wasm']).hexdigest()==m['wasm_sha256']}
assert all(all(v.values()) for v in checks.values())
def parse(name):
 raw=(c/name).read_text();invocations=[];current=None
 for line in raw.splitlines():
  m=re.match(r'macro-fuel ([^ ]+) ([^:]+): (\d+)',line)
  if m:
   target,stage,fuel=m.groups()
   if stage=='start':current={'target':target,'stages':[]};invocations.append(current)
   if current is not None:current['stages'].append({'stage':stage,'remaining':int(fuel)})
 return {'invocations':invocations,'starts':[row['stages'][0]['remaining'] for row in invocations],'decoded':[x['remaining'] for row in invocations for x in row['stages'] if x['stage']=='decoded'],'completed_stage_counts':dict(collections.Counter(x['stage'] for row in invocations for x in row['stages'])),'trace_line_counts':dict(collections.Counter(line.split(' ',1)[0] for line in raw.splitlines() if line.startswith(('metadata-','macro-','origin-')))),'failure_lines':[line for line in raw.splitlines() if 'caller &env input transport' in line or 'test result:' in line]}
a=parse('primitive-string-inference-trace.log');b=parse('primitive-string-lookup-inference-trace.log');comparison={'prior_f4af':a,'lookup_cd8b':b,'completed_decoded_remaining_improvement':[new-prev for prev,new in zip(a['decoded'],b['decoded'])],'fourth_start_remaining_improvement':b['starts'][3]-a['starts'][3],'interpretation':'Completed stage remaining balances only. Inclusive nested stage breadcrumbs and event counts cannot be added into exclusive callee costs. Same inference input fixture/default fuel, both fail fourth caller &env transport; no passing inference or individual helper cost attribution.'};payload['trace-comparison.json']=json.dumps(comparison,indent=2).encode()
for pattern in ['primitive-string-lookup-*','primitive-string-inference-trace-result.json','primitive-string-inference-trace.log']:
 for p in c.glob(pattern):
  if p.is_file():payload['receipts/'+p.name]=p.read_bytes()
for f in ['run-primitive-string-lookup.py','run-primitive-string-lookup-inference-trace.py','run-primitive-string-inference-trace.py','package-primitive-string-lookup.py']:payload['runners/'+f]=(c/f).read_bytes()
refs=[('primitive-string-root-success/m4-primitive-string-root-success-matched-2026-10-16.tar.gz','15f8691ee62aecf2743f6000c0ba33f0c3f9957df6ec8bb200177c07030c539d'),('m4-primitive-string-root-success-oracle-2026-10-16.tar.gz','f3d3cb48235a393fa66ce8b54d962d5700c713fbcdd308c59a5659e257bfa988')]
for f,digest in refs:assert hashlib.sha256((c/f).read_bytes()).hexdigest()==digest
payload['audit.json']=json.dumps({'source_emitter_sha256':'cd8b6ba6bcdf0dd4adaa8dae6182b2e6484435c85b444c24a6d65bc70a2f12eb','freeze_count':len(s['freeze']),'guest_cljs_explicitly_frozen':s['freeze']['crates/suss-compile/tests/fixtures/primitive_string_root_success.cljs'],'fingerprints':checks,'references':[{'cache_relative_path':f,'sha256':digest} for f,digest in refs],'limits':'Supporting critical fingerprint inputs captured after execution; source/CLJS/bootstrap paths frozen before/after both producer cohorts. No additional tests, full workspace baseline/final CI or committed-head review; no inference/issue closure. Prior root failures remain preserved and are not rerun by this cohort. Proposed patch included as proposal, full current snapshot authoritative.'},indent=2).encode()
readme='''Lookup-only evidence package, base8fda18a plus guarded String emitter and lookup shortcut. All original test files remain in snapshots. Exact commands/exits/durations in receipts. Pipeline bootstrap0; strings2pass; root-success1pass with Runtime/Macro rows66/17/true/66/[1 2 3 4]; source-tags1pass1fuel-fail at382..414. Traced exact inference0pass1fuel-fail, same fourth caller &env boundary. Both producer freezes439 paths match each other and current bytes, including .cljs. Both phase fingerprints recomputed. Priorf4af trace is retained for completed-stage balance comparison only; raw operation counts/inclusive stage events are not additive exclusive costs. Source-tag fixture hash unchanged. No compatibility/full-baseline/CI/issue completion claim. Native operational Wasm and fingerprint inputs captured; critical support inputs not independently pre-frozen. Nothing committed/pushed or production-edited by packaging.
''';payload['README.txt']=readme.encode()
m={f:hashlib.sha256(v).hexdigest() for f,v in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(m,indent=2).encode();out=c/'m4-primitive-string-lookup-focused-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f,v in sorted(payload.items()):
  info=tarfile.TarInfo(f);info.size=len(v);t.addfile(info,io.BytesIO(v))
with tarfile.open(out) as t:
 for f,digest in m.items():assert hashlib.sha256(t.extractfile(f).read()).hexdigest()==digest
result={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(m),'freeze_count':len(s['freeze']),'fingerprints':checks,'prior_decoded':a['decoded'],'current_decoded':b['decoded'],'completed_decoded_improvement':comparison['completed_decoded_remaining_improvement'],'fourth_start_improvement':comparison['fourth_start_remaining_improvement']};(c/'primitive-string-lookup-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
