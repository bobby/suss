from pathlib import Path
import os,json,time,hashlib,subprocess
r=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'))
env['SUSS_KEYWORD_CONFORMANCE_CAPTURE']=str(c/'primitive-string-keyword-observations')
state={'base':'8fda18a','stages':[],'current':None};out=c/'primitive-string-lookup-result.json'
def save():out.write_text(json.dumps(state,indent=2)+'\n')
def run(name,cmd):
 state['current']=name;entry={'name':name,'command':cmd};state['stages'].append(entry);save();start=time.time()
 with (c/f'primitive-string-lookup-{name}.log').open('w') as f:x=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 entry.update(exit=x.returncode,seconds=time.time()-start);save();return x.returncode
if run('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']):
 state['current']=None;save();raise SystemExit(1)
files=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus','.cljs']]+[p for p in (r/'runtime/bootstrap').glob('*') if p.is_file()]
state['freeze']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};save()
for name,args,stop in [('strings',['-p','suss-compile','--locked','--test','portable_primitive_string_access','primitive_string_access_'],True),('root-success',['-p','suss-compile','--locked','--test','portable_primitive_string_root_success'],True),('source-tags',['-p','suss-cli','--locked','--test','compiled_macro_source_tags'],False)]:
 exitcode=run(name,['cargo','test']+args+['--','--test-threads=2','--nocapture'])
 if stop and exitcode:state['stopped_on_unexpected_focused_failure']=name;break
state.update(current=None,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in state['freeze'].items()));save();print(json.dumps({k:v for k,v in state.items() if k!='freeze'},indent=2))
