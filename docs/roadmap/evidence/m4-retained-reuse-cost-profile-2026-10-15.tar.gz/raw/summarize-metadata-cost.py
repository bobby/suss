import re,json,collections
from pathlib import Path
p=Path('/home/bobby/.cache/suss-m4-work/suss-m4-metadata-cost-profile.log');totals=collections.Counter();counts=collections.Counter();previous=None
for line in p.read_text().splitlines():
 m=re.fullmatch(r'metadata-fuel (\S+) (\S+): (\d+)',line)
 if not m:continue
 owner,stage,fuel=m.group(1),m.group(2),int(m.group(3))
 if stage!='start' and previous and previous[0]==owner:
  delta=previous[2]-fuel
  assert delta>=0
  totals[stage]+=delta;counts[stage]+=1
 previous=owner,stage,fuel
result={'complete_stage_fuel_deltas':dict(totals),'complete_stage_counts':dict(counts),'limits':['Adjacent completed stages only; excludes fresh construction, expectation generation and any interrupted final stage.','Diagnostic measurement does not change configured fuel.']}
print(json.dumps(result,indent=2));(p.parent/'metadata-cost-summary.json').write_text(json.dumps(result,indent=2))
