import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path('/home/bobby/Work/code/bobby/suss')
out=Path('/home/bobby/.cache/suss-m4-work/suss-m4-metadata-cost-result.json')
paths=sorted(p for p in (root/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus'])
paths += sorted((root/'runtime/bootstrap').glob('*'))
start={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}
state={'current':None,'stages':[],'source-hashes':start}
env=os.environ.copy();env.update(PATH='/home/bobby/.cargo/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(root/'target-m4-prototype'))
env['SUSS_METADATA_FUEL_TRACE']='1';env['SUSS_MACRO_FUEL_TRACE']='1'
stages=[('all memo receipt checks','memo_receipts'),('provenance',None),('collection cost profile','profile')]
for name,filter_ in stages:
 cmd=(['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_collection_source_asts','collection_source_nodes_retain_original_children_before_factory_lowering','--','--test-threads=2','--nocapture'] if filter_=='profile' else ['cargo','test','-p','suss-compile','--locked','--lib',filter_,'--','--test-threads=2']) if filter_ else ['python3','scripts/check_record_macro_provenance.py']
 log=Path('/home/bobby/.cache/suss-m4-work/suss-m4-metadata-cost-'+(filter_ or 'provenance')+'.log')
 with log.open('wb') as f:
  process=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  state['current']={'name':name,'pid':process.pid,'log':str(log),'command':cmd};out.write_text(json.dumps(state,indent=2)+'\n')
  code=process.wait()
 state['stages'].append({**state['current'],'exit_code':code});state['current']=None
 state['source-unchanged']=all(p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==start[str(p.relative_to(root))] for p in paths if str(p.relative_to(root)) in start)
 out.write_text(json.dumps(state,indent=2)+'\n')
 print(json.dumps(state['stages'][-1]),flush=True)
 if code or not state['source-unchanged']:sys.exit(code or 1)
