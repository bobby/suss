import pathlib,json,hashlib,collections,subprocess,tarfile,io
p=pathlib.Path(__file__).parent
runs=[json.loads((p/f'run{i}-observations.json').read_text()) for i in [1,2]]
assert runs[0]==runs[1], 'ordered observations/dispatches differ'
x=runs[0]
names=['name','requires','renames','uses','require-macros','use-macros','rename-macros','excludes','defs']
actual={r['name']:r['memo'] for r in x['rows'] if r['label']=='actual-macro-env-ns-key'}
assert set(actual)==set(names)
assert all(type(v)==int for v in actual.values())
pre={n:collections.Counter(str(d['before']) for d in x['dispatches'] if d['name']==n) for n in names}
for n in names: assert set(pre[n])=={str(actual[n])}
controls=[r for r in x['rows'] if r['label'] in ['fresh-reader-control','source-value-control','actual-macro-source-value']]
assert len(controls)==12 and all(r['memo'] is None for r in controls)
nsvalues=[r for r in x['rows'] if r['label'].endswith('/value') and r['label']!='initial-default-namespace-key/value']
assert len(nsvalues)==3 and all(r['memo'] is None for r in nsvalues)
pin=pathlib.Path('/home/bobby/Work/code/bobby/suss/clojurescript')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=pin,text=True).strip()
clean=not subprocess.check_output(['git','status','--porcelain'],cwd=pin,text=True)
assert head=='c4295f303100bbf5afac449242d30bca1126f1a1' and clean
receipt={'pin':head,'pin_clean':clean,'runs':[json.loads((p/f'run{i}-receipt.json').read_text()) for i in [1,2]],'ordered_rows_and_dispatches_identical':True,'rows_per_run':len(x['rows']),'selected_predelegation_dispatches_per_run':len(x['dispatches']),'actual_macro_calls_per_run':x['macro-calls'],'namespace_literal_memos':actual,'selected_dispatch_counts_by_name':{n:sum(pre[n].values()) for n in names},'cold_controls_per_run':len(controls),'new_namespace_name_symbol_cold_snapshots':len(nsvalues),'limits':'Selected-name dispatch log is not exclusive namespace-construction cost nor per-instance association proof. Includes empty-state core-cache loading. Runtime field snapshots plus actual analyzer/create-state/ensure-defs path and generated direct constructor excerpts support only cited explicit literal sites. Default cljs.user symbol already warm; no universal symbol-cold rule. No Suss acceptance/performance claim. No new fixture failures; original structural setup failures retained as prior evidence.'}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
js=p/'out/cljs/cljs/analyzer.js';lines=js.read_text().splitlines()
needles=['var ns_info','cljs.analyzer.ensure_defs =','new cljs.core.Keyword(null,"defs","defs",1398449717)']
ex=[]
for i,line in enumerate(lines):
 if any(t in line for t in needles):
  ex.append({'file':'out/cljs/cljs/analyzer.js','line':i+1,'text':'\n'.join(lines[max(0,i-1):i+4])})
(p/'constructor-excerpts.json').write_text(json.dumps(ex,indent=2)+'\n')
(p/'README.txt').write_text('Pinned namespace-key oracle for #261.\nRun: python3 runner.py (two compile+Node executions).\nActual parse ns (analyze-deps/load-macros disabled), ensure-defs, def, registered analyzer macro invocation; no synthetic target namespace record. Registration of the observer macro namespace is fixture setup, not namespace provenance evidence.\nRaw IHash wrappers record fields before exact original delegation with original this/argument. No extra hash/equality calls, memo writes or printing during capture. Raw rows use JS fields/arrays; output occurs at end. Prototype methods and NS_CACHE contents restored in finally.\nUpstream constructor citations: analyzer.cljc3503-3515 ns-info;5091 ensure-defs; compiler.cljc emit-keyword. Full pinned files retain upstream notices. Compiled analyzer JS and complete output tree retained.\nDefault cljs.user name symbol already numeric; actual parsed namespace name remains nil. All ten fresh reader controls, one source value and actual macro source value remain nil.\nAll current run failures (none) and historical structural setup failures retained. Not Suss acceptance; no blanket spelling-based warming or numeric receipt authority. Environment/JRE/Maven cache paths are external development prerequisites, not an independently archived toolchain.\n')
files=sorted(f for f in p.rglob('*') if f.is_file() and '.cpcache' not in f.parts and 'clj-cache' not in f.parts)
manifest={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
out=p.parent/'m4-namespace-key-oracle-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)))
 data=(json.dumps({'schema':1,'files':manifest},indent=2)+'\n').encode();info=tarfile.TarInfo('MANIFEST.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
with tarfile.open(out,'r:gz') as t:
 assert len(t.getmembers())==len(manifest)+1
 for name,h in manifest.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h
print(json.dumps({'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'receipt':receipt},indent=2))
