(ns suss-oracle.namespace-keys
 (:require [cljs.analyzer :as ana] [cljs.env :as env] [cljs.js :as cljs]
           [cljs.tools.reader :as reader]))
(def rows (array))
(def dispatches (array))
(def stage (array "setup"))
(def selected #js ["name" "requires" "renames" "uses" "require-macros" "use-macros" "rename-macros" "excludes" "defs"])
(defn selected? [value]
 (and (keyword? value) (nil? (.-ns value)) (not= -1 (.indexOf selected (.-name value)))))
(defn observe-hash [kind original]
 (fn [coll]
  (this-as receiver
   (let [memo (.-_hash receiver) n (.-name receiver)]
    (when (or (and (= kind "keyword") (selected? receiver))
              (and (= kind "symbol") (= n "reader-value")))
     (.push dispatches #js {:stage (aget stage 0) :kind kind :name n
                           :before memo :nil-branch (nil? memo)}))
    (.call original receiver coll)))))
(defn leaf [label value]
 (let [memo (.-_hash value) n (.-name value) ns (.-ns value)]
  (.push rows #js {:label label :kind (if (keyword? value) "keyword" "symbol")
                  :name n :namespace ns :memo memo :nil (nil? memo)})))
(defn ns-record [label record]
 (doseq [entry record]
  (let [k (key entry) v (val entry)]
   (when (selected? k)
    (leaf label k)
    (when (or (keyword? v) (symbol? v)) (leaf (str label "/value") v))))))
(defn -main []
 (when (nil? cljs.core/NS_CACHE) (set! cljs.core/NS_CACHE (atom {})))
 (let [kp (.-prototype cljs.core/Keyword) sp (.-prototype cljs.core/Symbol)
       method "cljs$core$IHash$_hash$arity$1" kh (aget kp method) sh (aget sp method)
       cache cljs.core/NS_CACHE old-cache @cache seen (array 0)]
  (try
   (aset kp method (observe-hash "keyword" kh))
   (aset sp method (observe-hash "symbol" sh))
   (aset stage 0 "cold-source-controls")
   (doseq [text [":name" ":requires" ":renames" ":uses" ":require-macros" ":use-macros" ":rename-macros" ":excludes" ":defs" "reader-value"]]
    (leaf "fresh-reader-control" (reader/read-string text)))
   (let [source (reader/read-string "(identity :name)")]
    (leaf "source-value-control" (second source)))
   (aset stage 0 "empty-state")
   (let [state (cljs/empty-state) target 'suss-oracle.namespace-target
         lib 'suss-oracle.namespace-macros macro-ns (symbol (str lib "$macros"))
         analyze (fn [form]
          (binding [env/*compiler* state ana/*cljs-ns* target
                    ana/*analyze-deps* false ana/*load-macros* false]
           (ana/analyze (assoc (ana/empty-env) :ns (ana/get-namespace target)) form)))
         observer (fn [form macro-env value]
          (aset stage 0 "inside-actual-macro")
          (aset seen 0 (inc (aget seen 0)))
          (ns-record "actual-macro-env-ns-key" (:ns macro-env))
          (leaf "actual-macro-source-value" (second form))
          17)]
    (binding [env/*compiler* state]
     (ns-record "initial-default-namespace-key" (ana/get-namespace 'cljs.user)))
    (aset stage 0 "analyze-ns")
    (let [ast (analyze (reader/read-string "(ns suss-oracle.namespace-target (:refer-clojure :exclude [map]) (:require [cljs.string :as strings :refer [join] :rename {join renamed-join}]))"))]
     (assert (= :ns (:op ast)))
     (ns-record "actual-ns-ast-key" ast))
    (aset stage 0 "ensure-defs")
    (binding [env/*compiler* state] (ana/ensure-defs target))
    (aset stage 0 "analyze-def")
    (analyze (reader/read-string "(def ^{:audit :reader-value} watched 17)"))
    (binding [env/*compiler* state]
     (ns-record "actual-compiler-namespace-key" (ana/get-namespace target)))
    (aset stage 0 "register-macro")
    (swap! state assoc-in [::ana/namespaces macro-ns]
     {:name macro-ns :defs {'observe {:name (symbol (str macro-ns) "observe")
       :macro true :method-params [['&form '&env 'value]] :max-fixed-arity 3}}})
    (set! (.-cljs$lang$macro observer) true)
    (swap! cache assoc macro-ns (create-ns macro-ns #js {:observe observer}))
    (aset stage 0 "analyze-macro-call")
    (let [ast (analyze (reader/read-string "(suss-oracle.namespace-macros/observe :defs)"))]
     (assert (= 1 (aget seen 0)))
     (assert (= 17 (:val ast))))
    ;; Output only after all non-hashing field snapshots and real dispatches.
    (js/console.log (.stringify js/JSON #js {:pin "c4295f303100bbf5afac449242d30bca1126f1a1"
                   :macro-calls (aget seen 0) :rows rows :dispatches dispatches})))
   (finally (aset kp method kh) (aset sp method sh) (reset! cache old-cache)))))
(set! *main-cli-fn* -main)
