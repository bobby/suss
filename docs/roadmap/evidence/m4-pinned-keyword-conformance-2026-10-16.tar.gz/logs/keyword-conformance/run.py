import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-keyword-conformance-evidence')
cache=pathlib.Path('/home/bobby/.cache/suss-m4-work/keyword-conformance')
def freeze():
    names=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
    return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in names if p and (root/p).is_file()}
before=freeze()
(cache/'freeze-before.json').write_text(json.dumps(before,indent=2)+'\n')
(cache/'test.patch').write_bytes(subprocess.check_output(['git','diff','--','crates/suss-compile/tests/clojure_test_suite.rs'],cwd=root))
for name in ['crates/suss-compile/tests/clojure_test_suite.rs','vendor/clojure-test-suite/upstream/test/clojure/core_test/keyword.cljc','tests/oracle/clojure-test-suite-observations.json']:
    (cache/pathlib.Path(name).name).write_bytes((root/name).read_bytes())
cmd=['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','pinned_keyword_namespace_keeps_values','--','--exact','--test-threads=2','--nocapture']
env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']='/home/bobby/.cache/suss-m4-work/keyword-conformance-target';env['SUSS_KEYWORD_CONFORMANCE_CAPTURE']=str(cache)
start=time.time()
(cache/'command.json').write_text(json.dumps({'cwd':str(root),'argv':cmd,'env':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_TARGET_DIR','SUSS_KEYWORD_CONFORMANCE_CAPTURE']},'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()},indent=2)+'\n')
with (cache/'run.log').open('wb') as log:
    code=subprocess.call(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
after=freeze();(cache/'freeze-after.json').write_text(json.dumps(after,indent=2)+'\n')
result={'exit_code':code,'elapsed_seconds':time.time()-start,'unchanged':before==after,'tracked_files':len(before),'changed':[p for p in before if before[p]!=after.get(p)],'test_source_sha256':before['crates/suss-compile/tests/clojure_test_suite.rs'],'keyword_source_sha256':before['vendor/clojure-test-suite/upstream/test/clojure/core_test/keyword.cljc']}
(cache/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
