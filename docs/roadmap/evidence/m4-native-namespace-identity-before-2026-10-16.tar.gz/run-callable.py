import pathlib,subprocess,hashlib,json,os,time
root=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access');p=pathlib.Path(__file__).parent
fixture='crates/suss-cli/tests/compiled_macro_namespace_identity.rs'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head.startswith('4ab8a76')
files=sorted(f for f in (root/'crates').rglob('*') if f.is_file() and f.suffix in ['.rs','.sus'])+sorted(f for f in (root/'runtime/bootstrap').glob('*') if f.is_file())
before={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
(p/'callable-attempt1-freeze-before.json').write_text(json.dumps(before,indent=2)+'\n')
(p/'callable-attempt1-test.rs').write_bytes((root/fixture).read_bytes())
(p/'oracle-observations.json').write_bytes(pathlib.Path('/home/bobby/.cache/suss-m4-work/namespace-sharing-oracle/run1-observations.json').read_bytes())
cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_namespace_identity','resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations','--','--exact','--test-threads=2','--nocapture']
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/analyzer-literal-key-target',SUSS_NAMESPACE_IDENTITY_OUTPUT=str(p/'callable-attempt1-observations.json'))
(p/'callable-attempt1-command.json').write_text(json.dumps({'head':head,'cwd':str(root),'argv':cmd,'env':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_TARGET_DIR','SUSS_NAMESPACE_IDENTITY_OUTPUT']},'default_fuel':True,'bootstrap_regenerated':False},indent=2)+'\n')
start=time.time()
with (p/'callable-attempt1.log').open('wb') as log:code=subprocess.call(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
after={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
(p/'callable-attempt1-freeze-after.json').write_text(json.dumps(after,indent=2)+'\n')
r={'exit':code,'seconds':time.time()-start,'unchanged':before==after,'frozen_paths':len(before),'fixture_sha256':before[fixture],'changed':[n for n in before if before[n]!=after.get(n)],'head':head}
(p/'callable-attempt1-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
