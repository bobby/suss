//! Typed views of the genuine caller analysis state, never inferred from values.
//! This is a compiler interface, not an implementation of cljs.analyzer's
//! JS extern/module/warning branches or a source macro evaluator.
use super::{hir, resolve, Diagnostic, ExpansionContext};
use std::{collections::BTreeMap, ops::Range, sync::Arc};
use suss_reader::{
    forms::{Form, Kind},
    Symbol,
};

/// Immutable compiler namespace revisions, separate from runtime bound values.
/// Declared namespaces lacking a source scope remain explicit entries with None.
#[derive(Debug, Clone)]
pub struct CompilerNamespaceCatalog {
    pub phase: resolve::Phase,
    pub current: String,
    pub namespaces: BTreeMap<String, Option<Arc<hir::SourceNamespace>>>,
    pub native_interfaces: Vec<NativeInterfaceFact>,
}

/// A typed host interface proven by an actual phase-specific compiler binding.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NativeInterfaceFact {
    pub global: resolve::Global,
    pub kind: NativeInterfaceKind,
    pub export: &'static str,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NativeInterfaceKind {
    NativeObject,
}

fn native_interface_facts(
    environment: &resolve::Environment,
    phase: resolve::Phase,
) -> Vec<NativeInterfaceFact> {
    let symbol = Symbol { namespace: Some("js".into()), name: "Object".into() };
    match environment.resolve(phase, &symbol, 0..0) {
        Ok(resolve::Binding::Core { global, export: "object-constructor" })
            if global.phase() == phase && global.namespace() == "js" && global.name() == "Object" =>
        {
            vec![NativeInterfaceFact {
                global,
                kind: NativeInterfaceKind::NativeObject,
                export: "object-constructor",
            }]
        }
        _ => Vec::new(),
    }
}

impl CompilerNamespaceCatalog {
    pub fn capture(environment: &resolve::Environment, phase: resolve::Phase) -> Self {
        Self {
            phase,
            current: environment.current_namespace(phase).to_owned(),
            namespaces: environment
                .declared_namespaces(phase)
                .map(|namespace| {
                    (
                        namespace.to_owned(),
                        hir::SourceNamespace::capture_namespace(environment, phase, namespace)
                            .map(Arc::new),
                    )
                })
                .collect(),
            native_interfaces: native_interface_facts(environment, phase),
        }
    }

    /// Pinned find-ns-starts-with compares the complete needle with the first
    /// namespace segment. It does not perform a prefix or substring match.
    pub fn starts_with_namespace_segment(&self, needle: &str) -> bool {
        self.namespaces
            .keys()
            .any(|namespace| namespace.split('.').next() == Some(needle))
    }
}

impl ExpansionContext<'_> {
    /// Current resolution catalog differs from the enclosing source snapshot:
    /// provisional definitions published during analysis must be visible here.
    pub fn resolution_catalog(&self) -> Arc<hir::SourceNamespace> {
        Arc::new(hir::SourceNamespace::capture(self.environment, self.phase))
    }

    /// All lexical entries, including unused locals and field captures. A local
    /// shadows an identically named field, exactly as the existing &env graph.
    pub fn lexical_bindings(&self) -> BTreeMap<String, hir::SourceBinding> {
        let mut bindings = BTreeMap::new();
        for (name, field) in self.fields.iter() {
            bindings.insert(
                name.clone(),
                hir::SourceBinding::Field(field.clone()),
            );
        }
        for (name, local) in self.locals.iter() {
            bindings.insert(
                name.clone(),
                hir::SourceBinding::Local(local.clone()),
            );
        }
        bindings
    }

    /// Resolve only actual portable bindings using the same aliases/refers,
    /// exclusions and phase as source analysis. Missing names remain errors.
    /// `include_locals=false` implements the macro helpers' dissoc-env-locals
    /// operation without modifying the caller or guessing a global identity.
    pub fn resolve_binding_fact(
        &self,
        symbol: &Symbol,
        span: Range<usize>,
        include_locals: bool,
    ) -> Result<hir::SourceBinding, Diagnostic> {
        if include_locals && symbol.namespace.is_none() {
            if let Some(local) = self.locals.get(&symbol.name) {
                return Ok(hir::SourceBinding::Local(local.clone()));
            }
            if let Some(field) = self.fields.get(&symbol.name) {
                return Ok(hir::SourceBinding::Field(field.clone()));
            }
        }
        let binding = self.environment.resolve(self.phase, symbol, span)?;
        let global = binding.global().clone();
        let declaration = self.environment.shared_definition_info(&global).cloned();
        Ok(hir::SourceBinding::Global {
            global,
            declaration,
        })
    }

    /// Actual protocol declarations and overloads. Bundle positions are ABI
    /// facts and must not be confused with ClojureScript fast-path mask bits.
    pub fn protocol_signature_facts(
        &self,
        symbol: &Symbol,
        span: Range<usize>,
    ) -> Result<(resolve::Global, BTreeMap<String, Vec<usize>>), Diagnostic> {
        let binding = self.environment.resolve(self.phase, symbol, span.clone())?;
        let global = binding.global().clone();
        let methods = self
            .environment
            .protocols
            .get(&global)
            .ok_or_else(|| Diagnostic {
                span,
                message: format!("Not a declared protocol: {symbol}"),
            })?;
        let signatures = methods
            .iter()
            .map(|method| {
                (
                    method.name.clone(),
                    method.signatures.iter().map(|(arity, _)| *arity).collect(),
                )
            })
            .collect();
        Ok((global, signatures))
    }
}

/// Exact six-key elision from pinned analyzer.cljc elide-reader-meta. Input is
/// normalized reader metadata; values and qualified lookalike keys are retained.
/// This helper does not elide ::analyzed or arbitrary analyzer/user metadata.
pub fn elide_reader_metadata(form: &Form) -> Result<Vec<Form>, Diagnostic> {
    let pairs = hir::reader_metadata_pairs(form)?;
    Ok(pairs.chunks_exact(2).filter(|pair| {
        !matches!(&pair[0].kind, Kind::Keyword(key) if key.namespace.is_none()
            && matches!(key.name.as_str(), "file" | "line" | "column" | "end-column" | "end-line" | "source"))
    }).flat_map(|pair| pair.iter().cloned()).collect())
}

#[cfg(test)]
mod native_interface_tests {
    use super::*;

    #[test]
    fn native_object_fact_requires_exact_core_export_in_each_phase() {
        for phase in [resolve::Phase::Runtime, resolve::Phase::Macro] {
            let env = resolve::Environment::new("user").unwrap();
            let facts = native_interface_facts(&env, phase);
            assert_eq!(facts.len(), 1);
            assert_eq!(facts[0].kind, NativeInterfaceKind::NativeObject);
            assert_eq!(facts[0].export, "object-constructor");
            assert_eq!(facts[0].global.phase(), phase);
            assert_eq!(facts[0].global.namespace(), "js");
            assert_eq!(facts[0].global.name(), "Object");
        }
    }

    #[test]
    fn replaced_object_binding_emits_no_native_fact_in_either_phase() {
        for phase in [resolve::Phase::Runtime, resolve::Phase::Macro] {
            let mut env = resolve::Environment::new("user").unwrap();
            env.declare_cell(phase, "js", "Object").unwrap();
            let symbol = Symbol {
                namespace: Some("js".into()),
                name: "Object".into(),
            };
            assert!(matches!(
                env.resolve(phase, &symbol, 0..0),
                Ok(resolve::Binding::Cell(_))
            ));
            assert!(native_interface_facts(&env, phase).is_empty());
        }
    }
}
