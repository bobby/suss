from pathlib import Path
import subprocess,os,time,json,hashlib,shutil
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access')
paths=json.loads((c.parent/'source-roots-combined-precompile-5-freeze.json').read_text())
freeze={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths}
for rel in freeze:
 p=c/'source-before'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,p)
(c/'freeze-before.json').write_text(json.dumps(freeze,indent=2)+'\n')
shutil.copyfile(c.parent/'source-roots-session-bootstrap.log',c/'original-bootstrap-failure.log')
shutil.copyfile(c.parent/'source-roots-bootstrap-failure-receipt.json',c/'original-bootstrap-failure-receipt.json')
cmd=['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--',str(c/'bootstrap-output')]
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c.parent/'analyzer-literal-key-target'),SUSS_HIR_COW_TRACE='1')
receipt={'command':cmd,'cwd':str(r),'env_overrides':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_TARGET_DIR','SUSS_HIR_COW_TRACE']},'input_count':len(freeze),'status':'running','limits':'Native diagnostic bookkeeping is additional uncharged observer work; explicit production debits and allowances unchanged. Innermost-context buckets partition request charge calls; not timings or guest instruction costs.'}
(c/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
start=time.monotonic()
with (c/'bootstrap.log').open('w') as f:
 result=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
after={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths}
(c/'freeze-after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt.update(status='terminal',exit=result.returncode,seconds=time.monotonic()-start,changed=[p for p in freeze if freeze[p]!=after[p]])
(c/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
