import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path('/home/bobby/Work/code/bobby/suss')
out=Path('/tmp/suss-m4-prototype-origin-result.json')
paths=sorted(p for p in (root/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus'])
paths += sorted((root/'runtime/bootstrap').glob('*'))
start={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}
state={'current':None,'stages':[],'source-hashes':start}
env=os.environ.copy();env.update(PATH='/home/bobby/.cargo/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(root/'target-m4-prototype'))
stages=[('prototype origin','prototype_origin'),('initial source classes','initial_source_classes'),('recorded schema audit','recorded_class_schema_audit'),('constructor inputs','constructor_inputs'),('construction records','construction_records'),('canonical seeds','canonical_seeds'),('canonical methods','canonical_methods::tests::canonical_methods_'),('source array inputs','source_array_inputs'),('source facts','source_facts'),('metadata expectations','metadata_expectations')]
for name,filter_ in stages+[('provenance',None)]:
 cmd=['cargo','test','-p','suss-compile','--locked','--lib',filter_,'--','--test-threads=2'] if filter_ else ['python3','scripts/check_record_macro_provenance.py']
 log=Path('/tmp/suss-m4-prototype-origin-'+(filter_ or 'provenance')+'.log')
 with log.open('wb') as f:
  process=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  state['current']={'name':name,'pid':process.pid,'log':str(log),'command':cmd};out.write_text(json.dumps(state,indent=2)+'\n')
  code=process.wait()
 state['stages'].append({**state['current'],'exit_code':code});state['current']=None
 state['source-unchanged']=all(p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==start[str(p.relative_to(root))] for p in paths if str(p.relative_to(root)) in start)
 out.write_text(json.dumps(state,indent=2)+'\n')
 print(json.dumps(state['stages'][-1]),flush=True)
 if code or not state['source-unchanged']:sys.exit(code or 1)
