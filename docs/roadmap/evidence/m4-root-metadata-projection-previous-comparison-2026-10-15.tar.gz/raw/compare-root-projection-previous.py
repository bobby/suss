from pathlib import Path
import hashlib,json,os,subprocess,tarfile
root=Path('/home/bobby/Work/code/bobby/suss');cache=Path('/home/bobby/.cache/suss-m4-work')
fixed=json.loads((cache/'suss-m4-root-projection-result.json').read_text())
assert fixed['current'] is None,'Finish current cohort first'
assert fixed['source-unchanged']
for name,digest in fixed['source-hashes'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
archive=root/'docs/roadmap/evidence/m4-interned-form-copy-validated-2026-10-15.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='cd26297ddc4ab719b62a43da861f08ec41f40d670369ce785858cf1e8b2f6679'
paths=['crates/suss-compile/src/portable/origin/form_metadata.rs','crates/suss-compile/src/portable_macro_graph.rs',*[f'runtime/bootstrap/{p}' for p in ['macro.json','macro.wasm','runtime.json','runtime.wasm']]]
saved={p:(root/p).read_bytes() for p in paths}
with tarfile.open(archive) as t:
 old={p:t.extractfile('snapshot/'+p).read() for p in paths}
 for name,digest in fixed['source-hashes'].items():
  previous=t.extractfile('snapshot/'+name).read()
  if name not in paths:assert hashlib.sha256(previous).hexdigest()==digest,name
backup=cache/'root-projection-fixed-backup';backup.mkdir(exist_ok=True)
for name,data in saved.items():
 p=backup/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
state={'base_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'current':None,'stages':[],'restored':False,'paths':paths,'fixed_hashes':{k:hashlib.sha256(v).hexdigest() for k,v in saved.items()},'old_hashes':{k:hashlib.sha256(v).hexdigest() for k,v in old.items()}}
out=cache/'root-projection-previous-comparison-result.json'
def record():out.write_text(json.dumps(state,indent=2)+'\n')
try:
 for name,data in old.items():(root/name).write_bytes(data)
 record()
 env=os.environ.copy();env.update(PATH='/home/bobby/.cargo/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(root/'target-m4-prototype'),TMPDIR=str(cache),SUSS_MACRO_FUEL_TRACE='1')
 command=['cargo','test','--workspace','--locked','--no-fail-fast','--test','compiled_macro_declaration_metadata','--test','compiled_macro_declaration_functions','--','--test-threads=2','--nocapture']
 log=cache/'root-projection-previous-declarations.log'
 with log.open('wb') as stream:
  process=subprocess.Popen(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
  state['current']={'pid':process.pid,'command':command,'log':str(log)};record();code=process.wait()
 state['stages'].append({**state['current'],'exit_code':code});state['current']=None;record()
finally:
 conflicts=[]
 for name,data in saved.items():
  if (root/name).read_bytes()!=old[name]:conflicts.append(name)
  else:(root/name).write_bytes(data)
 state['restoration_conflicts']=conflicts
 state['restored']=not conflicts and all((root/name).read_bytes()==data for name,data in saved.items())
 state['fixed_snapshot_matches']=all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in fixed['source-hashes'].items())
 record()
 print(json.dumps({'stages':state['stages'],'restored':state['restored'],'fixed_snapshot_matches':state['fixed_snapshot_matches']}),flush=True)
