import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('census',Path(__file__).with_name('parse.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base='''source-snapshot phase=add-cuts count=0 event=before remaining=Some(1000)
source-snapshot phase=add-cuts count=0 event=after remaining=Some(1000)
source-snapshot-array ordinal=0 storage=i16 count=4 event=before remaining=Some(1000)
source-snapshot-allocation type=Atom count=4 element_bytes=48 requested_bytes=192
source-snapshot phase=allocation-debit count=4 event=before remaining=Some(1000)
source-snapshot phase=allocation-debit count=4 event=after result=Ok(()) remaining=Some(808)
source-snapshot-array ordinal=0 storage=i16 count=4 event=after result=Ok(()) remaining=Some(790)
source-snapshot-summary input_cuts=0 nodes=Some(1) complete=true remaining=Some(790)
'''
r=m.parse(base.encode());g=r['groups'][0];assert (g['completed_elements'],g['inclusive_fuel'],g['allocation_debit_fuel'])==(4,210,192)
assert r['captures'][0]['arrays'][0]['requested_bytes_by_native_type']=={'Atom':192}
r=m.parse(base.replace('result=Ok(()) remaining=Some(790)','result=Err("fuel") remaining=Some(790)').replace('nodes=Some(1) complete=true','nodes=None complete=false').encode());assert r['groups'][0]['status']=='failed/error';assert r['groups'][0]['completed_elements']==0
r=m.parse(base[:base.index('source-snapshot-array ordinal=0 storage=i16 count=4 event=after')].encode());assert r['captures'][0]['status']=='open';assert r['groups']==[];assert 'open_array' in r['captures'][0]
r=m.parse(b'no census labels');assert r['instrumentation_observed'] is False
try:m.parse(base.replace('ordinal=0 storage=i16 count=4 event=after','ordinal=1 storage=i16 count=4 event=after').encode())
except AssertionError:pass
else:raise AssertionError('mismatched array accepted')
print('5 synthetic parser checks passed; no runtime/type census executed')
