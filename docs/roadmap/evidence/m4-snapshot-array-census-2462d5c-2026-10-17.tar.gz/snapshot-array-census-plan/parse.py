#!/usr/bin/env python3
"""Parse proposed array census. No compiler/runtime calls. JSON to stdout."""
import sys,re,json,hashlib,collections
from pathlib import Path

def parse(data):
    captures=[]; cap=None; active=None; debits=[]; errors=[]; stage=None; groups={}
    lines=data.decode().splitlines()
    def group(storage,status):
        return groups.setdefault((storage,status),dict(arrays=0,declared_elements=0,completed_elements=0,inclusive_fuel=0,allocation_requested_bytes=0,allocation_debit_fuel=0,allocation_attempts=0))
    for lineno,line in enumerate(lines,1):
        m=re.search(r'source-child-fuel source=(\S+) variant=(None|Some\(\d+\)) stage=(\S+)',line)
        if m:stage='/'.join(m.groups())
        if re.search(r'source-snapshot phase=add-cuts .*event=before',line):
            assert cap is None,('overlapping capture',lineno)
            cap=dict(id=len(captures),start_line=lineno,stage=stage,arrays=[],status='open')
        m=re.search(r'source-snapshot-array ordinal=(\d+) storage=(\S+) count=(\d+) event=(before|after).*remaining=(Some\((\d+)\)|None)',line)
        if m:
            ordinal,storage,count,event,_,fuel=m.groups();fuel=None if fuel is None else int(fuel)
            key=(int(ordinal),storage,int(count))
            assert cap is not None,('array outside capture',lineno)
            if event=='before':
                assert active is None
                active=dict(ordinal=key[0],storage=storage,count=key[2],start_fuel=fuel,start_line=lineno,allocation_requested_bytes=0,allocation_debit_fuel=0,allocation_attempts=0,requested_bytes_by_native_type={})
            else:
                assert active is not None and (active['ordinal'],active['storage'],active['count'])==key
                active.update(end_line=lineno,result='error' if 'result=Err' in line else 'ok',inclusive_fuel=None if fuel is None or active['start_fuel'] is None else active['start_fuel']-fuel)
                assert not debits
                cap['arrays'].append(active);active=None
        m=re.search(r'source-snapshot-allocation type=(\S+).*requested_bytes=(\d+)',line)
        if m and active is not None:
            active['allocation_requested_bytes']+=int(m[2]);active['allocation_attempts']+=1
            bytype=active['requested_bytes_by_native_type'];bytype[m[1]]=bytype.get(m[1],0)+int(m[2])
        m=re.search(r'source-snapshot phase=allocation-debit .*event=(before|after).*remaining=(Some\((\d+)\)|None)',line)
        if m and active is not None:
            e,_,f=m.groups();f=None if f is None else int(f)
            if e=='before':debits.append(f)
            else:
                start=debits.pop()
                if start is not None and f is not None:active['allocation_debit_fuel']+=start-f
        if 'source-snapshot-summary ' in line:
            assert cap is not None and active is None and not debits,('incomplete array interval',lineno)
            cap['status']='complete' if 'complete=true' in line else 'failed';cap['end_line']=lineno
            captures.append(cap);cap=None
    # Truncated log retained, never treated as complete/zero work.
    if cap is not None:
        if active is not None:cap['open_array']=active
        captures.append(cap)
    for c in captures:
        for a in c['arrays']:
            status=c['status']+'/'+a['result'];g=group(a['storage'],status)
            g['arrays']+=1;g['declared_elements']+=a['count']
            if a['result']=='ok':g['completed_elements']+=a['count']
            for k in ['inclusive_fuel','allocation_requested_bytes','allocation_debit_fuel','allocation_attempts']:
                if a.get(k) is not None:g[k]+=a[k]
    return dict(instrumentation_observed=bool(groups) or active is not None,qualification='Inclusive arrays enclose allocation/atom work. Failed/open captures are not published snapshots. Uninstrumented logs do not prove zero arrays.',groups=[dict(storage=s,status=t,**v) for (s,t),v in sorted(groups.items())],captures=captures)

if __name__=='__main__':
    data=Path(sys.argv[1]).read_bytes();r=parse(data);r['raw_sha256']=hashlib.sha256(data).hexdigest();r['raw']=sys.argv[1];print(json.dumps(r,indent=2))
