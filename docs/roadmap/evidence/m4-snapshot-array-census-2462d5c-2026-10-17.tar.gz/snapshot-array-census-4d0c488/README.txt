CACHE-ONLY REVIEW PATCH; NOT APPLIED OR COMPILED.
Base commit4d0c4887831800385ad36b37bf5a7fdd5ed938dc. manifest.json hashes exact before/after/diff.
One array observer pair encloses original array allocation/loop Result. Original Result runs exactly once and is propagated after optional logging. Original element-loop bytes unchanged.
Tracing off skips element-type query/fuel reads/logs; one flag/mode branch per array remains. No per-element observer/charge. Tracing on adds native type inspection/formatting/I/O wall work, no added guest calls or charged work.
No charged layout, type/length check, root, allocation policy, element read/order, error or tariff changed. Incomplete arrays log Err without claiming completed element count.
Parser and synthetic tests are in sibling snapshot-array-census-plan/. Runtime census not executed. Parser distinguishes complete/failed/open captures and requested bytes from fuel actually debited.
Rustfmt parsed cache afterfile via --emit stdout (output discarded, file unchanged); no Cargo/typecheck/bootstrap performed. Locked Wasmtime49.0.1 enum/type API must be checked by actual combined compile. Independent review/application remains main-owned after producer49951 terminal.
