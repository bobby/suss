from pathlib import Path
import re,json,hashlib,collections
B=Path('/home/bobby/.cache/suss-m4-work');out=Path(__file__).parent
p=B/'native-named-field-loop-source-candidate/map.log';raw=p.read_text();groups=[]
for m in re.finditer(r'^macro-fuel (\S+) ([\w-]+): (\d+)$',raw,re.M):
 target,stage,value=m[1],m[2],int(m[3])
 if stage=='start':groups.append({'ordinal':len(groups)+1,'target':target,'stages':[]})
 assert groups and groups[-1]['target']==target
 groups[-1]['stages'].append({'stage':stage,'remaining':value})
order=['start','provenance','caller-form','caller-environment','arguments','invoked','decoded'];tot=collections.Counter();by={}
for g in groups:
 assert [x['stage'] for x in g['stages']]==order[:len(g['stages'])]
 t=by.setdefault(g['target'],{'count':0,'completed':0,'cost':collections.Counter()});t['count']+=1;t['completed']+=g['stages'][-1]['stage']=='decoded'
 for a,b in zip(g['stages'],g['stages'][1:]):
  assert a['remaining']>=b['remaining'];d=a['remaining']-b['remaining'];tot[b['stage']]+=d;t['cost'][b['stage']]+=d
receipt=json.loads((p.parent/'receipt.json').read_text());r={'current':receipt['current'],'raw_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'groups':groups,'completed':sum(g['stages'][-1]['stage']=='decoded'for g in groups),'disjoint_observed':tot,'by_target':by,'nested_lazy':{'completed_calls':len(re.findall(r'^macro-lazy-invoke .*stage=after.*success=true$',raw,re.M)),'fuel':sum(map(int,re.findall(r'^macro-lazy-invoke .*stage=after.*delta=Some\((\d+)\) success=true$',raw,re.M)))},'terminal_summary':re.findall(r'test result:.*',raw),'limits':['Nestedlazy cost not added to stage totals','d21 trace is historical, not exact2bc perstage control','No missed terminal/incomplete stage treatedzero','Only terminalreceipt/log provides finalresults']}
(out/'candidate-map-attribution.json').write_text(json.dumps(r,indent=2)+'\n');print({'current':r['current'],'starts':len(groups),'decoded':r['completed'],'last':groups[-1] if groups else None,'summaries':r['terminal_summary']})
