from pathlib import Path
import json,re,hashlib
B=Path('/home/bobby/.cache/suss-m4-work');out=Path(__file__).parent
runs=['native-named-field-loop-baseline','native-named-field-loop-baseline-2','native-named-field-loop-candidate','native-named-field-loop-candidate-followup','native-named-field-loop-source-candidate'];report={'runs':{},'qualified_zero_selections':[]}
for run in runs:
 p=B/run
 if not p.exists():continue
 r=json.loads((p/'receipt.json').read_text());rows=[]
 for st in r['stages']:
  log=p/(st['name']+'.log')
  if not log.exists():continue
  raw=log.read_text();executed=re.findall(r'^test (\S+) \.\.\. (ok|FAILED)$',raw,re.M)
  summ=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)
  row={'name':st['name'],'exit':st.get('exit'),'executed':executed,'summaries':summ,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};rows.append(row)
  if st.get('exit')==0 and summ and not executed:report['qualified_zero_selections'].append({'run':run,'stage':st['name'],'qualification':'Zero executed tests; not pass credit. Correct filters rerun in candidate-followup.'})
 report['runs'][run]={'current':r['current'],'final_changed':r.get('final_changed'),'stages':rows}
report['cost_comparison']=json.loads((B/'named-field-matched-cost-comparison.json').read_text());report['limits']=['Generic equality lengthmiss penalty19->25 retained','Completedstatic RuntimeABI work is not map saving forecast','No claim originalfailedallowance known from earlierlog; correctedrawsweep measures firstsuccess798vsdebit802','No issue/fullbaseline/CI claim']
(out/'current-summary.json').write_text(json.dumps(report,indent=2)+'\n');print('saved raw execution matrix')
