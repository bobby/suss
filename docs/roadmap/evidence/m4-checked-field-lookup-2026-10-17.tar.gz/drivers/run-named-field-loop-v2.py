from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
b=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');out=b/'native-named-field-loop-v2';out.mkdir(exist_ok=False)
paths=set(json.loads((b/'native-prototype-buffer-candidate-3/after-bootstrap-freeze.json').read_text()))
def freeze():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snap(label,h):
 (out/(label+'-freeze.json')).write_text(json.dumps(h,indent=2)+'\n')
 for p in h:
  d=out/label/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/p,d)
h=freeze();snap('before',h)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(b/'m4-cost-diagnostic-target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2')
for k in list(env):
 if k.startswith('SUSS_') and ('TRACE' in k or 'CAPTURE' in k):env.pop(k)
def test(pkg,target,selector=None,lib=False,exact=False):
 c=['cargo','test','-p',pkg,'--locked']+(['--lib'] if lib else ['--test',target])
 if selector:c.append(selector)
 return c+['--']+(['--exact'] if exact else [])+['--test-threads=2','--nocapture']
plan=[('new-two',test('suss-compile','runtime_abi','checked_field_loop_regression::'))]
plan.append(('generic-field-baseline', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'runtime_abi', 'runtime_abi_nominal_constructor_duplicate_fields_follow_live_utf16_schema', '--', '--exact', '--test-threads=2', '--nocapture']))
plan.append(('runtime_abi_schema_field_character_guard_checks_every_utf16_unit', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'runtime_abi', 'runtime_abi_schema_field_character_guard_checks_every_utf16_unit', '--', '--exact', '--test-threads=2', '--nocapture']))
plan.append(('runtime_abi_named_storage_preserves_native_keys_and_rejects_malformed_tables', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'runtime_abi', 'runtime_abi_named_storage_preserves_native_keys_and_rejects_malformed_tables', '--', '--exact', '--test-threads=2', '--nocapture']))
plan.append(('runtime_abi_reserved_schema_names_keep_all_spellings_and_near_misses', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'runtime_abi', 'runtime_abi_reserved_schema_names_keep_all_spellings_and_near_misses', '--', '--exact', '--test-threads=2', '--nocapture']))
plan.append(('runtime_abi_property_key_comparison_preserves_utf16_live_mutation_and_error_order', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'runtime_abi', 'runtime_abi_property_key_comparison_preserves_utf16_live_mutation_and_error_order', '--', '--exact', '--test-threads=2', '--nocapture']))
plan.append(('runtime_abi_munged_field_aliases_copy_last_constructor_value_and_use_last_named_slot', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'runtime_abi', 'runtime_abi_munged_field_aliases_copy_last_constructor_value_and_use_last_named_slot', '--', '--exact', '--test-threads=2', '--nocapture']))
plan.append(('runtime_abi_native_name_normalization_keeps_exact_utf16_and_live_input_identity', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'runtime_abi', 'runtime_abi_native_name_normalization_keeps_exact_utf16_and_live_input_identity', '--', '--exact', '--test-threads=2', '--nocapture']))
plan.append(('runtime_abi_exception_info_getters_reject_malformed_named_schema_without_trapping', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'runtime_abi', 'runtime_abi_exception_info_getters_reject_malformed_named_schema_without_trapping', '--', '--exact', '--test-threads=2', '--nocapture']))
plan.append(('runtime_abi_method_lookup_preserves_live_values_equal_id_keys_and_first_match_after_gc', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'runtime_abi', 'runtime_abi_method_lookup_preserves_live_values_equal_id_keys_and_first_match_after_gc', '--', '--exact', '--test-threads=2', '--nocapture']))
plan += [('full-runtime-abi',test('suss-compile','runtime_abi')),
('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),
('named-properties',test('suss-cli','portable_named_properties')),
('object-methods',test('suss-cli','portable_object_methods')),
('source-input-owners',test('suss-compile',None,'portable_session::source_array_inputs::tests::source_input_owner_checks_poll_before_later_foreign_values',lib=True,exact=True)),
('constructors',test('suss-compile',None,'portable_session::constructor_inputs::tests::',lib=True)),
('core-import-full',test('suss-cli','core_import')),
('map',test('suss-compile','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss',exact=True)),
('source-child',test('suss-compile',None,'portable_macro_graph::source_roots::tests::source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo',lib=True,exact=True))]

state={'base':'2bc35d1b7964fef711543d5693778f7f0a9de596','input_count':len(h),'current':None,'process':{'pid':os.getpid(),'pgid':os.getpgid(0)},'stages':[],'env_overrides':{k:env[k]for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS']},'limits':'Carver approved v2 exact patch3d025002: original generic bodies restored, private helpers/find unchanged. All stages unchanged allowances. Map existing SUSS_MACRO_FUEL_TRACE=1; known map/sourcechild failures retained and continue; hard guard/boot failure stops.'}
def save():(out/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
for name,cmd in plan:
 assert freeze()==h
 if name=='source-child':
  env['SUSS_SOURCE_CHILD_FUEL_TRACE']='1';env['SUSS_SOURCE_MATERIALIZE_FUEL_TRACE']='1'
 else:
  env.pop('SUSS_SOURCE_CHILD_FUEL_TRACE',None);env.pop('SUSS_SOURCE_MATERIALIZE_FUEL_TRACE',None)
 if name=='map':
  env['SUSS_MACRO_FUEL_TRACE']='1';env['SUSS_CLOJURE_TEST_SUITE_CAPTURE']=str(out/'map-capture')
 else:
  env.pop('SUSS_MACRO_FUEL_TRACE',None);env.pop('SUSS_CLOJURE_TEST_SUITE_CAPTURE',None)
 state['current']=name;row={'name':name,'command':cmd,'trace_flags':{k:v for k,v in env.items() if k.startswith('SUSS_')}};state['stages'].append(row);save();print('starting',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 row.update(exit=p.returncode,seconds=time.monotonic()-start);after=freeze();row['changed']=[p for p in h if h[p]!=after[p]]
 if name=='bootstrap' and p.returncode==0:
  assert set(row['changed'])<={f'runtime/bootstrap/{phase}.{ext}'for phase in ['macro','runtime']for ext in ['json','wasm']}
  h=after;snap('after-bootstrap',h)
 else:assert not row['changed']
 save()
 if name!='bootstrap':
  raw=(out/(name+'.log')).read_text();row['result_lines']=[l for l in raw.splitlines() if l.startswith('test result:')];assert row['result_lines'] and not any('0 passed; 0 failed' in l for l in row['result_lines']), 'Zero test selection'
 save()
 if p.returncode and name not in ['map','source-child']:break
state['current']=None;final=freeze();state['final_changed']=[p for p in h if h[p]!=final[p]];save();print(json.dumps(state),flush=True)
