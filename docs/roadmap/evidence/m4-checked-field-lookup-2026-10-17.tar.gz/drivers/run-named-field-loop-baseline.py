from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
b=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');out=b/'native-named-field-loop-baseline';out.mkdir(exist_ok=False)
paths=set(json.loads((b/'native-prototype-buffer-candidate-3/after-bootstrap-freeze.json').read_text()))
def freeze():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snap(label,h):
 (out/(label+'-freeze.json')).write_text(json.dumps(h,indent=2)+'\n')
 for p in h:
  d=out/label/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/p,d)
h=freeze();snap('before',h)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(b/'m4-cost-diagnostic-target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2')
for k in list(env):
 if k.startswith('SUSS_') and ('TRACE' in k or 'CAPTURE' in k):env.pop(k)
plan=[('new-two',['cargo','test','-p','suss-compile','--locked','--test','runtime_abi','checked_field_loop_regression::','--','--test-threads=2','--nocapture']),('generic-field-baseline',['cargo','test','-p','suss-compile','--locked','--test','runtime_abi','runtime_abi_nominal_constructor_duplicate_fields_follow_live_utf16_schema','--','--exact','--test-threads=2','--nocapture'])]
state={'base':'2bc35d1b7964fef711543d5693778f7f0a9de596','input_count':len(h),'current':None,'stages':[],'env_overrides':{k:env[k]for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS']},'limits':'RuntimeABI production module; noSession/bootstrap prerequisite. Test-only exact approved fragment on unchanged runtime baseline; each measured row unchanged10M; no nestedrefill.'}
def save():(out/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
for name,cmd in plan:
 assert freeze()==h
 state['current']=name;row={'name':name,'command':cmd};state['stages'].append(row);save();print('starting',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 row.update(exit=p.returncode,seconds=time.monotonic()-start);after=freeze();row['changed']=[p for p in h if h[p]!=after[p]];assert not row['changed'];save()
 if p.returncode:break
state['current']=None;final=freeze();state['final_changed']=[p for p in h if h[p]!=final[p]];save();print(json.dumps(state),flush=True)
