from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
b=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');out=b/'native-named-field-loop-candidate-followup';out.mkdir(exist_ok=False)
paths=set(json.loads((b/'native-prototype-buffer-candidate-3/after-bootstrap-freeze.json').read_text()))
def freeze():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snap(label,h):
 (out/(label+'-freeze.json')).write_text(json.dumps(h,indent=2)+'\n')
 for p in h:
  d=out/label/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/p,d)
h=freeze();snap('before',h)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(b/'m4-cost-diagnostic-target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2')
for k in list(env):
 if k.startswith('SUSS_') and ('TRACE' in k or 'CAPTURE' in k):env.pop(k)
plan=[(name,['cargo','test','-p','suss-compile','--locked','--test','runtime_abi',name,'--','--exact','--test-threads=2','--nocapture'])for name in ['runtime_abi_reserved_schema_names_keep_all_spellings_and_near_misses', 'runtime_abi_property_key_comparison_preserves_utf16_live_mutation_and_error_order', 'runtime_abi_munged_field_aliases_copy_last_constructor_value_and_use_last_named_slot', 'runtime_abi_native_name_normalization_keeps_exact_utf16_and_live_input_identity', 'runtime_abi_exception_info_getters_reject_malformed_named_schema_without_trapping', 'runtime_abi_method_lookup_preserves_live_values_equal_id_keys_and_first_match_after_gc']]
state={'base':'2bc35d1b7964fef711543d5693778f7f0a9de596','input_count':len(h),'current':None,'stages':[],'env_overrides':{k:env[k]for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS']},'limits':'RuntimeABI production module; noSession/bootstrap prerequisite. Reviewed typed-helper candidate; corrected exact guard names, zero-test selections in earlierattempt not credited; each measured row unchanged10M; no nestedrefill.'}
def save():(out/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
for name,cmd in plan:
 assert freeze()==h
 state['current']=name;row={'name':name,'command':cmd};state['stages'].append(row);save();print('starting',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 row.update(exit=p.returncode,seconds=time.monotonic()-start);raw=(out/(name+'.log')).read_text();row['executed_result_lines']=[l for l in raw.splitlines() if l.startswith('test ') and ' ... ' in l];assert row['executed_result_lines'],('Exactfilter selected zero tests',name);after=freeze();row['changed']=[p for p in h if h[p]!=after[p]];assert not row['changed'];save()
 if p.returncode:break
state['current']=None;final=freeze();state['final_changed']=[p for p in h if h[p]!=final[p]];save();print(json.dumps(state),flush=True)
