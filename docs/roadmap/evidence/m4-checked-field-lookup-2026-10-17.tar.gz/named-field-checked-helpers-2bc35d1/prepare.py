from pathlib import Path
import subprocess,re,difflib,hashlib,json
b=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');rel='crates/suss-compile/src/runtime_abi/named_properties.rs';a=subprocess.check_output(['git','show','2bc35d1:'+rel],cwd=r,text=True);s=a
helper='''// Internal typed helpers are deliberately not exported or registered in names.
// Only guarded callers in this module can supply their checked references.
fn checked_function(
    b: &mut Builder, params: &[ValType], results: &[ValType],
    locals: &[(u32, ValType)], instructions: &[Instruction<'_>],
) -> u32 {
    let index = b.count;
    b.types.ty().function(params.iter().copied(), results.iter().copied());
    b.functions.function(b.next_type);
    b.next_type += 1;
    let mut function = Function::new(locals.iter().copied());
    for instruction in instructions { function.instruction(instruction); }
    function.instruction(&Instruction::End);
    b.code.function(&function);
    b.count += 1;
    index
}

'''
s=s.replace('pub(super) fn functions(b: &mut Builder)',helper+'pub(super) fn functions(b: &mut Builder)',1)
start=s.index('    // UTF-16 equality');end=s.index('    let mut callbacks',start);part=s[start:end]
loop=part[part.index('    for local in [0, 1]'):part.index('    let equal =')]
# Params typed left,typed right,known rightlength; loopindex now3,leftlen4.
loop=loop.replace('LocalTee(3)','LocalTee(4)').replace('LocalGet(3)','LocalGet(4)').replace('LocalGet(2)','LocalGet(3)').replace('LocalSet(2)','LocalSet(3)')
x=loop.index('    body.extend([\n        I32Ne,')
loop='''    body.extend([LocalGet(0), ArrayLen, LocalTee(4), LocalGet(2)]);
'''+loop[x:]
loop=loop.replace('LocalGet(local), RefCastNonNull(HeapType::Concrete(STRING)),','LocalGet(local),')
loop=loop.replace('            RefCastNonNull(HeapType::Concrete(STRING)),\n','')
wrapper=part[:part.index('    for local in [0, 1]')]
part='''    // Checked equality keeps the existing short-name and live-unit algorithm.
    // The third operand is the same immutable right-array length for this call.
    let mut body = Vec::new();
'''+loop+'''    let equal_checked = checked_function(b,
        &[reference(STRING), reference(STRING), ValType::I32], &[ValType::I32],
        &[(2, ValType::I32)], &body);
'''+wrapper+'''    body.extend([
        LocalGet(0), RefCastNonNull(HeapType::Concrete(STRING)),
        LocalGet(1), RefCastNonNull(HeapType::Concrete(STRING)), LocalTee(2),
        LocalGet(2), ArrayLen, Call(equal_checked),
    ]);
    let equal = b.function_with_locals("property-key-equal", &[VALUE, VALUE],
        &[ValType::I32], &[(1, reference(STRING))], &body);

'''
s=s[:start]+part+s[end:]
start=s.index('    // Named instance access');end=s.index('    // Stride one',start);part=s[start:end]
part=part.replace('    guard(&mut body, 0, STRING);\n','',1)
part,n=re.subn(r'LocalGet\(0\),\s*RefCastNonNull\(HeapType::Concrete\(STRING\)\),','LocalGet(0),',part);assert n==4,n
x=part.index('    let field_supported =');part=part[:x]+'''    let field_supported_checked = checked_function(b,
        &[reference(STRING)], &[ValType::I32], &[(3, ValType::I32)], &body);
    // Public export retains its original wrong-shape language-error guard.
    let mut body = vec![];
    guard(&mut body, 0, STRING);
    body.extend([LocalGet(0), RefCastNonNull(HeapType::Concrete(STRING)),
        Call(field_supported_checked)]);
    let _field_supported = b.function("property-field-name-supported", &[VALUE],
        &[ValType::I32], &body);

'''
s=s[:start]+part+s[end:]
start=s.index('    // Stride one');end=s.index('    for writing in [false, true]',start);part=s[start:end]
part=part.replace('    guard(&mut body, 0, ARGS);','    guard(&mut body, 0, ARGS);\n    body.extend([LocalGet(0), RefCastNonNull(HeapType::Concrete(ARGS)), LocalSet(7)]);',1)
assert part.count('    array(&mut body, 0);')==3;part=part.replace('    array(&mut body, 0);','    body.push(LocalGet(7));')
needle='''        // Field schemas have already established a STRING lookup key above.''';i=part.index(needle);z=part.index('        I32Const(0),\n        LocalSet(3),',i)
part=part[:z]+'''        LocalGet(1), RefCastNonNull(HeapType::Concrete(STRING)), LocalTee(8),
        ArrayLen, LocalSet(10),
'''+part[z:]
part=part.replace('''        LocalGet(4),
        Call(field_supported),''','''        LocalGet(4), RefCastNonNull(HeapType::Concrete(STRING)), LocalTee(9),
        Call(field_supported_checked),''',1)
part=part.replace('''        LocalGet(4),
        LocalGet(1),
        Call(equal),''','''        LocalGet(9), LocalGet(8), LocalGet(10),
        Call(equal_checked),''',1)
part=part.replace('&[(1, ValType::I32), (1, VALUE), (2, ValType::I32)]','&[(1, ValType::I32), (1, VALUE), (2, ValType::I32),\n            (1, reference(ARGS)), (2, reference(STRING)), (1, ValType::I32)]',1)
s=s[:start]+part+s[end:]
(b/'before.rs').write_text(a);(b/'after.rs').write_text(s);(b/'candidate.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(b/'manifest.json').write_text(json.dumps({'base':'2bc35d1b7964fef711543d5693778f7f0a9de596','file':rel,'before_sha256':hashlib.sha256(a.encode()).hexdigest(),'after_sha256':hashlib.sha256(s.encode()).hexdigest(),'state':'cache-only uncompiled/unexecuted; replaces earlier outer-guard-removal draft'},indent=2)+'\n');print('sourceSHA',hashlib.sha256(s.encode()).hexdigest())
