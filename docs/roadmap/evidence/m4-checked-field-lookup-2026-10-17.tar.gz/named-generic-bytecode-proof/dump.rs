fn main() { std::fs::write(std::env::args_os().nth(1).unwrap(), suss_compile::runtime_abi::module()).unwrap(); }
