from pathlib import Path
import json,re,hashlib,subprocess,os,shutil,tarfile
C=Path('/home/bobby/.cache/suss-m4-work');P=Path(__file__).parent;D=C/'pr256-coreenv-2b-c170-completion-probe';OLD=C/'pr256-coreenv-2b-completion-probe';S=P/'staging';S.mkdir(exist_ok=True);REPO='/home/bobby/Work/code/bobby/suss';L=lambda p:json.loads(p.read_text());H=lambda b:hashlib.sha256(b).hexdigest()
r=L(D/'receipt.json');assert r['base']=='c170e116216ba26d3cb9b48b7c778ae6f185d4c8' and r['terminal'] and r['exit']==101 and r['changed']==[] and r['production_restored']
for pid in [r['controller_pid'],r['cargo_pid']]:
 try:os.kill(pid,0);raise AssertionError(('producer still alive',pid))
 except ProcessLookupError:pass
stable={str(f):H(f.read_bytes()) for f in D.rglob('*') if f.is_file() and '__pycache__' not in f.parts}
assert H((D/'carver-review.json').read_bytes())==r['review_sha256'];m=L(D/'manifest.json');assert H((D/'manifest.json').read_bytes())==r['main_preflight']['manifest_sha256']
for n,h in m['packet_files'].items():assert H((D/n).read_bytes())==h
assert (D/'original.rs').read_bytes()==(OLD/'original.rs').read_bytes() and (D/'diagnostic.rs').read_bytes()==(OLD/'diagnostic.rs').read_bytes()
def copy(src,dst):
 for f in src.rglob('*'):
  if not f.is_file() or '__pycache__' in f.parts or f.name.endswith('.tar.gz'):continue
  q=dst/f.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,q)
copy(D,S/'c170-actual');control=S/'4f-control';control.mkdir(exist_ok=True)
for n in ['manifest.json','run.py','receipt.json','original.rs','diagnostic.rs','candidate.patch','executed-source-freeze.json','execution.log','summary.json','carver-review.json']:shutil.copyfile(OLD/n,control/n)
# Independent fullfreeze binding, sourceGit objects only. Never read live root source.
def bind(directory,label):
 rec=L(directory/'receipt.json');man=L(directory/'manifest.json');head=rec['base'];freeze=L(directory/'executed-source-freeze.json');assert rec['changed']==[] and rec['production_restored'] and rec['terminal'];target=man['file'];assert H((directory/'diagnostic.rs').read_bytes())==freeze[target]==man['diagnostic_sha256']
 tree={}
 for line in subprocess.check_output(['git','-C',REPO,'ls-tree','-r',head],text=True).splitlines():
  meta,path=line.split('\t',1);mode,typ,oid=meta.split();tree[path]=(typ,oid)
 proc=subprocess.Popen(['git','-C',REPO,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);memo={};bindings={}
 for path,h in freeze.items():
  typ,oid=tree[path];assert typ=='blob'
  if oid not in memo:
   proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();assert hdr[1]==b'blob';left=int(hdr[2]);d=hashlib.sha256()
   while left:
    b=proc.stdout.read(min(left,1048576));assert b;d.update(b);left-=len(b)
   assert proc.stdout.read(1)==b'\n';memo[oid]=d.hexdigest()
  assert memo[oid]==(man['original_sha256'] if path==target else h),(label,path)
  bindings[path]={'base':head,'blob':oid,'executed_sha256':h,'kind':'retained_diagnostic_test_postimage' if path==target else 'unchanged_git_blob'}
 proc.stdin.close();assert proc.wait()==0
 (S/(label+'-SOURCE-GIT-BINDINGS.json')).write_text(json.dumps({'source':head,'paths':len(freeze),'all_match':True,'test_override':target,'receipt_changed':[],'production_restored':True,'bindings':bindings,'live_root_hashed':False},indent=2)+'\n')
 for n in ['runtime/bootstrap/macro.json','runtime/bootstrap/macro.wasm','runtime/bootstrap/runtime.json','runtime/bootstrap/runtime.wasm']:
  b=subprocess.check_output(['git','-C',REPO,'show',head+':'+n]);assert H(b)==freeze[n];q=S/'exact-BOOT'/label/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 return len(freeze)
currentn=bind(D,'c170');oldn=bind(OLD,'4f');assert currentn==3539 and oldn==3532
expected=['start','provenance','caller-form','caller-environment','arguments','invoked','decoded']
def raw(directory):
 t=(directory/'execution.log').read_text();rec=L(directory/'receipt.json');summary=L(directory/'summary.json');assert re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)==[('FAILED','0','1','0')]
 events=[(k,int(v)) for k,v in re.findall(r'(?<![\w-])macro-fuel user/declaration-facts ([\w-]+): (\d+)$',t,re.M)];assert len(events)==10 and [k for k,v in events[:7]]==expected and [k for k,v in events[7:]]==expected[:3]
 assert 'span: 0..36' in t and 'caller &env input transport' in t and 'all fuel consumed' in t
 first=dict(events[:7]);assert first['start']==1999999819 and all(events[i][1]>=events[i+1][1] for i in range(6))
 total=first['start']-first['decoded'];assert summary['requests'][0]['completed_expansion_interval_fuel']==total and not summary['test_pass_observed'] and not summary['requests'][1]['complete_expected_chain']
 seconds=float(re.search(r'finished in ([0-9.]+)s',t)[1]);return {'first':first,'second':dict(events[7:]),'total':total,'raw_harness_seconds':seconds,'receipt_seconds':rec['seconds'],'log_sha256':H((directory/'execution.log').read_bytes())}
a=raw(D);b=raw(OLD);assert a['total']==1701286018 and b['total']==1701285927 and a['total']-b['total']==91
balances=[{'stage':k,'control4f_remaining':b['first'][k],'candidate_c170_remaining':a['first'][k],'candidate_minus_control':a['first'][k]-b['first'][k]} for k in expected]
intervals=[]
for x,y in zip(expected,expected[1:]):
 old=b['first'][x]-b['first'][y];new=a['first'][x]-a['first'][y];intervals.append({'from':x,'to':y,'control4f_units':old,'c170_units':new,'candidate_minus_control_cost':new-old})
assert intervals[2]['c170_units']==1701066194 and intervals[2]['candidate_minus_control_cost']==91 and intervals[4]['c170_units']==210097 and intervals[5]['c170_units']==116
review={'verdict':'VERIFIED_TERMINAL_DIAGNOSTIC_FAILURE_NO_COST_REMOVAL_IN_THIS_CHAIN','base':r['base'],'current_counts':{'pass':0,'fail':1,'ignored':0},'control_counts_separate':{'pass':0,'fail':1,'ignored':0},'first_macro_stage_balances':balances,'first_macro_adjacent_intervals':intervals,'first_completed_macro':{'c170':a['total'],'4f':b['total'],'c170_additional_cost':91},'second_runtime_requests':{'c170':a['second'],'4f':b['second'],'identical_partial_balances':a['second']==b['second'],'both_failure_stage':'caller &env input transport','span':'0..36','unfinished_cost':None},'first_projection_assertions':'FirstRuntimeprojection/GC/assertions reached/passed by sequential unchanged source before second eval panic39:14; not independent assertion logs.','remaining_Macro_caller_phase':'UNEXECUTED','source_binding':{'current':currentn,'control':oldn,'exact_git_plus_identical_test_postimages':True,'restored_receipts':True,'live_root_hashed':False},'raw_durations_not_speed_comparison':{'c170':{k:a[k] for k in ['raw_harness_seconds','receipt_seconds']},'control4f':{k:b[k] for k in ['raw_harness_seconds','receipt_seconds']}},'prelaunch_v1':'controller-v1-not-executed retained with blocked review; childPID-shadow fix predates onlyactual execution. No V1coverage.','whole_compilation_cost':None,'default_acceptance':False,'limits':['c170nativeSlotLog is correctsource-tested separately; this actualfirstcoldmacro chain is91unitsmore, not reduced. Secondwarmrequest stillfails2B, so cost remainsunknown.','Start→decoded excludes outsidecompiler/caller/GC/assertionwork. Neither wholetest nor wholecompile completed.','Same1testexecuted in each separatetuple; do not sum as distinct acceptancecoverage.','No walltimespeedclaim; actual314.879controller/286.07harness seconds is not controlledtiming.','Metadata manifest UNEXECUTED strings are prepared-source metadata; terminalreceipt/rawlog establish laterexecution.']}
(P/'independent-review.json').write_text(json.dumps(review,indent=2)+'\n');shutil.copyfile(P/'independent-review.json',S/'independent-review.json')
table='\n'.join('| '+x['stage']+' | '+str(x['control4f_remaining'])+' | '+str(x['candidate_c170_remaining'])+' | '+str(x['candidate_minus_control'])+' |' for x in balances)
report=f'''# c1702B CoreEnv diagnostic\n\nSource `{r['base']}` + EXACTsame reviewed2Btestpostimage as4f. Macro2B setter only; caller defaults/two phases/all assertions unchanged. Terminal0PASS1fuelFAIL0ignored; actual{r['seconds']:.3f}s controller/{a['raw_harness_seconds']:.2f}s harness. Changed[], production_restored=true, controller/child exited. All3539inputs Gitc170bound except retainedtestpostimage; control4f3532independently bound separately. No live-root hashes.\n\nFirst Runtime macrochain complete:1,701,286,018units vs4f1,701,285,927 =91MOREunits. Caller-env1,701,066,194 vs1,701,066,103; transformer210,097 unchanged; decode116unchanged. All7exactstagebalances:\n\n|stage|4fremaining|c170remaining|c170−4f|\n|---|---:|---:|---:|\n{table}\n\nFirstRuntimeprojection/GC/assertions passed beforesecond eval by unchanged sourcecontrolflow/paniclocation. SECONDrequest has identical threepartialbalances in bothtuples and FAILScaller&env0..36at2B; requiredunfinishedcostUNKNOWN. Macrocallerphase entirelyUNEXECUTED. Slotnativefix didnotremove thiscoldchaincost or completewarmrequest. No wholecompile/fullfixturecost/defaultacceptance claim. Outsidecompiler/caller/read/GC/assertions excluded from macrostageintervals. No walltimespeedclaim.\n\nPrelaunchV1childPIDshadowcontroller preserved asUNEXECUTED withblockedreview; correctedreviewedcontroller is only executedtuple. Allrawcontrol/review/preflight/restore/sourcepatch/freezes retained.4fcontrol count remainsseparate, not a two-test acceptanceunion. Sourcecontroloriginal anddiagnosticbytes identical acrossheads. No source/Cargo/BOOTwrites or reruns for thisaudit.\n''';(P/'REPORT.md').write_text(report);shutil.copyfile(P/'REPORT.md',S/'REPORT.md');shutil.copyfile(P/'package.py',S/'package.py')
assert stable=={str(f):H(f.read_bytes()) for f in D.rglob('*') if f.is_file() and '__pycache__' not in f.parts}
manifest={str(f.relative_to(S)):{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size} for f in S.rglob('*') if f.is_file() and str(f.relative_to(S))!='MANIFEST.json'};(S/'MANIFEST.json').write_text(json.dumps({'schema':1,'payloads':manifest},indent=2)+'\n');out=C/'m4-pr256-coreenv-2b-c170-diagnostic-2026-10-18.tar.gz'
with tarfile.open(out,'w:gz') as tf:
 for f in sorted(S.rglob('*')):
  if f.is_file():tf.add(f,arcname=str(f.relative_to(S)),recursive=False)
with tarfile.open(out) as tf:
 ms=tf.getmembers();assert len(ms)==len(manifest)+1==len({m.name for m in ms})
 for m in ms:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='MANIFEST.json':assert H(tf.extractfile(m).read())==manifest[m.name]['sha256']
res={'archive':str(out),'sha256':H(out.read_bytes()),'members':len(manifest)+1,'payloads':len(manifest),'bytes':out.stat().st_size,'review':str(P/'independent-review.json'),'source':r['base'],'current_frozen_inputs':currentn,'first_macro_cost':a['total'],'delta_cost_vs4f':91};(P/'package-result.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
