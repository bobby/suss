Prepared, UNEXECUTED. No rootwrites/Cargo.

Base c170e116216ba26d3cb9b48b7c778ae6f185d4c8. Original and diagnostic test files BYTE-IDENTICAL to reviewed4f2B originals; all assertion/GC/two-caller-phase source unchanged. Two inserted lines remain the only fixture delta, Macro allowance2B; caller default/production defaults unchanged. No assumption2B completes test.

Controller delta is controller-delta.patch: remove obsolete baselinewait, replace with required main-preflight.json confirmed_by=root, exact base+manifest_sha256, all_prior_controllers_drained=true and target_idle=true; independently verify known prior baseline/2B/slot controller+child PIDs absent and receipts terminal, prior2B restoredtrue. Same one-shotlock/exactcleantrackedHEAD/preimage/freeze/ownedPGID/SIGTERM/postimage-onlyrestore controls.

Requires Carver carver-review.json reviewer=Carver, approved_for_execution=true, manifest_sha256=4b1801018b943e9980cff9724b275ed878298b989f4942fa138d784b6edc7633 and explicit --execute. No approval/preflight file fabricated. Do not launch until independentlyreviewed.

Prior4f2B terminal control remains separate at /home/bobby/.cache/suss-m4-work/pr256-coreenv-2b-completion-probe; no outcome/cost union. FirstRuntime4f chain1,701,285,927units completed; second2Brequestfailed. c170 outcome entirelyUNEXECUTED. Macro stages exclude wholecompiler/caller/read/GC/assertion cost. No new fullworkspacebaseline.
