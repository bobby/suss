# c1702B CoreEnv diagnostic

Source `c170e116216ba26d3cb9b48b7c778ae6f185d4c8` + EXACTsame reviewed2Btestpostimage as4f. Macro2B setter only; caller defaults/two phases/all assertions unchanged. Terminal0PASS1fuelFAIL0ignored; actual314.879s controller/286.07s harness. Changed[], production_restored=true, controller/child exited. All3539inputs Gitc170bound except retainedtestpostimage; control4f3532independently bound separately. No live-root hashes.

First Runtime macrochain complete:1,701,286,018units vs4f1,701,285,927 =91MOREunits. Caller-env1,701,066,194 vs1,701,066,103; transformer210,097 unchanged; decode116unchanged. All7exactstagebalances:

|stage|4fremaining|c170remaining|c170−4f|
|---|---:|---:|---:|
| start | 1999999819 | 1999999819 | 0 |
| provenance | 1999996363 | 1999996363 | 0 |
| caller-form | 1999996362 | 1999996362 | 0 |
| caller-environment | 298930259 | 298930168 | -91 |
| arguments | 298924105 | 298924014 | -91 |
| invoked | 298714008 | 298713917 | -91 |
| decoded | 298713892 | 298713801 | -91 |

FirstRuntimeprojection/GC/assertions passed beforesecond eval by unchanged sourcecontrolflow/paniclocation. SECONDrequest has identical threepartialbalances in bothtuples and FAILScaller&env0..36at2B; requiredunfinishedcostUNKNOWN. Macrocallerphase entirelyUNEXECUTED. Slotnativefix didnotremove thiscoldchaincost or completewarmrequest. No wholecompile/fullfixturecost/defaultacceptance claim. Outsidecompiler/caller/read/GC/assertions excluded from macrostageintervals. No walltimespeedclaim.

PrelaunchV1childPIDshadowcontroller preserved asUNEXECUTED withblockedreview; correctedreviewedcontroller is only executedtuple. Allrawcontrol/review/preflight/restore/sourcepatch/freezes retained.4fcontrol count remainsseparate, not a two-test acceptanceunion. Sourcecontroloriginal anddiagnosticbytes identical acrossheads. No source/Cargo/BOOTwrites or reruns for thisaudit.
