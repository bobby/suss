from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access')
out=Path(__file__).resolve().parent
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip(), 'requires clean committed source'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',TMPDIR='/home/bobby/.cache/suss-m4-work/workspace-tmp-65e9718-ccpsnhdq',SUSS_BOOTSTRAP_DIAGNOSTICS_DIR=str(out/'diagnostics'))
cmd=['sh','scripts/verify-bootstrap.sh'];started=time.monotonic()
with (out/'verify.log').open('x') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'head':head,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-started,'log_sha256':hashlib.sha256((out/'verify.log').read_bytes()).hexdigest(),'qualification':'Normal generation; old shipped comparison is expected stale. Read actual diagnostics before adoption; no execution success inferred.'}
(out/'terminal.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print((out/'verify.log').read_text()[-4000:]);raise SystemExit(r.returncode)
