//! Development cost attribution only; configured extra fuel is not acceptance.
use suss_cli::portable_session::{Session, SessionError, SessionOptions};

fn main() {
    let diagnostic_fuel: u64 = std::env::args().nth(1)
        .expect("explicit diagnostic fuel required").parse().unwrap();
    eprintln!("NATIVE_CORE_COST_PROBE default={} diagnostic={} acceptance=false",
        SessionOptions::default().fuel_per_operation, diagnostic_fuel);
    let mut session = Session::new().unwrap();
    session.set_operation_fuel(diagnostic_fuel);
    assert!(matches!(session.eval("(identity 7)"), Err(SessionError::Compile(_))));
    let result = session.eval(include_str!("../../../runtime/core-import/suss/core.sus"));
    eprintln!("NATIVE_CORE_COST_PROBE result={:?}", result.as_ref().map(|_| ()));
    if result.is_err() { std::process::exit(1); }
}
