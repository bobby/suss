"""Report actual declaration-facts traces; never extrapolate an unfinished tail."""
from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent
r=json.loads((p/'receipt.json').read_text())
assert r['terminal'],'Execution not terminal'
log=p/'execution.log'
assert log.is_file(),'No executed diagnostic output'
raw=log.read_bytes();text=raw.decode(errors='replace')
pattern=re.compile(r'(?<![\w-])macro-fuel user/declaration-facts ([\w-]+): (\d+)$',re.M)
expected=['start','provenance','caller-form','caller-environment','arguments','invoked','decoded']
requests=[];current=[];orphan=[]
for match in pattern.finditer(text):
    row={'stage':match[1],'remaining':int(match[2])}
    if row['stage']=='start':
        if current:requests.append(current)
        current=[row]
    elif current:current.append(row)
    else:orphan.append(row)
if current:requests.append(current)
reported=[]
for rows in requests:
    valid=[row['stage'] for row in rows]==expected
    monotone=all(a['remaining']>=b['remaining'] for a,b in zip(rows,rows[1:]))
    reported.append({'observations':rows,'complete_expected_chain':valid,'monotone':monotone,
        'completed_expansion_interval_fuel':rows[0]['remaining']-rows[-1]['remaining'] if valid and monotone else None,
        'required_unfinished_tail_fuel':None})
test_name='compiled_macro_core_namespace_keeps_complete_declaration_records'
starts=re.findall(r'^test '+re.escape(test_name)+r' \.\.\.',text,re.M)
summaries=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)
passed=(len(starts)==1 and summaries==[('ok','1','0','0')] and r.get('exit')==0
        and r.get('changed')==[] and r.get('production_restored') is True)
result={'base':r['base'],'diagnostic_macro_allowance':200_000_000,'caller_default_unchanged':True,
    'terminal_exit':r.get('exit'),'production_restored':r.get('production_restored',False),
    'log_sha256':hashlib.sha256(raw).hexdigest(),'test_pass_observed':passed,'test_starts':len(starts),'test_summaries':summaries,'frozen_inputs_changed':r.get('changed'),'requests':reported,
    'orphan_observations':orphan,'whole_compilation_fuel':None,'default_budget_acceptance':False,
    'limits':'Expansion start-to-decoded excludes outer compilation, caller execution, external decoding, GC and assertions. Failed tails remain unknown. Elapsed time is not a controlled performance comparison.'}
if passed and r.get('exit')==0:
    assert len(reported)==4 and all(x['complete_expected_chain'] and x['monotone'] for x in reported) and not orphan,'Passing fixture trace incomplete; inspect raw output'
(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
