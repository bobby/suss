from pathlib import Path
import json,subprocess,hashlib,shutil,sys
p=Path(__file__).resolve().parent
source=p.parent/'summarize.py';raw=source.read_bytes();(p/'summarize-reviewed.py').write_bytes(raw)
name='compiled_macro_core_namespace_keeps_complete_declaration_records'
stages=['start','provenance','caller-form','caller-environment','arguments','invoked','decoded']
def chain(i,omit=None):
 return '\n'.join(f'macro-fuel user/declaration-facts {s}: {1000-i*100-j*10}' for j,s in enumerate(stages) if s!=omit)+'\n'
def success(omit=None):
 return 'running 1 test\n'+'test '+name+' ... '+chain(0,omit)+''.join(chain(i) for i in range(1,4))+'ok\n\ntest result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s\n'
base={'base':'SYNTHETIC_NOT_RUNTIME_EVIDENCE','terminal':True,'exit':0,'changed':[],'production_restored':True}
cases=[
 ('prefixed_interleaved_success',success(),{},'success'),
 ('zero_tests','running 0 tests\ntest result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.0s\n',{},'no_credit'),
 ('compile_failure','error[E0509]: synthetic fixture cannot compile\n',{'exit':101},'no_credit'),
 ('missing_stage_success_harness',success('caller-environment'),{},'reject'),
 ('unfinished_failed_request','test '+name+' ... '+chain(0)+'macro-fuel user/declaration-facts start: 900\nmacro-fuel user/declaration-facts provenance: 880\nFAILED\ntest result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1s\n',{'exit':101},'partial'),
 ('duplicate_test_start', 'test '+name+' ... \n'+success(),{},'no_credit'),
 ('changed_freeze',success(),{'changed':['changed.rs']},'no_credit'),
 ('not_restored',success(),{'production_restored':False},'no_credit'),
 ('nonterminal',success(),{'terminal':False},'reject'),
 ('nonmonotone_success_harness',success().replace('provenance: 990','provenance: 1001',1),{},'reject'),
 ('orphan_success_harness','macro-fuel user/declaration-facts provenance: 1001\n'+success(),{},'reject'),
 ('wrong_target_noise',success().replace('running 1 test\n','running 1 test\nmacro-fuel other/declaration-facts start: 123\n'),{},'success'),
]
results=[]
for key,log,updates,kind in cases:
 d=p/'cases'/key;d.mkdir(parents=True,exist_ok=True);(d/'summarize.py').write_bytes(raw);(d/'execution.log').write_text(log);rc={**base,**updates};(d/'receipt.json').write_text(json.dumps(rc,indent=2)+'\n')
 proc=subprocess.run([sys.executable,str(d/'summarize.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);(d/'parser.stdout').write_text(proc.stdout);(d/'parser.stderr').write_text(proc.stderr)
 summary=json.loads((d/'summary.json').read_text()) if (d/'summary.json').exists() else None
 if kind=='reject':assert proc.returncode!=0 and summary is None,key
 else:
  assert proc.returncode==0 and summary is not None,key
  if kind=='success':
   assert summary['test_pass_observed'] and len(summary['requests'])==4,key
   assert [x['completed_expansion_interval_fuel'] for x in summary['requests']]==[60]*4,key
  else:assert not summary['test_pass_observed'],key
  if kind=='partial':
   assert len(summary['requests'])==2 and summary['requests'][0]['completed_expansion_interval_fuel']==60,key
   assert summary['requests'][1]['completed_expansion_interval_fuel'] is None and summary['requests'][1]['required_unfinished_tail_fuel'] is None,key
  assert summary['whole_compilation_fuel'] is None and summary['default_budget_acceptance'] is False,key
 results.append({'case':key,'expected':kind,'parser_exit':proc.returncode,'check':'PASS','observed_qualified_pass':summary.get('test_pass_observed') if summary else None})
(p/'checks.json').write_text(json.dumps({'schema':1,'synthetic_only':True,'parser_sha256':hashlib.sha256(raw).hexdigest(),'cases':results,'passed':len(results),'failed':0},indent=2)+'\n');print(json.dumps({'parser_sha256':hashlib.sha256(raw).hexdigest(),'synthetic_cases':len(results),'pass':len(results),'fail':0}))
