from pathlib import Path
import tarfile,hashlib,json,subprocess
c=Path('/home/bobby/.cache/suss-m4-work');r=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');out=c/'prototype-buffer-performance';receipt=json.loads((c/'native-prototype-buffer-candidate-3/receipt.json').read_text());assert receipt['current'] is None and receipt['final_changed']==[]
items={}
def add(name,p):
 assert p.is_file(),p;items[name]=p
for attempt in ['native-prototype-buffer-candidate','native-prototype-buffer-candidate-2','native-prototype-buffer-candidate-3']:
 d=c/attempt
 for p in d.iterdir():
  if p.is_file() and (p.suffix in ['.log','.json']):add(attempt+'/'+p.name,p)
 for name in ['prototype_origin.rs','constructor_inputs.rs']:
  f='crates/suss-compile/src/portable_session/'+name;add(attempt+'/before-source/'+f,d/'before'/f)
capture=c/'native-prototype-buffer-candidate-3/map-capture'
if capture.exists():
 for item in capture.rglob('*'):
  if item.is_file():add('native-prototype-buffer-candidate-3/map-capture/'+str(item.relative_to(capture)),item)
for name in ['source-child.log','receipt.json','after-bootstrap-freeze.json']:
 add('parent-ce-method-pass/'+name,c/'native-method-pass-candidate'/name)
for name in ['run-native-prototype-buffer-candidate.py','run-native-prototype-buffer-candidate-2.py','run-native-prototype-buffer-candidate-3.py','native-prototype-buffer-command-plan.json','native-prototype-buffer-2-command-plan.json','native-prototype-buffer-3-command-plan.json','run-native-prototype-buffer-foundation.py']:add('commands/'+name,c/name)
for dirname in ['prototype-stack-buffer-candidate','schema-private-handle-accounting-ce88795','prototype-buffer-performance','native-prototype-buffer-foundation']:
 for p in (c/dirname).iterdir():
  if p.is_file() and p.name!='payload-manifest.json':add(dirname+'/'+p.name,p)
for name in ['prototype_origin.rs','constructor_inputs.rs','source_array_inputs.rs']:
 f='crates/suss-compile/src/portable_session/'+name;add('source/'+f,r/f)
f='crates/suss-compile/src/portable_macro_graph/source_roots.rs';add('source/'+f,r/f)
for phase in ['macro','runtime']:
 for ext in ['wasm','json']:
  f='runtime/bootstrap/'+phase+'.'+ext;add('source/'+f,r/f)
manifest={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in items.items()};(out/'payload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');add('payload-manifest.json',out/'payload-manifest.json')
archive=r/'docs/roadmap/evidence/m4-prototype-buffers-private-schema-2026-10-17.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(items.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 for name,h in manifest.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h
result={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payloads':len(items),'parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'qualification':'Attempts1/2 failures retained; attempt3 terminal. Native pass executions not unique tests. No full baseline/CI/issue acceptance claim.'};(c/'prototype-buffer-publication-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
