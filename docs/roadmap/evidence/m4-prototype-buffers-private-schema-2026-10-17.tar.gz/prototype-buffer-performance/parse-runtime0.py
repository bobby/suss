from pathlib import Path
import re,json,collections,hashlib
raw=Path('/home/bobby/.cache/suss-m4-work/native-prototype-buffer-candidate-3/source-child.log');lines=raw.read_text().splitlines();start=end=None;before=after=None
for i,line in enumerate(lines):
 if 'source-child-fuel source=Runtime variant=Some(0) stage=materialize:before' in line:start=i;before=int(re.search(r'remaining=Some\((\d+)\)',line)[1])
 if start is not None and 'source-child-fuel source=Runtime variant=Some(0) stage=materialize result=' in line:end=i;after=int(re.search(r'remaining=Some\((\d+)\)',line)[1]);break
assert start is not None and end is not None
patterns=[('call',re.compile(r'source-materialize-call label=(\S+) event=(before|after).*remaining=Some\((\d+)\)')),
 ('record',re.compile(r'source-domain-record domain=\S+ fact=(\S+) phase=(\S+) event=(before|after).*remaining=Some\((\d+)\)')),
 ('domain',re.compile(r'source-domain domain=\S+ staged=\S+ phase=(\S+) event=(before|after).*remaining=Some\((\d+)\)')),
 ('domain-node',re.compile(r'source-domain-node domain=\S+ staged=\S+ ordinal=\d+ watch=\S+ seed=\S+ snapshot=\S+ phase=(\S+) event=(before|after).*remaining=Some\((\d+)\)'))]
stacks=collections.defaultdict(list);events=[]
for i in range(start+1,end):
 line=lines[i]
 for kind,p in patterns:
  m=p.search(line)
  if not m:continue
  if kind=='record':fact,label,event,fuel=m.groups();label=fact+'/'+label
  else:label,event,fuel=m.groups()
  fuel=int(fuel)
  if event=='before':
   outer=stacks['call'][-1]['label'] if stacks['call'] else 'unlabelled'
   stacks[kind].append({'kind':kind,'label':label,'start_fuel':fuel,'line':i+1,'parent_call':outer,'nested_call':bool(stacks['call']) if kind=='call' else False})
  else:
   e=stacks[kind].pop();assert e['label']==label,(i,label,e)
   e.update(end_line=i+1,spent=e['start_fuel']-fuel,result='error' if 'result=Err' in line else 'ok');events.append(e)
  break
assert not any(stacks.values())
groups={}
for e in events:
 key=(e['kind'],e['label'],e['parent_call'],e['nested_call'],e['result'])
 g=groups.setdefault(key,{'count':0,'spent':0});g['count']+=1;g['spent']+=e['spent']
rows=[dict(zip(['kind','label','parent_call','nested_call','result'],k),**v) for k,v in groups.items()]
outer=sum(e['spent'] for e in events if e['kind']=='call' and not e['nested_call'])
r={'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'start_line':start+1,'end_line':end+1,'materialize_spent':before-after,'outer_call_spent':outer,'outside_call_intervals':before-after-outer,'groups':rows,'qualification':'Runtime Some0 materialization only. Outer call intervals are disjoint; record/node rows nest within their call and must not be added to parent costs. No raw per-node phase group establishes source-authority weakening permission.'}
Path(__file__).with_name('census.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
