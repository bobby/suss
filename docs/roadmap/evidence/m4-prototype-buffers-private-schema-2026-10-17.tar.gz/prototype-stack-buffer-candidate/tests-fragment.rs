
#[cfg(test)]
mod prototype_buffer_tests {
    use super::*;
    use crate::portable::resolve::Phase;
    fn real_origin(session: &mut Session) -> PrototypeInputs {
        drop(session.eval("(list 17)").unwrap());
        let constructor = session.eval("suss.core/List").unwrap();
        let descriptor = session.data_descriptor(&constructor, true).unwrap();
        let handles = session.prototype_origin.as_ref().unwrap().handles.clone();
        let prototype = runtime(session, "owned-descriptor-prototype", &[&descriptor], &handles).unwrap();
        session.prototype_origin_inputs(&constructor, &descriptor, &prototype).unwrap().unwrap()
    }
    fn query_array(session: &mut Session, origin: &PrototypeInputs, malformed_last: bool) -> SessionValue {
        let _request = session.operation_budget_scope().unwrap();
        let mut scope = RootScope::new(&mut session.store);
        let mut result = [Val::null_any_ref()];
        session.runtime.get_func(&mut scope, "args-new").unwrap()
            .call(&mut scope, &[Val::I32(12)], &mut result).unwrap();
        let array = result[0].unwrap_anyref().unwrap().as_array(&scope).unwrap().unwrap();
        for index in 0..12 {
            // Index zero intentionally differs from the captured constructor.
            let value = if malformed_last && index == 11 { Val::null_any_ref() }
                else { Val::AnyRef(Some(origin.fields[if index == 0 { 2 } else { index }].value.to_rooted(&mut scope))) };
            array.set(&mut scope, index as u32, value).unwrap();
        }
        own(&mut scope, result[0].clone(), session.identity, &session.handles).unwrap()
    }
    #[test]
    fn prototype_buffer_real_origins_survive_gc_and_reject_mutated_key() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = match phase { Phase::Runtime => Session::new_repl().unwrap(), Phase::Macro => Session::new_macro().unwrap() };
            let origin = real_origin(&mut session);
            session.collect().unwrap();
            assert!(origin.matches(&mut session).unwrap());
            let old = {
                let mut scope = RootScope::new(&mut session.store);
                let key = origin.fields[7].value.to_rooted(&mut scope).as_array(&scope).unwrap().unwrap();
                let old = key.get(&mut scope, 0).unwrap();
                key.set(&mut scope, 0, Val::I32(100)).unwrap();
                old
            };
            assert!(!origin.matches(&mut session).unwrap());
            {
                let mut scope = RootScope::new(&mut session.store);
                let key = origin.fields[7].value.to_rooted(&mut scope).as_array(&scope).unwrap().unwrap();
                key.set(&mut scope, 0, old).unwrap();
            }
            assert!(origin.matches(&mut session).unwrap());
        }
    }
    #[test]
    fn prototype_buffer_late_null_precedes_early_reference_mismatch() {
        let mut session = Session::new_macro().unwrap();
        let origin = real_origin(&mut session);
        let malformed = query_array(&mut session, &origin, true);
        let irq = session.host_work_interrupt();
        let _request = session.operation_budget_scope().unwrap();
        let mut scope = RootScope::new(&mut session.store);
        let expected = Val::AnyRef(Some(origin.fields[0].value.to_rooted(&mut scope)));
        let witness = Val::AnyRef(Some(malformed.value.to_rooted(&mut scope)));
        let array = witness.unwrap_anyref().unwrap().as_array(&scope).unwrap().unwrap();
        let first = array.get(&mut scope, 0).unwrap();
        assert!(!same(&scope.as_context_mut(), &expected, &first).unwrap());
        let mut compared = false;
        let result = (|| -> Result<bool> {
            let current = scoped_prototype_fields(scope.as_context_mut(), &witness, &irq)?.unwrap();
            compared = true;
            Ok(same(&scope.as_context_mut(), &expected, &current[0])?)
        })();
        assert_eq!(result.unwrap_err().to_string(), "Expected non-null runtime Value");
        assert!(!compared, "late malformed input must fail before early mismatch comparison");
    }
    #[test]
    fn prototype_buffer_all_charge_boundaries_irq_retry_and_scoped_roots() {
        let mut session = Session::new_macro().unwrap();
        let origin = real_origin(&mut session);
        let witness = query_array(&mut session, &origin, false);
        let irq = session.host_work_interrupt();
        let measured = {
            let _request = session.operation_budget_scope().unwrap();
            let mut scope = RootScope::new(&mut session.store);
            let witness = Val::AnyRef(Some(witness.value.to_rooted(&mut scope)));
            let before = scope.as_context_mut().get_fuel().unwrap();
            assert!(scoped_prototype_fields(scope.as_context_mut(), &witness, &irq).unwrap().is_some());
            before - scope.as_context_mut().get_fuel().unwrap()
        };
        assert!(measured > 0);
        for fuel in 0..measured {
            let _request = session.operation_budget_scope().unwrap();
            session.store.set_fuel(fuel).unwrap();
            let mut scope = RootScope::new(&mut session.store);
            let witness = Val::AnyRef(Some(witness.value.to_rooted(&mut scope)));
            let error = scoped_prototype_fields(scope.as_context_mut(), &witness, &irq).unwrap_err();
            assert!(matches!(error, SessionError::Trap(ref e) | SessionError::Host(ref e)
                if e.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)), "{error}");
        }
        {
            let _request = session.operation_budget_scope().unwrap();
            let mut scope = RootScope::new(&mut session.store);
            let witness = Val::AnyRef(Some(witness.value.to_rooted(&mut scope)));
            irq.store(true, std::sync::atomic::Ordering::SeqCst);
            assert!(scoped_prototype_fields(scope.as_context_mut(), &witness, &irq).unwrap_err().is_interrupt());
        }
        irq.store(false, std::sync::atomic::Ordering::SeqCst);
        {
            let _request = session.operation_budget_scope().unwrap();
            let handles = session.prototype_origin.as_ref().unwrap().handles.clone();
            let before = handles.load(std::sync::atomic::Ordering::Relaxed);
            let mut scope = RootScope::new(&mut session.store);
            let witness = Val::AnyRef(Some(witness.value.to_rooted(&mut scope)));
            let fields = scoped_prototype_fields(scope.as_context_mut(), &witness, &irq).unwrap().unwrap();
            scope.as_context_mut().gc(None).unwrap();
            for field in &fields { assert!(field.anyref().flatten().is_some()); }
            assert_eq!(handles.load(std::sync::atomic::Ordering::Relaxed), before);
        }
        assert!(origin.matches(&mut session).unwrap());
    }
}
