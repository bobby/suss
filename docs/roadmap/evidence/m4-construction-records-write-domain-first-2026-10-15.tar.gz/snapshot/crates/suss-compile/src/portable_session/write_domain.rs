//! Factory-grounded payload snapshots for protected memo writes.
//! Captures occur before the fresh factory result can reach a guest callback.
use super::{
    Session, SessionError, SessionValue,
    canonical_methods::{CanonicalMethods, InspectionContext},
    canonical_seeds::CanonicalSeed,
    construction_records::Fact,
    memo_bridge::{Receipt, Watch},
    prototype_origin::Authority,
    registry_lock,
    storage_snapshot::StorageSnapshot,
};
use std::sync::{
    Arc, Mutex, Weak,
    atomic::{AtomicBool, AtomicUsize},
};
use wasmtime::{AnyRef, AsContextMut, RootScope, Rooted, StoreContextMut, Val};
type Result<T> = std::result::Result<T, SessionError>;
struct Node {
    value: SessionValue,
    snapshot: Option<StorageSnapshot>,
    seed: Option<Arc<CanonicalSeed>>,
    edges: Vec<SessionValue>,
    watch: Option<Weak<Watch>>,
}
struct State {
    valid: bool,
    nodes: Vec<Node>,
}
pub(super) struct WriteDomain {
    state: Mutex<State>,
    handles: Arc<AtomicUsize>,
}
impl WriteDomain {
    pub(super) fn new() -> Arc<Self> {
        Arc::new(Self {
            state: Mutex::new(State {
                valid: true,
                nodes: Vec::new(),
            }),
            handles: Arc::new(AtomicUsize::new(0)),
        })
    }
    pub(super) fn invalidate(&self) {
        registry_lock(&self.state).valid = false;
    }
    pub(super) fn record(
        self: &Arc<Self>,
        session: &mut Session,
        value: &SessionValue,
        fact: &Fact,
    ) -> Result<()> {
        let watch = match fact {
            Fact::Constructor(f) => f.memo_watch(),
            _ => None,
        };
        if let Some(watch) = &watch {
            watch.bind_source_domain(self);
        }
        let own = match fact {
            Fact::Scalar(f) => f.matches(session, value)?,
            Fact::Array(f) => f.matches(session, value)?,
            Fact::Constructor(f) => {
                f.matches(session, value)? && f.matches_prototype_origin(session)?
            }
            Fact::CanonicalSeed(f) => f.matches(session, value)?,
            Fact::ExternalSeed(_) => false,
        };
        if !own {
            self.invalidate();
        }
        let upper = match fact {
            Fact::Constructor(f) => f.inputs().size_hint().1.unwrap_or(0),
            Fact::Array(f) => f.inputs().size_hint().1.unwrap_or(0),
            _ => 0,
        };
        session.charge_host_work(
            (upper as u64 + 4).saturating_mul((3 * std::mem::size_of::<SessionValue>()) as u64)
                + std::mem::size_of::<Node>() as u64,
        )?;
        let mut edges = Vec::new();
        edges.try_reserve_exact(upper).map_err(|_| {
            SessionError::Host(wasmtime::Error::msg("Memo domain edges allocation failed"))
        })?;
        match fact {
            Fact::Constructor(f) => edges.extend(f.inputs().cloned()),
            Fact::Array(f) => edges.extend(f.inputs().cloned()),
            _ => {}
        }
        let cuts = match fact {
            Fact::Constructor(f) => f.write_cuts(),
            Fact::Array(f) => f.write_cuts(),
            _ => Vec::new(),
        };
        let seed = match fact {
            Fact::CanonicalSeed(seed) => Some(seed.clone()),
            _ => None,
        };
        let snapshot = if own && seed.is_none() {
            Some(session.capture_storage_cut_accounted(value, &cuts, self.handles.clone())?)
        } else {
            None
        };
        let mut state = registry_lock(&self.state);
        if state.nodes.len() == state.nodes.capacity() {
            let capacity = state
                .nodes
                .capacity()
                .checked_mul(2)
                .unwrap_or(usize::MAX)
                .max(4);
            let bytes = capacity
                .checked_add(state.nodes.len())
                .and_then(|n| n.checked_mul(std::mem::size_of::<Node>()))
                .ok_or_else(|| {
                    SessionError::Host(wasmtime::Error::msg("Memo domain capacity overflow"))
                })?;
            session.charge_host_work(bytes as u64 + 1)?;
            let extra = capacity - state.nodes.len();
            state.nodes.try_reserve_exact(extra).map_err(|_| {
                SessionError::Host(wasmtime::Error::msg("Memo domain allocation failed"))
            })?;
        }
        state.nodes.push(Node {
            value: value.clone(),
            snapshot,
            seed,
            edges,
            watch: watch.as_ref().map(Arc::downgrade),
        });
        Ok(())
    }
    pub(super) fn matches(
        &self,
        mut store: StoreContextMut<'_, ()>,
        runtime: wasmtime::Instance,
        identity: u64,
        irq: &AtomicBool,
        methods: &CanonicalMethods,
        prototype: &Authority,
        staged: Option<(&Watch, &Receipt)>,
    ) -> Result<bool> {
        // Authority adapters may allocate. Run them before locking the domain;
        // all subsequent operations are native reads, without guest execution.
        let classes = methods.source_classes_in_context(InspectionContext {
            store: store.as_context_mut(),
            runtime,
            identity,
            interrupt: irq,
        })?;
        let parent = prototype.parent_matches_in_context(InspectionContext {
            store: store.as_context_mut(),
            runtime,
            identity,
            interrupt: irq,
        })?;
        let state = registry_lock(&self.state);
        let mut valid = state.valid && classes && parent;
        let mut scope = RootScope::new(store);
        for node in &state.nodes {
            Session::consume_host_work(scope.as_context_mut(), 1, irq)?;
            let root = Val::AnyRef(Some(node.value.value.to_rooted(&mut scope)));
            if let Some(seed) = &node.seed {
                valid &= seed.write_storage().matches_in_context(
                    scope.as_context_mut(),
                    root,
                    identity,
                    irq,
                )?;
            } else if let Some(snapshot) = &node.snapshot {
                let watch = node.watch.as_ref().and_then(Weak::upgrade);
                valid &= snapshot.matches_in_context_with_slots(
                    scope.as_context_mut(),
                    root,
                    identity,
                    irq,
                    |mut store, array, index, actual| {
                        let Some(watch) = &watch else {
                            return Ok(false);
                        };
                        if !watch.is_slot(store.as_context_mut(), &array, index, irq)? {
                            return Ok(false);
                        }
                        if let Some((current, receipt)) = staged {
                            if std::ptr::eq(current, watch.as_ref()) {
                                return watch
                                    .matches_receipt(store, actual, receipt, irq)
                                    .map_err(Into::into);
                            }
                        }
                        watch
                            .source_authenticated(store, actual, irq)
                            .map_err(Into::into)
                    },
                )?;
            } else {
                valid = false;
            }
            for edge in &node.edges {
                Session::consume_host_work(scope.as_context_mut(), 1, irq)?;
                let edge = edge.value.to_rooted(&mut scope);
                let mut member = edge.as_i31(&scope)?.is_some();
                if member {
                    continue;
                }
                for other in &state.nodes {
                    Session::consume_host_work(scope.as_context_mut(), 1, irq)?;
                    let other_root = other.value.value.to_rooted(&mut scope);
                    member |= Rooted::<AnyRef>::ref_eq(&scope, &edge, &other_root)?;
                    if member {
                        break;
                    }
                    if let Some(seed) = &other.seed {
                        member |= seed.write_storage().contains_reference_in_context(
                            scope.as_context_mut(),
                            Val::AnyRef(Some(edge)),
                            identity,
                            irq,
                        )?;
                        if member {
                            break;
                        }
                    }
                }
                valid &= member;
            }
        }
        Ok(valid)
    }
}
