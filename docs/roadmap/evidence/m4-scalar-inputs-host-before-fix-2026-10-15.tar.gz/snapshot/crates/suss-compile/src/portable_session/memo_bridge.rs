//! Protected Macro-bootstrap store route. No memo receipts are issued here.
//! It preserves the ordinary runtime setter, including its layout/error rules.
use super::Session;
use crate::portable::bootstrap;
use std::sync::{Arc, atomic::AtomicBool};
use wasmtime::{AsContextMut, Func, FuncType, Instance, Linker, RefType, Store, Val, ValType};

pub(super) fn install(
    store: &mut Store<()>,
    linker: &mut Linker<()>,
    runtime: Instance,
    interrupt: Arc<AtomicBool>,
) -> wasmtime::Result<()> {
    let setter = runtime
        .get_func(&mut *store, "object-field-set")
        .ok_or_else(|| wasmtime::Error::msg("Missing canonical memo setter"))?;
    let ty = FuncType::new(
        store.engine(),
        [
            ValType::Ref(RefType::EQREF),
            ValType::I32,
            ValType::Ref(RefType::EQREF),
        ],
        [],
    );
    // Store-bound registration preserves the runtime/root/interrupt association
    // across nested calls; reset constructs a fresh bound function.
    let bridge = Func::new(&mut *store, ty, move |mut caller, arguments, _results| {
        Session::consume_host_work(caller.as_context_mut(), 32, &interrupt)?;
        let index = usize::try_from(arguments[1].unwrap_i32())
            .map_err(|_| wasmtime::Error::msg("Invalid canonical memo site"))?;
        let (_, field) = bootstrap::memo_owner_slots()
            .nth(index)
            .ok_or_else(|| wasmtime::Error::msg("Unknown canonical memo site"))?;
        setter.call(
            &mut caller,
            &[
                arguments[0].clone(),
                Val::I32(field as i32),
                arguments[2].clone(),
            ],
            &mut [],
        )
    });
    linker.define(
        &*store,
        bootstrap::COMPILER_INTEGRITY_IMPORT_MODULE,
        bootstrap::MEMO_WRITE_IMPORT_NAME,
        bridge,
    )?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{portable::resolve::Phase, portable_session::SessionError};

    #[test]
    fn private_memo_bridge_preserves_hash_miss_hit_and_cache_field_after_gc() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = match phase {
                Phase::Runtime => Session::new_repl().unwrap(),
                Phase::Macro => Session::new_macro().unwrap(),
            };
            session.eval("(def bridge-value (list 1 2))").unwrap();
            session.enter_namespace("suss.core").unwrap();
            session
                .eval("(def hash-ordered-coll (fn [_] 719))")
                .unwrap();
            session.enter_namespace("user").unwrap();
            let first = session.eval("(hash bridge-value)").unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &first).unwrap(),
                "719"
            );
            let value = session.eval("bridge-value").unwrap();
            session.collect().unwrap();
            let fields = session.data_fields(&value).unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &fields[4]).unwrap(),
                "719"
            );
            session.enter_namespace("suss.core").unwrap();
            session
                .eval("(def hash-ordered-coll (fn [_] (throw 8801)))")
                .unwrap();
            session.enter_namespace("user").unwrap();
            let hit = session.eval("(hash bridge-value)").unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &hit).unwrap(),
                "719"
            );
        }
    }

    fn guest_setter(session: &mut Session, setter: Func) -> Func {
        use wasm_encoder::*;
        let mut module = Module::new();
        let mut types = TypeSection::new();
        types.ty().function(
            [
                ValType::Ref(RefType::EQREF),
                ValType::I32,
                ValType::Ref(RefType::EQREF),
            ],
            [],
        );
        module.section(&types);
        let mut imports = ImportSection::new();
        imports.import("test", "setter", EntityType::Function(0));
        module.section(&imports);
        let mut functions = FunctionSection::new();
        functions.function(0);
        module.section(&functions);
        let mut exports = ExportSection::new();
        exports.export("run", ExportKind::Func, 1);
        module.section(&exports);
        let mut code = CodeSection::new();
        let mut body = Function::new([]);
        for instruction in [
            Instruction::LocalGet(0),
            Instruction::LocalGet(1),
            Instruction::LocalGet(2),
            Instruction::Call(0),
            Instruction::End,
        ] {
            body.instruction(&instruction);
        }
        code.function(&body);
        module.section(&code);
        let module = wasmtime::Module::new(&session.engine, module.finish()).unwrap();
        let instance = Instance::new(&mut session.store, &module, &[setter.into()]).unwrap();
        instance.get_func(&mut session.store, "run").unwrap()
    }

    #[test]
    fn private_memo_bridge_preserves_language_exception_payload_across_nested_runtime_call() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = Session::with_options_in(Default::default(), phase).unwrap();
            let receiver = session.eval("42").unwrap();
            let bridge = session
                .linker
                .get(
                    &mut session.store,
                    bootstrap::COMPILER_INTEGRITY_IMPORT_MODULE,
                    bootstrap::MEMO_WRITE_IMPORT_NAME,
                )
                .unwrap()
                .into_func()
                .unwrap();
            let setter = session
                .runtime
                .get_func(&mut session.store, "object-field-set")
                .unwrap();
            let mut payloads = Vec::new();
            // The first route crosses Wasm -> native bridge -> runtime Wasm.
            // The ordinary setter provides the independently observed control.
            for (function, index) in [(bridge, 0), (setter, 4)] {
                let function = guest_setter(&mut session, function);
                let mut scope = wasmtime::RootScope::new(&mut session.store);
                let value = Val::AnyRef(Some(receiver.value.to_rooted(&mut scope)));
                let error = function
                    .call(
                        &mut scope,
                        &[value.clone(), Val::I32(index), value],
                        &mut [],
                    )
                    .unwrap_err();
                let error = super::super::execution_error(
                    &mut scope,
                    session.runtime,
                    error,
                    session.identity,
                    &session.handles,
                );
                let SessionError::Language(payload) = error else {
                    panic!("{error:?}")
                };
                assert!(!scope.as_context_mut().has_pending_exception());
                payloads.push(payload);
            }
            session.collect().unwrap();
            for payload in &payloads {
                session
                    .inspect(payload, |mut store, value| {
                        let error = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                        let control = payloads[1].value.to_rooted(&mut store);
                        let control = control.as_struct(&store)?.unwrap();
                        let found = error.field(&mut store, 0)?;
                        let expected = control.field(&mut store, 0)?;
                        assert!(wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(
                            &store,
                            found.unwrap_anyref().unwrap(),
                            expected.unwrap_anyref().unwrap()
                        )?);
                        let message = error
                            .field(&mut store, 1)?
                            .unwrap_anyref()
                            .unwrap()
                            .as_array(&store)?
                            .unwrap();
                        let units: Vec<_> = message
                            .elems(&mut store)?
                            .map(|unit| unit.unwrap_i32() as u16)
                            .collect();
                        assert_eq!(
                            units,
                            "Invalid nominal operation"
                                .encode_utf16()
                                .collect::<Vec<_>>()
                        );
                        Ok(())
                    })
                    .unwrap();
            }
            let recovery = session.eval("43").unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &recovery).unwrap(),
                "43"
            );
        }
    }
}
