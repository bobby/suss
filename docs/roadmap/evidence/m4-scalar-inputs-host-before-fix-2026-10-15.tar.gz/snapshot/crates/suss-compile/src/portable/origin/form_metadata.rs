//! Original provenance matching for opt-in indexing-reader macro data.
use super::SourceOrigin;
use crate::portable::Diagnostic;
use std::collections::HashMap;
use suss_reader::forms::{
    Form, Kind, read_forms, read_forms_with_source_metadata, resolve_conditionals,
};

fn code_children(form: &Form) -> &[Form] {
    match &form.kind {
        Kind::List(items) | Kind::Vector(items) | Kind::Map(items) | Kind::Set(items) => {
            items.as_slice()
        }
        _ => &[],
    }
}
fn children(form: &Form) -> impl Iterator<Item = &Form> {
    form.metadata.iter().chain(code_children(form))
}

type WorkMeter<'a> = dyn FnMut(u64) -> Result<(), Diagnostic> + 'a;

fn charge(
    meter: &mut WorkMeter<'_>,
    amount: usize,
    span: &std::ops::Range<usize>,
) -> Result<(), Diagnostic> {
    if amount == 0 {
        return Ok(());
    }
    let amount = u64::try_from(amount).unwrap_or(u64::MAX);
    meter(amount).map_err(|mut error| {
        error.span = span.clone();
        error
    })
}

fn all_children(form: &Form) -> Vec<&Form> {
    let mut result: Vec<_> = form.metadata.iter().collect();
    match &form.kind {
        Kind::List(items)
        | Kind::Vector(items)
        | Kind::Map(items)
        | Kind::Set(items)
        | Kind::Conditional(items)
        | Kind::SplicingConditional(items) => result.extend(items),
        Kind::Discard(item) => result.push(item),
        Kind::Prefix { operator, target } => result.extend([operator.as_ref(), target.as_ref()]),
        _ => {}
    }
    result
}

#[derive(Clone, Copy)]
enum CompareMode {
    Same(bool),
    Derived,
}

/// Iterative equivalent of `same` that meters both node visits and compared
/// text. `Derived` is used only where the legacy fallback delegated to Form's
/// derived PartialEq implementation.
fn same_metered(
    left: &Form,
    right: &Form,
    metadata: bool,
    meter: &mut WorkMeter<'_>,
) -> Result<bool, Diagnostic> {
    let mut pending = vec![(left, right, CompareMode::Same(metadata))];
    while let Some((a, b, mode)) = pending.pop() {
        charge(meter, 1, &a.span)?;
        if a.span != b.span {
            return Ok(false);
        }
        let derived = matches!(mode, CompareMode::Derived);
        if derived || matches!(mode, CompareMode::Same(true)) {
            if a.metadata.len() != b.metadata.len() {
                return Ok(false);
            }
            pending.extend(a.metadata.iter().zip(&b.metadata).rev().map(|(x, y)| {
                (
                    x,
                    y,
                    if derived {
                        CompareMode::Derived
                    } else {
                        CompareMode::Same(true)
                    },
                )
            }));
        }
        let equal = match (&a.kind, &b.kind) {
            (Kind::Nil, Kind::Nil) => true,
            (Kind::Bool(x), Kind::Bool(y)) => x == y,
            (Kind::Number(x), Kind::Number(y)) => {
                if derived {
                    x == y
                } else {
                    x.to_bits() == y.to_bits()
                }
            }
            (Kind::String(x), Kind::String(y)) => {
                charge(meter, x.len().max(y.len()), &a.span)?;
                x == y
            }
            (Kind::Symbol(x), Kind::Symbol(y)) => {
                charge(
                    meter,
                    x.name.len().max(y.name.len())
                        + x.namespace
                            .as_ref()
                            .map_or(0, String::len)
                            .max(y.namespace.as_ref().map_or(0, String::len)),
                    &a.span,
                )?;
                x == y
            }
            (Kind::Keyword(x), Kind::Keyword(y)) => {
                charge(
                    meter,
                    x.name.len().max(y.name.len())
                        + x.namespace
                            .as_ref()
                            .map_or(0, String::len)
                            .max(y.namespace.as_ref().map_or(0, String::len)),
                    &a.span,
                )?;
                x == y
            }
            (Kind::List(x), Kind::List(y))
            | (Kind::Vector(x), Kind::Vector(y))
            | (Kind::Map(x), Kind::Map(y))
            | (Kind::Set(x), Kind::Set(y))
                if x.len() == y.len() =>
            {
                pending.extend(x.iter().zip(y).rev().map(|(x, y)| (x, y, mode)));
                true
            }
            (Kind::Conditional(x), Kind::Conditional(y))
            | (Kind::SplicingConditional(x), Kind::SplicingConditional(y))
                if x.len() == y.len() =>
            {
                pending.extend(
                    x.iter()
                        .zip(y)
                        .rev()
                        .map(|(x, y)| (x, y, CompareMode::Derived)),
                );
                true
            }
            (Kind::Discard(x), Kind::Discard(y)) => {
                pending.push((x, y, CompareMode::Derived));
                true
            }
            (
                Kind::Prefix {
                    operator: xo,
                    target: xt,
                },
                Kind::Prefix {
                    operator: yo,
                    target: yt,
                },
            ) => {
                pending.push((xt, yt, CompareMode::Derived));
                pending.push((xo, yo, CompareMode::Derived));
                true
            }
            _ => false,
        };
        if !equal {
            return Ok(false);
        }
    }
    Ok(true)
}

fn form_text_bytes(form: &Form) -> usize {
    match &form.kind {
        Kind::String(value) => value.len().saturating_mul(2),
        Kind::Symbol(value) => value
            .name
            .len()
            .saturating_add(value.namespace.as_ref().map_or(0, String::len)),
        Kind::Keyword(value) => value
            .name
            .len()
            .saturating_add(value.namespace.as_ref().map_or(0, String::len)),
        _ => 0,
    }
}

fn rebuild_form(node: &Form, children: Vec<Form>) -> Form {
    let mut children = children.into_iter();
    let metadata = children
        .by_ref()
        .take(node.metadata.len())
        .collect::<Vec<_>>();
    let values = children.collect::<Vec<_>>();
    let kind = match &node.kind {
        Kind::Nil => Kind::Nil,
        Kind::Bool(value) => Kind::Bool(*value),
        Kind::Number(value) => Kind::Number(*value),
        Kind::String(value) => Kind::String(value.clone()),
        Kind::Symbol(value) => Kind::Symbol(value.clone()),
        Kind::Keyword(value) => Kind::Keyword(value.clone()),
        Kind::List(_) => Kind::List(values),
        Kind::Vector(_) => Kind::Vector(values),
        Kind::Map(_) => Kind::Map(values),
        Kind::Set(_) => Kind::Set(values),
        Kind::Conditional(_) => Kind::Conditional(values),
        Kind::SplicingConditional(_) => Kind::SplicingConditional(values),
        Kind::Discard(_) => Kind::Discard(Box::new(values.into_iter().next().unwrap())),
        Kind::Prefix { .. } => {
            let mut values = values.into_iter();
            Kind::Prefix {
                operator: Box::new(values.next().unwrap()),
                target: Box::new(values.next().unwrap()),
            }
        }
    };
    Form {
        span: node.span.clone(),
        metadata,
        kind,
    }
}

pub(crate) fn clone_form_metered(
    form: &Form,
    meter: &mut WorkMeter<'_>,
) -> Result<Form, Diagnostic> {
    let mut pending = vec![(form, false, 0usize)];
    let mut completed = Vec::<Form>::new();
    while let Some((node, finish, child_count)) = pending.pop() {
        if !finish {
            let children = all_children(node);
            charge(
                &mut *meter,
                1usize
                    .saturating_add(children.len())
                    .saturating_add(form_text_bytes(node)),
                &node.span,
            )?;
            pending.push((node, true, children.len()));
            pending.extend(children.into_iter().rev().map(|child| (child, false, 0)));
            continue;
        }
        let children = completed.split_off(completed.len() - child_count);
        completed.push(rebuild_form(node, children));
    }
    Ok(completed.pop().expect("form clone produces a root"))
}

fn same(a: &Form, b: &Form, metadata: bool) -> bool {
    if a.span != b.span {
        return false;
    }
    if metadata
        && (a.metadata.len() != b.metadata.len()
            || !a
                .metadata
                .iter()
                .zip(&b.metadata)
                .all(|(a, b)| same(a, b, true)))
    {
        return false;
    }
    match (&a.kind, &b.kind) {
        (Kind::Number(a), Kind::Number(b)) => a.to_bits() == b.to_bits(),
        (Kind::List(a), Kind::List(b))
        | (Kind::Vector(a), Kind::Vector(b))
        | (Kind::Map(a), Kind::Map(b))
        | (Kind::Set(a), Kind::Set(b)) => {
            a.len() == b.len() && a.iter().zip(b).all(|(a, b)| same(a, b, metadata))
        }
        (a, b) => a == b,
    }
}

#[cfg(test)]
fn find<'a>(
    forms: &'a [Form],
    wanted: &Form,
    metadata: bool,
    budget: &mut usize,
) -> Result<Option<&'a Form>, Diagnostic> {
    let mut pending: Vec<&Form> = forms.iter().rev().collect();
    while let Some(form) = pending.pop() {
        *budget = budget.checked_sub(1).ok_or_else(|| Diagnostic {
            span: wanted.span.clone(),
            message: "Source metadata provenance exceeds traversal bound".into(),
        })?;
        if same(form, wanted, metadata) {
            return Ok(Some(form));
        }
        pending.extend(children(form));
    }
    Ok(None)
}

const TRAVERSAL_BOUND: usize = 1_048_576;

#[derive(Debug)]
pub(super) struct MetadataSnapshot {
    original: IndexedForms,
    located: IndexedForms,
}

#[derive(Debug)]
struct IndexedForms {
    forms: Vec<Form>,
    index: FormIndex,
}

impl IndexedForms {
    fn new(forms: Vec<Form>) -> Self {
        let index = FormIndex::new(&forms, TRAVERSAL_BOUND);
        Self { forms, index }
    }

    fn find(
        &self,
        wanted: &Form,
        metadata: bool,
        budget: &mut usize,
    ) -> Result<Option<&Form>, Diagnostic> {
        self.index.find(&self.forms, wanted, metadata, budget)
    }

    fn new_metered(forms: Vec<Form>, meter: &mut WorkMeter<'_>) -> Result<Self, Diagnostic> {
        let index = FormIndex::new_metered(&forms, meter)?;
        Ok(Self { forms, index })
    }

    fn find_metered(
        &self,
        wanted: &Form,
        metadata: bool,
        meter: &mut WorkMeter<'_>,
    ) -> Result<Option<&Form>, Diagnostic> {
        self.index
            .find_metered(&self.forms, wanted, metadata, meter)
    }
}

#[derive(Debug, Clone, Copy)]
enum Step {
    Root(usize),
    Metadata(usize),
    Code(usize),
}

#[derive(Debug)]
struct Node {
    parent: Option<usize>,
    step: Step,
}

/// Immutable paths into the owned trees, in the linear matcher's visitation
/// order. Nodes contain no cloned subtrees or references into movable storage.
/// Only the bounded prefix reachable by a provenance query is indexed.
#[derive(Debug)]
struct FormIndex {
    nodes: Vec<Node>,
    spans: HashMap<(usize, usize), Vec<usize>>,
    truncated: bool,
    limit: usize,
}

impl FormIndex {
    fn new(forms: &[Form], limit: usize) -> Self {
        let mut pending: Vec<_> = forms
            .iter()
            .enumerate()
            .rev()
            .map(|(i, form)| (form, None, Step::Root(i)))
            .collect();
        let mut nodes = Vec::new();
        let mut spans: HashMap<_, Vec<_>> = HashMap::new();
        while nodes.len() < limit {
            let Some((form, parent, step)) = pending.pop() else {
                break;
            };
            let rank = nodes.len();
            nodes.push(Node { parent, step });
            spans
                .entry((form.span.start, form.span.end))
                .or_default()
                .push(rank);
            // Preserve the old stack order: code children are visited in
            // reverse, followed by metadata children in reverse.
            pending.extend(
                form.metadata
                    .iter()
                    .enumerate()
                    .map(|(i, form)| (form, Some(rank), Step::Metadata(i))),
            );
            pending.extend(
                code_children(form)
                    .iter()
                    .enumerate()
                    .map(|(i, form)| (form, Some(rank), Step::Code(i))),
            );
        }
        Self {
            nodes,
            spans,
            truncated: !pending.is_empty(),
            limit,
        }
    }

    fn new_metered(forms: &[Form], meter: &mut WorkMeter<'_>) -> Result<Self, Diagnostic> {
        let mut pending: Vec<_> = forms
            .iter()
            .enumerate()
            .rev()
            .map(|(i, form)| (form, None, Step::Root(i)))
            .collect();
        let mut nodes = Vec::new();
        let mut spans: HashMap<_, Vec<usize>> = HashMap::new();
        while let Some((form, parent, step)) = pending.pop() {
            let children = children(form).collect::<Vec<_>>();
            charge(meter, 1usize.saturating_add(children.len()), &form.span)?;
            let rank = nodes.len();
            nodes.push(Node { parent, step });
            spans
                .entry((form.span.start, form.span.end))
                .or_default()
                .push(rank);
            pending.extend(
                form.metadata
                    .iter()
                    .enumerate()
                    .map(|(i, child)| (child, Some(rank), Step::Metadata(i))),
            );
            pending.extend(
                code_children(form)
                    .iter()
                    .enumerate()
                    .map(|(i, child)| (child, Some(rank), Step::Code(i))),
            );
        }
        Ok(Self {
            nodes,
            spans,
            truncated: false,
            limit: usize::MAX,
        })
    }

    fn form<'a>(&self, forms: &'a [Form], mut rank: usize) -> &'a Form {
        let mut steps = Vec::new();
        let root = loop {
            let node = &self.nodes[rank];
            match node.parent {
                Some(parent) => {
                    steps.push(node.step);
                    rank = parent;
                }
                None => {
                    let Step::Root(root) = node.step else {
                        unreachable!()
                    };
                    break root;
                }
            }
        };
        let mut form = &forms[root];
        for step in steps.into_iter().rev() {
            form = match step {
                Step::Metadata(i) => &form.metadata[i],
                Step::Code(i) => &code_children(form)[i],
                Step::Root(_) => unreachable!(),
            };
        }
        form
    }

    fn form_metered<'a>(
        &self,
        forms: &'a [Form],
        mut rank: usize,
        meter: &mut WorkMeter<'_>,
        span: &std::ops::Range<usize>,
    ) -> Result<&'a Form, Diagnostic> {
        let mut steps = Vec::new();
        let root = loop {
            charge(meter, 1, span)?;
            let node = &self.nodes[rank];
            match node.parent {
                Some(parent) => {
                    steps.push(node.step);
                    rank = parent;
                }
                None => {
                    let Step::Root(root) = node.step else {
                        unreachable!()
                    };
                    break root;
                }
            }
        };
        let mut form = &forms[root];
        for step in steps.into_iter().rev() {
            charge(meter, 1, span)?;
            form = match step {
                Step::Metadata(i) => &form.metadata[i],
                Step::Code(i) => &code_children(form)[i],
                Step::Root(_) => unreachable!(),
            };
        }
        Ok(form)
    }

    fn find<'a>(
        &self,
        forms: &'a [Form],
        wanted: &Form,
        metadata: bool,
        budget: &mut usize,
    ) -> Result<Option<&'a Form>, Diagnostic> {
        // Public queries start with this bound, or a remainder of it. Charging
        // logical visits keeps shared reader-tree budgets and errors unchanged.
        debug_assert!(*budget <= self.limit);
        let failure = || Diagnostic {
            span: wanted.span.clone(),
            message: "Source metadata provenance exceeds traversal bound".into(),
        };
        let mut charge = |count| -> Result<(), Diagnostic> {
            if let Some(remaining) = budget.checked_sub(count) {
                *budget = remaining;
                Ok(())
            } else {
                *budget = 0;
                Err(failure())
            }
        };
        let mut visited = 0;
        if let Some(candidates) = self.spans.get(&(wanted.span.start, wanted.span.end)) {
            for &rank in candidates {
                charge(rank + 1 - visited)?;
                visited = rank + 1;
                let form = self.form(forms, rank);
                if same(form, wanted, metadata) {
                    return Ok(Some(form));
                }
            }
        }
        charge(self.nodes.len() - visited)?;
        if self.truncated {
            charge(1)?;
        }
        Ok(None)
    }

    fn find_metered<'a>(
        &self,
        forms: &'a [Form],
        wanted: &Form,
        metadata: bool,
        meter: &mut WorkMeter<'_>,
    ) -> Result<Option<&'a Form>, Diagnostic> {
        charge(meter, 1, &wanted.span)?; // span-index lookup
        if let Some(candidates) = self.spans.get(&(wanted.span.start, wanted.span.end)) {
            for &rank in candidates {
                charge(meter, 1, &wanted.span)?;
                let candidate = self.form_metered(forms, rank, meter, &wanted.span)?;
                if same_metered(candidate, wanted, metadata, meter)? {
                    return Ok(Some(candidate));
                }
            }
        }
        Ok(None)
    }
}

impl SourceOrigin {
    /// Reader metadata for a source form whose entire original syntax and spans
    /// still match. Expanded data with reused spans retains only explicit meta.
    /// Neither provenance construction nor comparison evaluates source.
    pub fn macro_form_data(&self, form: &Form) -> Result<Form, Diagnostic> {
        let mut remaining = 1_048_576u64;
        self.macro_form_data_metered(form, &mut |work| {
            remaining = remaining.checked_sub(work).ok_or_else(|| Diagnostic {
                span: form.span.clone(),
                message: "Source provenance computation fuel exhausted".into(),
            })?;
            Ok(())
        })
    }

    /// Metered source-form provenance for macro expansion. The callback is
    /// charged for input bytes parsed, indexed/tree nodes visited, comparisons,
    /// and copied form data. Warm snapshots still charge every lookup and clone.
    /// The legacy `macro_form_data` wrapper retains a finite allowance for
    /// callers that do not provide the session's operation meter.
    pub(crate) fn macro_form_data_metered(
        &self,
        form: &Form,
        meter: &mut impl FnMut(u64) -> Result<(), Diagnostic>,
    ) -> Result<Form, Diagnostic> {
        if let Some(pair) = &self.reader_forms {
            let mut pending = vec![(&pair.0, &pair.1)];
            while let Some((lowered, reader)) = pending.pop() {
                charge(meter, 1, &form.span)?;
                if same_metered(lowered, form, true, &mut *meter)? {
                    return clone_form_metered(reader, &mut *meter);
                }
                // Metadata has an independent shape; source indexing may add
                // prefixes. Never let it shift correspondence of code children.
                charge(
                    meter,
                    lowered.metadata.len().min(reader.metadata.len()),
                    &form.span,
                )?;
                pending.extend(lowered.metadata.iter().zip(&reader.metadata));
                if std::mem::discriminant(&lowered.kind) == std::mem::discriminant(&reader.kind) {
                    let (a, b) = (code_children(lowered), code_children(reader));
                    if a.len() == b.len() {
                        charge(meter, a.len(), &form.span)?;
                        pending.extend(a.iter().zip(b));
                    }
                }
            }
        }
        match self.original_form_data_metered(form, &mut *meter)? {
            Some(original) => Ok(original),
            None => clone_form_metered(form, &mut *meter),
        }
    }

    pub(crate) fn with_reader_expansion(&self, lowered: Form, reader: Form) -> Self {
        let mut result = self.clone();
        result.reader_forms = Some(std::sync::Arc::new((lowered, reader)));
        result
    }

    /// Synthesized defmacro wrappers may not match source. Enrich only verified
    /// original subtrees and leave every compiler-generated location unknown.
    pub(crate) fn reader_tree(&self, form: &Form) -> Result<Form, Diagnostic> {
        let mut remaining = 1_048_576u64;
        self.reader_tree_metered(form, &mut |work| {
            remaining = remaining.checked_sub(work).ok_or_else(|| Diagnostic {
                span: form.span.clone(),
                message: "Source provenance computation fuel exhausted".into(),
            })?;
            Ok(())
        })
    }

    pub(crate) fn reader_tree_metered(
        &self,
        form: &Form,
        meter: &mut impl FnMut(u64) -> Result<(), Diagnostic>,
    ) -> Result<Form, Diagnostic> {
        let mut pending = vec![(form, false, 0usize)];
        let mut completed = Vec::<Form>::new();
        while let Some((node, finish, child_count)) = pending.pop() {
            if !finish {
                charge(meter, 1, &node.span)?;
                if let Some(original) = self.original_form_data_metered(node, &mut *meter)? {
                    completed.push(original);
                    continue;
                }
                let children = all_children(node);
                charge(meter, children.len(), &node.span)?;
                pending.push((node, true, children.len()));
                pending.extend(children.into_iter().rev().map(|child| (child, false, 0)));
            } else {
                let children = completed.split_off(completed.len() - child_count);
                completed.push(rebuild_form(node, children));
            }
        }
        Ok(completed
            .pop()
            .expect("reader tree enrichment produces a root"))
    }

    fn original_form_data_metered(
        &self,
        form: &Form,
        meter: &mut WorkMeter<'_>,
    ) -> Result<Option<Form>, Diagnostic> {
        if self.metadata_forms.get().is_none() {
            // The reader charges actual scanning, selection and location work
            // to this same operation rather than starting an independent pool.
            let path = self
                .path
                .as_ref()
                .map(|path| {
                    charge(meter, path.as_os_str().len(), &form.span)?;
                    path.to_str().ok_or_else(|| Diagnostic {
                        span: form.span.clone(),
                        message: "Source metadata path is not Unicode".into(),
                    })
                })
                .transpose()?;
            let mut reader_meter = |work| {
                meter(work).map_err(|error| suss_reader::ParseError {
                    span: error.span,
                    message: error.message,
                    expected: vec![],
                })
            };
            let parsed = suss_reader::forms::read_forms_metered(&self.text, &mut reader_meter)
                .map_err(|error| Diagnostic {
                    span: form.span.clone(),
                    message: format!("Unable to construct source metadata snapshot: {error}"),
                })?;
            let original =
                suss_reader::forms::resolve_conditionals_metered(parsed, &mut reader_meter)
                    .map_err(|error| Diagnostic {
                        span: form.span.clone(),
                        message: format!("Unable to construct source metadata snapshot: {error}"),
                    })?;
            let located = suss_reader::forms::read_forms_with_source_metadata_metered(
                &self.text,
                path,
                &mut reader_meter,
            )
            .map_err(|error| Diagnostic {
                span: form.span.clone(),
                message: format!("Unable to construct source metadata snapshot: {error}"),
            })?;
            let snapshot = MetadataSnapshot {
                original: IndexedForms::new_metered(original, meter)?,
                located: IndexedForms::new_metered(located, meter)?,
            };
            // If another thread won the OnceLock race, our extra construction
            // was still charged, and all future lookup work uses the winner.
            let _ = self.metadata_forms.set(Ok(snapshot));
        }
        let forms = self.metadata_forms.get().expect("snapshot initialized");
        let snapshot = forms.as_ref().map_err(|error| Diagnostic {
            span: form.span.clone(),
            message: format!("Unable to construct source metadata snapshot: {error}"),
        })?;
        if snapshot.original.find_metered(form, true, meter)?.is_none() {
            return Ok(None);
        }
        let Some(found) = snapshot.located.find_metered(form, false, meter)? else {
            return Err(Diagnostic {
                span: form.span.clone(),
                message: "Verified source form missing from source metadata snapshot".into(),
            });
        };
        Ok(Some(clone_form_metered(found, meter)?))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn all_forms(forms: &[Form]) -> Vec<&Form> {
        let mut pending: Vec<_> = forms.iter().rev().collect();
        let mut result = Vec::new();
        while let Some(form) = pending.pop() {
            result.push(form);
            pending.extend(children(form));
        }
        result
    }

    fn equivalent(forms: &[Form], index: &FormIndex, wanted: &Form, metadata: bool, budget: usize) {
        let (mut linear_budget, mut indexed_budget) = (budget, budget);
        let linear = find(forms, wanted, metadata, &mut linear_budget);
        let indexed = index.find(forms, wanted, metadata, &mut indexed_budget);
        assert_eq!(
            linear_budget, indexed_budget,
            "remaining budget for {wanted:?}"
        );
        match (linear, indexed) {
            (Ok(Some(a)), Ok(Some(b))) => {
                // Pointer identity verifies first-match order, including forms
                // which have identical spans, metadata and syntax.
                assert!(std::ptr::eq(a, b), "different first match for {wanted:?}");
            }
            (Ok(None), Ok(None)) => (),
            (Err(a), Err(b)) => {
                assert_eq!(a.span, b.span);
                assert_eq!(a.message, b.message);
            }
            (a, b) => panic!("linear/indexed mismatch for {wanted:?}: {a:?} / {b:?}"),
        }
    }

    #[test]
    fn provenance_index_matches_linear_reader_trees_and_budget_boundaries() {
        let source = "^:outer (do [1 -0.0 ##NaN] {:a #{2 3} :b ^{:tag number} value})\n#?(:suss (quote x) :cljs nope)";
        let original = resolve_conditionals(read_forms(source).unwrap()).unwrap();
        let located = read_forms_with_source_metadata(source, Some("source.cljc")).unwrap();
        for forms in [&original, &located] {
            let all = all_forms(forms);
            let limit = all.len() + 2;
            let index = FormIndex::new(forms, limit);
            for form in all {
                let mut changed = form.clone();
                changed.kind = Kind::String(vec![0xd83d, 0, 0xdc00]);
                let mut changed_metadata = form.clone();
                changed_metadata.metadata.push(Form {
                    span: 0..0,
                    metadata: Vec::new(),
                    kind: Kind::Bool(false),
                });
                for wanted in [form, &changed, &changed_metadata] {
                    for metadata in [false, true] {
                        for budget in 0..=limit {
                            equivalent(forms, &index, wanted, metadata, budget);
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn provenance_index_preserves_colliding_spans_float_bits_and_child_order() {
        let leaf = |number| Form {
            span: 0..1,
            metadata: Vec::new(),
            kind: Kind::Number(number),
        };
        let forms = vec![
            Form {
                span: 0..1,
                metadata: vec![leaf(0.0), leaf(-0.0)],
                kind: Kind::Vector(vec![
                    leaf(f64::from_bits(0x7ff8000000000001)),
                    leaf(-0.0),
                    leaf(-0.0),
                ]),
            },
            leaf(f64::from_bits(0x7ff8000000000002)),
        ];
        let index = FormIndex::new(&forms, 20);
        for form in all_forms(&forms) {
            for budget in 0..=20 {
                equivalent(&forms, &index, form, true, budget);
                equivalent(&forms, &index, form, false, budget);
            }
        }
        let absent_nan = leaf(f64::from_bits(0xfff8000000000001));
        for budget in 0..=20 {
            equivalent(&forms, &index, &absent_nan, true, budget);
        }
    }

    #[test]
    fn provenance_index_truncation_preserves_early_matches_and_exhaustion() {
        let forms = read_forms("[0 [1 2] 3] 4 5").unwrap();
        let absent = Form {
            span: 100..101,
            metadata: Vec::new(),
            kind: Kind::Nil,
        };
        for limit in 0..=all_forms(&forms).len() {
            let index = FormIndex::new(&forms, limit);
            for wanted in all_forms(&forms).into_iter().chain([&absent]) {
                for budget in 0..=limit {
                    equivalent(&forms, &index, wanted, true, budget);
                }
            }
        }
        let index = FormIndex::new(&[], 0);
        equivalent(&[], &index, &absent, true, 0);
    }

    #[test]
    fn provenance_index_late_unique_span_has_one_candidate() {
        let source = (0..10_000)
            .map(|i| i.to_string())
            .collect::<Vec<_>>()
            .join(" ");
        let forms = read_forms(&source).unwrap();
        let index = FormIndex::new(&forms, TRAVERSAL_BOUND);
        let wanted = forms.last().unwrap();
        assert_eq!(
            index.spans[&(wanted.span.start, wanted.span.end)],
            vec![9_999]
        );
        let mut budget = TRAVERSAL_BOUND;
        assert!(std::ptr::eq(
            index
                .find(&forms, wanted, true, &mut budget)
                .unwrap()
                .unwrap(),
            wanted
        ));
        assert_eq!(budget, TRAVERSAL_BOUND - 10_000);
        equivalent(&forms, &index, wanted, true, 10_000);
        equivalent(&forms, &index, wanted, true, 9_999);
    }

    #[test]
    fn provenance_snapshot_metering_charges_cold_build_and_warm_lookups() {
        let source = "^:marked (identity [false nil -0.0]) {:key \"value\"}";
        let original = resolve_conditionals(read_forms(source).unwrap()).unwrap();
        let located = read_forms_with_source_metadata(source, Some("snapshot.sus")).unwrap();
        let origin = SourceOrigin::new(source, Some("snapshot.sus".into()));
        let clone = origin.clone();
        let mut cold_work = 0u64;
        let cold = clone
            .original_form_data_metered(original.first().unwrap(), &mut |amount| {
                cold_work += amount;
                Ok(())
            })
            .unwrap();
        let mut warm_work = 0u64;
        let warm = origin
            .original_form_data_metered(original.first().unwrap(), &mut |amount| {
                warm_work += amount;
                Ok(())
            })
            .unwrap();
        assert!(
            cold.as_ref()
                .is_some_and(|form| same(form, located.first().unwrap(), false))
        );
        assert!(
            warm.as_ref()
                .is_some_and(|form| same(form, located.first().unwrap(), false))
        );
        assert!(
            cold_work > warm_work,
            "cold snapshot construction must be charged"
        );
        assert!(
            warm_work > 0,
            "warm cache lookup/comparison/clone must still be charged"
        );

        let mut remaining = 0u64;
        let failure = origin
            .original_form_data_metered(original.first().unwrap(), &mut |amount| {
                remaining = remaining.checked_add(amount).ok_or_else(|| Diagnostic {
                    span: 0..0,
                    message: "test counter overflow".into(),
                })?;
                Err(Diagnostic {
                    span: 0..0,
                    message: "host budget exhausted".into(),
                })
            })
            .unwrap_err();
        assert_eq!(failure.span, original[0].span);
        assert_eq!(failure.message, "host budget exhausted");
        assert!(remaining > 0);
        assert!(std::sync::Arc::ptr_eq(
            &origin.metadata_forms,
            &clone.metadata_forms
        ));
        assert!(origin.metadata_forms.get().unwrap().is_ok());
    }

    #[test]
    fn metered_reader_provenance_handles_deep_forms_without_recursive_comparison_or_clone() {
        fn nested(depth: usize, leaf: Form) -> Form {
            (0..depth).fold(leaf, |form, _| Form {
                span: 0..1,
                metadata: vec![],
                kind: Kind::Vector(vec![form]),
            })
        }
        let leaf = Form {
            span: 0..1,
            metadata: vec![],
            kind: Kind::Number(-0.0),
        };
        let lowered = nested(96, leaf.clone());
        let reader = nested(96, leaf);
        let origin =
            SourceOrigin::new("", None).with_reader_expansion(lowered.clone(), reader.clone());
        let mut work = 0u64;
        let observed = origin
            .macro_form_data_metered(&lowered, &mut |amount| {
                work += amount;
                Ok(())
            })
            .unwrap();
        assert_eq!(observed, reader);
        assert!(work > 96);
        let different = nested(
            96,
            Form {
                span: 0..1,
                metadata: vec![],
                kind: Kind::Number(0.0),
            },
        );
        let mut mismatch_work = 0u64;
        let observed = origin
            .macro_form_data_metered(&different, &mut |amount| {
                mismatch_work += amount;
                Ok(())
            })
            .unwrap();
        assert_eq!(
            observed, different,
            "binary64 sign bits remain part of provenance identity"
        );
        assert!(mismatch_work > 96);
    }

    #[test]
    fn metered_provenance_accepts_source_larger_than_legacy_text_cap() {
        let source = format!("{}target", " ".repeat(1_100_000));
        let form = read_forms(&source).unwrap().remove(0);
        let origin = SourceOrigin::new(source, None);
        let mut work = 0u64;
        let observed = origin
            .macro_form_data_metered(&form, &mut |amount| {
                work += amount;
                Ok(())
            })
            .unwrap();
        assert_eq!(observed.span, form.span);
        assert_eq!(observed.kind, form.kind);
        assert!(work > 2_200_000);
    }
}
