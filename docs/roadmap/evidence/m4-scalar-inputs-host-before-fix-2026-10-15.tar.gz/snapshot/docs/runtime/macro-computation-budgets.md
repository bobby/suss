# Compiler and macro computation budgets

Macro expansion uses compiled Suss in a Macro-phase Session. Its guest execution
and explicitly accounted native work consume the same Wasmtime Store fuel
counter. Native Rust instructions are not automatically metered by Wasmtime.
Fuel is a computation allowance, not a byte limit or a complete memory policy.

## Scope and configuration

`SessionOptions::fuel_per_operation` defaults to 10,000,000. The default has not
been raised by the cumulative-accounting changes. `Session::set_operation_fuel`
(and the corresponding CompiledMacros method) changes the allowance for the next
outer operation; it does not refill an operation already in progress.

An outer operation establishes its fuel and epoch deadline. Nested request
scopes, constructors, transformer calls and inspection helpers reuse the remaining
counter. Leaving a nested scope does not replenish it. Request guards retire on
success, returned error and panic unwinding. A later independent operation starts
with its configured allowance.

Expansion accounting includes caller provenance and quotation, explicit
arguments, materialized `&env` graphs, compiled transformer execution, nested
helpers, result realization and decoding. Source reading, selection, metadata,
syntax-quote support, IR lowering and verification also have explicit work charges on their
metered entry points. The AOT and persistent REPL paths use this same compiled
expansion machinery. Runtime execution and the isolated Macro Session retain
separate Stores and configurations.

Standalone native APIs that have no Session use finite computation allowances:

| Entry point | Default allowance |
| --- | ---: |
| Form reading and conditional selection | 10,000,000 |
| ReaderState syntax-quote expansion | 10,000,000 |
| Default ExpansionHost request | 10,000,000 |
| Standalone IR, liveness and continuation verification | 10,000,000 |
| Legacy SourceOrigin provenance convenience wrappers | 1,048,576 |

Production expansion paths pass their caller's meter to provenance operations;
they do not reset the standalone provenance allowance for every form. Native
convenience APIs can establish separate allowances at stage boundaries. A default
emitter for a host without an accounting hook has its own finite allowance rather
than debiting that host's analysis ledger; custom emitter overrides remain the
host's responsibility.

## Charging and recovery

Native charges describe work performed: visited forms/graph edges, copied or
compared text units, allocated collection entries, reader bytes, and verifier
word operations. Traversal and copies are charged before their corresponding
unbounded allocations where supported. Source-tag encoding copies already
charged large scalars in bounded chunks and polls cancellation between chunks
without charging the same bytes twice. Other native clones can perform a
precharged copy as one operation.
Provenance cache hits still charge lookup, comparison and copying work. Guest
realization invokes live methods rather than trusting cached lazy storage across
calls or callbacks.

Raw form identities are interned bottom-up from exact scalar payloads and ordered
child identities. Raw metadata, namespace presence, number bits and UTF-16 units
remain part of identity; bare spans remain separate compiler facts. Key lookup
uses fallible byte comparisons that bill inspected prefixes and poll cancellation.
Planning buffers and tree growth are precharged, including possible relocation;
tree insertion conservatively admits 64 primitive updates per ancestor plus 12
fixed updates before mutation. These are computation charges, not an additional
form-size rejection policy or a promise about process memory admission.

Before graph construction invokes reader callbacks, a cycle-checked DAG counts
logical materialization frame work in reverse postorder. Repeated reader nodes
propagate every arrival; compiler sharing barriers propagate one execution.
Duplicate dependency edges remain separate arrivals. Each executed frame costs
twice its dependency count plus one for copying dependencies, visiting edges and
finishing the frame. Checked count overflow rejects admission. The planner bills
its actual compact counting work and compares required frame work with remaining
fuel; materialization bills that work when performed. Guest constructor and
callback execution consume additional fuel. This avoids expanding every logical
occurrence merely to preflight it and does not move or omit callbacks.

Immutable native source ownership does not make the transported guest object's
reachable arrays immutable. Sharing across expansions must preserve both the
pinned captured-declaration metadata identity and the original source facts,
without trusting guest-mutated storage or suppressing live construction callbacks.
Fresh construction alone prevents mutation leakage but does not satisfy that
cross-invocation identity contract. Compiler record/revision sharing and
intentional quote aliases within one graph build remain separate requirements.

IR dominance intersections use dense bitsets and charge word operations. Runtime
field-name validation reads an immutable string length once per call. Prototype
cycle checking reuses validation only inside a callback-free traversal; later
operations validate the current storage again. Such implementation changes can
reduce actual fuel cost without changing the configured allowance, user source,
observable metadata, or validation contract. Fuel costs are not stable source
size estimates or wall-clock predictions.

Optional artifact-key construction can decline reuse after 64K admitted work
units. Mandatory IR verification still runs first, and the crossing operation
is billed to the shared budget before decline is considered. Real exhaustion or
cancellation remains an error. A declined key is discarded and verified IR is
emitted fresh, without a cache lookup or entry mutation. Produced Debug fragments
are charged in full before hashing can stop; successful hash framing remains
unchanged. This cache admission policy does not reject large source forms or
change their metadata, execution effects or operation allowance.

Native Session installation reserves `suss.compiler-integrity` for future
authenticated compiler operations. Ordinary artifacts cannot inherit that
namespace from a populated linker or claim it through source provenance.
Import checks debit the active Store budget and poll cancellation. All artifacts
are checked before allocating binding cells, executing module start functions,
or publishing staged environments.
Only the embedded bootstrap, checked against its manifest and artifact identity,
receives a private Rust authority token. Installation checks each module against
that token using its verified executable-body digest and phase; authority does
not extend to other batch members. Public artifact restoration and ordinary
evaluation receive no token. No reserved memo hook is registered yet; authentic
memo-write receipts and checked metadata reuse remain implementation work.

Nominal construction likewise reads schema length and each outer field-name
length once during its callback-free duplicate-name normalization. It still
reads the current descriptor fields and UTF-16 units on every construction,
ignores nonstring schema slots for name matching, and uses the last matching
argument without overwriting the input argument array. No schema cache survives
the call.

Protocol lookup retains its original first-four-pair path. Later complete
four-pair groups share a bounds check; partial groups retain ordered individual
checks, followed by the existing loop after sixteen pairs. Odd table lengths
are rejected before lookup. Each call reads the current table and matching
value; duplicate keys retain first-match behavior. This changes the instruction
cost by table size and match position rather than caching a prior result.

A native charge that exceeds remaining fuel leaves the Store at zero and returns
OutOfFuel. A consumed cancellation request likewise leaves zero fuel and returns
Interrupt. Native work checks the Session's cancellation flag; guest execution
also uses epoch interruption. An idle interrupt is discarded when the next outer
operation starts. Nested entry does not clear an active request.

Failed expansion does not install a partial Runtime compilation. Recovery starts
a new operation with the same configuration. Already executed effects and failed
definition handling follow the accepted Session atomicity contract; compilation
is not a transaction over arbitrary guest objects or external effects.

## Structural validity and coverage boundaries

Finite syntax is governed by computation accounting rather than fixed form-node,
source-text or language nesting ceilings. Cycle detection, malformed layouts,
foreign ownership, signed runtime lengths, checked count arithmetic and ABI
validity remain required. Native recursive paths need stack growth or iterative
walks independently of fuel. Bounded hash-trie routing and batch sizes are
algorithm choices, not user-form rejection thresholds.

The host ledger is not yet a complete bound on all compiler activity. Wasm emission, engine module compilation, cached-Wasm validation/copying and some
native cache comparison/clone paths have work outside it. Do not infer complete
compiler resource coverage from an individual metered traversal or a passing
small fixture. Allocation admission and process OOM behavior require a separate
memory policy.

Executing regression locations include `compiled_macro_cumulative_fuel`,
`compiled_macro_forms`, `portable_hir_resources`,
`portable_module_discovery_budget`, `portable::syntax_quote::tests`,
`portable::ir::metering_tests`, `portable::origin::tests`, and
`portable::origin::form_metadata::tests`. Commands, actual outcomes and raw
failure locations are retained in the handoff; issue acceptance evidence belongs
in GitHub.

The native source-constructor argument-buffer copy charges one host-work unit
and polls cancellation for each supplied reference, including extra arguments
that the ordinary constructor subsequently ignores. The opt-in constructor-input
witness additionally charges its native schema copies, expected-field references,
UTF-16 comparisons and storage inspection to the same operation. It does not
refill the budget around preparation, construction or matching. This preparation
is not enabled for ordinary transport or retained-root reuse.

Native array and constructor builders now check input owners in argument order
within the active operation budget. Each reached valid input costs one host-work
unit and polls cancellation before scanning the next input. A reached foreign
value fails before its own charge; an exhausted or cancelled valid prefix can
stop before a later foreign argument is reached. Native values are already
materialized when this check runs. Array-buffer copies also charge and poll per
reference. The helpers establish no per-element budget refill.
