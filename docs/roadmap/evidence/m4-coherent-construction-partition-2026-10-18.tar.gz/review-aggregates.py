import pathlib,json,re,collections,hashlib
P=pathlib.Path(__file__).parent;R=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');lines=(P/'callable.log').read_text().splitlines();a=json.loads((P/'partition.json').read_text());out=[]
for ri,r in enumerate(a['requests']):
 complete=[b for b in r['boundaries'] if b['complete']];assert len(complete)==51;all_intervals=[];total=sum(b['cost'] for b in complete);recomputed=collections.Counter()
 for b in complete:
  stacks=collections.defaultdict(list);sums=collections.Counter();counts=collections.Counter();intervals=[]
  for i in range(b['start_line'],b['end_line']+1):
   l=lines[i];m=re.search(r'source-materialize-call label=(\S+) event=(before|after)',l)
   if m:k='call:'+m[1];event=m[2]
   else:
    m=re.search(r'source-snapshot phase=(\S+) count=\d+ event=(before|after)',l)
    if m:k='snapshot:'+m[1];event=m[2]
    else:
     m=re.search(r'source-domain domain=\S+ staged=\S+ phase=(\S+) event=(before|after)',l)
     if m:k='domain:'+m[1];event=m[2]
     else:
      m=re.search(r'source-domain-record domain=\S+ fact=(\S+) phase=(\S+) event=(before|after)',l)
      if not m:continue
      k='record:'+m[1]+':'+m[2];event=m[3]
   n=int(re.search(r'remaining=(?:Some\()?(\d+)',l)[1])
   if event=='before':stacks[k].append((i,n))
   else:
    assert stacks[k];start,before=stacks[k].pop();assert before>=n;sums[k]+=before-n;counts[k]+=1;intervals.append((k,start,i,before-n))
  assert not any(stacks.values());assert {x['label']:(x['count'],x['debit']) for x in b['nested_inclusive_intervals_not_additive']}=={k:(counts[k],v) for k,v in sums.items()};recomputed.update(sums);all_intervals+=intervals
 calls=[x for x in all_intervals if x[0].startswith('call:')];calls.sort(key=lambda x:x[1]);assert all(calls[i][2]<calls[i+1][1] for i in range(len(calls)-1)),('bridgecalloverlap',ri)
 enroll=[x for x in calls if x[0]=='call:domain-enrollment'];keys=['record:Constructor:snapshot-capture','record:Constructor:prototype','record:Array:snapshot-capture'];sub=[x for x in all_intervals if x[0] in keys]
 for x in sub:assert sum(y[1]<=x[1] and x[2]<=y[2] for y in enroll)==1
 sub.sort(key=lambda x:x[1]);assert all(sub[i][2]<sub[i+1][1] for i in range(len(sub)-1))
 out.append({'request':ri,'completed_construction_inclusive':total,'disjoint_bridge_calls':{k:v for k,v in recomputed.items() if k.startswith('call:')},'nested_selected_enrollment_parts':{k:recomputed[k] for k in keys},'bridge_labels_mutually_nonoverlapping':True,'selected_enrollment_subparts_disjoint_and_wholly_inside_enrollment':True})
assert out[0]['completed_construction_inclusive']==9205330 and min(x['completed_construction_inclusive'] for x in out[1:])==9159991 and max(x['completed_construction_inclusive'] for x in out[1:])==9205302
first=out[0];assert first['disjoint_bridge_calls']['call:domain-enrollment']==3637122 and first['disjoint_bridge_calls']['call:hash-invocation-inclusive']==1787629;assert list(first['nested_selected_enrollment_parts'].values())==[1270143,1161447,241100]
report=R/'docs/roadmap/evidence/m4-coherent-construction-partition-2026-10-18.md';sha=lambda b:hashlib.sha256(b).hexdigest();o={'verdict':'APPROVED_EXPANDED_AGGREGATE_PARSER_AND_REPORT_FOR_DIAGNOSTIC_PACKAGING','source':a['source'],'report_path':str(report.relative_to(R)),'report_sha256':sha(report.read_bytes()),'handoff_sha256':sha((R/'docs/roadmap/handoff.md').read_bytes()),'expanded_parser_sha256':sha((P/'analyze.py').read_bytes()),'expanded_partition_sha256':sha((P/'partition.json').read_bytes()),'raw_log_sha256':sha((P/'callable.log').read_bytes()),'all_completed_boundary_aggregates_independently_recomputed_including_record_labels':True,'requests':out,'interpretation':['Across completed51prefix domain-enrollment is larger than hashinvocation; boundary23hashdominance is local, not aggregatewholeprefixdominance.','Bridgecallintervals directly verified mutuallynonoverlapping in thistrace. Constructor snapshot/prototype and Array snapshot intervals directly verified disjointsubintervals withinenrollment. Do not add them again to enrollment/constructor totals.','No eliminableduplicatework/saving established by aggregate costs. Incompleteboundary26 and laterexport/finalization/values remainunknown/unexecuted.','Expand existing nativeconstructor/prototype/snapshot recordlabels and residualhash before selecting implementation; no authorization for skippedvalidation/warmcache/ratecuts.'],'prior_terminal_review':'terminal-review.json: six requests/publicJSONexactownedcandidate,3668frozenfilesGitbound, no newexecution.','limits':['Earlier terminal-review recorded prioranalyze/partition hashes; this supplemental review supersedes only expandedparser/partition hashes and adds newaggregateverification. Rawtrace unchanged.','No production adoption, acceptancepass, oracle/fullbaseline/CI/closure/promotion. Archive/finaldocscope audit separate.'],'reviewer_actions':'Read-only existingraw/parser/report audit; host cache script/receipt only, no Cargo/source edits.'};(P/'reports-review.json').write_text(json.dumps(o,indent=2)+'\n');print(P/'reports-review.json')
