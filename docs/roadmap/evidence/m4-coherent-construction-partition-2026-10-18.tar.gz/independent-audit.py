import pathlib,json,re,hashlib,collections,subprocess
P=pathlib.Path(__file__).parent;R=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');sha=lambda b:hashlib.sha256(b).hexdigest();receipt=json.loads((P/'receipt.json').read_text());assert receipt['terminal'] and receipt['exit']==101 and not receipt['changed'];source=receipt['source'];assert source=='2d2275bcb8905e0501de3f39d143431fc28fa963';raw=(P/'callable.log').read_text();lines=raw.splitlines();assert re.findall(r'test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored',raw)==[('0','1','0')];obj=json.loads((P/'callable.json').read_text());assert obj==json.loads((P.parent/'snapshot-owned-type-v1/callable.json').read_text());assert len(obj['phases'])==2 and all(not x['observations']['rows'] and len(x['observations']['errors'])==3 for x in obj['phases'])
a=json.loads((P/'partition.json').read_text());runs=[];r=None;pending=None
for i,l in enumerate(lines):
 m=re.search(r'coherent-stage stage=([\w-]+) boundary=(None|Some\(\d+\)).*remaining=Some\((\d+)\)',l)
 if not m:continue
 st,b,n=m.groups();n=int(n)
 if st=='entry':r={'complete':[],'markers':[]};runs.append(r);pending=None
 if r is None:continue
 r['markers'].append([st,b,n])
 if st=='construct-before':assert pending is None;pending=(b,n,i)
 if st=='construct-after':assert pending and pending[0]==b;r['complete'].append({'id':int(b[5:-1]),'start_line':pending[2],'end_line':i,'cost':pending[1]-n});pending=None
assert len(runs)==6;results=[]
for ix,r in enumerate(runs):
 assert len(r['complete'])==51 and r['markers'][-1][:2]==['construct-before','Some(26)'];assert not any(x[0].startswith(('finalize','export-construct','postcallback')) for x in r['markers']);expected=[x for x in a['requests'][ix]['boundaries'] if x['complete']];assert [(x['id'],x['cost'],x['start_line'],x['end_line']) for x in r['complete']]==[(x['id'],x['cost'],x['start_line'],x['end_line']) for x in expected]
 # Validate every completed-boundary parsed aggregate, not just the largest row.
 biggest=None
 for b,e in zip(r['complete'],expected):
  stacks=collections.defaultdict(list);sums=collections.Counter();counts=collections.Counter();intervals=[]
  for i in range(b['start_line'],b['end_line']+1):
   l=lines[i];m=re.search(r'source-materialize-call label=(\S+) event=(before|after)',l)
   if m:key='call:'+m[1];event=m[2]
   else:
    m=re.search(r'source-snapshot phase=(\S+) count=\d+ event=(before|after)',l)
    if m:key='snapshot:'+m[1];event=m[2]
    else:
     m=re.search(r'source-domain domain=\S+ staged=\S+ phase=(\S+) event=(before|after)',l)
     if not m:continue
     key='domain:'+m[1];event=m[2]
   fuel=int(re.search(r'remaining=(?:Some\()?(\d+)',l)[1])
   if event=='before':stacks[key].append((i,fuel))
   else:
    assert stacks[key],(ix,b['id'],key)
    start,before=stacks[key].pop();assert before>=fuel;sums[key]+=before-fuel;counts[key]+=1;intervals.append((key,start,i,before-fuel))
  assert not any(stacks.values())
  assert {x['label']:(x['count'],x['debit']) for x in e['nested_inclusive_intervals_not_additive']}=={k:(counts[k],v) for k,v in sums.items()}
  if b['id']==23:
   hs=[x for x in intervals if x[0]=='call:hash-invocation-inclusive'];assert len(hs)==18 and sum(x[3] for x in hs)==692058
   assert all(hs[i][2]<hs[i+1][1] for i in range(17))
   selected={k:[x for x in intervals if x[0]=='domain:'+k] for k in ['storage-and-edges','source-classes','prototype']}
   for k,seq in selected.items():assert len(seq)==36 and all(sum(h[1]<=x[1] and x[2]<=h[2] for h in hs)==1 for x in seq)
   seq=sorted(sum(selected.values(),[]),key=lambda x:x[1]);assert all(seq[j][2]<seq[j+1][1] for j in range(len(seq)-1))
   sums3={k:sum(x[3] for x in v) for k,v in selected.items()};assert sums3=={'storage-and-edges':139374,'source-classes':78300,'prototype':67320};biggest={'boundary':23,'construction_inclusive':b['cost'],'hash_intervals':18,'hash_inclusive':692058,'nested_domain_parts':sums3,'hash_residual_excluding_only_these_three_disjoint_parts':407064,'qualification':'Residual still includes other native hooks/canonical/method and guest work; not pureguest cost.'}
 assert max(x['cost'] for x in r['complete'])==1037471 and biggest['construction_inclusive']==1037471;results.append({'request':ix,'complete_constructors':51,'failure_boundary':26,'finalization':False,'largest':biggest})
manifest=json.loads((P/'source-manifest.json').read_text());assert len(manifest)==3668;changed=[n for n,h in manifest.items() if not (R/n).is_file() or sha((R/n).read_bytes())!=h]
requests=[source+':'+n for n in manifest];data=subprocess.check_output(['git','cat-file','--batch'],cwd=R,input=('\n'.join(requests)+'\n').encode());pos=0;bad=[]
for n,h in manifest.items():
 end=data.index(b'\n',pos);header=data[pos:end];pos=end+1;assert not header.endswith(b' missing'),n;oid,typ,size=header.split();size=int(size);b=data[pos:pos+size];pos+=size+1
 if typ!=b'blob' or sha(b)!=h:bad.append(n)
assert not bad
o={'verdict':'VERIFIED_FAILED_DIAGNOSTIC_PARTITION_AND_SOURCE_BINDING','source':source,'execution':{'selected_rust':1,'pass':0,'fail':1,'ignored':0,'exit':101,'seconds':receipt['seconds'],'public_requests':6,'rows':0,'public_json_exact_owned_candidate':True},'requests':results,'all_completed_boundary_parser_aggregates_recomputed':True,'source_freeze':{'actual_tracked_regular_files':len(manifest),'receipt_changed':receipt['changed'],'current_rehash_changed':changed,'all_manifest_files_exact_git_source':True,'qualification':'Actual3668files, not tentative3662. No expanded external/untracked oracleinput claim.'},'artifacts_sha256':{n:sha((P/n).read_bytes()) for n in ['callable.log','callable.json','partition.json','analyze.py','receipt.json','source-manifest.json']},'next_bounded_diagnostic':'First use these already-captured intervals to partition remaining407064hashunits into existing canonical/method/directfact/callback labels, retaining nesting and occurrences. If a concrete residual remains unattributed, one source-preserving label boundary around that exact livehash/helper path is appropriate; no cache/skip optimization authorized merely by aggregatecounts.','limits':['Hash692058 nested insideconstruction1037471; domainparts nested insidehash, not additive to either enclosing span.','Partial failingboundary26 and fullrequestrequiredcost unknown; no export/finalization/value observations.','No perf-saving, acceptance, adoption, productionCI or closure claim.'],'reviewer_actions':'Read-only existingraw/source/Git audit plus hostcacheparser; no Cargo/source edits/newruntimeexecution.'};(P/'terminal-review.json').write_text(json.dumps(o,indent=2)+'\n');print(P/'terminal-review.json');print('freeze',len(manifest),'current_changes',changed)
