import subprocess as s,pathlib,os,json,time,hashlib
p=pathlib.Path('/home/bobby/.cache/suss-m4-work/coherent-construction-stages-v1');env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',SUSS_METADATA_FUEL_TRACE='1',SUSS_CALLABLE_IDENTITY_OUTPUT=str(p/'callable.json'))
rows=[]
for name,cmd in [('bootstrap',['cargo','run','--profile','test','--locked','-p','suss-cli','--bin','suss-bootstrap','--','runtime/bootstrap']),('callable',['cargo','test','--locked','-p','suss-cli','--test','compiled_macro_namespace_identity','resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations','--','--exact','--test-threads=1','--nocapture'])]:
 t=time.time()
 with (p/(name+'.log')).open('w') as f:r=s.run(cmd,env=env,stdout=f,stderr=s.STDOUT)
 rows.append(dict(name=name,argv=cmd,exit=r.returncode,seconds=time.time()-t));(p/'receipt.json').write_text(json.dumps(rows,indent=2))
 print(name,r.returncode,flush=True)
 if name=='bootstrap' and r.returncode:break
