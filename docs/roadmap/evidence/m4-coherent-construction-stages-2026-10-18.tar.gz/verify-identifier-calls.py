import pathlib,re,json,collections,hashlib
p=pathlib.Path(__file__).parent;runs=[];run=None;active=None;stack=[];nested=0;identifier_count=0
for line in (p/'detailed-callable.log').open():
 if 'coherent-stage stage=entry ' in line:
  assert not stack and active is None
  run={'calls':collections.defaultdict(lambda:[0,0]),'identifiers':0,'identifier_dispatch_units':0};runs.append(run)
 if run is None:continue
 m=re.search(r'source-materialize root=(\d+) recipe=(\d+) kind=identifier event=dispatch-before remaining=Some\((\d+)\)',line)
 if m:
  assert active is None and not stack
  active=(m[1],m[2],int(m[3]));run['identifiers']+=1
 m=re.search(r'source-materialize-call label=([\w-]+) event=before remaining=Some\((\d+)\)',line)
 if m and active:
  if stack:nested+=1
  stack.append([m[1],int(m[2]),0])
 m=re.search(r'source-materialize-call label=([\w-]+) event=after result=(.*) remaining=Some\((\d+)\)',line)
 if m and active:
  assert stack and stack[-1][0]==m[1]
  label,before,child=stack.pop();inclusive=before-int(m[3]);assert inclusive>=child and m[2]=='Ok(())'
  run['calls'][label][0]+=1;run['calls'][label][1]+=inclusive-child
  if stack:stack[-1][2]+=inclusive
 m=re.search(r'source-materialize root=(\d+) recipe=(\d+) event=dispatch-after result=(.*) remaining=Some\((\d+)\)',line)
 if m and active:
  assert not stack and (m[1],m[2])==active[:2] and m[3]=='Ok(())'
  run['identifier_dispatch_units']+=active[2]-int(m[4]);active=None
assert not stack and active is None and len(runs)==6
expected=json.loads((p/'identifier-call-analysis.json').read_text());assert [dict(r['calls']) for r in runs]==expected
for r in runs:
 assert r['identifiers']==211
 r['calls']=dict(r['calls']);r['sum_exclusive_call_units']=sum(v[1] for v in r['calls'].values());r['residual_outside_call_scopes']=r['identifier_dispatch_units']-r['sum_exclusive_call_units'];assert r['residual_outside_call_scopes']>=0
out={'verdict':'VERIFIED_RAW_IDENTIFIER_CALL_ATTRIBUTION','requests':runs,'nested_same_family_scopes_observed':nested,'method':'Matched LIFO before/after labels inside completed identifier dispatches; subtract directly nested inclusive durations once. No unmatched or failed call scopes in these completed identifiers.','raw_sha256':hashlib.sha256((p/'detailed-callable.log').read_bytes()).hexdigest(),'analysis_sha256':hashlib.sha256((p/'identifier-call-analysis.json').read_bytes()).hexdigest(),'limits':['These call costs are nested within identifier dispatch and construction totals; do not add across enclosing scopes.','Labels describe inclusive work within each call boundary after subtraction of nested same-family scopes; no finer attribution to pure allocation, validation, guest code or duplicate work is established.','No new execution/source changes, proven eliminable duplicate work or measured saving. Full current physical/memo authority and callback/error ordering remain required.']}
(p/'identifier-call-independent-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'requests':runs,'nested':nested,'receipt':str(p/'identifier-call-independent-review.json')}))
