import pathlib,json,re,hashlib
P=pathlib.Path(__file__).parent;R=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance')
def sha(b):return hashlib.sha256(b).hexdigest()
def scan(name):
 runs=[];r=None;pending=None;cb=None
 for line in (P/name).open():
  if 'coherent-stage stage=entry ' in line:
   assert pending is None
   r={'markers':[],'construct':[],'dispatch':[],'failed':[]};runs.append(r);cb=None
  if r is None:continue
  m=re.search(r'coherent-stage stage=([\w-]+) boundary=(None|Some\(\d+\)).*remaining=Some\((\d+)\)',line)
  if m:
   st,b,n=m.groups();n=int(n);r['markers'].append([st,b,n])
   if st=='construct-before':assert cb is None;cb=(b,n)
   if st=='construct-after':assert cb and cb[0]==b;r['construct'].append({'boundary':b,'units':cb[1]-n});cb=None
  m=re.search(r'source-materialize root=(\d+) recipe=(\d+) kind=([\w-]+) event=dispatch-before remaining=Some\((\d+)\)',line)
  if m and cb:
   assert pending is None,'overlapping dispatch: cannot call exclusive'
   root,recipe,kind,n=m.groups();pending={'root':root,'recipe':recipe,'kind':kind,'before':int(n),'boundary':cb[0]}
  m=re.search(r'source-materialize root=(\d+) recipe=(\d+) event=dispatch-after result=(.*) remaining=Some\((\d+)\)',line)
  if m and pending:
   assert (m[1],m[2])==(pending['root'],pending['recipe']);d=pending;pending=None;d.update(after=int(m[4]),result=m[3]);d['units']=d['before']-d['after'];r['dispatch' if d['result']=='Ok(())' else 'failed'].append(d)
 assert pending is None
 assert len(runs)==6
 return runs
coarse=scan('callable.log');detailed=scan('detailed-callable.log');ca=json.loads((P/'construction-analysis.json').read_text());da=json.loads((P/'detailed-analysis.json').read_text());summary=[]
for i,(a,b) in enumerate(zip(coarse,detailed)):
 assert a['markers']==b['markers']
 assert len(a['construct'])==45
 assert sum(x['units'] for x in a['construct'])==ca[i]['completed_units']
 assert a['markers'][-1][0:2]==['construct-before','Some(23)']
 assert not any(x[0].startswith(('finalize','postcallback-recheck','export-construct')) for x in a['markers'])
 assert b['dispatch']==da[i]['completed_dispatches'] and b['failed']==da[i]['failed_dispatches']
 ids=[x for x in b['dispatch'] if x['kind']=='identifier'];assert len(ids)==211 and len(set(x['recipe'] for x in ids))==80
 assert len(b['failed'])==1;f=b['failed'][0];assert f['root']==f['recipe']=='94' and f['kind']=='map' and f['boundary']=='Some(23)' and f['after']==0
 summary.append({'completed_constructors':45,'inclusive_completed_construction_units':sum(x['units'] for x in a['construct']),'identifier_dispatch_count':211,'identifier_exact_recipe_ids':80,'completed_exclusive_identifier_dispatch_units':sum(x['units'] for x in ids),'partial_failed_map_debit':f['units'],'last_marker':a['markers'][-1],'finalization_reached':False})
a=json.loads((P/'callable.json').read_text());assert a==json.loads((P/'detailed-callable.json').read_text())==json.loads((P.parent/'shared-native-witness-acceptance-v1/callable.json').read_text())
assert len(a['phases'])==2
for ph in a['phases']:
 assert ph['observations']['rows']==[] and len(ph['observations']['errors'])==3
 assert all('caller &env input transport' in x['error'] and 'all fuel consumed' in x['error'] for x in ph['observations']['errors'])
for n in ['callable.log','detailed-callable.log']:
 s=(P/n).read_text();assert re.findall(r'test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored;',s)==[('0','1','0')]
hashes=json.loads((P/'during-run-source-hashes.json').read_text());bad=[n for n,h in hashes.items() if not (R/n).is_file() or sha((R/n).read_bytes())!=h]
o={'verdict':'VERIFIED_DIAGNOSTIC_FAILED_PREFIX_EVIDENCE_ONLY','requests':summary,'public_json_exact_historical_candidate':True,'six_public_fuel_errors_zero_rows':True,'coarse_detailed_all_coherent_stage_rows_and_balances_exact':True,'analysis_json_recomputed_from_raw':True,'dispatch_intervals_nonoverlapping':True,'executions':{'coarse':'0PASS1FAIL0ignored exit101','detailed':'0PASS1FAIL0ignored exit101; repeated same selected test, not additive acceptance coverage'},'source_binding':{'during_first_run_files':len(hashes),'current_mismatches':bad,'qualification':'Hashes were captured DURING first run, not a before-run whole-tree freeze. Terminal-binding claims during-to-terminal unchanged. Current rehash is an additional later check only.','during_run_manifest_sha256':sha((P/'during-run-source-hashes.json').read_bytes())},'limits':['Construction before/after spans are INCLUSIVE and must not be summed with dispatch subintervals.','Completed dispatch intervals are nonoverlapping in this raw trace; exclusive means relative to other dispatch intervals, not pure guest execution or exclusive native work. Each includes any nested helper/guest costs within that dispatch.','Partial failing map94 debits558682..612615 exhaust remaining fuel; total cost needed for successful completion is UNKNOWN. Unstarted later construction/finalization costs are unknown.','No finalization or postcallback-recheck stage reached. No identity/value rows decoded; no acceptance, adoption, issue closure, baseline or CI success.'],'artifacts_sha256':{n:sha((P/n).read_bytes()) for n in ['callable.log','callable.json','detailed-callable.log','detailed-callable.json','construction-analysis.json','detailed-analysis.json','analyze.py','terminal-binding.json']}}
(P/'terminal-review.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps({'receipt':str(P/'terminal-review.json'),'requests':summary,'current_mismatches':bad}))
