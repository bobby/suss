import pathlib,re,collections,json
p=pathlib.Path(__file__).parent;runs=[];run=None;inside=False;stack=[]
for l in (p/'detailed-callable.log').open():
 if 'coherent-stage stage=entry ' in l:run=collections.defaultdict(lambda:[0,0]);runs.append(run)
 if run is None:continue
 if 'source-materialize ' in l and 'event=dispatch-before' in l:inside='kind=identifier ' in l;stack=[]
 if 'source-materialize ' in l and 'event=dispatch-after' in l:inside=False
 if not inside:continue
 m=re.search(r'source-materialize-call label=([\w-]+) event=before remaining=Some\((\d+)\)',l)
 if m:stack.append([m[1],int(m[2]),0]);continue
 m=re.search(r'source-materialize-call label=([\w-]+) event=after result=Ok\(\(\)\) remaining=Some\((\d+)\)',l)
 if m:
  name,start,children=stack.pop();assert name==m[1];elapsed=start-int(m[2]);run[name][0]+=1;run[name][1]+=elapsed-children
  if stack:stack[-1][2]+=elapsed
(p/'identifier-call-analysis.json').write_text(json.dumps([dict(r) for r in runs],indent=2)+'\n')
