import pathlib,re,json,collections,hashlib
p=pathlib.Path(__file__).parent
runs=[];run=None;pending={};boundary=None
for line in (p/'detailed-callable.log').open():
 if 'coherent-stage stage=entry ' in line:
  run=dict(completed_dispatches=[],failed_dispatches=[],unclosed=[],markers=[]);runs.append(run);pending={};boundary=None
 if run is None:continue
 m=re.search(r'coherent-stage stage=([\w-]+) boundary=(None|Some\(\d+\)).*remaining=Some\((\d+)\)',line)
 if m:
  stage,b,n=m.groups();run['markers'].append([stage,b,int(n)])
  if stage=='construct-before':boundary=b
  if stage=='construct-after':boundary=None
 m=re.search(r'source-materialize root=(\d+) recipe=(\d+) kind=([\w-]+) event=dispatch-before remaining=Some\((\d+)\)',line)
 if m and boundary is not None:
  root,node,kind,n=m.groups();pending[(root,node)]=dict(boundary=boundary,root=root,recipe=node,kind=kind,before=int(n))
 m=re.search(r'source-materialize root=(\d+) recipe=(\d+) event=dispatch-after result=(.*) remaining=Some\((\d+)\)',line)
 if m and (m[1],m[2]) in pending:
  row=pending.pop((m[1],m[2]));row.update(after=int(m[4]),result=m[3]);row['units']=row['before']-row['after']
  run['completed_dispatches' if row['result']=='Ok(())' else 'failed_dispatches'].append(row)
 if 'CALLABLE_NAMESPACE_IDENTITY ' in line and run is not None:
  run['unclosed']=list(pending.values())
# An error marker can contain an escaped multiline error, but after markers are one actual line.
for i,r in enumerate(runs):
 bykind=collections.defaultdict(lambda:dict(count=0,units=0))
 for d in r['completed_dispatches']:
  bykind[d['kind']]['count']+=1;bykind[d['kind']]['units']+=d['units']
 r['completed_by_kind']=dict(bykind)
 print(i,'bykind',dict(bykind),'failed',r['failed_dispatches'],'final',r['markers'][-1] if r['markers'] else None)
(p/'detailed-analysis.json').write_text(json.dumps(runs,indent=2)+'\n')
