# Borrowed metadata guard candidate

Base: `0acd17f9a59f14ac64e2bebd9770a75424a99cda`.
Only the validation-only metadata route changes. No consuming normalizer,
Graph recipe/raw-key transport, ordinary normalization caller or quota changes.
The manifest binds all four Rust files, including the new test module.

## Semantics and lifetime

The complete existing reader metadata view normalizes all prefixes before any
winning contents are visited. The same preserve_source_error wrapper transports
meter failures as original typed SessionError values. The old synthetic Map
root contributes exactly one unit. Reverse entries push value then key, yielding
key/value source visitation order. The view remains alive through the inner
walk, retaining synthesized shorthand owners. The inner loop deliberately does
NOT traverse item.metadata. The original outer pending metadata traversal and
ordinary node checks are unchanged, including malformed map/prefix/target errors.

The generic visit observer is a no-op at the production entrypoint. It gives
unit tests the full semantic visit sequence (including a distinct synthetic root)
without copying Form payloads in production. The retained old implementation in
the test module is the pre-change owned guard, with only the same observer added.

## Actual work and metering

Removed work: materializing and deep-copying every winning normalized key/value
into a temporary Vec<Form>, and reconstructing a temporary synthetic Form map.
Remaining normalization, key equality, all text/UTF16 and guard traversal charges
are retained. Cloning is not a semantic validator: the old clone routine also
reconstructs unresolved prefix kinds, which the unchanged guard rejects later.
New reference-stack backing is checked, fallibly reserved, and prepaid before
allocation. Geometric requested capacity plus existing live-reference relocation
is charged in bytes, plus allocation/release control. The eventual release fee
is paid at acquisition even if a later meter failure aborts. Stack references do
not retain or clone Form owners. Existing view backing/shorthand accounting is
unchanged; this does not claim to repair all pre-existing allocation/drop gaps.

## Focused tests (NOT EXECUTED)

Filter: `portable_macro_graph::metadata_guard_tests::` (three tests).

- Compare complete Forms/spans/nested metadata and semantic visit order with the
  retained owned guard, including canonical equal map/list-vector keys, key and
  value metadata, shorthands, 128-level equal nested keys and raw UTF16 units.
  A metadata-heavy fixture compares actual summed planned charge units and
  requires lower work. No numeric result or runtime benefit is claimed yet.
- Compare typed semantic errors and visits for malformed losing/late prefixes,
  odd maps, unsupported metadata targets, nested winner metadata and losing
  malformed values. No strengthened inner metadata validation.
- Inject exact OutOfFuel and ForeignValue errors at EVERY charge of a successful
  path, assert immediate propagation and no later charge, unchanged full input,
  and identical complete charge-sequence retry after each failure.

Retain existing sharing tests (including metadata callback/source-order guards),
quote/view tests, default CoreEnv and original record/reduction criteria when root
runs the reviewed candidate. No Cargo/bootstrap/guest tests have run for this
patch. git diff --check passed. No source commit, staging or push performed.
