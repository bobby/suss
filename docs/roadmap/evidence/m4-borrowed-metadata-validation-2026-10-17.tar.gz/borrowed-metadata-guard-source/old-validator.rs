fn validate_form_data(form: &Form, charge: &mut impl FnMut(u64) -> Result<()>) -> Result<()> {
    let mut pending = vec![form];
    while let Some(form) = pending.pop() {
        let text_units = match &form.kind {
            Kind::String(value) => value.len(),
            Kind::Symbol(value) => value.to_string().encode_utf16().count(),
            Kind::Keyword(value) => {
                value.name.encode_utf16().count()
                    + value
                        .namespace
                        .as_ref()
                        .map_or(0, |ns| ns.encode_utf16().count() + 1)
            }
            _ => 0,
        };
        charge(1u64.saturating_add(text_units as u64))?;
        match &form.kind {
            Kind::List(items) | Kind::Vector(items) | Kind::Map(items) | Kind::Set(items) => {
                if matches!(form.kind, Kind::Map(_)) && items.len() % 2 != 0 {
                    return Err(SessionError::Host(wasmtime::Error::msg(
                        "Macro form map requires paired entries",
                    )));
                }
                pending.extend(items.iter().rev());
            }
            Kind::Conditional(_)
            | Kind::SplicingConditional(_)
            | Kind::Discard(_)
            | Kind::Prefix { .. } => {
                return Err(SessionError::Host(wasmtime::Error::msg(
                    "Native macro data requires resolved reader prefixes",
                )));
            }
            _ => {}
        }
        if !form.metadata.is_empty() {
            if !matches!(
                form.kind,
                Kind::Symbol(_) | Kind::List(_) | Kind::Vector(_) | Kind::Map(_) | Kind::Set(_)
            ) {
                return Err(SessionError::Host(wasmtime::Error::msg(
                    "Metadata requires a symbol or collection",
                )));
            }
            // Normalize and clone metadata within the same graph work budget.
            charge(form.metadata.len() as u64)?;
            let pairs = preserve_source_error(form.span.clone(), charge, |charge| {
                hir::reader_metadata_pairs_metered(form, &mut |work| charge(work))
            })?;
            let normalized = Form {
                span: form.span.clone(),
                metadata: vec![],
                kind: Kind::Map(pairs),
            };
            // Keep the temporary alive until it is visited below by validating
            // it immediately with a second iterative stack.
            let mut metadata_pending = vec![&normalized];
            while let Some(item) = metadata_pending.pop() {
                let used = match &item.kind {
                    Kind::String(value) => value.len(),
                    Kind::Symbol(value) => value.to_string().encode_utf16().count(),
                    Kind::Keyword(value) => {
                        value.name.encode_utf16().count()
                            + value
                                .namespace
                                .as_ref()
                                .map_or(0, |ns| ns.encode_utf16().count() + 1)
                    }
                    _ => 0,
                };
                charge(1u64.saturating_add(used as u64))?;
                match &item.kind {
                    Kind::Map(items) if items.len() % 2 == 0 => {
                        metadata_pending.extend(items.iter().rev())
                    }
                    Kind::Map(_) => {
                        return Err(SessionError::Host(wasmtime::Error::msg(
                            "Macro form map requires paired entries",
                        )));
                    }
                    Kind::List(items) | Kind::Vector(items) | Kind::Set(items) => {
                        metadata_pending.extend(items.iter().rev())
                    }
                    Kind::Conditional(_)
                    | Kind::SplicingConditional(_)
                    | Kind::Discard(_)
                    | Kind::Prefix { .. } => {
                        return Err(SessionError::Host(wasmtime::Error::msg(
                            "Native macro data requires resolved reader prefixes",
                        )));
                    }
                    _ => {}
                }
            }
        }
        pending.extend(form.metadata.iter().rev());
    }
    Ok(())
}
