"""Prepared preservation; no execution without --execute and root release."""
from pathlib import Path
import argparse,collections,datetime,fcntl,hashlib,importlib.util,json,os,re,shutil,subprocess,time,sys
C=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def testnames(p):
    text=p.read_text();assert not re.search(r'^\s*#\[ignore',text,re.M),('Ignored selection',str(p))
    names=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',text);assert names and len(names)==len(set(names));return names

def stages(root):
    cargo=['cargo','test','--locked'];tail=['--','--test-threads=1','--nocapture'];lib=['-p','suss-compile','--lib'];cli=['-p','suss-cli'];source=[]
    modules=['portable_session/scalar_inputs','portable_session/write_domain','portable_session/construction_records','portable_session/storage_snapshot','portable_macro_graph/raw_keys','portable_macro_graph/initializer_plan']
    prefixes=['::'.join(n.split('/'))+'::tests::' for n in modules]
    for n in modules:source+=testnames(root/('crates/suss-compile/src/'+n+'.rs'))
    child='source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo';source+=[child];prefixes+=[child];assert len(source)==len(set(source))==59,('Source cohort changed',source)
    core=testnames(root/'crates/suss-cli/tests/core_import.rs')
    if 'mod portable_decode;' in (root/'crates/suss-cli/tests/core_import.rs').read_text():core+=testnames(root/'crates/suss-compile/tests/support/portable_decode.rs')
    assert len(core)==17
    graph=testnames(root/'crates/suss-cli/tests/compiled_macro_analysis_graph.rs')
    if 'mod portable_decode;' in (root/'crates/suss-cli/tests/compiled_macro_analysis_graph.rs').read_text():graph+=testnames(root/'crates/suss-compile/tests/support/portable_decode.rs')
    # All actual full-target tests, without a guessed35-test selection.
    bitwise='bitwise_hash_match_independently_decoded_primary_observations_after_gc';assert bitwise in testnames(root/'crates/suss-cli/tests/portable_bitwise_hash.rs')
    mapname='pinned_map_declaration_executes_without_transport_loss'
    return [
      {'name':'source-domain-raw-key','command':cargo+lib+tail+prefixes,'names':source,'env':{'SUSS_SOURCE_CHILD_FUEL_TRACE':'1'}},
      {'name':'core-import','command':cargo+cli+['--test','core_import']+tail,'names':core},
      {'name':'map','command':cargo+['-p','suss-compile','--test','clojure_test_suite',mapname,'--','--exact','--test-threads=1','--nocapture'],'names':[mapname],'capture':True},
      {'name':'pinned-bitwise','command':cargo+cli+['--test','portable_bitwise_hash',bitwise,'--','--exact','--test-threads=1','--nocapture'],'names':[bitwise]},
      {'name':'analysis-graph','command':cargo+cli+['--test','compiled_macro_analysis_graph']+tail,'names':graph}]

def parse(text):
    starts=list(re.finditer(r'^test (\S+) \.\.\.',text,re.M));rows=[]
    for i,m in enumerate(starts):
        segment=text[m.end():starts[i+1].start() if i+1<len(starts) else len(text)];status=re.findall(r'(?:^|\n)\s*(ok|FAILED|ignored)\s*(?=\n|$)',segment);assert len(status)==1,('Unfinished/ambiguous test',m[1]);rows.append({'name':m[1],'status':status[0]})
    sums=[dict(zip(('pass','fail','ignore'),map(int,x))) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)];return rows,sums

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--plan',type=Path,default=C/'borrowed-metadata-validation-preservation-plan.json');ap.add_argument('--execute',action='store_true');args=ap.parse_args()
    if not args.execute:print('PREPARED ONLY; no Cargo/leases/snapshots. Await borrowed-metadata focused terminal freeze and root release.');return
    plan=load(args.plan);assert plan.get('root_launch_authorization') and plan.get('expected_base'),'Root final binding/release required'
    focus=Path(plan['focused_run']);r=load(focus/'receipt.json');assert r['current'] is None and r['final_changed']==[] and 'stopped_anomaly' not in r
    assert r['stages'][-1]['name']=='record-reduction-witnesses' and all('exit' in x for x in r['stages']) and r['stages'][0]['name']=='bootstrap' and r['stages'][0]['exit']==0
    assert not Path('/proc',str(r['driver_pid'])).exists(),('Focused driver live',r['driver_pid'])
    root=Path(plan['root']);target=Path(plan['target']);run=Path(plan['run']);assert r['base']==plan['expected_base']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
    assert not subprocess.check_output(['git','ls-files','-u'],cwd=root)
    binding=load(focus/'bound-plan.json');packet=Path(binding['packet_manifest']);assert sha(packet.read_bytes())==binding['packet_manifest_sha256'];assert binding['expected_base']==plan['expected_base']
    expected=load(focus/'terminal-freeze.json');assert expected==load(focus/'after-bootstrap-freeze.json');assert len(expected)==r['input_count']==2989;assert 'crates/suss-compile/src/portable_macro_graph/metadata_guard_tests.rs' in expected
    paths=sorted(expected);freeze=lambda:{n:sha((root/n).read_bytes()) for n in paths};assert freeze()==expected
    for h in set(expected.values()):assert sha((focus/'input-blobs'/h).read_bytes())==h
    assert subprocess.check_output(['git','-C',str(root/'clojurescript'),'rev-parse','HEAD'],text=True).strip()=='c4295f303100bbf5afac449242d30bca1126f1a1'
    specs=stages(root)
    assert [len(stage['names']) for stage in specs]==[59,17,1,1,11], 'Reviewed preservation selection changed'
    assert sum(len(stage['names']) for stage in specs)==89
    assert len({name for stage in specs for name in stage['names']})==89, 'Unexpected duplicate selected names'
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
        try:env=(proc/'environ').read_bytes();exe=str((proc/'exe').resolve())
        except OSError:continue
        assert b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' not in env and not exe.startswith(str(target)+'/'),('Target occupied',proc.name)
    leases=[]
    for n in ['.typed-scalar-witness.lease','.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease']:
        f=open(target/n,'a+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
    # Copy reviewed host-only comparator helper for durable execution provenance.
    helperpath=Path(plan['comparison_helper']);assert sha(helperpath.read_bytes())==plan['comparison_helper_sha256'];sys.dont_write_bytecode=True
    spec=importlib.util.spec_from_file_location('projection_preservation_host_helpers',helperpath);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    run.mkdir(exist_ok=False);shutil.copyfile(__file__,run/'driver.py');shutil.copyfile(helperpath,run/'host-comparison-helper.py');dump(run/'bound-plan.json',plan);dump(run/'source-derived-selection.json',{x['name']:x['names'] for x in specs});dump(run/'before-freeze.json',expected)
    dump(run/'source-CAS-reference.json',{'source_blob_store':str(focus/'input-blobs'),'focus_terminal_freeze':str(focus/'terminal-freeze.json'),'freeze_sha256':sha((focus/'terminal-freeze.json').read_bytes()),'focused_receipt_sha256':sha((focus/'receipt.json').read_bytes()),'scope':'External borrowed-metadata focused CAS reused exactly; no standalone archive claim.'})
    state={'driver_pid':os.getpid(),'root':str(root),'base':plan['expected_base'],'input_count':len(expected),'current':None,'stages':[],'environment':{'jobs':1,'rayon':1,'test_threads':1,'RUSTFLAGS':'inherited, not assigned'},'limits':'No bootstrap rerun/profiles/cap probes or duplicate CoreEnv stage. Focused already traced default CoreEnv; borrowed-metadata terminal exact-source preservation; semantic failures continue; compile/source/selection/process anomalies stop. Fixture-specific unit work is not whole CoreEnv/Native cost.'};save=lambda:dump(run/'receipt.json',state)
    env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target),PYTHONDONTWRITEBYTECODE='1')
    for k in list(env):
        if k.startswith('SUSS_') and (k.endswith('TRACE') or 'CAPTURE' in k):env.pop(k)
    save()
    try:
        for stage in specs:
            name=stage['name'];assert freeze()==expected,('Pre-stage source change',name);row={'name':name,'command':stage['command']};state['stages'].append(row);state['current']=name;save();start=time.monotonic();stageenv=env.copy();stageenv.update(stage.get('env',{}))
            if stage.get('capture'):stageenv['SUSS_CLOJURE_TEST_SUITE_CAPTURE']=str(run/'map-capture')
            with (run/(name+'.log')).open('w') as out:
                proc=subprocess.Popen(stage['command'],cwd=root,env=stageenv,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
            row.update(exit=code,seconds=time.monotonic()-start,changed=[n for n,h in expected.items() if not(root/n).is_file() or sha((root/n).read_bytes())!=h]);save();assert not row['changed'],('Source mutation',name)
            records,sums=parse((run/(name+'.log')).read_text(errors='replace'));row.update(records=records,summaries=sums);save()
            assert collections.Counter(x['name'].split('::')[-1] for x in records)==collections.Counter(stage['names']),('Test selection anomaly',name)
            total={k:sum(x[k] for x in sums) for k in ('pass','fail','ignore')};assert total=={'pass':sum(x['status']=='ok' for x in records),'fail':sum(x['status']=='FAILED' for x in records),'ignore':0};assert code in (0,101) and (code==0)==(total['fail']==0),('Compile/process anomaly',name,code)
            if name=='source-domain-raw-key':
                row['sourcechild']=helper.sourcechild_compare(run,Path(plan['sourcechild_control_log']))
                if code==0:assert row['sourcechild']['candidate_markers']==row['sourcechild']['control_markers']==220 and row['sourcechild']['ordered_labels_results_match'],'Sourcechild completed shape mismatch'
            if name=='map':
                obs=run/'map-capture/map-transport-observations.json'
                if obs.exists():row['capture_sha256']=sha(obs.read_bytes())
                if code==0:helper.map_compare(root,run)
                else:row['map_comparison']='Unexecuted after Rust failure; partial raw observations retained.'
            save() # Continue independent semantic failures.
    except BaseException as error:state['stopped_anomaly']=repr(error);save();raise
    finally:
        state['current']=None;state['final_changed']=[n for n,h in expected.items() if not(root/n).is_file() or sha((root/n).read_bytes())!=h];save()
        if not state['final_changed']:dump(run/'terminal-freeze.json',freeze())
if __name__=='__main__':main()
