"""Prepared only. Explicit --execute and final root-reviewed packet required."""
from pathlib import Path
import argparse,collections,datetime,fcntl,hashlib,json,os,re,shutil,subprocess,time
C=Path(__file__).resolve().parent
BOOT={f'runtime/bootstrap/{p}.{e}' for p in ('macro','runtime') for e in ('wasm','json')}
GRAPH='crates/suss-compile/src/portable_macro_graph.rs'
PROJECTION='crates/suss-compile/src/portable_macro_graph/hir_projection.rs'
CORE='compiled_macro_core_namespace_keeps_complete_declaration_records'
WITNESSES=['public_record_nominal_equality_and_predicate_decode_after_gc_in_both_phases','public_records_execute_jank_and_authored_contracts_with_two_nominal_classes','public_reduce_dispatch_and_source_order_match_pinned_cljs_after_gc']
def sha(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text())
def dump(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args])
def tests(text):
    assert not re.search(r'^\s*#\[ignore',text,re.M),'Ignored source requires explicit revised selection review'
    found=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',text)
    assert found and len(set(found))==len(found),'Empty/duplicate source test selection'
    return found
def module(text,name):
    pattern=r'^mod '+re.escape(name)+r'\s*\{\s*$'
    start=list(re.finditer(pattern,text,re.M));assert len(start)==1,('Module selection',name)
    end=re.search(r'^}\s*$',text[start[0].end():],re.M);assert end,('Unclosed module',name)
    return text[start[0].end():start[0].end()+end.start()]
def stages(root,plan):
    graph=(root/GRAPH).read_text();tail=['--','--test-threads=1','--nocapture'];cargo=['cargo','test','--locked']
    result=[{'name':'bootstrap','command':['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']}]
    validation=(root/plan['validation_source']).read_text()
    if plan.get('validation_inline_module'):
        validation=module(validation,plan['validation_inline_module'])
    for label,prefix,source,count in [
        ('validation',plan['validation_test_prefix'],validation,None),
        ('sharing','portable_macro_graph::sharing_tests::',module(graph,'sharing_tests'),20),
        ('async-payload-clone-meter','portable_macro_graph::async_payload_clone_meter_tests::',module(graph,'async_payload_clone_meter_tests'),3)]:
        selected=[prefix+n for n in tests(source)]
        if count is not None:assert len(selected)==count,('Existing selection changed',label,len(selected),count)
        result.append({'name':label,'command':cargo+['-p','suss-compile','--lib',prefix]+tail,'names':selected})
    assert CORE in tests((root/'crates/suss-cli/tests/compiled_macro_core_environment.rs').read_text())
    result.append({'name':'default-core-env','command':cargo+['-p','suss-cli','--test','compiled_macro_core_environment',CORE,'--','--exact','--test-threads=1','--nocapture'],'names':[CORE],'env':{'SUSS_METADATA_FUEL_TRACE':'1','SUSS_MACRO_FUEL_TRACE':'1'}})
    for n in WITNESSES:
        path='compiled_public_records' if n.startswith('public_record') else 'portable_reduction_dispatch'
        assert n in tests((root/f'crates/suss-cli/tests/{path}.rs').read_text())
    result.append({'name':'record-reduction-witnesses','command':cargo+['-p','suss-cli','--no-fail-fast','--test','compiled_public_records','--test','portable_reduction_dispatch','--','--exact','--test-threads=1','--nocapture']+WITNESSES,'names':WITNESSES})
    return result

def parse(text):
    starts=list(re.finditer(r'^test (\S+) \.\.\.',text,re.M));rows=[]
    for i,m in enumerate(starts):
        segment=text[m.end():starts[i+1].start() if i+1<len(starts) else len(text)]
        status=re.findall(r'(?:^|\n)\s*(ok|FAILED|ignored)\s*(?=\n|$)',segment)
        assert len(status)==1,('Unfinished/ambiguous record',m[1],status)
        rows.append({'name':m[1],'status':status[0]})
    summaries=[dict(zip(('pass','fail','ignore'),map(int,x))) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)]
    return rows,summaries

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--plan',type=Path,default=C/'borrowed-metadata-validation-focused-plan.json');ap.add_argument('--execute',action='store_true');args=ap.parse_args()
    if not args.execute:print('PREPARED ONLY; no Cargo, leases, producer or snapshots. Final reviewed packet/base binding required.');return
    plan=load(args.plan)
    for k in ('expected_base','packet_manifest','packet_manifest_sha256','root_launch_authorization','validation_source','validation_test_prefix'):assert plan.get(k),('Unbound reviewed plan',k)
    root=Path(plan['root']);target=Path(plan['target']);run=Path(plan['run']);packetpath=Path(plan['packet_manifest']);assert sha(packetpath.read_bytes())==plan['packet_manifest_sha256'];packet=load(packetpath)
    assert git(root,'rev-parse','HEAD').decode().strip()==plan['expected_base'];assert not git(root,'ls-files','-u')
    assert plan['validation_source'] in packet['files'], 'Reviewed packet must bind the actual new validation test source'
    assert plan['validation_test_prefix'].endswith('::'), 'Fully qualified validation module prefix required'
    for n,h in packet['files'].items():assert sha((root/n).read_bytes())==h,('Reviewed file hash',n)
    assert git(root/'clojurescript','rev-parse','HEAD').decode().strip()=='c4295f303100bbf5afac449242d30bca1126f1a1' and not git(root/'clojurescript','status','--porcelain').strip()
    seed=load(Path(plan['seed_freeze']));assert len(seed)==2988
    tracked=git(root,'ls-files','-z','--cached','--others','--exclude-standard').decode().split('\0')
    paths=set(seed)|set(packet['files'])
    for n in tracked:
        if n and n.startswith(('crates/','runtime/','scripts/','tests/','vendor/','docs/compatibility/')) and (root/n).is_file() and not n.endswith(('.tar.gz','.zip')) and not any(x in ('target','__pycache__','.git') for x in Path(n).parts):paths.add(n)
    assert PROJECTION in paths and plan['validation_source'] in paths and all((root/n).is_file() for n in paths)
    paths=sorted(paths);freeze=lambda:{n:sha((root/n).read_bytes()) for n in paths}
    initial=freeze();unreviewed=[n for n,h in seed.items() if initial[n]!=h and n not in packet['files']];assert not unreviewed,('Unreviewed old input differences',unreviewed)
    specs=stages(root,plan);selections={s['name']:s.get('names',[]) for s in specs}
    # No discovery/compile-only command is used as execution evidence.
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
        try:env=(proc/'environ').read_bytes();exe=str((proc/'exe').resolve())
        except OSError:continue
        assert b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' not in env and not exe.startswith(str(target)+'/'),('Target occupied',proc.name)
    leases=[]
    for n in ['.typed-scalar-witness.lease','.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease']:
        f=open(target/n,'a+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
    run.mkdir(exist_ok=False);(run/'input-blobs').mkdir();shutil.copyfile(__file__,run/'driver.py');dump(run/'bound-plan.json',plan);dump(run/'reviewed-source-manifest.json',packet);dump(run/'source-derived-selection.json',selections)
    state={'driver_pid':os.getpid(),'root':str(root),'base':plan['expected_base'],'input_count':len(paths),'current':None,'stages':[],'environment':{'jobs':1,'rayon':1,'test_threads':1,'RUSTFLAGS':'inherited; not assigned'},'limits':'Default fixture/budgets unchanged. No cap probes. Actual operation stage/fuel timestamps are not an exhaustive cost partition. Prior212M pre-root residual is unpartitioned, not all cloning. No quote/metadata broad suite added. New guard-only validation + original sharing20/async3 precede unchanged default CoreEnv1 and record/reduce3. Source59/CORE17/map/fullgraph/bitwise follow-up separate, unexecuted here.'}
    save=lambda:dump(run/'receipt.json',state)
    def snapshot(label,data):
        dump(run/(label+'-freeze.json'),data)
        for n,h in data.items():
            dest=run/'input-blobs'/h
            if not dest.exists():dest.write_bytes((root/n).read_bytes())
            assert sha(dest.read_bytes())==h
    expected=initial;snapshot('before',expected);save()
    env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target),PYTHONDONTWRITEBYTECODE='1')
    for k in list(env):
        if k.startswith('SUSS_') and (k.endswith('TRACE') or 'CAPTURE' in k):env.pop(k)
    try:
        for spec in specs:
            assert freeze()==expected,('Pre-stage freeze',spec['name']);row={'name':spec['name'],'command':spec['command']};state['stages'].append(row);state['current']=spec['name'];save();start=time.monotonic();stageenv=env.copy();stageenv.update(spec.get('env',{}))
            with (run/(spec['name']+'.log')).open('w') as out:
                proc=subprocess.Popen(spec['command'],cwd=root,env=stageenv,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
            current=freeze();changed=[n for n in paths if current[n]!=expected[n]];row.update(exit=code,seconds=time.monotonic()-start,changed=changed);save()
            if spec['name']=='bootstrap':
                assert code==0 and set(changed)<=BOOT,('Bootstrap anomaly',code,changed);expected=current;snapshot('after-bootstrap',expected);continue
            assert not changed,('Source mutation',changed)
            text=(run/(spec['name']+'.log')).read_text(errors='replace');records,summaries=parse(text);row.update(records=records,summaries=summaries);save()
            assert collections.Counter(x['name'] for x in records)==collections.Counter(spec['names']),('Exact test selection anomaly',spec['name'])
            total={k:sum(x[k] for x in summaries) for k in ('pass','fail','ignore')};assert total=={'pass':sum(x['status']=='ok' for x in records),'fail':sum(x['status']=='FAILED' for x in records),'ignore':0}
            assert code in (0,101) and (code==0)==(total['fail']==0),('Compile/process anomaly',spec['name'],code)
            if spec['name']=='default-core-env':
                row['raw_trace_lines']=[line for line in text.splitlines() if 'fuel' in line.lower() or 'macro-stage' in line];row['cost_partition']='Unknown beyond explicitly measured existing stage markers; no whole-cost or cloning attribution.'
            save() # Semantic failures continue to the independent remaining gates.
    except BaseException as e:state['stopped_anomaly']=repr(e);save();raise
    finally:
        state['current']=None;state['final_changed']=[n for n,h in expected.items() if not(root/n).is_file() or sha((root/n).read_bytes())!=h];save()
        if not state['final_changed']:snapshot('terminal',freeze())
if __name__=='__main__':main()
