#!/usr/bin/env python3
"""Cache-only thin evidence assembly. Never launches Cargo or writes a repository."""
import argparse, gzip, hashlib, io, json, pathlib, re, shutil, tarfile, subprocess
from collections import Counter
C = pathlib.Path('/home/bobby/.cache/suss-m4-work')
ROOT = pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace')
HERE = pathlib.Path(__file__).resolve().parent
DEPENDENCIES = [
    ('base71', 'm4-boxed-integer-bits-checkpoint-2026-10-17.tar.gz',
     '266d1ce35b4014cbe9eb67fdcf20220cd2dcec0784f0aecb34ef7412e7cdc88c'),
    ('supplement3a', 'm4-invoke-unsigned-upper-bound-2026-10-17.tar.gz',
     '6455ee46741981db166cfc593711236681ea584008c39ed6e202803dd9f5a9f5'),
    ('projection0acd', 'm4-retained-hir-projection-2026-10-17.tar.gz',
     '3971b9301e31abcf2fa16f3720ec1c9a491e0f82e11063ac546fd67fca120f90'),
]
RUNS = ['borrowed-metadata-validation-focused', 'borrowed-metadata-validation-preservation']
PACKETS = ['borrowed-metadata-guard-source']
# Candidate CI and live baseline logs are deliberately excluded.
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_bytes())
def terminal(path):
    r = read(path / 'receipt.json')
    return r.get('current') is None and (path / 'terminal-freeze.json').is_file() and all(
        isinstance(s.get('exit'), int) for s in r.get('stages', []))
def copy_tree(source, destination):
    for f in sorted(source.rglob('*')):
        if f.is_symlink(): raise RuntimeError(f'No symlinks allowed: {f}')
        parts = f.relative_to(source).parts
        if not f.is_file() or 'input-blobs' in parts or ('frozen' in parts and 'sha256' in parts): continue
        target = destination / f.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(f.read_bytes())
def receipt_summary(directory):
    r = read(directory / 'receipt.json'); rows=[]
    for stage in r['stages']:
        counts = {k: sum(s.get(k, 0) for s in stage.get('summaries', [])) for k in ['pass','fail','ignore']}
        rows.append(dict(name=stage['name'], exit=stage['exit'], **counts,
                         diagnostic_duplicate=bool(stage.get('diagnostic_duplicate')),
                         records=stage.get('records', [])))
    return dict(base=r.get('base'), input_count=r.get('input_count'), stages=rows,
                final_changed=r.get('final_changed'), terminal=True)
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--assemble', action='store_true')
    parser.add_argument('--binding', type=pathlib.Path)
    parser.add_argument('--source-commit')
    parser.add_argument('--extra-review', action='append', type=pathlib.Path, default=[])
    parser.add_argument('--parent-ci', type=pathlib.Path)
    parser.add_argument('--diagnostic', type=pathlib.Path)
    parser.add_argument('--diagnostic-binding', type=pathlib.Path)
    parser.add_argument('--diagnostic-root', type=pathlib.Path, default=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-unboxed-bitwise-ssa'))
    parser.add_argument('--parent-baseline', type=pathlib.Path, help='Optional terminal 3a baseline directory; requires --parent-baseline-review')
    parser.add_argument('--parent-baseline-review', type=pathlib.Path)
    args=parser.parse_args()
    state={name: {'terminal': terminal(C/name), 'receipt_sha256':sha((C/name/'receipt.json').read_bytes())} for name in RUNS}
    plan={'dependencies':[{'id':i,'archive':n,'sha256':h} for i,n,h in DEPENDENCIES],
          'runs':state, 'input_maps_expected':2989,
          'scope':'thin supplement; requires ALL THREE exact dependency archives; no standalone claim',
          'counts':'per-attempt executions plus separate deduplicated selected names; diagnostic rerun adds no unique coverage',
          'baseline':'3a terminal exit101; include raw/freezes plus independent verification only as exact parent context, never candidate baseline',
          'ci':'No partial candidate/0acd CI logs; optional parent baseline only after terminal independent review',
          'source_binding':'require final candidate committed Git binding for focused terminal freeze before assembling',
          'output':'cache only; three proposed repository documents are report/archive/handoff append',
          'no_execution':'no guest tests, Cargo, bootstrap, commit, push or repository writes'}
    (HERE/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
    if not args.assemble:
        print(json.dumps(plan,indent=2)); return
    assert all(v['terminal'] for v in state.values()), 'WAIT: frozen preservation/attempt producer not terminal'
    assert args.binding and args.source_commit, 'Final source binding and commit required'
    binding=read(args.binding)
    resolve = lambda head: subprocess.check_output(['git','rev-parse','--verify',head+'^{commit}'], cwd=ROOT, text=True).strip()
    assert resolve(binding['head']) == resolve(args.source_commit) and binding['checked']==2989 and binding['mismatches']==[]
    args.source_commit = resolve(args.source_commit)
    focus_freeze=C/'borrowed-metadata-validation-focused/terminal-freeze.json'
    assert read(pathlib.Path(binding['freeze'])) == read(focus_freeze)
    for name in RUNS:
        r=read(C/name/'receipt.json'); assert r.get('final_changed', [])==[], (name,r.get('final_changed'))
    stage=HERE/'payload'
    assert not stage.exists(), 'Refuse to overwrite reviewed/staged bytes; preserve old attempt explicitly first'
    stage.mkdir()
    for name in RUNS+PACKETS: copy_tree(C/name, stage/name)
    for name in ['run-borrowed-metadata-validation-focused.py',
                 'run-borrowed-metadata-validation-preservation.py','bind-suss-frozen-source.py']:
        source=C/name
        if source.exists(): shutil.copyfile(source,stage/name)
    shutil.copyfile(__file__,stage/'package-borrowed-metadata-validation.py')
    if (HERE/'assembly-attempt-1/package-result.json').exists():
        shutil.copyfile(HERE/'assembly-attempt-1/package-result.json',stage/'initial-assembly-result.json')
        shutil.copyfile(HERE/'assembly-attempt-1/QUALIFICATION.txt',stage/'initial-assembly-qualification.txt')
    shutil.copyfile(args.binding,stage/'candidate-source-commit-binding.json')
    for index,source in enumerate(args.extra_review):
        target=stage/'independent-reviews'/f'{index}-{source.name}'
        target.parent.mkdir(exist_ok=True); target.write_bytes(source.read_bytes())
    # No partial baseline/CI capture. Optional exact parent context requires
    # an independently reviewed, terminal packet explicitly supplied by root.
    if args.parent_baseline:
        assert args.parent_baseline_review and args.parent_baseline_review.is_file()
        parent = read(args.parent_baseline / 'receipt.json')
        assert parent.get('current') is None
        assert parent['head'] == parent['actual_head'] == '3a3898c95fafa7c4faedc4876ed3639286136a89'
        assert parent['git_status'] == ''
        assert parent['input_count'] == 2987
        assert read(args.parent_baseline/'before-freeze.json') == read(args.parent_baseline/'after-freeze.json')
        independent = read(args.parent_baseline_review)
        assert independent['head'] == parent['head'] and independent['before_after_unchanged'] is True
        assert independent['log_sha256'] == sha((args.parent_baseline/'workspace.log').read_bytes())
        assert isinstance(parent.get('exit'), int), 'Require terminal workspace receipt exit'
        assert parent.get('final_changed', parent.get('changed')) == []
        copy_tree(args.parent_baseline, stage/'parent-baseline-3a')
        shutil.copyfile(args.parent_baseline_review, stage/'parent-baseline-independent-review.json')
    parent_ci_summary = None
    if args.parent_ci:
        parent_ci_summary = read(args.parent_ci/'independent-terminal-summary.json')
        assert parent_ci_summary['head'] == '0acd17f9a59f14ac64e2bebd9770a75424a99cda'
        assert parent_ci_summary['run'] == 39064392448 and parent_ci_summary['conclusion'] == 'failure'
        assert parent_ci_summary['all10_logs_verified'] is True
        assert len(parent_ci_summary['checkout_proofs']) == 9
        assert all(x['checkout'] == parent_ci_summary['head'] and x['tree_equals_head'] is True for x in parent_ci_summary['checkout_proofs'])
        copy_tree(args.parent_ci,stage/'parent-ci-0acd17f/39064392448')
    diagnostic_summary = None
    if args.diagnostic:
        assert args.diagnostic_binding and args.diagnostic_binding.is_file()
        assert terminal(args.diagnostic), 'Diagnostic must be terminal'
        diagnostic_binding = read(args.diagnostic_binding)
        assert re.fullmatch('[0-9a-f]{40}',diagnostic_binding['head']), 'Immutable full diagnostic head required; symbolic HEAD rejected'
        diagnostic_head = subprocess.check_output(['git','rev-parse','--verify',diagnostic_binding['head']+'^{commit}'],cwd=args.diagnostic_root,text=True).strip()
        assert diagnostic_head == diagnostic_binding['head']
        assert diagnostic_binding['checked'] == 2988 and diagnostic_binding['mismatches'] == []
        assert read(pathlib.Path(diagnostic_binding['freeze'])) == read(args.diagnostic/'terminal-freeze.json')
        diagnostic_receipt = read(args.diagnostic/'receipt.json')
        assert diagnostic_receipt['final_changed'] == []
        assert [(x['name'],x['exit']) for x in diagnostic_receipt['stages']] == [('bootstrap',0),('core-env',101)]
        analysis = read(args.diagnostic/'tail-region-analysis.json')
        assert analysis['log_sha256'] == sha((args.diagnostic/'core-env.log').read_bytes())
        assert analysis['old_stage_count'] == 777
        assert analysis['all_existing_ordered_stage_labels_and_fuel_equal_parent'] is True
        copy_tree(args.diagnostic,stage/'separate-diagnostic')
        shutil.copyfile(args.diagnostic_binding,stage/'separate-diagnostic-source-binding.json')
        diagnostic_summary = {'head':diagnostic_head,'acceptance_credit':0,'receipt':diagnostic_receipt,'analysis':analysis}
        (stage/'SEPARATE-DIAGNOSTIC.json').write_text(json.dumps(diagnostic_summary,indent=2)+'\n')
    freezes={}
    for name in RUNS:
        for f in sorted((C/name).glob('*freeze*.json')):
            data=read(f)
            assert isinstance(data,dict) and len(data)==2989, (f,len(data))
            assert all(isinstance(h,str) and re.fullmatch('[0-9a-f]{64}',h) for h in data.values())
            freezes[f'{name}/{f.name}']=data
    if args.parent_baseline:
        for name in ['before-freeze.json','after-freeze.json']:
            data = read(args.parent_baseline/name)
            assert len(data) == 2987 and all(re.fullmatch('[0-9a-f]{64}',h) for h in data.values())
            freezes['parent-baseline-3a/'+name] = data
    if args.diagnostic:
        for f in sorted(args.diagnostic.glob('*freeze*.json')):
            data = read(f)
            assert len(data) == 2988 and all(re.fullmatch('[0-9a-f]{64}',h) for h in data.values())
            freezes['separate-diagnostic/'+f.name] = data
    assert freezes
    wanted={h for data in freezes.values() for h in data.values()}
    resolution={}; dependencies=[]
    for identifier,name,expected in DEPENDENCIES:
        archive=ROOT/'docs/roadmap/evidence'/name
        assert sha(archive.read_bytes())==expected, archive
        dependencies.append({'id':identifier,'archive':name,'sha256':expected})
        with tarfile.open(archive,'r:gz') as tar:
            for member in tar:
                h=pathlib.PurePosixPath(member.name).name
                if not member.isfile() or '/input-blobs/' not in '/'+member.name or h not in wanted or h in resolution: continue
                raw=tar.extractfile(member).read(); assert sha(raw)==h
                resolution[h]={'dependency':identifier,'member':member.name,'size':len(raw)}
    sources=[C/name/'input-blobs' for name in RUNS]
    if args.parent_baseline: sources.extend([args.parent_baseline/'input-blobs',args.parent_baseline/'frozen/sha256'])
    if args.diagnostic: sources.append(args.diagnostic/'input-blobs')
    for h in sorted(wanted-resolution.keys()):
        matches=[directory/h for directory in sources if (directory/h).is_file()]
        assert matches, f'Unresolved source blob {h}'
        raw=matches[0].read_bytes(); assert sha(raw)==h
        target=stage/'input-blobs'/h; target.parent.mkdir(exist_ok=True); target.write_bytes(raw)
        resolution[h]={'supplement_member':f'input-blobs/{h}','size':len(raw)}
    assert set(resolution)==wanted
    source_resolution={'format':1,'standalone':False,'required_dependencies':dependencies,
                       'freeze_maps':{n:{'inputs':len(m),'sha256':sha((stage/n).read_bytes())} for n,m in freezes.items()},
                       'blob_resolution':resolution,'resolved_distinct_blobs':len(wanted),
                       'new_blob_count':sum('supplement_member' in v for v in resolution.values())}
    (stage/'BASE-AND-SOURCE-RESOLUTION.json').write_text(json.dumps(source_resolution,indent=2)+'\n')
    summaries={name:receipt_summary(C/name) for name in RUNS}
    selected={}; diagnostics=[]
    for name in RUNS:
        selection=read(C/name/'source-derived-selection.json')
        for item in summaries[name]['stages']:
            expected = Counter(selection.get(item['name'], []))
            # Preservation's source-derived catalog deliberately records leaf
            # names (including all CORE/analysis decoder tests); match its
            # driver policy without discarding multiplicity. Focus uses full
            # module names. Original records stay full for union/dedup below.
            actual = Counter(row['name'].split('::')[-1] if name == 'borrowed-metadata-validation-preservation'
                             else row['name'] for row in item['records'])
            if expected: assert actual == expected, (name, item['name'], expected-actual, actual-expected)
            counts = Counter(row['status'] for row in item['records'])
            assert (item['pass'], item['fail'], item['ignore']) == (
                counts['ok'], counts['FAILED'], counts['ignored']), (name, item['name'], counts)
            if item['diagnostic_duplicate']:
                diagnostics.append({'attempt':name,**item});continue
            for row in item['records']:
                selected.setdefault(row['name'],[]).append({'attempt':name,'stage':item['name'],'status':row['status']})
    # Keep original raw counts; don't add diagnostic reruns or count repeated names twice.
    unique={'pass':0,'fail':0,'ignore':0}
    for test,records in selected.items():
        statuses={r['status'] for r in records}
        assert len(statuses)==1, ('mixed verdict requires manual report',test,statuses)
        status=statuses.pop(); key={'ok':'pass','FAILED':'fail','ignored':'ignore'}[status];unique[key]+=1
    def attempt_counts(name):
        return {key: sum(item[key] for item in summaries[name]['stages']) for key in ['pass', 'fail', 'ignore']}
    focus_counts = attempt_counts('borrowed-metadata-validation-focused')
    preservation_counts = attempt_counts('borrowed-metadata-validation-preservation')
    assert focus_counts == {'pass':26,'fail':4,'ignore':0}, focus_counts
    assert preservation_counts == {'pass':89,'fail':0,'ignore':0}, preservation_counts
    assert unique == {'pass':115,'fail':4,'ignore':0} and len(selected) == 119, unique
    assert diagnostics == [], 'No repeated CoreEnv diagnostic in this preservation run'
    summary={'source_commit':args.source_commit,'attempts':summaries,'unique_by_selected_test_name':unique,
             'selected_records':selected,'diagnostic_repeats_no_unique_credit':diagnostics,
             'limits':'No full workspace/current candidate CI verdict; original 4 focused fuel failures preserved. Fixture costs not whole-CoreEnv saving.'}
    (stage/'TERMINAL-RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n')
    comparison=read(C/'borrowed-metadata-validation-preservation/sourcechild-comparison.json')
    assert comparison['candidate_markers'] == comparison['control_markers'] == 220
    assert comparison['ordered_labels_results_match'] is True
    assert set(comparison['phase_results']) == {'Runtime', 'Macro'}
    for phase in comparison['phase_results'].values():
        assert phase['candidate_start'] == 10000000 and phase['candidate_final_result'] == 'Ok(())'
    for phase in comparison['phase_results'].values():
        assert phase['candidate_remaining'] == 131281 and phase['control_remaining'] == 129753
        assert phase['net_removed_at_final_marker'] == 1528
    validation_log = (C/'borrowed-metadata-validation-focused/validation.log').read_text()
    assert 'owned=49054 borrowed=9087' in validation_log
    replacements = {'{{SOURCE_COMMIT}}': args.source_commit,
                    '{{UNIQUE_RESULTS}}': '119 unique selected tests: 115 pass, 4 fuel failures, zero ignored',
                    '{{PRESERVATION_RESULTS}}': '89 passing executions, zero failures or ignored; no duplicate CoreEnv diagnostic',
                    '{{PHASE_RESULTS}}': json.dumps(comparison['phase_results'])}
    replacements['{{PARENT_BASELINE}}'] = ('Exact parent 3a full-workspace baseline: ' + json.dumps(independent['counts']) + '; ' + str(independent['integration_unexecuted_targets']) + ' integration targets unexecuted. Not a candidate baseline.' if args.parent_baseline else 'Parent baseline not included in this assembly; no candidate baseline verdict.')
    replacements['{{DIAGNOSTIC}}'] = ('Separate diagnostic '+diagnostic_summary['head']+': normal bootstrap0, default CoreEnv1 fuel failure, zero additional acceptance credit. All777 prior ordered labels and balances exactly match 0acd control. Across131 completed declarations, completed-tag -> definition-form totals5,243,100 units within definition_with_initializer. This includes guard/correspondence/planning/recipe work, not established cloning-only cost. Full2988 source closure and initial-symbolic-binding correction history are retained.' if diagnostic_summary else 'Separate tail diagnostic not included; no extra diagnostic test credit.')
    replacements['{{PARENT_CI}}'] = ('Exact parent0acd CI39064392448 terminal FAILURE: foundation528 Rust pass/0 fail/1 ignored and351 Python; integration111 pass/14 same3a failures;30 of255 targets completed,225 unexecuted; all10 logs and9 checkout proofs retained. This is not candidate CI.' if parent_ci_summary else 'No candidate CI verdict; parent CI not included.')
    def render(name):
        text = (HERE / name).read_text()
        for before, after in replacements.items(): text = text.replace(before, after)
        return text
    report = render('evidence.proposed.md')
    (HERE/'evidence.ready.md').write_text(report)
    for name in ['handoff', 'prbody']:
        (HERE / (name + '.ready.md')).write_text(render(name + '.proposed.md'))
    (stage/'REPORT.md').write_text(report)
    manifest={f.relative_to(stage).as_posix():{'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size}
              for f in sorted(stage.rglob('*')) if f.is_file()}
    (stage/'MANIFEST.json').write_text(json.dumps({'payloads':manifest,'payload_count':len(manifest),
        'source_commit':args.source_commit,'dependencies':dependencies},indent=2)+'\n')
    archive=HERE/'m4-borrowed-metadata-validation-2026-10-17.tar.gz'
    assert not archive.exists()
    with archive.open('wb') as output, gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for file in sorted(stage.rglob('*')):
                if not file.is_file():continue
                raw=file.read_bytes();info=tarfile.TarInfo(file.relative_to(stage).as_posix());info.size=len(raw);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(raw))
    result={'archive':str(archive),'sha256':sha(archive.read_bytes()),'members':len(manifest)+1,'manifested_payloads':len(manifest),
            'source_commit':args.source_commit,'unique_by_selected_name':unique,'dependencies':dependencies,
            'publication':'CACHE ONLY: requires independent archive/report/handoff review; no repository mutation'}
    (HERE/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__': main()
