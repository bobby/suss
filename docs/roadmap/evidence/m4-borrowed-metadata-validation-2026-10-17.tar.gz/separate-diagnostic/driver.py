from pathlib import Path
import fcntl,hashlib,json,os,re,shutil,subprocess,time
C=Path(__file__).parent
ROOT=Path('/home/bobby/Work/code/bobby/suss-m4-unboxed-bitwise-ssa')
TARGET=C/'memo-proof-cost-target'
RUN=C/'declaration-tail-default-diagnostic'
GRAPH='crates/suss-compile/src/portable_macro_graph.rs'
BASE='0acd17f9a59f14ac64e2bebd9770a75424a99cda'
BOOT={f'runtime/bootstrap/{p}.{e}' for p in ('macro','runtime') for e in ('wasm','json')}
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE
assert not git('ls-files','-u')
seed=json.loads((C/'hir-projection-focused-v5/terminal-freeze.json').read_text());assert len(seed)==2988
paths=sorted(seed);freeze=lambda:{n:sha((ROOT/n).read_bytes()) for n in paths}
expected=freeze();assert {n for n in paths if expected[n]!=seed[n]}=={GRAPH}
assert git('-C','clojurescript','rev-parse','HEAD').decode().strip()=='c4295f303100bbf5afac449242d30bca1126f1a1'
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:env=(proc/'environ').read_bytes();exe=str((proc/'exe').resolve())
 except OSError:continue
 assert b'CARGO_TARGET_DIR='+str(TARGET).encode()+b'\0' not in env and not exe.startswith(str(TARGET)+'/'),('Target occupied',proc.name)
leases=[]
for name in ['.typed-scalar-witness.lease','.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease']:
 f=open(TARGET/name,'a+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
RUN.mkdir(exist_ok=False);(RUN/'input-blobs').mkdir();shutil.copyfile(__file__,RUN/'driver.py')
(RUN/'candidate.patch').write_bytes(git('diff','--',GRAPH));dump(RUN/'source-packet.json',{'base':BASE,'files':{GRAPH:expected[GRAPH]},'patch_sha256':sha((RUN/'candidate.patch').read_bytes()),'scope':'Eight existing-gate read-only stage labels; no operation/rate/cap change; source reviewed by Carver before launch.'})
def snapshot(label):
 dump(RUN/(label+'-freeze.json'),expected)
 for n,h in expected.items():
  p=RUN/'input-blobs'/h
  if not p.exists():p.write_bytes((ROOT/n).read_bytes())
  assert sha(p.read_bytes())==h
snapshot('before')
state={'driver_pid':os.getpid(),'base':BASE,'branch':git('branch','--show-current').decode().strip(),'input_count':len(paths),'current':None,'stages':[],'limits':'Single unchanged default CoreEnv diagnostic. No unique acceptance credit. Native adjacent intervals only; no whole-cost/cloning inference. Jobs1/Rayon1, inherited RUSTFLAGS. Separate from borrowed-guard preservation.'}
save=lambda:dump(RUN/'receipt.json',state)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
for k in list(env):
 if k.startswith('SUSS_') and (k.endswith('TRACE') or 'CAPTURE' in k):env.pop(k)
core='compiled_macro_core_namespace_keeps_complete_declaration_records'
stages=[('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('core-env',['cargo','test','--locked','-p','suss-cli','--test','compiled_macro_core_environment',core,'--','--exact','--test-threads=1','--nocapture'])]
save()
try:
 for name,command in stages:
  assert freeze()==expected
  row={'name':name,'command':command};state['stages'].append(row);state['current']=name;save();start=time.monotonic();stageenv=env.copy()
  if name=='core-env':stageenv.update(SUSS_METADATA_FUEL_TRACE='1',SUSS_MACRO_FUEL_TRACE='1')
  with (RUN/(name+'.log')).open('w') as output:
   p=subprocess.Popen(command,cwd=ROOT,env=stageenv,stdout=output,stderr=subprocess.STDOUT);row['pid']=p.pid;save();code=p.wait()
  current=freeze();changed=[n for n in paths if current[n]!=expected[n]];row.update(exit=code,seconds=time.monotonic()-start,changed=changed);save()
  if name=='bootstrap':
   assert code==0 and set(changed)<=BOOT;expected=current;snapshot('after-bootstrap')
  else:
   assert not changed
   text=(RUN/'core-env.log').read_text();summaries=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
   assert len(summaries)==1 and list(map(int,summaries[0])) in ([0,1,0],[1,0,0]);assert f'test {core} ...' in text
   row['pass'],row['fail'],row['ignore']=map(int,summaries[0]);assert (code==0)==(row['fail']==0) and code in (0,101)
   row['extra_unique_coverage']=0;save()
except BaseException as e:state['anomaly']=repr(e);save();raise
finally:
 current=freeze();state['current']=None;state['final_changed']=[n for n in paths if current[n]!=expected[n]];save()
 if not state['final_changed']:snapshot('terminal')
