import pathlib,json,re,hashlib,subprocess
C=pathlib.Path('/home/bobby/.cache/suss-m4-work');R=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');N=C/'compact-snapshot-atoms-v1';O=C/'snapshot-owned-type-v1';sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((N/'receipt.json').read_text());assert len(r)==7 and all(not x['changed'] for x in r);assert [x['exit'] for x in r]==[0,0,0,0,101,101,101];names=[];st=[]
for n in ['atom-bits','snapshots','source-child','coherent-guards','callable','namespace']:
 s=(N/(n+'.log')).read_text();counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',s);assert len(counts)==1;ns=re.findall(r'^test (\S+) \.\.\.',s,re.M);assert len(ns)==sum(map(int,counts[0]));names+=ns;st.append({'name':n,'counts':list(map(int,counts[0]))})
assert len(names)==43 and len(set(names))==42;assert [x['counts'] for x in st]==[[1,0,0],[21,0,0],[1,0,0],[12,6,0],[0,1,0],[0,1,0]]
assert len(json.loads((N/'before-hashes.json').read_text()))==3662
binding=json.loads((N/'rejected-source-binding.json').read_text());assert len(binding['files'])==5
for p,h in binding['files'].items():assert sha((N/'rejected-source'/p).read_bytes())==h
# Recompute all completed49 intervals individually, not just summed totals.
def completed(p):
 runs=[];r=None;pending=None
 for l in p.open():
  m=re.search(r'coherent-stage stage=([\w-]+) boundary=(None|Some\(\d+\)).*remaining=Some\((\d+)\)',l)
  if not m:continue
  s,b,n=m.groups();n=int(n)
  if s=='entry':r={'completed':[],'last':None};runs.append(r);pending=None
  if r is None:continue
  r['last']=[s,b,n]
  if s=='construct-before':assert pending is None;pending=(b,n)
  if s=='construct-after':assert pending and pending[0]==b;r['completed'].append([b,pending[1]-n]);pending=None
 return runs
old=completed(C/'boxed-construction-facts-v1/callable.log');neg=completed(N/'callable.log');assert len(old)==len(neg)==6
for a,b in zip(old,neg):assert len(b['completed'])==49 and a['completed']==b['completed'] and b['last'][:2]==['construct-before','Some(1)']
negtext=(N/'atom-bits.log').read_text();assert re.search(r'snapshot-atom-layout size=48 align=8 snapshot=80',negtext)
for directory in [N,O]:
 s=(directory/'coherent-guards.log').read_text();panic=list(re.finditer(r"thread '(.*?)'.*?panicked at .*?coherent_tests.rs:(\d+):",s));assert len(panic)==6
 locs={int(x[2]) for x in panic};assert locs=={80,148,372,595,1332,1450}
 for i,m in enumerate(panic):assert 'all fuel consumed' in s[m.end():panic[i+1].start() if i+1<len(panic) else len(s)]
# Verify the actual source at ORIGINAL failure lines, rather than interpreting later assertions.
for ln in [1332,1450]:assert 'graph.materialize_using(root, &bridge).unwrap()' in (R/'crates/suss-compile/src/portable_macro_graph/source_roots/coherent_tests.rs').read_text().splitlines()[ln-1]
head=json.loads((O/'source-head.json').read_text());assert head['head']=='a504e95f57dec0d3f1d58bbdb1ea943a8148fa17' and len(head['files'])==5
for p,h in head['files'].items():assert sha(subprocess.check_output(['git','show',head['head']+':'+p],cwd=R))==h
reports=['m4-pr268-010e-terminal-ci-2026-10-18.md','m4-rejected-atom-layout-2026-10-18.md','m4-snapshot-owned-types-2026-10-18.md'];reporthash={n:sha((R/'docs/roadmap/evidence'/n).read_bytes()) for n in reports}
o={'verdict':'APPROVED_THREE_REPORTS_AND_HANDOFF_FOR_EVIDENCE_PACKAGING','report_sha256':reporthash,'handoff_sha256':sha((R/'docs/roadmap/handoff.md').read_bytes()),'ci_reference':'pr268-010e-ci/independent-review.json: actual010checkout9/foundation541PASS1ignore353Python/integrations111PASS14fuelFAIL/same14stage_span/30of259targets229unexecuted. No broad regression-free claim.','rejected_atom_trial':{'unique':42,'pass':34,'fuel_fail':8,'ignored':0,'standalone_overlaps_snapshot21':True,'actual_frozen_tracked_count':3662,'five_archived_dirty_source_bootstrap_hashes_exact':True,'all49individual_intervals_exact_boxedcontrol_six_requests':True,'layout':'Atom48 align8 Snapshot80; no saving','V128_specific_fee_cuts':'UNEXECUTED','disposition':'Rejected, no adoption; source variant preserved by base/patch/hash rather than invented testedcommit.'},'owned_node_candidate':{'source_head_json_exact_git5':head['head'],'terminal_review':'snapshot-owned-type-v1/terminal-review.json','unique':42,'pass':34,'fuel_fail':8,'ignored':0,'matched49removed_range':[210422,215421],'completed51_then_boundary26':'No export/finalization reached.'},'guard_failure_raw_classification':{'both_source_variants':'6fuelpanic locations80/148/372/595/1332/1450 checked from raw, not inferred false assertions.','four':'Initial build/materialization fails before later guard/poison/identity assertions.','two':'Source lines1332/1450 are ORIGINALgraph.materialize_using branches; coherent/effect comparison unexecuted.'},'scope_limits':['CI010production, rejectedAtomdirtyvariant, ownedNodea504 are separate tuples, not additive acceptance or production adoption.','No new oracle/fullbaseline/finalheadCIpass/issueclosure/promotion/merge.','Archive/member hashes and final documentation commit still require review after packaging.'],'reviewer_actions':'Read-only raw/current source and Git inspection; host cache parser/receipt only, no Cargo/source edits.'};(O/'reports-review.json').write_text(json.dumps(o,indent=2)+'\n');terminal=json.loads((O/'terminal-review.json').read_text());terminal['final_reports_review']='reports-review.json';terminal['source_head_json_now_present_and_verified']=head;terminal['report_sha256']=reporthash; (O/'terminal-review.json').write_text(json.dumps(terminal,indent=2)+'\n');(N/'terminal-review.json').write_text(json.dumps({'verdict':'VERIFIED_REJECTED_TRIAL_NEGATIVE_EVIDENCE','details':o['rejected_atom_trial'],'raw_stages':st,'guard_failures':o['guard_failure_raw_classification'],'reports_review':'snapshot-owned-type-v1/reports-review.json'},indent=2)+'\n');print(O/'reports-review.json');print(O/'terminal-review.json')
