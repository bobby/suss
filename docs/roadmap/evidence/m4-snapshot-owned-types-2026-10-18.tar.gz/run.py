import os,pathlib,subprocess as s,json,time,hashlib
p=pathlib.Path(__file__).parent;env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
rows=[]
def freeze():
 return {f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest() for f in s.check_output(['git','ls-files'],text=True).splitlines() if pathlib.Path(f).is_file()}
start=freeze();(p/'before-hashes.json').write_text(json.dumps(start,indent=2)+'\n');(p/'source.patch').write_bytes(s.check_output(['git','diff','--binary']))
commands=[('identity',['python3','scripts/verify_bootstrap_identity.py']),('owned-types',['cargo','test','--locked','-p','suss-compile','--lib','native_storage_snapshot_owned_nodes_survive_external_type_and_module_drop','--','--test-threads=1','--nocapture']),('snapshots',['cargo','test','--locked','-p','suss-compile','--lib','storage_snapshot::tests::','--','--test-threads=1','--nocapture']),('source-child',['cargo','test','--locked','-p','suss-compile','--lib','source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo','--','--test-threads=1','--nocapture']),('coherent-guards',['cargo','test','--locked','-p','suss-compile','--lib','--','source_roots::coherent::tests::','legacy_cache_retirement_is_atomic_and_not_sustained_by_its_own_native_references','--test-threads=1','--nocapture']),('callable',['cargo','test','--locked','-p','suss-cli','--test','compiled_macro_namespace_identity','resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations','--','--exact','--test-threads=1','--nocapture']),('namespace',['cargo','test','--locked','-p','suss-cli','--test','compiled_macro_namespace_identity','compiler_namespace_and_declaration_aliases_match_pinned_five_call_observations','--','--exact','--test-threads=1','--nocapture'])]
for name,cmd in commands:
 runenv=env.copy()
 if name in ['callable','namespace']:runenv.update(SUSS_METADATA_FUEL_TRACE='1',SUSS_NAMESPACE_IDENTITY_OUTPUT=str(p/(name+'.json')))
 t=time.time()
 with (p/(name+'.log')).open('w') as f:r=s.run(cmd,env=runenv,stdout=f,stderr=s.STDOUT)
 now=freeze();row=dict(name=name,argv=cmd,exit=r.returncode,seconds=time.time()-t,changed=[f for f,h in start.items() if now.get(f)!=h]);rows.append(row);(p/'receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,'changed',row['changed'],flush=True)
 if row['changed'] or (name in ['identity','owned-types','snapshots','source-child'] and r.returncode):break
