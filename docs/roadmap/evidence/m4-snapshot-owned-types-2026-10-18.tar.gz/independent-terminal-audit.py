import pathlib,json,re,hashlib
P=pathlib.Path(__file__).parent;C=P.parent;R=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');sha=lambda b:hashlib.sha256(b).hexdigest();receipt=json.loads((P/'receipt.json').read_text());assert len(receipt)==7 and [x['exit'] for x in receipt]==[0,0,0,0,101,101,101] and all(not x['changed'] for x in receipt)
names=[];stages=[]
for n in ['owned-types','snapshots','source-child','coherent-guards','callable','namespace']:
 s=(P/(n+'.log')).read_text();cs=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',s);assert len(cs)==1;ns=re.findall(r'^test (\S+) \.\.\.',s,re.M);assert len(set(ns))==sum(map(int,cs[0]));stages.append({'name':n,'counts':list(map(int,cs[0])),'names':ns,'sha256':sha(s.encode())});names+=ns
assert len(names)==43 and len(set(names))==42
oldguards=(C/'shared-native-witness-acceptance-v1/guards.log').read_text();newguards=(P/'coherent-guards.log').read_text();failed=lambda s:set(re.findall(r'^    (portable_macro_graph::\S+)$',s,re.M));assert failed(oldguards)==failed(newguards) and len(failed(newguards))==6
for f in ['callable.json','namespace.json']:
 obj=json.loads((P/f).read_text());assert len(obj['phases'])==2
 if f.startswith('callable'):
  for ph in obj['phases']:assert not ph['observations']['rows'] and len(ph['observations']['errors'])==3 and all('caller &env input transport' in x['error'] and 'all fuel consumed' in x['error'] for x in ph['observations']['errors'])
 else:
  for ph in obj['phases']:assert '46..82' in ph['error'] and 'all fuel consumed' in ph['error'] and isinstance(ph['rows'],str)
def parse(p):
 out=[];r=None;pending=None
 for l in p.open():
  m=re.search(r'coherent-stage stage=([\w-]+) boundary=(None|Some\(\d+\)).*remaining=Some\((\d+)\)',l)
  if not m:continue
  st,b,n=m.groups();n=int(n)
  if st=='entry':r={'completed':[],'markers':[]};out.append(r);pending=None
  if r is None:continue
  r['markers'].append([st,b,n])
  if st=='construct-before':assert pending is None;pending=(b,n)
  if st=='construct-after':assert pending and pending[0]==b;r['completed'].append((b,pending[1]-n));pending=None
 return out
old=parse(C/'boxed-construction-facts-v1/callable.log');new=parse(P/'callable.log');assert len(old)==len(new)==6;expected=json.loads((P/'public-prefix-comparison.json').read_text());rows=[]
for i,(a,b) in enumerate(zip(old,new)):
 assert len(a['completed'])==49 and len(b['completed'])==51;assert [x[0] for x in a['completed']]==[x[0] for x in b['completed'][:49]];x=sum(t[1] for t in a['completed']);y=sum(t[1] for t in b['completed'][:49]);assert x==expected[i]['old_prefix_units'] and y==expected[i]['new_prefix_units'];assert b['markers'][-1][:2]==['construct-before','Some(26)'];assert not any(m[0].startswith(('finalize','postcallback-recheck')) for m in b['markers']);rows.append({'old_matched49':x,'new_matched49':y,'removed':x-y,'new_completed':51,'last_marker':b['markers'][-1]})
before=json.loads((P/'before-hashes.json').read_text());assert len(before)==3662;changed=[n for n,h in before.items() if not (R/n).is_file() or sha((R/n).read_bytes())!=h];sr=json.loads((P/'source-review.json').read_text());assert sha((R/sr['path']).read_bytes())==sr['source_sha256'];layout=re.search(r'snapshot-owned-layout Node=(\d+) Contents=(\d+) Snapshot=(\d+) Atom=(\d+)',(P/'owned-types.log').read_text());assert list(map(int,layout.groups()))==[88,32,80,48]
o={'verdict':'VERIFIED_TERMINAL_CANDIDATE_RESULTS_AND_MATCHED_COMPLETED_PREFIX_ONLY','terminal_receipt_all_seven_stages_complete':True,'counts':{'unique':42,'pass':34,'fuel_fail':8,'ignored':0,'executions_with_owned_test_repeat':43},'stages':stages,'source_hash_exact_final_review':sr['source_sha256'],'during_candidate_pre_run_tracked_files':len(before),'all_stage_changed_empty':True,'current_mismatches':changed,'layout':{'Node':88,'Contents':32,'StorageSnapshot':80,'Atom':48,'old_Node_reported':136,'old_Node_status':'Historical layout supplied by root; no new old-layout measurement run.'},'comparison':rows,'guard_failed_names':sorted(failed(newguards)),'guard_classification':'Same six names as historical shared-witness cohort. Four fail initial materialize/build before later guard assertions. Reader-before-every-alias and repeated-locals fail ORIGINALgraph.materialize_using branches1450/1332; coherent/effect comparison unexecuted. No callback control success inferred. Legacyretirement passes.','public_classification':'Both selected tests fuelFAIL: callable six errors/zero decoded rows; namespace firstlexical46..82 bothphases, later rows unexecuted.','limits':['Snapshot21 includes standaloneowned1; do not sum as22unique snapshot tests.','Matched49completed constructor intervals remove210422..215421chargedunits;51nowcomplete beforeboundary26fuel, no finalization. Unknown whole required request cost; not publiccriterion pass.','Candidate coherent source separate from production010CI, no adoption/promotion/closure/fullbaseline/oracleCI success.','Freeze covers tracked regularfiles, not expanded oracle/untracked closure. No independent process-drain proof beyond complete finalstage receipt and terminal logs.'],'reviewer_actions':'Read-only rawlogs/currenthash audit; cache parser/receipt only, no Cargo/source edits.'};(P/'terminal-review.json').write_text(json.dumps(o,indent=2)+'\n');print(P/'terminal-review.json');print(changed);print([x['removed'] for x in rows])
