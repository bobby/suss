from pathlib import Path
import json,re,subprocess,hashlib,tarfile
c=Path('/home/bobby/.cache/suss-m4-work');root=Path('/home/bobby/Work/code/bobby/suss');run=json.loads((c/'ci9f-run.json').read_text());assert run['status']=='completed' and run['conclusion']=='failure'
summary={'run':38871958298,'head':run['headSha'],'jobs':[],'failures':[],'limits':['Rust counts are executions per job, not unique tests across overlapping foundation/integration checks.','Each integration partition stops at its first failing target; remaining planned targets are unexecuted.','No passing-prefix or foundation result makes the complete workflow green.']}
for j in run['jobs']:
 raw=c/('ci9f-job-'+str(j['databaseId'])+'-raw.log')
 if not raw.exists():
  with raw.open('wb') as f:subprocess.run(['gh','api',f"repos/bobby/suss/actions/jobs/{j['databaseId']}/logs",'--allow-escape-sequences'],stdout=f,check=True)
 text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.read_text(errors='replace'));clean=c/('ci9f-job-'+str(j['databaseId'])+'-clean.log');clean.write_text(text)
 counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 failures=re.findall(r'\btest (\S+) \.\.\. FAILED',text);panics=list(re.finditer(r"thread '([^']+)'[^\n]*panicked at",text));causes={}
 for n,m in enumerate(panics):
  block=text[m.start():panics[n+1].start() if n+1<len(panics) else len(text)]
  causes[m[1]]='fuel-exhaustion' if 'all fuel consumed' in block or 'out of fuel' in block.lower() else ('metadata-identity' if m[1]=='source_metadata_keeps_identity_with_a_replaced_hash_method' else 'unclassified')
 entry={'name':j['name'],'job':j['databaseId'],'status':j['status'],'conclusion':j['conclusion'],'rust_suites_completed':len(counts),'rust_pass_executions':sum(int(v[0]) for v in counts),'rust_fail_executions':sum(int(v[1]) for v in counts),'rust_ignored_executions':sum(int(v[2]) for v in counts),'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}
 for name in failures:summary['failures'].append({'job':j['databaseId'],'test':name,'cause':causes.get(name,'unclassified')})
 if j['name'].startswith('integration ('):
  line=next(l for l in text.splitlines() if '{"index":' in l);plan=json.loads(line[line.index('{"index":'):]);targets=[{'package':p,'target':n,'status':'not-executed'} for p,n in plan['targets']]
  for line in text.splitlines():
   m=re.search(r'\bRunning tests/[^ ]+ \(([^)]+)\)',line)
   if m:
    stem=m[1].rsplit('/',1)[-1].rsplit('-',1)[0];matching=[t for t in targets if t['target'].replace('-','_')==stem];assert len(matching)==1,(stem,matching);matching[0]['status']='executed'
  entry.update(targets=targets,planned=len(targets),executed=sum(t['status']=='executed' for t in targets),unexecuted=sum(t['status']=='not-executed' for t in targets))
 summary['jobs'].append(entry)
summary['prior_ci_failure_names_match'] = {f['test'] for f in summary['failures']} == {f['test'] for f in json.loads((c/'ci209-classification.json').read_text())['failures']}
comparison=json.loads((c/'raw-heads-failure-comparison.json').read_text());known=set(comparison['declarations']['current-failed']+comparison['broad']['current-failed']);summary['additional_fuel_regressions']=[f['test'] for f in summary['failures'] if f['cause']=='fuel-exhaustion' and f['test'] not in known]
prior=root/'docs/compatibility/caching-hash-callable/baseline-exclusive-2026-10-15.tar.gz'
with tarfile.open(prior) as t:priorlog=t.extractfile('raw/full-workspace.log').read()
(c/'ci9f-prior-main-full-workspace.log').write_bytes(priorlog)
for name in summary['additional_fuel_regressions']:assert ('test '+name+' ... ok') in priorlog.decode()
summary['combined_known_fuel_failure_count']=len(known|{f['test'] for f in summary['failures'] if f['cause']=='fuel-exhaustion'})
summary['combined_known_identity_failure_count']=1
(c/'ci9f-classification.json').write_text(json.dumps(summary,indent=2)+'\n')
print('CI failed tests',len(summary['failures']),'additional regressions',len(summary['additional_fuel_regressions']),'combined fuel',summary['combined_known_fuel_failure_count']);print('partition targets',sum(j.get('planned',0) for j in summary['jobs']),'executed',sum(j.get('executed',0) for j in summary['jobs']),'unexecuted',sum(j.get('unexecuted',0) for j in summary['jobs']))
