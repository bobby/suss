from pathlib import Path
import subprocess as s,os,json,time,hashlib
root=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');p=Path(__file__).parent
r=json.loads((p/'receipt.json').read_text());assert r['terminal']
m=json.loads((p/'run-manifest.json').read_text());assert all(hashlib.sha256((root/f).read_bytes()).hexdigest()==h for f,h in m.items())
argv=['cargo','test','--locked','-p','suss-cli','--test','compiled_macro_initializer_plan','definition_initializer_plan_preserves_metadata_quote_barriers_and_source_values','--','--exact','--test-threads=1','--nocapture']
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
x={'terminal':False,'argv':argv};(p/'initializer-receipt.json').write_text(json.dumps(x,indent=2)+'\n');start=time.monotonic()
with (p/'initializer.log').open('w') as log:
 child=s.Popen(argv,cwd=root,env=env,stdout=log,stderr=s.STDOUT);x['pid']=child.pid;(p/'initializer-receipt.json').write_text(json.dumps(x,indent=2)+'\n');code=child.wait()
x.update(terminal=True,exit=code,seconds=time.monotonic()-start,changed=[f for f,h in m.items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h]);assert not x['changed'];(p/'initializer-receipt.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x),flush=True)
