from pathlib import Path
import json,re,collections,subprocess,hashlib
p=Path(__file__).resolve().parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');receipt=json.loads((p/'receipt.json').read_text());assert receipt['terminal'] and receipt['current'] is None and not receipt['unexecuted']
head=subprocess.check_output(['git','-C',str(r),'rev-parse','4e21'],text=True).strip();manifest=json.loads((p/'run-manifest.json').read_text())
# Batch Git objects: each frozen tracked file resolved against exact tested commit.
paths=list(manifest);proc=subprocess.run(['git','-C',str(r),'cat-file','--batch'],input=''.join(head+':'+x+'\n' for x in paths).encode(),stdout=subprocess.PIPE,check=True);data=proc.stdout;offset=0;different=[]
for path in paths:
 end=data.index(b'\n',offset);header=data[offset:end].split();assert header[1]==b'blob',(path,header);size=int(header[2]);blob=data[end+1:end+1+size];offset=end+size+2
 if hashlib.sha256(blob).hexdigest()!=manifest[path]:different.append(path)
assert not different,different
rows=[];names=collections.defaultdict(list);targets=collections.defaultdict(set);totals=collections.Counter()
for stage in receipt['stages']:
 assert not stage['changed'];text=(p/(stage['name']+'.log')).read_text();starts=re.findall(r'^test (\S+) \.\.\.',text,re.M);summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 if stage['name']=='identity':assert stage['exit']==0;continue
 assert len(summaries)==1;_,passed,failed,ignored=summaries[0];passed,failed,ignored=map(int,(passed,failed,ignored));assert len(starts)==passed+failed+ignored
 argv=stage['argv'];target=argv[argv.index('--test')+1] if '--test' in argv else 'suss-compile::lib'
 failures=re.findall(r"thread '([^']+)' .*?panicked at ([^\n]+)",text);assert len(failures)==failed
 for n in starts:names[n].append(stage['name']);targets[n].add(target)
 totals.update(passed=passed,failed=failed,ignored=ignored,executions=len(starts))
 rows.append({'stage':stage['name'],'target':target,'pass':passed,'fail':failed,'ignored':ignored,'names':starts,'failures':[{'name':n,'panic':at} for n,at in failures]})
# Same name in separate targets is a separate execution, but same source-module definition is not extra coverage.
repeats={n:stages for n,stages in names.items() if len(stages)>1}
result={'verdict':'PRESERVATION_TERMINAL_WITH_EIGHT_FUEL_FAILURES_INITIALIZER_PENDING','source':head,'git_binding':{'frozen_files':len(paths),'all_match_commit':True},'per_target_stage_results':rows,'execution_totals':dict(totals),'distinct_full_names':len(names),'repeat_full_names':repeats,'names_in_multiple_targets':{n:sorted(t) for n,t in targets.items() if len(t)>1},'source_definition_union':{'count':len(names),'basis':'All actual full names inspected; core_import has no portable_decode::adversarial_owner executions, so no extra shared-decoder subtraction for that target. One exact coherent definition repeated across strict and full selections.','shared_decoder_definitions_executed':3},'unexecuted_main_stages':[],'initializer':'PENDING_SEPARATE_TERMINAL_REVIEW','limits':['Counts cover this preservation runner only, not earlier snapshot/callable runs, future initializer, CI or whole workspace.','fresh-proof filter executed ONE test, not two.','Public two and six coherent failures remain; no identity/acceptance/readiness claim.','Historical SourceChild/callable repeats must be deduplicated if combining this run with initial validation.']}
(p/'independent-terminal-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['source','git_binding','execution_totals','distinct_full_names','repeat_full_names','names_in_multiple_targets']},indent=2))
