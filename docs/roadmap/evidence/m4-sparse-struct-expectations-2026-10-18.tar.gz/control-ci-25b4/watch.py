from pathlib import Path
import subprocess,json,re,hashlib,time,datetime
p=Path(__file__).parent;rid=39129238646;head='25b4a57cbfec7f9047f4afb1f5d0b06b5114b00e'
base=json.loads((p.parent/'pr268-fd78441-ci/terminal-audit.json').read_text());bf={n:v for j in base['jobs'] for n,v in j['failed'].items()}
aca=json.loads((p.parent/'pr271-aca5899-ci/terminal-audit.json').read_text());af={n:v for j in aca['jobs'] for n,v in j.get('failed',{}).items()}
def api(route):return subprocess.check_output(['gh','api','--allow-escape-sequences','repos/bobby/suss/'+route],stderr=subprocess.PIPE)
def save(name,data):
 f=p/name;tmp=p/(name+'.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(f)
def commit(sha):
 f=p/f'git-commit-{sha}.json'
 if not f.exists():f.write_bytes(api('git/commits/'+sha))
 return json.loads(f.read_text())
while True:
 try:
  stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');run=json.loads(api(f'actions/runs/{rid}'));jobs=json.loads(api(f'actions/runs/{rid}/jobs?per_page=100'));assert run['head_sha']==head
  save('run-'+stamp+'.json',run);save('jobs-'+stamp+'.json',jobs);save('run-current.json',run);save('jobs-current.json',jobs)
  rows=[];fail={};plans=[];done=[];unfinished=[];tot=[0,0,0];manifest={};proofs=[]
  headtree=commit(head)['tree']['sha']
  for j in jobs['jobs']:
   row={k:j.get(k) for k in ['id','name','status','conclusion','started_at','completed_at']};f=p/f"{j['id']}.log"
   if j['status']=='completed' and not f.exists():f.write_bytes(api(f"actions/jobs/{j['id']}/logs"))
   if f.exists():
    raw=f.read_bytes();manifest[f.name]=hashlib.sha256(raw).hexdigest();t=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.decode('utf-8-sig'));t=re.sub(r'^\S+Z ?', '',t,flags=re.M)
    summaries=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)]
    row['execution_counts']=[sum(x[i] for x in summaries) for i in range(3)];row['summaries']=len(summaries)
    fs={};chunks=re.split(r'^---- (.*?) stdout ----\s*$',t,flags=re.M)
    for i in range(1,len(chunks),2):
     name,body=chunks[i:i+2];diag=next((l for l in body.splitlines() if 'Compiled macro expansion failed during ' in l),None)
     s=re.search(r'Compiled macro expansion failed during ([^:]+):',diag or '');sp=re.search(r'span:\s*(\d+\.\.\d+)',diag or '')
     panic=next((l for l in body.splitlines() if 'panicked at ' in l),None)
     fs[name]={'stage':s[1] if s else None,'span':sp[1] if sp else None,'fuel':('all fuel consumed' in (diag or body)),'panic':panic,'diagnostic':diag}
    row['failed']=fs;fail.update(fs);row['compile_errors']=re.findall(r'^error(?:\[E\d+\])?:.*$',t,re.M)
    shas=re.findall(r'^\[command\].*git log -1 --format=%H\n([a-f0-9]{40})\s*$',t,re.M);row['checkout_proofs']=[]
    for sha in shas:
     c=commit(sha);pr={'checkout':sha,'tree':c['tree']['sha'],'candidate_tree':headtree,'same_commit':sha==head,'tree_equivalent':c['tree']['sha']==headtree,'parents':[x['sha'] for x in c['parents']]};row['checkout_proofs'].append(pr);proofs.append(pr)
    if j['name'].startswith('integration'):
     pl=next((l for l in t.splitlines() if l.startswith('{"index":') and '"targets"' in l),None)
     if pl:
      plan=json.loads(pl);plans.extend(map(tuple,plan['targets']));row['planned_targets']=plan['targets']
     starts=re.findall(r'Running tests/([^\s.]+)\.rs',t);row['started_targets']=starts
     # Cargo's sequential integration runner emits one summary per started binary.
     row['completed_targets']=starts[:len(summaries)];row['started_unfinished']=starts[len(summaries):];done+=row['completed_targets'];unfinished+=row['started_unfinished'];tot=[x+y for x,y in zip(tot,row['execution_counts'])]
    if j['name']=='foundation':
     row['python_execution_count']=sum(map(int,re.findall(r'^Ran (\d+) tests? in ',t,re.M)))
     row['step_outcomes']=[{k:s.get(k) for k in ['name','status','conclusion']} for s in j['steps']]
   rows.append(row)
  unexec=[list(x) for x in plans if x[1] not in set(done+unfinished)]
  comparison={n:{'previous':bf.get(n),'same_fuel_stage_span':n in bf and all(v[k]==bf[n][k] for k in ['stage','span','fuel'])} for n,v in fail.items()}
  report={'run':rid,'head':head,'event':run['event'],'status':run['status'],'conclusion':run['conclusion'],'observed_at_utc':stamp,'jobs':rows,'integration_executions':tot,'known_plan_targets':len(plans),'completed_targets':len(done),'started_unfinished':unfinished,'unexecuted_in_known_plans':unexec,'checkout_proof_count':len(proofs),'all_observed_checkout_trees_equal_candidate':all(x['tree_equivalent'] for x in proofs) if proofs else None,'failure_comparison_to_fd78441':comparison,'new_observed_failed_names':sorted(set(fail)-set(bf)),'previous_failures_not_observed_here':sorted(set(bf)-set(fail)),'limits':['Only downloaded terminal-job logs are classified; live jobs remain unknown.','Unexecuted inventory covers only shard plans present in retained logs, until all plans are available.','Completed summaries are executions, not distinct tests; interrupted binaries remain separate.','Tree equality verifies checkout source tree, not per-job post-checkout immutable inputs.','Matching observed failure labels is not broad regression absence, acceptance or full-baseline evidence.']}
  report['comparison_to_aca5899']={'head':aca['head'],'new_observed_failed_names':sorted(set(fail)-set(af)),'previous_failed_names_not_observed':sorted(set(af)-set(fail)),'failure_comparison':{n:{'previous':af.get(n),'same_fuel_stage_span':n in af and all(v[k]==af[n][k] for k in ['stage','span','fuel'])} for n,v in fail.items()}}
  prior_path=p.parent/'pr271-239a4aa-ci/terminal-audit.json'
  if prior_path.exists():
   prior=json.loads(prior_path.read_text());pf={n:v for j in prior['jobs'] for n,v in j.get('failed',{}).items()}
   report['comparison_to_239a4aa']={'head':prior['head'],'prior_status':prior['status'],'prior_observation':prior['observed_at_utc'],'observed_only':True,'new_failed_names':sorted(set(fail)-set(pf)),'prior_failed_names_not_observed':sorted(set(pf)-set(fail)),'failure_comparison':{n:{'previous':pf.get(n),'same_fuel_stage_span':n in pf and all(v[k]==pf[n][k] for k in ['stage','span','fuel'])} for n,v in fail.items()}}
  save('current-audit.json',report);save('raw-log-manifest.json',manifest)
  print(json.dumps({'at':stamp,'status':run['status'],'jobs':[(r['name'],r['status'],r['conclusion']) for r in rows],'counts':tot,'new_failures':report['new_observed_failed_names'],'proofs':len(proofs),'tree_equal':report['all_observed_checkout_trees_equal_candidate']}),flush=True)
  if run['status']=='completed' and all(j['status']=='completed' for j in jobs['jobs']):save('terminal-audit.json',report);save('run-terminal.json',run);save('jobs-terminal.json',jobs);break
 except Exception as e:
  with (p/'watch-errors.log').open('a') as f:f.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+' '+repr(e)+'\n')
  print('observation error '+repr(e),flush=True)
 time.sleep(30)
