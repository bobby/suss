from pathlib import Path
import os,json,hashlib,subprocess as s,time,datetime
root=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');out=Path(__file__).parent
head=s.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not s.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
files=s.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
manifest={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if (root/f).is_file()}
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
cmd=['cargo','test','--locked','-p','suss-cli','--test','compiled_macro_namespace_identity','resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations','--','--exact','--test-threads=1','--nocapture']
extra={'CARGO_TARGET_DIR':'/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target','CARGO_BUILD_JOBS':'1','RAYON_NUM_THREADS':'1','SUSS_METADATA_FUEL_TRACE':'1','SUSS_SOURCE_MATERIALIZE_FUEL_TRACE':'1','SUSS_NAMESPACE_IDENTITY_OUTPUT':str(out/'callable.json')}
env=os.environ.copy();env.update(extra);receipt={'source':head,'argv':cmd,'environment_overrides':extra,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal':False}
start=time.monotonic()
with (out/'callable.log').open('w') as log:
 child=s.Popen(cmd,cwd=root,env=env,stdout=log,stderr=s.STDOUT);receipt['pid']=child.pid;(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');code=child.wait()
receipt.update(terminal=True,exit=code,seconds=round(time.monotonic()-start,3),changed=[f for f,h in manifest.items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h])
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
