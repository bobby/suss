from pathlib import Path
import re,json,collections,hashlib
p=Path(__file__).resolve().parent
assert json.loads((p/'receipt.json').read_text()).get('terminal')
requests=[]; current=None;boundary=None;total=collections.defaultdict(lambda:collections.Counter())
pat=re.compile(r'source-snapshot-allocation type=(.*?) count=(\d+) element_bytes=(\d+) requested_bytes=(\d+)')
def add(dst,m):
 t,c,s,b=m.groups();c,s,b=map(int,(c,s,b));assert c*s==b
 x=dst[t];x['events']+=1;x['elements']+=c;x['requested_bytes']+=b;x['zero_count_events']+=int(c==0)
with (p/'callable.log').open() as f:
 for n,line in enumerate(f,1):
  if 'coherent-stage stage=entry ' in line:
   current={'entry_line':n,'boundaries':[]};requests.append(current);boundary=None
  if 'coherent-stage stage=construct-before ' in line:
   boundary={'id':int(re.search(r'boundary=Some\((\d+)\)',line)[1]),'complete':False,'allocations':collections.defaultdict(lambda:collections.Counter())};current['boundaries'].append(boundary)
  m=pat.search(line)
  if m:
   add(total,m)
   if boundary is not None:add(boundary['allocations'],m)
  if 'coherent-stage stage=construct-after ' in line:
   assert boundary is not None;boundary['complete']=True;boundary=None
result={'source':json.loads((p/'receipt.json').read_text())['source'],'whole_log_allocation_events':total,'requests':requests,'limits':['Requested backing allocation counts from emitted markers only, not retained bytes, live memory, or fuel.','Growth/repeated snapshots can repeat elements; counts are not unique objects/fields.','Failed boundary allocation markers describe only observed prefix.','These markers alone do not identify mutable versus immutable struct fields or establish removable work.']}
(p/'independent-allocations.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(total))
