from pathlib import Path
import re,json,collections
p=Path(__file__).parent
lines=(p/'callable.log').read_text().splitlines(); requests=[];current=None;block=None
fuel=lambda l:int(re.search(r'remaining=(?:Some\()?(\d+)',l)[1])
for i,line in enumerate(lines):
 if 'coherent-stage stage=entry ' in line:
  current={'entry_line':i,'entry_fuel':fuel(line),'boundaries':[]};requests.append(current)
 if 'coherent-stage stage=construct-before ' in line:
  block={'id':int(re.search(r'boundary=Some\((\d+)\)',line)[1]),'start_line':i,'start_fuel':fuel(line),'complete':False};current['boundaries'].append(block)
 if 'coherent-stage stage=construct-after ' in line:
  assert block is not None
  block.update(end_line=i,end_fuel=fuel(line),complete=True,cost=block['start_fuel']-fuel(line));block=None
for req in requests:
 for b in req['boundaries']:
  if not b['complete']:continue
  stacks=collections.defaultdict(list); sums=collections.Counter(); counts=collections.Counter();intervals=[];allocs=collections.Counter()
  for i in range(b['start_line'],b['end_line']+1):
   l=lines[i]
   if 'source-snapshot-allocation ' in l:
    m=re.search(r'type=(.*?) count=(\d+) element_bytes=(\d+) requested_bytes=(\d+)',l)
    if m:allocs[m[1]]+=int(m[4])
   m=re.search(r'source-materialize-call label=(\S+) event=(before|after)',l)
   if m:key='call:'+m[1];event=m[2]
   else:
    m=re.search(r'source-snapshot phase=(\S+) count=(\d+) event=(before|after)',l)
    if m:
     key='snapshot:'+m[1];event=m[3]
    else:
     m=re.search(r'source-domain domain=(\S+) staged=(\S+) phase=(\S+) event=(before|after)',l)
     if m:
      key='domain:'+m[3];event=m[4]
     else:
      m=re.search(r'source-domain-record domain=(\S+) fact=(\S+) phase=(\S+) event=(before|after)',l)
      if not m:continue
      key='record:'+m[2]+':'+m[3];event=m[4]
   if event=='before':stacks[key].append((i,fuel(l)))
   elif stacks[key]:
    start,before=stacks[key].pop();debit=before-fuel(l);sums[key]+=debit;counts[key]+=1;intervals.append({'label':key,'debit':debit,'start_line':start,'end_line':i})
  b['nested_inclusive_intervals_not_additive']=[{'label':key,'debit':v,'count':counts[key]} for key,v in sums.most_common()]
  b['snapshot_allocation_requested_bytes']=dict(allocs)
  b['largest_intervals']=sorted(intervals,key=lambda x:x['debit'],reverse=True)[:10]
  b['unclosed_intervals']={key:len(vals) for key,vals in stacks.items() if vals}
result={'source':json.loads((p/'receipt.json').read_text())['source'],'requests':requests,'limits':['Nested intervals are inclusive and overlap: do not add them.','Incomplete construction boundaries and later finalization/value observations remain unknown.','Trace-only unchanged budgets/source; not an acceptance pass.']}
(p/'partition.json').write_text(json.dumps(result,indent=2)+'\n')
for n,r in enumerate(requests):
 complete=[b for b in r['boundaries'] if b['complete']]
 if not complete:continue
 b=max(complete,key=lambda b:b['cost'])
 print('request',n,'completed',len(complete),'largest',b['id'],b['cost'],'calls',b['nested_inclusive_intervals_not_additive'][:7])
