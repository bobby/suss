"""Read current terminal trace only; no historical aggregates or runtime execution."""
from pathlib import Path
import collections, hashlib, json, re
p=Path(__file__).resolve().parent
receipt=json.loads((p/'receipt.json').read_text())
if not receipt.get('terminal'):
    raise SystemExit('WAIT: producer is not terminal; no analysis written')
log=p/'callable.log'; requests=[]; request=None; boundary=None; last_fuel=None
fuel_re=re.compile(r'remaining=(?:Some\()?(\d+)')
def marker(line):
    patterns=[('call',r'source-materialize-call label=(\S+) event=(before|after)'),
      ('snapshot',r'source-snapshot phase=(\S+) count=\d+ event=(before|after)'),
      ('domain',r'source-domain domain=\S+ staged=\S+ phase=(\S+) event=(before|after)'),
      ('record',r'source-domain-record domain=\S+ fact=(\S+) phase=(\S+) event=(before|after)')]
    for family,pattern in patterns:
        m=re.search(pattern,line)
        if m:return family, ':'.join(m.groups()[:-1]),m.groups()[-1]
def close_partial():
    if boundary is not None:
        observed=boundary.get('last_in_scope_fuel',boundary['start_fuel'])
        boundary['last_observed_fuel']=observed
        boundary['observed_prefix_debit']=boundary['start_fuel']-observed
        boundary['total_cost']=None
with log.open() as stream:
    for n,line in enumerate(stream,1):
        fm=fuel_re.search(line)
        if fm:last_fuel=int(fm[1])
        if boundary is not None and fm and 'coherent-stage stage=entry ' not in line:
            prior=boundary.get('last_in_scope_fuel',boundary['start_fuel'])
            if last_fuel<=prior and not boundary.get('post_failure_fuel_reset'):
                boundary['last_in_scope_fuel']=last_fuel
            elif last_fuel>prior:
                boundary['post_failure_fuel_reset']=True
        if 'coherent-stage stage=entry ' in line:
            close_partial()
            request={'entry_line':n,'entry_fuel':last_fuel,'boundaries':[]}; requests.append(request);boundary=None
        if 'coherent-stage stage=construct-before ' in line:
            assert request is not None and boundary is None, ('unexpected construction start',n)
            bid=re.search(r'boundary=Some\((\d+)\)',line)
            boundary={'id':int(bid[1]),'start_line':n,'start_fuel':last_fuel,'complete':False,'intervals':[],'open':collections.defaultdict(list)}
            request['boundaries'].append(boundary)
        if boundary is not None:
            m=marker(line)
            if m and fm:
                family,key,event=m; stack=boundary['open'][(family,key)]
                if event=='before':stack.append((n,last_fuel))
                else:
                    assert stack, ('unmatched end',n,family,key)
                    start,before=stack.pop(); debit=before-last_fuel
                    assert debit>=0, ('fuel increased within interval',n)
                    boundary['intervals'].append({'family':family,'label':key,'start_line':start,'end_line':n,'inclusive_debit':debit})
        if 'coherent-stage stage=construct-after ' in line:
            assert boundary is not None
            boundary.update(complete=True,end_line=n,end_fuel=last_fuel,total_cost=boundary['start_fuel']-last_fuel);boundary=None
close_partial()
for request in requests:
    sums=collections.Counter(); counts=collections.Counter()
    for b in request['boundaries']:
        intervals=b.pop('intervals'); opened=b.pop('open')
        b['unclosed_intervals']={f+':'+k:len(v) for (f,k),v in opened.items() if v}
        inclusive=collections.Counter(); exclusive=collections.Counter()
        family_stacks=collections.defaultdict(list)
        children_debits=collections.Counter()
        for x in sorted(intervals,key=lambda x:x['start_line']):
            stack=family_stacks[x['family']]
            while stack and x['start_line']>stack[-1]['end_line']:stack.pop()
            if stack:
                assert x['end_line']<stack[-1]['end_line'], 'crossing trace intervals'
                children_debits[stack[-1]['start_line']]+=x['inclusive_debit']
            stack.append(x)
        for x in intervals:
            exclusive_debit=x['inclusive_debit']-children_debits[x['start_line']]
            assert exclusive_debit>=0
            key=x['family']+':'+x['label'];inclusive[key]+=x['inclusive_debit'];exclusive[key]+=exclusive_debit
            if b['complete'] and x['family']=='call':sums[x['label']]+=exclusive_debit;counts[x['label']]+=1
        b['inclusive_nested_not_additive']=dict(inclusive)
        b['exclusive_within_family_only']=dict(exclusive)
    complete=[b for b in request['boundaries'] if b['complete']]
    request['completed_count']=len(complete)
    request['completed_construction_inclusive_debit']=sum(b['total_cost'] for b in complete)
    request['disjoint_completed_call_exclusive_debit']=dict(sums)
    request['completed_call_counts']=dict(counts)
    request['unattributed_completed_construction_debit']=request['completed_construction_inclusive_debit']-sum(sums.values())
result={'source':receipt['source'],'receipt_exit':receipt.get('exit'),'changed':receipt.get('changed'),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'requests':requests,'limits':['Current terminal trace only; no historical costs reused.','Cross-family inclusive/exclusive totals overlap and must not be added.','Call exclusive buckets are disjoint within completed constructor boundaries only.','Unfinished constructor prefix is observed debit only; total cost and unexecuted tail unknown.','Native accepted fuel observations are not wall time or complete failed-operation work.','No acceptance, performance comparison, or adoption verdict.']}
(p/'independent-partition.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':result['source'],'requests':len(requests),'completed_counts':[r['completed_count'] for r in requests]}))
