from pathlib import Path
import json,subprocess,hashlib,shutil,re,datetime
r=Path('/home/bobby/.cache/suss-m4-work');out=Path(__file__).parent;base=r/'sparse-struct-expectations-v1';dst=out/'staging';dst.mkdir(exist_ok=True);u=json.loads((out/'terminal-name-union.json').read_text());head='4e21edfef1f61e39da563fbeeeb3abbf319e2793';repo='/home/bobby/Work/code/bobby/suss'
# Copy only completed runs; initializer replay is still its own live tuple.
for n in ['validation','preservation']:
 src=base/n;rec=json.loads((src/'receipt.json').read_text());assert rec['terminal'];target=dst/n;target.mkdir(exist_ok=True)
 for f in src.iterdir():
  if f.name.startswith('initializer'):continue
  if f.is_dir():shutil.copytree(f,target/f.name,dirs_exist_ok=True)
  elif f.is_file():shutil.copyfile(f,target/f.name)
for f in base.glob('*review*.json'):shutil.copyfile(f,dst/f.name)
for n in ['source-commit-binding-4e21edf.json','terminal-name-union.json','parse-terminal-union.py','archive-plan.json','initializer-regression-report-note.md']:
 shutil.copyfile(out/n,dst/n)
# Recover exact initial validation source/BOOT from full binary patch; final source via published Git.
v=base/'validation';freeze=json.loads((v/'run-manifest.json').read_text());patch=(v/'source.patch').read_text();paths=re.findall(r'^diff --git i/(.*?) w/.*$',patch,re.M);assert len(paths)==5
vdir=dst/'selected-source/initial-validation';vdir.mkdir(parents=True,exist_ok=True)
for path in paths:
 f=vdir/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','-C',repo,'show','25b4a57cbfec7f9047f4afb1f5d0b06b5114b00e:'+path]))
subprocess.run(['git','apply','--binary','--unsafe-paths',str(v/'source.patch')],cwd=vdir,check=True,capture_output=True)
for path in paths:assert hashlib.sha256((vdir/path).read_bytes()).hexdigest()==freeze[path]
finalfreeze=json.loads((base/'preservation/run-manifest.json').read_text());fdir=dst/'selected-source/published-4e21edf'
for path in paths:
 f=fdir/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','-C',repo,'show',head+':'+path]));assert hashlib.sha256(f.read_bytes()).hexdigest()==finalfreeze[path]
# Full diagnostic control and oldCI live in distinct namespaces; neither inferred from candidate.
shutil.copytree(r/'pr271-current-request-partition-staging',dst/'control-current-request-25b4',dirs_exist_ok=True)
ci=r/'pr271-25b4a57-ci';ct=dst/'control-ci-25b4';ct.mkdir(exist_ok=True)
for f in ci.iterdir():
 if f.is_file() and (f.suffix=='.log' or f.name.startswith('git-commit-') or f.name in ['terminal-audit.json','terminal-outcomes-verified.json','initializer-plan-regression-classification.json','raw-log-manifest.json','run-terminal.json','jobs-terminal.json','watch.py']):shutil.copyfile(f,ct/f.name)
proof=json.loads((ci/'initializer-plan-regression-classification.json').read_text());pd=dst/'initializer-P-pass-proofs';pd.mkdir(exist_ok=True)
for row in proof['history']:
 for hit in row['observed_test_status']:
  src=Path(hit['log']);name=row['folder']+'-'+src.name;shutil.copyfile(src,pd/name)
  assert hashlib.sha256((pd/name).read_bytes()).hexdigest()==hit['sha256']
report={'kind':'CACHE_STAGING_NOT_FINAL_ARCHIVE','source':head,'initial_validation_counts':[29,1,0],'preservation_counts':[88,8,0],'combined_executions':[117,9,0],'combined_distinct':[115,8,0],'distinct_total':123,'repeated_tests':u['repeated_tests'],'all_stage_changes_empty':all(not s['source_changes'] for s in u['stages']),'initializer_supplemental':'PENDING_SEPARATE_RECEIPT; not included in counts or copied stdout','source_closure':'Published4e21 all3690freezeGitbindingsalreadyverified; all5changedinitial/finalsourceBOOT files included with exacthashmatches; commoninputs Gitresolved.','walltime':u['durations'],'layout':u['layout_observed'],'sourcechild_scope':'333314netunits perphase only actualcompletedfixture; public51prefix219934–220603saving stillboundary26/noidentityrows; rawwalltimes worsened anduncontrolled.','initializer_regression':'010e/fdPASS and25bFAIL rawlogs preserved with unchangedsourceproof; do not claim regressionfree when target wasunexecuted239.','release_gates':['Initializer replay terminal and actualreceipt/log/freeze classified','Carver finalscope review retained whenavailable','Explicitrootrelease beforefinalarchive']}
(dst/'STAGING-REPORT.json').write_text(json.dumps(report,indent=2)+'\n');manifest={str(f.relative_to(dst)):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in dst.rglob('*') if f.is_file() and f.name!='STAGING-MANIFEST.json'};(dst/'STAGING-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'staging-result.json').write_text(json.dumps({'staging':str(dst),'payloads':len(manifest),'archive_created':False,'report':report},indent=2)+'\n');print(json.dumps({'staging':str(dst),'payloads':len(manifest),'preservation':[88,8,0],'distinct_across_completed_tuples':[115,8,0],'initializer_pending':True,'archive_created':False},indent=2))
