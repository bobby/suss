from pathlib import Path
import json,re,hashlib,shutil,collections
r=Path('/home/bobby/.cache/suss-m4-work');p=Path(__file__).parent;src=r/'sparse-struct-expectations-v1/preservation';u=json.loads((p/'terminal-name-union.json').read_text());names=collections.defaultdict(list);tot=collections.Counter()
for s in u['stages']:
 for x in s['tests']:names[x['name']].append({'tuple':s['tuple'],'stage':s['stage'],'status':x['status']});tot[x['status']]+=1
supp=[];pending=[]
for stem in ['initializer','prototype-extra']:
 rec=json.loads((src/(stem+'-receipt.json')).read_text())
 if not rec['terminal']:pending.append(stem);continue
 assert not rec['changed'];f=src/(stem+'.log');t=f.read_text();counts=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)];assert len(counts)==1
 tests=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$',t,re.M)
 if len(tests)!=sum(counts[0]):
  tests=[];current=None
  for l in t.splitlines():
   m=re.match(r'^test (\S+) \.\.\. (.*)$',l)
   if m:
    assert current is None;current=m[1];z=re.match(r'^(ok|FAILED|ignored)(?:$|,)',m[2])
    if z:tests.append((current,z[1]));current=None
   elif current and l in ['ok','FAILED','ignored']:tests.append((current,l));current=None
  assert current is None
 assert [sum(v==s for n,v in tests) for s in ['ok','FAILED','ignored']]==list(counts[0])
 if stem=='initializer':assert counts[0]==(0,1,0) and 'span: 1..39' in t and 'caller &env input transport' in t and 'all fuel consumed' in t
 target=p/'staging'/('supplemental-'+stem);target.mkdir(parents=True,exist_ok=True)
 for n in [stem+'-receipt.json',stem+'-run.py',stem+'.log']:shutil.copyfile(src/n,target/n)
 row={'name':stem,'receipt':rec,'counts':list(counts[0]),'tests':[{'name':n,'status':v} for n,v in tests],'log_sha256':hashlib.sha256(f.read_bytes()).hexdigest()};supp.append(row)
 for n,v in tests:names[n].append({'tuple':'published4e21samefreeze','stage':stem,'status':v});tot[v]+=1
unique=collections.Counter();conflicts={}
for n,vs in names.items():
 statuses={x['status'] for x in vs}
 if len(statuses)==1:unique[next(iter(statuses))]+=1
 else:conflicts[n]=vs
report={'supplementals':supp,'pending_supplementals':pending,'combined_executions':dict(tot),'unique_names':len(names),'unique_consistent_counts':dict(unique),'status_conflicts':conflicts,'name_statuses':names,'scope':'Initialvalidation+growthpreservation+actualterminalseparatesupplementals only. Pendingtestsnotcounted. Initializer remainsPpass→current4e21fuelregression beforeRuntimeobservations/Macrounreached.','archive_created':False}
(p/'terminal-union-with-supplementals.json').write_text(json.dumps(report,indent=2)+'\n');(p/'staging/terminal-union-with-supplementals.json').write_text(json.dumps(report,indent=2)+'\n')
f=p/'staging/STAGING-REPORT.json';a=json.loads(f.read_text());a['supplemental_actual']=report;a['initializer_supplemental']='TERMINAL0PASS1FUELFAIL1..39.Runtimeinput; Macrounreached';a['pending_additional_coverage']={'prototype-extra':'certification_audit_tests1+prototype_buffer_tests3; pendingunless actualterminalreceiptincluded'};f.write_text(json.dumps(a,indent=2)+'\n');manifest={str(f.relative_to(p/'staging')):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in (p/'staging').rglob('*') if f.is_file() and f.name!='STAGING-MANIFEST.json'};(p/'staging/STAGING-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['combined_executions','unique_names','unique_consistent_counts','pending_supplementals','status_conflicts']},indent=2))
