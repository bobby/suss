# Sparse struct expectations — partial execution evidence

Published source4e21edfef1f61e39da563fbeeeb3abbf319e2793, based on25b4a57cbfec7f9047f4afb1f5d0b06b5114b00e. Two candidate source/BOOTtuples plus separate unchanged-source supplemental executions are retained. This packet is not identityacceptance or a fullbaseline/finalCIpass claim.

Actual totals:131Rustexecutions =121PASS10fuelFAIL0ignored. Exact-nameunion128 =119PASS9fuelFAIL, no statusconflicts. RepeatedsourcechildPASS, callbackpoisonPASS and callableFAIL explain the3execution overlaps. Initialvalidation29PASS1FAIL; preservation88PASS8FAIL; initializer0PASS1FAIL; certification_audit1+prototype_buffer3 supplemental4PASS. Do not call fresh-proof2 or prototype-origin8: actual preservation selects fresh-proof1 and prototype-origin4; separate extra4 cover different names. Maincounts and independent exactname/status data are included.

Allfive original librarycertification regressions and both replaced-hash integration tests PASS. Constructors12, sourcechild, map, authoredCLJS-observation-wrapper4 and core_import17 PASS. Publicnamespace/callable2 and coherent6 stillfuel; no required publicidentityrows established. Initializer remains a genuine P-pass→currentfuel regression: unchangedtest passed010e/fd, unexecuted239, fails25b and current4e Runtimecaller&env at1..39 before assertions, Macro unreached. Complete quotedPpass/currentfailurelogs and supplementalreceipt preserved. No global regression-absence claim.

All3690 preservationfreeze paths were independently matched to committedGit4e21 blobs. Five initialvalidation source/BOOTbytes differ after adding growthtest and normalregeneration. Exactstorage_snapshot.rs plus all4BOOToutputs areincluded for both candidate tuples. Initialvalidation bytes were recovered from savedfullbinarypatch, thenSHA256-verified againstitsrunfreeze, without regeneration. Commonfrozeninputs require exactGitcommit:blob from source-commit-binding; archive is not a full duplicate of everyvendor/repositoryfile.

Sourcechild: bothcandidate executions retain220events,110persourcephase. Matched original220labels/results compareequal; completedfixture gains333314units perphase. Callable6requests eachcomplete51constructions and stillstopboundary26: matchedcompletedprefix saves219934–220603units, notwholefailedrequest orunknownunexecutedtail savings. Different generic vsWasmbacktrace errorformat is retained, notattributed asa newcause.

Raw command timings are slower and uncontrolled: initialcandidate sourcechild62.77s, preservation65.561s vscontrol44.07s; callable126.819s vscontrol86.144s. Compilation, tracing andload differ. No walltimeimprovement or peak/live-memoryclaim. Actual layout witness Node88/Atom48/MutableSlot64/Snapshot112 retained.

Independent actual map check:69ordered expectedIDs;62hostPASS7guestjudged;0failure/unexecuted/skips/namespacetestfailure. Opaqueguestjudgments are not promoted tohostpasses. All48native memo rows have13fields with actual==expected. Existing wrapper passes do not claim afreshCLJSoracle run.

Control25b CI39129238646 FAILED: foundation548PASS6fuelFAIL,353PythonPASS; integration79PASS19fuelFAIL;24/259targets completed235unexecuted, no startedunfinished. Nine actual syntheticcheckouttrees equal25b; checkoutSHA itself isnotheadSHA. All10terminaljoblogs/proofs are preserved. Source4eCI remains separatelypending at packaging; no finalheadCIpass inferred.

Completecontroltrace andallocation/partitionanalyses are included. Nested andcrossfamily attribution intervals overlap; do not sum them or infer immutable/mutable classification from allocationcounts. Immutable descendants/membership and all original mutable/source/prototype/memo guards remain required. Design/source-review versions and rawfailures preserved; sourcecomponentreview is not finalPRreadiness.

Planning-history contains superseded pending coverage notes. Final authoritative counts are cross-checked in terminal-union-with-supplementals.json, main-terminal-counts.json and observations-independent-review.json. No new Cargo, bootstrap, testexecution, trackedfileedit orpush was performed for packaging.
