"""Host-only evidence parsing. No Cargo, source reads, process control or archive creation."""
from pathlib import Path
import json,re,hashlib,collections,argparse,datetime
ap=argparse.ArgumentParser();ap.add_argument('--supplemental-dir',type=Path);args=ap.parse_args();cache=Path('/home/bobby/.cache/suss-m4-work');out=Path(__file__).parent;base=cache/'sparse-struct-expectations-v1';runs=[('initial_validation',base/'validation'),('preservation',base/'preservation')]
if args.supplemental_dir:runs.append(('supplemental_initializer',args.supplemental_dir))
# Do not publish even a partial-union verdict until each requested tuple is terminal.
receipts={name:json.loads((p/'receipt.json').read_text()) for name,p in runs}
for name,r in receipts.items():
 if r.get('terminal') is not True:raise SystemExit(f'PENDING: {name} receipt is not terminal; no counts/report written')
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def parse(log):
 t=log.read_text();parsed=[];pending=None;failures=[]
 for line in t.splitlines():
  m=re.match(r'^test (\S+) \.\.\. (.*)$',line)
  if m:
   if pending:raise ValueError(('unfinished test before next',pending,log))
   pending=m[1];status=re.match(r'^(ok|FAILED|ignored)(?:$|,)',m[2])
   if status:parsed.append((pending,status[1]));pending=None
  elif pending and line in ('ok','FAILED','ignored'):parsed.append((pending,line));pending=None
 if pending:raise ValueError(('unfinished test at terminal',pending,log))
 summaries=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)]
 counts=[sum(c[i] for c in summaries) for i in range(3)]
 if counts!=[sum(v==k for n,v in parsed) for k in ['ok','FAILED','ignored']]:raise ValueError(('summary/status mismatch',log,counts,parsed))
 # --nocapture inline panic output; saved Rust error remains bound to its test.
 chunks=re.split(r"^thread '([^']+)' .*?panicked at ([^\n]+):\s*$",t,flags=re.M)
 for i in range(1,len(chunks),3):
  n,loc,body=chunks[i:i+3];body=body.split('\ntest ',1)[0]
  cls='fuel' if 'all fuel consumed' in body else 'certification' if 'coherent source failed' in body else 'assertion_or_other'
  failures.append({'name':n,'class':cls,'location':loc,'raw_error':body.strip()})
 return parsed,counts,failures,t
all_rows=[];occ=collections.defaultdict(list);counts=collections.Counter();runinfo=[]
for tuple_name,p in runs:
 r=receipts[tuple_name];selected=set(r.get('planned',[]));stages=r['stages'];executed={s['name'] for s in stages};missing=sorted(selected-executed)
 if 'unexecuted' in r and set(r['unexecuted'])!=set(missing):raise ValueError(('unexecuted mismatch',tuple_name))
 runinfo.append({'tuple':tuple_name,'directory':str(p),'receipt_sha256':digest(p/'receipt.json'),'recorded_base':r.get('base',r.get('source')),'unexecuted_stages':missing})
 for stage in stages:
  name=stage['name'];f=p/(name+'.log');tests,c,fail,t=parse(f)
  if stage.get('changed'):raise ValueError(('source mutation',tuple_name,name,stage['changed']))
  row={'tuple':tuple_name,'stage':name,'argv':stage['argv'],'exit':stage['exit'],'seconds':stage.get('seconds'),'counts':c,'tests':[{'name':n,'status':v} for n,v in tests],'failures':fail,'log':str(f),'sha256':digest(f),'source_changes':stage.get('changed',[])}
  for n,status in tests:occ[n].append({'tuple':tuple_name,'stage':name,'status':status});counts[status]+=1
  if name=='source-child':
   events=[l.split('source-child-fuel ',1)[1] for l in t.splitlines() if 'source-child-fuel ' in l];row['sourcechild_events']=len(events);row['sourcechild_final_events']=[l for l in events if 'stage=final-validation result=' in l]
  if name in ['symbol-originals','keyword-and-effects']:
   memo=[json.loads(l.split('NATIVE_MEMO_LEAF ',1)[1]) for l in t.splitlines() if 'NATIVE_MEMO_LEAF ' in l];row['memo_rows']=len(memo);row['memo13_all_equal']=all(len(x['fields'])==len(x['actual'])==len(x['expected'])==13 and x['actual']==x['expected'] for x in memo)
  all_rows.append(row)
unique=collections.Counter();conflicts={}
for n,vs in occ.items():
 states={v['status'] for v in vs}
 if len(states)==1:unique[next(iter(states))]+=1
 else:conflicts[n]=vs
comparison=json.loads((base/'validation/independent-terminal-comparison.json').read_text())
control_seed=json.loads((cache/'pr271-fresh-seed-validation/receipt.json').read_text());control_request=json.loads((cache/'pr271-current-request-partition/receipt.json').read_text())
durations={'candidate_sourcechild':[{k:s[k] for k in ['tuple','stage','seconds']} for s in all_rows if s['stage']=='source-child'],'control_sourcechild':next(s['seconds'] for s in control_seed['stages'] if s['name']=='source-child'),'candidate_callable':next(s['seconds'] for s in all_rows if s['tuple']=='initial_validation' and s['stage']=='callable'),'control_callable':control_request['seconds'],'qualification':'Raw command durations include differing compilation, tracing and machine load. Candidate is slower in these wall-time observations; no controlled timing or wall-time improvement claim. Fuel deltas apply only matched scopes.'}
result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':runinfo,'executions':dict(counts),'unique_consistent_test_statuses':dict(unique),'unique_test_names':len(occ),'status_conflicts':conflicts,'repeated_tests':{n:v for n,v in occ.items() if len(v)>1},'stages':all_rows,'durations':durations,'layout_observed':{'Node':88,'Atom':48,'MutableSlot':64,'Snapshot':112,'basis':'Actual candidate layout witness retained in initial validation; not changed by parser.'},'measurement_scopes':{'sourcechild_per_phase_saving':comparison['source_child']['finals'],'callable_completed_prefix_savings':comparison['matched_completed_public_prefix'],'public_failed_boundary':26},'limitations':['Cross-tuple union is not execution on one identical test/BOOT tuple; repeated names retained.','Supplemental initializer replay must be separately included when terminal; omission is pending coverage, not pass.','OldPinitializerPASS vs25bfailure must remain explicit even if candidate supplemental replay passes.','MapRustwrapperpass is not independenthostcomparison; separatelyvalidate69orderedIDs62host7guest.','No archive/readiness/identityacceptance/fullbaseline or globalregressionabsence claim.']}
(out/'terminal-name-union.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'executions':result['executions'],'unique':result['unique_consistent_test_statuses'],'names':len(occ),'conflicts':len(conflicts),'durations':durations},indent=2))
