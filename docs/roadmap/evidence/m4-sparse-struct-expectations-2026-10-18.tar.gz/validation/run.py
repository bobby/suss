from pathlib import Path
import subprocess as s,os,json,time,hashlib
root=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');p=Path(__file__).parent
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
files=s.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
def hashes():return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if (root/f).is_file()}
freeze=hashes();p.joinpath('run-manifest.json').write_text(json.dumps(freeze,indent=2)+'\n');p.joinpath('source.patch').write_bytes(s.check_output(['git','diff','--binary'],cwd=root))
r={'base':s.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'terminal':False,'stages':[]};stages=[('identity',['python3','scripts/verify_bootstrap_identity.py'],{},True),('snapshots',['cargo','test','--locked','-p','suss-compile','--lib','storage_snapshot::','--','--test-threads=1','--nocapture'],{},True),('source-child',['cargo','test','--locked','-p','suss-compile','--lib','source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo','--','--test-threads=1','--nocapture'],{'SUSS_SOURCE_CHILD_FUEL_TRACE':'1'},False),('callable',['cargo','test','--locked','-p','suss-cli','--test','compiled_macro_namespace_identity','resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations','--','--exact','--test-threads=1','--nocapture'],{'SUSS_METADATA_FUEL_TRACE':'1','SUSS_SOURCE_MATERIALIZE_FUEL_TRACE':'1','SUSS_NAMESPACE_IDENTITY_OUTPUT':str(p/'callable.json')},False)]
for name,argv,extra,stop in stages:
 assert hashes()==freeze
 r['current']=name;p.joinpath('receipt.json').write_text(json.dumps(r,indent=2)+'\n');e=env.copy();e.update(extra);start=time.monotonic()
 with p.joinpath(name+'.log').open('w') as log:
  child=s.Popen(argv,cwd=root,env=e,stdout=log,stderr=s.STDOUT);r['pid']=child.pid;p.joinpath('receipt.json').write_text(json.dumps(r,indent=2)+'\n');code=child.wait()
 changed=[f for f,h in freeze.items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h];row={'name':name,'argv':argv,'overrides':extra,'exit':code,'seconds':time.monotonic()-start,'changed':changed};r['stages'].append(row);print(row,flush=True);assert not changed
 if code and stop:break
r.update(terminal=True,current=None,unexecuted=[n for n,_,_,_ in stages if n not in [t['name'] for t in r['stages']]]);p.joinpath('receipt.json').write_text(json.dumps(r,indent=2)+'\n')
