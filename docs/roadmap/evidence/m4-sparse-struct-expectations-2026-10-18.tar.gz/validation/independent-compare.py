from pathlib import Path
import re,json,hashlib,subprocess
p=Path(__file__).resolve().parent;c=p.parent.parent
control=c/'pr271-current-request-partition';seed=c/'pr271-fresh-seed-validation'
def constructors(path):
 rows=[];cur=None;active=None
 for line in path.open():
  m=re.search(r'remaining=(?:Some\()?(\d+)',line)
  if 'coherent-stage stage=entry ' in line:cur=[];rows.append(cur);active=None
  if 'coherent-stage stage=construct-before ' in line:active=(int(re.search(r'boundary=Some\((\d+)\)',line)[1]),int(m[1]))
  if 'coherent-stage stage=construct-after ' in line:
   assert active;cur.append({'id':active[0],'cost':active[1]-int(m[1])});active=None
 return rows
a=constructors(control/'callable.log');b=constructors(p/'callable.log');assert len(a)==len(b)==6
prefix=[]
for x,y in zip(a,b):
 assert [v['id'] for v in x]==[v['id'] for v in y]
 prefix.append({'completed':len(x),'boundary_ids':[v['id'] for v in x],'control_units':sum(v['cost'] for v in x),'candidate_units':sum(v['cost'] for v in y),'saved_units':sum(v['cost'] for v in x)-sum(v['cost'] for v in y)})
def trace(path):
 rows=[]
 for line in path.open():
  if 'source-child-fuel ' in line:
   line=line[line.index('source-child-fuel '):].strip();m=re.search(r'remaining=Some\((\d+)\)',line)
   assert m;rows.append((re.sub(r'remaining=Some\(\d+\)','remaining=<fuel>',line),int(m[1])))
 return rows
x=trace(seed/'source-child.log');y=trace(p/'source-child.log');assert len(x)==len(y)==220;assert [v[0] for v in x]==[v[0] for v in y]
finals=[{'event':u[0],'control_remaining':u[1],'candidate_remaining':v[1],'saved_units':v[1]-u[1]} for u,v in zip(x,y) if 'variant=None stage=final-validation result=Ok(())' in u[0]]
# Exact fixture identity against base Git, not merely trace label similarity.
r=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');fixture='crates/suss-compile/src/portable_macro_graph/source_roots.rs';base='25b4a57cbfec7f9047f4afb1f5d0b06b5114b00e'
manifest=json.loads((p/'run-manifest.json').read_text());blob=subprocess.check_output(['git','-C',str(r),'show',base+':'+fixture]);assert hashlib.sha256(blob).hexdigest()==manifest[fixture]
summary={name:re.findall(r'test result:.*',(p/(name+'.log')).read_text()) for name in ['snapshots','source-child','callable']}
result={'verdict':'POSITIVE_MEASURED_PARTIAL_OPTIMIZATION_NOT_IDENTITY_ACCEPTANCE','base':base,'candidate_storage_sha256':manifest['crates/suss-compile/src/portable_session/storage_snapshot.rs'],'receipt':json.loads((p/'receipt.json').read_text()),'matched_completed_public_prefix':prefix,'source_child':{'control':str(seed/'source-child.log'),'same_220_ordered_events_results':True,'fixture_exact_base_blob':True,'last_events':x[-2:],'finals':finals},'summaries':summary,'limits':['Public requests still fail; no completed public whole-request savings or finalization/identity verdict.','SourceChild whole-request savings apply only this actual fixture.','Control SourceChild is the prior seed validation source variant; exact fixture blob and labels verified, not a newly rerun control.','Additional immutable-member growth test not executed in this frozen tuple.']}
(p/'independent-terminal-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'prefix':prefix,'finals':finals,'last':y[-2:],'summaries':summary},indent=2))
