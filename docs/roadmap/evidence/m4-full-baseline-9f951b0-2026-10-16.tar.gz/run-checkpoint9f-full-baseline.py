from pathlib import Path
import subprocess,os,json,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss');c=Path('/home/bobby/.cache/suss-m4-work');e=os.environ.copy();e.update(PATH='/home/bobby/.cargo/bin:'+e['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(r/'target-m4-prototype'))
files=[p for p in (r/'crates').rglob('*') if p.suffix in ['.rs','.sus']]+list((r/'runtime/bootstrap').glob('*'))
freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
cmd=['cargo','test','--workspace','--locked','--','--test-threads=2'];d={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'command':cmd,'started':time.time(),'current':'full-baseline','freeze':freeze};p=c/'checkpoint9f-full-baseline-result.json';p.write_text(json.dumps(d,indent=2)+'\n')
with (c/'checkpoint9f-full-baseline.log').open('w') as f: child=subprocess.run(cmd,cwd=r,env=e,stdout=f,stderr=subprocess.STDOUT)
d.update(current=None,exit=child.returncode,seconds=time.time()-d['started'],source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in freeze.items()));p.write_text(json.dumps(d,indent=2)+'\n')
