from pathlib import Path
import json,hashlib,subprocess,tarfile,io,re
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss-m4-borrowed-cut-capture');O=C/'borrowed-cut-production-evidence-e0';H='e0f73aeaa31a9394affad0d923288b4779a27889';PIN='c4295f303100bbf5afac449242d30bca1126f1a1';runs=['native-borrowed-cut-capture','native-borrowed-cut-capture-acceptance'];payload={};blobs={}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H
allowed={'docs/roadmap/handoff.md','docs/roadmap/evidence/m4-borrowed-cut-capture-2026-10-17.md','docs/roadmap/evidence/m4-borrowed-cut-capture-2026-10-17.tar.gz'}
changed=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R,text=True).splitlines());assert changed<=allowed,changed
def put(n,b):assert n not in payload,n;payload[n]=b
for rn in runs:
 root=C/rn;j=json.loads((root/'receipt.json').read_text());assert j['current'] is None and j['final_changed']==[] and all(s['exit']==0 for s in j['stages'])
 for f in root.rglob('*'):
  if f.is_file() and f.relative_to(root).parts[0] not in ['before','after-bootstrap'] and '__pycache__' not in f.parts:put('runs/'+rn+'/'+str(f.relative_to(root)),f.read_bytes())
 for freeze_file in root.glob('*freeze.json'):
  freeze=json.loads(freeze_file.read_text());assert len(freeze)==2915
  for n,h in freeze.items():
   if h in blobs:continue
   for stage in ['before','after-bootstrap']:
    p=root/stage/n
    if p.is_file():
     b=p.read_bytes()
     if hashlib.sha256(b).hexdigest()==h:blobs[h]=b;break
   else:raise AssertionError((rn,freeze_file.name,n,h))
final=json.loads((C/runs[0]/'after-bootstrap-freeze.json').read_text());assert final==json.loads((C/runs[1]/'before-freeze.json').read_text());normal=[n for n in final if not n.startswith('clojurescript/')];checked={}
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=R,input=''.join(H+':'+n+'\n' for n in normal).encode());stream=io.BytesIO(raw)
for n in normal:
 header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob';b=stream.read(int(header[2]));assert stream.read(1)==b'\n';assert hashlib.sha256(b).hexdigest()==final[n],n;checked[n]=final[n]
for n in final:
 if not n.startswith('clojurescript/'):continue
 b=subprocess.check_output(['git','show',PIN+':'+n.removeprefix('clojurescript/')],cwd=R/'clojurescript');assert hashlib.sha256(b).hexdigest()==final[n],n;checked[n]=final[n]
put('final/source-binding.json',(json.dumps({'head':H,'parent_docs':'d2b1079cb0b7b6aa49d0ffcf61dcf8a7a3676bcc','production_source_parent':'6a1d15e88103484d9c6fc73c50b08f88024ebf49','checked':len(checked),'pinned_cljs':PIN,'inputs':checked,'mismatches':[]},indent=2)+'\n').encode())
for h,b in blobs.items():put('frozen/sha256/'+h,b)
for d in ['borrowed-cut-capture-design-6a','borrowed-cut-capture-source']:
 for f in (C/d).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:put('packets/'+d+'/'+str(f.relative_to(C/d)),f.read_bytes())
for n in ['run-borrowed-cut-capture.py','run-borrowed-cut-capture-acceptance.py','compare-borrowed-cut-map.py']:
 put('commands-and-comparators/'+n,(C/n).read_bytes())
prior=C/'native-typed-scalar-complete-cost'
for n in ['source-child.log','receipt.json','comparison.json','complete-cost-census.json','whole-phase-native-census.json']:
 put('prior6a-fixed30M-diagnostic/'+n,(prior/n).read_bytes())
references={'prior_production_source':'6a1d15e88103484d9c6fc73c50b08f88024ebf49','prior_production_evidence_head':'d2b1079cb0b7b6aa49d0ffcf61dcf8a7a3676bcc','prior_production_archive_sha256':'d0d1c7f366c90b6cc33b4e035a405f81cae18d2902880a09d51b93bdf4bf3897','prior_diagnostic_source':'bc70a7cf16eca1ca84cdd0613e780927c8ddde60','prior_diagnostic_evidence_head':'9edd31915433ab6b89fa26a94ab5d6a082c139dd','prior_corrected_diagnostic_archive_sha256':'f3f1ae35a9b20a0b6364a474361302d776c629f3984eddf2ac7fed0e24ba857c','qualification':'Immutable independently-reviewed parent evidence references, not current e0 execution. Prior initial f54 archive packaging rejected; corrected f3 is self-contained.'}
put('parent-publication-references.json',(json.dumps(references,indent=2)+'\n').encode())
budget=json.loads((C/runs[0]/'default-budget-result.json').read_text());assert all(x['start']==10000000 and x['final_remaining']==21893 and x['complete_request_cost']==9978107 and x['source_child_markers']==110 for x in budget.values())
comparison=json.loads((C/runs[1]/'map-independent-comparison.json').read_text());assert comparison['ordered_ids_match'] and comparison['counts']['pass']==62 and comparison['counts']['guest-judged']==7 and comparison['counts']['fail']==0
summaries=[]
for f in [C/runs[0]/'focused-rust.log',C/runs[1]/'core-import.log',C/runs[1]/'map.log']:
 rows=re.findall(r'test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored',f.read_text());assert rows;row=tuple(map(int,rows[-1]));summaries.append(row)
assert summaries==[(43,0,0),(17,0,0),(1,0,0)],summaries
summary={'head':H,'unique_rust_pass':61,'rust_fail':0,'ignored':0,'sourcechild_default10M_both_phases':'PASS','default_complete_each':9978107,'final_remaining_each':21893,'saving_vs_prior6a_diagnostic_each':313876,'ordered_markers':220,'map_host_pass':62,'map_guest_judged':7,'map_ordered_ids':69,'limits':['No e0 full workspace baseline run','CI39037933447ongoing with2failedshards classificationpending atassembly','No issueclosure/M4acceptance/fullCIgreen inferred','Setup/cleanup outside boundary excluded','Repeated parentattempts not extra currentunique passes']}
ci=C/'pr268-e0f73ae-ci'/'39037933447';terminal=json.loads((ci/'terminal-comparison-vs-6a.json').read_text());assert terminal['run_state']=='completed failure'
assert terminal['integration']=={'completed_targets':29,'metadata_plan':253,'unexecuted_targets':224,'pass':106,'fail':14,'ignore':0}
proofs=[x for x in terminal['checkout_proofs'] if x['proof']];assert len(proofs)==9
for job in proofs:
 assert all(p['checkout']==H and p['tree_equals_head'] for p in job['proof'])
assert len(list(ci.glob('job-*.log')))==10
for f in ci.rglob('*'):
 if f.is_file() and '__pycache__' not in f.parts:put('ci-e0-run39037933447/'+str(f.relative_to(ci)),f.read_bytes())
summary['limits']=[s for s in summary['limits'] if not s.startswith('CI39037933447ongoing')]
summary['ci']={'run':39037933447,'result':'completed failure','foundation_pass_executions':512,'foundation_fail':0,'foundation_ignored':1,'integration_pass':106,'integration_fail':14,'known_parent6a_failure_names':True,'integration_targets_executed':29,'integration_targets_unexecuted':224,'caller_env_fuel':11,'invocation_fuel':3,'checkout_proofs':9,'raw_job_logs':10,'limits':'Counts separate from focused61; no aggregateunique CI/fullbaseline claim. No newlyobserved failures != allunexecuted targets unchanged.'}
put('assembly/pre-terminal-ci-packaging-reference.json',(json.dumps({'superseded_archive_sha256':'c303abd8fc53ce52752640de12e0a0859a4297f4cb3645be02b6ff309bed9c91','members':2911,'manifested_payloads':2910,'qualified_cache_preservation':str(O/'pre-terminal-ci-c303-packaging-attempt'),'reason':'Add terminalCI rather thanleavepending classification; source and focusedresults unchanged'},indent=2)+'\n').encode())
put('summary.json',(json.dumps(summary,indent=2)+'\n').encode());put('assembly/package.py',Path(__file__).read_bytes())
checks=''.join(hashlib.sha256(payload[n]).hexdigest()+'  '+n+'\n' for n in sorted(payload));put('SHA256SUMS',checks.encode())
archive=R/'docs/roadmap/evidence/m4-borrowed-cut-capture-2026-10-17.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for n in sorted(payload):
  b=payload[n];i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(b))
# One streaming validation checks both payload integrity AND every retained
# before/after snapshot closure, including old bootstrap images.
hashes={};freezes={}
with tarfile.open(archive,'r|gz') as tar:
 for m in tar:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts;assert m.name not in hashes
  b=tar.extractfile(m).read();hashes[m.name]=hashlib.sha256(b).hexdigest();assert b==payload[m.name]
  if m.name.endswith('freeze.json'):freezes[m.name]=json.loads(b)
for name,freeze in freezes.items():
 assert len(freeze)==2915
 for n,h in freeze.items():assert hashes.get('frozen/sha256/'+h)==h,(name,n,h)
assert len(hashes)==len(payload)
result={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(payload),'manifested_payloads':len(payload)-1,'bytes':archive.stat().st_size,'source_head':H,'inputs_bound':len(checked),'retained_freezes_self_contained':list(freezes)};(O/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
