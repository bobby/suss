#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import json,re,hashlib,subprocess,tarfile,io
C=Path('/home/bobby/.cache/suss-m4-work');RUN=C/'probe-preservation-full-baseline-8a11094';OUT=Path(__file__).parent
HEAD='8a110949f1c558ade6c38999e61aeeaffade6c2d';PIN='c4295f303100bbf5afac449242d30bca1126f1a1';ROOT=Path('/home/bobby/Work/code/bobby/suss')
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def main():
 receipt=json.loads((RUN/'receipt.json').read_text());before=json.loads((RUN/'before-freeze.json').read_text());after=json.loads((RUN/'after-freeze.json').read_text());need(receipt['head']==receipt['actual_head']==HEAD and receipt['current'] is None and receipt['exit']==101 and receipt['changed']==[] and receipt['git_status']=='','not exact terminal run');need(before==after and len(before)==4037,'freeze mismatch')
 need(receipt['command']==['cargo','test','--workspace','--locked','--','--test-threads=2'],'baseline command changed')
 tree=subprocess.check_output(['git','-C',str(ROOT),'rev-parse',HEAD+'^{tree}'],text=True).strip();need(tree==receipt['git_tree'],'wrong tree')
 log=(RUN/'workspace.log').read_text();log=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log)
 targets=json.loads((RUN/'workspace-targets.json').read_text());planned=[(x['package'],x['name']) for x in targets if x['kind']==['test']];need(len(planned)==len(set(planned))==259,'target plan mismatch')
 starts=list(re.finditer(r'^\s*Running (.*)$',log,re.M));harness=[];all_results=[];executed=[];failures=[]
 for i,hit in enumerate(starts):
  label=hit.group(1);part=log[hit.end():starts[i+1].start() if i+1<len(starts) else len(log)];summ=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',part);need(len(summ)==1,'missing/multiple terminal harness summaries '+label);counts=list(map(int,summ[0]));rows=re.findall(r'^test ([\w:]+) \.\.\. (ok|FAILED|ignored)\s*$',part,re.M);need(len(rows)==sum(counts),'test result names mismatch '+label);need(len({n for n,status in rows})==len(rows),'duplicate names in harness')
  tm=re.match(r'tests/(\w+)\.rs',label);pkg=None;target=None
  if tm:
   target=tm.group(1);matches=[x for x in planned if x[1]==target];need(len(matches)==1,'ambiguous target '+target);pkg,target=matches[0];executed.append((pkg,target))
  entry={'running':label,'package':pkg,'integration_target':target,'counts':dict(zip(['pass','fail','ignore'],counts)),'full_test_results':[{'name':n,'status':status} for n,status in rows]};harness.append(entry);all_results+=rows
  for name,status in rows:
   if status!='FAILED':continue
   panic=re.search(r"thread '"+re.escape(name)+r"'.*?panicked at ([^\n]+):\n(.*?)(?=\n\n|\Z)",part,re.S);need(panic is not None,'missing panic '+name);msg=panic.group(2);need('all fuel consumed by WebAssembly' in msg,'failure not fuel '+name);span=re.search(r'span: (\d+\.\.\d+)',msg);stage=re.search(r'Compiled macro expansion failed during (.*?): Runtime trap',msg);failures.append({'name':name,'target':target,'location':panic.group(1),'cause':'guest Wasm fuel exhaustion','span':span.group(1),'stage':stage.group(1),'raw_diagnostic':msg})
 counts={'pass':sum(v=='ok' for n,v in all_results),'fail':sum(v=='FAILED' for n,v in all_results),'ignore':sum(v=='ignored' for n,v in all_results)};need(counts=={'pass':88,'fail':2,'ignore':0},'unexpected baseline totals');need(len(harness)==18 and len(executed)==len(set(executed))==15,'unexpected harness/target counts');need(('empty_do_source_return_retains_context_and_nil_after_gc','ok') in all_results,'empty_do not passed')
 need({(f['name'],f['span'],f['stage']) for f in failures}=={('collection_source_nodes_retain_original_children_before_factory_lowering','851..882','compiled macro invocation'),('unordered_literal_ast_edges_and_runtime_effects_preserve_textual_order','510..531','caller &env input transport')},'unexpected failure sites')
 unexecuted=sorted(set(planned)-set(executed));need(len(unexecuted)==244,'unexecuted target count mismatch')
 # All source bytes are already retained in the run CAS. Resolve them to explicit
 # Git objects; compare both SHA256 and Git blob SHA1 without copying into archive.
 bindings={};cas_verified={}
 for sub in (False,True):
  items=[(f,h) for f,h in before.items() if f.startswith('clojurescript/')==sub];repo=ROOT/'clojurescript' if sub else ROOT
  # Main worktree might lack checkout? shared clojurescript initialized as below.
  if sub and not (repo/'.git').exists():repo=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace/clojurescript')
  ref=PIN if sub else HEAD;rels=[f.removeprefix('clojurescript/') if sub else f for f,h in items];output=subprocess.check_output(['git','-C',str(repo),'cat-file','--batch-check'],input=('\n'.join(ref+':'+f for f in rels)+'\n').encode()).decode().splitlines();need(len(output)==len(items),'Git batch count')
  for (f,h),rel,line in zip(items,rels,output):
   info=line.split();need(len(info)==3 and info[1]=='blob','missing Git binding '+f);size=int(info[2]);cas=RUN/'frozen/sha256'/h;need(cas.is_file() and cas.stat().st_size==size,'CAS missing/size mismatch '+f)
   if h not in cas_verified:
    s256=hashlib.sha256();s1=hashlib.sha1(b'blob '+str(size).encode()+b'\0')
    with cas.open('rb') as inp:
     while b:=inp.read(1024*1024):s256.update(b);s1.update(b)
    need(s256.hexdigest()==h,'CAS sha256 mismatch '+f);cas_verified[h]=s1.hexdigest()
   need(cas_verified[h]==info[0],'Git blob bytes differ '+f)
   bindings[f]={'repository':'clojure/clojurescript' if sub else 'bobby/suss','commit':ref,'path':rel,'blob_oid':info[0],'sha256':h,'bytes':size}
 resolution={'head':HEAD,'tree':tree,'cljs_pin':PIN,'inputs':4037,'bindings':bindings,'limits':'All CAS bytes SHA256 and exact Git blob identity verified; full source/CAS excluded from this lean archive, explicit Git dependencies required.'}
 (OUT/'git-input-bindings.json').write_text(json.dumps(resolution,indent=2)+'\n')
 review={'verdict':'VERIFIED exact-head terminal failing required baseline; negative evidence only, not passing baseline/readiness','head':HEAD,'git_tree':tree,'command':receipt['command'],'seconds':receipt['seconds'],'exit':101,'input_count':4037,'before_after_identical':True,'all_frozen_bytes_git_verified':True,'counts':counts,'harnesses_started_and_terminal':18,'integration_targets':{'planned':259,'started':15,'terminal':15,'unfinished':0,'unexecuted':244},'integration_counts':{k:sum(x['counts'][k] for x in harness if x['integration_target']) for k in counts},'nonintegration_counts':{k:sum(x['counts'][k] for x in harness if not x['integration_target']) for k in counts},'failed_tests':failures,'empty_do':'PASS in same failed target','harnesses':harness,'planned_integration_targets':sorted(planned),'unexecuted_integration_targets':unexecuted,'limits':['Normal Cargo fail-fast stopped after collection_source target, not a full workspace execution.','Three terminal CLI unit/bin harnesses; other workspace library/unit harnesses and doctests not observed/executed; building a crate is not test execution.','No Python test lane in this Cargo baseline. Do not combine counts with separate CI39080390999.','The same two failed names were actually observed as fuel failures in exact8a and parentf156 CI; no new cause inferred from aggregate counts.','Source review/focused passes do not replace these failing acceptance witnesses.','No code, source worktree, index, tests or build mutated/launched by reviewer.']}
 review_path=C/'probe-preservation-full-baseline-8a11094-independent-review.json';review_path.write_text(json.dumps(review,indent=2)+'\n')
 # Archive only durable evidence; never frozen source blob directory.
 payload={'REPORT.md':(OUT/'REPORT.md').read_bytes(),'packager.py':Path(__file__).read_bytes(),'git-input-bindings.json':(OUT/'git-input-bindings.json').read_bytes(),'independent-terminal-review.json':review_path.read_bytes(),'committed-head-independent-review.json':(C/'probe-integration-8a11094-final-head-independent-review.json').read_bytes()}
 for f in RUN.iterdir():
  if f.is_file():need(not f.is_symlink(),'symlink run input');payload['run/'+f.name]=f.read_bytes()
 index={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())};payload['MANIFEST.json']=(json.dumps({'schema':1,'files':index},indent=2)+'\n').encode();out=OUT/'m4-probe-preservation-full-baseline-2026-10-17.tar.gz';need(not out.exists(),'archive already exists')
 with out.open('xb') as output:
  with tarfile.open(fileobj=output,mode='w:gz') as tar:
   for n,b in sorted(payload.items()):
    need(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts,'unsafe path');info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
 with tarfile.open(out) as tar:
  members=tar.getmembers();need(len(members)==len({m.name for m in members})==len(payload),'duplicate/member mismatch');need(all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members),'unsafe members');d={m.name:tar.extractfile(m).read() for m in members};need(set(d)==set(payload),'archive member scope')
  for n,v in index.items():need(sha(d[n])==v['sha256'] and len(d[n])==v['bytes'],'digest mismatch')
 result={'archive':str(out),'sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'members':len(payload),'hashed_payloads':len(index),'safe_paths_all_digests_verified':True,'head':HEAD,'source_bindings':len(bindings),'unique_cas_blobs_verified':len(cas_verified),'review':str(review_path),'counts':counts,'target_scope':review['integration_targets'],'report_sha256':sha(payload['REPORT.md']),'limits':'No source blobs copied; explicit exact Git dependencies. Negative terminal baseline only. No repository edits/commit/push.'};(OUT/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
