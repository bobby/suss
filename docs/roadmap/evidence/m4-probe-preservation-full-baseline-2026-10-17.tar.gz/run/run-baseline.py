from pathlib import Path
import subprocess,os,time,json,hashlib,fcntl,shutil,sys
cache=Path('/home/bobby/.cache/suss-m4-work');root=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace');target=cache/'m4-cost-diagnostic-target';head=sys.argv[sys.argv.index('--head')+1];run=cache/('probe-preservation-full-baseline-'+head[:7])
# Execute only after final committed-scope review and exact-head publication.
assert '--published-reviewed-head' in sys.argv
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''
remote=subprocess.check_output(['git','ls-remote','--heads','origin','refs/heads/portable/m4-native-fuel-hotspots'],cwd=root,text=True).split();assert remote==[head,'refs/heads/portable/m4-native-fuel-hotspots'],remote
leases=[]
for name in ['.invoke-upper-bound.lease','.full-workspace-baseline.lease','.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease']:
 f=open(target/name,'a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:envb=(proc/'environ').read_bytes();cmd=(proc/'cmdline').read_bytes().split(b'\0')[0]
 except OSError:continue
 if b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' in envb or str(target).encode() in cmd:raise RuntimeError('Target active '+proc.name)
component=json.loads((cache/'short-property-observations-preservation/terminal-freeze.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in component.items())
tracked=[p.decode() for p in subprocess.check_output(['git','ls-files','--recurse-submodules','-z'],cwd=root).split(b'\0') if p]
paths=sorted(set(tracked)|set(component))
freeze=lambda:{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
expected=freeze()
metadata=json.loads(subprocess.check_output(['cargo','metadata','--locked','--no-deps','--format-version','1'],cwd=root))
workspace=set(metadata['workspace_members'])
targets=[{'package':p['name'],'name':t['name'],'source':t['src_path'],'kind':t['kind']} for p in metadata['packages'] if p['id'] in workspace for t in p['targets']]

run.mkdir(exist_ok=False);(run/'frozen/sha256').mkdir(parents=True);(run/'workspace-targets.json').write_text(json.dumps(targets,indent=2)+'\n')
for source,h in expected.items():
 dest=run/'frozen/sha256'/h
 if not dest.exists():shutil.copyfile(root/source,dest)
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==h
(run/'before-freeze.json').write_text(json.dumps(expected,indent=2)+'\n');shutil.copyfile(Path(__file__),run/'run-baseline.py')
command=['cargo','test','--workspace','--locked','--','--test-threads=2'];env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
for k in list(env):
 if k.startswith('SUSS_') and ('TRACE' in k or 'DIAGNOSTIC' in k):env.pop(k)
receipt={'head':head,'git_tree':subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=root,text=True).strip(),'pid':os.getpid(),'pgid':os.getpgid(0),'sid':os.getsid(0),'target':str(target),'command':command,'environment':{'CARGO_BUILD_JOBS':'1','RAYON_NUM_THREADS':'1','test_threads':2,'RUSTFLAGS':'inherited, not assigned'},'input_count':len(expected),'component_input_count':len(component),'integration_targets':sum(t['kind']==['test'] for t in targets),'current':'workspace','limits':'Exact published reviewed head; all tracked/submodule files and2996 component inputs frozen. Default budgets. Cargo standard fail-fast may leave later harnesses/doctests unexecuted; workspace-targets.json records actual scope. No fixture/rate/quota changes or old baseline restart.'}
def save():(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save();print(json.dumps(receipt),flush=True);start=time.monotonic()
try:
 with (run/'workspace.log').open('w') as log:
  child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);receipt['cargo_pid']=child.pid;save();code=child.wait()
 receipt.update(exit=code,seconds=time.monotonic()-start)
finally:
 actual=freeze();(run/'after-freeze.json').write_text(json.dumps(actual,indent=2)+'\n');receipt.update(current=None,changed=[p for p in expected if actual[p]!=expected[p]],git_status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),actual_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip());save();print(json.dumps(receipt),flush=True)
