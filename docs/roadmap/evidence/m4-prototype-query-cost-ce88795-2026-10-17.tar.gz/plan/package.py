from pathlib import Path
import tarfile,hashlib,json,subprocess
c=Path('/home/bobby/.cache/suss-m4-work');root=Path('/home/bobby/Work/code/bobby/suss-m4-prototype-query-cost');plan=c/'prototype-query-cost-plan';approved=c/'native-prototype-query-cost-approved-sourcechild';receipt=json.loads((approved/'receipt.json').read_text());assert receipt['current'] is None and receipt['final_changed']==[]
items={}
def add(name,p):
 assert p.is_file(),p;items[name]=p
for attempt in ['native-prototype-query-cost-candidate','native-prototype-query-cost-candidate-2','native-prototype-query-cost-approved-sourcechild']:
 d=c/attempt
 for name in ['receipt.json','command-plan.json','before-freeze.json','after-bootstrap-freeze.json','compile.log','bootstrap.log','source-child.log','prototype-query-census.json','prototype-query-intervals.json']:
  if (d/name).is_file():add(attempt+'/'+name,d/name)
 f='crates/suss-compile/src/portable_session/prototype_origin.rs';add(attempt+'/source/'+f,d/'before'/f)
for f in plan.iterdir():
 if f.is_file():add('plan/'+f.name,f)
for f in ['run-native-prototype-query-cost.py','run-native-prototype-query-cost-2.py','run-prototype-query-approved-sourcechild.py','native-prototype-query-command-plan.json','prototype-query-sourcechild-command-plan.json']:add('commands/'+f,c/f)
for f in ['prototype_origin.rs','constructor_inputs.rs','canonical_methods.rs','write_domain.rs']:
 add('source/crates/suss-compile/src/portable_session/'+f,root/'crates/suss-compile/src/portable_session'/f)
add('source/crates/suss-compile/src/portable_macro_graph/source_roots.rs',root/'crates/suss-compile/src/portable_macro_graph/source_roots.rs')
for phase in ['macro','runtime']:
 for ext in ['wasm','json']:add('source/runtime/bootstrap/'+phase+'.'+ext,root/'runtime/bootstrap'/(phase+'.'+ext))
manifest={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in items.items()};(plan/'payload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');add('payload-manifest.json',plan/'payload-manifest.json')
archive=root/'docs/roadmap/evidence/m4-prototype-query-cost-ce88795-2026-10-17.tar.gz';archive.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(items.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 for name,h in manifest.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h
r={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'payloads':len(items),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'qualification':'Observer independently approved per user relay before sourcechild-only fresh run; prior unreviewed compile attempts and SIGINT preserved explicitly; no acceptance.'};(c/'prototype-query-publication-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
