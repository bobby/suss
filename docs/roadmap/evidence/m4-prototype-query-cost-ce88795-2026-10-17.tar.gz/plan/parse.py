from pathlib import Path
import re,json,collections,hashlib
cache=Path('/home/bobby/.cache/suss-m4-work');raw=cache/'native-prototype-query-cost-approved-sourcechild/source-child.log'
lines=raw.read_text().splitlines();stack=[];rows=[];region='setup';groups=collections.defaultdict(lambda:{'count':0,'spent':0,'errors':0,'false':0});regions={}
for i,line in enumerate(lines,1):
 m=re.search(r'source-child-fuel source=(\S+) variant=(.*?) stage=materialize:before',line)
 if m:
  assert not stack;(source,variant)=m.groups();region=source+'/'+variant;regions[region]={'start_line':i}
 m=re.search(r'source-prototype phase=(\S+) event=(before|after).*remaining=Some\((\d+)\)',line)
 if m:
  phase,event,fuel=m.groups();fuel=int(fuel)
  if event=='before':stack.append({'phase':phase,'region':region,'start_line':i,'start_fuel':fuel,'repeat':any(x['phase']=='repeat-query' for x in stack)})
  else:
   assert stack,(i,line);r=stack.pop();assert r['phase']==phase,(i,r,line);r.update(end_line=i,spent=r['start_fuel']-fuel,error='result=Err' in line,false='result=Ok(false)' in line);rows.append(r)
   key=(region,phase,r['repeat']);g=groups[key];g['count']+=1;g['spent']+=r['spent'];g['errors']+=r['error'];g['false']+=r['false']
 if re.search(r'source-child-fuel .*stage=materialize result=',line):
  assert not stack;regions[region]['end_line']=i;region+=':after-materialize'
result={'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'regions':regions,'groups':[{'region':k[0],'phase':k[1],'nested_in_repeat':k[2],**v} for k,v in groups.items()],'unclosed_intervals':stack,'qualification':'Single unchanged source-child test. Groups include errors and every reached phase; repeat-query includes its nested input authority/query/materialization costs. Do not sum parent and nested intervals. Twelve-field comparison excludes preceding existing 24*size_of(Val) precharge and Vec allocation; post-query/unlabelled work not attributed. Setup and post-materialize tail are kept separate. No optimization or acceptance claim.'}
(raw.parent/'prototype-query-census.json').write_text(json.dumps(result,indent=2)+'\n');(raw.parent/'prototype-query-intervals.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(result,indent=2))
