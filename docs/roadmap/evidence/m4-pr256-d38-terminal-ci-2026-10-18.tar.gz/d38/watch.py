from pathlib import Path
import json,subprocess,re,hashlib,time,datetime,argparse
ap=argparse.ArgumentParser();ap.add_argument('--capture-old-once',action='store_true');a=ap.parse_args();ROOT=Path('/home/bobby/.cache/suss-m4-work');P=Path(__file__).parent
RID=39149083057 if a.capture_old_once else 39149952174;HEAD='440a0b7735a4c290eb7c291cfe29e239b5ac33d9' if a.capture_old_once else 'd38b59cb1cbaff0def4aad257c79e4f28ebe339a';D=ROOT/'pr256-440a0b7-ci' if a.capture_old_once else P
D.mkdir(exist_ok=True)
def api(route):return subprocess.check_output(['gh','api','--allow-escape-sequences','repos/bobby/suss/'+route],stderr=subprocess.PIPE)
def save(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
def commit(sha):
 f=D/f'git-commit-{sha}.json'
 if not f.exists():f.write_bytes(api('git/commits/'+sha))
 return json.loads(f.read_text())
def inspect(j):
 row={k:j.get(k) for k in ['name','id','status','conclusion','started_at','completed_at']};f=D/f"{j['id']}.log"
 if j['status']=='completed' and not f.exists():
  try:f.write_bytes(api(f"actions/jobs/{j['id']}/logs"))
  except subprocess.CalledProcessError as e:row['log_unavailable']=e.stderr.decode(errors='replace');save(f"{j['id']}-log-error.json",row)
 if not f.exists():return row
 raw=f.read_bytes();row['log_sha256']=hashlib.sha256(raw).hexdigest();t=re.sub(r'^\S+Z ?', '',re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.decode('utf-8-sig')),flags=re.M)
 summaries=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)];row['completed_summary_counts']=[sum(x[i] for x in summaries) for i in range(3)];row['summary_count']=len(summaries)
 blocks=[];cur=None
 for l in t.splitlines():
  m=re.search(r'Running (tests/([^\s.]+)\.rs|unittests (\S+))',l)
  if m:
   cur={'harness':m[2] or 'unittests:'+m[3],'completed':False,'observed_tests':[]};blocks.append(cur)
  m=re.match(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:$|,)',l)
  if m and cur:cur['observed_tests'].append({'name':m[1],'status':m[2]})
  m=re.match(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',l)
  if m and cur:cur['completed']=True;cur['counts']=list(map(int,m.groups()))
 row['harnesses']=blocks;row['started_unfinished']=[x for x in blocks if not x['completed']];row['compile_errors']=re.findall(r'^error\[E\d+\]:.*$',t,re.M)
 row['failed']={};chunks=re.split(r'^---- (.*?) stdout ----\s*$',t,flags=re.M)
 for i in range(1,len(chunks),2):
  n,b=chunks[i:i+2];diag=next((l for l in b.splitlines() if 'Compiled macro expansion failed during ' in l),None);s=re.search(r'Compiled macro expansion failed during ([^:]+):',diag or '');sp=re.search(r'span:\s*(\d+\.\.\d+)',diag or '')
  row['failed'][n]={'fuel':'all fuel consumed' in (diag or b),'stage':s[1] if s else None,'span':sp[1] if sp else None,'raw_body':b.strip()}
 row['checkout_proofs']=[]
 for sha in re.findall(r'^\[command\].*git log -1 --format=%H\n([a-f0-9]{40})\s*$',t,re.M):
  c=commit(sha);row['checkout_proofs'].append({'sha':sha,'tree':c['tree']['sha'],'head_tree':commit(HEAD)['tree']['sha'],'tree_equal_head':c['tree']['sha']==commit(HEAD)['tree']['sha'],'parents':[x['sha'] for x in c['parents']]})
 if j['name'].startswith('integration'):
  pl=next((l for l in t.splitlines() if l.startswith('{"index":') and '"targets"' in l),None)
  if pl:row['plan']=json.loads(pl)
  row['completed_targets']=[x['harness'] for x in blocks if x['completed'] and not x['harness'].startswith('unittests:')]
 if j['name']=='foundation':row['Python_execution_count']=sum(map(int,re.findall(r'^Ran (\d+) tests? in ',t,re.M)));row['step_outcomes']=[{k:s.get(k) for k in ['name','status','conclusion']} for s in j['steps']]
 return row
while True:
 try:
  stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');r=json.loads(api(f'actions/runs/{RID}'));j=json.loads(api(f'actions/runs/{RID}/jobs?per_page=100'));assert r['head_sha']==HEAD
  save(f'run-{stamp}.json',r);save(f'jobs-{stamp}.json',j);save('run-current.json',r);save('jobs-current.json',j);rows=[inspect(x) for x in j['jobs']];integ=[x for x in rows if x['name'].startswith('integration')];plans=[tuple(t) for x in integ for t in x.get('plan',{}).get('targets',[])];complete=[t for x in integ for t in x.get('completed_targets',[])];unfinished=[b['harness'] for x in integ for b in x.get('started_unfinished',[])];known_unexecuted=[list(x) for x in plans if x[1] not in set(complete+unfinished)];counts=[sum(x.get('completed_summary_counts',[0,0,0])[i] for x in integ) for i in range(3)]
  result={'run':RID,'head':HEAD,'event':r['event'],'status':r['status'],'conclusion':r['conclusion'],'at_utc':stamp,'jobs':rows,'integration_completed_summary_counts':counts,'known_plan_targets':len(plans),'shards_with_known_plan':sum('plan' in x for x in integ),'completed_integration_targets':len(complete),'started_unfinished_integration_targets':unfinished,'unexecuted_within_known_plans':known_unexecuted,'limits':['Cancellationisnotpassorfailureofunexecutedtests. Partialobservedtestrowsinsideunfinishedharnesses retained separately andnotaddedtocompletedsummaries.','Targetinventoryispartialuntilall8plansavailable; do notinferfullunexecutedcount frommissingplans.','Testcounts areexecutionsincluding anybootstraprepeats, notunique-testcoverage.','Checkouttreeproof doesnotestablishpostcheckoutcleaninputfreeze; allresults arethisexacthead/eventonly.']}
  old=ROOT/'pr256-440a0b7-ci/terminal-audit.json'
  if not a.capture_old_once and old.exists():
   olddata=json.loads(old.read_text());of={n:v for x in olddata['jobs'] for n,v in x.get('failed',{}).items()};nf={n:v for x in rows for n,v in x.get('failed',{}).items()};result['comparison_to_cancelled440_observed_only']={'new_observed_failed_names':sorted(set(nf)-set(of)),'old_failed_names_not_observed_here':sorted(set(of)-set(nf)),'qualification':'Oldrun wascancelled; absenceofnameisnotfixed/unexecutedpass.'}
  save('current-audit.json',result);save('raw-log-manifest.json',{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in D.glob('*.log')});print(json.dumps({'at':stamp,'run':RID,'status':r['status'],'conclusion':r['conclusion'],'jobs':[(x['name'],x['status'],x['conclusion']) for x in rows],'completed_integration_summary_counts':counts,'unfinished_targets':unfinished}),flush=True)
  terminal=r['status']=='completed' and all(x['status']=='completed' for x in j['jobs'])
  if terminal:save('terminal-audit.json',result);save('run-terminal.json',r);save('jobs-terminal.json',j)
  if a.capture_old_once or terminal:break
 except Exception as e:
  with (D/'watch-errors.log').open('a') as f:f.write(datetime.datetime.now(datetime.timezone.utc).isoformat()+' '+repr(e)+'\n')
  print('observation error '+repr(e),flush=True)
  if a.capture_old_once:raise
 time.sleep(30)
