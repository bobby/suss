from pathlib import Path
import json,re,hashlib,subprocess,datetime,tarfile,io
C=Path('/home/bobby/.cache/suss-m4-work');P=Path(__file__).parent
L=lambda p:json.loads(p.read_text()); H=lambda b:hashlib.sha256(b).hexdigest()
a=L(P/'terminal-audit.json');old=L(C/'pr256-440a0b7-ci/terminal-audit.json');a3=L(C/'cia3-classification.json')
assert a['status']=='completed' and len(a['jobs'])==10
clean=lambda f:re.sub(r'^\S+Z ?', '',re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',f.read_text(encoding='utf-8-sig')),flags=re.M)
def failures(t):
 out={};c=re.split(r'^---- (.*?) stdout ----\s*$',t,flags=re.M)
 for i in range(1,len(c),2):
  n,b=c[i:i+2];b=b.split('\nfailures:',1)[0];s=re.search(r'Compiled macro expansion failed during ([^:]+):',b);sp=re.search(r'span:\s*(\d+\.\.\d+)',b) or re.search(r'at bytes (\d+\.\.\d+)',b)
  out[n]={'fuel':'all fuel consumed by WebAssembly' in b,'stage':s[1] if s else None,'span':sp[1] if sp else None,'raw_body':b.strip()}
 return out
rows=[];nf={};passed=set();proofs=[]
for j in a['jobs']:
 f=P/f"{j['id']}.log";b=f.read_bytes();assert H(b)==j['log_sha256'];t=clean(f)
 sums=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)];counts=[sum(x[i] for x in sums) for i in range(3)];assert counts==j['completed_summary_counts']
 fs=failures(t);failed_rows=set(re.findall(r'^test (\S+) \.\.\. FAILED$',t,re.M));assert set(fs)==failed_rows,(j['name'],set(fs)^failed_rows)
 passed.update(re.findall(r'^test (\S+) \.\.\. ok$',t,re.M));nf.update(fs);proofs+=j['checkout_proofs'];assert not j['compile_errors']
 rows.append({'name':j['name'],'id':j['id'],'counts':counts,'summary_records':len(sums),'failures':fs,'sha256':H(b),'python':sum(map(int,re.findall(r'^Ran (\d+) tests? in ',t,re.M)))})
assert len(nf)==18 and all(v['fuel'] for v in nf.values());assert len(proofs)==9 and all(x['tree_equal_head'] for x in proofs)
oldfs={n:v for j in old['jobs'] for n,v in failures(clean(C/'pr256-440a0b7-ci'/f"{j['id']}.log")).items()}
a3fs={};a3pass=set()
for j in a3['jobs']:
 f=C/f"cia3-job-{j['job']}-clean.log"
 if f.exists():
  t=clean(f);a3fs.update(failures(t));a3pass.update(re.findall(r'^test (\S+) \.\.\. ok$',t,re.M))
assert set(a3fs)=={x['test'] for x in a3['failures']}
def compare(fs,ps=None):
 return {'failed_names_common':sorted(set(nf)&set(fs)),'new_observed_failed_names':sorted(set(nf)-set(fs)),'previous_failed_names_not_failed_now':sorted(set(fs)-set(nf)),'same_class_stage_span':all(all(nf[n][k]==fs[n][k] for k in ['fuel','stage','span']) for n in set(nf)&set(fs)),'changed_failures':{n:{'current':nf[n],'previous':fs[n]} for n in set(nf)&set(fs) if any(nf[n][k]!=fs[n][k] for k in ['fuel','stage','span'])},'previous_observed_pass_now_fail':sorted(set(nf)&(ps or set()))}
counts=[sum(j['counts'][i] for j in rows if j['name'].startswith('integration')) for i in range(3)];assert counts==[124,18,0]
assert a['completed_integration_targets']==31 and len(a['unexecuted_within_known_plans'])==220 and a['known_plan_targets']==251 and not a['started_unfinished_integration_targets']
result={'run':a['run'],'head':a['head'],'status':'completed','conclusion':'failure','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_10_rawlogs_sha_verified':True,'checkout_proofs':proofs,'foundation':next(x for x in rows if x['name']=='foundation'),'integration':{'counts':counts,'completed_targets':31,'planned_targets':251,'unexecuted_targets':220,'started_unfinished':[]},'jobs':rows,'comparison_to_cancelled440':compare(oldfs),'comparison_to_a3':compare(a3fs,a3pass),'no_observed_new_semantic_or_provenance_failures':True,'parser_correction':'public_records_execute_jank_and_authored_contracts_with_two_nominal_classes wraps a multiline Wasm fuel trap in Semantic error; full raw body proves fuel, bytes453..489. Old first-line-only fuel=false was incorrect; initial audit retained.','limits':['This CI has no complete baseline coverage. Unexecuted tests are unknown.','440 canceled before constructor target completion; newly observed constructor failure here is already failed in a3.','No local baseline input/log/receipt read or copied; no Cargo, source writes, retries or cancellations.','Foundation counts are executions including bootstrap verification repeats, not distinct coverage.'],'unexecuted_targets':a['unexecuted_within_known_plans']}
(P/'independent-terminal-review.json').write_text(json.dumps(result,indent=2)+'\n')
text=f"""# PR256 d38 terminal CI\n\nRun {a['run']} completed failure. Foundation:398Rust pass executions/0fail/1ignore and353Python passes; inventory, bootstrap reproduction/execution, library/binary/example/doc steps all successful. Integration:124PASS18fuelFAIL0ignored,31/251targets completed,220unexecuted, no started unfinished. All eight shards fail; aggregate test gate fails because integration result failed. No compile/provenance/semantic assertion failure observed.\n\nNine actual checkout proofs: synthetic3fc3004ce1d084b3b97d135093bee46430ce8827 tree b9d2e131a1217e32888deefe161f2176fb3f2873 equals d38 head tree. This is tree equality, not a claim that checkout SHA was headline d38 or that a postcheckout source freeze ran in CI.\n\nAll18failed names/class/stage/span match a3 CI38908029824. No a3 observed-pass name now fails. Relative to canceled440,17same failures and one newly observed constructor failure(607..636 caller&env), already failed in a3; not evidence of a new regression. No old failed name observed resolved. 440 incomplete coverage retained separately.\n\nFull exact names/stages/spans, raw SHA hashes, target inventory and proofs are in independent-terminal-review.json. The public-record authored-contract test's multiline error explicitly ends in all fuel consumed at453..489; the word Semantic in its wrapper does not establish a semantic assertion failure.\n\nNo local baseline result is included or inferred. Baseline43114 remains root-owned/live. No reruns/cancels/builds/source mutations.\n"""
assert result['comparison_to_a3']['same_class_stage_span'],result['comparison_to_a3']['changed_failures']
(P/'TERMINAL-REPORT.md').write_text(text)
# Separate CI packet; no focused archive or live workspace baseline data.
files={f'd38/{f.name}':f for f in P.iterdir() if f.is_file() and f.suffix in ['.json','.log','.py','.md']}
for f in (C/'pr256-440a0b7-ci').iterdir():
 if f.is_file() and (f.suffix=='.log' or f.name in ['terminal-audit.json','jobs-terminal.json','run-terminal.json','raw-log-manifest.json'] or f.name.startswith('git-commit-')):files['control440/'+f.name]=f
for f in C.glob('cia3-*'):
 if f.is_file() and (f.name.endswith('-raw.log') or f.name in ['cia3-classification.json','cia3-run.json','cia3-checkout.json']):files['control-a3/'+f.name]=f
payload={n:{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size} for n,f in files.items()};manifest=json.dumps({'schema':1,'payloads':payload},indent=2).encode();out=C/'m4-pr256-d38-terminal-ci-2026-10-18.tar.gz'
with tarfile.open(out,'w:gz') as tf:
 for n,f in sorted(files.items()):tf.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(manifest);tf.addfile(info,io.BytesIO(manifest))
with tarfile.open(out) as tf:
 ms=tf.getmembers();assert len(ms)==len(files)+1==len(set(m.name for m in ms))
 for m in ms:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='MANIFEST.json':assert H(tf.extractfile(m).read())==payload[m.name]['sha256']
res={'archive':str(out),'sha256':H(out.read_bytes()),'members':len(files)+1,'payloads':len(files),'bytes':out.stat().st_size,'review':str(P/'independent-terminal-review.json')};(P/'ci-package-result.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2));print(json.dumps(result['comparison_to_a3'],indent=2))
