# PR256 d38 terminal CI

Run 39149952174 completed failure. Foundation:398Rust pass executions/0fail/1ignore and353Python passes; inventory, bootstrap reproduction/execution, library/binary/example/doc steps all successful. Integration:124PASS18fuelFAIL0ignored,31/251targets completed,220unexecuted, no started unfinished. All eight shards fail; aggregate test gate fails because integration result failed. No compile/provenance/semantic assertion failure observed.

Nine actual checkout proofs: synthetic3fc3004ce1d084b3b97d135093bee46430ce8827 tree b9d2e131a1217e32888deefe161f2176fb3f2873 equals d38 head tree. This is tree equality, not a claim that checkout SHA was headline d38 or that a postcheckout source freeze ran in CI.

All18failed names/class/stage/span match a3 CI38908029824. No a3 observed-pass name now fails. Relative to canceled440,17same failures and one newly observed constructor failure(607..636 caller&env), already failed in a3; not evidence of a new regression. No old failed name observed resolved. 440 incomplete coverage retained separately.

Full exact names/stages/spans, raw SHA hashes, target inventory and proofs are in independent-terminal-review.json. The public-record authored-contract test's multiline error explicitly ends in all fuel consumed at453..489; the word Semantic in its wrapper does not establish a semantic assertion failure.

No local baseline result is included or inferred. Baseline43114 remains root-owned/live. No reruns/cancels/builds/source mutations.
