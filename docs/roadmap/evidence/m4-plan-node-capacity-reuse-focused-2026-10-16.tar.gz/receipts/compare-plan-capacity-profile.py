from pathlib import Path
import re,json
c=Path('/home/bobby/.cache/suss-m4-work');before=(c/'definition-initializer-declaration-profile.log').read_text().splitlines();after=(c/'plan-capacity-declaration-profile.log').read_text().splitlines()
labels=['metadata-graph start','metadata-declaration suss.core/*print-dup* start','metadata-declaration suss.core/->ArrayChunk start','metadata-declaration suss.core/->RecordIter definition-origin','metadata-declaration suss.core/->RecordIter finished','metadata-declaration suss.core/->RedNode start']
rows=[]
for label in labels:
 a=[int(l.rsplit(': ',1)[1]) for l in before if l.startswith(label)];b=[int(l.rsplit(': ',1)[1]) for l in after if l.startswith(label)]
 if a and b:rows.append({'boundary':label,'before':a[-1],'after':b[-1],'net_remaining_gain':b[-1]-a[-1]})
previous=None;cliffs=[];active=False
for line in after:
 if line.startswith('macro-fuel user/core-file start:'):active=True
 if active and line.startswith('raw-key-profile '):
  row={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}
  if previous:cliffs.append({'before':previous,'after':row,'intern_delta':row['intern']-previous['intern'],'head_insert_delta':row['head_insert']-previous['head_insert']})
  previous=row
state={'base':'867451d','before_log':'definition-initializer-declaration-profile.log','after_log':'plan-capacity-declaration-profile.log','matched_boundaries':rows,'largest_head_growth_intervals':sorted(cliffs,key=lambda r:-r['head_insert_delta'])[:3],'before_failure':'->RedNode start, graph preparation','after_failure':'-drop definition-form planning, graph preparation','limits':['Neither declaration fixture nor exact core-environment target passes.','Native retained/discarded fixture uses NEW reset tariffs on BOTH sides; not net versus 867.','Matched profile boundaries include actual new clear/publication costs and are net versus 867.','Full deficit includes unexecuted preparation/materialization/certification and remains unknown.','No full baseline, quota change or issue acceptance claim.']}
(c/'plan-capacity-profile-comparison.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state,indent=2))
