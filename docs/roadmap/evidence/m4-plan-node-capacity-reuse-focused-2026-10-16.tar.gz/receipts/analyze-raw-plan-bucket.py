from pathlib import Path
import re,json,collections
c=Path('/home/bobby/.cache/suss-m4-work');lines=(c/'raw-plan-bucket-profile.log').read_text().splitlines();runs=[];current=None;decl=None;stage=None
keys=['total','node_alloc','node_reloc','edge_alloc','edge_reloc','stack_alloc','stack_reloc','encoding','intern','other','visits']
def zero():return {k:0 for k in keys}|{'plans':0}
def add(dst,row):
 for k in keys:dst[k]+=int(row[k])
 dst['plans']+=1
for line in lines:
 m=re.match(r'macro-fuel (\S+) start: (\d+)',line)
 if m:current={'macro':m[1],'start':int(m[2]),'buckets':zero(),'preparation':zero(),'declarations':{},'graph_stages':{}};runs.append(current);decl=None;stage=None
 if current is None:continue
 m=re.match(r'metadata-graph (\S+).*: (\d+)',line)
 if m:stage=m[1];current['graph_stages'][stage]=int(m[2])
 m=re.match(r'metadata-declaration (\S+) (\S+): (\d+)',line)
 if m:
  decl=m[1];d=current['declarations'].setdefault(decl,{'stages':{},'buckets':zero()});d['stages'][m[2]]=int(m[3])
 if line.startswith('raw-plan-buckets '):
  row=dict(re.findall(r'(\w+)=([^ ]+)',line));add(current['buckets'],row)
  if stage=='start':add(current['preparation'],row)
  if decl is not None and stage=='start':add(current['declarations'][decl]['buckets'],row)
for run in runs:
 arrow=zero()
 for name,d in run['declarations'].items():
  if name.startswith('suss.core/->'):
   for k in keys+['plans']:arrow[k]+=d['buckets'][k]
 run['generated_constructors']=arrow
 for field in ['buckets','preparation','generated_constructors']:
  b=run[field];assert b['total']==sum(b[k] for k in ['node_alloc','node_reloc','edge_alloc','edge_reloc','stack_alloc','stack_reloc','encoding','intern','other'])
# Diagnostic must preserve all existing charged-stage observations exactly.
pattern=re.compile(r'^(?:macro-fuel |metadata-(?:graph |declaration |initializer ))')
before=[l for l in (c/'definition-initializer-declaration-profile.log').read_text().splitlines() if pattern.match(l)]
after=[l for l in lines if pattern.match(l)]
result={'runs':runs,'existing_trace_identical':before==after,'existing_trace_before_count':len(before),'existing_trace_after_count':len(after),'limits':['Counts only successful charges, rejected request partial consumption excluded.','Core namespace first appears on final invocation; no second full-core invocation completes.','Full deficit beyond the exhausted prefix is unknown, not zero.']}
(c/'raw-plan-bucket-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'trace_identical':result['existing_trace_identical'],'runs':[{k:v for k,v in r.items() if k!='declarations'} for r in runs]},indent=2))
