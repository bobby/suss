(ns suss-oracle.boxed-integer-bits)
(def cached_integer_saved (unsigned-bit-shift-right -1 0))
(defn -main [] (println (.stringify js/JSON (into-array [
(let [x (unsigned-bit-shift-right -1 0) alias x read-x (fn [] x) a (bit-xor x x) captured (read-x) b (bit-and x 255)] (and (identical? x alias) (= captured 4294967295) (= a 0) (= b 255) (= x 4294967295)))
(let [events (atom []) x (int 7) y (js-obj "valueOf" (fn [] (swap! events conj :convert) 3)) a (bit-xor x (do (swap! events conj :evaluate) y)) b (bit-or x 0)] (and (= a 4) (= b 7) (= @events [:evaluate :convert]) (= x 7)))
(let [x (unsigned-bit-shift-right -1 0) recur-call (fn walk [n] (if (= n 0) 3 (walk (dec n)))) a (bit-xor x (recur-call 3)) b (bit-and x 255)] (and (= a -4) (= b 255) (= x 4294967295)))
(let [a (bit-xor cached_integer_saved 0)] (and (= cached_integer_saved 4294967295) (= a -1)))
]))))
(set! *main-cli-fn* -main)
