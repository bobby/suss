use suss_cli::portable_session::Session;
use wasmtime::Val;

#[test]
fn bitwise_hash_match_independently_decoded_primary_observations_after_gc() {
    let corpus: serde_json::Value = serde_json::from_str(include_str!(
        "../../../tests/oracle/bitwise-hash-cases.json"
    ))
    .unwrap();
    let cases = corpus["cases"].as_array().unwrap();
    assert_eq!(cases.len(), 70);
    let mut session = Session::new().unwrap();
    session
        .eval(include_str!("../../../runtime/core-import/suss/core.sus"))
        .unwrap();
    session
        .enter_namespace("suss-oracle.bitwise-hash-cases")
        .unwrap();
    let mut ids = std::collections::BTreeSet::new();
    let mut failures = Vec::new();
    for case in cases {
        let id = case["id"].as_str().unwrap();
        assert!(ids.insert(id));
        let source = case["source"].as_str().unwrap();
        let value = match session.eval(source) {
            Ok(value) => value,
            Err(error) => {
                failures.push(format!("{id}: {source}: {error:?}"));
                continue;
            }
        };
        let actual = match case["expected"]["tag"].as_str().unwrap() {
            "f64" => {
                let bits = session
                    .inspect(&value, |mut store, value| {
                        let object = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                        let fields = object.fields(&mut store)?.collect::<Vec<_>>();
                        let [Val::F64(bits)] = fields.as_slice() else {
                            panic!("Number layout");
                        };
                        Ok(*bits)
                    })
                    .unwrap();
                serde_json::json!({"tag":"f64", "bits":format!("{bits:016x}")})
            }
            "nil" => {
                session
                    .inspect(&value, |store, value| {
                        assert_eq!(
                            value
                                .unwrap_anyref()
                                .unwrap()
                                .as_i31(&store)?
                                .unwrap()
                                .get_u32(),
                            0
                        );
                        Ok(())
                    })
                    .unwrap();
                serde_json::json!({"tag":"nil"})
            }
            "bool" => {
                let boolean = session
                    .inspect(&value, |store, value| {
                        let sentinel = value
                            .unwrap_anyref()
                            .unwrap()
                            .as_i31(&store)?
                            .unwrap()
                            .get_u32();
                        match sentinel {
                            2 => Ok(false),
                            4 => Ok(true),
                            n => panic!("Boolean {n}"),
                        }
                    })
                    .unwrap();
                serde_json::json!({"tag":"bool", "value":boolean})
            }
            "string" => {
                let units = session
                    .inspect(&value, |mut store, value| {
                        let array = value.unwrap_anyref().unwrap().as_array(&store)?.unwrap();
                        Ok(array
                            .elems(&mut store)?
                            .map(|v| v.unwrap_i32() as u16)
                            .collect::<Vec<_>>())
                    })
                    .unwrap();
                serde_json::json!({"tag":"string", "units":units})
            }
            tag => panic!("unsupported Bitwise hash observation {tag}"),
        };
        if actual != case["expected"] {
            failures.push(format!(
                "{id}: {source}: actual {actual}, expected {}",
                case["expected"]
            ));
        }
        session.collect().unwrap();
    }
    assert!(
        failures.is_empty(),
        "{} failing observations:\n{}",
        failures.len(),
        failures.join("\n")
    );
}

fn bitwise_number(session: &mut Session, source: &str) -> f64 {
    let value = session.eval(source).unwrap();
    session
        .inspect(&value, |mut store, value| {
            let object = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
            Ok(object.field(&mut store, 0)?.unwrap_f64())
        })
        .unwrap()
}

#[test]
fn bitwise_bad_arities_fail_with_spans_and_no_partial_publication() {
    use suss_cli::portable_session::SessionError;
    let mut session = Session::new().unwrap();
    for body in [
        "(int)",
        "(int 1 2)",
        "(bit-and)",
        "(bit-and 7)",
        "(bit-not 1 2)",
        "(unsigned-bit-shift-right 1)",
    ] {
        let source = format!("(do (def bitwise_unpublished 7) {body})");
        let SessionError::Compile(error) = session.eval(&source).unwrap_err() else {
            panic!("expected compile error: {source}");
        };
        assert!(error.span.start < error.span.end && error.span.end <= source.len());
        assert!(session.eval("bitwise_unpublished").is_err());
        assert_eq!(bitwise_number(&mut session, "(int 4294967295)"), -1.0);
    }
    // The accepted arity contract diagnoses these separately from pinned JS
    // captured wrappers' off-arity fill/ignore behavior; no differential claim.
    for source in [
        "(let [f int] (f))",
        "(let [f int] (f 1 2))",
        "(let [f bit-and] (f 1))",
        "(imul 1)",
    ] {
        assert!(session.eval(source).is_err(), "{source}");
        assert_eq!(bitwise_number(&mut session, "(imul 7 3)"), 21.0);
    }
}

#[test]
fn bitwise_macro_folds_preserve_throw_order_and_computed_calls_evaluate_all_args() {
    let mut session = Session::new().unwrap();
    session.eval("(def bitwise_trace 0)").unwrap();
    // Object coercion is explicitly unsupported. Nested macro pair conversion
    // fails before the third operand; computed function arguments precede it.
    for (source, expected) in [
        ("(bit-or (fn [] 0) 1 (do (set! bitwise_trace 7) 2))", 0.0),
        (
            "(let [f bit-or] (f (fn [] 0) 1 (do (set! bitwise_trace 7) 2)))",
            7.0,
        ),
    ] {
        session.eval("(set! bitwise_trace 0)").unwrap();
        assert!(session.eval(source).is_err());
        assert_eq!(bitwise_number(&mut session, "bitwise_trace"), expected);
        session.collect().unwrap();
        assert_eq!(bitwise_number(&mut session, "(bit-or 1 2 4)"), 7.0);
    }
}

#[test]
fn bitwise_alias_exclusion_and_both_compilation_phases_are_explicit() {
    use suss_compile::portable::{
        prepare_fragment,
        resolve::{Environment, Phase},
    };
    let mut session = Session::new().unwrap();
    session
        .eval("(ns bitwise.alias (:require [cljs.core :as c]))")
        .unwrap();
    assert_eq!(bitwise_number(&mut session, "(c/bit-or 1 2 4)"), 7.0);
    session.eval("(ns bitwise.excluded (:refer-clojure :exclude [bit-or])) (def bit-or (fn [x y] (+ x y)))").unwrap();
    assert_eq!(bitwise_number(&mut session, "(bit-or 1 1)"), 2.0);
    assert_eq!(bitwise_number(&mut session, "(cljs.core/bit-or 1 1)"), 1.0);
    for phase in [Phase::Runtime, Phase::Macro] {
        let fragment = prepare_fragment("(bit-or 1 2 4)", &Environment::default(), phase).unwrap();
        suss_compile::runtime_abi::verify_artifact(
            &fragment.wasm,
            &suss_compile::runtime_abi::Manifest::default(),
        )
        .unwrap();
    }
}

#[test]
fn captured_variadic_bitwise_body_reads_the_current_tail_reducer_once() {
    let mut session = Session::new().unwrap();
    let corpus: serde_json::Value = serde_json::from_str(include_str!(
        "../../../tests/oracle/bitwise-capture-observations.json"
    ))
    .unwrap();
    for case in corpus["cases"].as_array().unwrap() {
        // Four pinned public wrapper errors remain separate observations, never
        // counted as equal public-source matches. The five body diagnostics use
        // development-only JS to inspect the retained implementation directly.
        let actual = bitwise_number(&mut session, case["native-source"].as_str().unwrap());
        assert_eq!(
            format!("{:016x}", actual.to_bits()),
            case["expected-native"]["bits"].as_str().unwrap(),
            "{}",
            case["id"]
        );
        session.collect().unwrap();
    }
    assert_eq!(bitwise_number(&mut session, "(bit-or 1 2 4)"), 7.0);
}

#[test]
fn variadic_bitwise_reducers_preserve_gc_errors_and_dynamic_recovery() {
    use suss_cli::portable_session::SessionError;
    let mut session = Session::new().unwrap();
    session.eval("(def bitwise_saved bit-or)").unwrap();
    session.collect().unwrap();
    // No tail arguments: the original pair succeeds without reading a reducer.
    assert_eq!(
        bitwise_number(
            &mut session,
            "(with-redefs [cljs.core/bit-or nil] (bitwise_saved 1 2))"
        ),
        3.0
    );
    for replacement in ["nil", "(fn [x] x)", "(fn [x y] (throw 29))"] {
        let source =
            format!("(with-redefs [cljs.core/bit-or {replacement}] (bitwise_saved 1 2 4))");
        assert!(
            matches!(session.eval(&source), Err(SessionError::Language(_))),
            "{source}"
        );
        session.collect().unwrap();
        assert_eq!(bitwise_number(&mut session, "(bitwise_saved 1 2 4)"), 7.0);
    }
    assert_eq!(
        bitwise_number(
            &mut session,
            "(binding [cljs.core/bit-or (fn [x y] (+ x y 100))] (bitwise_saved 1 2 4))"
        ),
        107.0
    );
    session.collect().unwrap();
    assert_eq!(bitwise_number(&mut session, "(bitwise_saved 1 2 4)"), 7.0);
}

#[test]
fn integer_chains_preserve_signed_unsigned_shift_and_nonfinite_boundaries() {
    let cases: [(&str, f64); 20] = [
        ("(bit-xor (unsigned-bit-shift-right -1 0) 0)", -1.0),
        ("(unsigned-bit-shift-right (bit-xor -1 0) 0)", 4294967295.0),
        ("(int (unsigned-bit-shift-right -2147483648 0))", -2147483648.0),
        ("(bit-or (bit-and-not 4294967295 2147483647) 1)", -2147483647.0),
        ("(bit-flip (bit-clear (bit-set 0 31) 0) 31)", 0.0),
        ("(bit-and (bit-not 0) 2147483648)", -2147483648.0),
        ("(bit-xor (bit-shift-left 3 0) 0)", 3.0),
        ("(bit-xor (bit-shift-left 3 31) 0)", -2147483648.0),
        ("(bit-xor (bit-shift-left 3 32) 0)", 3.0),
        ("(bit-xor (bit-shift-left 3 33) 0)", 6.0),
        ("(bit-or (bit-shift-right -3 1) 0)", -2.0),
        ("(bit-xor (bit-shift-left 3 1.9) 0)", 6.0),
        ("(bit-xor (bit-shift-left 3 -0.9) 0)", 3.0),
        ("(bit-xor (bit-shift-left 3 (/ 0 0)) 0)", 3.0),
        ("(bit-xor (bit-shift-left 3 (/ 1 0)) 0)", 3.0),
        ("(bit-xor (int (/ 0 0)) 7)", 7.0),
        ("(bit-xor (int (/ 1 0)) 7)", 7.0),
        ("(bit-xor (int (/ -1 0)) 7)", 7.0),
        ("(bit-xor (int 4294967297.9) 7)", 6.0),
        ("(bit-or (int -0.0) 0)", 0.0),
    ];
    for mut session in [Session::new_repl().unwrap(), Session::new_macro().unwrap()] {
        for (source, expected) in cases {
            let value = session.eval(source).unwrap();
            session.collect().unwrap();
            let actual = session.inspect(&value, |mut store, value| {
                let object = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                Ok(object.field(&mut store, 0)?.unwrap_f64())
            }).unwrap();
            assert_eq!(actual.to_bits(), expected.to_bits(), "{source}");
        }
    }
}

fn bitwise_true_after_gc(session: &mut Session, source: &str) {
    let value = session.eval(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
    session.collect().unwrap();
    session.inspect(&value, |store, value| {
        assert_eq!(value.unwrap_anyref().unwrap().as_i31(&store)?.unwrap().get_u32(), 4, "{source}");
        Ok(())
    }).unwrap();
}

#[test]
fn integer_chains_keep_valueof_at_the_original_position_and_preserve_throw_order() {
    let cases = [
        // Both operands exist before the producer. Conversion remains x then y.
        r#"(let [events (atom []) x (js-obj "valueOf" (fn [] (swap! events conj :x) 7)) y (js-obj "valueOf" (fn [] (swap! events conj :y) 3))]
            (and (= (bit-xor (int x) y) 4) (= @events [:x :y])))"#,
        // The effectful second source expression is a fusion barrier. The first
        // primitive must already have converted x before evaluating that effect.
        r#"(let [events (atom []) x (js-obj "valueOf" (fn [] (swap! events conj :x) 7)) y (js-obj "valueOf" (fn [] (swap! events conj :y) 3))]
            (and (= (bit-xor (int x) (do (swap! events conj :evaluate-y) y)) 4)
                 (= @events [:x :evaluate-y :y])))"#,
        r#"(let [events (atom []) x (js-obj "valueOf" (fn [] (swap! events conj :x) (throw 17))) y (js-obj "valueOf" (fn [] (swap! events conj :y) 3))]
            (try (bit-xor (int x) (do (swap! events conj :evaluate-y) y)) false
                 (catch :default e (and (= e 17) (= @events [:x])))))"#,
        r#"(let [events (atom []) x (js-obj "valueOf" (fn [] (swap! events conj :x) 7)) y (js-obj "valueOf" (fn [] (swap! events conj :y) (throw 19)))]
            (try (bit-xor (int x) y) false
                 (catch :default e (and (= e 19) (= @events [:x :y])))))"#,
    ];
    for mut session in [Session::new_repl().unwrap(), Session::new_macro().unwrap()] {
        for source in cases { bitwise_true_after_gc(&mut session, source); }
        assert_eq!(bitwise_number(&mut session, "(bit-xor (int 7) 3)"), 4.0);
    }
}

#[test]
fn integer_results_escape_through_multiple_uses_branches_captures_and_shadowed_calls() {
    let cases = [
        "(let [x (unsigned-bit-shift-right -1 0)] (and (= x 4294967295) (= (bit-xor x 0) -1)))",
        "(let [x (unsigned-bit-shift-right -1 0) read-x (fn [] x)] (and (= (read-x) 4294967295) (= (bit-xor x 0) -1)))",
        "(let [x (unsigned-bit-shift-right -1 0)] (= (if (> 1 0) x nil) 4294967295))",
        "(let [bit-xor (fn [a b] (+ a b))] (= (bit-xor (int -1) 3) 2))",
        "(let [int (fn [x] 42)] (= (bit-xor (int 0) 3) 41))",
        "(let [bit-shift-left (fn [x n] 17)] (= (bit-xor (bit-shift-left 1 2) 1) 16))",
        // Public predicate results remain booleans; Test is not a raw producer.
        "(and (bit-test (bit-shift-left 1 31) 31) (not (bit-test 0 31)))",
    ];
    for mut session in [Session::new_repl().unwrap(), Session::new_macro().unwrap()] {
        for source in cases { bitwise_true_after_gc(&mut session, source); }
    }
}

#[test]
fn cached_integer_bits_preserve_alias_capture_effects_and_recursive_calls() {
    for mut session in [Session::new_repl().unwrap(), Session::new_macro().unwrap()] {
        // Retain the actual Number through a global, collect it, then compare
        // aliases and consume it again. Reloaded globals have no planner facts.
        session.eval("(def cached_integer_saved (unsigned-bit-shift-right -1 0))").unwrap();
        session.collect().unwrap();
        for source in [
            "(let [x (unsigned-bit-shift-right -1 0) alias x read-x (fn [] x) a (bit-xor x x) captured (read-x) b (bit-and x 255)] (and (identical? x alias) (= captured 4294967295) (= a 0) (= b 255) (= x 4294967295)))",
            r#"(let [events (atom []) x (int 7) y (js-obj "valueOf" (fn [] (swap! events conj :convert) 3)) a (bit-xor x (do (swap! events conj :evaluate) y)) b (bit-or x 0)] (and (= a 4) (= b 7) (= @events [:evaluate :convert]) (= x 7)))"#,
            "(let [x (unsigned-bit-shift-right -1 0) recur-call (fn walk [n] (if (= n 0) 3 (walk (dec n)))) a (bit-xor x (recur-call 3)) b (bit-and x 255)] (and (= a -4) (= b 255) (= x 4294967295)))",
            "(let [a (bit-xor cached_integer_saved 0)] (and (= cached_integer_saved 4294967295) (= a -1)))",
        ] { bitwise_true_after_gc(&mut session, source); }
    }
}
