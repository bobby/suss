from pathlib import Path
import os,re,json,hashlib,subprocess,time
cache=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace')
pinroot=Path('/home/bobby/Work/code/bobby/suss-m4-unboxed-bitwise-ssa/clojurescript')
run=cache/'boxed-integer-bits-oracle';run.mkdir(exist_ok=False)
source=root/'crates/suss-cli/tests/portable_bitwise_hash.rs'
text=source.read_text().split('fn cached_integer_bits_preserve_alias_capture_effects_and_recursive_calls() {',1)[1]
cases=[]
for line in text.splitlines():
 line=line.strip()
 if line.startswith('r#"'): cases.append(line[3:line.rindex('"#')])
 elif line.startswith('"'): cases.append(json.loads(line.rstrip(',')))
assert len(cases)==4
pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=pinroot,text=True).strip()
assert pin=='c4295f303100bbf5afac449242d30bca1126f1a1'
(run/'src/suss_oracle').mkdir(parents=True)
(run/'deps.edn').write_text('{:paths ["src"] :mvn/local-repo "/tmp/suss-oracle-m2" :deps {org.clojure/clojure {:mvn/version "1.12.1"} org.clojure/clojurescript {:local/root '+json.dumps(str(pinroot))+'}}}\n')
cljs='(ns suss-oracle.boxed-integer-bits)\n(def cached_integer_saved (unsigned-bit-shift-right -1 0))\n(defn -main [] (println (.stringify js/JSON (into-array [\n'+'\n'.join(cases)+'\n]))))\n(set! *main-cli-fn* -main)\n'
(run/'src/suss_oracle/boxed_integer_bits.cljs').write_text(cljs)
(run/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(run/'rust-source.rs').write_bytes(source.read_bytes())
state={'pin':pin,'rust_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cases':len(cases),'driver_pid':os.getpid(),'stages':[]}
def save(): (run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
env=os.environ.copy();env.update(JAVA_HOME='/home/bobby/.cache/suss-m4-oracle-tools/jdk-21.0.8+9-jre',CLJ_CONFIG='/tmp/suss-oracle-clojure-config',CLJ_CACHE='/tmp/suss-oracle-clojure-cache')
commands=[('compile',['/home/bobby/.cache/suss-m4-oracle-tools/bin/clojure','-J-Xmx1g','-J-XX:ActiveProcessorCount=2','-Srepro','-M','-m','cljs.main','-co','{:force true :cache-analysis false :target :nodejs :output-to "out/main.js" :output-dir "out/cljs" :optimizations :none :source-map false}','-c','suss-oracle.boxed-integer-bits']),('observe',['node','out/main.js'])]
for name,cmd in commands:
 row={'name':name,'command':cmd};state['stages'].append(row);save();start=time.monotonic()
 with (run/(name+'.stdout')).open('w') as out,(run/(name+'.stderr')).open('w') as err:
  proc=subprocess.Popen(cmd,cwd=run,env=env,stdout=out,stderr=err);row['pid']=proc.pid;save();row['exit']=proc.wait()
 row['seconds']=time.monotonic()-start;save()
 if row['exit']:break
if state['stages'][-1]['name']=='observe' and state['stages'][-1]['exit']==0:
 values=json.loads((run/'observe.stdout').read_text());state['observations']=values;state['all_true']=values==[True]*4
state['source_unchanged']=hashlib.sha256(source.read_bytes()).hexdigest()==state['rust_sha256'];state['terminal']=True;save()
print(json.dumps(state))
