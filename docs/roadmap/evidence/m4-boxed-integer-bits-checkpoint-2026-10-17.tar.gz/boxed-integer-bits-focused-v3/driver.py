"""Prepared only. Root must supply final reviewed source binding and --execute.
No Cargo/process/lock/snapshot action occurs on import or without --execute.
"""
from pathlib import Path
import argparse,collections,fcntl,hashlib,json,os,re,shutil,subprocess,time
CACHE=Path(__file__).resolve().parent
BOOT={f'runtime/bootstrap/{phase}.{ext}' for phase in ('macro','runtime') for ext in ('wasm','json')}
COUNT={'bitwise-ir':5,'artifact-cache':12,'cli-bitwise':10,'object-coercion':2,'compiled-when-let':6,'compiled-let-destructuring':5,'pinned-when-let':1,'regression-witnesses':3}
WITNESSES=['public_record_nominal_equality_and_predicate_decode_after_gc_in_both_phases','public_records_execute_jank_and_authored_contracts_with_two_nominal_classes','public_reduce_dispatch_and_source_order_match_pinned_cljs_after_gc']
def sha(data):return hashlib.sha256(data).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def tests(p):
    s=p.read_text();assert not re.search(r'^\s*#\[ignore',s,re.M),f'Ignored source requires explicit review: {p}'
    return re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',s)
def stages(root):
    common=['cargo','test','--locked'];tail=['--','--test-threads=1','--nocapture']
    compiler=['-p','suss-compile'];cli=['-p','suss-cli']
    return [
      ('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),
      ('bitwise-ir',common+compiler+['--test','portable_bitwise']+tail),
      ('artifact-cache',common+compiler+['--lib','portable::artifact_cache::tests::']+tail),
      ('cli-bitwise',common+cli+['--test','portable_bitwise_hash']+tail),
      ('object-coercion',common+cli+['--test','portable_object_coercion']+tail),
      ('compiled-when-let',common+cli+['--test','compiled_when_let']+tail),
      ('compiled-let-destructuring',common+cli+['--test','compiled_let_destructuring']+tail),
      ('pinned-when-let',common+compiler+['--test','clojure_test_suite','pinned_when_let_complete_body_matches_reference','--','--exact','--test-threads=1','--nocapture']),
      ('regression-witnesses',common+cli+['--no-fail-fast','--test','compiled_public_records','--test','portable_reduction_dispatch','--','--exact','--test-threads=1','--nocapture']+WITNESSES)]
def expected_names(root):
    decoder=tests(root/'crates/suss-compile/tests/support/portable_decode.rs');assert len(decoder)==3
    names={
      'bitwise-ir':tests(root/'crates/suss-compile/tests/portable_bitwise.rs'),
      'artifact-cache':tests(root/'crates/suss-compile/src/portable/artifact_cache.rs'),
      'cli-bitwise':tests(root/'crates/suss-cli/tests/portable_bitwise_hash.rs'),
      'object-coercion':tests(root/'crates/suss-cli/tests/portable_object_coercion.rs'),
      'compiled-when-let':tests(root/'crates/suss-cli/tests/compiled_when_let.rs')+decoder,
      'compiled-let-destructuring':tests(root/'crates/suss-cli/tests/compiled_let_destructuring.rs')+decoder,
      'pinned-when-let':['pinned_when_let_complete_body_matches_reference'],
      'regression-witnesses':WITNESSES}
    for stage,want in COUNT.items():assert len(names[stage])==want,(stage,names[stage],want)
    return names

def closure(root,packet):
    # Rebuild actual merged-input closure; old2917 paths are additional seeds,
    # never the sole authority. Preserve full when-let provenance/oracle sources.
    tracked=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).decode().split('\0')
    prefixes=('crates/','runtime/','scripts/','tests/','vendor/','docs/compatibility/')
    paths={n for n in tracked if n and (n.startswith(prefixes) or n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml','.github/workflows/ci.yml')) and not n.endswith(('.tar.gz','.zip')) and not any(part in ('target','__pycache__','.git') for part in Path(n).parts) and (root/n).is_file()}
    old=json.loads((CACHE/'unboxed-bitwise-ssa-preservation/terminal-freeze.json').read_text())
    removed=set(packet.get('removed_files',[]))
    for n in old:
        if (root/n).is_file():paths.add(n)
        else:assert n in removed,f'Old input absent without reviewed removal: {n}'
    paths.update(packet['files'])
    for n in ['clojurescript/deps.edn','clojurescript/project.clj','clojurescript/src/main/cljs/cljs/core.cljs','clojurescript/src/main/clojure/cljs/core.cljc']:
        assert (root/n).is_file(),f'Missing exact pinned prerequisite: {n}';paths.add(n)
    required=['crates/suss-cli/tests/compiled_when_let.rs','crates/suss-cli/tests/compiled_let_destructuring.rs','crates/suss-compile/src/portable_when_let.rs','scripts/check_when_let_provenance.py','docs/compatibility/when-let/provenance.json','tests/oracle/when-let-observations.json','tests/oracle/when-let-validation-observations.json','runtime/core-import/manifest.json','docs/compatibility/reviews.edn']
    for n in required:assert n in paths,f'Merged267 input missing: {n}'
    assert any(n.startswith('docs/compatibility/when-let/oracle/') and n.endswith('.cljs') for n in paths)
    return sorted(paths)

def parse_results(text):
    starts=list(re.finditer(r'^test (\S+) \.\.\.',text,re.M));records=[]
    for i,m in enumerate(starts):
        segment=text[m.start():starts[i+1].start() if i+1<len(starts) else len(text)]
        status=re.findall(r'(?:^|\n)\s*(?:test \S+ \.\.\. )?(ok|FAILED|ignored)\s*(?=\n|$)',segment)
        assert status,('Missing terminal test status',m[1]);records.append({'name':m[1],'status':status[-1]})
    summaries=[dict(zip(('pass','fail','ignore'),map(int,r))) for r in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)]
    return records,summaries

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--plan',type=Path,default=CACHE/'boxed-integer-bits-focused-plan.json');ap.add_argument('--execute',action='store_true',help='Only after root explicitly authorizes final reviewed tuple');args=ap.parse_args()
    plan=json.loads(args.plan.read_text())
    if not args.execute:print('PREPARED ONLY: no Cargo/locks/processes/snapshots. Await root authorization and final packet/hash/base.');return
    for k in ('root','expected_base','packet_manifest','packet_manifest_sha256','root_launch_authorization'):
        assert plan.get(k),f'Unbound plan: {k}'
    root=Path(plan['root']);target=Path(plan['target']);run=Path(plan['run']);packet_path=Path(plan['packet_manifest']);assert sha(packet_path.read_bytes())==plan['packet_manifest_sha256'];packet=json.loads(packet_path.read_text())
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==plan['expected_base']
    assert not subprocess.check_output(['git','ls-files','-u'],cwd=root),'Unresolved merge: no producer'
    for n,h in packet['files'].items():assert sha((root/n).read_bytes())==h,('Reviewed source mismatch',n)
    names=expected_names(root);paths=closure(root,packet)
    assert subprocess.check_output(['git','-C',str(root/'clojurescript'),'rev-parse','HEAD'],text=True).strip()=='c4295f303100bbf5afac449242d30bca1126f1a1'
    leases=[]
    for name in ['.typed-scalar-witness.lease','.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease']:
        f=open(target/name,'a+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
        try:envb=(proc/'environ').read_bytes();exe=str((proc/'exe').resolve())
        except OSError:continue
        assert b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' not in envb and not exe.startswith(str(target)+'/'),f'Target live PID{proc.name}'
    run.mkdir(exist_ok=False);(run/'frozen/sha256').mkdir(parents=True)
    def freeze():return {n:sha((root/n).read_bytes()) for n in paths}
    def snapshot(label,values):
        dump(run/(label+'-freeze.json'),values)
        for n,h in values.items():
            dest=run/'frozen/sha256'/h
            if not dest.exists():shutil.copyfile(root/n,dest)
            assert sha(dest.read_bytes())==h
    expected=freeze();snapshot('before',expected);shutil.copyfile(__file__,run/'driver.py');shutil.copyfile(args.plan,run/'bound-plan.json');shutil.copyfile(packet_path,run/'reviewed-source-manifest.json');dump(run/'source-derived-selection.json',names)
    env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target),PYTHONDONTWRITEBYTECODE='1')
    for k in list(env):
        if k.startswith('SUSS_') and (k.endswith('TRACE') or 'CAPTURE' in k):env.pop(k)
    state={'driver_pid':os.getpid(),'root':str(root),'base':plan['expected_base'],'input_count':len(paths),'environment':{'jobs':1,'rayon':1,'test_threads':1,'RUSTFLAGS':'inherited, not assigned'},'current':None,'stages':[],'limits':'Semantic test failures retained and independent gates continue. Stop bootstrap failure, source mutation, compile/selection/observation anomalies. No quota/tariff/fixture changes. Merge267 support/provenance/oracle inputs frozen; CAS snapshots avoid archive cloning.'}
    save=lambda:dump(run/'receipt.json',state)
    try:
        for name,cmd in stages(root):
            assert freeze()==expected,('Source changed before',name)
            row={'name':name,'command':cmd};state['stages'].append(row);state['current']=name;save();started=time.monotonic();stage_env=env.copy()
            if name=='pinned-when-let':stage_env['SUSS_WHEN_LET_CAPTURE']=str(run/'when-let-capture')
            with (run/(name+'.log')).open('w') as out:
                proc=subprocess.Popen(cmd,cwd=root,env=stage_env,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
            after=freeze();changed=[n for n in paths if after[n]!=expected[n]];row.update(exit=code,seconds=time.monotonic()-started,changed=changed);save()
            if name=='bootstrap':
                assert code==0, 'Bootstrap failed; stop before Session tests'
                assert set(changed)<=BOOT,('Unexpected bootstrap mutation',changed)
                expected=after;snapshot('after-bootstrap',expected);continue
            assert not changed,('Frozen source changed',name,changed)
            records,summaries=parse_results((run/(name+'.log')).read_text(errors='replace'));row.update(records=records,summaries=summaries,expected_count=COUNT[name]);save()
            assert collections.Counter(r['name'].split('::')[-1] for r in records)==collections.Counter(names[name]),('Selection drift',name)
            total=collections.Counter()
            for r in summaries:total.update(r)
            assert total=={'pass':sum(r['status']=='ok' for r in records),'fail':sum(r['status']=='FAILED' for r in records),'ignore':0},('Summary/record anomaly',name,total)
            assert len(records)==COUNT[name] and code in (0,101) and (code==0)==(total['fail']==0),('Compile/process anomaly',name,code)
            if name=='pinned-when-let':
                # Preserve actual rows before any assertion; authored harness also
                # independently compares all12IDs/host values on success.
                obs=run/'when-let-capture/when-let-observations.json'
                if obs.exists():row['observation_sha256']=sha(obs.read_bytes());row['observed_assertion_ids']=[[a['test'],a['ordinal']] for a in json.loads(obs.read_text())['assertions']]
                if code==0:
                    want=[['clojure.core-test.when-let/test-when-let',i] for i in range(1,13)]
                    assert row.get('observed_assertion_ids')==want,'Missing/changed actual12assertion IDs'
            save() # Semantic failures deliberately do NOT break later gates.
    except BaseException as error:
        state['stopped_anomaly']=repr(error);raise
    finally:
        state['current']=None;state['final_changed']=[n for n,h in expected.items() if not (root/n).is_file() or sha((root/n).read_bytes())!=h];save()
        if not state['final_changed']:snapshot('terminal',freeze())
if __name__=='__main__':main()
