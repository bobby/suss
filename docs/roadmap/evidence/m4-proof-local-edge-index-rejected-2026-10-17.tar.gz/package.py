from pathlib import Path
import json,hashlib,subprocess,tarfile,io
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-proof-local-edge-index');run=cache/'native-proof-local-edge-index';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();freeze=json.loads((run/'after-freeze.json').read_text())
def batch(repo,items):
 requests=''.join(ref+'\n' for _,ref in items).encode();data=subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=requests);offset=0;result={}
 for path,ref in items:
  end=data.index(b'\n',offset);header=data[offset:end].decode();offset=end+1;parts=header.split();assert len(parts)==3 and parts[1]=='blob',(path,header);size=int(parts[2]);blob=data[offset:offset+size];offset+=size+1;result[path]=hashlib.sha256(blob).hexdigest()
 assert offset==len(data);return result
normal=[(p,head+':'+p) for p in freeze if not p.startswith('clojurescript/')];sub=[(p,'c4295f303100bbf5afac449242d30bca1126f1a1:'+p.removeprefix('clojurescript/')) for p in freeze if p.startswith('clojurescript/')];bound=batch(root,normal);bound.update(batch(root/'clojurescript',sub));mismatch=[p for p in freeze if freeze[p]!=bound[p]];assert not mismatch,mismatch
binding={'source_commit':head,'paths':len(freeze),'matches':len(freeze),'mismatches':mismatch,'submodule_pin':'c4295f303100bbf5afac449242d30bca1126f1a1','method':'git cat-file --batch actual committed blobs; four pinned submodule blobs separately'};(run/'committed-source-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
(run/'setup-failure-record.json').write_text(json.dumps({'attempt1':'Closure assertion2912 before Cargo: leaf submodule absent.','attempt2':'After pinned source symlink, closure assertion2914 before Cargo: enumerator omitted two supporting paths.','correction':'Union with exact prior2915 manifest plus newmodule produced2916. Both empty setup directories retained.','postexecution':'Leaf symlink repaired to independent local pinned clone; all2916 bytes unchanged; actual build-script fingerprint agrees with both bootstrap JSON files. No rerun or source changes.','host_finalizer':'SIGTERM only after all five child stages terminal; repeated per-path freeze bug preserved, one full external scan records final_changed[].'},indent=2)+'\n')
report=f'''# Rejected proof-local edge-membership experiment

Diagnostic source commit `{head}`, base19326ae. This entire candidate is PARKED, not intended for production integration or PR268. No PR, issue closure, milestone completion or full baseline claim. No further refinement was applied.

Actual bootstrap exits0 and only four outputs change. Index primitives3 + indexed-domain negatives2 + full-domain6 =11 pass executions,9 unique tests; default sourcechild0pass1fail, typed SessionError::Trap(Wasmtime OutOfFuel) at final-parent ledger publication, source_roots.rs951. Macro-source half unexecuted. Jobs1/Rayon1/test1, no RUSTFLAGS assignment, unchanged default quotas. All2916 inputs remain unchanged after bootstrap and bind byte-exactly to the committed source/submodule pin. No foundation/new full baseline was run for this rejected diagnostic.

Five Runtime materializations save173820, but later physical work regresses17832, leaving155988 more at final-parent entry (76024->232012). These are matched PREFIX deltas, not whole-request savings. Current separately published19326 fixed30M diagnostic costs11752345 per complete source-phase request, default deficit1752345. Candidate complete cost is not measured; do not infer its remaining gap by subtracting prefix improvement.

All24 physical passes have55 roots and real reference lookups: old edge897, new497, preparation1143 per pass =>743 regression each. Variant0 has24 passes at120 roots: old edge4849,new1446,preparation1966 =>1437 saving each. Full storage-and-edges intervals include construction, hashing, probes, stack init/handoff and immediate controls. Nested sums are never added to enclosing totals. This small and uneven improvement does not justify roughly500 lines of GC-sensitive machinery now. Lazy-first-reference cache proposal is UNAPPLIED and does not repair these reference-bearing55-root passes. Adaptive size threshold is an unmeasured alternative, not shipped code.

Archive preserves exact two source files/four bootstrap outputs in snapshots, before/after2916 closures, raw commands/logs and typed failures, initial setup failures, failed host-finalizer code and qualified external final scan, Git-plumbing repair, pinned supporting files, actual build-script output, model/design/source review packet and cache-only lazy proposal/parking decision. Source Carver approval14568e48 authorized isolated testing only; final artifact/head review remains separate. Root relayed parking decision applies to ENTIRE candidate. Original primary/class/whenlet baselines were not modified or restarted.

Limitations: first leaf setup used a symlink to exact pinned source, breaking ordinary Git status; repaired after execution without byte/fingerprint change. Initial independent Python fingerprint reconstruction failed and is NOT proof; actual existing compiled build script provides identity. Driver finalizer unnecessarily repeated freeze per path, terminated after every test process was terminal; one equivalent external scan completed and is explicit, not represented as normal driver exit. All raw outcomes preserved. Source-child expected negative Host errors are not reclassified as unexpected semantic failures. No total-gap/acceptance/speed claim.
'''
reportpath=cache/'proof-local-edge-index-report.md';reportpath.write_text(report)
entries={}
def addtree(label,directory):
 for p in sorted(directory.rglob('*')):
  if p.is_file():entries[label+'/'+str(p.relative_to(directory))]=p
for label,p in [('run',run),('source-review',cache/'proof-local-edge-index-review'),('unapplied-lazy-review',cache/'proof-local-edge-index-lazy-review')]:addtree(label,p)
for name in ['native-proof-local-edge-index-setup-failed','native-proof-local-edge-index-setup-failed-2']:
 addtree(name,cache/name)
entries['run-driver.py']=cache/'run-proof-local-edge-index.py';entries['package.py']=Path(__file__);entries['REPORT.md']=reportpath
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in entries.items()};manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode();dest=root/'docs/roadmap/evidence/m4-proof-local-edge-index-rejected-2026-10-17.tar.gz';dest.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(dest,'w:gz') as tar:
 for name,p in sorted(entries.items()):tar.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('SHA256-MANIFEST.json');info.size=len(manifest_bytes);tar.addfile(info,io.BytesIO(manifest_bytes))
result={'archive':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'payloads':len(entries),'members':len(entries)+1,'bytes':dest.stat().st_size,'source_commit':head,'binding':binding};(cache/'proof-local-edge-index-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
