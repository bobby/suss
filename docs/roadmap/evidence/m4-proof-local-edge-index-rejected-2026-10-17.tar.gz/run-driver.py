from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,fcntl
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-proof-local-edge-index');run=cache/'native-proof-local-edge-index';run.mkdir(exist_ok=False)
lease=open(cache/'m4-cost-diagnostic-target/.proof-local-edge-index.lease','w');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);lease.write(str(os.getpid()));lease.flush()
tracked=subprocess.check_output(['git','ls-files','--recurse-submodules'],cwd=root,text=True).splitlines()
paths={p for p in tracked if (root/p).is_file() and (p.startswith(('crates/','runtime/','scripts/','tests/','vendor/','docs/compatibility/','.cargo/','.github/workflows/')) or p in ['Cargo.toml','Cargo.lock','clojurescript/deps.edn','clojurescript/project.clj'])}
paths.update(p for p in json.loads((cache/'when-let-reconcile-after/after-freeze.json').read_text()) if (root/p).is_file());paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
paths.update(json.loads((cache/'native-fresh-class-complete-cost/before-freeze.json').read_text()))
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snapshot(label,data):
 (run/(label+'-freeze.json')).write_text(json.dumps(data,indent=2))
 for p in data:
  dest=run/label/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,dest)
expected=freeze();assert len(expected)>=2916,len(expected);assert any(p.endswith('/write_domain/edge_index.rs') for p in expected);snapshot('before',expected)
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(cache/'m4-cost-diagnostic-target'))
for k in list(env):
 if k.startswith('SUSS_') and k.endswith('TRACE'):env.pop(k)
base=['cargo','test','-p','suss-compile','--locked','--lib'];tail=['--','--test-threads=1','--nocapture']
commands=[('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('index',base+['portable_session::write_domain::edge_index::tests::']+tail),('indexed-domains',base+['portable_session::write_domain::tests::indexed_domain_']+tail),('domains',base+['portable_session::write_domain::tests::']+tail),('source-child',base+['source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo']+tail)]
state={'driver_pid':os.getpid(),'root':str(root),'input_count':len(expected),'current':None,'stages':[],'limits':'Unchanged default budgets; index preparation included in storage-and-edges. No performance claim; stop unexpected semantic failures.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for name,cmd in commands:
 assert freeze()==expected
 if name=='source-child':env.update(SUSS_SOURCE_CHILD_FUEL_TRACE='1',SUSS_SOURCE_MATERIALIZE_FUEL_TRACE='1')
 state['current']=name;row={'name':name,'command':cmd};state['stages'].append(row);save();start=time.monotonic()
 with (run/(name+'.log')).open('w') as out:
  proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
 after=freeze();changed=[p for p in expected if expected[p]!=after[p]];row.update(exit=code,seconds=time.monotonic()-start,changed=changed)
 if name=='bootstrap' and code==0 and set(changed)<={f'runtime/bootstrap/{phase}.{ext}' for phase in ['macro','runtime'] for ext in ['wasm','json']}:expected=after;snapshot('after-bootstrap',expected)
 elif changed:row['unexpected_changes']=True;save();break
 save()
 if code and name!='source-child':break
state['current']=None;state['final_changed']=[p for p,h in expected.items() if freeze()[p]!=h];save()
