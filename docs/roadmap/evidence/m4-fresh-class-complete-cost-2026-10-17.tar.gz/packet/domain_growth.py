from pathlib import Path
import re,json
c=Path('/home/bobby/.cache/suss-m4-work');r=c/'native-fresh-class-complete-cost';j=json.loads((r/'complete-cost-census.json').read_text());lines=(r/'source-child.log').read_text().splitlines();out={}
for source,request in j['requests'].items():
 pending=None;rows=[]
 for i in range(request['start_line'],request['last_line']-1):
  m=re.search(r'source-domain-record domain=(\S+) fact=(\S+) phase=node-growth event=(before|after).*remaining=Some\((\d+)\)',lines[i])
  if not m:continue
  domain,fact,event,fuel=m.groups();fuel=int(fuel)
  if event=='before':assert pending is None;pending=(domain,fact,fuel,i+1)
  else:
   assert pending[:2]==(domain,fact);cost=pending[2]-fuel
   if cost:
    backing_plus_copy=cost-1;assert backing_plus_copy%160==0
    if backing_plus_copy==4*160:new,copy=backing_plus_copy,0
    else:assert backing_plus_copy%3==0;copy=backing_plus_copy//3;new=copy*2
    rows.append({'fact':fact,'before_line':pending[3],'after_line':i+1,'accepted':cost,'new_backing_bytes':new,'relocation_work_bytes':copy})
   pending=None
 assert pending is None
 out[source]={'growth_events':len(rows),'accepted_including_controls':sum(x['accepted'] for x in rows),'new_backing_bytes':sum(x['new_backing_bytes'] for x in rows),'relocation_work_bytes':sum(x['relocation_work_bytes'] for x in rows),'events':rows}
assert out['Runtime']['new_backing_bytes']==out['Macro']['new_backing_bytes']
(r/'domain-node-growth-census.json').write_text(json.dumps({'sources':out,'qualification':'Source-bound reconstruction from complete node-growth before/after fuel intervals: closure has only the existing bytes+1 charge; size_of(write_domain::Node)=160 follows its unchanged source layout and repeated scalar edge/cuts640 =4*3*SessionValue40 +Node. Full-capacity growth bills (new_capacity+old_len)*160; initial4 slots otherwise new_capacity2*old_len. This is accepted requested backing/relocation work, not measured allocator usable capacity or physical memory traffic. Separate from snapshot::Node136; no zero-growth intervals counted as allocations.'},indent=2)+'\n')
for source,v in out.items():print(source,{k:x for k,x in v.items() if k!='events'})
