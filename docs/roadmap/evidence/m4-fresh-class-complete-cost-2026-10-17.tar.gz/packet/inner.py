from pathlib import Path
import re,json,collections
c=Path('/home/bobby/.cache/suss-m4-work');r=c/'native-fresh-class-complete-cost';lines=(r/'source-child.log').read_text().splitlines();j=json.loads((r/'complete-cost-census.json').read_text());patterns=[('call',re.compile(r'source-materialize-call label=(\S+) event=(before|after).*remaining=Some\((\d+)\)')),('record',re.compile(r'source-domain-record domain=\S+ fact=(\S+) phase=(\S+) event=(before|after).*remaining=Some\((\d+)\)')),('domain',re.compile(r'source-domain domain=\S+ staged=\S+ phase=(\S+) event=(before|after).*remaining=Some\((\d+)\)')),('snapshot',re.compile(r'source-snapshot phase=(\S+) count=(\d+) event=(before|after).*remaining=Some\((\d+)\)'))]
out=[]
for window in j['paired_intervals'] + j.get('derived_parent_windows', []):
 if window['stage'] not in ['physical-inputs','physical-materialize','final-parent','parent-map-construction','parent-finish','physical-child-checks','final-validation','parent-child-preparation-gap','parent-entry-materialization-gap','parent-expectation-gap']:continue
 stacks=collections.defaultdict(list);events=[]
 for i in range(window['line_before'],window['line_after']-1):
  line=lines[i]
  for kind,pattern in patterns:
   m=pattern.search(line)
   if not m:continue
   if kind=='record':fact,label,event,fuel=m.groups();label=fact+'/'+label
   elif kind=='snapshot':label,count,event,fuel=m.groups()
   else:label,event,fuel=m.groups()
   fuel=int(fuel)
   if event=='before':stacks[kind].append({'kind':kind,'label':label,'start_fuel':fuel,'start_line':i+1,'outer_kind':not stacks[kind],'outer_call':not stacks['call'] if kind!='call' else len(stacks['call'])==0})
   else:
    e=stacks[kind].pop();assert e['label']==label,(i,e,line);e.update(end_line=i+1,spent=e['start_fuel']-fuel,result='error' if 'result=Err' in line else 'ok');events.append(e)
   break
 assert not any(stacks.values()),(window,stacks)
 groups=collections.defaultdict(lambda:{'count':0,'spent':0})
 for e in events:
  k=(e['kind'],e['label'],e['outer_kind'],e['outer_call'],e['result']);g=groups[k];g['count']+=1;g['spent']+=e['spent']
 outercalls=sum(x['spent'] for x in events if x['kind']=='call' and x['outer_kind']);snapouter=sum(x['spent'] for x in events if x['kind']=='snapshot' and x['outer_kind']);out.append({'source':window['request_source'],'stage':window['stage'],'spent':window['spent'],'internal_trace_events':len(events),'outer_call_spent':outercalls,'outside_call_intervals':window['spent']-outercalls,'outer_snapshot_spent_inclusive':snapouter,'groups':[dict(zip(['kind','label','outer_kind','outside_call','result'],k),**v) for k,v in groups.items()]})
(r/'inner-cost-census.json').write_text(json.dumps({'windows':out,'qualification':'Nested categories are inclusive; do not add call/domain/record/snapshot groups together. Zero events means instrumentation absent, not zero host cost.'},indent=2)+'\n')
for w in out:
 if w['source']!='Runtime':continue
 print(w['stage'],w['spent'],'outercalls',w['outer_call_spent'],'outside',w['outside_call_intervals'],'snapshotinclusive',w['outer_snapshot_spent_inclusive'])
 for x in sorted([x for x in w['groups'] if x['kind'] in ['call','record','domain']],key=lambda x:-x['spent']):print(' ',x['kind'],x['label'],x['count'],x['spent'])
