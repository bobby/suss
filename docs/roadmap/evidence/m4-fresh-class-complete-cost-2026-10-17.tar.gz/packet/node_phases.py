from pathlib import Path
import re,json,collections
r=Path('/home/bobby/.cache/suss-m4-work/native-fresh-class-complete-cost');lines=(r/'source-child.log').read_text().splitlines();requests=json.loads((r/'complete-cost-census.json').read_text())['requests'];out={}
pattern=re.compile(r'source-domain-node domain=(\S+) staged=(\S+) ordinal=(\d+) .*phase=(\S+) event=(before|after).*remaining=Some\((\d+)\)')
for source,request in requests.items():
 pending={};counts=collections.defaultdict(lambda:{'count':0,'spent':0});events=[]
 for i in range(request['start_line'],request['last_line']-1):
  m=pattern.search(lines[i])
  if not m:continue
  domain,staged,ordinal,phase,kind,remaining=m.groups();fuel=int(remaining);key=(domain,staged,ordinal,phase)
  if kind=='before':assert key not in pending;pending[key]=(fuel,i+1)
  else:
   before,start=pending.pop(key);assert before>=fuel;g=counts[phase];g['count']+=1;g['spent']+=before-fuel;events.append({'phase':phase,'before':before,'after':fuel,'spent':before-fuel,'line_before':start,'line_after':i+1})
 assert not pending,pending
 out[source]={'phases':dict(counts),'events':events}
(r/'domain-node-phase-census.json').write_text(json.dumps({'sources':out,'qualification':'Existing production node before/after fuel traces only; no new GC queries/counters/observer. Costs are inclusive native regions and nested in storage-and-edges/hash, never add to those parent intervals. This does not newly measure exact ref_eq attempts; historical605952 counts belong to separate48observer tuple.'},indent=2)+'\n');print(json.dumps({s:v['phases'] for s,v in out.items()},indent=2))
