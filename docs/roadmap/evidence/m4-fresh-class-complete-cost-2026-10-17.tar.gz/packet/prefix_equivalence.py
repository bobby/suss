from pathlib import Path
import json,re,collections,hashlib
c=Path('/home/bobby/.cache/suss-m4-work');r=c/'native-fresh-class-complete-cost';paths=[c/'native-class-audit-fresh-inspection/source-child.log',r/'source-child.log']
def read(p):
 out=[];counts=collections.Counter()
 for line in p.read_text().splitlines():
  m=re.search(r'source-child-fuel source=(\S+) (?:variant=(.*?) )?stage=(.*?) remaining=Some\((\d+)\)',line)
  if not m:continue
  source,variant,stage,fuel=m.groups();key=(source,variant,stage);i=counts[key];counts[key]+=1;out.append({'key':(*key,i),'fuel':int(fuel),'line':line})
 return out
old,new=map(read,paths);indexed={tuple(x['key']):x for x in new};matched=[]
for x in old:
 key=tuple(x['key']);assert key in indexed,key;y=indexed[key];delta=y['fuel']-x['fuel'];matched.append({'key':list(key),'default_fuel':x['fuel'],'diagnostic_fuel':y['fuel'],'delta':delta});assert delta==20_000_000,(key,delta)
assert len(new)==220
for phase in ['Runtime','Macro']:
 starts=[x for x in new if x['key'][:3]==(phase,'None','request-start')];assert len(starts)==1 and starts[0]['fuel']==30_000_000
result={'paths':list(map(str,paths)),'sha256':[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths],'default_prefix_markers':len(old),'diagnostic_markers':len(new),'all_same_outcome_prefix_delta_exact20M':True,'matches':matched,'qualification':'Exact stage/result/occurrence matched default19326prefix only. Diagnostic request-start30M independently Runtime/Macro, no monotonicity violation inside either phase; defaultMacrohalf unexecuted. Later diagnostic markers have no default successful counterpart and confer no default10M acceptance.'};(r/'default-prefix-equivalence.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='matches'}))
