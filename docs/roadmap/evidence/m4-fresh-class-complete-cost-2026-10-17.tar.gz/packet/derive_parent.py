from pathlib import Path
import json
r=Path('/home/bobby/.cache/suss-m4-work/native-fresh-class-complete-cost');p=r/'complete-cost-census.json';j=json.loads(p.read_text());markers=json.loads((r/'source-child-markers.json').read_text());derived=[]
pairs=[('parent-child-preparation-gap','parent-layout result=Ok(())','parent-recording:before'),('parent-entry-materialization-gap','parent-recording result=Ok(())','parent-map-construction:before'),('parent-expectation-gap','parent-records result=Ok(())','parent-finish:before')]
for source in j['requests']:
 for label,start,end in pairs:
  a=[m for m in markers if m['request_source']==source and m['event_source']==source and m['variant'] is None and m['stage']==start];b=[m for m in markers if m['request_source']==source and m['event_source']==source and m['variant'] is None and m['stage']==end]
  if not a or not b:continue
  assert len(a)==len(b)==1,(source,label);a,b=a[0],b[0];assert a['line']<b['line'] and a['fuel']>=b['fuel']
  derived.append({'request_source':source,'event_source':source,'variant':None,'stage':label,'before':a['fuel'],'after':b['fuel'],'spent':a['fuel']-b['fuel'],'line_before':a['line'],'line_after':b['line'],'result':'Derived gap between exact paired markers, same established prior parser convention; no new instrumentation'})
j['derived_parent_windows']=derived;p.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(derived,indent=2))
