from pathlib import Path
import json,hashlib,subprocess,tarfile,io,shutil
cache=Path('/home/bobby/.cache/suss-m4-work');root=Path('/home/bobby/Work/code/bobby/suss-m4-fresh-class-complete-cost');packet=Path(__file__).parent;run=cache/'native-fresh-class-complete-cost';out=cache/'fresh-class-complete-cost-package';out.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='3baf7ee15009700690aa5b1b6d1252e1fd3ee940'
frozen=json.loads((run/'after-freeze.json').read_text());receipt=json.loads((run/'receipt.json').read_text());assert receipt['current'] is None and not receipt['final_changed'] and len(receipt['stages'])==3 and all(x['exit']==0 for x in receipt['stages']);assert receipt['stages'][-1]['summaries']==[['ok','1','0','0']]
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in frozen.items())
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE);matched=[]
for p,h in frozen.items():
 proc.stdin.write((head+':'+p+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().strip();row={'path':p,'sha256':h}
 if header.endswith(' missing'):
  assert p.startswith('clojurescript/'),p;pin=subprocess.check_output(['git','rev-parse',head+':clojurescript'],cwd=root,text=True).strip();data=subprocess.check_output(['git','show',pin+':'+p[len('clojurescript/'):]],cwd=root/'clojurescript');row.update(gitlink='clojurescript',pin=pin)
 else:
  size=int(header.split()[2]);data=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n'
 assert hashlib.sha256(data).hexdigest()==h,p;matched.append(row)
proc.stdin.close();assert proc.wait()==0;(out/'committed-binding.json').write_text(json.dumps({'head':head,'base':receipt['head'],'count':len(matched),'missing':[],'matches':matched},indent=2)+'\n')
# Back all current default negative inputs too, preserving its original source.
default=cache/'native-class-audit-fresh-inspection';df=json.loads((default/'after-freeze.json').read_text());manifest=json.loads((packet/'manifest.json').read_text())
for p,h in df.items():
 dest=run/'frozen/sha256'/h
 if not dest.exists():
  assert p==manifest['path'];data=(packet/'before.rs').read_bytes();assert hashlib.sha256(data).hexdigest()==h;dest.write_bytes(data)
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==h
census=json.loads((run/'complete-cost-census.json').read_text());assert len(json.loads((run/'source-child-markers.json').read_text()))==220 and not census['unclosed_intervals'];assert all(x['accepted_debit']==11752345 and x['start_fuel']==30000000 and x['last_fuel']==18247655 for x in census['requests'].values())
proof=json.loads((run/'terminal-process-proof.json').read_text());assert proof['released'];eq=json.loads((run/'default-prefix-equivalence.json').read_text());assert eq['all_same_outcome_prefix_delta_exact20M'] and eq['default_prefix_markers']==98
summary={'source_head':head,'base':receipt['head'],'diagnostic_only':True,'three_stages_exit0':True,'rust_pass':1,'rust_fail':0,'ignored':0,'actual_input_count':len(frozen),'phase_total_each':11752345,'phase_gap_each_vs_default10M':1752345,'independent_phases':['Runtime','Macro'],'ordered_markers':220,'matched_default_prefix_markers':98,'prefix_delta_exact':20000000,'final_parent_each':1709074,'default_negative':'Published19326 remainstypedOutOfFuel at950, no zero marker; not replaced by30Msuccess','large_inclusive_regions':'Hash4239143/domainEnrollment3904952; snapshots/edges1518540 nested; snapshottypedbufferdebits1609824 nested; no removability claim','actual_target_released':True,'reviews':'Carver exact2linepatch2d5edaf3 beforeexecution; finalcommittedsource/artifactscope review pending','no_claims':['No production quota/rate/observer/body change','No default10M acceptance, issue closure, fullbaseline/CI green or production integration','No standalone summation of nested regions as savings']};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
def add(path,prefix):
 if path.is_file():files[prefix]=path
 elif path.is_dir():
  for p in sorted(path.rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:files[prefix+'/'+str(p.relative_to(path))]=p
add(run,'run');add(packet,'packet')
for name in ['source-child.log','receipt.json','command-plan.json','after-freeze.json','source-commit.json','root-sourcechild-comparison.json','root-comparison-initial-strict.json','root-comparison-initial-strict.py','root-classification-correction.txt','source-child-failure-qualification.json','source-child-prefix-comparison.json','source-child-prefix-comparison-initial.json','prefix-comparison-correction.txt','manifest.json']:
 add(default/name,'default19326/'+name)
production=root/'docs/roadmap/evidence/m4-fresh-class-inspection-2026-10-17.tar.gz';assert hashlib.sha256(production.read_bytes()).hexdigest()=='060ead0acfe314929f00b1657aaccc544207e590dc7738d63ba4a77355da673a'
(out/'production-parent-reference.json').write_text(json.dumps({'published_head':receipt['head'],'source_head':'812b7257e3031cf1db5790a2e0d02d7128b53363','archive':production.name,'sha256':hashlib.sha256(production.read_bytes()).hexdigest(),'qualification':'Already independently reviewed production packet; currentdiag includes default raw negative+frozen input backing, without rerun/defaultacceptanceclaim'},indent=2)+'\n')
for p in out.glob('*.json'):add(p,'final/'+p.name)
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+name+'\n' for name,p in sorted(files.items())).encode();archive=root/'docs/roadmap/evidence/m4-fresh-class-complete-cost-2026-10-17.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=5) as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('SHA256SUMS');info.size=len(manifest);t.addfile(info,io.BytesIO(manifest))
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(files)+1;assert len({m.name for m in members})==len(members)
 for line in t.extractfile('SHA256SUMS').read().decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h,n
result={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files)+1,'manifested_payloads':len(files),'bytes':archive.stat().st_size,'source_head':head,'binding_count':len(matched)};(packet/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');shutil.copyfile(packet/'COST-REPORT.md',root/'docs/roadmap/evidence/m4-fresh-class-complete-cost-2026-10-17.md');print(json.dumps(result))
