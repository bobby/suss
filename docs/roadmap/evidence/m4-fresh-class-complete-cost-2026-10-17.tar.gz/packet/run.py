from pathlib import Path
import subprocess,os,time,json,hashlib,shutil,re,fcntl
cache=Path('/home/bobby/.cache/suss-m4-work');packet=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-fresh-class-complete-cost');target=cache/'m4-cost-diagnostic-target';run=cache/'native-fresh-class-complete-cost'
leases=[]
for name in ['.root-observation-target.lease','.suss-array-census.lock','.fresh-class-complete-cost.lease']:
 f=open(target/name,'a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:envb=(proc/'environ').read_bytes();cmd=(proc/'cmdline').read_bytes().split(b'\0')[0]
 except OSError:continue
 if b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' in envb or str(target).encode() in cmd:raise RuntimeError('Target active: '+proc.name)
manifest=json.loads((packet/'manifest.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==manifest['base']
assert hashlib.sha256((root/manifest['path']).read_bytes()).hexdigest()==manifest['after_sha256']
assert hashlib.sha256((packet/'diagnostic30M.patch').read_bytes()).hexdigest()==manifest['patch_sha256']
assert subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()==[manifest['path']]
run.mkdir(exist_ok=False);(run/'frozen/sha256').mkdir(parents=True)
for f in ['diagnostic30M.patch','manifest.json','PLAN.txt','run.py','before.rs','after.rs','lease-precheck.json']:shutil.copyfile(packet/f,run/f)
tracked=subprocess.check_output(['git','ls-files','--recurse-submodules'],cwd=root,text=True).splitlines()
paths={p for p in tracked if (root/p).is_file() and (p.startswith(('crates/','runtime/','scripts/','tests/','vendor/','docs/compatibility/','.cargo/','.github/workflows/')) or p in ['Cargo.toml','Cargo.lock','clojurescript/deps.edn','clojurescript/project.clj'])}
historical=json.loads((cache/'native-sourcechild-complete-cost/after-bootstrap-freeze.json').read_text());assert all((root/p).is_file() for p in historical);paths.update(historical);paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snapshot(label,hashes):
 (run/(label+'-freeze.json')).write_text(json.dumps(hashes,indent=2)+'\n')
 for p,sha in hashes.items():
  dest=run/'frozen/sha256'/sha
  if not dest.exists():
   data=(root/p).read_bytes();assert hashlib.sha256(data).hexdigest()==sha;dest.write_bytes(data)
expected=freeze();snapshot('before',expected)
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target))
for k in list(env):
 if k.startswith('SUSS_') and ('TRACE' in k or 'DIAGNOSTIC' in k):env.pop(k)
base=['cargo','test','-p','suss-compile','--locked','--lib'];tail=['--','--test-threads=1','--nocapture']
commands=[('compile',base+['--no-run'],None),('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap'],None),('source-child',base+['portable_macro_graph::source_roots::tests::source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo','--','--exact','--test-threads=1','--nocapture'],1)]
(run/'command-plan.json').write_text(json.dumps(commands,indent=2)+'\n')
state={'process':{'pid':os.getpid(),'pgid':os.getpgid(0),'sid':os.getsid(0),'target':str(target)},'head':manifest['base'],'patch_sha256':manifest['patch_sha256'],'input_count':len(expected),'environment':{'CARGO_BUILD_JOBS':'1','RAYON_NUM_THREADS':'1','test_threads':1,'RUSTFLAGS':'inherited, not assigned'},'current':None,'stages':[],'limits':'DIAGNOSTIC fixed30M separately per source-phase outer request after default setup, no helper refill/production quota/tariff changes, original body/assertions. Onlytwoaddedtestlines; no observer. Both source phases/allvariants/tail required for full-cost measurement, not acceptance. Published19326 default10M failure remains. No old baseline restarted.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
save();print('producer '+json.dumps(state['process'])+' inputs='+str(len(paths)),flush=True)
allowed={f'runtime/bootstrap/{p}.{e}' for p in ['macro','runtime'] for e in ['wasm','json']}
try:
 for name,cmd,minimum in commands:
  assert freeze()==expected,'Input changed before '+name
  stageenv=env.copy()
  if name=='source-child':stageenv.update(SUSS_SOURCE_CHILD_FUEL_TRACE='1',SUSS_SOURCE_MATERIALIZE_FUEL_TRACE='1')
  if name=='map':stageenv['SUSS_CLOJURE_TEST_SUITE_CAPTURE']=str(run/'map-capture');stageenv['SUSS_MACRO_FUEL_TRACE']='1'
  state['current']=name;entry={'name':name,'command':cmd};state['stages'].append(entry);save();print('starting '+name,flush=True);start=time.monotonic()
  with (run/(name+'.log')).open('w') as log:
   process=subprocess.Popen(cmd,cwd=root,env=stageenv,stdout=log,stderr=subprocess.STDOUT);entry['pid']=process.pid;save();code=process.wait()
  after=freeze();changed=[p for p in expected if after[p]!=expected[p]];raw=(run/(name+'.log')).read_text();summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)
  entry.update(exit=code,seconds=time.monotonic()-start,changed=changed,summaries=summaries)
  if name=='bootstrap' and code==0 and set(changed)<=allowed:expected=after;snapshot('after-bootstrap',expected)
  elif changed:entry['unexpected_input_changes']=True;save();break
  save();print(json.dumps(entry),flush=True)
  if code:
   state['stopped_on']=name;save();break
  if minimum is not None:
   assert summaries,'No actual tests: '+name
   assert int(summaries[-1][1])>=minimum and int(summaries[-1][2])==0 and int(summaries[-1][3])==0,'Unexpected test counts: '+name
except BaseException as error:
 state['driver_error']=repr(error);raise
finally:
 state['current']=None;final=freeze();state['final_changed']=[p for p in expected if final[p]!=expected[p]];snapshot('after',final);save();print(json.dumps(state),flush=True)
