from pathlib import Path
import subprocess,json,re
cache=Path('/home/bobby/.cache/suss-m4-work'); run='38904754873'
response=subprocess.run(['gh','run','view',run,'--json','status,conclusion,jobs,headSha,url'],capture_output=True,text=True);response.check_returncode();state=json.loads(response.stdout)
(cache/'cif1-run.json').write_text(json.dumps(state,indent=2)+'\n');result={'run':run,'head':state['headSha'],'status':state['status'],'conclusion':state['conclusion'],'jobs':[]}
for job in state['jobs']:
 item={k:job[k] for k in ['name','databaseId','status','conclusion']};result['jobs'].append(item)
 if job['status']!='completed':continue
 raw=cache/('cif1-job-'+str(job['databaseId'])+'-raw.log')
 if not raw.exists() or not raw.stat().st_size:
  fetch=subprocess.run(['gh','api','repos/bobby/suss/actions/jobs/'+str(job['databaseId'])+'/logs','--allow-escape-sequences'],capture_output=True)
  if fetch.returncode:item['log_error']='fetch failed; retry this exact terminal job';continue
  raw.write_bytes(fetch.stdout)
 clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.read_text(errors='replace'));(cache/('cif1-job-'+str(job['databaseId'])+'-clean.log')).write_text(clean)
 item['failed_tests']=re.findall(r'\btest ([a-zA-Z0-9_:]+) \.{3} FAILED',clean)
 item['rust_results']=re.findall(r'test result: (?:ok|FAILED)\. [^\n]+',clean)
 item['fuel_markers']=len(re.findall(r'fuel|Fuel',clean))
(cache/'cif1-classification-live.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'conclusion':result['conclusion'],'jobs':[{k:v for k,v in j.items() if k not in ['rust_results']} for j in result['jobs']]},indent=2))
