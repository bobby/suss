from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-acceptance');c=Path(__file__).parent
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'combined-acceptance-target'),RAYON_NUM_THREADS='2',SUSS_CLOJURE_TEST_SUITE_CAPTURE=str(c/'map-combined-paged'))
paths=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.sus')]+[p for p in (r/'runtime/bootstrap').glob('*') if p.is_file()]
state={'base':'f1ab36c','integrated':'bb444a7','freeze':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'stages':[]};out=c/'combined-paged-focused-result.json'
commands=[]
for name,filter in [('raw','portable_macro_graph::raw_keys'),('sharing','portable_macro_graph::sharing_tests'),('paired','paired_source'),('scoped','scoped_memo_stores'),('leaves','memo_leaf')]:
 commands.append((name,['cargo','test','-p','suss-compile','--lib','--locked',filter,'--','--test-threads=2','--nocapture']))
for name,target,filter in [('tags','compiled_macro_source_tags',''),('core','compiled_macro_core_environment',''),('declaration','compiled_macro_declaration_metadata','declaration_metadata_merge_and_tag_precedence_match_pinned_analyzer')]:
 commands.append((name,['cargo','test','-p','suss-cli','--locked','--test',target]+([filter] if filter else [])+['--','--test-threads=2','--nocapture']))
commands.append(('map',['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--test-threads=2','--nocapture']))
for name,cmd in commands:
 state['current']=name;out.write_text(json.dumps(state,indent=2)+'\n');start=time.time()
 with (c/('combined-paged-focused-'+name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 state['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start})
state.update(current=None,source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in state['freeze'].items()));out.write_text(json.dumps(state,indent=2)+'\n')
