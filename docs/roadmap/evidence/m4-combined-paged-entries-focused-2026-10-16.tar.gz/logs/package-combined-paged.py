from pathlib import Path
import json,hashlib,tarfile,io,re,shutil
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-acceptance')
d=json.loads((c/'combined-paged-focused-result.json').read_text());assert d['current'] is None and d['source_unchanged'];assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in d['freeze'].items())
rows=[]
for stage in d['stages']:
 s=(c/('combined-paged-focused-'+stage['name']+'.log')).read_text(errors='replace');v=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored',s);assert len(v)==1
 rows.append(dict(stage,passed=int(v[0][0]),failed=int(v[0][1]),ignored=int(v[0][2])))
summary={'stages':rows,'totals':{k:sum(x[k] for x in rows) for k in ['passed','failed','ignored']},'freeze_paths':len(d['freeze']),'limits':'Focused integration only. Both source-tag cases, core environment and declaration precedence still exhaust default fuel. No full baseline or final-head CI at this source. No acceptance claim.'};assert summary['totals']==dict(passed=60,failed=4,ignored=0)
(c/'combined-paged-classification.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[c/('combined-paged-focused-'+s['name']+'.log') for s in rows]+[c/n for n in ['combined-paged-bootstrap.log','combined-paged-focused-result.json','combined-paged-classification.json','run-combined-paged-focused.py','combined-paged-entries.patch']]+[c/'map-combined-paged'/n for n in ['map-transport-observations.json','comparison.json']]+[Path(__file__)]
a=r/'docs/roadmap/evidence/m4-combined-paged-entries-focused-2026-10-16.tar.gz';manifest={}
with tarfile.open(a,'w:gz') as t:
 for p in files:
  name='logs/'+p.name;manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest();t.add(p,arcname=name)
 for n in sorted(d['freeze']):
  p=r/n;name='snapshot/'+n;manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest();t.add(p,arcname=name)
 b=(json.dumps(manifest,indent=2)+'\n').encode();i=tarfile.TarInfo('SHA256.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
sha=hashlib.sha256(a.read_bytes()).hexdigest();print(sha,len(manifest),summary['totals'])
component=Path('/home/bobby/Work/code/bobby/suss-m4-paged-canonical-entries/docs/roadmap/evidence/m4-paged-canonical-entries-focused-2026-10-16.tar.gz');shutil.copyfile(component,r/'docs/roadmap/evidence'/component.name)
with (r/'docs/roadmap/handoff.md').open('a') as f:f.write('\n### Combined paged canonical-entry validation (2026-10-16)\n\nApplied only the reviewed65b565f..bb444a7 entry-arena source delta onto f1ab36c, preserving other combined source, and regenerated both bootstraps (exit0). The frozen focused runner terminates with60pass executions/4fuel failures/0ignored: raw19,sharing20,paired3,scoped13,identifier leaves4 and pinned map1 pass. Both source-tag cases, core environment and declaration precedence still exhaust default fuel; no regression repair or issue acceptance is claimed. The other preservation corpora and public cumulative target were not rerun in this cohort.\n\nAll432 frozen Rust/Suss/bootstrap paths remain unchanged. Independent map comparison confirms all69 ordered assertions:62host passes/7guest judgments and0fail/missing/skips/test/namespace failures. Raw commands, failures, observations, classification and snapshots are in `'+str(a.relative_to(r))+'`, SHA256 `'+sha+'` ('+str(len(manifest))+' payloads). No full baseline or CI success is claimed at this combined source.\n\nSeparately reviewed component bb444a7 evidence is retained in `docs/roadmap/evidence/'+component.name+'`, SHA256 `5158c12b92b5e342e49d8c97c479af2a12e85a3220be5cba5d6eff821e2d7180`:42focusedpasses, two retained critical fuel failures,612048netstorage saving including85352extraaccess charges;matchedBitmap remainingfuel gain612860. These component savings are not additional combined acceptance evidence. Next: validate explicit analyzer-literal keyword provenance against pinned observations and repair the source-tag/default-fuel gaps; require full baseline, independent review and final-head CI for issue resolution.\n')
