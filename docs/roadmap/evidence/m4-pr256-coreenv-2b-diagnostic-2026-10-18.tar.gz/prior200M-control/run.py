from pathlib import Path
import hashlib,json,os,signal,subprocess,time,traceback
p=Path(__file__).resolve().parent
root=Path('/home/bobby/Work/code/bobby/suss')
observer=p.parent/'pr256-declaration-tail-observer-run'
baseline=p.parent/'pr256-compact-heads-workspace-baseline'
m=json.loads((p/'manifest.json').read_text())
h=lambda b:hashlib.sha256(b).hexdigest()
def read(path):
    for attempt in range(5):
        try:return json.loads(path.read_text())
        except json.JSONDecodeError:
            if attempt==4:raise
            time.sleep(.1)
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
r={'base':m['base'],'diagnostic_only':True,'terminal':False,'current':'waiting-for-existing-runs','pid':os.getpid()}
def save():
    tmp=p/'receipt.tmp';tmp.write_text(json.dumps(r,indent=2)+'\n');tmp.replace(p/'receipt.json')
def terminated(signum,frame):raise KeyboardInterrupt('controller interrupted')
signal.signal(signal.SIGTERM,terminated)
save()
def group_live(group):
    rows=subprocess.check_output(['ps','-eo','pgid=,stat='],text=True).splitlines()
    return any(parts[0]==str(group) and not parts[1].startswith('Z')
               for line in rows if len(parts:=line.split())==2)
def drain(child):
    if group_live(child.pid):
        try:os.killpg(child.pid,signal.SIGTERM)
        except ProcessLookupError:pass
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:
        if group_live(child.pid):os.killpg(child.pid,signal.SIGKILL)
        child.wait()
    if group_live(child.pid):os.killpg(child.pid,signal.SIGKILL)
    for _ in range(100):
        if not group_live(child.pid):return
        time.sleep(.02)
    raise RuntimeError('Diagnostic process group did not drain; source must remain untouched')
active=None;applied=False
try:
    while True:
        b=read(baseline/'receipt.json');o=read(observer/'receipt.json')
        processes=subprocess.check_output(['ps','-eo','args='],text=True).splitlines()
        for directory,receipt in [(baseline,b),(observer,o)]:
            if not receipt['terminal'] and 'python3 '+str(directory/'run.py') not in processes:
                assert read(directory/'receipt.json')['terminal'],'Predecessor disappeared without terminal receipt'
        if b['terminal'] and o['terminal'] and all('python3 '+str(d/'run.py') not in processes for d in [baseline,observer]):
            assert not Path('/proc/'+str(b['pid'])).exists(),'Baseline Cargo still live'
            break
        time.sleep(2)
    assert o.get('production_restored') is True,o
    assert git('rev-parse','HEAD').decode().strip()==m['base']
    assert not git('diff','--name-only','HEAD').strip(),'Tracked files changed'
    review=read(p/'independent-review.json')
    r['review_sha256']=h((p/'independent-review.json').read_bytes())
    assert h((p/'candidate.patch').read_bytes())==m['patch_sha256']
    target=root/m['file'];original=(p/'original.rs').read_bytes();diagnostic=(p/'diagnostic.rs').read_bytes()
    assert h(target.read_bytes())==m['original_sha256']==h(original)
    assert h(diagnostic)==m['diagnostic_sha256']
    files=git('ls-files').decode().splitlines()
    freeze={n:h((root/n).read_bytes()) for n in files if (root/n).is_file()}
    target.write_bytes(diagnostic);applied=True;freeze[m['file']]=m['diagnostic_sha256']
    (p/'executed-source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
    env=os.environ.copy();overrides={'CARGO_TARGET_DIR':'/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target','CARGO_BUILD_JOBS':'1','RAYON_NUM_THREADS':'1',**m['required_environment']};env.update(overrides)
    r.update(current='coreenv-200M',argv=m['command'],environment_overrides=overrides);save()
    start=time.monotonic()
    with (p/'execution.log').open('w') as log:
        active=subprocess.Popen(m['command'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        r['cargo_pid']=active.pid;save()
        code=active.wait()
        assert not group_live(active.pid),'Owned descendants survived command completion'
        active=None
    r.update(exit=code,seconds=time.monotonic()-start)
    changed=[n for n,digest in freeze.items() if not (root/n).is_file() or h((root/n).read_bytes())!=digest]
    r['changed']=changed
    assert not changed,'Frozen source changed during diagnostic'
except BaseException:
    r['error']=traceback.format_exc()
    raise
finally:
    if active is not None:
        try:
            drain(active)
            active=None
        except BaseException:
            r['manual_restore_required']='Owned process group not drained; source not restored'
            r.update(terminal=True,current=None);save()
            raise
    if applied:
        # Restore only our known test-file postimage; preserve any unknown edit.
        if h(target.read_bytes())==m['diagnostic_sha256']:
            target.write_bytes(original)
            r['production_restored']=h(target.read_bytes())==m['original_sha256']
        else:r['manual_restore_required']='Test-file bytes changed; no overwrite performed'
    r.update(terminal=True,current=None);save()
print(json.dumps(r),flush=True)
