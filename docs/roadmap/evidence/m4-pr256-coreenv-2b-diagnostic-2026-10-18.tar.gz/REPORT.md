# PR2562B CoreEnv completion diagnostic

Exact4f source plus comment+Macro allowance2_000_000_000 only. Original caller defaults, both caller phases, full corpus and all assertions remain in source. Terminal exit101/0PASS1fuelFAIL0ignored;270.845s. Changed[], production_restored=true; controller/child exited. All3532executed inputs bind to Git4f except exact retained testpostimage. No current-root hashes or slot-log bytes used.

First Runtime request completed all7macro stages. Initial remaining1,999,999,819 demonstrates actual2B scope. Start→decoded actual1,701,285,927units; caller-form→caller-environment1,701,066,103 (1,999,996,362→298,930,259); arguments6,154; transformer interval210,097; decode116. First macro request completion is NOT completion of full test or whole compile. Sequential source/panic location shows first caller projection/GC/assertions passed before second eval.

Second Runtime request starts1,999,999,804 then caller-form1,999,996,335; caller&env0..36 exhausts. Required unfinished cost UNKNOWN. Remaining Macro caller phase and its two requests unexecuted.2B is insufficient for this full fixture. Wholecompilation cost UNKNOWN: stages exclude outer compiler/setup/caller execution/external decode/GC/assertions. No default-budget acceptance credit, no allowance change proposed.

Prior200M control retained in separate directory/tuple: actual200M stillfailed, d38 source,3526Gitbound paths; no union/count or same-source comparison. All raw controls/reviews/argv/environment/normalBOOT bytes and source hashes retained. This packet does not include current slot candidate or any localbaseline outcome beyond recorded predecessor gate receipt.
