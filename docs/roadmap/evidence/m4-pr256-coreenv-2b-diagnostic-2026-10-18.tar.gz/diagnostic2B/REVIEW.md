Prepared ONLY; no source/Cargo execution.

Exact base 4f48ea6bd7d2e198b9dd82086e4abf4e118e7a7b; test preimage matches prior200M original. Only comment+Macro2B setter inserted; caller defaults/two phases/all assertion bytes retained. Prior200M actual failure retained separately.

Controller waits terminal baseline changed[] and BOTH fixed driver/Cargo PIDs gone, then demands exact base/clean tracked files/preimage. Owns only the test postimage; process group drained before conditional restore. Unknown test bytes are never overwritten. SIGTERM/INT triggers cleanup. Requires carver-review.json with reviewer=Carver, approved_for_execution=true, manifest_sha256 matching this manifest; no review placeholder grants authority. Explicit --execute is also required. No launch authorized by this packet.

The summary retains incomplete/error/zero-coverage outcomes and excludes whole compilation from macro costs. Previous reviewed summarizer pattern retained; unchanged broad corpus, no sufficiency assumption.
