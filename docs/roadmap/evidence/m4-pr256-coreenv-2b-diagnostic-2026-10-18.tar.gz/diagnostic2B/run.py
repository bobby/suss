"""Prepared only. Requires independent Carver approval + explicit --execute; never reruns."""
from pathlib import Path
import argparse,hashlib,json,os,signal,subprocess,time,traceback,fcntl
P=Path(__file__).resolve().parent;R=Path('/home/bobby/Work/code/bobby/suss');B=P.parent/'pr256-raw-key-scratch-workspace-baseline'
H=lambda b:hashlib.sha256(b).hexdigest()
def read(p):
 for i in range(5):
  try:return json.loads(p.read_text())
  except json.JSONDecodeError:
   if i==4:raise
   time.sleep(.1)
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def alive(pid):
 try:os.kill(pid,0);return True
 except ProcessLookupError:return False
def group_live(pgid):
 return any(x[0]==str(pgid) and not x[1].startswith('Z') for l in subprocess.check_output(['ps','-eo','pgid=,stat='],text=True).splitlines() if len(x:=l.split())==2)
def drain(c):
 if group_live(c.pid):
  try:os.killpg(c.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 try:c.wait(timeout=10)
 except subprocess.TimeoutExpired:
  if group_live(c.pid):os.killpg(c.pid,signal.SIGKILL)
  c.wait()
 if group_live(c.pid):os.killpg(c.pid,signal.SIGKILL)
 for _ in range(100):
  if not group_live(c.pid):return
  time.sleep(.02)
 raise RuntimeError('Owned group not drained: source restoration refused')
def interrupted(s,f):raise KeyboardInterrupt('controller signal '+str(s))
def hashes(names):return {n:H((R/n).read_bytes()) if (R/n).is_file() else None for n in names}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');a=ap.parse_args();assert a.execute,'Prepared only: explicit --execute required after Carver review'
 m=read(P/'manifest.json');reviewpath=P/'carver-review.json';review=read(reviewpath)
 assert review['approved_for_execution'] is True and review['reviewer']=='Carver'
 assert review['manifest_sha256']==H((P/'manifest.json').read_bytes())
 for name,h in m['packet_files'].items():assert H((P/name).read_bytes())==h,name
 assert not (P/'receipt.json').exists(),'One-shot controller; previous receipt requires a new reviewed packet/run directory'
 lock=(P/'controller.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 receipt={'base':m['base'],'diagnostic_only':True,'macro_allowance':2_000_000_000,'caller_default_unchanged':True,'terminal':False,'current':'waiting-for-baseline','controller_pid':os.getpid(),'review_sha256':H(reviewpath.read_bytes())}
 def save():
  q=P/'receipt.tmp';q.write_text(json.dumps(receipt,indent=2)+'\n');q.replace(P/'receipt.json')
 signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
 child=None;applied=False;target=R/m['file'];original=(P/'original.rs').read_bytes();diag=(P/'diagnostic.rs').read_bytes();names=[];freeze={};save()
 try:
  while True:
   b=read(B/'receipt.json');assert b['base']==m['base'] and b['pid']==m['baseline_cargo_pid']
   if b['terminal']:
    assert 'exit' in b and b['changed']==[],'Baseline source closure not proven'
    if not alive(b['pid']) and not alive(m['baseline_driver_pid']):break
   elif not alive(m['baseline_driver_pid']):raise RuntimeError('Baseline driver disappeared without terminal receipt')
   time.sleep(2)
  receipt['baseline_terminal_receipt']=b;receipt['baseline_receipt_sha256']=H((B/'receipt.json').read_bytes());save()
  assert git('rev-parse','HEAD').decode().strip()==m['base']
  assert not git('diff','--name-only','HEAD').strip(),'Unknown tracked changes: refuse install'
  assert H(target.read_bytes())==m['original_sha256']==H(original)
  assert H(diag)==m['diagnostic_sha256']
  names=git('ls-files').decode().splitlines();freeze=hashes(names);assert all(v is not None for v in freeze.values() if v is not None)
  # Track regular files only, matching existing drivers; submodule gitlink is bound separately.
  freeze={n:v for n,v in freeze.items() if v is not None};names=list(freeze)
  pin=git('ls-tree','HEAD','clojurescript').decode().strip();receipt['gitlink']=pin
  target.write_bytes(diag);applied=True;freeze[m['file']]=m['diagnostic_sha256'];(P/'executed-source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
  overrides={'CARGO_TARGET_DIR':'/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target','CARGO_BUILD_JOBS':'1','RAYON_NUM_THREADS':'1',**m['required_environment']};env=os.environ.copy();env.update(overrides)
  receipt.update(current='coreenv-2B',argv=m['command'],environment_overrides=overrides);save();start=time.monotonic()
  with (P/'execution.log').open('w') as log:
   child=subprocess.Popen(m['command'],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);receipt['cargo_pid']=child.pid;save();code=child.wait()
   if group_live(child.pid):drain(child)
   assert not group_live(child.pid);child=None
  receipt.update(exit=code,seconds=time.monotonic()-start,changed=[n for n,v in hashes(names).items() if v!=freeze[n]])
  assert not receipt['changed'],'Source drift: no acceptance credit'
 except BaseException:
  receipt['error']=traceback.format_exc();raise
 finally:
  # Finish owned group cleanup before restoring source even if SIGTERM arrived.
  signal.signal(signal.SIGTERM,signal.SIG_IGN);signal.signal(signal.SIGINT,signal.SIG_IGN)
  safe=True
  if child is not None:
   try:drain(child);child=None
   except BaseException:receipt['drain_error']=traceback.format_exc();safe=False
  if applied:
   if safe and target.is_file() and H(target.read_bytes())==m['diagnostic_sha256']:
    target.write_bytes(original);receipt['production_restored']=H(target.read_bytes())==m['original_sha256']
   else:receipt['manual_restore_required']='Group not drained or unknown test bytes; no overwrite'
  receipt.update(terminal=True,current=None);save()
 print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()
