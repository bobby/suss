from pathlib import Path
import json,re,hashlib,subprocess,os,shutil,tarfile
C=Path('/home/bobby/.cache/suss-m4-work');P=Path(__file__).parent;D=C/'pr256-coreenv-2b-completion-probe';OLD=C/'pr256-coreenv-completion-budget-probe';S=P/'staging';S.mkdir(exist_ok=True);REPO='/home/bobby/Work/code/bobby/suss';H=lambda b:hashlib.sha256(b).hexdigest();L=lambda p:json.loads(p.read_text())
r=L(D/'receipt.json');m=L(D/'manifest.json');summary=L(D/'summary.json');assert r['terminal'] and r['exit']==101 and r['changed']==[] and r['production_restored'] is True and r['base']==m['base']=='4f48ea6bd7d2e198b9dd82086e4abf4e118e7a7b'
for pid in [r['controller_pid'],r['cargo_pid']]:
 try:os.kill(pid,0);raise AssertionError(('still live',pid))
 except ProcessLookupError:pass
stable={f.name:H(f.read_bytes()) for f in D.iterdir() if f.is_file()}
assert H((D/'carver-review.json').read_bytes())==r['review_sha256']
assert H((D/'original.rs').read_bytes())==m['original_sha256'] and H((D/'diagnostic.rs').read_bytes())==m['diagnostic_sha256']
assert (D/'diagnostic.rs').read_bytes().replace(b'        // Diagnostic allowance only; caller budget and every assertion stay unchanged.\n        macros.set_operation_fuel(2_000_000_000);\n',b'')==(D/'original.rs').read_bytes()
# Both independent source tuples use Gitobjects; no live root bytes.
def bind(directory,label):
 manifest=L(directory/'manifest.json');receipt=L(directory/'receipt.json');head=receipt['base'];freeze=L(directory/'executed-source-freeze.json');target=manifest['file'];post=(directory/'diagnostic.rs').read_bytes();assert H(post)==manifest['diagnostic_sha256']==freeze[target]
 assert receipt['terminal'] and receipt['changed']==[] and receipt['production_restored'];tree={}
 for line in subprocess.check_output(['git','-C',REPO,'ls-tree','-r',head],text=True).splitlines():
  meta,path=line.split('\t',1);mode,typ,oid=meta.split();tree[path]=(typ,oid)
 proc=subprocess.Popen(['git','-C',REPO,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);memo={};bindings={}
 for path,h in freeze.items():
  typ,oid=tree[path];assert typ=='blob'
  if oid not in memo:
   proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();assert hdr[1]==b'blob';left=int(hdr[2]);d=hashlib.sha256()
   while left:
    b=proc.stdout.read(min(left,1048576));assert b;d.update(b);left-=len(b)
   assert proc.stdout.read(1)==b'\n';memo[oid]=d.hexdigest()
  expected=manifest['original_sha256'] if path==target else h;assert memo[oid]==expected,(label,path)
  bindings[path]={'base':head,'blob':oid,'executed_sha256':h,'kind':'exact_test_postimage' if path==target else 'unchanged_git_blob'}
 proc.stdin.close();assert proc.wait()==0
 q=S/label;q.mkdir(exist_ok=True)
 for n in ['original.rs','diagnostic.rs','candidate.patch','manifest.json','receipt.json','execution.log','summary.json','executed-source-freeze.json','run.py','independent-review.json','carver-review.json','controller-review.json','summarizer-review-final.json','REVIEW.md']:
  f=directory/n
  if f.exists():shutil.copyfile(f,q/n)
 (q/'SOURCE-GIT-BINDINGS.json').write_text(json.dumps({'source':head,'paths':len(bindings),'all_match':True,'test_override_only':target,'receipt_changed':[],'production_restored':True,'live_worktree_hashed':False,'bindings':bindings},indent=2)+'\n')
 return len(bindings)
n=bind(D,'diagnostic2B');oldn=bind(OLD,'prior200M-control');assert n==3532 and oldn==3526
for path in ['runtime/bootstrap/macro.json','runtime/bootstrap/macro.wasm','runtime/bootstrap/runtime.json','runtime/bootstrap/runtime.wasm','crates/suss-compile/src/portable_macros.rs']:
 b=subprocess.check_output(['git','-C',REPO,'show',r['base']+':'+path]);assert H(b)==L(D/'executed-source-freeze.json')[path];q=S/'exact4f-source'/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
t=(D/'execution.log').read_text();assert re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)==[('FAILED','0','1','0')]
expected=['start','provenance','caller-form','caller-environment','arguments','invoked','decoded'];events=[(s,int(v)) for s,v in re.findall(r'(?<![\w-])macro-fuel user/declaration-facts ([\w-]+): (\d+)$',t,re.M)];assert len(events)==10 and [s for s,v in events[:7]]==expected and [s for s,v in events[7:]]==expected[:3]
assert all(x[1]>=y[1] for x,y in zip(events[:7],events[1:7]));first=dict(events[:7]);second=dict(events[7:]);assert first['start']==1999999819 and second['start']==1999999804
costs={expected[i]+'→'+expected[i+1]:events[i][1]-events[i+1][1] for i in range(6)};total=first['start']-first['decoded'];assert total==1701285927 and sum(costs.values())==total and costs['caller-form→caller-environment']==1701066103 and costs['arguments→invoked']==210097 and costs['invoked→decoded']==116
assert summary['requests'][0]['completed_expansion_interval_fuel']==total and len(summary['requests'])==2 and not summary['requests'][1]['complete_expected_chain'] and not summary['test_pass_observed']
assert 'span: 0..36' in t and 'caller &env input transport' in t and 'all fuel consumed' in t
review={'verdict':'VERIFIED_TERMINAL_DIAGNOSTIC_FAILURE_NOT_ACCEPTANCE','source':r['base'],'counts':{'pass':0,'fail':1,'ignored':0},'seconds':r['seconds'],'2B_initial_remaining':first['start'],'first_Runtime_request':{'all7stages_completed':True,'observations':events[:7],'start_to_decoded':total,'adjacent_nonoverlapping_intervals':costs,'caller_projection_GC_assertions':'Reached/passed by unchanged sequential source before second eval_with_macros unwrap at39:14; inferred from control flow and panic location, not separately logged assertions.'},'second_Runtime_request':{'observations':events[7:],'failure_stage':'caller &env input transport','span':'0..36','unfinished_required_cost':None},'Macro_caller_phase':'UNEXECUTED after Runtime failure','source_binding':{'2B_frozen_paths':n,'prior200M_frozen_paths':oldn,'all_match_git_plus_exact_test_override':True,'restored_receipts':True,'live_root_hashed':False},'whole_compilation_fuel':None,'default_budget_acceptance':False,'limits':['Actual2B maximum evidenced by setter and start1999999819; not assumed sufficient, second request still fails.','Start-to-decoded excludes earlier setup/provenance budget installation, outer compilation, caller runtime work, external read/GC/assertions.','Adjacent stage deltas include work charged in that macro account, not a host-vs-guest partition or exclusive transformer profile.','No extrapolation of unfinished second request; Macro caller phase unexecuted.','Prior200M uses separate d38 tuple; no union of test counts or causal comparison with changed4f source.']}
(P/'independent-review.json').write_text(json.dumps(review,indent=2)+'\n');shutil.copyfile(P/'independent-review.json',S/'independent-review.json')
report=f'''# PR2562B CoreEnv completion diagnostic\n\nExact4f source plus comment+Macro allowance2_000_000_000 only. Original caller defaults, both caller phases, full corpus and all assertions remain in source. Terminal exit101/0PASS1fuelFAIL0ignored;{r['seconds']:.3f}s. Changed[], production_restored=true; controller/child exited. All3532executed inputs bind to Git4f except exact retained testpostimage. No current-root hashes or slot-log bytes used.\n\nFirst Runtime request completed all7macro stages. Initial remaining1,999,999,819 demonstrates actual2B scope. Start→decoded actual1,701,285,927units; caller-form→caller-environment1,701,066,103 (1,999,996,362→298,930,259); arguments6,154; transformer interval210,097; decode116. First macro request completion is NOT completion of full test or whole compile. Sequential source/panic location shows first caller projection/GC/assertions passed before second eval.\n\nSecond Runtime request starts1,999,999,804 then caller-form1,999,996,335; caller&env0..36 exhausts. Required unfinished cost UNKNOWN. Remaining Macro caller phase and its two requests unexecuted.2B is insufficient for this full fixture. Wholecompilation cost UNKNOWN: stages exclude outer compiler/setup/caller execution/external decode/GC/assertions. No default-budget acceptance credit, no allowance change proposed.\n\nPrior200M control retained in separate directory/tuple: actual200M stillfailed, d38 source,3526Gitbound paths; no union/count or same-source comparison. All raw controls/reviews/argv/environment/normalBOOT bytes and source hashes retained. This packet does not include current slot candidate or any localbaseline outcome beyond recorded predecessor gate receipt.\n''';(P/'REPORT.md').write_text(report);shutil.copyfile(P/'REPORT.md',S/'REPORT.md');shutil.copyfile(P/'package.py',S/'package.py')
assert stable=={f.name:H(f.read_bytes()) for f in D.iterdir() if f.is_file()}
payload={str(f.relative_to(S)):{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size} for f in S.rglob('*') if f.is_file() and f.name!='MANIFEST.json'};(S/'MANIFEST.json').write_text(json.dumps({'schema':1,'payloads':payload},indent=2)+'\n');out=C/'m4-pr256-coreenv-2b-diagnostic-2026-10-18.tar.gz'
with tarfile.open(out,'w:gz') as tf:
 for f in sorted(S.rglob('*')):
  if f.is_file():tf.add(f,arcname=str(f.relative_to(S)),recursive=False)
with tarfile.open(out) as tf:
 ms=tf.getmembers();assert len(ms)==len(payload)+1==len({m.name for m in ms})
 for m in ms:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='MANIFEST.json':assert H(tf.extractfile(m).read())==payload[m.name]['sha256']
res={'archive':str(out),'sha256':H(out.read_bytes()),'members':len(payload)+1,'payloads':len(payload),'bytes':out.stat().st_size,'first_complete_macro_units':total,'whole_compilation_cost':None,'test_pass':False,'review':str(P/'independent-review.json')};(P/'package-result.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
