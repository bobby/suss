from pathlib import Path
import json,re,hashlib,datetime
p=Path(__file__).parent; old=p.parent/'pr268-010e-ci'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(f):return json.loads(f.read_text())
def clean(raw):
 t=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.decode('utf-8-sig'))
 return re.sub(r'^\S+Z ?', '',t,flags=re.M)
def inspect(raw):
 t=clean(raw);summary=[tuple(map(int,m)) for m in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)]
 failures={}
 chunks=re.split(r'^---- (.*?) stdout ----\s*$',t,flags=re.M)
 for i in range(1,len(chunks),2):
  name,body=chunks[i:i+2]
  # Bind stage/span/fuel to the same diagnostic line, not subsequent failure output.
  ls=[l for l in body.splitlines() if 'Compiled macro expansion failed during ' in l]
  assert len(ls)==1,(name,len(ls))
  l=ls[0];s=re.search(r'Compiled macro expansion failed during ([^:]+):',l);sp=re.search(r'span:\s*(\d+\.\.\d+)',l)
  assert s and sp and 'all fuel consumed by WebAssembly' in l,name
  failures[name]={'stage':s[1],'span':sp[1],'fuel':True}
 statuses=re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:$|,)',t,re.M)
 counts=[sum(s[i] for s in summary) for i in range(3)]
 assert [sum(v==x for _,v in statuses) for x in ['ok','FAILED','ignored']]==counts,counts
 return t,summary,counts,failures,statuses
manifest=load(p/'raw-log-manifest.json')
for name,h in manifest.items():assert sha((p/name).read_bytes())==h,name
run=load(p/'run-terminal.json');jobs=load(p/'jobs-terminal.json')['jobs'];a=load(p/'terminal-audit.json')
assert run['id']==39113136094 and run['head_sha']==a['head'] and run['status']=='completed' and run['conclusion']=='failure'
assert len(jobs)==10 and all(j['status']=='completed' for j in jobs)
rows=[];plans=[];complete=[];fail={};ic=[0,0,0];proofs=0
for j in jobs:
 raw=(p/f"{j['id']}.log").read_bytes();t,sums,c,fs,status=inspect(raw)
 r={'id':j['id'],'name':j['name'],'conclusion':j['conclusion'],'sha256':sha(raw),'execution_counts':c,'summary_count':len(sums),'failures':fs}
 ar=next(x for x in a['jobs'] if x['id']==j['id']);assert c==ar['counts'] and fs==ar['failed'] and r['sha256']==ar['log_sha256']
 proof=bool(re.search(r'^\[command\].*git log -1 --format=%H\n'+a['head']+r'\s*$',t,re.M));r['checkout_head_command_proof']=proof
 if j['name']!='test':assert proof;proofs+=1
 if j['name'].startswith('integration'):
  plan=json.loads(next(l for l in t.splitlines() if l.startswith('{"index":') and '"targets"' in l));plans+=list(map(tuple,plan['targets']))
  bins=re.findall(r'Running tests/([^\s.]+)\.rs',t)
  assert bins==ar['started'] and len(bins)==len(sums)
  r['completed_targets']=bins;complete+=bins;ic=[x+y for x,y in zip(ic,c)]
 if j['name']=='foundation':
  py=sum(map(int,re.findall(r'^Ran (\d+) tests? in ',t,re.M)));assert py==353;r['python_executions']=py
 fail.update(fs);rows.append(r)
assert len(plans)==len(set(plans))==259 and len(complete)==len(set(complete))==30
assert ic==[111,14,0] and len(fail)==14
# Independent raw control parse, deduplicated by log bytes.
oldfail={};seen=set();oldcounts=[0,0,0]
for f in old.glob('*.log'):
 raw=f.read_bytes();h=sha(raw)
 if h in seen:continue
 seen.add(h);t,sums,c,fs,status=inspect(raw);oldfail.update(fs)
assert fail==oldfail
unexec=[list(x) for x in plans if x[1] not in complete]
# Plan tuple is (package,target); assert explicit inventory closure.
assert len(unexec)==229
out={'verdict':'approved_with_scope_limits','run':run['id'],'head':a['head'],'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{'manifest_entries_verified':len(manifest),'terminal_jobs':len(jobs),'checkout_head_command_proofs':proofs,'summary_counts_equal_individual_test_status_counts':True,'each_failure_diagnostic_independently_binds_fuel_stage_span':True,'audit_counts_and_failures_match_raw':True,'raw_010e_failure_name_stage_span_fuel_equal':True},'foundation_executions':[542,0,1],'foundation_python_executions':353,'integration_executions':ic,'integration_targets':{'planned':259,'completed':30,'started_unfinished':0,'unexecuted':229,'unexecuted_inventory':unexec},'control':{'head':load(old/'terminal-audit.json')['head'],'run':load(old/'terminal-audit.json')['run'],'observed_failed_names_equal':True,'observed_stage_span_and_fuel_equal':True,'observed_failed_names':sorted(fail)},'jobs':rows,'input_sha256':{n:sha((p/n).read_bytes()) for n in ['terminal-audit.json','raw-log-manifest.json','audit.py','run-terminal.json','jobs-terminal.json']},'limits':['Counts are executed test rows, including any repeated foundation executions; not distinct-test counts.','Nine git-log checkout proofs establish logged checked-out HEAD, not per-job complete clean source/input freezes.','Equal observed failure names, stages and spans do not establish identical backtraces or causes, nor general regression absence.','229 integration targets were unexecuted; no full baseline, readiness, acceptance or closure verdict.']}
(p/'independent-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['jobs','integration_targets','control','input_sha256','limits']},indent=2));print('unexecuted',len(unexec),'same failures',len(fail))
