from pathlib import Path
import subprocess,json,re,hashlib,datetime
p=Path(__file__).parent
head='fd7844109fbf14ee7f78d46ae735faffdfd23c73'; rid=39113136094
def api(route):return subprocess.check_output(['gh','api','--allow-escape-sequences','repos/bobby/suss/'+route])
run=json.loads(api(f'actions/runs/{rid}'));jobs=json.loads(api(f'actions/runs/{rid}/jobs?per_page=100'))
assert run['head_sha']==head
terminal=run['status']=='completed'
(p/('run-terminal.json' if terminal else 'run-progress-api.json')).write_text(json.dumps(run,indent=2))
(p/('jobs-terminal.json' if terminal else 'jobs-progress-api.json')).write_text(json.dumps(jobs,indent=2))
old=json.loads((p.parent/'pr268-010e-ci/terminal-audit.json').read_text());before={n:v for j in old['jobs'] for n,v in j['failed'].items()}
rows=[];failures={};plans=[];started=[]
for j in jobs['jobs']:
 row={k:j[k] for k in ['name','id','status','conclusion']}
 if j['status']!='completed':rows.append(row);continue
 f=p/f"{j['id']}.log"
 if not f.exists():f.write_bytes(api(f"actions/jobs/{j['id']}/logs"))
 raw=f.read_bytes();text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.decode('utf-8-sig'))
 counts=[list(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)]
 fs={};matches=list(re.finditer(r'---- (.*?) stdout ----',text))
 for i,m in enumerate(matches):
  body=text[m.end():matches[i+1].start() if i+1<len(matches) else len(text)];stage=re.search(r'Compiled macro expansion failed during ([^:]+):',body);span=re.search(r'span:\s*(\d+\.\.\d+)',body)
  fs[m[1]]=dict(stage=stage[1] if stage else None,span=span[1] if span else None,fuel='all fuel consumed' in body)
 failures.update(fs)
 proofs=re.findall(r'^\S+Z ([0-9a-f]{40})\s*$',text,re.M)
 row.update(counts=[sum(c[i] for c in counts) for i in range(3)],failed=fs,checkout_hash_lines=proofs,checkout_proof=head in proofs,log_sha256=hashlib.sha256(raw).hexdigest())
 if j['name'].startswith('integration'):
  match=re.search(r'(\{"index": \d+, "count": 8, "total_targets": \d+, "targets": .*\})',text);assert match,j['name'];plan=json.loads(match[1]);plans.extend(map(tuple,plan['targets']));bins=re.findall(r'Running tests/([^\s.]+)\.rs',text);row.update(planned=len(plan['targets']),started=bins,completed_target_summaries=len(counts));assert len(bins)==len(counts),j['name'];started.extend(bins)
 if j['name']=='foundation':row['python_tests']=sum(map(int,re.findall(r'Ran (\d+) tests? in ',text)))
 rows.append(row)
comparison={n:dict(current=v,previous=before.get(n),same_stage_and_span=n in before and v['stage']==before[n]['stage'] and v['span']==before[n]['span']) for n,v in failures.items()}
integ=[j for j in rows if j['name'].startswith('integration') and j['status']=='completed'];foundation=next((j for j in rows if j['name']=='foundation' and j['status']=='completed'),None)
a=dict(head=head,run=rid,status=run['status'],conclusion=run['conclusion'],audited_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),completed_integration_jobs=len(integ),integration=[sum(j['counts'][i] for j in integ) for i in range(3)],foundation=foundation['counts'] if foundation else None,foundation_python=foundation.get('python_tests') if foundation else None,observed_failed_names=sorted(failures),new_failed_names=sorted(set(failures)-set(before)),all_observed_same_stage_and_span=all(v['same_stage_and_span'] for v in comparison.values()),jobs=rows,failure_comparison=comparison)
if terminal:
 assert len(rows)==10 and all(j['status']=='completed' for j in rows)
 assert all(j['checkout_proof'] for j in rows if j['name']!='test')
 assert len(integ)==8 and len(set(plans))==len(plans)
 a.update(planned_targets=len(plans),completed_targets=len(started),unexecuted_targets=len(plans)-len(started),failed_names_match_previous=set(failures)==set(before),all_failures_fuel=all(v['fuel'] for v in failures.values()))
 a['limits']='Completed harness executions only. Unexecuted integration targets and later package/doc tests are not established; matching observed failures does not prove absence of other regressions. Checkout SHA proof is not a per-job clean source freeze.'
(p/('terminal-audit.json' if terminal else 'partial-audit.json')).write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({k:v for k,v in a.items() if k not in ['jobs','failure_comparison','observed_failed_names']},indent=2))
