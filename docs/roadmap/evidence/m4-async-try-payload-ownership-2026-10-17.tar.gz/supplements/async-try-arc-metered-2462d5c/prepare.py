from pathlib import Path
import subprocess,difflib,hashlib,json
repo='/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots'
out=Path(__file__).parent
paths=['crates/suss-compile/src/portable/hir.rs','crates/suss-compile/src/portable/hir/exceptions.rs','crates/suss-compile/src/portable/hir/local_bindings.rs','crates/suss-compile/src/portable/ir.rs','crates/suss-compile/tests/portable_async_analysis.rs','crates/suss-compile/tests/portable_async_execution.rs']
before={p:subprocess.check_output(['git','show','2462d5c:'+p],cwd=repo).decode() for p in paths};after=dict(before)
p=paths[0];old='''        payload: Option<Parameter>,''';assert after[p].count(old)==1;after[p]=after[p].replace(old,'''        // Private immutable lowering facts, separate from SourceNode::Try's
        // source binding owner. Each actual construction creates a fresh Arc.
        payload: Option<std::sync::Arc<Parameter>>,''')
p=paths[1];old='''                    Parameter { id: payload.id, name: name.name.clone(), metadata: vec![],
                        span: payload.declaration.span.clone() }
                }),''';new='''                    local_bindings::capture_async_parameter(payload.id, &name.name,
                        payload.declaration.span.clone(), &mut |work| {
                            self.expander.charge_expansion_work(work, form.span.clone())
                        })
                }).transpose()?,''';assert after[p].count(old)==1;after[p]=after[p].replace(old,new)
p=paths[2];after[p]=after[p].replace('Option<Box<Hir>>, Option<Parameter>)>()','Option<Box<Hir>>, Option<Arc<Parameter>>)>()');old='payload: payload.as_ref().map(|p| cow_parameter(p, meter)).transpose()?';assert after[p].count(old)==1;after[p]=after[p].replace(old,'payload: cow_self_parameter(payload, meter)?')
needle='fn cow_self_parameter(parameter:';idx=after[p].index(needle)
after[p]=after[p][:idx]+'''/// A fresh lowering-only catch parameter. The hidden source LocalBinding
/// remains a separate owner; neither Arc identity authorizes guest reuse.
/// Prepare the actual copied name, then prepay Parameter and Arc header.
pub(super) fn capture_async_parameter(id: BindingId, name: &str, span: Range<usize>,
    meter: &mut CowMeter<'_>) -> Result<Arc<Parameter>, Diagnostic> {
    let name = cow_text(name, meter)?;
    capture_self_parameter(Parameter { id, name, metadata: Vec::new(), span }, meter)
}
'''+after[p][idx:]
after[p]=after[p].replace('payload: Some(parameter()) }.census_created()', 'payload: Some(Arc::new(parameter())) }.census_created()')
p=paths[3];old='payload.as_ref(), Vec::new()';assert after[p].count(old)==1;after[p]=after[p].replace(old,'payload.as_deref(), Vec::new()')
# Tests inserted separately below.
for p in paths:
 extra=out/('extra-'+Path(p).name+'.txt')
 if extra.exists():
  if p.endswith('local_bindings.rs'):
   idx=after[p].rfind('\n}');after[p]=after[p][:idx]+extra.read_text()+after[p][idx:]
  else:after[p]+=extra.read_text()
diffs=[];manifest={'base':subprocess.check_output(['git','rev-parse','2462d5c'],cwd=repo).decode().strip(),'files':{}}
for p in paths:
 for label,contents in [('before',before[p]),('after',after[p])]:
  dest=out/label/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(contents)
 manifest['files'][p]={'before_sha256':hashlib.sha256(before[p].encode()).hexdigest(),'after_sha256':hashlib.sha256(after[p].encode()).hexdigest()}
 diffs.extend(difflib.unified_diff(before[p].splitlines(True),after[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p))
(out/'async-try-arc.patch').write_text(''.join(diffs));manifest['patch_sha256']=hashlib.sha256((out/'async-try-arc.patch').read_bytes()).hexdigest();(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
