// Cache-only type model. DO NOT EXECUTE until main releases producer73414.
#![allow(dead_code)]
use suss_compile::portable::hir::*;
use suss_compile::portable::resolve::Global;
use std::{mem::size_of,ops::Range,sync::Arc};
enum BeforeModel {
    /// Deferred executable body and its lexical captures; never a body value.
    Future {
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    Await {
        value: Box<Hir>,
    },
    /// Suspension-aware executable regions, before closure packaging.
    AsyncTry {
        body: Box<Hir>,
        handler: Option<Box<Hir>>,
        cleanup: Option<Box<Hir>>,
        payload: Option<Parameter>,
    },
    AsyncDynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Bitwise {
        operation: Bitwise,
        arguments: Vec<Hir>,
    },
    Comparison {
        operation: Comparison,
        arguments: Vec<Hir>,
    },
    /// Compiler bootstrap primitive, independent of mutable core vars.
    NilTest(Box<Hir>),
    Array {
        operation: ArrayOperation,
        arguments: Vec<Hir>,
    },
    DynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Assign {
        global: Global,
        value: Box<Hir>,
    },
    /// A terminal language throw of an evaluated portable value.
    Throw(Box<Hir>),
    /// Private compiled regions: body/cleanup arity0, handler arity1 or nil.
    Try {
        regions: [Box<Hir>; 3],
    },
    Nominal {
        operation: Nominal,
        arguments: Vec<Hir>,
    },
    Literal(Literal),
    Local(BindingId),
    /// Read a live cell by resolved language identity, never by a Wasm index.
    Global(Global),
    /// Reader calls use a live public value only after successful initialization.
    GlobalOrFallback {
        global: Global,
        fallback: Global,
    },
    /// Private cell identity for a captured live protocol fallback.
    GlobalCell(Global),
    Definition {
        global: Global,
        syntax: DefinitionSyntax,
        name_span: Range<usize>,
        initializer: Option<Box<Hir>>,
        once: bool,
    },
    Let {
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Loop {
        target: LoopId,
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Recur {
        target: LoopId,
        arguments: Vec<Hir>,
    },
    If {
        condition: Box<Hir>,
        consequent: Box<Hir>,
        alternative: Box<Hir>,
    },
    Do(Vec<Hir>),
    Function {
        parameters: Vec<Parameter>,
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    GeneralFunction {
        methods: Vec<Method>,
        captures: Vec<BindingId>,
        self_binding: Option<std::sync::Arc<Parameter>>,
        rest_class: Option<Global>,
    },
    Call {
        callee: Box<Hir>,
        arguments: Vec<Hir>,
    },
    /// Resolved bootstrap intrinsic identity, never an unresolved name.
    Arithmetic {
        operator: Arithmetic,
        arguments: Vec<Hir>,
    },
}
enum ArcPayloadModel {
    /// Deferred executable body and its lexical captures; never a body value.
    Future {
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    Await {
        value: Box<Hir>,
    },
    /// Suspension-aware executable regions, before closure packaging.
    AsyncTry {
        body: Box<Hir>,
        handler: Option<Box<Hir>>,
        cleanup: Option<Box<Hir>>,
        payload: Option<Arc<Parameter>>,
    },
    AsyncDynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Bitwise {
        operation: Bitwise,
        arguments: Vec<Hir>,
    },
    Comparison {
        operation: Comparison,
        arguments: Vec<Hir>,
    },
    /// Compiler bootstrap primitive, independent of mutable core vars.
    NilTest(Box<Hir>),
    Array {
        operation: ArrayOperation,
        arguments: Vec<Hir>,
    },
    DynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Assign {
        global: Global,
        value: Box<Hir>,
    },
    /// A terminal language throw of an evaluated portable value.
    Throw(Box<Hir>),
    /// Private compiled regions: body/cleanup arity0, handler arity1 or nil.
    Try {
        regions: [Box<Hir>; 3],
    },
    Nominal {
        operation: Nominal,
        arguments: Vec<Hir>,
    },
    Literal(Literal),
    Local(BindingId),
    /// Read a live cell by resolved language identity, never by a Wasm index.
    Global(Global),
    /// Reader calls use a live public value only after successful initialization.
    GlobalOrFallback {
        global: Global,
        fallback: Global,
    },
    /// Private cell identity for a captured live protocol fallback.
    GlobalCell(Global),
    Definition {
        global: Global,
        syntax: DefinitionSyntax,
        name_span: Range<usize>,
        initializer: Option<Box<Hir>>,
        once: bool,
    },
    Let {
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Loop {
        target: LoopId,
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Recur {
        target: LoopId,
        arguments: Vec<Hir>,
    },
    If {
        condition: Box<Hir>,
        consequent: Box<Hir>,
        alternative: Box<Hir>,
    },
    Do(Vec<Hir>),
    Function {
        parameters: Vec<Parameter>,
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    GeneralFunction {
        methods: Vec<Method>,
        captures: Vec<BindingId>,
        self_binding: Option<std::sync::Arc<Parameter>>,
        rest_class: Option<Global>,
    },
    Call {
        callee: Box<Hir>,
        arguments: Vec<Hir>,
    },
    /// Resolved bootstrap intrinsic identity, never an unresolved name.
    Arithmetic {
        operator: Arithmetic,
        arguments: Vec<Hir>,
    },
}
struct HirArcModel { source: Option<Arc<SourceAnalysis>>, span: Range<usize>, metadata: Vec<suss_reader::forms::Form>, ty: Type, kind: ArcPayloadModel }
fn main() {
 assert_eq!(size_of::<BeforeModel>(),size_of::<Expression>(),"baseline model mismatch");
 println!("Expression={} Hir={} BeforeModel={} ArcPayloadModel={} HirArcModel={} ArcParameter={} OptionArcParameter={} Parameter={} ArcHeaderModel={}",
 size_of::<Expression>(),size_of::<Hir>(),size_of::<BeforeModel>(),size_of::<ArcPayloadModel>(),size_of::<HirArcModel>(),size_of::<Arc<Parameter>>(),size_of::<Option<Arc<Parameter>>>(),size_of::<Parameter>(),2*size_of::<usize>());
}
