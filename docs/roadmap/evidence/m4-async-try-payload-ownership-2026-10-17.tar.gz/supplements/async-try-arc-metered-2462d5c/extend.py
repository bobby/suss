from pathlib import Path
import subprocess,json,hashlib,difflib
out=Path(__file__).parent;repo='/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots'
# Always regenerate original Arc packet first to make this script repeatable.
subprocess.run(['python',str(out/'prepare.py')],check=True,stdout=subprocess.DEVNULL)
rel='crates/suss-compile/src/portable_macro_graph.rs'
before=subprocess.check_output(['git','show','2462d5c:'+rel],cwd=repo).decode()
for part in ['before','after']:
 p=out/part/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(before)
p=out/'after/crates/suss-compile/src/portable/hir.rs';s=p.read_text();idx=s.index('\nimpl Drop for Hir {');s=s[:idx]+'''
/// Copy owned HIR through the active caller's cumulative work meter. Native
/// source owners stay shared; each owned child and parameter retain is charged.
pub(crate) fn clone_hir_metered(node: &Hir,
    meter: &mut dyn FnMut(u64) -> Result<(), Diagnostic>) -> Result<Hir, Diagnostic> {
    local_bindings::cow_hir(node, meter)
}
'''+s[idx:];p.write_text(s)
p=out/'after/crates/suss-compile/src/portable/hir/local_bindings.rs';s=p.read_text();s=s.replace('fn cow_hir(node: &Hir, meter:', 'pub(super) fn cow_hir(node: &Hir, meter:');p.write_text(s)
p=out/'after/crates/suss-compile/src/portable_macro_graph.rs';s=p.read_text();idx=s.index('    pub fn new(bridge:');s=s[:idx]+'''    fn clone_hir(&mut self, node: &Hir) -> Result<Hir> {
        preserve_source_error(node.span.clone(),
            &mut |units| self.session.charge_host_work(units),
            |meter| hir::clone_hir_metered(node, meter))
    }
'''+s[idx:];s=s.replace('let native = self.task(Task::Ast(hir.clone()))?;', 'let copied = self.clone_hir(hir)?;\n        let native = self.task(Task::Ast(copied))?;');s=s.replace('self.task(Task::Lowering(hir.clone()))', 'let copied = self.clone_hir(hir)?;\n        self.task(Task::Lowering(copied))');p.write_text(s)
p=out/'after/crates/suss-compile/src/portable/hir/exceptions.rs';s=p.read_text()
s=s.replace('self.exception_region(form, vec![], body.clone())','let copied = self.clone_local_hir(body)?;\n            self.exception_region(form, vec![], copied)')
s=s.replace('self.exception_region(form, vec![parameter], source_handler.clone())', 'let copied = self.clone_local_hir(&source_handler)?;\n            self.exception_region(form, vec![parameter], copied)')
s=s.replace('let body = self.exception_region(form, vec![], source_body.clone());', 'let copied_body = self.clone_local_hir(&source_body)?;\n        let body = self.exception_region(form, vec![], copied_body);')
s=s.replace('body: Box::new(source_body.clone()),','body: Box::new(self.clone_local_hir(&source_body)?),')
s=s.replace('handler: payload.as_ref().map(|_| Box::new(source_handler.clone())),','handler: payload.as_ref().map(|_| self.clone_local_hir(&source_handler).map(Box::new)).transpose()?,')
s=s.replace('cleanup: source_cleanup.clone().map(Box::new),','cleanup: source_cleanup.as_ref().map(|body| self.clone_local_hir(body).map(Box::new)).transpose()?,')
p.write_text(s)
# AST keeps its single metered HIR copy for the exported lowering field.
p=out/'after/crates/suss-compile/src/portable_macro_graph.rs';s=p.read_text()
s=s.replace('Task::Ast(value) => self.ast_record(id, &value, 0)?,', 'Task::Ast(value) => self.ast_record(id, value, 0)?,')
s=s.replace('    fn ast_record(&mut self, slot: Value, hir: &Hir, depth: usize) -> Result<Value> {\n        let source = hir.source.as_ref().expect("source AST task");', '    fn ast_record(&mut self, slot: Value, hir: Hir, depth: usize) -> Result<Value> {\n        // The original owned HIR is needed later by the exported lowering field.\n        // Retain its source separately so HIR can move without stripping facts.\n        self.charge(1)?;\n        let source_owner = hir.source.as_ref().expect("source AST task").clone();\n        let source = &source_owner;')
s=s.replace('        let lowering = self.lowering(hir, depth + 1)?;', '        // Same queue position as before; move the already copied HIR rather\n        // than making a second recursive copy for suss/lowering.\n        let lowering = self.task(Task::Lowering(hir))?;')
s=s.replace('        let value = self.source_boundary(source_roots::Owner::Ast(source.clone()), native)?;\n        self.asts.insert(key, (source.clone(), value));', "        self.charge(1)?; // source_boundary consumes this owner; it does not clone it\n        let boundary_source = source.clone();\n        let value = self.source_boundary(source_roots::Owner::Ast(boundary_source), native)?;\n        self.charge(1)?; // memo table's owning reference\n        self.asts.insert(key, (source.clone(), value));")
p.write_text(s)
# Native helper/error regression exercises same Graph adapter without a Session
# budget refill or mock source authority.
p=out/'after/crates/suss-compile/src/portable_macro_graph.rs';s=p.read_text()+'''
#[cfg(test)]
mod async_payload_clone_meter_tests {
    use super::*;
    #[test]
    fn graph_hir_clone_preserves_typed_error_and_payload_owner_on_failed_retain() {
        let parameter = Arc::new(hir::Parameter { id: hir::BindingId(7), name: "payload".into(),
            metadata: vec![], span: 0..7 });
        let node = Hir { source: None, span: 0..7, metadata: vec![], ty: hir::Type::Value,
            kind: Expression::AsyncTry { body: Box::new(Hir { source: None, span: 0..7,
                metadata: vec![], ty: hir::Type::Nil, kind: Expression::Literal(Literal::Nil) }),
                handler: None, cleanup: None, payload: Some(parameter.clone()) } };
        let mut measured = 0;
        let copied = preserve_source_error(node.span.clone(),
            &mut |work| { measured += work; Ok(()) },
            |meter| hir::clone_hir_metered(&node, meter)).unwrap();
        let Expression::AsyncTry { payload: Some(actual), .. } = &copied.kind else { panic!("payload") };
        assert!(Arc::ptr_eq(actual, &parameter));
        let count = Arc::strong_count(&parameter);
        let mut remaining = measured - 1;
        let result = preserve_source_error(node.span.clone(), &mut |work| {
            remaining = remaining.checked_sub(work).ok_or(SessionError::ForeignValue)?;
            Ok(())
        }, |meter| hir::clone_hir_metered(&node, meter));
        assert!(matches!(result, Err(SessionError::ForeignValue)), "do not relabel typed Session errors");
        assert_eq!(Arc::strong_count(&parameter), count);
    }
}
''';p.write_text(s)
p=out/'after/crates/suss-compile/src/portable_macro_graph.rs';s=p.read_text()
idx=s.rfind('\n}')
s=s[:idx]+(out/'extra-graph-ast-test.txt').read_text()+s[idx:]
p.write_text(s)
manifest={'base':'2462d5c85fd81096ee30dddedeef68ce67e10ba8','files':{}};diff=[]
for before_path in sorted((out/'before').rglob('*.rs')):
 rel=before_path.relative_to(out/'before');b=before_path.read_text();a=(out/'after'/rel).read_text()
 manifest['files'][str(rel)]={'before_sha256':hashlib.sha256(b.encode()).hexdigest(),'after_sha256':hashlib.sha256(a.encode()).hexdigest()}
 diff.extend(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
(out/'async-try-arc.patch').write_text(''.join(diff));manifest['patch_sha256']=hashlib.sha256((out/'async-try-arc.patch').read_bytes()).hexdigest();(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('patch',manifest['patch_sha256'],'files',len(manifest['files']))
