# Original M4 scope coverage audit

Read-only audit, 2026-10-17. Native source HEAD: cd20a986a0c7a4e22067917c41c33cb8a8eb285a. GitHub issue bodies captured beside this file are the scope/state authority; historical acceptance-m4.md is not used as completion authority. No Cargo or new Suss execution. No issues created/closed.

Verdict: no original acceptance clause found with BOTH no executing evidence and no explicit open issue coverage. This is scope-accountability, NOT original-issue/M4 acceptance or current-head full-suite certification. Historical successes below remain historical; cd20 focused passes do not recertify the whole collection corpus.

Evidence keys (absolute cache paths):
- H: /home/bobby/.cache/suss-m4-work/cold-reader-full-baseline-classification.json and cold-reader-full-baseline.log: executed 5aff baseline, 1808 pass/0 fail/22 ignore. Individual names establish historical execution only.
- N: /home/bobby/.cache/suss-m4-work/native-async-payload-macro-session-candidate/receipt.json and adjacent raw stage logs: current 2915-input producer, still live at inspection; completed core-import-full 17/0, graph-clone 2/0, async-execution 14/0, ownership 26/0, async-analysis 11/0, self-local-methods 2/0. Later stages not presumed complete.
- J: /home/bobby/.cache/suss-m4-work/function-owner-jank-classification/original-m4-groups/{17-sequences,18-associative,19-contracts,summary}.json and producer-run/producer-source: historical 817 capture, mixed outcomes; NOT cd20 execution.
- A: /home/bobby/.cache/suss-m4-work/original-m4-16-19-acceptance-audit/README.md, focused-test-index.json, source-manifest.json: assertion/body mapping, NOT execution by itself.
- P: /home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots/ (relative source paths below).

| Original criterion | Concrete test / reference evidence | Remaining open scope / qualification |
|---|---|---|
| #16 notices, hashes, explicit adaptations | scripts/test_core_import.py: reproduction notices/licenses, exact-source patch; runtime/core-import manifests/reviews; scripts/cljs_reviews.py | Existing Python execution captured in N foundation companion; no review invalidation inferred from prose |
| #16 source updates invalidate review | scripts/test_core_import.py stale_review_and_unreviewed_selection; scripts/test_cljs_reviews.py stale commit/hash/unknown declaration negatives | No uncovered clause; generated review/manifest checks remain required on every new tuple |
| #16 forms load in Suss namespaces | crates/suss-cli/tests/core_import.rs 17 unchanged cases; N core-import-full.log 17/0 under default allowances | #270 retains full focused/baseline/CI gate; this pass does not close it |
| #17 31/32/33 and deeper trie values/effects | portable_vector_trie.rs; compiled_macro_vectors.rs 1056/1057 collapse/regrowth; pinned vector fixtures; named passes in H | Current-head broad rerun not claimed; original stress allowances are explicit, not default transport proof |
| #17 sharing/metadata | portable_subvector.rs backing identity+GC; vector path-copy/old-value/metadata tests; H | #257/#264 cover retained compiler-source identity/integrity extensions, not substitutes for collection identity tests |
| #17 list/seq/map entries | portable_sequences.rs, core_sequence_interfaces.rs, portable_apply_sequences.rs, compiled_macro_hamt_sequences.rs; H + pinned observations | #241/#252 cover unchanged map transport; J reader-rejected bodies remain unexecuted, not missing native sequence implementation evidence |
| #17 lazy/chunk effects | portable_lazy_sequences.rs, portable_lazy_transformations.rs, portable_chunk_effects.rs; exact traces/force-once/throw retry/GC; H | Native reference supplements are essential: J lazy-seq/assert and realized?/promise setup failures do not pass |
| #18 collisions/deletion/nil/false | compiled_macro_hash_maps.rs collision+dense deletion/reinsert; compiled_macro_sets.rs; pinned hash-map/set observations; H | #241/#252 cover complete original map declaration and resource blockers |
| #18 comparators/iteration | portable_sorted_comparator_prerequisites.rs, portable_sorted_tree_nodes.rs, portable_sorted_tree_collections.rs, core_sorted_interfaces.rs; H | J sort/sorted? failures remain classified; raw comparator/tree/interface tests are independent evidence, not whole-Jank pass |
| #18 queues | portable_queues.rs: FIFO, metadata, raw front/rear sharing and iterator mutation/error; H | No new uncovered criterion found |
| #18 cross-type equality/nominal records | compiled_public_records.rs actual defrecord classes/independent fields/meta decode; vector/HAMT/sorted/queue equality corpora; H | Excerpted record cases are not entire Jank namespaces; no broad conformance claim |
| #19 equal values hash equally | portable_collection_hash.rs, portable_caching_hash.rs; cross-type sequential/unordered, public-record hash/invalidation; H | #261 literal memo provenance; #257 authenticated warming/poison; their authority boundaries remain open |
| #19 metadata per required operation | vector/Subvec/sequence/lazy/chunk/HAMT/sorted/queue + compiled_public_records.rs assoc/dissoc/GC tests; H | #257/#264 cover retained compiler metadata and child identity separately |
| #19 transient invalidation | portable_transient_errors.rs; compiled_macro_hamt_lookup.rs; compiled_macro_sets.rs all operations after persistent!; H | J public pop! load failure retained; private protocol/lifecycle coverage is actual evidence, not public pop! success |
| #19 Reduced stops before later effects | portable_reduction.rs, portable_reduction_dispatch.rs, portable_reduce_kv_fallback.rs; exact callback/throw/stop traces, 31/32/33 boundaries; H | J reduce body excludes Reduced: cannot replace native effect-sensitive supplements |
| #19 all reduction/transducer arities (spec section4) | tests/oracle/hamt-sequence-cases.json includes into0/1 and transduce3/4; compiled_macro_hamt_sequences.rs consumes cases; portable_transducers.rs + transducer-cases.json sequence1/2/variadic, completing1/2, eduction/both reduce arities; portable_reduction_dispatch.rs; H named reduction/transducer passes | Existing A warning about 26-case corpus ALONE is correct, but complementary HAMT corpus supplies concrete missing arity examples. No newly demonstrated arity hole; do not infer all type/arity combinations from one test name |
| #19 structural sharing | portable_hash_map_sharing.rs, vector/Subvec, sorted tree, portable_queues.rs raw roots/children; H | #257/#264 source-owner sharing is distinct and remains checked, not pointer-only authority |

Open-issue coverage boundaries:
- #241: original unchanged pinned map declaration, input/result transport and observable metadata/env.
- #252: cumulative host/guest budget, remaining arbitrary HIR clone accounting, guards, cancellation/recovery, AOT/REPL publication. Not a blanket collection-semantic issue.
- #257: retained metadata integrity, authenticated memos, poisoning and callbacks.
- #261: explicit analyzer literal provenance, live IHash, source-tag default execution and applicable Jank.
- #264: captured namespace/declaration child identity, complete checked composition/callback rebuilding.
- #270: all17 core imports plus complete five-variant/two-source-phase source-child negative cohort, default budget, map IDs, final baseline/CI. cd20 core import is now executed; other clauses remain open.

Genuine uncovered original clauses identified: NONE. Verification gaps remain, not untracked feature work: no current cd20 complete collection/full-baseline/Jank acceptance is established by this audit. Preserve J mixed result counts and inspect new exact-head results before closure. Unresolved public Jank helpers (assert, promise, sort, distinct, ->>, pop!, long-array), unsupported nonportable reader literals and guest-judged/skip mismatches are retained compatibility outcomes; none automatically proves a new uncovered original collection clause, because focused portable reference tests cover the relevant clause. Do not silently assign those unrelated helpers to the six bounded issues or call them fixed.
