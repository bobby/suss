use suss_compile::portable::{self,hir::{Hir,Expression,Literal}};
use suss_reader::forms::Kind;
fn main() {
        fn single(mut node: &Hir) -> &Hir {
            while let Expression::Do(items) = &node.kind {
                // Preserve the genuine annotated do; only unwrap synthetic or
                // metadata-empty sequence wrappers around the selected node.
                if node.source.as_ref().is_some_and(|source| !source.form.metadata.is_empty()) { break; }
                assert_eq!(items.len(), 1);
                node = &items[0];
            }
            node
        }
        // Inspect executable children only, never retained SourceAnalysis HIR:
        // the assertion must observe the task's actual lowering allocation.
        fn string_buffer<'a>(node: &'a Hir, expected: &[u16]) -> Option<&'a [u16]> {
            match &node.kind {
                Expression::Literal(Literal::String(units)) if units.as_slice() == expected => Some(units),
                Expression::Call { callee, arguments } => string_buffer(callee, expected)
                    .or_else(|| arguments.iter().find_map(|child| string_buffer(child, expected))),
                Expression::Array { arguments, .. } | Expression::Nominal { arguments, .. }
                | Expression::Do(arguments) => arguments.iter().find_map(|child| string_buffer(child, expected)),
                Expression::Let { bindings, body } | Expression::Loop { bindings, body, .. } =>
                    bindings.iter().find_map(|binding| string_buffer(&binding.value, expected))
                        .or_else(|| string_buffer(body, expected)),
                _ => None,
            }
        }
    let text = "^:transfer (do \"owned-storage\")";
    let analyzed = portable::analyze(text).expect("analyze builtin-only annotated do");
    let node = single(&analyzed);
    let source = node.source.as_ref().expect("actual source owner");
    assert!(matches!(&source.form.kind, Kind::List(_)));
    assert!(!source.form.metadata.is_empty());
    assert!(matches!(&node.kind, Expression::Do(_)));
    let expected: Vec<u16> = "owned-storage".encode_utf16().collect();
    let units = string_buffer(node, &expected).expect("exact owned literal in executable HIR");
    assert_eq!(units, expected);
    println!("analysis_ok=true annotated_do_preserved=true source_kind=list source_metadata={} hir_metadata={} exact_utf16_units={}",source.form.metadata.len(),node.metadata.len(),units.len());
}
