from pathlib import Path
import subprocess,hashlib,json,time
out=Path(__file__).parent;deps=Path('/home/bobby/.cache/suss-m4-work/memo-proof-cost-target/debug/deps');fp=deps.parent/'.fingerprint'
integration=fp/'suss-compile-a4fdb4a16c637b26/test-integration-test-portable_async_analysis.json'
j=json.loads(integration.read_text());wanted=next(d[3] for d in j['deps'] if d[1]=='suss_compile')
candidates=[]
for lib in deps.glob('libsuss_compile-*.rlib'):
 h=lib.stem.split('-')[1];marker=fp/('suss-compile-'+h)/'lib-suss_compile'
 if marker.exists() and int.from_bytes(bytes.fromhex(marker.read_text().strip()),'little')==wanted:candidates.append(lib)
assert len(candidates)==1,candidates
compiler=candidates[0];reader=deps/'libsuss_reader.rlib';paths=[compiler,reader]
def hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=hashes();cmd=['rustc','--edition=2024',str(out/'analyze_probe.rs'),'--extern','suss_compile='+str(compiler),'--extern','suss_reader='+str(reader),'-L','dependency='+str(deps),'-o',str(out/'analyze-probe')]
start=time.time();r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/'probe-compile.log').write_text(r.stdout)
receipt={'command':cmd,'compile_exit':r.returncode,'rlib_selection':{'integration_fingerprint':str(integration),'fingerprint_sha256':hashlib.sha256(integration.read_bytes()).hexdigest(),'suss_compile_dependency_fingerprint':wanted,'matching_library':str(compiler)},'rlib_hashes_before':before,'source_sha256':hashlib.sha256((out/'analyze_probe.rs').read_bytes()).hexdigest(),'scope':'Standalone cache-output public analyzer probe using exact library fingerprint from producer async-analysis test; no Cargo or target writes. Not Graph execution.'}
if r.returncode==0:
 run=subprocess.run([str(out/'analyze-probe')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/'probe-run.log').write_text(run.stdout);receipt.update(run_exit=run.returncode,output=run.stdout)
receipt['rlib_hashes_after']=hashes();receipt['rlibs_unchanged']=before==receipt['rlib_hashes_after'];receipt['seconds']=time.time()-start;(out/'probe-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
