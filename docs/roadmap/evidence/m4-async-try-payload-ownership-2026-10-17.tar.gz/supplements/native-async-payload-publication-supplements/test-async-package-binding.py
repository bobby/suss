from pathlib import Path
import runpy,subprocess,json,tempfile,hashlib
cache=Path(__file__).parent;m=runpy.run_path(str(cache/'package-native-async-payload.py'));repo=m['REPO'];sha=m['sha'];commit='2462d5c85fd81096ee30dddedeef68ce67e10ba8'
blobs={}
for path in ['Cargo.toml','ROADMAP.md']:
 blobs[path]=subprocess.check_output(['git','-C',str(repo),'show',commit+':'+path])
expected={'Cargo.toml':sha(blobs['Cargo.toml']),'ROADMAP.md':sha(b'intentional different snapshot'),'missing-test-only-path':sha(b'missing')}
data={sha(blobs['Cargo.toml']):blobs['Cargo.toml'],sha(b'intentional different snapshot'):b'intentional different snapshot',sha(b'missing'):b'missing'}
r=m['checkpoint_binding'](repo,commit,expected,data);assert (r['matched_count'],r['changed_count'],r['missing_count'],r['exact_match'])==(1,1,1,False)
# Verify pinned gitlink traversal against committed submodule bytes, not checkout.
link=subprocess.check_output(['git','-C',str(repo),'ls-tree',commit,'clojurescript'],text=True).split()[2]
path='src/main/cljs/cljs/core.cljs';body=subprocess.check_output(['git','-C',str(repo/'clojurescript'),'show',link+':'+path]);p='clojurescript/'+path
sub=m['checkpoint_binding'](repo,commit,{p:sha(body)},{sha(body):body});assert sub['exact_match'] and sub['object_sources'][0]['revision']==link
with tempfile.TemporaryDirectory(prefix='async-foundation-hash-check-',dir=cache) as tmp:
 base=Path(tmp);expected={'Cargo.toml':sha(blobs['Cargo.toml'])};freeze=json.dumps(expected).encode()
 good=m['foundation_hash_binding'](base,{'input_hashes':expected},expected,freeze);assert not good['mismatches'] and good['verified_maps'][0]['full_tuple_coverage']
 bad=m['foundation_hash_binding'](base,{'actual_hashes':{'Cargo.toml':'0'*64}},expected,freeze);assert bad['mismatches']
 malformed=m['foundation_hash_binding'](base,{'input_hashes':{'Cargo.toml':'wrong'}},expected,freeze);assert malformed['mismatches']
 count=m['foundation_hash_binding'](base,{'input_count':1,'inputs_unchanged':True},expected,freeze);assert not count['hash_maps_supplied'] and 'No per-path' in count['qualification']
 digest=m['foundation_hash_binding'](base,{'freeze_sha256':sha(freeze)},expected,freeze);assert not digest['mismatches'] and digest['verified_manifest_digests']
report={'scope':'Synthetic expected-byte mismatch checks against existing committed objects; not final candidate binding and no archive created. No repo writes/Cargo.', 'checkpoint_sample':r,'pinned_gitlink_sample':sub,'foundation_checks':['full-map verified','changed digest detected','malformed digest detected','count-only explicitly qualified','manifest digest verified']}
(cache/'native-async-payload-binding-helper-checks.json').write_text(json.dumps(report,indent=2)+'\n');print('Checkpoint exact/missing/changed, pinned gitlink, and5 foundation checks passed; no archive created.')
