// TYPE-ONLY MODELS: no runtime/compiler execution. Not executed yet.
// Build later against exact reviewed candidate rlib, after main releases target.
#![allow(dead_code)]
use suss_compile::portable::hir::*;
use suss_compile::portable::resolve::Global;
use std::{mem::{size_of,align_of},ops::Range,sync::Arc};
struct AsyncTryPayload { body: Box<Hir>, handler: Option<Box<Hir>>, cleanup: Option<Box<Hir>>, payload: Option<Parameter> }
struct GeneralFunctionPayload { methods: Vec<Method>, captures: Vec<BindingId>, self_binding: Option<Arc<Parameter>>, rest_class: Option<Global> }
enum UnchangedModel {
    /// Deferred executable body and its lexical captures; never a body value.
    Future {
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    Await {
        value: Box<Hir>,
    },
    /// Suspension-aware executable regions, before closure packaging.
    AsyncTry {
        body: Box<Hir>,
        handler: Option<Box<Hir>>,
        cleanup: Option<Box<Hir>>,
        payload: Option<Parameter>,
    },
    AsyncDynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Bitwise {
        operation: Bitwise,
        arguments: Vec<Hir>,
    },
    Comparison {
        operation: Comparison,
        arguments: Vec<Hir>,
    },
    /// Compiler bootstrap primitive, independent of mutable core vars.
    NilTest(Box<Hir>),
    Array {
        operation: ArrayOperation,
        arguments: Vec<Hir>,
    },
    DynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Assign {
        global: Global,
        value: Box<Hir>,
    },
    /// A terminal language throw of an evaluated portable value.
    Throw(Box<Hir>),
    /// Private compiled regions: body/cleanup arity0, handler arity1 or nil.
    Try {
        regions: [Box<Hir>; 3],
    },
    Nominal {
        operation: Nominal,
        arguments: Vec<Hir>,
    },
    Literal(Literal),
    Local(BindingId),
    /// Read a live cell by resolved language identity, never by a Wasm index.
    Global(Global),
    /// Reader calls use a live public value only after successful initialization.
    GlobalOrFallback {
        global: Global,
        fallback: Global,
    },
    /// Private cell identity for a captured live protocol fallback.
    GlobalCell(Global),
    Definition {
        global: Global,
        syntax: DefinitionSyntax,
        name_span: Range<usize>,
        initializer: Option<Box<Hir>>,
        once: bool,
    },
    Let {
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Loop {
        target: LoopId,
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Recur {
        target: LoopId,
        arguments: Vec<Hir>,
    },
    If {
        condition: Box<Hir>,
        consequent: Box<Hir>,
        alternative: Box<Hir>,
    },
    Do(Vec<Hir>),
    Function {
        parameters: Vec<Parameter>,
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    GeneralFunction {
        methods: Vec<Method>,
        captures: Vec<BindingId>,
        self_binding: Option<std::sync::Arc<Parameter>>,
        rest_class: Option<Global>,
    },
    Call {
        callee: Box<Hir>,
        arguments: Vec<Hir>,
    },
    /// Resolved bootstrap intrinsic identity, never an unresolved name.
    Arithmetic {
        operator: Arithmetic,
        arguments: Vec<Hir>,
    },
}
enum BoxAsyncParameterModel {
    /// Deferred executable body and its lexical captures; never a body value.
    Future {
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    Await {
        value: Box<Hir>,
    },
    /// Suspension-aware executable regions, before closure packaging.
    AsyncTry {
        body: Box<Hir>,
        handler: Option<Box<Hir>>,
        cleanup: Option<Box<Hir>>,
        payload: Option<Box<Parameter>>,
    },
    AsyncDynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Bitwise {
        operation: Bitwise,
        arguments: Vec<Hir>,
    },
    Comparison {
        operation: Comparison,
        arguments: Vec<Hir>,
    },
    /// Compiler bootstrap primitive, independent of mutable core vars.
    NilTest(Box<Hir>),
    Array {
        operation: ArrayOperation,
        arguments: Vec<Hir>,
    },
    DynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Assign {
        global: Global,
        value: Box<Hir>,
    },
    /// A terminal language throw of an evaluated portable value.
    Throw(Box<Hir>),
    /// Private compiled regions: body/cleanup arity0, handler arity1 or nil.
    Try {
        regions: [Box<Hir>; 3],
    },
    Nominal {
        operation: Nominal,
        arguments: Vec<Hir>,
    },
    Literal(Literal),
    Local(BindingId),
    /// Read a live cell by resolved language identity, never by a Wasm index.
    Global(Global),
    /// Reader calls use a live public value only after successful initialization.
    GlobalOrFallback {
        global: Global,
        fallback: Global,
    },
    /// Private cell identity for a captured live protocol fallback.
    GlobalCell(Global),
    Definition {
        global: Global,
        syntax: DefinitionSyntax,
        name_span: Range<usize>,
        initializer: Option<Box<Hir>>,
        once: bool,
    },
    Let {
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Loop {
        target: LoopId,
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Recur {
        target: LoopId,
        arguments: Vec<Hir>,
    },
    If {
        condition: Box<Hir>,
        consequent: Box<Hir>,
        alternative: Box<Hir>,
    },
    Do(Vec<Hir>),
    Function {
        parameters: Vec<Parameter>,
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    GeneralFunction {
        methods: Vec<Method>,
        captures: Vec<BindingId>,
        self_binding: Option<std::sync::Arc<Parameter>>,
        rest_class: Option<Global>,
    },
    Call {
        callee: Box<Hir>,
        arguments: Vec<Hir>,
    },
    /// Resolved bootstrap intrinsic identity, never an unresolved name.
    Arithmetic {
        operator: Arithmetic,
        arguments: Vec<Hir>,
    },
}
enum BoxAsyncTryModel {
    /// Deferred executable body and its lexical captures; never a body value.
    Future {
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    Await {
        value: Box<Hir>,
    },
    /// Suspension-aware executable regions, before closure packaging.
    AsyncTry(Box<AsyncTryPayload>),
    AsyncDynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Bitwise {
        operation: Bitwise,
        arguments: Vec<Hir>,
    },
    Comparison {
        operation: Comparison,
        arguments: Vec<Hir>,
    },
    /// Compiler bootstrap primitive, independent of mutable core vars.
    NilTest(Box<Hir>),
    Array {
        operation: ArrayOperation,
        arguments: Vec<Hir>,
    },
    DynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Assign {
        global: Global,
        value: Box<Hir>,
    },
    /// A terminal language throw of an evaluated portable value.
    Throw(Box<Hir>),
    /// Private compiled regions: body/cleanup arity0, handler arity1 or nil.
    Try {
        regions: [Box<Hir>; 3],
    },
    Nominal {
        operation: Nominal,
        arguments: Vec<Hir>,
    },
    Literal(Literal),
    Local(BindingId),
    /// Read a live cell by resolved language identity, never by a Wasm index.
    Global(Global),
    /// Reader calls use a live public value only after successful initialization.
    GlobalOrFallback {
        global: Global,
        fallback: Global,
    },
    /// Private cell identity for a captured live protocol fallback.
    GlobalCell(Global),
    Definition {
        global: Global,
        syntax: DefinitionSyntax,
        name_span: Range<usize>,
        initializer: Option<Box<Hir>>,
        once: bool,
    },
    Let {
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Loop {
        target: LoopId,
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Recur {
        target: LoopId,
        arguments: Vec<Hir>,
    },
    If {
        condition: Box<Hir>,
        consequent: Box<Hir>,
        alternative: Box<Hir>,
    },
    Do(Vec<Hir>),
    Function {
        parameters: Vec<Parameter>,
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    GeneralFunction {
        methods: Vec<Method>,
        captures: Vec<BindingId>,
        self_binding: Option<std::sync::Arc<Parameter>>,
        rest_class: Option<Global>,
    },
    Call {
        callee: Box<Hir>,
        arguments: Vec<Hir>,
    },
    /// Resolved bootstrap intrinsic identity, never an unresolved name.
    Arithmetic {
        operator: Arithmetic,
        arguments: Vec<Hir>,
    },
}
enum BoxAsyncParameterAndGeneralModel {
    /// Deferred executable body and its lexical captures; never a body value.
    Future {
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    Await {
        value: Box<Hir>,
    },
    /// Suspension-aware executable regions, before closure packaging.
    AsyncTry {
        body: Box<Hir>,
        handler: Option<Box<Hir>>,
        cleanup: Option<Box<Hir>>,
        payload: Option<Box<Parameter>>,
    },
    AsyncDynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Bitwise {
        operation: Bitwise,
        arguments: Vec<Hir>,
    },
    Comparison {
        operation: Comparison,
        arguments: Vec<Hir>,
    },
    /// Compiler bootstrap primitive, independent of mutable core vars.
    NilTest(Box<Hir>),
    Array {
        operation: ArrayOperation,
        arguments: Vec<Hir>,
    },
    DynamicScope {
        bindings: Vec<(Global, Hir)>,
        body: Box<Hir>,
    },
    Assign {
        global: Global,
        value: Box<Hir>,
    },
    /// A terminal language throw of an evaluated portable value.
    Throw(Box<Hir>),
    /// Private compiled regions: body/cleanup arity0, handler arity1 or nil.
    Try {
        regions: [Box<Hir>; 3],
    },
    Nominal {
        operation: Nominal,
        arguments: Vec<Hir>,
    },
    Literal(Literal),
    Local(BindingId),
    /// Read a live cell by resolved language identity, never by a Wasm index.
    Global(Global),
    /// Reader calls use a live public value only after successful initialization.
    GlobalOrFallback {
        global: Global,
        fallback: Global,
    },
    /// Private cell identity for a captured live protocol fallback.
    GlobalCell(Global),
    Definition {
        global: Global,
        syntax: DefinitionSyntax,
        name_span: Range<usize>,
        initializer: Option<Box<Hir>>,
        once: bool,
    },
    Let {
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Loop {
        target: LoopId,
        bindings: Vec<Binding>,
        body: Box<Hir>,
    },
    Recur {
        target: LoopId,
        arguments: Vec<Hir>,
    },
    If {
        condition: Box<Hir>,
        consequent: Box<Hir>,
        alternative: Box<Hir>,
    },
    Do(Vec<Hir>),
    Function {
        parameters: Vec<Parameter>,
        captures: Vec<BindingId>,
        body: Box<Hir>,
    },
    GeneralFunction(Box<GeneralFunctionPayload>),
    Call {
        callee: Box<Hir>,
        arguments: Vec<Hir>,
    },
    /// Resolved bootstrap intrinsic identity, never an unresolved name.
    Arithmetic {
        operator: Arithmetic,
        arguments: Vec<Hir>,
    },
}
struct HirUnchangedModel { source: Option<Arc<SourceAnalysis>>, span: Range<usize>, metadata: Vec<suss_reader::forms::Form>, ty: Type, kind: UnchangedModel }
struct HirBoxAsyncParameterModel { source: Option<Arc<SourceAnalysis>>, span: Range<usize>, metadata: Vec<suss_reader::forms::Form>, ty: Type, kind: BoxAsyncParameterModel }
struct HirBoxAsyncTryModel { source: Option<Arc<SourceAnalysis>>, span: Range<usize>, metadata: Vec<suss_reader::forms::Form>, ty: Type, kind: BoxAsyncTryModel }
struct HirBoxAsyncParameterAndGeneralModel { source: Option<Arc<SourceAnalysis>>, span: Range<usize>, metadata: Vec<suss_reader::forms::Form>, ty: Type, kind: BoxAsyncParameterAndGeneralModel }
fn main() {
println!("Expression size={} align={}",size_of::<Expression>(),align_of::<Expression>());
println!("Hir size={} align={}",size_of::<Hir>(),align_of::<Hir>());
println!("Parameter size={} align={}",size_of::<Parameter>(),align_of::<Parameter>());
println!("GeneralFunctionPayload size={} align={}",size_of::<GeneralFunctionPayload>(),align_of::<GeneralFunctionPayload>());
println!("AsyncTryPayload size={} align={}",size_of::<AsyncTryPayload>(),align_of::<AsyncTryPayload>());
println!("UnchangedModel size={} align={}",size_of::<UnchangedModel>(),align_of::<UnchangedModel>());
println!("BoxAsyncParameterModel size={} align={}",size_of::<BoxAsyncParameterModel>(),align_of::<BoxAsyncParameterModel>());
println!("BoxAsyncTryModel size={} align={}",size_of::<BoxAsyncTryModel>(),align_of::<BoxAsyncTryModel>());
println!("BoxAsyncParameterAndGeneralModel size={} align={}",size_of::<BoxAsyncParameterAndGeneralModel>(),align_of::<BoxAsyncParameterAndGeneralModel>());
println!("HirUnchangedModel size={} align={}",size_of::<HirUnchangedModel>(),align_of::<HirUnchangedModel>());
println!("HirBoxAsyncParameterModel size={} align={}",size_of::<HirBoxAsyncParameterModel>(),align_of::<HirBoxAsyncParameterModel>());
println!("HirBoxAsyncTryModel size={} align={}",size_of::<HirBoxAsyncTryModel>(),align_of::<HirBoxAsyncTryModel>());
println!("HirBoxAsyncParameterAndGeneralModel size={} align={}",size_of::<HirBoxAsyncParameterAndGeneralModel>(),align_of::<HirBoxAsyncParameterAndGeneralModel>());
assert_eq!(size_of::<UnchangedModel>(),size_of::<Expression>(),"model no longer matches actual enum");
assert_eq!(size_of::<HirUnchangedModel>(),size_of::<Hir>(),"model no longer matches actual Hir");
}
