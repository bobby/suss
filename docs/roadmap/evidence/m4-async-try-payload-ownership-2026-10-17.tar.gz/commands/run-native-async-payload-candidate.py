from pathlib import Path
import subprocess,os,time,json,hashlib,shutil,re
cache=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots')
run=cache/'native-async-payload-candidate'
run.mkdir(exist_ok=False)
# Expand earlier diagnostic cohorts to the declared compiler/runtime/oracle closure.
tracked=subprocess.check_output(['git','ls-files','--recurse-submodules'],cwd=root,text=True).splitlines()
paths={p for p in tracked if (root/p).is_file() and (p.startswith(('crates/','runtime/','scripts/','tests/','vendor/','docs/compatibility/','.cargo/','.github/workflows/')) or p in ['Cargo.toml','Cargo.lock','clojurescript/deps.edn','clojurescript/project.clj'])}
paths.update(p for p in json.loads((cache/'when-let-reconcile-after/after-freeze.json').read_text()) if (root/p).is_file())
paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snapshot(label,hashes):
 (run/(label+'-freeze.json')).write_text(json.dumps(hashes,indent=2)+'\n')
 for rel in hashes:
  target=run/label/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,target)
paths.update(['scripts/clojure_test_suite.py','scripts/cljs_inventory.py','tests/oracle/clojure-test-suite-observations.json','vendor/clojure-test-suite/upstream/test/clojure/core_test/map.cljc','clojurescript/src/main/cljs/cljs/core.cljs','clojurescript/src/main/clojure/cljs/core.cljc'])
paths.add('crates/suss-compile/tests/fixtures/bootstrap-selection-c10c037.tsv')
paths.update(['tests/oracle/function-parameter-cases.json','tests/oracle/bitwise-hash-cases.json','tests/oracle/core-import-cases.json'])
expected=freeze();snapshot('before',expected);shutil.copyfile(cache/'native-async-payload-command-plan.json',run/'command-plan.json')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(cache/'memo-proof-cost-target'))
for flag in ['SUSS_HIR_COW_TRACE','SUSS_SOURCE_CERT_TRACE','SUSS_SOURCE_CHILD_FUEL_TRACE','SUSS_SOURCE_MATERIALIZE_FUEL_TRACE']:env.pop(flag,None)
env['SUSS_CLOJURE_TEST_SUITE_CAPTURE']=str(run/'map-capture')
state={'current':None,'stages':[],'input_count':len(expected),'limits':'AsyncTry owns immutable Parameter facts; AST jobs retain exact source owners, lowering and exception copies metered. Other analyzer clone gaps remain explicit; defaults unchanged. Completefrozeninputsandrawfailures retained; custom30Mcompilerprobe diagnostics only, noStoreexecution.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
commands=[(item['name'],item['command']) for item in json.loads((cache/'native-async-payload-command-plan.json').read_text())]

allowed={f'runtime/bootstrap/{phase}.{ext}' for phase in ['macro','runtime'] for ext in ['wasm','json']}
for name,cmd in commands:
 assert freeze()==expected,'Source changed before '+name
 if name in ['core-import','diagnostic-core-cost']:env['SUSS_HIR_COW_TRACE']='1'
 else:env.pop('SUSS_HIR_COW_TRACE',None)
 if name=='source-child':env['SUSS_SOURCE_CHILD_FUEL_TRACE']='1';env['SUSS_SOURCE_MATERIALIZE_FUEL_TRACE']='1'
 else:env.pop('SUSS_SOURCE_CHILD_FUEL_TRACE',None);env.pop('SUSS_SOURCE_MATERIALIZE_FUEL_TRACE',None)
 state['current']=name;entry={'name':name,'command':cmd};state['stages'].append(entry);save();print('starting '+name,flush=True);start=time.monotonic()
 with (run/(name+'.log')).open('w') as f:result=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 after=freeze();changed=[p for p in expected if expected[p]!=after[p]]
 entry.update(exit=result.returncode,seconds=time.monotonic()-start,changed=changed)
 entry['summaries']=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', (run/(name+'.log')).read_text())
 if name=='bootstrap' and result.returncode==0 and set(changed)<=allowed:expected=after;snapshot('after-bootstrap',expected)
 elif changed:entry['unexpected_input_changes']=True;save();break
 save();print(json.dumps(entry),flush=True)
 if result.returncode and name in ['compile','bootstrap']:break
state['current']=None;final=freeze();state['final_changed']=[p for p,h in expected.items() if final[p]!=h];save();print(json.dumps(state),flush=True)
