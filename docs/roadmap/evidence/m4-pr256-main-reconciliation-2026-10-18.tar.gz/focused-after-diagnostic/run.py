from pathlib import Path
import subprocess as s,os,json,hashlib,time
p=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss');env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
files=s.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
def hashes():return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if (root/f).is_file()}
freeze=hashes();(p/'manifest.json').write_text(json.dumps(freeze,indent=2)+'\n');cargo=['cargo','test','--locked'];tail=['--','--test-threads=1','--nocapture']
stages=[('identity',['python3','scripts/verify_bootstrap_identity.py'],{},True),('when-let-provenance',['python3','scripts/check_when_let_provenance.py'],{},True),('compiled-when-let',cargo+['-p','suss-cli','--test','compiled_when_let']+tail,{},True),('pinned-when-let',cargo+['-p','suss-compile','--test','clojure_test_suite','pinned_when_let_complete_body_matches_reference','--','--exact','--test-threads=1','--nocapture'],{'SUSS_WHEN_LET_CAPTURE':str(p/'when-let-capture')},True),('source-tags',cargo+['-p','suss-cli','--test','compiled_macro_source_tags']+tail,{},False)]
r={'base':s.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'terminal':False,'stages':[]}
def save():(p/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
for name,cmd,extra,stop in stages:
 assert hashes()==freeze;r['current']=name;save();e=env.copy();e.update(extra);start=time.monotonic()
 with (p/(name+'.log')).open('w') as log:
  child=s.Popen(cmd,cwd=root,env=e,stdout=log,stderr=s.STDOUT);r['pid']=child.pid;save();code=child.wait()
 changed=[f for f,h in freeze.items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h];r['stages'].append({'name':name,'argv':cmd,'environment_overrides':extra,'exit':code,'seconds':time.monotonic()-start,'changed':changed});save();print(name,code,flush=True);assert not changed
 if code and stop:break
r.update(terminal=True,current=None,unexecuted=[n for n,_,_,_ in stages if n not in [x['name'] for x in r['stages']]]);save()
