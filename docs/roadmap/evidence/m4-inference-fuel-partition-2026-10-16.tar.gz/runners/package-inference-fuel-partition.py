from pathlib import Path
import json,hashlib,subprocess,tarfile,io
r=Path('/home/bobby/Work/code/bobby/suss-m4-inference-fuel-partition');c=Path('/home/bobby/.cache/suss-m4-work');o=c/'inference-fuel-partition';s=json.loads((o/'result.json').read_text());a=json.loads((o/'analysis.json').read_text());assert s['current'] is None and s['source_unchanged'];assert a['decoded_remaining']==a['expected_decoded'] and a['starts'][-1]==20210 and a['all_interval_equations_match'] and not a['unknown_store_events']
payload={}
for f,h in s['freeze'].items():
 b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+f]=b
extras=['Cargo.toml','Cargo.lock','crates/suss-core/Cargo.toml','crates/suss-reader/Cargo.toml','crates/suss-compile/Cargo.toml','crates/suss-cli/Cargo.toml','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','runtime/core-import/LICENSE','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json','vendor/wasi/wasi-wit-0.3.1/cli/cli.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit']
for f in extras:payload['snapshot/'+f]=(r/f).read_bytes()
paths=[f for f in s['freeze'] if f=='crates/suss-compile/build.rs' or any(f.startswith('crates/'+n+'/src/') and f.endswith(('.rs','.sus')) for n in ['suss-core','suss-reader','suss-compile'])]+extras[:5]+extras[9:];h=hashlib.sha256()
for f in sorted(set(paths),key=lambda p:tuple(p.split('/'))):
 b=payload['snapshot/'+f];n=f.encode();h.update(len(n).to_bytes(8,'little')+n+len(b).to_bytes(8,'little')+b)
checks={}
for phase in ['macro','runtime']:
 m=json.loads(payload[f'snapshot/runtime/bootstrap/{phase}.json']);checks[phase]={'compiler':h.hexdigest()==m['compiler_source_sha256'],'core':hashlib.sha256(payload['snapshot/runtime/core-import/suss/core.sus']).hexdigest()==m['source_sha256'],'dependencies':hashlib.sha256(payload['snapshot/runtime/core-import/manifest.json']).hexdigest()==m['dependency_graph_sha256'],'wasm':hashlib.sha256(payload[f'snapshot/runtime/bootstrap/{phase}.wasm']).hexdigest()==m['wasm_sha256']}
assert all(all(x.values()) for x in checks.values());(o/'fingerprints.json').write_text(json.dumps(checks,indent=2)+'\n')
comp=json.loads((o/'operational-comparison.json').read_text())
for phase in ['macro','runtime']:assert hashlib.sha256((o/f'candidate-{phase}.wasm').read_bytes()).hexdigest()==comp[phase]['candidate_sha256'] and comp[phase]['stripped_equal']
for p in o.iterdir():
 if p.is_file():payload['raw/'+p.name]=p.read_bytes()
for f in ['run-inference-fuel-partition.py','analyze-inference-fuel-partition.py','package-inference-fuel-partition.py']:payload['runners/'+f]=(c/f).read_bytes()
payload['change.patch']=subprocess.check_output(['git','diff','8fda18a','--','crates'],cwd=r)
m={n:hashlib.sha256(b).hexdigest() for n,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(m,indent=2).encode();out=r/'docs/roadmap/evidence/m4-inference-fuel-partition-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,b in sorted(payload.items()):
  info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
result={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(m),'freeze_count':len(s['freeze']),'fingerprints':checks};(c/'inference-fuel-partition-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
