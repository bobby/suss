from pathlib import Path
import os,json,hashlib,subprocess,time
r=Path('/home/bobby/Work/code/bobby/suss-m4-inference-fuel-partition');c=Path('/home/bobby/.cache/suss-m4-work');o=c/'inference-fuel-partition';o.mkdir(exist_ok=True)
assert hashlib.sha256((r/'crates/suss-compile/src/portable/emit.rs').read_bytes()).hexdigest()=='f4af4079fb2716d1d6de7173fc96076622b069eeb720539f071ff8c7fbfb5b9c'
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(c/'inference-fuel-partition-target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2');s={'base':'8fda18a','emitter_sha256':'f4af4079fb2716d1d6de7173fc96076622b069eeb720539f071ff8c7fbfb5b9c','stages':[]};out=o/'result.json'
def save():out.write_text(json.dumps(s,indent=2)+'\n')
def run(name,cmd):
 s['current']=name;save();start=time.time()
 with (o/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 s['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start});s['current']=None;save();return p.returncode
if run('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']):raise SystemExit(1)
files=sorted([p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']]+[p for p in (r/'runtime/bootstrap').glob('*') if p.is_file()]);s['freeze']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};save();env.update(SUSS_FUEL_PARTITION='1',SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1')
run('inference',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_source_tags','compiled_source_inference_matches_pinned_tags_without_changing_executed_storage_or_effects','--','--exact','--nocapture','--test-threads=1'])
s['source_unchanged']=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in s['freeze'].items());save();print(json.dumps({k:v for k,v in s.items() if k!='freeze'},indent=2))
