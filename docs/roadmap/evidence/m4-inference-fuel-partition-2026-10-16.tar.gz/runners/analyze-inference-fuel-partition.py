from pathlib import Path
import json,re
p=Path('/home/bobby/.cache/suss-m4-work/inference-fuel-partition');raw=(p/'inference.log').read_text();rows=[json.loads(x.split('fuel-ledger-stage ',1)[1]) for x in raw.splitlines() if 'fuel-ledger-stage ' in x];all_intervals=[];last={};env=[];invocation=0
for row in rows:
 id=row['session'];prev=last.get(id);last[id]=row
 if row['stage']=='start':invocation+=1
 if prev is None:continue
 d={k:int(v) for k,v in row['since_previous_stage'].items()};delta=prev['fuel']-row['fuel'];H=sum(v for k,v in d.items() if k.startswith('successful_host_units:'));F=sum(v for k,v in d.items() if k.startswith('failed_host_actual_debit:'));V=sum(v for k,v in d.items() if k.startswith('vm_debit:'));A=sum(v for k,v in d.items() if k.startswith('administrative_debit:'))-sum(v for k,v in d.items() if k.startswith('administrative_credit:'));U=sum(v for k,v in d.items() if k.startswith('unknown') or k=='set_errors');valid=delta==H+F+V+A and U==0
 x={'invocation':invocation,'session':id,'from':prev['stage'],'to':row['stage'],'fuel_before':prev['fuel'],'fuel_after':row['fuel'],'total_debit':delta,'successful_host_units':H,'failed_host_actual_debit':F,'vm_debit_finite':d.get('vm_debit:finite',0),'vm_debit_unlimited':sum(v for k,v in d.items() if k.startswith('vm_debit:') and k!='vm_debit:finite'),'administrative_net_debit':A,'accounting_equation_matches':valid,'unknown':U,'counters':d}
 all_intervals.append(x)
 if prev['stage']=='caller-form' and row['stage'] in ['caller-environment','expansion-exit']:env.append(x)
result={'expected_decoded':[6548798,3283219,20631],'decoded_remaining':[int(x) for x in re.findall(r'macro-fuel user/observe-tags decoded: (\d+)',raw)],'starts':[int(x) for x in re.findall(r'macro-fuel user/observe-tags start: (\d+)',raw)],'all_interval_equations_match':all(x['accounting_equation_matches'] for x in all_intervals),'unknown_store_events':raw.count('fuel-ledger-unknown-store'),'environments':env,'all_intervals':all_intervals,'failure_lines':[x for x in raw.splitlines() if 'caller &env input transport' in x or 'test result:' in x]};(p/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:([{a:b for a,b in x.items() if a!='counters'} for x in v] if k=='environments' else v) for k,v in result.items() if k!='all_intervals'},indent=2))
