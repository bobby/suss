(ns suss-oracle.structural-dispatch
 (:require [cljs.analyzer :as ana] [cljs.env :as env] [cljs.js :as cljs]
           [cljs.tools.reader :as reader]))
(def rows (array))
(def dispatches (array))
(def stage (array "controls"))
(defn observed [kind original]
 (fn [coll]
  (this-as receiver
   (let [memo (.-_hash receiver) n (.-name receiver)]
    (when (or (= n "op") (= n "locals") (= n "env") (= n "tag") (= n "name") (= n "context") (= n "local-x"))
     ;; A nil-aware custom method records the branch before delegating exactly.
     (.push dispatches #js {:stage (aget stage 0) :kind kind :name n
                           :before memo :nil-branch (nil? memo)}))
    (.call original receiver coll)))))
(defn leaf [label value]
 ;; Snapshot before name, printing, explicit hash, or use as a map key.
 (let [memo (.-_hash value)]
  (.push rows #js {:label label :kind (if (keyword? value) "keyword" "symbol")
                  :initial-memo memo :initial-nil (nil? memo)
                  :initial-number (number? memo) :text (str value)})))
(defn keys-of [label m]
 (doseq [entry m]
  (let [k (key entry)]
   (when (or (keyword? k) (symbol? k)) (leaf label k)))))
(defn -main []
 (when (nil? cljs.core/NS_CACHE) (set! cljs.core/NS_CACHE (atom {})))
 (let [kp (.-prototype cljs.core/Keyword) sp (.-prototype cljs.core/Symbol)
       method "cljs$core$IHash$_hash$arity$1" kh (aget kp method) sh (aget sp method)
       state (cljs/empty-state) cache cljs.core/NS_CACHE old-cache @cache
       target 'suss-oracle.structural-target lib 'suss-oracle.structural-macros
       macro-ns (symbol (str lib "$macros"))
       analyze (fn [form]
        (binding [env/*compiler* state ana/*cljs-ns* target
                  ana/*analyze-deps* false ana/*load-macros* false]
         (ana/analyze (assoc (ana/empty-env) :ns (ana/get-namespace target)) form)))
       seen (array 0)
       observer (fn [form macro-env source-kw source-sym]
        (aset stage 0 "inside-observer")
        (aset seen 0 (inc (aget seen 0)))
        (keys-of "macro-env-key" macro-env)
        (keys-of "namespace-key" (:ns macro-env))
        (doseq [entry (:locals macro-env)]
         (leaf "locals-name" (key entry))
         (keys-of "local-descriptor-key" (val entry)))
        (let [info (ana/resolve-var macro-env 'watched)
              ast (ana/analyze macro-env 'watched)]
         (keys-of "resolved-info-key" info)
         (keys-of "var-ast-key" ast)
         (keys-of "source-metadata-key" (:meta info))
         (leaf "source-metadata-value" (:audit (:meta info))))
        (leaf "macro-source-arg-keyword" (second form))
        (leaf "macro-source-arg-symbol" (nth form 2))
        17)]
  (try
   (aset kp method (observed "keyword" kh))
   (aset sp method (observed "symbol" sh))
   ;; These compiled constants are controls, not reader-produced leaves.
   (leaf "compiled-keyword-control" :op)
   (leaf "compiled-symbol-control" 'op)
   (leaf "fresh-reader-keyword-control" (reader/read-string ":op"))
   (leaf "fresh-reader-symbol-control" (reader/read-string "op"))
   (let [q (reader/read-string "'(:op op)") body (second q)]
    (leaf "reader-quoted-keyword-control" (first body))
    (leaf "reader-quoted-symbol-control" (second body)))
   (aset stage 0 "registration")
   (swap! state assoc-in [::ana/namespaces target] {:name target :defs {}})
   (swap! state assoc-in [::ana/namespaces macro-ns]
    {:name macro-ns :defs {'observe {:name (symbol (str macro-ns) "observe")
      :macro true :method-params [['&form '&env 'source-kw 'source-sym]] :max-fixed-arity 4}}})
   (set! (.-cljs$lang$macro observer) true)
   (swap! cache assoc macro-ns (create-ns macro-ns #js {:observe observer}))
   (aset stage 0 "analyze-declaration")
   (analyze (reader/read-string "(def ^{:audit :reader-only-leaf} watched 17)"))
   (aset stage 0 "analyze-macro-caller")
   (let [ast (analyze (reader/read-string "(let [^number local-x 17] (suss-oracle.structural-macros/observe :op op))"))]
    (assert (= 1 (aget seen 0)))
    (assert (= :let (:op ast)))
    (js/console.log (.stringify js/JSON #js {:pin "c4295f303100bbf5afac449242d30bca1126f1a1" :macro-calls (aget seen 0) :rows rows :dispatches dispatches})))
   (finally (aset kp method kh) (aset sp method sh) (reset! cache old-cache)))))
(set! *main-cli-fn* -main)
