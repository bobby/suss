import hashlib, json
from pathlib import Path

class Reader:
    def __init__(self, data): self.data, self.pos = data, 0
    def byte(self):
        result = self.data[self.pos]
        self.pos += 1
        return result
    def leb(self):
        result = shift = 0
        while True:
            value = self.byte()
            result |= (value & 127) << shift
            if value < 128: return result
            shift += 7
            assert shift <= 70
    def take(self, length):
        end = self.pos + length
        result = self.data[self.pos:end]
        assert len(result) == length
        self.pos = end
        return result
    def name(self): return self.take(self.leb()).decode('utf-8')
    def value_type(self):
        first = self.byte()
        if first in (0x63, 0x64): self.leb()
    def limits(self):
        flags = self.leb()
        self.leb()
        if flags & 1: self.leb()
        assert flags & ~7 == 0, flags

root = Path('/home/bobby/Work/code/bobby/suss/runtime/bootstrap')
observations = []
for phase in ['runtime', 'macro']:
    data = (root / (phase + '.wasm')).read_bytes()
    r = Reader(data)
    assert r.take(8) == b'\x00asm\x01\x00\x00\x00'
    imports = []
    while r.pos < len(data):
        section = r.byte()
        body = Reader(r.take(r.leb()))
        if section != 2: continue
        for _ in range(body.leb()):
            module, name, kind = body.name(), body.name(), body.byte()
            imports.append({'module': module, 'name': name, 'kind': kind})
            if kind == 0: body.leb()
            elif kind == 1: body.value_type(); body.limits()
            elif kind == 2: body.limits()
            elif kind == 3: body.value_type(); body.byte()
            elif kind == 4: body.byte(); body.leb()
            else: raise AssertionError(kind)
        assert body.pos == len(body.data)
    private = [i for i in imports if i['module'] == 'suss.compiler-integrity']
    expected = [] if phase == 'runtime' else [{'module': 'suss.compiler-integrity', 'name': 'memo-field-set', 'kind': 0}]
    assert private == expected, (phase, private)
    observations.append({'phase': phase, 'sha256': hashlib.sha256(data).hexdigest(), 'private-imports': private, 'total-imports': len(imports)})
print(json.dumps({'boundary': 'import inspection only; not Wasm validation or execution', 'artifacts': observations}, indent=2))
