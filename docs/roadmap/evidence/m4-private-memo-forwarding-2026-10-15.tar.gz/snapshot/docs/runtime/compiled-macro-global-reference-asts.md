# Resolved global source AST facts

Initializer records for genuine resolved global symbols expose `:op :var`,
qualified `:name`, canonical `:ns`, and `:info` copied from the captured
`SourceBinding::Global` declaration revision. Resolved operation/name/namespace
override raw declaration metadata in this copy. Each resolution has a fresh outer
`:info` map and shares the captured declaration revision's final nested `:meta`
value, including function `:top-fn` metadata overlays. This preserves the pinned
shallow merge identity without changing reader occurrence construction elsewhere.
Across calls, the same captured declaration revision must retain its pinned nested
metadata identity; equal data from distinct revisions remain distinct. Outer
resolved `:info` maps remain fresh. Source-owner identity alone cannot justify
reusing guest storage: reachable backing arrays can be mutated. Any sharing
mechanism must also preserve the original source facts, live construction
callbacks, cycle/layout checks and cumulative materialization budget. Rebuilding
fresh metadata alone is insufficient because it loses cross-call identity.
The namespace catalog retains
its original record, including raw metadata overrides. Global AST tag presence
and value come from resolved info, including false; lexical inference is unchanged.
Runtime values, physical HIR and source reexecution do not determine these facts.

Eleven fresh pinned observations and all eleven executed Node projections cover
scalar/qualified/hinted/dynamic/function/declared references, raw metadata overrides,
core aliases and old/new declaration revisions. The native parent regression
reproduced absent var identity/info fields. The initial new native helper also
exposed unavailable public `symbol`/`mapv` functions; the bounded projection now
receives the unqualified declaration key as a raw macro argument and explicitly
selects the same fields in both implementations. Fresh force/cache-disabled
analysis and actual Node execution revalidate every unchanged expected observation.
This establishes the projection, not support for those unimplemented core APIs.

The repaired graph initially failed the core case because the identity adaptation
patch omitted its upstream docstring. The patch now retains the original body and
docstring in the actual compiled declaration. Source extraction/hash, patch hash,
review overlay and generated manifest retain provenance and the EPL notice/license.
Both Runtime and Macro bootstrap image pairs were regenerated; Java-free
reproduction and all four executing bootstrap tests pass before native acceptance.

All 58 affected native tests pass across nine groups (graph11/bindings8/scalars3/
globals1/locals2/env3/tags2/syntaxquote11/core-import17). The eleven global cases run
in Runtime and Macro caller Stores after GC, with only the exact two core resolved
name/ns spellings adapted to the design's canonical `suss.core`. Old declaration
metadata remains captured after redefinition, while the live value changes; the
initializer effect occurs once. The extended focused test also passes: a global
callee invocation does not inherit its callee's var identity or a fabricated
constant value, and its effect occurs once. All123Python checks pass, including
five observation-corruption checks that distinguish numeric1 from true metadata.

The source contract follows pinned ClojureScript
`c4295f303100bbf5afac449242d30bca1126f1a1`, `analyzer.cljc`'s
`analyze-symbol`4149–4165, `resolve-var` and default `resolve*`1248.
Analyzer SHA-256:
`297802c627474434f1ef868e31f5f9913c290a4e80c509a40c704dced95bbf47`.
Identity source SHA-256:
`4997a405f43df040b92909ac831f031385fd1ac86948cb1be06dd3529323504e`.
[Identity adaptation](../compatibility/patches/identity.json),
[generated manifest](../../runtime/core-import/manifest.json), and
[EPL license](../../runtime/core-import/epl-v10.html) remain distributed.
Native graph transport and observation helpers are original code; JVM/Node remain
development oracles with no shipped dependency.

Fresh forced/cache-disabled primary analysis and actual Node execution also
establish four cross-call metadata identities `[true true false false]`, with
before/before/after/after documents and live value17. The earlier native execution preserved
all four observations in both caller phases after GC, keeps the old metadata
accessible after redefinition, confirms outer info is fresh across calls, and
rechecks unchanged-revision sharing after reset. A Macro Store graph regression
forces GC, rejects warmed node/UTF-16/work budgets, distinguishes equal metadata
from different revision identities, prunes dead source owners and recovers.

Field/quote/compound/invocation/children ASTs, constant-expression policy, complete
source declaration/function/method/inference schema and evaluator retirement remain
unfinished. Dependency/target integration and rooted pending-I/O cancellation plus
code/live-heap accounting remain original M3 gates. Independent review, significant
fixes, the unfiltered full workspace baseline and exact final-head CI are required
for this increment. No issue closure, merge or milestone completion.

The cumulative-fuel prototype currently disables cross-call declaration-root
reuse to reject nested guest-storage poisoning. The pinned identity observations
above remain the required contract; the prototype still fails warmed metadata
identity. Within-build sharing and poison rejection do not substitute for that
contract.

After authorized shipped-bootstrap provisioning, a private native registry now
captures the actual canonical IHash descriptors, key and method closures. It
checks live installation identity and exact key, schema and closure storage with
metered, cancellation-aware native observations. It does not refresh from mutable
globals; unrelated protocol dispatch and live hash-helper bindings remain live.
Internal roots have separate accounting from externally held Session values.
Failed staging publishes no registry, and reset creates new identities.

These are physical installation observations, not source-data certification.
Legitimate UID/property changes can currently make an installation ineligible.
No memo receipt, source-backed retained candidate or cross-call reuse is enabled
by this registry; those checks must precede restoring the required identities.

Installation inspection also accepts an active Wasmtime caller context, debiting
its existing fuel without starting another operation or replenishing fuel.
Callback registration must bind the Store, runtime instance, roots, identity and
interrupt flag from the same Session; the supplied numeric identity alone does
not prove that relationship. A Store-bound native callback and executed Wasm
driver exercise repeated calls, exhaustion, interruption and recovery. The new
memo forwarding bridge also executes a Wasm-to-native-to-runtime exception
boundary, comparing actual error descriptors and UTF-16 payload messages after
GC against an ordinary-setter control. Guest catch handlers and nontrivial
dynamic bindings remain unexecuted for that bridge.

Bootstrap generation builds a private plan borrowing the exact verified IR
functions and memo-store instructions. Macro emission consumes its recorder,
rejecting cloned or wrong-parent instructions, duplicate selection, missing
coverage and errors followed by otherwise complete selection. The25 protected
store calls preserve receiver/result locals and carry their source-order site
IDs to a native bridge, which charges the active allowance and forwards to the
ordinary runtime setter. Runtime emission retains ordinary setters for portable
AOT providers. Ordinary compilation has no private mode, and Session admission
reserves the integrity import namespace. This forwarding path issues no receipts
and certifies no receiver/source data; cross-call reuse remains disabled.

The development-only [CLJS-hosted analyzer probe](../../tests/oracle/src/suss_oracle/declaration_metadata_retention.cljs)
separates fresh reader construction from analysis of pre-read declarations,
repeated resolved-var analysis and explicit set/map construction controls. Its
[recorded observations](../../tests/oracle/declaration-metadata-retention-observations.json)
come from the clean pinned compiler executing in Node, with structural guards
on the actual initializer/info/metadata path. The old declaration metadata and
nested audit set retain identity across resolutions; outer info maps differ and
a new declaration revision supplies distinct metadata. The selected numeric
hash trace is empty during repeated resolution; fresh nine-element reader sets
and explicit set/map controls each record101 through109 once in order. Total
public hash counts are also retained, including unrelated analyzer work.

Run `scripts/probe-declaration-metadata-retention.sh` to observe the pin afresh.
This probe executes the analyzer as ClojureScript, avoiding substitution of JVM
hashing behavior. It does not execute Suss's additional native-to-guest transport
and therefore does not establish a transport callback-count policy or authorize
removing independently established reader-occurrence effects. Its total internal
hash counts are raw evidence, not Suss acceptance targets. Retained candidates
still require independent source expectations, authentic memo validation and
revalidation after any callbacks that can mutate their reachable storage.
