from pathlib import Path
import os,subprocess,json,time,hashlib,tarfile,sys
root=Path('/home/bobby/Work/code/bobby/suss-m4-analyzer-literal-env-effects')
cache=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(cache/'analyzer-literal-env-effects-target'))
prefix='analyzer-literal-env-effects'
paths=sorted([p for p in (root/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']])
def hashes(paths):return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
state={'base':'be6a219','current':None,'stages':[],'source_freeze':hashes(paths),'environment':{k:env[k] for k in ['CARGO_BUILD_JOBS','RAYON_NUM_THREADS','CARGO_TARGET_DIR']}}
receipt=cache/(prefix+'-result.json')
def save():receipt.write_text(json.dumps(state,indent=2)+'\n')
for name,cmd in [('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('actual-env',['cargo','test','-p','suss-compile','--lib','--locked','analyzer_literal_actual_env_pre_dispatch_memo_effects_survive_gc_and_restoration','--','--test-threads=2','--nocapture'])]:
 if name=='actual-env':
  state['freeze']=hashes(paths+sorted((root/'runtime/bootstrap').glob('*')))
  with tarfile.open(cache/(prefix+'-tested-source.tar.gz'),'w:gz') as t:
   for n in state['freeze']:t.add(root/n,arcname=n)
 state['current']=name;save();start=time.time()
 with (cache/(prefix+'-'+name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 state['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start})
 state['source_unchanged']=hashes(paths)==state['source_freeze']
 if name=='actual-env':state['frozen_source_bootstrap_unchanged']=hashes(paths+sorted((root/'runtime/bootstrap').glob('*')))==state['freeze']
 state['current']=None;save()
 if p.returncode:sys.exit(p.returncode)
