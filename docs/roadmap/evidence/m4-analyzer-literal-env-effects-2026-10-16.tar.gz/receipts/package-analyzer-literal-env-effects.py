from pathlib import Path
import tarfile,json,hashlib,subprocess,io
r=Path('/home/bobby/Work/code/bobby/suss-m4-analyzer-literal-env-effects');c=Path('/home/bobby/.cache/suss-m4-work');prefix='analyzer-literal-env-effects'
j=json.loads((c/(prefix+'-result.json')).read_text());assert j['current'] is None and j['source_unchanged'] and j['frozen_source_bootstrap_unchanged'];assert all(s['exit']==0 for s in j['stages'])
d={}
for n in ['run-'+prefix+'.py','package-'+prefix+'.py',prefix+'-result.json',prefix+'-bootstrap.log',prefix+'-actual-env.log']:
 d['receipts/'+n]=(c/n).read_bytes()
d['receipts/original-unexecuted-draft.rs']=(c/'analyzer-literal-macro-effect-draft.rs').read_bytes()
for n,h in j['freeze'].items():
 b=(r/n).read_bytes();assert hashlib.sha256(b).hexdigest()==h;d['snapshot/'+n]=b
for phase in ['macro','runtime']:
 m=json.loads(d[f'snapshot/runtime/bootstrap/{phase}.json']);assert hashlib.sha256(d[f'snapshot/runtime/bootstrap/{phase}.wasm']).hexdigest()==m['wasm_sha256']
d['tracked.patch']=subprocess.check_output(['git','diff','be6a219','--','crates','runtime/bootstrap'],cwd=r)
d['limits.txt']=b'One actual macro-&env custom delegated Keyword IHash effect regression in both caller phases. No production behavior changes. Bootstrap fingerprints change with test source. No full baseline, final CI, issue closure, push or PR. Source/bootstrap freeze covers Rust/Suss/bootstrap paths; not all compiler/toolchain inputs. No failed stage occurred in this producer. Original supplied draft was not executed.\n'
hs={n:hashlib.sha256(b).hexdigest() for n,b in d.items()};d['manifest.json']=(json.dumps(hs,indent=2)+'\n').encode()
p=r/'docs/roadmap/evidence/m4-analyzer-literal-env-effects-2026-10-16.tar.gz';p.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(p,'w:gz') as t:
 for n,b in d.items():
  m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(p) as t:
 for n,h in hs.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
print(json.dumps({'archive':str(p.relative_to(r)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'payloads':len(hs),'freeze_count':len(j['freeze'])}))
