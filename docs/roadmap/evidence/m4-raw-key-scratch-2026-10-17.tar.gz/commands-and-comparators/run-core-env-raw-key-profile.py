from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,fcntl
cache=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-core-env-profile-e0')
run=cache/'core-env-raw-key-profile'
target=cache/'m4-cost-diagnostic-target'
lease=open(target/'.typed-scalar-witness.lease','w')
fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
lease.write(str(os.getpid()));lease.flush()
run.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='e0f73aeaa31a9394affad0d923288b4779a27889'
manifest={'base':'e0f73aeaa31a9394affad0d923288b4779a27889'}
paths=set(json.loads((cache/'native-fresh-class-complete-cost/before-freeze.json').read_text()))
paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
def freeze():
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snapshot(label,data):
 (run/(label+'-freeze.json')).write_text(json.dumps(data,indent=2))
 for p in data:
  dest=run/label/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,dest)
expected=freeze();assert expected==json.loads((cache/'core-env-preparation-observer-run/after-bootstrap-freeze.json').read_text());snapshot('before',expected)
shutil.copyfile(Path(__file__),run/'run-profile.py')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target))
for k in list(env):
 if k.startswith('SUSS_') and k.endswith('TRACE'):env.pop(k)
base=['cargo','test','-p','suss-compile','--locked','--lib'];tail=['--','--test-threads=1','--nocapture']
commands=[('core-env',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_core_environment','compiled_macro_core_namespace_keeps_complete_declaration_records','--','--exact','--test-threads=1','--nocapture'])]
state={'driver_pid':os.getpid(),'root':str(root),'base':manifest['base'],'input_count':len(expected),'target':str(target),'environment':{'jobs':1,'rayon':1,'test_threads':1,'RUSTFLAGS':'inherited, not assigned'},'current':None,'stages':[],'limits':'Diagnostic existing6trace-helper calls only; no quota/test/body/layout changes. Require all725control metadata events and macro balances unchanged before interpreting new subdivisions. Preserve terminal failure and unexecuted later caller/definition phases; no scope reduction.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for name,cmd in commands:
 assert freeze()==expected,'source changed before '+name
 if name=='core-env':env.update(SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1',SUSS_SOURCE_MATERIALIZE_FUEL_TRACE='1',SUSS_RAW_KEY_TRACE='1')
 state['current']=name;row={'name':name,'command':cmd};state['stages'].append(row);save();start=time.monotonic()
 with (run/(name+'.log')).open('w') as out:
  proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
 after=freeze();changed=[p for p in expected if expected[p]!=after[p]]
 row.update(exit=code,seconds=time.monotonic()-start,changed=changed)
 if name=='bootstrap' and code==0 and set(changed)<={f'runtime/bootstrap/{phase}.{ext}' for phase in ['macro','runtime'] for ext in ['wasm','json']}:
  expected=after;snapshot('after-bootstrap',expected)
 elif changed:
  row['unexpected_changes']=True;save();break
 save()
 if name=='core-env':
  import re
  text=(run/(name+'.log')).read_text(errors='replace')
  counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
  assert len(counts)==1 and sum(map(int,counts[0]))==1 and counts[0][2]=='0', 'unexpected focused execution count'
 if code:break
final=freeze();state['current']=None;state['final_changed']=[p for p,h in expected.items() if final[p]!=h];save()
