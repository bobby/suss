from pathlib import Path
import re,json
cache=Path(__file__).parent
run=cache/'native-raw-key-scratch-v2'
receipt=json.loads((run/'receipt.json').read_text())
assert receipt['current'] is None,'producer still live'
stage=next(s for s in receipt['stages'] if s['name']=='core-env')
assert not stage['changed'] and not receipt['final_changed']
def rows(path):
 return [(m[1],m[2],int(m[3])) for line in path.read_text(errors='replace').splitlines() if (m:=re.fullmatch(r'metadata-declaration (\S+) (\S+): (\d+)',line))]
old=rows(cache/'core-env-profile-e0/core-env.log')
new=rows(run/'core-env.log')
assert len(old)==725
common=0
for a,b in zip(old,new):
 if a[:2]!=b[:2]:break
 common+=1
assert common==len(old),'Original event sequence changed before control exhaustion'
checkpoints=[{'declaration':a[0],'stage':a[1],'control_remaining':a[2],'candidate_remaining':b[2],'saving_at_same_checkpoint':b[2]-a[2]} for a,b in zip(old,new)]
text=(run/'core-env.log').read_text(errors='replace')
counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
assert len(counts)==1 and sum(map(int,counts[0]))==1 and counts[0][2]=='0'
out={'control_events':len(old),'candidate_events':len(new),'common_ordered_checkpoint_count':common,'last_common_checkpoint':checkpoints[-1],'test_counts':dict(zip(['passed','failed','ignored'],map(int,counts[0]))),'exit':stage['exit'],'checkpoints':checkpoints,'limits':'Savings measured only at matched checkpoint. A failing candidate is not whole-operation savings or default acceptance. Later caller halves remain unexecuted until terminal full test success.'}
(run/'core-env-comparison.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checkpoints'},indent=2))
