from pathlib import Path
import re,json
c=Path(__file__).parent;r=c/'native-raw-key-scratch-acceptance';state=json.loads((r/'receipt.json').read_text());cohort=next(x for x in state['stages']if x['name']=='source-domain-cohort');assert cohort['exit']==0 and not cohort['changed']
s=(r/'source-domain-cohort.log').read_text(errors='replace');assert 'test result: ok. 43 passed; 0 failed; 0 ignored;'in s
old=(c/'native-borrowed-cut-capture/focused-rust.log').read_text(errors='replace')
def rows(text):
 result=[]
 for line in text.splitlines():
  if 'source-child-fuel 'not in line:continue
  line=line[line.index('source-child-fuel '):]
  m=re.search(r'remaining=Some\((\d+)\)',line);assert m,line
  result.append((re.sub(r'remaining=Some\(\d+\)','remaining=Some(<fuel>)',line),int(m[1])))
 return result
a,b=rows(old),rows(s);assert len(a)==len(b)==220;assert [x[0]for x in a]==[x[0]for x in b]
final={}
for phase in ['Runtime','Macro']:
 m=re.search(r'source-child-fuel source='+phase+r' variant=None stage=final-validation result=Ok\(\(\)\) remaining=Some\((\d+)\)',s);assert m
 remaining=int(m[1]);assert remaining==21485
 final[phase]={'fuel_start':10000000,'fuel_remaining':remaining,'actual_request_cost':10000000-remaining,'parent_actual_request_cost':9978107,'added_cost':408}
out={'cohort':{'passed':43,'failed':0,'ignored':0},'all_220_original_markers_match_in_order':True,'phases':final,'parser_note':'First inline parser required startswith and rejected the first marker sharing its libtest prefix (219/220). No guest failure. Corrected parser isolates every actual marker and requires exactly220 ordered matching rows.','limits':'Whole default source-child fixture only; CoreEnv still fails. No parent61passes credited as current candidate results.'}
(r/'default-source-child-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
