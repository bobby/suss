from pathlib import Path
import re,json
c=Path(__file__).parent;r=c/'core-env-raw-key-profile'
new={'definition-form','declaration-form','initializer-form','callable-reference','semantic-fields','source-boundaries'}
def rows(p):
 result=[]
 for x in p.read_text(errors='replace').splitlines():
  m=re.match(r'metadata-declaration (\S+) (\S+): (\d+)$',x)
  if m:result.append((m[1],m[2],int(m[3])))
 return result
control=rows(c/'core-env-profile-e0/core-env.log');observed=rows(r/'core-env.log');old=[x for x in observed if x[1]not in new]
assert old==control,'Existing metadata balances/sequence changed; observer invalid'
assert len(control)==725
macro=lambda p:[x for x in p.read_text(errors='replace').splitlines() if x.startswith('macro-fuel ')]
assert macro(c/'core-env-profile-e0/core-env.log')==macro(r/'core-env.log')
s=(r/'core-env.log').read_text();assert 'test result: FAILED. 0 passed; 1 failed; 0 ignored;' in s
out={'control_events':len(control),'observed_total_events':len(observed),'all_existing_events_and_balances_equal':True,'macro_balances_equal':True,'expected_failure_retained':True,'limits':'New completed subintervals only; remaining failing interval unknown. Not default acceptance.'};(r/'control-comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
