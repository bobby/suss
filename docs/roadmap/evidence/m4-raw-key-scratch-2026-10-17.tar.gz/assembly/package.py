from pathlib import Path
import json,hashlib,subprocess,tarfile,io,re,collections
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss-m4-raw-key-scratch');O=C/'raw-key-scratch-production-evidence';H='5e0d9f273081ec3a5d7c04aa9e949a1a3c08a0f0';P='dc5096d49d47b36c9bfcef9ed04a530f13869190';PIN='c4295f303100bbf5afac449242d30bca1126f1a1';runs=['native-raw-key-scratch','native-raw-key-scratch-v2','native-raw-key-scratch-acceptance'];payload={};blobs={}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H
allowed={'docs/roadmap/handoff.md','docs/roadmap/evidence/m4-raw-key-scratch-2026-10-17.md','docs/roadmap/evidence/m4-raw-key-scratch-2026-10-17.tar.gz'};assert set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R,text=True).splitlines())<=allowed
def put(n,b):assert n not in payload,n;payload[n]=b
freeze_records={}
for rn in runs+['core-env-profile-e0','core-env-preparation-observer-run','core-env-raw-key-profile']:
 root=C/rn;j=json.loads((root/'receipt.json').read_text())
 if rn=='native-raw-key-scratch':
  rec=json.loads((root/'terminal-reconciliation.json').read_text());assert rec['inputs_unchanged'] and rec['core_env']=='unexecuted';freeze_records[rn+'/terminal-reconciliation.json#terminal_source_freeze']=rec['terminal_source_freeze']
 else:assert j['current'] is None and j['final_changed']==[]
 for f in root.rglob('*'):
  if f.is_file() and f.relative_to(root).parts[0] not in ['before','after-bootstrap','terminal'] and '__pycache__' not in f.parts:put('runs/'+rn+'/'+str(f.relative_to(root)),f.read_bytes())
 for f in root.glob('*freeze.json'):freeze_records[rn+'/'+f.name]=json.loads(f.read_text())
 for key,freeze in list(freeze_records.items()):
  if not key.startswith(rn+'/'):continue
  assert len(freeze)==2915
  for n,h in freeze.items():
   if h in blobs:continue
   for stage in ['before','after-bootstrap','terminal']:
    p=root/stage/n
    if p.is_file():
     b=p.read_bytes()
     if hashlib.sha256(b).hexdigest()==h:blobs[h]=b;break
   else:raise AssertionError((key,n,h))
final=json.loads((C/runs[2]/'terminal-freeze.json').read_text());assert final==json.loads((C/runs[1]/'terminal-freeze.json').read_text());normal=[n for n in final if not n.startswith('clojurescript/')];checked={}
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=R,input=''.join(H+':'+n+'\n' for n in normal).encode());stream=io.BytesIO(raw)
for n in normal:
 header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob';b=stream.read(int(header[2]));assert stream.read(1)==b'\n';assert hashlib.sha256(b).hexdigest()==final[n],n;assert hashlib.sha256((R/n).read_bytes()).hexdigest()==final[n],n;checked[n]=final[n]
for n in final:
 if not n.startswith('clojurescript/'):continue
 b=subprocess.check_output(['git','show',PIN+':'+n.removeprefix('clojurescript/')],cwd=R/'clojurescript');assert hashlib.sha256(b).hexdigest()==final[n],n;checked[n]=final[n]
put('final/source-binding.json',(json.dumps({'head':H,'parent':P,'checked':len(checked),'pinned_cljs':PIN,'inputs':checked,'mismatches':[]},indent=2)+'\n').encode())
observed=json.loads((C/'core-env-preparation-observer-run'/'after-bootstrap-freeze.json').read_text());rawkey=json.loads((C/'core-env-raw-key-profile'/'before-freeze.json').read_text());assert observed==rawkey
obinding=json.loads((C/'core-env-raw-key-profile'/'source-commit-binding.json').read_text());cbinding=json.loads((C/'core-env-profile-e0'/'source-commit-binding.json').read_text());assert obinding['head']=='3c1e419f0e92cb1e16d3f09c74dd151f28d46f09' and obinding['checked']==2915 and not obinding['mismatches'];assert cbinding['head']=='e0f73aeaa31a9394affad0d923288b4779a27889' and cbinding['checked']==2915 and not cbinding['mismatches']
put('parent-diagnostic-source-correspondence.json',(json.dumps({'control_source':'e0f73aeaa31a9394affad0d923288b4779a27889','observer_and_rawkey_profile_source':'3c1e419f0e92cb1e16d3f09c74dd151f28d46f09','observer_after_equals_rawkey_before':True,'each_source_binding_checked':2915,'observer_scope':'Only6existingtracehelpercalls +4normalbootstrap artifacts, independent diagnostic branch, no acceptancecredit','prior_preliminary_archive_sha256':'cde03bc0c017b02c17d9567652f43aef5211ab6d6832694966e44c4ffac033c5'},indent=2)+'\n').encode())
put('final/source-five-file-diff.patch',subprocess.check_output(['git','diff','--binary',P,H],cwd=R))
for h,b in blobs.items():put('frozen/sha256/'+h,b)
for d in ['raw-key-scratch-design','raw-key-scratch-final-source-review','raw-key-scratch-provenance','raw-key-scratch-evidence-plan','core-env-preparation-observer']:
 for f in (C/d).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:put('packets/'+d+'/'+str(f.relative_to(C/d)),f.read_bytes())
for n in ['run-raw-key-scratch.py','run-raw-key-scratch-v2.py','run-raw-key-scratch-acceptance.py','compare-raw-key-scratch-core-env.py','compare-raw-key-scratch-v2-core-env.py','compare-raw-key-scratch-source-child.py','compare-raw-key-scratch-map.py','compare-core-env-preparation-observer.py','compare-core-env-raw-key-profile.py','run-core-env-preparation-observer.py','run-core-env-raw-key-profile.py','bind-suss-frozen-source.py']:
 put('commands-and-comparators/'+n,(C/n).read_bytes())
# Parentdc terminal CI is not candidateCI. Earlier raw parentbaseline is a
# different source19326 tuple, retained explicitly as historical context.
ci=C/'pr268-dc5096d-ci'/'39040606120';term=json.loads((ci/'terminal-receipt.json').read_text());assert term['head']==P and term['conclusion']=='failure'
for f in ci.rglob('*'):
 if f.is_file() and '__pycache__' not in f.parts:put('parent-dc-ci39040606120/'+str(f.relative_to(ci)),f.read_bytes())
b=C/'class-audit-full-baseline-19326ae'
for n in ['receipt.json','workspace.log','before-freeze.json','after-freeze.json','terminal-summary.json']:
 put('parent19326-full-baseline/'+n,(b/n).read_bytes())
# All retained historicalfreeze maps must also resolveinternally.
for n in ['before-freeze.json','after-freeze.json']:
 fm=json.loads((b/n).read_text())
 for path,h in fm.items():
  if h not in blobs:
   data=(b/'frozen'/'sha256'/h).read_bytes();assert hashlib.sha256(data).hexdigest()==h;blobs[h]=data;put('frozen/sha256/'+h,data)
comparison=json.loads((C/runs[1]/'core-env-comparison.json').read_text());assert comparison['common_ordered_checkpoint_count']==725 and comparison['candidate_events']==777 and comparison['last_common_checkpoint']['saving_at_same_checkpoint']==257798
budget=json.loads((C/runs[2]/'default-source-child-result.json').read_text());assert budget['all_220_original_markers_match_in_order'] and all(v['actual_request_cost']==9978515 and v['added_cost']==408 for v in budget['phases'].values())
selected=[C/runs[1]/'focused-rust.log',C/runs[2]/'source-domain-cohort.log',C/runs[2]/'core-import.log',C/runs[2]/'map.log'];counts=[];names=set()
for f in selected:
 text=f.read_text();rows=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert rows;counts.append(tuple(map(int,rows[-1])));names.update(re.findall(r'^test (\S+) \.\.\.',text,re.M))
assert counts==[(16,0,0),(43,0,0),(17,0,0),(1,0,0)],counts
assert len(names)==77,len(names)
mapcmp=json.loads((C/runs[2]/'map-independent-comparison.json').read_text());assert mapcmp['ordered_ids_match'] and mapcmp['counts']['pass']==62 and mapcmp['counts']['guest-judged']==7
summary={'head':H,'parent':P,'selected_unique_rust_pass':77,'selected_fail':0,'ignored':0,'separate_core_env':{'pass':0,'fuel_fail':1,'wholecost':'unknown','matched_prefix_more_remaining':257798,'matched_events':725,'candidate_events':777},'earlier_fixture_attempt':{'pass_executions':15,'fixture_fail':1,'core_env':'unexecuted','stale_receipt_preserved_with_reconciliation':True},'sourcechild_each_phase':{'cost':9978515,'remaining':21485,'more_cost_vs_parent':408,'complete_markers':220},'map_host_pass':62,'map_guest_judged':7,'provenance_checks_pass':6,'provenance_python_regressions_pass':30,'limits':['77selected unique, not initial15repeats','CoreEnvstillfailsbeforefirstRuntimeprojectioncompletes; laterhalvesunexecuted','ParentdcCI512foundation/106integrationpass14knownfail224unexecuted is notnewheadCI','Parent19326baseline83pass2fuel239integrationunexecuted separatetuple','No candidatefullbaseline or finalheadCIgreen claimed','No issueclosure/M4completion/merge']}
put('summary.json',(json.dumps(summary,indent=2)+'\n').encode());put('final/selected-unique-tests.json',(json.dumps(sorted(names),indent=2)+'\n').encode());put('assembly/package.py',Path(__file__).read_bytes())
checks=''.join(hashlib.sha256(payload[n]).hexdigest()+'  '+n+'\n' for n in sorted(payload));put('SHA256SUMS',checks.encode())
a=R/'docs/roadmap/evidence/m4-raw-key-scratch-2026-10-17.tar.gz'
with tarfile.open(a,'w:gz',compresslevel=6) as tar:
 for n in sorted(payload):
  data=payload[n];info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
hashes={};maps={}
with tarfile.open(a,'r|gz') as tar:
 for m in tar:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts and m.name not in hashes
  data=tar.extractfile(m).read();assert data==payload[m.name];hashes[m.name]=hashlib.sha256(data).hexdigest()
  if m.name.endswith('freeze.json'):maps[m.name]=json.loads(data)
  elif m.name.endswith('terminal-reconciliation.json'):maps[m.name+'#terminal_source_freeze']=json.loads(data)['terminal_source_freeze']
for n,fm in maps.items():
 assert len(fm)==2915
 for path,h in fm.items():assert hashes.get('frozen/sha256/'+h)==h,(n,path,h)
assert len(hashes)==len(payload)
j={'archive':str(a),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'members':len(payload),'manifested_payloads':len(payload)-1,'bytes':a.stat().st_size,'source_head':H,'source_bound':2915,'retained_2915_freeze_maps':len(maps),'selected_unique_tests':len(names)};(O/'package-result.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j))
