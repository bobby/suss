from pathlib import Path
import subprocess as s,os,json,time,hashlib,sys
root=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');p=Path(__file__).parent
assert json.loads((p/'receipt.json').read_text())['terminal']
freeze=json.loads((p/'source-manifest.json').read_text())
def changed():return [f for f,h in freeze.items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h]
assert not changed()
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
cargo=['cargo','test','--locked'];tail=['--','--test-threads=1','--nocapture'];stages=[('prototype-preservation',cargo+['-p','suss-compile','--lib','--','prototype_buffer_tests::','audit_prototype_uses_all_twelve_fields_and_survives_gc','--test-threads=1','--nocapture'],{}),('namespace',cargo+['-p','suss-cli','--test','compiled_macro_namespace_identity','compiler_namespace_and_declaration_aliases_match_pinned_five_call_observations','--','--exact','--test-threads=1','--nocapture'],{'SUSS_METADATA_FUEL_TRACE':'1','SUSS_NAMESPACE_IDENTITY_OUTPUT':str(p/'namespace.json')}),('cljs-value-effects',cargo+['-p','suss-cli','--test','portable_short_property_observations']+tail,{}),('pinned-map',cargo+['-p','suss-compile','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--exact','--test-threads=1','--nocapture'],{'SUSS_CLOJURE_TEST_SUITE_CAPTURE':str(p/'map-capture')})]
r={'terminal':False,'stages':[],'current':None}
def save():(p/'preserve-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
for name,cmd,extra in stages:
 assert not changed();start=time.monotonic();r['current']=name;runenv=env.copy();runenv.update(extra)
 with (p/(name+'.log')).open('w') as f:
  child=s.Popen(cmd,cwd=root,env=runenv,stdout=f,stderr=s.STDOUT);r['pid']=child.pid;save();code=child.wait()
 row={'name':name,'argv':cmd,'environment_overrides':extra,'exit':code,'seconds':round(time.monotonic()-start,3),'changed':changed()};r['stages'].append(row);r['current']=None;save();print(json.dumps(row),flush=True)
 assert not row['changed']
 if name=='prototype-preservation' and code:break
if any(x['name']=='pinned-map' for x in r['stages']):
 sys.path.insert(0,str(root/'scripts'));import clojure_test_suite as suite
 ref=json.loads((root/'tests/oracle/clojure-test-suite-observations.json').read_text());name='clojure.core-test.map/test-map';ns='clojure.core-test.map';ref.update(namespaces=[ns],tests=[name],assertions=[a for a in ref['assertions'] if a['test']==name],skips=[x for x in ref['skips'] if x['namespace']==ns]);capture=p/'map-capture/map-transport-observations.json';obs=json.loads(capture.read_text());counts,failures=suite.compare(ref,obs);ids=[[a['test'],a['ordinal']] for a in obs['assertions']];comp={'counts':counts,'failures':failures,'ordered_ids_match':ids==[[name,i] for i in range(1,70)],'capture_sha256':hashlib.sha256(capture.read_bytes()).hexdigest()};(p/'map-comparison.json').write_text(json.dumps(comp,indent=2)+'\n');print(json.dumps(comp),flush=True)
r['terminal']=True;save()
