import pathlib,json,re
p=pathlib.Path(__file__).parent;old=p/'control'
def parse(path):
 runs=[];current=None;pending={}
 for line in path.read_text().splitlines():
  m=re.search(r'coherent-stage stage=([\w-]+) boundary=(None|Some\(\d+\)).*remaining=Some\((\d+)\)',line)
  if not m:continue
  stage,b,n=m.groups();n=int(n)
  if stage=='entry':
   current=dict(admission=None,completed=[],last=None,finalization_reached=False);runs.append(current);pending={}
  if current is None:continue
  current['last']=[stage,b,n]
  if stage=='admitted':current['admission']=n
  if stage=='construct-before':pending[b]=n
  if stage=='construct-after':current['completed'].append(dict(boundary=b,units=pending.pop(b)-n,after=n))
  if stage=='finalize-before':current['finalization_reached']=True
 return runs
before=parse(old/'callable.log');after=parse(p/'callable.log');rows=[]
assert len(before)==len(after)==6
for a,b in zip(before,after):
 oldids=[x['boundary'] for x in a['completed']];newids=[x['boundary'] for x in b['completed']];prefix=min(len(oldids),len(newids));assert oldids[:prefix]==newids[:prefix]
 rows.append(dict(old_completed=len(oldids),new_completed=len(newids),common_completed_prefix=prefix,old_prefix_units=sum(x['units'] for x in a['completed'][:prefix]),new_prefix_units=sum(x['units'] for x in b['completed'][:prefix]),old_last=a['last'],new_last=b['last'],new_finalization_reached=b['finalization_reached']))
(p/'public-prefix-comparison.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
