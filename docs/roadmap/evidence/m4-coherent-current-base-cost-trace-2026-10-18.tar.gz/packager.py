from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,io,subprocess
C=Path('/home/bobby/.cache/suss-m4-work');P=Path(__file__).parent;PACK=C/'coherent-current-base-cost-trace-source-v1';RUN=C/'coherent-current-base-cost-trace-v1';PRIOR=C/'coherent-retention-current-base-focused-v1';OLDPACK=C/'coherent-retention-current-base-source-v1';sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def need(x,msg):
 if not x:raise RuntimeError(msg)
def main():
 m=load(PACK/'manifest.json');oldm=load(OLDPACK/'manifest.json');r=load(RUN/'receipt.json');oldr=load(PRIOR/'receipt.json');need(r['current'] is None and r['final_changed']==[],'trace not stable');need(r['stages'][0]['exit']==0 and r['stages'][1]['counts']=={'pass':0,'fail':1,'ignore':0} and r['stages'][1]['selection_established'],'wrong trace result');need(oldr['current'] is None and oldr['stages'][1]['counts']=={'pass':12,'fail':5,'ignore':0},'wrong prior result')
 payload={}
 def put(n,p):payload[n]=p.read_bytes()
 def tree(folder,prefix):
  for p in sorted(folder.rglob('*')):
   if p.is_file():need(not p.is_symlink(),'symlink payload');put(prefix+'/'+str(p.relative_to(folder)),p)
 tree(PACK,'marker-source');tree(OLDPACK,'prior-source-variant');tree(RUN,'run/marker-trace');tree(PRIOR,'run/prior17guards');tree(C/'coherent-current-base-admission-stages-source-v1','marker-delta')
 for n in ['coherent-current-base-cost-trace-source-v1-independent-review.json','coherent-retention-current-base-source-v1-independent-review.json','coherent-retention-current-base-focused-v1-independent-terminal-review.json','coherent-current-base-cost-trace-independent-terminal-review.json']:
  put('reviews/'+n,C/n)
 for n in ['REPORT.md','analyze.py','cost-analysis.json']:put(n,P/n)
 put('packager.py',Path(__file__))
 maps={}
 for label,folder,names in [('marker',RUN,['before.json','after-bootstrap.json','terminal.json']),('prior17',PRIOR,['before-freeze.json','after-bootstrap-freeze.json','terminal-freeze.json'])]:
  for n in names:maps[label+'/'+n]=load(folder/n);need(len(maps[label+'/'+n])==4043,'wrong freeze count')
 need(maps['marker/after-bootstrap.json']==maps['marker/terminal.json'],'marker post drift');need(maps['prior17/after-bootstrap-freeze.json']==maps['prior17/terminal-freeze.json'],'prior post drift')
 snapshots={};candidates={}
 for prefix,manifest in [('marker-source',m),('prior-source-variant',oldm)]:
  for n,h in manifest['files'].items():
   member=prefix+'/after/'+n;need(sha(payload[member])==h,'bad archivedsource '+n);candidates[(n,h)]=member
   if prefix=='marker-source':snapshots[n]={'sha256':h,'payload':member}
 boot=set(m['retained_generated_dependencies'])
 for n in boot:
  member='run/marker-trace/bootstrap/'+n;b=payload[member];h=maps['marker/terminal.json'][n];need(sha(b)==h,'captured marker boot mismatch');snapshots[n]={'sha256':h,'payload':member};candidates[(n,h)]=member
 unresolved=[];bindings={};queries={}
 for values in maps.values():
  for n,h in values.items():
   key=n+'@'+h
   if (n,h) in candidates:bindings[key]={'kind':'archived_payload','sha256':h,'payload':candidates[(n,h)]};continue
   # Earlier integration-generated boots were only hashed, never captured. No guessed Git binding.
   if n in boot and h==m['retained_generated_dependencies'][n]['sha256']:
    bindings[key]={'kind':'unavailable_historical_generated_dependency','sha256':h,'path':n,'reason':'Prior17 controller retained hash only; bootstrap overwritten by marker regeneration before payload capture. Not claimed copied or bound to Git. Reproduction requires original prior source variant and normal generator; exact historical-byte recovery NOT ESTABLISHED.'};unresolved.append(key);continue
   sub=n.startswith('clojurescript/');repo=Path(m['worktree'])/'clojurescript' if sub else Path(m['worktree']);ref='c4295f303100bbf5afac449242d30bca1126f1a1' if sub else m['base'];path=n.removeprefix('clojurescript/') if sub else n;queries[key]=(str(repo),ref,path,h)
 for repo in sorted({v[0] for v in queries.values()}):
  keys=[k for k,v in queries.items() if v[0]==repo];q=P/('queries-cljs.txt' if repo.endswith('/clojurescript') else 'queries-suss.txt');q.write_text('\n'.join(queries[k][1]+':'+queries[k][2] for k in keys)+'\n')
  with q.open('rb') as stdin:
   proc=subprocess.Popen(['git','-C',repo,'cat-file','--batch'],stdin=stdin,stdout=subprocess.PIPE)
   for key in keys:
    header=proc.stdout.readline().split();need(len(header)==3 and header[1]==b'blob','missing source '+key);size=int(header[2]);left=size;digest=hashlib.sha256()
    while left:
     b=proc.stdout.read(min(left,1024*1024));need(bool(b),'short Git object');digest.update(b);left-=len(b)
    need(proc.stdout.read(1)==b'\n','Git frame');v=queries[key];need(digest.hexdigest()==v[3],'Git source mismatch '+key);bindings[key]={'kind':'public_git_dependency','repository':'clojure/clojurescript' if repo.endswith('/clojurescript') else 'bobby/suss','commit':v[1],'path':v[2],'blob_oid':header[0].decode(),'sha256':v[3],'bytes':size}
   need(proc.wait()==0,'Git batch failure')
 terminal=maps['marker/terminal.json'];need(all(bindings[n+'@'+h]['kind']!='unavailable_historical_generated_dependency' for n,h in terminal.items()),'terminal not complete');need(len(set(unresolved))==4,'historical missing count')
 resolution={'base':m['base'],'freeze_maps':maps,'bindings':bindings,'unavailable_historical_generated_dependencies':sorted(set(unresolved)),'all4043_marker_postbootstrap_terminal_inputs_resolved':True,'snapshot_paths':snapshots,'limits':'Git-resolved current marker snapshot, not standalone source. Earlier prior17 generated four bootstrap payload bytes unavailable; hashes/raw outcomes/source variant preserved distinctly. No claim those bytes were captured.'};payload['source-resolution.json']=(json.dumps(resolution,indent=2)+'\n').encode()
 index={n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(payload.items())};payload['MANIFEST.json']=(json.dumps({'schema':1,'files':index},indent=2)+'\n').encode();out=P/'m4-coherent-current-base-cost-trace-2026-10-18.tar.gz'
 with out.open('xb') as f:
  with tarfile.open(fileobj=f,mode='w:gz') as t:
   for n,b in sorted(payload.items()):
    need(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts,'unsafe member');i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
 with tarfile.open(out) as t:
  ms=t.getmembers();need(len(ms)==len({x.name for x in ms})==len(payload),'member mismatch');need(all(x.isfile() and not PurePosixPath(x.name).is_absolute() and '..' not in PurePosixPath(x.name).parts for x in ms),'unsafe tar');data={x.name:t.extractfile(x).read() for x in ms}
  for n,v in index.items():need(sha(data[n])==v['sha256'] and len(data[n])==v['bytes'],'digest mismatch')
 result={'archive':str(out),'sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'members':len(payload),'hashed_payloads':len(index),'safe_paths_and_all_payload_hashes_verified':True,'source_base':m['base'],'source_patch_sha256':m['patch_sha256'],'source_inputs':4043,'unique_source_bindings':len(bindings),'unavailable_historical_generated_dependencies':sorted(set(unresolved)),'all_marker_terminal_inputs_resolved':True,'snapshot_paths':snapshots,'report_sha256':sha((P/'REPORT.md').read_bytes()),'results':'Marker bootstrapPASS;alias0PASS1typedfuelFAIL zero additional acceptance. Separate prior17 bootstrapPASS12PASS5typedfuelFAIL2CLIunexecuted; prior generated bootstrap payloads unavailable, hashes only.','publication':'Current diagnostic experimental backup from ae28 only, no PR/integration/readiness. Oldbe940 nativeV5 backup separate; baseline/CI reviews separate. Author source not read.'};(P/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='snapshot_paths'},indent=2))
if __name__=='__main__':main()
