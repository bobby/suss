from pathlib import Path
import json,re,hashlib,collections
C=Path('/home/bobby/.cache/suss-m4-work');R=C/'coherent-current-base-cost-trace-v1';P=Path(__file__).parent
log=(R/'alias-cost-trace.log').read_text();rows=[]
for match in re.finditer(r'^coherent-stage stage=(\S+) boundary=(None|Some\((\d+)\)) recipes=(\d+) captures=(\d+) remaining=Some\((\d+)\)$',log,re.M):
 rows.append({'stage':match[1],'boundary':int(match[3]) if match[3] else None,'recipes':int(match[4]),'captures':int(match[5]),'remaining':int(match[6])})
assert len([r for r in rows if r['stage']=='entry'])==len([r for r in rows if r['stage']=='admitted'])==1
assert rows[0]['remaining']==9965607 and rows[-1]['remaining']==2824163
intervals=[];groups=collections.Counter()
for a,b in zip(rows,rows[1:]):
 debit=a['remaining']-b['remaining'];assert debit>=0
 group={'expectation-project-before':'expectation_project','export-project-before':'export_project','expectation-witness-before':'expectation_witness','export-logical-witness-before':'export_witness','placement-before':'boundary_placement','export-placement-before':'export_placement','owner-check-before':'owner_duplicate_checks','source-root-children-before':'full_source_root_children','finish-recipes-before':'finish_recipes','frontier-before':'frontier','order-before':'order','schema-before':'class_schema_preflight','expectation-before':'expectation_child_setup','expectation-witness-after':'expectation_key_lease_allocation'}.get(a['stage'],'other_between_markers')
 intervals.append({'from':a['stage'],'to':b['stage'],'boundary':a['boundary'],'debit':debit,'bucket':group});groups[group]+=debit
project=[i for i in intervals if i['bucket']=='expectation_project'];assert len(project)==44 and len({i['boundary'] for i in project})==44
assert groups['expectation_project']==5300742 and groups['export_project']==1199431 and groups['expectation_witness']==294567 and groups['export_witness']==44920
assert sum(groups.values())==9965607-2824163==7141444
out={'raw_log_sha256':hashlib.sha256((R/'alias-cost-trace.log').read_bytes()).hexdigest(),'entry_remaining':9965607,'admitted_remaining':2824163,'admission_debit':7141444,'expectation_project_count':44,'disjoint_buckets':dict(groups),'project_total':groups['expectation_project']+groups['export_project'],'witness_total':groups['expectation_witness']+groups['export_witness'],'top_expectation_project':sorted(project,key=lambda x:x['debit'],reverse=True),'marker_rows':rows,'disjoint_adjacent_intervals':intervals,'limits':'Observed completed admission interval only, not whole request/actual failure cost. Every adjacent debit assigned exactly once; parent expectation/export inclusive spans not added again. Project buckets include existing native project traversal/copy/normalization work, not demonstrated pure copies or optimization savings. No later materialization partition or failed-debit inference.'}
(P/'cost-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'admission':out['admission_debit'],'buckets':out['disjoint_buckets'],'project':out['project_total'],'witness':out['witness_total']}))
