#!/usr/bin/env python3
"""Cache-only controller. Default: source-derived plan only. Execution needs exact review authorization."""
from pathlib import Path
import argparse,fcntl,hashlib,json,os,re,signal,subprocess,time
C=Path('/home/bobby/.cache/suss-m4-work')
ROOT=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace')
TARGET=C/'m4-cost-diagnostic-target'
BASE='ae28db396ee3050dedca812ff6993d7998e3e27f'
PIN='c4295f303100bbf5afac449242d30bca1126f1a1'
BOOT={f'runtime/bootstrap/{p}.{e}' for p in ('macro','runtime') for e in ('wasm','json')}
def sha(b):return hashlib.sha256(b).hexdigest()
def require(ok,why):
    if not ok:raise RuntimeError(why)
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def git(*args,root=ROOT):return subprocess.check_output(['git','-C',str(root),*args])
def check_processes():
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
        try:
            stat=(proc/'stat').read_text().split(') ',1)[1].split()[0]
            if stat in ('Z','X'):continue
            env=(proc/'environ').read_bytes();cmd=(proc/'cmdline').read_bytes();exe=str((proc/'exe').resolve());cwd=os.readlink(proc/'cwd')
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
        require(b'CARGO_TARGET_DIR='+str(TARGET).encode()+b'\0' not in env and not exe.startswith(str(TARGET)+'/'),f'Target producer active PID{proc.name}')
        if Path(exe).name in ('cargo','rustc'):
            require(not (str(TARGET).encode() in cmd or cwd==str(ROOT)),f'Cargo/rustc in requested root/target PID{proc.name}')
def inventory():
    paths=set()
    for prefix,repo in [('',ROOT),('clojurescript/',ROOT/'clojurescript')]:
        for raw in git('ls-files','-z','--cached','--others','--exclude-standard',root=repo).split(b'\0'):
            if not raw:continue
            rel=os.fsdecode(raw);full=repo/rel
            if not prefix and rel=='clojurescript':continue # pinned gitlink expanded below
            require(full.is_file(),f'Non-file/missing tracked input {prefix+rel}')
            paths.add(prefix+rel)
    # Also freeze ignored native compiler sources accidentally present in either crate/runtime tree.
    for base in (ROOT/'crates',ROOT/'runtime'):
        for folder,dirs,files in os.walk(base):
            dirs[:]=[d for d in dirs if d not in ('target','.git','out','node_modules','__pycache__')]
            for name in files:
                if Path(name).suffix in ('.rs','.sus'):
                    paths.add(str((Path(folder)/name).relative_to(ROOT)))
    return sorted(paths)
def freeze():
    values={};links={}
    for rel in inventory():
        p=ROOT/rel;values[rel]=sha(p.read_bytes())
        if p.is_symlink():links[rel]=os.readlink(p)
    return values,links

def source_names(path):
    text=(ROOT/path).read_text();require('#[ignore' not in text,'Ignored tests in selected file '+path)
    ns=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',text);require(len(ns)==len(set(ns)) and ns,'Invalid source selection '+path);return ns

def stages(packet):
    t=packet['tests'];groups=[];full=[]
    for label in ('coherent','legacy_retirement'):
        group=t[label];text=(ROOT/group['path']).read_text()
        if label=='legacy_retirement':
            anchor='mod retirement_tests {';require(text.count(anchor)==1,'ambiguous retirement module');text=text.split(anchor,1)[1]
            actual=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',text)
        else:actual=source_names(group['path'])
        require(actual==group['names'],'packet/source guard names mismatch '+label)
        prefix=group['prefix'];groups.append(prefix);full += [prefix+n for n in actual]
    require(len(full)==len(set(full))==t['count'],'guard selection count mismatch')
    # Independently check nested module routing, rather than treating prefixes as arbitrary labels.
    require('mod coherent;' in (ROOT/'crates/suss-compile/src/portable_macro_graph/source_roots.rs').read_text(),'missing coherent module')
    require('#[path = "coherent_tests.rs"]' in (ROOT/'crates/suss-compile/src/portable_macro_graph/source_roots/coherent.rs').read_text(),'missing tests module routing')
    fixture='crates/suss-cli/tests/compiled_macro_namespace_identity.rs';ns=source_names(fixture)
    callable='resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations'
    other='compiler_namespace_and_declaration_aliases_match_pinned_five_call_observations'
    require(set(ns)=={callable,other},'unchanged namespace pair identity differs')
    expected=packet['unchanged_namespace_fixture'];require(sha((ROOT/fixture).read_bytes())==expected['sha256'],'namespace fixture changed')
    cargo=['cargo','test','--locked'];tail=['--','--exact','--test-threads=1','--nocapture']
    return [
      {'name':'bootstrap','command':['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap'],'selected_names':[]},
      {'name':'coherent-guards','command':cargo+['-p','suss-compile','--lib','--','--test-threads=1','--nocapture']+groups,'selected_names':full},
      {'name':'callable-six-row','command':cargo+['-p','suss-cli','--test','compiled_macro_namespace_identity',callable]+tail,'selected_names':[callable]},
      {'name':'remaining-namespace-five-call','command':cargo+['-p','suss-cli','--test','compiled_macro_namespace_identity',other]+tail,'selected_names':[other]}
    ]

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--packet',type=Path,required=True);ap.add_argument('--packet-sha256',required=True);ap.add_argument('--approval',type=Path);ap.add_argument('--run',type=Path,default=C/'coherent-retention-current-base-focused-v1');ap.add_argument('--execute',action='store_true');args=ap.parse_args()
    require(sha(args.packet.read_bytes())==args.packet_sha256,'manifest digest mismatch');packet=json.loads(args.packet.read_text())
    require(packet['base']==BASE and packet['worktree']==str(ROOT),'wrong isolated source/base')
    require(sha((args.packet.parent/'candidate.patch').read_bytes())==packet['patch_sha256'],'patch digest mismatch')
    for path,digest in packet['files'].items():require(sha((ROOT/path).read_bytes())==digest,'source packet mismatch '+path)
    require(git('rev-parse','HEAD').decode().strip()==BASE,'HEAD differs from authorized base')
    require(git('rev-parse','--abbrev-ref','HEAD').decode().strip()==packet['branch'],'branch mismatch')
    selected=stages(packet)
    plan={'base':BASE,'packet':str(args.packet),'manifest_sha256':args.packet_sha256,'patch_sha256':packet['patch_sha256'],'target':str(TARGET),'run':str(args.run),'stages':selected,'guard_count':len(selected[1]['selected_names']),'conditional':'Stop dependent stages on any compile/selection/semantic/fuel failure. Remaining five-call namespace probe only after bootstrap+guards+exact callable PASS. No test repeated.','limits':'No source8a baseline/target touched. Own isolated be940 tuple only; no allowances/fixtures/fees/RUSTFLAGS changes; no integration/readiness claim.'}
    if not args.execute:print(json.dumps(plan,indent=2));return
    require(args.approval and args.approval.is_file(),'final independent source approval required')
    approval=json.loads(args.approval.read_text());require(approval.get('authorization')=='APPROVED_FOR_FOCUSED_EXECUTION' and approval.get('manifest_sha256')==args.packet_sha256 and approval.get('patch_sha256')==packet['patch_sha256'] and approval.get('files')==packet['files'],'approval not exact packet/source authorization')
    require(args.run.is_absolute() and args.run.is_relative_to(C) and not args.run.exists(),'run must be new cache directory')
    require(git('rev-parse','HEAD',root=ROOT/'clojurescript').decode().strip()==PIN,'CLJS not pinned');require(not git('status','--porcelain',root=ROOT/'clojurescript').strip(),'dirty CLJS')
    tracked=set(git('diff','--name-only',BASE).decode().splitlines());untracked=set(os.fsdecode(x) for x in git('ls-files','-z','--others','--exclude-standard').split(b'\0') if x)
    retained=packet.get('retained_generated_dependencies',{})
    require(set(retained)==BOOT,'V4 retained bootstrap dependencies must be exact four paths')
    for path,entry in retained.items():require(sha((ROOT/path).read_bytes())==entry['sha256'],'retained bootstrap dependency differs '+path)
    dirty=tracked|untracked
    require(set(packet['files']) <= dirty <= set(packet['files'])|set(retained),'dirty scope not exact reviewed source plus optional declared bootstrap dependency changes')
    check_processes();TARGET.mkdir(exist_ok=True);leases=[]
    lease_names={'.typed-scalar-witness.lease','.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease','.coherent-declaration-retention.lease'}
    lease_names.update(p.name for p in TARGET.iterdir() if p.is_file() and (p.name.endswith('.lease') or p.name.endswith('.lock')) and p.name not in ('.cargo-lock',))
    for name in sorted(lease_names):
        handle=(TARGET/name).open('a+');fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(handle)
    check_processes()
    initial,links=freeze();require(all(initial[path]==value for path,value in packet['files'].items()),'initial freeze packet mismatch')
    args.run.mkdir();run=args.run;(run/'driver.py').write_bytes(Path(__file__).read_bytes());dump(run/'reviewed-source-manifest.json',packet);dump(run/'independent-source-approval.json',approval);dump(run/'source-derived-selection.json',plan);dump(run/'before-freeze.json',initial);dump(run/'before-symlinks.json',links)
    state={'driver_pid':os.getpid(),'root':str(ROOT),'target':str(TARGET),'base':BASE,'packet_sha256':args.packet_sha256,'input_count':len(initial),'current':None,'planned_stages':[s['name'] for s in selected],'stages':[],'leases':sorted(lease_names),'environment_controls':{'CARGO_BUILD_JOBS':'1','RAYON_NUM_THREADS':'1','test_threads':1,'RUSTFLAGS':'inherited unchanged; not set by driver'},'limits':plan['limits']};dump(run/'receipt.json',state)
    expected=initial;env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(TARGET))
    for k in list(env):
        if k.startswith('SUSS_') and (k.endswith('TRACE') or 'CAPTURE' in k):env.pop(k)
    fatal=None;proc=None
    try:
        for spec in selected:
            now,nowlinks=freeze();require(now==expected and nowlinks==links,'inputs changed before stage')
            row={**spec,'execution':'UNEXECUTED'};state['stages'].append(row);state['current']=spec['name'];dump(run/'receipt.json',state);start=time.monotonic()
            with (run/(spec['name']+'.log')).open('wb') as log:
                proc=subprocess.Popen(spec['command'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=proc.pid;dump(run/'receipt.json',state);code=proc.wait()
            row.update(exit=code,seconds=time.monotonic()-start)
            after,afterlinks=freeze();changed=sorted(p for p in set(after)|set(expected) if after.get(p)!=expected.get(p));row['changed']=changed
            if spec['name']=='bootstrap':
                row['execution']='PASS' if code==0 else 'FAIL'
                require(not(set(changed)-BOOT) and afterlinks==links,'bootstrap changed non-allowlisted input')
                if code==0:expected=after;dump(run/'after-bootstrap-freeze.json',after)
            else:
                require(after==expected and afterlinks==links,'source changed during test stage')
                text=(run/(spec['name']+'.log')).read_text(errors='replace');text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)
                starts=re.findall(r'^test ([\w:]+) \.\.\.',text,re.M);summaries=[tuple(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)];counts=[sum(x[i] for x in summaries) for i in range(3)]
                row.update(observed_full_names=starts,counts=dict(zip(['pass','fail','ignore'],counts)),rust_summaries=summaries)
                established=(len(starts)==len(set(starts))==len(spec['selected_names']) and set(starts)==set(spec['selected_names']) and len(summaries)==1 and sum(counts)==len(starts) and counts[2]==0)
                row['execution']='COMPLETE' if established else 'UNESTABLISHED: compile/setup/zero-test/incomplete selection; raw log retained'
                if spec['name'] in ('callable-six-row','remaining-namespace-five-call'):
                    for tag in ['CALLABLE_NAMESPACE_IDENTITY','NAMESPACE_IDENTITY']:
                        captures=re.findall(tag+r' (\{[^\n]+\})',text)
                        if captures:dump(run/(spec['name']+'-'+tag+'.json'),[json.loads(s) for s in captures])
                if code==0:require(established and counts[1]==0,'exit0 without exact successful selected execution')
            dump(run/'receipt.json',state)
            if code!=0 or row['execution'].startswith('UNESTABLISHED'):break
    except BaseException as error:
        state['controller_error']=repr(error);fatal=error
        if proc is not None and proc.poll() is None:
            # Only this driver's dedicated child process group; never unrelated producers.
            state['intervention']='terminate own stage process group after controller interruption'
            try: os.killpg(proc.pid,signal.SIGTERM)
            except ProcessLookupError: pass
            try: proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL);proc.wait()
            state['stages'][-1]['exit']=proc.returncode
            state['stages'][-1]['execution']='INTERRUPTED: no successful execution inferred'
    finally:
        final,finallinks=freeze();state['current']=None;state['final_changed']=sorted(p for p in set(final)|set(expected) if final.get(p)!=expected.get(p));state['symlink_changes']={p:[links.get(p),finallinks.get(p)] for p in set(links)|set(finallinks) if links.get(p)!=finallinks.get(p)};state['unexecuted_stages']=[s['name'] for s in selected if s['name'] not in {x['name'] for x in state['stages']}];state['pid']=os.getpid();dump(run/'terminal-freeze.json',final);dump(run/'receipt.json',state)
    print(json.dumps({k:state[k] for k in ['base','current','stages','final_changed','unexecuted_stages']},indent=2))
    if fatal:raise fatal
    require(state['final_changed']==[] and state['symlink_changes']=={},'terminal freeze changed')
    if state['unexecuted_stages'] or any(s.get('exit')!=0 or s['execution'] not in ('PASS','COMPLETE') for s in state['stages']):raise SystemExit(1)
if __name__=='__main__':main()
