from pathlib import Path
import subprocess,os,json,hashlib,time,fcntl,re,signal
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace');T=C/'m4-cost-diagnostic-target';O=C/'coherent-current-base-cost-trace-v1';P=C/'coherent-current-base-cost-trace-source-v1';BOOT={f'runtime/bootstrap/{p}.{e}' for p in ('macro','runtime') for e in ('wasm','json')}
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def git(*a,root=R):return subprocess.check_output(['git','-C',str(root),*a])
manifest=json.loads((P/'manifest.json').read_text())
assert sha((P/'manifest.json').read_bytes())=='3df7480580056bc9a2ffe4bd2e49a52fb4e7c501efe7e66c1c830d02e2936288'
assert git('rev-parse','HEAD').decode().strip()==manifest['base']
assert git('rev-parse','HEAD',root=R/'clojurescript').decode().strip()=='c4295f303100bbf5afac449242d30bca1126f1a1'
assert not git('status','--porcelain',root=R/'clojurescript').strip()
for f,h in manifest['files'].items():assert sha((R/f).read_bytes())==h
assert sha((P/'candidate.patch').read_bytes())==manifest['patch_sha256']
fixture=manifest['unchanged_cli_fixture'];assert sha((R/fixture['path']).read_bytes())==fixture['sha256']
actual=set(git('diff','HEAD','--name-only').decode().splitlines())|set(x for x in git('ls-files','--others','--exclude-standard').decode().splitlines() if x)
assert set(manifest['files']) <= actual <= set(manifest['files'])|BOOT
for f,v in manifest['retained_generated_dependencies'].items():assert sha((R/f).read_bytes())==v['sha256']
stages=[{'name':'bootstrap','command':['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap'],'selected_names':[]},{'name':'alias-cost-trace','command':['cargo','test','--locked','-p','suss-compile','--lib',manifest['diagnostic_test'],'--','--exact','--test-threads=1','--nocapture'],'selected_names':[manifest['diagnostic_test']]}]
if '--execute' not in __import__('sys').argv:print(json.dumps(stages,indent=2));raise SystemExit()
approval=json.loads((C/'coherent-current-base-cost-trace-source-v1-independent-review.json').read_text());assert approval['authorization']=='APPROVED_FOR_BOUNDED_DIAGNOSTIC_EXECUTION' and approval['manifest_sha256']==sha((P/'manifest.json').read_bytes()) and approval['files']==manifest['files'] and approval['patch_sha256']==manifest['patch_sha256']
assert not O.exists()
leases=[]
for p in sorted(T.iterdir()):
 if p.is_file() and p.name.endswith(('.lease','.lock')) and p.name!='.cargo-lock':
  h=p.open('a+');fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(h)
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=str((p/'exe').resolve());cmd=(p/'cmdline').read_bytes()
 except (OSError,PermissionError):continue
 assert not exe.startswith(str(T)+'/'),f'target process {p.name}'
 if Path(exe).name in ('cargo','rustc'):assert str(T).encode() not in cmd

def freeze():
 paths=set()
 for prefix,repo in [('',R),('clojurescript/',R/'clojurescript')]:
  for x in git('ls-files','-z','--cached','--others','--exclude-standard',root=repo).split(b'\0'):
   if not x:continue
   f=os.fsdecode(x)
   if not prefix and f=='clojurescript':continue
   paths.add(prefix+f)
 for folder in (R/'crates',R/'runtime'):
  for base,dirs,files in os.walk(folder):
   dirs[:]=[x for x in dirs if x not in ('target','.git','out','node_modules','__pycache__')]
   paths.update(str((Path(base)/f).relative_to(R)) for f in files if Path(f).suffix in ('.rs','.sus'))
 return {f:sha((R/f).read_bytes()) for f in sorted(paths)}
expected=freeze();O.mkdir();dump(O/'before.json',expected);(O/'driver.py').write_bytes(Path(__file__).read_bytes());(O/'source-manifest.json').write_bytes((P/'manifest.json').read_bytes());(O/'source-approval.json').write_text(json.dumps(approval,indent=2));dump(O/'selection.json',stages)
state={'driver_pid':os.getpid(),'head':manifest['base'],'input_count':len(expected),'target':str(T),'current':None,'stages':[],'limits':'Marker-only coherent admission cost diagnostic; one unchanged alias test. No quota/refill/fee/fixture/RUSTFLAGS changes. No repeated17guard credit or CLI acceptance.'}
code=0
proc=None
controller_error=None
try:
 for stage in stages:
  assert freeze()==expected
  row=dict(stage);row['execution']='UNEXECUTED';state['stages'].append(row);state['current']=stage['name'];dump(O/'receipt.json',state)
  env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(T))
  for k in list(env):
   if k.startswith('SUSS_') and (k.endswith('TRACE') or 'CAPTURE' in k):env.pop(k)
  if stage['name']=='alias-cost-trace':env.update(SUSS_METADATA_FUEL_TRACE='1',SUSS_SOURCE_MATERIALIZE_FUEL_TRACE='1')
  start=time.monotonic()
  with (O/(stage['name']+'.log')).open('wb') as log:
   proc=subprocess.Popen(stage['command'],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row.update(pid=proc.pid,pgid=proc.pid,execution='RUNNING');dump(O/'receipt.json',state);code=proc.wait()
  after=freeze();changed=[f for f in sorted(expected.keys()|after.keys()) if expected.get(f)!=after.get(f)];row.update(exit=code,seconds=time.monotonic()-start,changed=changed)
  if stage['name']=='bootstrap':
   row['execution']='PASS' if code==0 else 'FAIL'
   assert set(changed)<=BOOT
   if code==0:
    expected=after;dump(O/'after-bootstrap.json',after)
    for f in BOOT:
     dst=O/'bootstrap'/f;dst.parent.mkdir(parents=True,exist_ok=True);b=(R/f).read_bytes();assert sha(b)==expected[f];dst.write_bytes(b)
  else:
   assert not changed
   text=(O/(stage['name']+'.log')).read_text(errors='replace')
   found=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
   names=re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\.',text,re.M)
   row['actual_test_starts']=names
   counts=tuple(map(int,found[0])) if len(found)==1 else None
   established=counts is not None and sum(counts)==len(stage['selected_names']) and counts[2]==0 and sorted(names)==sorted(stage['selected_names'])
   row['selection_established']=established
   if counts is not None:row['counts']=dict(zip(('pass','fail','ignore'),counts))
   if established:row['execution']='PASS' if code==0 and counts[1]==0 else 'FAIL'
   else:row['execution']='UNESTABLISHED: compile/setup/zero-test/incomplete exact selection; no probe execution credit'
   dump(O/'receipt.json',state)
   if not established and code==0:raise RuntimeError('Zero or incomplete exact test selection despite exit0')
  dump(O/'receipt.json',state)
  if code:break
except BaseException as error:
 controller_error=repr(error);state['controller_error']=controller_error;code=code or 1
 if state['stages'] and state['stages'][-1]['execution']=='RUNNING':state['stages'][-1]['execution']='UNESTABLISHED: controller interrupted; raw partial log retained'
finally:
 # Observation timeouts never terminate this producer. Only an actual controller
 # exception/interruption cleans its own new-session child group before release.
 if controller_error is not None and proc is not None:
  try:
   os.killpg(proc.pid,signal.SIGTERM);state['own_group_cleanup']='SIGTERM'
  except ProcessLookupError:pass
  if proc.poll() is None:
   try:proc.wait(timeout=30)
   except subprocess.TimeoutExpired:
    try:os.killpg(proc.pid,signal.SIGKILL);state['own_group_cleanup']='SIGKILL after30s'
    except ProcessLookupError:pass
    proc.wait()
  state['own_child_terminal_exit']=proc.returncode
  def own_group_live():
   for entry in Path('/proc').iterdir():
    if not entry.name.isdigit():continue
    try:parts=(entry/'stat').read_text().rsplit(') ',1)[1].split()
    except (OSError,IndexError):continue
    if parts[0] not in ('Z','X') and int(parts[2])==proc.pid and int(parts[3])==proc.pid:return True
   return False
  deadline=time.monotonic()+10
  while own_group_live() and time.monotonic()<deadline:time.sleep(.1)
  if own_group_live():
   try:os.killpg(proc.pid,signal.SIGKILL);state['own_group_cleanup']='SIGKILL remaining own descendants'
   except ProcessLookupError:pass
   deadline=time.monotonic()+10
   while own_group_live() and time.monotonic()<deadline:time.sleep(.1)
  state['own_group_live_after_cleanup']=own_group_live()
 try:
  terminal=freeze();state['final_changed']=[f for f in sorted(expected.keys()|terminal.keys()) if expected.get(f)!=terminal.get(f)];dump(O/'terminal.json',terminal)
 except BaseException as error:state['terminal_freeze_error']=repr(error)
 state['current']=None
 state['unexecuted_stages']=[s['name'] for s in stages[len(state['stages']):]]
 dump(O/'receipt.json',state)
print(json.dumps({'head':state['head'],'stages':[{k:v for k,v in r.items() if k in ('name','exit','execution','seconds','counts')} for r in state['stages']],'unexecuted':state['unexecuted_stages'],'final_changed':state.get('final_changed'),'controller_error':state.get('controller_error')}));raise SystemExit(code)
