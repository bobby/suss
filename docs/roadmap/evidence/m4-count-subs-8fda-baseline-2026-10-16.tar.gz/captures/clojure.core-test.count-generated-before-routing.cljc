(ns clojure.core-test.count
  (:require [clojure.test :as t :refer [are deftest]]
            [clojure.core-test.portability #?(:cljs :refer-macros :default :refer) [when-var-exists] :as p]))

(when-var-exists count
  (deftest test-count
    (are [expected x] (= expected (count x))
      0 nil
      0 '()
      0 []
      0 {}
      0 #{}
      0 ""
      1 '(:a)
      1 [:a]
      1 {:a 1}
      1 #{:a}
      1 "a"
      2 '(:a :b)
      2 [:a :b]
      2 {:a 1 :b 2}
      2 #{:a :b}
      2 "ab")

    ;; Negative tests
    (are [x] (p/thrown? (count x))
      1
      :a
      'a
      #?@(:lpy [] :cljs [] :default [\a]))))
