(ns clojure.core-test.count (:require [suss.harness.test :as t] [clojure.core-test.portability :as p]) (:require-macros [suss.harness.portability-macros :refer [when-var-exists]] [suss.harness.test-macros :refer [are deftest]]))

(when-var-exists count
  (deftest test-count
    (are [expected x] (= expected (count x))
      0 nil
      0 '()
      0 []
      0 {}
      0 #{}
      0 ""
      1 '(:a)
      1 [:a]
      1 {:a 1}
      1 #{:a}
      1 "a"
      2 '(:a :b)
      2 [:a :b]
      2 {:a 1 :b 2}
      2 #{:a :b}
      2 "ab")

    ;; Negative tests
    (are [x] (p/thrown? (count x))
      1
      :a
      'a
      #?@(:lpy [] :cljs [] :default [\a]))))
