from pathlib import Path
r=Path('/home/bobby/Work/code/bobby/suss-m4-count-subs-baseline');p=r/'crates/suss-compile/tests/clojure_test_suite.rs';s=p.read_text();a=s.index('/// #261 supplemental value conformance:');new=s[a:]
new=new.replace('/// #261 supplemental value conformance: execute the entire unchanged pinned keyword test.\n/// Memo state and callback effects require the separate CLJS/native probes.','/// Test-only 8fda18a baseline: complete pinned count/subs bodies, independent observations.')
new=new.replace('fn pinned_keyword_namespace_keeps_values()', 'fn pinned_count_subs_namespaces_keep_full_ordered_observations()')
new=new.replace('let names = ["clojure.core-test.keyword"];','let names = ["clojure.core-test.count", "clojure.core-test.subs"];')
new=new.replace('let tests = ["clojure.core-test.keyword/test-keyword"];','let tests = ["clojure.core-test.subs/test-subs", "clojure.core-test.count/test-count"];')
new=new.replace('SUSS_KEYWORD_CONFORMANCE_CAPTURE','SUSS_COUNT_SUBS_CONFORMANCE_CAPTURE').replace('keyword-observations','count-subs-observations').replace('keyword-comparison','count-subs-comparison').replace('keyword-comparator','count-subs-comparator').replace('PINNED_KEYWORD_CONFORMANCE','PINNED_COUNT_SUBS_CONFORMANCE')
new=new.replace("names=['clojure.core-test.keyword']","names=['clojure.core-test.count','clojure.core-test.subs']").replace("tests=['clojure.core-test.keyword/test-keyword']","tests=['clojure.core-test.subs/test-subs','clojure.core-test.count/test-count']")
old='''        assert_eq!(std::fs::read(original).unwrap(),
            std::fs::read(source_file(&source_root, namespace)).unwrap(),
            "the complete original keyword declaration must remain intact");'''
replace='''        let original_bytes=std::fs::read(original).unwrap();
        let generated_bytes=std::fs::read(source_file(&source_root, namespace)).unwrap();
        assert_eq!(original_bytes,generated_bytes,
            "the complete original namespace declaration/body must remain intact");
        if let Some(directory)=std::env::var_os("SUSS_COUNT_SUBS_CONFORMANCE_CAPTURE") {
            let directory=PathBuf::from(directory);std::fs::create_dir_all(&directory).unwrap();
            std::fs::write(directory.join(format!("{namespace}-original.cljc")),&original_bytes).unwrap();
            std::fs::write(directory.join(format!("{namespace}-generated-before-routing.cljc")),&generated_bytes).unwrap();
        }'''
assert old in new;new=new.replace(old,replace)
needle='''    let captured = workspace.path().join("count-subs-observations.json");'''
extra='''    for namespace in names {
        let original=std::fs::read_to_string(repository.join("vendor/clojure-test-suite/upstream/test")
            .join(namespace.replace('.', "/").replace('-', "_")+".cljc")).unwrap();
        let routed=std::fs::read_to_string(source_file(&source_root,namespace)).unwrap();
        let original_end=read_forms(&original).unwrap()[0].span.end;
        let routed_end=read_forms(&routed).unwrap()[0].span.end;
        assert_eq!(&original.as_bytes()[original_end..],&routed.as_bytes()[routed_end..],
            "only the existing harness namespace adaptation may change");
        if let Some(directory)=std::env::var_os("SUSS_COUNT_SUBS_CONFORMANCE_CAPTURE") {
            std::fs::write(PathBuf::from(directory).join(format!("{namespace}-routed.cljc")),routed).unwrap();
        }
    }
'''
assert needle in new;new=new.replace(needle,extra+needle)
p.write_text(s+'\n'+new)
