from pathlib import Path
import os,json,time,hashlib,subprocess
r=Path('/home/bobby/Work/code/bobby/suss-m4-count-subs-baseline');c=Path('/home/bobby/.cache/suss-m4-work');capture=c/'count-subs-baseline-capture';capture.mkdir(exist_ok=True)
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(c/'count-subs-baseline-target'),SUSS_COUNT_SUBS_CONFORMANCE_CAPTURE=str(capture))
files=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']]+[p for p in (r/'runtime/bootstrap').glob('*') if p.is_file()]
freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
changed=subprocess.check_output(['git','diff','--name-only','8fda18a'],cwd=r,text=True).splitlines();assert changed==['crates/suss-compile/tests/clojure_test_suite.rs'],changed
state={'base':'8fda18a','production_unchanged':True,'test_only_changed_paths':changed,'freeze':freeze,'command':['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','pinned_count_subs_namespaces_keep_full_ordered_observations','--','--exact','--nocapture','--test-threads=1'],'current':'test','capture':str(capture)};out=c/'count-subs-baseline-result.json';out.write_text(json.dumps(state,indent=2)+'\n');start=time.time()
with (c/'count-subs-baseline.log').open('w') as f:p=subprocess.run(state['command'],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
state.update(current=None,exit=p.returncode,seconds=time.time()-start,source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in freeze.items()));out.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({k:v for k,v in state.items() if k!='freeze'},indent=2))
