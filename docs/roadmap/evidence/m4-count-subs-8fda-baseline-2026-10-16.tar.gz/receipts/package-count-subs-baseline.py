from pathlib import Path
import hashlib,json,subprocess,tarfile,io
r=Path('/home/bobby/Work/code/bobby/suss-m4-count-subs-baseline');c=Path('/home/bobby/.cache/suss-m4-work');s=json.loads((c/'count-subs-baseline-result.json').read_text());assert s['current'] is None and s['source_unchanged'] and s['production_unchanged'];payload={}
for f,h in s['freeze'].items():
 b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+f]=b
extra=['Cargo.toml','Cargo.lock','crates/suss-core/Cargo.toml','crates/suss-reader/Cargo.toml','crates/suss-compile/Cargo.toml','crates/suss-cli/Cargo.toml','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','runtime/core-import/LICENSE','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json','vendor/wasi/wasi-wit-0.3.1/cli/cli.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit']
for f in extra:assert (r/f).is_file();payload['snapshot/'+f]=(r/f).read_bytes()
paths=[f for f in s['freeze'] if f=='crates/suss-compile/build.rs' or any(f.startswith('crates/'+n+'/src/') and f.endswith(('.rs','.sus')) for n in ['suss-core','suss-reader','suss-compile'])]+extra[:5]+extra[9:];h=hashlib.sha256()
for f in sorted(set(paths),key=lambda p:tuple(p.split('/'))):
 b=payload['snapshot/'+f];n=f.encode();h.update(len(n).to_bytes(8,'little'));h.update(n);h.update(len(b).to_bytes(8,'little'));h.update(b)
checks={}
for phase in ['macro','runtime']:
 m=json.loads(payload[f'snapshot/runtime/bootstrap/{phase}.json']);checks[phase]={'compiler':h.hexdigest()==m['compiler_source_sha256'],'core':hashlib.sha256(payload['snapshot/runtime/core-import/suss/core.sus']).hexdigest()==m['source_sha256'],'dependencies':hashlib.sha256(payload['snapshot/runtime/core-import/manifest.json']).hexdigest()==m['dependency_graph_sha256'],'wasm':hashlib.sha256(payload[f'snapshot/runtime/bootstrap/{phase}.wasm']).hexdigest()==m['wasm_sha256']}
assert all(all(v.values()) for v in checks.values()),checks

for p in (c/'count-subs-baseline-capture').iterdir():
 if p.is_file():payload['captures/'+p.name]=p.read_bytes()
for n in ['count-subs-baseline-result.json','count-subs-baseline.log','count-subs-source-receipt.json','run-count-subs-baseline.py','install-count-subs-gate.py','package-count-subs-baseline.py']:
 payload['receipts/'+n]=(c/n).read_bytes()
for n in ['tests/oracle/clojure-test-suite-observations.json','vendor/clojure-test-suite/README.md','vendor/clojure-test-suite/upstream/LICENSE','vendor/clojure-test-suite/upstream/README.md','vendor/clojure-test-suite/upstream/test/clojure/core_test/count.cljc','vendor/clojure-test-suite/upstream/test/clojure/core_test/subs.cljc','scripts/clojure_test_suite.py']:
 payload['reference/'+n]=(r/n).read_bytes()
payload['uncommitted-temporary-gate.patch']=subprocess.check_output(['git','diff','8fda18a','--','crates/suss-compile/tests/clojure_test_suite.rs'],cwd=r)
# Confirm every original compiler/core/artifact source path equals committed baseline.
changed=subprocess.check_output(['git','diff','--name-only','8fda18a'],cwd=r,text=True).splitlines();assert changed==['crates/suss-compile/tests/clojure_test_suite.rs'],changed
report={'base':'8fda18a','suite':'95d4a9112cfc5fe6629be3d14bb99080ea00af2f','freeze_count':len(s['freeze']),'fingerprints':checks,'outcome':'count19 host-pass in complete ordered subset; subs namespace failed Unresolved Runtime name subs at bytes228..2414, all30 subs assertions unexecuted. Combined49 IDs not complete. Zero guest-judged, assertion mismatches and skips; one namespace failure. Strict temporary gate failed and is NOT committed or an accepted conformance gate.','source':'Both complete original namespace byte sequences equal generated sources before existing namespace routing. Executed Rust assertions also check exact body suffix after routing. Original/generated/routed source bytes retained. No production, bootstrap, fixture-body or comparator changes. No workarounds.','harness_budget':'Existing Harness OPERATION_FUEL200000000 and decode budget unchanged; no default macro-fuel acceptance claim.','support_inputs_capture':'Supporting fingerprint/reference inputs captured after execution, not independently frozen beforehand. Source and artifacts checked unchanged.','limits':'No full baseline, final CI or new production optimization. Subs semantics were never executed, so no subs conformance claim. Main controls any later checked-String candidate and references this before result separately.'}
payload['audit.json']=json.dumps(report,indent=2).encode()
manifest={f:hashlib.sha256(b).hexdigest() for f,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode();out=r/'docs/roadmap/evidence/m4-count-subs-8fda-baseline-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f,b in sorted(payload.items()):
  info=tarfile.TarInfo(f);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:assert all(hashlib.sha256(t.extractfile(f).read()).hexdigest()==h for f,h in manifest.items())
result={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'freeze_count':len(s['freeze']),'fingerprints':checks};(c/'count-subs-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
