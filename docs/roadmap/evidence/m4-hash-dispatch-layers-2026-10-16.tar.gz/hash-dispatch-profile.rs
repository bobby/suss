use suss_compile::{portable_macro_data::FormBridge, portable_session::Session};
#[test]
fn profile_cached_identifier_hash_layers() {
    let mut session = Session::new_macro().unwrap();
    let bridge = FormBridge::new(&mut session).unwrap();
    for keyword in [false, true] {
        let input = bridge.identifier(&mut session, Some("profile"), "sample", keyword, None).unwrap();
        for (label, source) in [
            ("identity", "(fn [x] x)"),
            ("memo-read", "(fn [x] (.-_hash x))"),
            ("implements", "(fn [x] (implements? suss.core/IHash x))"),
            ("ihash", "(fn [x] (suss.core/-hash x))"),
            ("hash", "(fn [x] (suss.core/hash x))"),
        ] {
            let function = session.eval(source).unwrap();
            let value = session.invoke(&function, &[&input]).unwrap();
            let remaining = session.inspect(&value, |store, _| store.get_fuel()).unwrap();
            eprintln!("cached-hash-layer keyword={keyword} layer={label} consumed={} remaining={remaining}", 10_000_000u64-remaining);
        }
    }
}
