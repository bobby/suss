from pathlib import Path
import json,hashlib,tarfile,io
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');run=cache/'native-selection-snapshot-candidate'
state=json.loads((run/'receipt.json').read_text());assert state['current'] is None,'Do not package a live cohort'
assert state['final_changed']==[]
files={};tuples={};sha=lambda b:hashlib.sha256(b).hexdigest()
for label in ['before','after-bootstrap']:
 frozen=json.loads((run/(label+'-freeze.json')).read_text());tuples[label]=frozen
 for rel,digest in frozen.items():
  data=(run/label/rel).read_bytes();assert sha(data)==digest
  files['inputs/'+digest]=data
for directory in ['native-selection-snapshot-candidate','native-selection-snapshot-foundation','global-routing-parent']:
 base=cache/directory
 for path in base.rglob('*'):
  if path.is_file() and path.name not in ['layout','layout.rs'] and (directory!='native-selection-snapshot-candidate' or path.relative_to(base).parts[0] not in ['before','after-bootstrap']):
   files['runs/'+directory+'/'+str(path.relative_to(base))]=path.read_bytes()
for name in ['run-native-selection-snapshot-candidate.py','run-native-selection-snapshot-foundation.py','native-selection-snapshot-command-plan.json','implement-bootstrap-selection.py','compare-native-selection-snapshot-map.py','package-native-selection-snapshot.py']:
 files['commands/'+name]=(cache/name).read_bytes()
manifest={'parent':'c10c037dd9d8dd3d478d27c064659ac9f1d232db','scope':'Copyable bootstrap operation selection and adaptive exact-reference snapshot indexes; all raw failures preserved. Full workspace baseline and final-head CI not established by this archive. Custom30M compiler probe is diagnostics only, no user program execution.','input_storage':'Each tuple path/digest maps to exact bytes in inputs/<digest>. Duplicate bytes stored once.','parent_probe':'Routing fixture records actual compiled c10 public-API execution; retains source, compiler receipts, failed private-API source and executable/hash. This does not execute guest programs.','tuples':tuples,'payloads':{p:sha(b) for p,b in sorted(files.items())}}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=root/'docs/roadmap/evidence/m4-bootstrap-selection-snapshot-indexes-2026-10-17.tar.gz'
with tarfile.open(out,'w:gz') as archive:
 for name,data in sorted(files.items()):
  item=tarfile.TarInfo(name);item.size=len(data);archive.addfile(item,io.BytesIO(data))
with tarfile.open(out) as archive:
 for name,digest in manifest['payloads'].items():assert sha(archive.extractfile(name).read())==digest
result={'path':str(out),'sha256':sha(out.read_bytes()),'payloads':len(files),'bytes':out.stat().st_size}
(cache/'native-selection-snapshot-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
