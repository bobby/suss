from pathlib import Path
root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots')
p=root/'crates/suss-compile/src/portable/resolve.rs';s=p.read_text()
marker='#[derive(Debug, Clone, PartialEq, Eq)]\npub enum Binding {'
assert marker in s
selection='''/// Bootstrap syntax dispatch needs an operation, not a retained live-cell key.
/// Name selection still performs the existing qualification/shadow checks.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum BootstrapSelection {
    Control(ControlForm), Bitwise(Bitwise), Comparison(Comparison), Array(ArrayOperation),
    Let, Loop, Fn, Defonce, Binding, Nominal(NominalForm),
}
impl BootstrapSelection {
    fn from_name(name: &str) -> Self {
        if let Some(operation) = ControlForm::from_name(name) {
            Self::Control(operation)
        } else if let Some(operation) = Bitwise::from_name(name) {
            Self::Bitwise(operation)
        } else if let Some(operation) = match name {
            "<" => Some(Comparison::Less), "<=" => Some(Comparison::LessEqual),
            ">" => Some(Comparison::Greater), ">=" => Some(Comparison::GreaterEqual),
            "==" => Some(Comparison::StrictEqual), _ => None,
        } { Self::Comparison(operation) }
        else if let Some(operation) = match name {
            "array" => Some(ArrayOperation::Literal), "make-array" => Some(ArrayOperation::Make),
            "alength" => Some(ArrayOperation::Length), "aget" => Some(ArrayOperation::Get),
            "aset" => Some(ArrayOperation::Set), _ => None,
        } { Self::Array(operation) }
        else {
            match name {
                "let" => Self::Let, "loop" => Self::Loop, "fn" => Self::Fn,
                "defonce" => Self::Defonce, "binding" | "with-redefs" => Self::Binding,
                _ => Self::Nominal(match name {
                    "deftype" => NominalForm::Deftype, "deftype*" => NominalForm::DeftypeInternal,
                    "defrecord*" => NominalForm::DefrecordInternal, "defprotocol" => NominalForm::Defprotocol,
                    "instance?" => NominalForm::Instance, "satisfies?" => NominalForm::Satisfies,
                    "implements?" => NominalForm::Implements, _ => NominalForm::ExtendType,
                }),
            }
        }
    }
    pub(crate) fn from_binding(binding: &Binding) -> Option<Self> {
        Some(match binding {
            Binding::BootstrapControl { operation, .. } => Self::Control(*operation),
            Binding::BootstrapBitwise { operation, .. } => Self::Bitwise(*operation),
            Binding::BootstrapComparison { operation, .. } => Self::Comparison(*operation),
            Binding::BootstrapArray { operation, .. } => Self::Array(*operation),
            Binding::BootstrapLet(_) => Self::Let, Binding::BootstrapLoop(_) => Self::Loop,
            Binding::BootstrapFn(_) => Self::Fn, Binding::BootstrapDefonce(_) => Self::Defonce,
            Binding::BootstrapBinding(_) => Self::Binding,
            Binding::Nominal { form, .. } => Self::Nominal(*form),
            _ => return None,
        })
    }
    fn with_global(self, global: Global) -> Binding {
        match self {
            Self::Control(operation) => Binding::BootstrapControl { global, operation },
            Self::Bitwise(operation) => Binding::BootstrapBitwise { global, operation },
            Self::Comparison(operation) => Binding::BootstrapComparison { global, operation },
            Self::Array(operation) => Binding::BootstrapArray { global, operation },
            Self::Let => Binding::BootstrapLet(global), Self::Loop => Binding::BootstrapLoop(global),
            Self::Fn => Binding::BootstrapFn(global), Self::Defonce => Binding::BootstrapDefonce(global),
            Self::Binding => Binding::BootstrapBinding(global), Self::Nominal(form) => Binding::Nominal { global, form },
        }
    }
}
'''
s=s.replace(marker,selection+marker,1)
start=s.index('        // Preserve the original bootstrap VARIANT, independent of live Binding.')
end=s.index('\n    pub fn resolve(',start)
s=s[:start]+'''        // Public callers requesting a Binding still receive its charged owner.
        Ok(Some(BootstrapSelection::from_name(name).with_global(global)))
    }
    pub(crate) fn bootstrap_selection(&self, phase: Phase, symbol: &Symbol) -> Option<BootstrapSelection> {
        self.selected_bootstrap_name(phase, symbol).map(BootstrapSelection::from_name)
    }
'''+s[end:]
p.write_text(s)
p=root/'crates/suss-compile/src/portable/hir.rs';s=p.read_text()
s=s.replace('resolve::{Binding as ResolvedBinding, Environment, Global, Phase}', 'resolve::{Binding as ResolvedBinding, BootstrapSelection, Environment, Global, Phase}',1)
old='''match self.environment.resolve_bootstrap_macro_metered(self.phase, symbol,
                            &mut |work| self.expander.charge_expansion_work(work, form.span.clone()))? {
                            Some(ResolvedBinding::BootstrapLet(_)) => Some("let*"),
                            Some(ResolvedBinding::BootstrapLoop(_)) => Some("loop*"),'''
new='''match self.environment.bootstrap_selection(self.phase, symbol) {
                            Some(BootstrapSelection::Let) => Some("let*"),
                            Some(BootstrapSelection::Loop) => Some("loop*"),'''
assert old in s;s=s.replace(old,new,1)
start=s.index('        let resolved = if bare',s.index('// Only true special forms bypass'))
end=s.index('        if bare && symbol.name == "set!"',start)
s=s[:start]+'''        let (selected, resolved) = if bare
            && matches!(
                symbol.name.as_str(),
                "if" | "do" | "fn*" | "def" | "let*" | "loop*" | "recur" | "throw" | "try" | "set!"
            ) {
            (None, None)
        } else {
            if bare
                && (self.locals.contains_key(&symbol.name)
                    || self.fields.contains_key(&symbol.name))
            {
                return self.call(form, items);
            }
            if let Some(selected) = self.environment.bootstrap_selection(self.phase, symbol) {
                (Some(selected), None)
            } else {
                (None, Some(self.environment.resolve(self.phase, symbol, items[0].span.clone())?))
            }
        };
        // Ordinary resolution can also yield a bootstrap/nominal binding (for
        // example reify). Keep that fallback and its errors unchanged.
        let bootstrap = selected.or_else(|| resolved.as_ref().and_then(BootstrapSelection::from_binding));
        if let Some(BootstrapSelection::Control(operation)) = bootstrap {
            return self.control_form(form, args, operation, context, tail);
        }
        if let Some(BootstrapSelection::Bitwise(operation)) = bootstrap {
            return self.bitwise_form(form, args, operation);
        }
        if let Some(BootstrapSelection::Comparison(operation)) = bootstrap {
            return self.comparison_form(form, args, operation);
        }
        if let Some(BootstrapSelection::Array(operation)) = bootstrap {
            return self.array_form(form, args, operation);
        }
        if let Some(BootstrapSelection::Nominal(nominal_form)) = bootstrap {
            return self.nominal_form(form, args, nominal_form);
        }
'''+s[end:]
s=s.replace('matches!(resolved, Some(ResolvedBinding::BootstrapBinding(_)))','matches!(bootstrap, Some(BootstrapSelection::Binding))')
s=s.replace('matches!(resolved, Some(ResolvedBinding::BootstrapDefonce(_)))','matches!(bootstrap, Some(BootstrapSelection::Defonce))')
s=s.replace('matches!(resolved, Some(ResolvedBinding::BootstrapFn(_)))','matches!(bootstrap, Some(BootstrapSelection::Fn))')
p.write_text(s)
