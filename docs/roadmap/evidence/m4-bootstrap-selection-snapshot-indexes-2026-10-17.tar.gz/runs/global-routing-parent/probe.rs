const NAMES: &[&str] = &["->", "<", "<=", "==", ">", ">=", "aget", "alength", "and", "array", "as->", "aset", "binding", "bit-and", "bit-and-not", "bit-clear", "bit-flip", "bit-not", "bit-or", "bit-set", "bit-shift-left", "bit-shift-right", "bit-shift-right-zero-fill", "bit-test", "bit-xor", "caching-hash", "case", "cond", "dec", "declare", "defonce", "defprotocol", "defrecord*", "deftype", "deftype*", "extend-type", "fn", "if-let", "if-not", "implements?", "inc", "instance?", "int", "let", "loop", "make-array", "neg?", "or", "pos?", "satisfies?", "unsigned-bit-shift-right", "when", "when-not", "with-redefs", "zero?"];
use suss_compile::portable::resolve::{Environment, Phase};
use suss_reader::Symbol;
fn main() {
    for phase in [Phase::Runtime, Phase::Macro] {
        for name in NAMES {
            let base = Environment::new("routing.probe").unwrap();
            for scenario in ["bare", "qualified", "alias", "shadowed", "excluded", "redefined", "referred", "restored"] {
                let mut env = base.clone();
                let symbol = match scenario {
                    "qualified" => Symbol::namespaced("cljs.core", *name),
                    "alias" => { env.alias(phase, "corealias", "cljs.core").unwrap(); Symbol::namespaced("corealias", *name) },
                    "shadowed" => { env.declare_cell(phase, "routing.probe", name).unwrap(); Symbol::new(*name) },
                    "excluded" => { env.exclude_core(phase, name).unwrap(); Symbol::new(*name) },
                    "redefined" => { env.declare_cell(phase, "suss.core", name).unwrap(); Symbol::namespaced("cljs.core", *name) },
                    "referred" => { if env.resolve(phase, &Symbol::namespaced("suss.core", *name), 0..0).is_err() { env.declare_cell(phase, "suss.core", name).unwrap(); }
                        env.refer(phase, "renamed", "suss.core", name).unwrap(); Symbol::new("renamed") },
                    "restored" => { let prior = env.clone(); let global = env.declare_cell(phase, "suss.core", name).unwrap();
                        env.restore_declarations(&prior, &[global], phase); Symbol::namespaced("cljs.core", *name) },
                    _ => Symbol::new(*name),
                };
                println!("{phase:?}\t{scenario}\t{name}\t{:?}", env.resolve_bootstrap_macro(phase, &symbol));
            }
        }
    }
}
