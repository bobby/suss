//! Private post-provision observations of canonical IHash installations.
//! This is not source-data certification and issues no memo receipts.
use super::{Session, SessionError, SessionValue, call, own, storage_snapshot::StorageSnapshot};
use crate::portable::bootstrap;
use std::sync::{Arc, atomic::AtomicUsize};
use wasmtime::{AnyRef, RootScope, Rooted, Val};

type Result<T> = std::result::Result<T, SessionError>;

struct Method {
    owner: &'static str,
    slot: usize,
    descriptor: SessionValue,
    implementation: SessionValue,
    schema: StorageSnapshot,
    closure: StorageSnapshot,
}

pub(super) struct CanonicalMethods {
    methods: Vec<Method>,
    key: SessionValue,
    key_storage: StorageSnapshot,
    // Internal roots must not inflate the public external-value-handle count.
    handles: Arc<AtomicUsize>,
}

fn invalid(message: &'static str) -> SessionError {
    SessionError::Host(wasmtime::Error::msg(message))
}

fn binding(
    session: &mut Session,
    namespace: &str,
    name: &str,
    handles: &Arc<AtomicUsize>,
) -> Result<SessionValue> {
    session.charge_host_work(
        session.cells.len() as u64 + namespace.len() as u64 + name.len() as u64 + 3,
    )?;
    let global = session
        .cells
        .iter()
        .find(|(identity, _)| {
            identity.phase() == session.phase
                && identity.namespace() == namespace
                && identity.name() == name
        })
        .map(|(_, value)| *value)
        .ok_or_else(|| invalid("Missing canonical method binding"))?;
    let mut scope = RootScope::new(&mut session.store);
    let cell = global
        .get(&mut scope)
        .unwrap_anyref()
        .ok_or_else(|| invalid("Null canonical binding cell"))?
        .as_struct(&scope)?
        .ok_or_else(|| invalid("Invalid canonical binding cell"))?;
    if cell.field(&mut scope, 1)?.unwrap_i32() == 0 {
        return Err(invalid("Unbound canonical method binding"));
    }
    let value = cell.field(&mut scope, 0)?;
    own(&mut scope, value, session.identity, handles)
}

fn runtime(
    session: &mut Session,
    name: &str,
    arguments: &[&SessionValue],
    handles: &Arc<AtomicUsize>,
) -> Result<SessionValue> {
    session.charge_host_work(arguments.len() as u64 + 1)?;
    for argument in arguments {
        session.check(argument)?;
    }
    let mut scope = RootScope::new(&mut session.store);
    let arguments: Vec<_> = arguments
        .iter()
        .map(|value| Val::AnyRef(Some(value.value.to_rooted(&mut scope))))
        .collect();
    let function = session
        .runtime
        .get_func(&mut scope, name)
        .ok_or_else(|| invalid("Missing canonical method adapter"))?;
    call(
        &mut scope,
        session.runtime,
        function,
        &arguments,
        session.identity,
        handles,
    )
}

fn schema(
    session: &mut Session,
    descriptor: &SessionValue,
    slot: usize,
    handles: &Arc<AtomicUsize>,
) -> Result<SessionValue> {
    session.check(descriptor)?;
    session.charge_host_work(12)?;
    let mut scope = RootScope::new(&mut session.store);
    let descriptor = descriptor
        .value
        .to_rooted(&mut scope)
        .as_struct(&scope)?
        .ok_or_else(|| invalid("Invalid canonical class descriptor"))?;
    let value = descriptor.field(&mut scope, 1)?;
    let fields = value
        .unwrap_anyref()
        .ok_or_else(|| invalid("Null canonical schema"))?
        .as_array(&scope)?
        .ok_or_else(|| invalid("Invalid canonical schema"))?;
    if slot >= fields.len(&scope)? as usize {
        return Err(invalid("Canonical memo slot is outside its schema"));
    }
    let name = fields.get(&mut scope, slot as u32)?;
    let name = name
        .unwrap_anyref()
        .ok_or_else(|| invalid("Null canonical memo field name"))?
        .as_array(&scope)?
        .ok_or_else(|| invalid("Invalid canonical memo field name"))?;
    if !matches!(name.len(&scope)?, 5 | 6) {
        return Err(invalid("Wrong canonical memo field name"));
    }
    let units: Vec<_> = name
        .elems(&mut scope)?
        .map(|unit| match unit {
            Val::I32(unit) if (0..=u16::MAX as i32).contains(&unit) => Ok(unit as u16),
            _ => Err(invalid("Invalid canonical memo field code unit")),
        })
        .collect::<Result<_>>()?;
    if units != "__hash".encode_utf16().collect::<Vec<_>>()
        && units != "_hash".encode_utf16().collect::<Vec<_>>()
    {
        return Err(invalid("Wrong canonical memo field name"));
    }
    own(&mut scope, value, session.identity, handles)
}

fn same(session: &mut Session, left: &SessionValue, right: &SessionValue) -> Result<bool> {
    session.check(left)?;
    session.check(right)?;
    session.charge_host_work(1)?;
    let mut scope = RootScope::new(&mut session.store);
    let left = left.value.to_rooted(&mut scope);
    let right = right.value.to_rooted(&mut scope);
    Rooted::<AnyRef>::ref_eq(&scope, &left, &right).map_err(Into::into)
}

impl CanonicalMethods {
    // Called only inside the authorized provisioning interval. Never refresh
    // this registry by reading mutable globals after returning a Session.
    pub(super) fn capture(
        session: &mut Session,
        authority: &bootstrap::IntegrityAuthority,
    ) -> Result<Self> {
        if session.bootstrap_core || session.canonical_methods.is_some() {
            return Err(invalid(
                "Canonical methods can only be captured during initial provisioning",
            ));
        }
        Self::capture_accounted(
            session,
            authority,
            Arc::new(AtomicUsize::new(0)),
            #[cfg(test)]
            None,
        )
    }

    fn capture_accounted(
        session: &mut Session,
        authority: &bootstrap::IntegrityAuthority,
        handles: Arc<AtomicUsize>,
        #[cfg(test)] interrupt_after: Option<usize>,
    ) -> Result<Self> {
        if !std::ptr::eq(
            authority,
            bootstrap::shipped_authority(session.phase).map_err(SessionError::Compile)?,
        ) {
            return Err(invalid(
                "Canonical method capture needs this phase's shipped authority",
            ));
        }
        let _request = session.operation_budget_scope()?;
        let key_name = format!(
            "key-{}",
            "suss.core/IHash/-hash/1"
                .as_bytes()
                .iter()
                .map(|byte| format!("{byte:02x}"))
                .collect::<String>()
        );
        let key = binding(session, "suss.internal.protocol-keys", &key_name, &handles)?;
        let key_storage = session.capture_storage_accounted(&key, handles.clone())?;
        let mut methods = Vec::new();
        for (owner, slot) in bootstrap::memo_owner_slots() {
            session.charge_host_work(1)?;
            let class = binding(session, "suss.core", owner, &handles)?;
            let descriptor = runtime(session, "constructor-descriptor", &[&class], &handles)?;
            // Preserve the runtime's descriptor/schema validity checks.
            runtime(
                session,
                "nominal-source-constructor-plan",
                &[&descriptor],
                &handles,
            )?;
            let implementation = runtime(
                session,
                "protocol-method-get",
                &[&descriptor, &key],
                &handles,
            )?;
            runtime(session, "closure-environment", &[&implementation], &handles)?;
            let fields = schema(session, &descriptor, slot, &handles)?;
            let schema = session.capture_storage_accounted(&fields, handles.clone())?;
            let closure = session.capture_storage_accounted(&implementation, handles.clone())?;
            methods.push(Method {
                owner,
                slot,
                descriptor,
                implementation,
                schema,
                closure,
            });
            #[cfg(test)]
            if interrupt_after == Some(methods.len()) {
                session
                    .interrupt
                    .store(true, std::sync::atomic::Ordering::SeqCst);
                session.charge_host_work(0)?;
            }
        }
        session.charge_host_work(0)?;
        Ok(Self {
            methods,
            key,
            key_storage,
            handles,
        })
    }

    /// Installation eligibility only. Actual source storage and authenticated
    /// memo writes still require their separate checks before candidate reuse.
    pub(super) fn matches(
        &self,
        session: &mut Session,
        owner: &str,
        descriptor: &SessionValue,
    ) -> Result<bool> {
        session.check(descriptor)?;
        let _request = session.operation_budget_scope()?;
        session.charge_host_work(self.methods.len() as u64)?;
        let Some(method) = self.methods.iter().find(|method| method.owner == owner) else {
            return Ok(false);
        };
        if !same(session, descriptor, &method.descriptor)? {
            return Ok(false);
        }
        if !session.storage_matches(&self.key, &self.key_storage)? {
            return Ok(false);
        }
        let current = runtime(
            session,
            "protocol-method-get",
            &[descriptor, &self.key],
            &self.handles,
        )?;
        if !same(session, &current, &method.implementation)? {
            return Ok(false);
        }
        if !session.storage_matches(&current, &method.closure)? {
            return Ok(false);
        }
        let fields = schema(session, descriptor, method.slot, &self.handles)?;
        session.storage_matches(&fields, &method.schema)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::portable::resolve::Phase;

    fn session(phase: Phase) -> Session {
        match phase {
            Phase::Runtime => Session::new_repl().unwrap(),
            Phase::Macro => Session::new_macro().unwrap(),
        }
    }

    #[test]
    fn canonical_methods_capture_actual_installations_without_external_handles() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = session(phase);
            assert_eq!(session.stats().external_value_handles, 0);
            let methods = session.canonical_methods.clone().unwrap();
            assert_eq!(methods.methods.len(), 25);
            session.collect().unwrap();
            session
                .with_operation_budget(|session| {
                    for method in &methods.methods {
                        assert!(methods.matches(session, method.owner, &method.descriptor)?);
                    }
                    Ok(())
                })
                .unwrap();
            assert_eq!(session.stats().external_value_handles, 0);
            let descriptor = methods
                .methods
                .iter()
                .find(|method| method.owner == "List")
                .unwrap()
                .descriptor
                .clone();
            session
                .eval("(extend-type List ICounted (-count [_] 73))")
                .unwrap();
            session.collect().unwrap();
            assert!(
                methods.matches(&mut session, "List", &descriptor).unwrap(),
                "unrelated protocol stays live"
            );
            session
                .eval("(ns suss.core) (def registry-saved-list List) (def List nil)")
                .unwrap();
            assert!(
                methods.matches(&mut session, "List", &descriptor).unwrap(),
                "rebinding globals does not redirect captured identity"
            );
            session.eval("(def List registry-saved-list) (def registry-saved-hash hash-ordered-coll) (def hash-ordered-coll (fn [_] 711))").unwrap();
            session.enter_namespace("user").unwrap();
            let hash = session.eval("(hash (list 1))").unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &hash).unwrap(),
                "711"
            );
            drop(hash);
            assert!(
                methods.matches(&mut session, "List", &descriptor).unwrap(),
                "live hash helper remains ordinary dispatch"
            );
            session
                .eval("(extend-type List IHash (-hash [_] 91))")
                .unwrap();
            session.collect().unwrap();
            assert!(!methods.matches(&mut session, "List", &descriptor).unwrap());
            assert!(
                CanonicalMethods::capture(
                    &mut session,
                    bootstrap::shipped_authority(phase).unwrap()
                )
                .is_err(),
                "late capture must not refresh replaced methods"
            );
            session.eval("(ns suss.core) (def List nil)").unwrap();
            assert!(
                !methods.matches(&mut session, "List", &descriptor).unwrap(),
                "mutable globals cannot refresh authority"
            );
            assert_eq!(session.stats().external_value_handles, 0);
        }
    }

    #[test]
    fn canonical_methods_partial_capture_failure_releases_roots_and_keeps_registry() {
        use std::sync::atomic::Ordering;
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = session(phase);
            let original = session.canonical_methods.clone().unwrap();
            let pending = Arc::new(AtomicUsize::new(0));
            let authority = bootstrap::shipped_authority(phase).unwrap();
            let error = CanonicalMethods::capture_accounted(
                &mut session,
                authority,
                pending.clone(),
                Some(3),
            )
            .err()
            .expect("injected cancellation after three captures");
            assert!(
                matches!(error, SessionError::Trap(error) if matches!(error.downcast_ref::<wasmtime::Trap>(), Some(wasmtime::Trap::Interrupt)))
            );
            assert_eq!(pending.load(Ordering::SeqCst), 0);
            assert!(Arc::ptr_eq(
                &original,
                session.canonical_methods.as_ref().unwrap()
            ));
            session.with_operation_budget(|session| {
                session.store.set_fuel(0)?;
                let error = CanonicalMethods::capture_accounted(session, authority, pending.clone(), None).err().expect("actual exhausted budget");
                assert!(matches!(error, SessionError::Trap(error) if matches!(error.downcast_ref::<wasmtime::Trap>(), Some(wasmtime::Trap::OutOfFuel))));
                Ok(())
            }).unwrap();
            assert_eq!(pending.load(Ordering::SeqCst), 0);
            let value = session.eval("42").unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &value).unwrap(),
                "42"
            );
            drop(value);
            assert_eq!(session.stats().external_value_handles, 0);
        }
    }

    #[test]
    fn canonical_methods_key_mutation_and_reset_do_not_refresh_old_roots() {
        use std::sync::atomic::Ordering;
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = session(phase);
            let methods = session.canonical_methods.clone().unwrap();
            let handles = methods.handles.clone();
            let descriptor = methods.methods[0].descriptor.clone();
            let owner = methods.methods[0].owner;
            let nil = session.eval("nil").unwrap();
            session
                .inspect(&methods.key, |mut store, value| {
                    let descriptor = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                    let schema = descriptor
                        .field(&mut store, 1)?
                        .unwrap_anyref()
                        .unwrap()
                        .as_array(&store)?
                        .unwrap();
                    assert!(schema.len(&store)? > 0);
                    let nil = nil.value.to_rooted(&mut store);
                    schema.set(&mut store, 0, Val::AnyRef(Some(nil)))
                })
                .unwrap();
            drop(nil);
            session.collect().unwrap();
            assert!(!methods.matches(&mut session, owner, &descriptor).unwrap());
            session.reset().unwrap();
            let fresh = session.canonical_methods.clone().unwrap();
            assert!(!Arc::ptr_eq(&methods, &fresh));
            assert!(matches!(
                fresh.matches(&mut session, owner, &descriptor),
                Err(SessionError::ForeignValue)
            ));
            drop(descriptor);
            drop(methods);
            assert_eq!(handles.load(Ordering::SeqCst), 0);
            assert_eq!(session.stats().external_value_handles, 0);
        }
    }
}
