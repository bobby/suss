# PR256 d38 workspace baseline

Exact source `d38b59cb1cbaff0def4aad257c79e4f28ebe339a`. Command: `cargo test --workspace --locked -- --test-threads=2`. Receipt exit 101, duration 3299.7533997220453 seconds; Cargo and driver exited. Original 3526 frozen files match exact Git blobs; receipt changed[] confirms closure. No live worktree hashes substituted.

Completed-harness counts: {"pass": 86, "fail": 2, "ignored": 0}. 17 completed harnesses. Integration targets: 14 executed, 14 completed, 0 started unfinished, 237 unexecuted of actual251. Doctests separately: {"counts": {"pass": 0, "fail": 0, "ignored": 0}, "completed": 0, "not_reached": "No inferred doctest pass when Cargo stops before doctest stages."}. Full per-test names/status, harness summaries and failure stage/span bodies are in terminal-classification.json.

This packet contains only this baseline tuple; no prior focus/control/CI totals merged. Full-baseline success is claimed only if actual exit0 and no raw failures. Unknown later coverage stays unexecuted. Source evidence uses published d38 objects; root may mutate its worktree after completion.
