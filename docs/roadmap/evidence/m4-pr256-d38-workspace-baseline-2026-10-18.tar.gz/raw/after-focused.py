from pathlib import Path
import json,time,subprocess as s,os
p=Path(__file__).parent;prior=Path('/home/bobby/.cache/suss-m4-work/pr256-compact-heads-validation/receipt.json')
parent_pid=1135093
while True:
 r=json.loads(prior.read_text())
 if r['terminal']:
  assert r['current'] is None
  break
 try:os.kill(parent_pid,0)
 except ProcessLookupError:
  r=json.loads(prior.read_text())
  assert r['terminal'],'Focused driver missing without terminal receipt; inspect before proceeding'
  break
 time.sleep(2)
print('Focused driver terminal; starting exact full workspace baseline.',flush=True)
raise SystemExit(s.call(['python3',str(p/'run.py')]))
