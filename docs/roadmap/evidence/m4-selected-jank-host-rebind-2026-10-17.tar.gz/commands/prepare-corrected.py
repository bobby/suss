import pathlib,json,hashlib,subprocess,shutil,concurrent.futures,difflib
base=pathlib.Path('/home/bobby/.cache/suss-m4-work');old=base/'original-m4-16-19-acceptance-audit';out=base/'m4-selected-jank-76a-rebind-review';out.mkdir(exist_ok=True)
repo=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-when-let-baseline-reconcile');commit='1a85c8dbd8a5affac85e6091b0fa30782a75e985';capture=base/'when-let-reconcile-after'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
def blob(c,p):return subprocess.check_output(['git','-C',str(repo),'show',c+':'+p])
m=json.loads((old/'comparison-source-manifest.json').read_bytes());changed=[]
for p,expected in m['files'].items():
 b=blob(commit,p);dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 if sha(b)!=expected:
  previous=(old/'source'/p).read_bytes();assert sha(previous)==expected
  changed.append({'path':p,'old_sha256':expected,'new_sha256':sha(b)})
  d=out/'diffs'/(p.replace('/','__')+'.diff');d.parent.mkdir(exist_ok=True);d.write_text(''.join(difflib.unified_diff(previous.decode().splitlines(True),b.decode().splitlines(True),fromfile='d311/'+p,tofile='1a85/'+p)))
 m['files'][p]=sha(b)
m['audited_commit']=commit;dump(out/'comparison-source-manifest.json',m)
for name in ['pinned-jank-selection.json','pre-hardening/source-manifest.json']:
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/name,p)
binding=json.loads((old/'comparison-binding.json').read_bytes());binding['source_manifest_sha256']=sha((out/'comparison-source-manifest.json').read_bytes());dump(out/'comparison-binding.json',binding)
helper=(old/'compare-selected-jank.py').read_text();oldpin=sha((old/'comparison-binding.json').read_bytes());newpin=sha((out/'comparison-binding.json').read_bytes());assert helper.count(oldpin)==1
newhelper=helper.replace(oldpin,newpin);(out/'compare-selected-jank.py').write_text(newhelper)
(out/'helper.diff').write_text(''.join(difflib.unified_diff(helper.splitlines(True),newhelper.splitlines(True),fromfile='approved-helper',tofile='rebound-helper')))
for name in ['suite-observations.json','receipt.json','before-freeze.json','after-freeze.json','candidate.patch']:
 p=out/'producer'/name;p.parent.mkdir(exist_ok=True);shutil.copyfile(capture/name,p)
freeze=json.loads((capture/'before-freeze.json').read_bytes());assert len(freeze)==1846;assert freeze==json.loads((capture/'after-freeze.json').read_bytes())
def verify(item):
 p,h=item;b=(capture/'before'/p).read_bytes();assert sha(b)==h,(p,'snapshot');assert sha(blob(commit,p))==h,(p,'commit');return p
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:verified=list(pool.map(verify,freeze.items()))
aliases={}
for c in ['76a79718843741ead53f9432a2407cbcc4913c65','69dcc2fc4379c5b5d9980e63247f2d489159f8d3']:
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  ok=list(pool.map(lambda item:sha(blob(c,item[0]))==item[1],freeze.items()))
 assert all(ok);aliases[c]=len(ok)
# All harness differences are confined to supplemental tests: the whole-suite
# capture runner and Harness implementation occur before the first changed test.
p='crates/suss-compile/tests/clojure_test_suite.rs';a=(old/'source'/p).read_bytes();b=blob(commit,p)
marker=b'#[test]\nfn pinned_map_declaration_executes_without_transport_loss'
assert marker in a
prefix=b''.join(a.splitlines(keepends=True)[:762]);assert b.startswith(prefix)
dump(out/'rebind-proof.json',{'schema':1,'audited_commit':commit,'source_files':len(m['files']),'changed_manifest_files':changed,'helper_only_change':'BINDING_SHA256 literal','old_helper_sha256':sha(helper.encode()),'new_helper_sha256':sha(newhelper.encode()),'old_binding_sha256':oldpin,'new_binding_sha256':newpin,'selection_unchanged':True,'groups_unchanged':binding['groups']==json.loads((old/'comparison-binding.json').read_bytes())['groups'],'whole_suite_harness_prefix_bytes_unchanged':len(prefix),'producer_inputs_verified_snapshot_and_commit':len(verified),'source_identical_commits':aliases,'producer_payload_sha256':{n:sha((out/'producer'/n).read_bytes()) for n in ['suite-observations.json','receipt.json','before-freeze.json','after-freeze.json','candidate.patch']},'execution':'NOT INVOKED: independent Carver review required','old_invalid_result':str(base/'m4-acceptance-execution-audit-2026-10-17/selected-jank-76a/summary.json')})
print(json.dumps({'directory':str(out),'changed':changed,'verified':len(verified),'prefix_bytes':len(prefix),'binding':newpin},indent=2))
