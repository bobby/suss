from pathlib import Path
import json,hashlib,difflib
p=Path('/home/bobby/.cache/suss-m4-work/m4-selected-jank-76a-rebind-review')
def sha(b):return hashlib.sha256(b).hexdigest()
(p/'preparation-failure.txt').write_text('Initial preparation assertion failed: prefix included the changed supplemental-test documentation preceding pinned_map_declaration. No comparator was invoked. Corrected proof uses the exact unchanged first 762 lines, 31689 bytes; full diff retained. Initial builder preserved at ../prepare-selected-rebind.first.py.\n')
files={str(x.relative_to(p)):sha(x.read_bytes()) for x in sorted(p.rglob('*')) if x.is_file()}
raw=(json.dumps({'schema':1,'files':files},indent=2)+'\n').encode();(p/'review-payload-manifest.json').write_bytes(raw);pin=sha(raw)
wrapper='''#!/usr/bin/env python3
"""Host-only launch gate; invoke only after independent review."""
import hashlib,json,pathlib,subprocess,sys
BUNDLE=pathlib.Path(__file__).resolve().parent
PIN=PIN_LITERAL
def digest(b):return hashlib.sha256(b).hexdigest()
def check(root):
    raw=(BUNDLE/'review-payload-manifest.json').read_bytes()
    if digest(raw)!=PIN:raise RuntimeError('review payload manifest mismatch')
    manifest=json.loads(raw)
    for name,h in manifest['files'].items():
        path=BUNDLE/name
        if not path.resolve().is_relative_to(BUNDLE):raise RuntimeError('escaping payload')
        if digest(path.read_bytes())!=h:raise RuntimeError('payload changed: '+name)
    freeze=json.loads((BUNDLE/'producer/before-freeze.json').read_bytes())
    if len(freeze)!=1846 or freeze!=json.loads((BUNDLE/'producer/after-freeze.json').read_bytes()):
        raise RuntimeError('producer freeze mismatch')
    for name,h in freeze.items():
        path=root/name
        if not path.resolve().is_relative_to(root):raise RuntimeError('escaping source')
        if digest(path.read_bytes())!=h:raise RuntimeError('producer source mismatch: '+name)
    return subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).strip()
def main():
    if len(sys.argv)!=3:raise SystemExit('usage: run-reviewed.py GIT_ROOT OUTPUT_DIRECTORY')
    root=pathlib.Path(sys.argv[1]).resolve();output=pathlib.Path(sys.argv[2]).resolve()
    if output.exists():raise RuntimeError('output must be new; preserve previous evidence')
    if output.is_relative_to(BUNDLE):raise RuntimeError('output must be outside frozen review bundle')
    head=check(root)
    result=subprocess.run([sys.executable,str(BUNDLE/'compare-selected-jank.py'),str(root),
        str(BUNDLE/'producer/suite-observations.json'),str(output)],
        env={**__import__('os').environ,'PYTHONDONTWRITEBYTECODE':'1'})
    if check(root)!=head:raise RuntimeError('checkout HEAD changed during comparison')
    raise SystemExit(result.returncode)
if __name__=='__main__':main()
'''.replace('PIN_LITERAL',repr(pin))
(p/'run-reviewed.py').write_text(wrapper)
(p/'REVIEW-REQUEST.md').write_text('''Carver independent review requested through main. Do not invoke the rebound helper before approval.

Scope: host-only rebind; no guest execution, source changes, Cargo, baseline/reference/selection changes.

Exact differences: one of 263 source-manifest files changes: crates/suss-compile/tests/clojure_test_suite.rs. The first 762 lines (31689 bytes), containing Harness, whole-suite capture/check, and existing observation tests, are identical. Supplemental pinned-map gate removed; pinned-keyword gate replaced by reader-identifier gate; when-let gate added. Full diff is in diffs/. Those supplemental gates do not participate in the unchanged whole-suite runner. All other 262 files, including comparator dependencies, pinned reference, suite lock, corpus and patches, are byte-identical. Group definitions/ordered IDs and original audit manifest remain identical. Helper code differs ONLY in the binding SHA literal (helper.diff). New manifest audited_commit is 1a85; source-manifest SHA and consequently binding SHA are rebound.

Producer correspondence: all 1846 before snapshots independently hashed and matched Git blobs at 1a85; before/after freezes identical. All 1846 hashes also match 76a and 69d commits. Historical receipt HEAD is 896 plus the retained two-file candidate.patch; do not claim receipt originally recorded 1a85. Copied exact capture, receipt, freezes and patch are bound by the launch gate. Wrapper hashes all review payloads and checks all 1846 current-root source bytes before/after invocation. Existing helper retains its independent reference/corpus/harness checks, exact ID/order, namespace outcomes/errors/skips, phase-sensitive skip multiset, guest classification and exit semantics. Wrapper does not alter judgments.

Old invalid-evidence result preserved at ../m4-acceptance-execution-audit-2026-10-17/selected-jank-76a/summary.json (harness source SHA mismatch). Preparation prefix assertion failure preserved separately; no comparison invocation occurred.

Current judgments: existing whole-suite capture reports 943 host passes, 17 guest-judged, 21 failures, 188 failed namespaces, 4873 unexecuted, zero skips. This is NOT all green. No new selected-group judgments are claimed: rebound helper NOT INVOKED. Exit 0 requires selected host acceptance; exit 2 means qualified guest/reference-skip judgments, not host pass; exit 1 failure/invalid evidence.

After approval only, intended command:
python /home/bobby/.cache/suss-m4-work/m4-selected-jank-76a-rebind-review/run-reviewed.py /home/bobby/Work/code/bobby/suss-m4-when-let-baseline-reconcile /home/bobby/.cache/suss-m4-work/m4-selected-jank-76a-reviewed-results

Please review exact diff, helper pin-only change, producer-binding wrapper and payload manifest. Prior approved helper passed 38 host adversarial checks; no new helper execution before this review.
''')
print(json.dumps({'review_request':str(p/'REVIEW-REQUEST.md'),'payload_manifest_sha256':pin,'wrapper_sha256':sha(wrapper.encode()),'payload_files':len(files),'helper_invoked':False},indent=2))
