#!/usr/bin/env python3
"""Host-only launch gate; invoke only after independent review."""
import hashlib,json,pathlib,subprocess,sys
BUNDLE=pathlib.Path(__file__).resolve().parent
PIN='b59f342d84993687ff23965d6f1507cb2ff3c5ccdbdbf033a1209ecde797b934'
def digest(b):return hashlib.sha256(b).hexdigest()
def check(root):
    raw=(BUNDLE/'review-payload-manifest.json').read_bytes()
    if digest(raw)!=PIN:raise RuntimeError('review payload manifest mismatch')
    manifest=json.loads(raw)
    for name,h in manifest['files'].items():
        path=BUNDLE/name
        if not path.resolve().is_relative_to(BUNDLE):raise RuntimeError('escaping payload')
        if digest(path.read_bytes())!=h:raise RuntimeError('payload changed: '+name)
    freeze=json.loads((BUNDLE/'producer/before-freeze.json').read_bytes())
    if len(freeze)!=1846 or freeze!=json.loads((BUNDLE/'producer/after-freeze.json').read_bytes()):
        raise RuntimeError('producer freeze mismatch')
    for name,h in freeze.items():
        path=root/name
        if not path.resolve().is_relative_to(root):raise RuntimeError('escaping source')
        if digest(path.read_bytes())!=h:raise RuntimeError('producer source mismatch: '+name)
    return subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).strip()
def main():
    if len(sys.argv)!=3:raise SystemExit('usage: run-reviewed.py GIT_ROOT OUTPUT_DIRECTORY')
    root=pathlib.Path(sys.argv[1]).resolve();output=pathlib.Path(sys.argv[2]).resolve()
    if output.exists():raise RuntimeError('output must be new; preserve previous evidence')
    if output.is_relative_to(BUNDLE):raise RuntimeError('output must be outside frozen review bundle')
    head=check(root)
    result=subprocess.run([sys.executable,str(BUNDLE/'compare-selected-jank.py'),str(root),
        str(BUNDLE/'producer/suite-observations.json'),str(output)],
        env={**__import__('os').environ,'PYTHONDONTWRITEBYTECODE':'1'})
    if check(root)!=head:raise RuntimeError('checkout HEAD changed during comparison')
    raise SystemExit(result.returncode)
if __name__=='__main__':main()
