#!/usr/bin/env python3
"""Read-only host comparison. Exit0=all selected host-verified;2=qualified guest judgments/reference skips;1=failed/invalid.
Never executes Suss or rewrites expectations. Input hashes bind the reviewed corpus,
comparator dependencies, harness and source bodies. Producer freeze/review remains
necessary: an observed JSON file does not authenticate its own execution history.
"""
import argparse
import collections
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import types

BINDING_SHA256 = '41fdfdc949058db3a92bc087711438868a22011f9956bbb4e38eed4086d3b5aa'
REQUIRED_GROUPS = {'17-sequences', '18-associative', '19-contracts'}
PIN = 'c4295f303100bbf5afac449242d30bca1126f1a1'
SUITE = '95d4a9112cfc5fe6629be3d14bb99080ea00af2f'

class InvalidEvidence(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise InvalidEvidence(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def unique(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, f'duplicate JSON key: {key}')
        out[key] = value
    return out

def load(data):
    def bad_constant(value):
        raise InvalidEvidence(f'non-JSON numeric constant: {value}')
    return json.loads(data, object_pairs_hook=unique, parse_constant=bad_constant)

def read_under(root, name):
    path = root / name
    require(path.resolve().is_relative_to(root.resolve()), f'path escapes root: {name}')
    return path.read_bytes()

def bind_inputs(root, bundle):
    raw = (bundle / 'comparison-binding.json').read_bytes()
    require(digest(raw) == BINDING_SHA256, 'binding SHA mismatch')
    binding = load(raw)
    require(binding['schema'] == 1 and binding['suite'] == SUITE and binding['upstream'] == PIN,
            'invalid binding identity')
    selection_raw = (bundle / 'pinned-jank-selection.json').read_bytes()
    manifest_raw = (bundle / 'comparison-source-manifest.json').read_bytes()
    require(digest(selection_raw) == binding['selection_sha256'], 'selection SHA mismatch')
    require(digest(manifest_raw) == binding['source_manifest_sha256'], 'source manifest SHA mismatch')
    original_raw = (bundle / 'pre-hardening/source-manifest.json').read_bytes()
    require(digest(original_raw) == binding['original_audit_manifest_sha256'], 'original audit manifest SHA mismatch')
    selection, manifest = load(selection_raw), load(manifest_raw)
    require(selection['suite'] == SUITE, 'selection suite mismatch')
    require(set(selection['groups']) == REQUIRED_GROUPS == set(binding['groups']),
            'missing/empty/unexpected selection groups')
    require(manifest['schema'] == 1 and bool(manifest['files']), 'empty/invalid source manifest')
    actual, contents = {}, {}
    for name, expected_sha in manifest['files'].items():
        data = read_under(root, name)
        actual[name] = digest(data)
        require(actual[name] == expected_sha, f'source SHA mismatch: {name}')
        contents[name] = data
    for group, spec in selection['groups'].items():
        for key, expected in binding['groups'][group].items():
            require(spec[key] == expected, f'group membership changed: {group}/{key}')
        require(spec['namespaces'] and spec['tests'] and spec['ordered_ids'], f'empty group: {group}')
        require(len(set(spec['namespaces'])) == len(spec['namespaces']), 'duplicate selected namespace')
        require(len(set(spec['tests'])) == len(spec['tests']), 'duplicate selected test')
        require(spec['assertion_count'] == len(spec['ordered_ids']), 'selection assertion count mismatch')
    reference = load(contents['tests/oracle/clojure-test-suite-observations.json'])
    require(reference['schema'] == 1 and reference['suite'] == SUITE and reference['upstream'] == PIN,
            'reference identity mismatch')
    for group, spec in selection['groups'].items():
        names, tests = spec['namespaces'], spec['tests']
        require(names == [n for n in reference['namespaces'] if n in names], 'reference namespace/order mismatch')
        require(tests == [t for t in reference['tests'] if t.split('/')[0] in names],
                'selection does not cover whole namespace test membership')
        expected = [[a['test'], a['ordinal']] for a in reference['assertions'] if a['test'] in tests]
        require(expected == spec['ordered_ids'], f'pinned assertion ID/order drift: {group}')
        for name in spec['source_files']:
            require(name in actual, f'unbound selected source: {name}')
    git = subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD'], capture_output=True, text=True)
    require(git.returncode == 0, 'source root must have a Git HEAD for provenance')
    top = subprocess.run(['git', '-C', str(root), 'rev-parse', '--show-toplevel'], capture_output=True, text=True)
    require(top.returncode == 0 and pathlib.Path(top.stdout.strip()).resolve() == root.resolve(),
            'source root must be the Git checkout root')
    return selection, reference, contents, {
        'binding_sha256': digest(raw), 'selection_sha256': digest(selection_raw),
        'source_manifest_sha256': digest(manifest_raw), 'audited_commit': manifest['audited_commit'],
        'actual_checkout_head': git.stdout.strip(), 'actual_source_sha256': actual,
        'scope': 'Verified comparison/corpus/harness files at comparison time. This is not a producer freeze or full production-source identity proof.'}

def load_comparator(contents, root):
    # Execute verified bytes directly, avoiding stale pyc or preloaded local modules.
    saved = {name: sys.modules.get(name) for name in ['oracle_transport', 'oracle_compare', 'm4_suite_comparator']}
    try:
        for name, path in [('oracle_transport', 'scripts/oracle_transport.py'),
                           ('oracle_compare', 'scripts/oracle_compare.py'),
                           ('m4_suite_comparator', 'scripts/clojure_test_suite.py')]:
            module = types.ModuleType(name)
            module.__file__ = str(root / path)
            sys.modules[name] = module
            exec(compile(contents[path], module.__file__, 'exec'), module.__dict__)
        return sys.modules['m4_suite_comparator']
    finally:
        for name, module in saved.items():
            if module is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = module

def validate_tagged(node, depth=0):
    require(depth <= 128 and type(node) is dict, 'invalid/deep tagged value')
    tag = node.get('tag')
    fields = {'nil':{'tag'}, 'bool':{'tag','value'}, 'f64':{'tag','bits'},
              'string':{'tag','units'}, 'keyword':{'tag','namespace','name'},
              'symbol':{'tag','namespace','name'}, 'vector':{'tag','items'},
              'seq':{'tag','items'}, 'set':{'tag','items'}, 'map':{'tag','entries'},
              'exception-info':{'tag','message','data','cause'}}
    if tag == 'opaque':
        require(set(node) in [{'tag','reason'}, {'tag','reason','type'}] and type(node['reason']) is str,
                'invalid opaque value')
        require('type' not in node or type(node['type']) is str, 'invalid opaque type')
        return
    require(tag in fields and set(node) == fields[tag], 'unknown/malformed tagged value')
    if tag == 'bool':
        require(type(node['value']) is bool, 'non-Boolean tagged bool')
    elif tag == 'f64':
        require(type(node['bits']) is str and re.fullmatch('[0-9a-f]{16}',node['bits']) is not None,
                'invalid f64 bits')
    elif tag == 'string':
        require(type(node['units']) is list and all(type(n) is int and 0 <= n <= 65535 for n in node['units']),
                'invalid UTF16 units')
    elif tag in ['keyword','symbol']:
        for key in ['namespace','name']: validate_tagged(node[key],depth+1)
        require(node['namespace']['tag'] in ['nil','string'] and node['name']['tag'] == 'string', 'invalid identifier')
    elif tag in ['vector','seq','set']:
        require(type(node['items']) is list, 'invalid tagged collection')
        for item in node['items']: validate_tagged(item,depth+1)
    elif tag == 'map':
        require(type(node['entries']) is list, 'invalid tagged map')
        for entry in node['entries']:
            require(type(entry) is list and len(entry) == 2, 'invalid tagged map entry')
            for item in entry: validate_tagged(item,depth+1)
    elif tag == 'exception-info':
        for key in ['message','data','cause']: validate_tagged(node[key],depth+1)
        require(node['message']['tag'] in ['nil','string'], 'invalid exception message')

def validate_observed(observed, reference, selection):
    require(type(observed) is dict and set(observed) == {'schema','suite','namespaces','test-failures','skips','assertions'},
            'unexpected observation envelope')
    require(type(observed['schema']) is int and observed['schema'] == 1 and observed['suite'] == SUITE,
            'observation identity mismatch')
    for key in ['namespaces','test-failures','skips','assertions']:
        require(type(observed[key]) is list, f'observation {key} must be a list')
    namespaces = observed['namespaces']
    require(all(type(n) is dict and type(n.get('namespace')) is str for n in namespaces), 'invalid namespace record')
    require([n['namespace'] for n in namespaces] == reference['namespaces'],
            'complete suite namespace catalog/order missing, duplicate or changed')
    for n in namespaces:
        require(n.get('status') in ['loaded','failure'], 'invalid namespace status')
        if n['status'] == 'failure':
            require(type(n.get('stage')) is str and type(n.get('diagnostic')) is str and bool(n['diagnostic']),
                    'invalid namespace failure')
    selected_names = {n for g in selection['groups'].values() for n in g['namespaces']}
    known_tests = set(reference['tests'])
    seen = set()
    for row in observed['assertions']:
        require(type(row) is dict and type(row.get('test')) is str and '/' in row['test'], 'invalid assertion test identity')
        require(type(row.get('ordinal')) is int and row['ordinal'] > 0, 'invalid assertion ordinal')
        kind = row.get('kind')
        base = {'test','ordinal','kind','verdict','head'}
        payload_fields = {'predicate':{'operands','result'}, 'value':{'value'}, 'thrown':{'threw'}, 'error':{'thrown'}}
        require(kind in payload_fields and set(row) == base | payload_fields[kind], 'invalid assertion fields/kind')
        require(row['verdict'] in ['pass','fail','error'], 'invalid assertion verdict')
        require(row['head'] is None or type(row['head']) is str, 'invalid assertion head')
        if kind == 'thrown':
            require(type(row['threw']) is bool, 'threw must be a Boolean')
        elif kind == 'predicate':
            require(type(row['operands']) is list, 'predicate operands must be a list')
            for node in row['operands'] + [row['result']]: validate_tagged(node)
            truthy = not (row['result']['tag'] == 'nil' or
                          (row['result']['tag'] == 'bool' and row['result']['value'] is False))
            require((row['verdict'] == 'pass') == truthy, 'predicate result contradicts verdict')
        else:
            validate_tagged(row['value'] if kind == 'value' else row['thrown'])
        require(row['test'].split('/')[0] in reference['namespaces'], 'unknown assertion namespace')
        identity = (row['test'], row['ordinal'])
        require(identity not in seen, f'duplicate assertion ID: {identity}')
        seen.add(identity)
        if row['test'].split('/')[0] in selected_names:
            require(row['test'] in known_tests, f'unexpected selected-namespace assertion test: {row["test"]}')
    for failure in observed['test-failures']:
        require(type(failure) is dict and type(failure.get('test')) is str and '/' in failure['test'], 'invalid test failure identity')
        require(type(failure.get('stage')) is str and type(failure.get('diagnostic')) is str and bool(failure['diagnostic']), 'invalid test failure')
        require(failure['test'].split('/')[0] in reference['namespaces'], 'unknown failure namespace')
        if failure['test'].split('/')[0] in selected_names:
            require(failure['test'] in known_tests, f'unexpected selected-namespace test failure: {failure["test"]}')
    for skip in observed['skips']:
        require(type(skip) is dict and type(skip.get('namespace')) is str, 'invalid skip identity')
        require(skip['namespace'] in reference['namespaces'], 'unknown skip namespace')
        require(type(skip.get('symbol')) is str and skip.get('phase') in ['load','run'], 'invalid skip record')
        require(skip.get('test') is None or (type(skip['test']) is str and skip['test'].split('/')[0] == skip['namespace']), 'skip namespace/test mismatch')

def evaluate(root, observed_path, out, bundle=None):
    root, observed_path, out = map(pathlib.Path, [root, observed_path, out])
    bundle = pathlib.Path(bundle) if bundle else pathlib.Path(__file__).resolve().parent
    # Fresh output required so a failed invocation cannot leave an old success receipt in place.
    require(not out.exists(), 'output path already exists; use a fresh evidence directory')
    out.mkdir(parents=True)
    summary = {'schema':1,'scope':'Selected whole-body groups only; never full-suite/M4 acceptance.',
               'status':'invalid-evidence','exit_code':1,'all_selected_host_verified':False}
    try:
        selection, reference, contents, provenance = bind_inputs(root, bundle)
        raw = observed_path.read_bytes()
        observed = load(raw)
        validate_observed(observed, reference, selection)
        suite = load_comparator(contents, root)
        results = {}
        for group, spec in selection['groups'].items():
            names, tests = spec['namespaces'], spec['tests']
            ref = dict(reference, namespaces=names, tests=tests,
                       assertions=[a for a in reference['assertions'] if a['test'] in tests],
                       skips=[s for s in reference['skips'] if s['namespace'] in names])
            # Filter by namespace, NOT selected test allowlist: unknown outcomes cannot disappear.
            obs = dict(observed, namespaces=[n for n in observed['namespaces'] if n['namespace'] in names],
                       assertions=[a for a in observed['assertions'] if a['test'].split('/')[0] in names],
                       skips=[s for s in observed['skips'] if s['namespace'] in names],
                       **{'test-failures':[f for f in observed['test-failures'] if f['test'].split('/')[0] in names]})
            expected = spec['ordered_ids']
            actual = [[a['test'], a['ordinal']] for a in obs['assertions']]
            counts, failures = suite.compare(ref, obs)
            # The pinned comparator's skip identity omits phase; add an exact
            # multiset check here without changing that reviewed dependency.
            skip_key = lambda entry: (entry['namespace'], entry['test'], entry['symbol'], entry['phase'])
            expected_skips = collections.Counter(skip_key(entry) for entry in ref['skips'])
            actual_skips = collections.Counter(skip_key(entry) for entry in obs['skips'])
            skip_multisets_match = expected_skips == actual_skips
            skip_differences = {
                'missing': [{'identity':list(key),'count':count} for key,count in (expected_skips-actual_skips).items()],
                'unexpected': [{'identity':list(key),'count':count} for key,count in (actual_skips-expected_skips).items()]}
            accounted = counts['pass'] + counts['guest-judged'] + counts['fail'] + counts['not-executed']
            clean = (bool(expected) and actual == expected and not obs['test-failures']
                     and not any(failures[k] for k in ['tests','namespaces','assertions','skip-mismatches'])
                     and counts['fail'] == counts['not-executed'] == 0
                     and counts['skipped'] == len(ref['skips']) and skip_multisets_match
                     and accounted == len(expected))
            host = clean and counts['guest-judged'] == counts['skipped'] == 0 and counts['pass'] == len(expected)
            qualifications = []
            if counts['guest-judged']: qualifications.append('guest-judgments')
            if counts['skipped']: qualifications.append('matched-reference-skips')
            result = {'counts':counts,'failures':failures,'expected_ids':expected,'actual_ids':actual,
                      'ordered_ids_match':actual == expected,'observed_test_failures':obs['test-failures'],
                      'skips':obs['skips'],'skip_identity_fields':['namespace','test','symbol','phase'],
                      'skip_multisets_match':skip_multisets_match,'skip_multiset_differences':skip_differences,
                      'no_detected_failures_or_missing_outcomes':clean,
                      'all_host_verified':host,'qualification_reasons':qualifications,
                      'matched_reference_skips':ref['skips'] if clean else [],
                      'status':('all-host-verified' if host else 'qualified' if clean else 'failed')}
            results[group] = result
            (out / (group+'.json')).write_text(json.dumps(result,indent=2)+'\n')
        clean = all(r['no_detected_failures_or_missing_outcomes'] for r in results.values())
        host = all(r['all_host_verified'] for r in results.values())
        status = 'all-host-verified' if host else 'qualified' if clean else 'failed'
        code = 0 if host else 2 if clean else 1
        # Verify bytes again: changes during comparison invalidate every outcome.
        for name, actual_sha in provenance['actual_source_sha256'].items():
            require(digest(read_under(root,name)) == actual_sha, f'source changed during comparison: {name}')
        require(observed_path.read_bytes() == raw, 'observations changed during comparison')
        final_head = subprocess.run(['git','-C',str(root),'rev-parse','HEAD'],capture_output=True,text=True)
        require(final_head.returncode == 0 and final_head.stdout.strip() == provenance['actual_checkout_head'],
                'source checkout HEAD changed during comparison')
        summary.update(status=status,exit_code=code,all_selected_host_verified=host,
                       selected_groups=results,provenance=provenance,observed_sha256=digest(raw),
                       unselected_test_failures=[f for f in observed['test-failures'] if f['test'].split('/')[0] not in {n for g in selection['groups'].values() for n in g['namespaces']}],
                       unselected_namespace_failures=[n for n in observed['namespaces'] if n['status'] != 'loaded' and n['namespace'] not in {ns for g in selection['groups'].values() for ns in g['namespaces']}],
                       exit_meanings={'0':'All selected assertions independently host-verified; NOT entire M4 or full-suite acceptance.',
                                      '2':'Selected IDs complete, no detected failure, but guest judgments and/or matched pinned reference skips remain; NOT host acceptance.',
                                      '1':'Selected failure, missing/unknown/skip outcome, or invalid evidence.'})
    except Exception as error:
        summary.update(status='invalid-evidence',exit_code=1,error=f'{type(error).__name__}: {error}',all_selected_host_verified=False)
    (out / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    return summary['exit_code'], summary

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=pathlib.Path)
    parser.add_argument('observations',type=pathlib.Path)
    parser.add_argument('output',type=pathlib.Path)
    args = parser.parse_args()
    try:
        code, summary = evaluate(args.root,args.observations,args.output)
    except Exception as error:
        print(json.dumps({'status':'invalid-evidence','exit_code':1,'error':f'{type(error).__name__}: {error}'}),file=sys.stderr)
        return 1
    print(json.dumps({'status':summary['status'],'exit_code':code,'all_selected_host_verified':summary['all_selected_host_verified']}))
    return code

if __name__ == '__main__':
    raise SystemExit(main())
