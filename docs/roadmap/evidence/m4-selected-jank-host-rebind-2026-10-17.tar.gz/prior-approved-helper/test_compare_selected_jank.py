"""Adversarial HOST-ONLY fixtures; synthetic observations are never Suss execution evidence."""
import copy
import importlib.util
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile
import unittest

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('selected_helper', HERE/'compare-selected-jank.py')
helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)

class ComparisonTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.area = HERE/'adversarial-fixtures'
        cls.area.mkdir(exist_ok=True)
        cls.temp = tempfile.TemporaryDirectory(prefix='host-only-',dir=cls.area)
        cls.base = pathlib.Path(cls.temp.name)
        cls.root = cls.base/'fixture-checkout';cls.root.mkdir()
        manifest = json.loads((HERE/'comparison-source-manifest.json').read_text())
        for name in manifest['files']:
            dest=cls.root/name;dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(HERE/'source'/name,dest)
        subprocess.run(['git','init','-q',str(cls.root)],check=True)
        subprocess.run(['git','-C',str(cls.root),'add','.'],check=True)
        subprocess.run(['git','-C',str(cls.root),'-c','user.name=Host fixture','-c','user.email=fixture@example.invalid','-c','commit.gpgsign=false','-c','core.hooksPath=/dev/null','commit','-q','-m','Synthetic comparison inputs; not Suss execution'],check=True)
        cls.bundle=cls.base/'bundle';cls.bundle.mkdir()
        for name in ['comparison-binding.json','comparison-source-manifest.json','pinned-jank-selection.json','pre-hardening/source-manifest.json']:
            dest=cls.bundle/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(HERE/name,dest)
        cls.reference=json.loads((cls.root/'tests/oracle/clojure-test-suite-observations.json').read_text())
        cls.selection=json.loads((cls.bundle/'pinned-jank-selection.json').read_text())
        tests={t for g in cls.selection['groups'].values() for t in g['tests']}
        rows=[]
        for expected in cls.reference['assertions']:
            if expected['test'] not in tests: continue
            row={k:copy.deepcopy(expected[k]) for k in ['test','ordinal','kind','verdict']}
            row['head']=helper.re.match(r'\(([^\s()\[\]{}"]+)',expected['form'])
            row['head']=row['head'][1] if row['head'] else None
            if row['kind']=='predicate':
                row['operands']=copy.deepcopy(expected['operands']);row['result']={'tag':'bool','value':True}
            elif row['kind']=='value': row['value']=copy.deepcopy(expected['value'])
            elif row['kind']=='thrown': row['threw']=expected['threw']
            else: raise RuntimeError('unexpected reference fixture kind')
            rows.append(row)
        cls.observed={'schema':1,'suite':helper.SUITE,'namespaces':[{'namespace':n,'status':'loaded'} for n in cls.reference['namespaces']], 'test-failures':[],'skips':copy.deepcopy(cls.reference['skips']),'assertions':rows}
        # Fixture checkout and every resulting observation/report are retained.
        (cls.base/'SYNTHETIC-NOT-EXECUTED.txt').write_text('No Suss, Cargo, CLJS or guest code executed. Inputs model comparator behavior only.\n')
        (HERE/'adversarial-fixture-location.txt').write_text(str(cls.base)+'\n')
        cls.temp._finalizer.detach()

    def setUp(self): self.value=copy.deepcopy(self.observed)

    def run_case(self, expected, value=None, raw=None):
        name=self.id().split('.')[-1]
        path=self.base/(name+'.observations.json')
        path.write_text(raw if raw is not None else json.dumps(self.value if value is None else value))
        code,summary=helper.evaluate(self.root,path,self.base/(name+'.results'),self.bundle)
        self.assertEqual(code,expected,summary.get('error',summary.get('status')))
        self.assertEqual(summary['exit_code'],expected)
        if expected: self.assertFalse(summary['all_selected_host_verified'])
        return summary

    def mutate_file(self, path, transform, expected=1):
        old=path.read_bytes()
        try:
            path.write_bytes(transform(old));return self.run_case(expected)
        finally: path.write_bytes(old)

    def test_legitimate_complete_guest_judgments_are_qualified_not_host_pass(self):
        s=self.run_case(2)
        self.assertEqual(s['status'],'qualified')
        self.assertIn('guest-judgments',s['selected_groups']['19-contracts']['qualification_reasons'])
        self.assertIn('matched-reference-skips',s['selected_groups']['17-sequences']['qualification_reasons'])
        self.assertEqual(s['selected_groups']['17-sequences']['counts']['skipped'],3)
        self.assertTrue(s['selected_groups']['18-associative']['all_host_verified'])
        self.assertTrue(any(r['counts']['guest-judged']>0 for r in s['selected_groups'].values()))
        for r in s['selected_groups'].values():
            self.assertTrue(r['no_detected_failures_or_missing_outcomes'])
            self.assertEqual(r['counts']['pass']+r['counts']['guest-judged'],len(r['expected_ids']))
        self.assertEqual(len(s['provenance']['actual_source_sha256']),263)
        self.assertEqual(s['provenance']['source_manifest_sha256'],helper.digest((HERE/'comparison-source-manifest.json').read_bytes()))

    def test_reference_value_drift_same_ids_rejected(self):
        def edit(b):
            d=json.loads(b);d['assertions'][0]['operands']=[{'tag':'bool','value':False}];return json.dumps(d).encode()
        s=self.mutate_file(self.root/'tests/oracle/clojure-test-suite-observations.json',edit)
        self.assertIn('source SHA mismatch',s['error'])

    def test_reference_upstream_drift_rejected(self):
        self.mutate_file(self.root/'tests/oracle/clojure-test-suite-observations.json',lambda b:b.replace(helper.PIN.encode(),b'0'*40))

    def test_comparator_logic_drift_rejected_before_import(self):
        self.mutate_file(self.root/'scripts/clojure_test_suite.py',lambda b:b+b'\nraise RuntimeError("must never import changed comparator")\n')

    def test_comparator_dependency_drift_rejected(self):
        self.mutate_file(self.root/'scripts/oracle_compare.py',lambda b:b+b'\n# changed dependency\n')

    def test_transitive_dependency_drift_rejected(self):
        self.mutate_file(self.root/'scripts/oracle_transport.py',lambda b:b+b'\n# changed dependency\n')

    def test_actual_selected_source_body_drift_rejected(self):
        f=self.selection['groups']['17-sequences']['source_files'][0]
        self.mutate_file(self.root/f,lambda b:b+b'\n; changed body\n')

    def test_rust_capture_harness_drift_rejected(self):
        self.mutate_file(self.root/'crates/suss-compile/tests/clojure_test_suite.rs',lambda b:b+b'\n// changed capture\n')

    def test_empty_groups_rejected(self):
        def edit(b):
            d=json.loads(b);d['groups']={};return json.dumps(d).encode()
        self.mutate_file(self.bundle/'pinned-jank-selection.json',edit)

    def test_absent_group_rejected(self):
        def edit(b):
            d=json.loads(b);del d['groups']['19-contracts'];return json.dumps(d).encode()
        self.mutate_file(self.bundle/'pinned-jank-selection.json',edit)

    def test_changed_group_membership_rejected(self):
        def edit(b):
            d=json.loads(b);d['groups']['17-sequences']['tests'].pop();return json.dumps(d).encode()
        self.mutate_file(self.bundle/'pinned-jank-selection.json',edit)

    def test_manifest_tampering_rejected(self):
        self.mutate_file(self.bundle/'comparison-source-manifest.json',lambda b:b+b' ')

    def test_binding_tampering_rejected(self):
        self.mutate_file(self.bundle/'comparison-binding.json',lambda b:b+b' ')

    def test_original_audit_manifest_tampering_rejected(self):
        self.mutate_file(self.bundle/'pre-hardening/source-manifest.json',lambda b:b+b' ')

    def test_unknown_same_namespace_assertion_rejected(self):
        row=copy.deepcopy(self.value['assertions'][0]);row['test']=row['test'].split('/')[0]+'/unexpected-test'
        self.value['assertions'].append(row);self.run_case(1)

    def test_unknown_same_namespace_late_failure_rejected(self):
        ns=self.selection['groups']['17-sequences']['namespaces'][0]
        self.value['test-failures'].append({'test':ns+'/unexpected-late-test','stage':'trap','diagnostic':'late fixture trap'})
        self.run_case(1)

    def test_known_test_late_failure_rejected_with_all_ids(self):
        self.value['test-failures'].append({'test':self.value['assertions'][0]['test'],'stage':'trap','diagnostic':'late failure after complete assertion prefix'})
        s=self.run_case(1);self.assertEqual(s['status'],'failed')

    def test_missing_assertion_rejected(self):
        self.value['assertions'].pop(0);self.run_case(1)

    def test_reordered_assertions_rejected(self):
        self.value['assertions'][0],self.value['assertions'][1]=self.value['assertions'][1],self.value['assertions'][0]
        s=self.run_case(1);self.assertEqual(s['status'],'failed')

    def test_duplicate_assertion_id_rejected(self):
        self.value['assertions'].append(copy.deepcopy(self.value['assertions'][0]));self.run_case(1)

    def test_extra_ordinal_known_test_rejected(self):
        row=copy.deepcopy(self.value['assertions'][0]);row['ordinal']=999999;self.value['assertions'].append(row);self.run_case(1)

    def test_namespace_error_rejected_even_with_complete_assertions(self):
        ns=self.selection['groups']['17-sequences']['namespaces'][0]
        row=next(r for r in self.value['namespaces'] if r['namespace']==ns)
        row.update(status='failure',stage='read',diagnostic='reader gap retained')
        self.run_case(1)

    def test_missing_namespace_rejected(self):
        self.value['namespaces'].pop(0);self.run_case(1)

    def test_skip_selected_namespace_rejected(self):
        ns=self.selection['groups']['17-sequences']['namespaces'][0]
        self.value['skips'].append({'namespace':ns,'symbol':'example','test':None,'phase':'load'});self.run_case(1)

    def test_pinned_run_skip_changed_to_load_is_rejected(self):
        selected_names={n for g in self.selection['groups'].values() for n in g['namespaces']}
        skip=next(x for x in self.value['skips'] if x['namespace'] in selected_names and x['phase']=='run')
        original=copy.deepcopy(skip);skip['phase']='load'
        result=self.run_case(1)
        group=result['selected_groups']['17-sequences']
        self.assertEqual(result['status'],'failed')
        self.assertFalse(group['skip_multisets_match'])
        self.assertFalse(group['no_detected_failures_or_missing_outcomes'])
        self.assertEqual(group['counts']['fail'],0)  # old dependency misses this mismatch
        expected=[original[k] for k in ['namespace','test','symbol','phase']]
        changed=[skip[k] for k in ['namespace','test','symbol','phase']]
        self.assertIn({'identity':expected,'count':1},group['skip_multiset_differences']['missing'])
        self.assertIn({'identity':changed,'count':1},group['skip_multiset_differences']['unexpected'])

    def test_skip_duplicate_changes_multiset_multiplicity_and_fails(self):
        selected_names={n for g in self.selection['groups'].values() for n in g['namespaces']}
        skip=next(x for x in self.value['skips'] if x['namespace'] in selected_names)
        self.value['skips'].append(copy.deepcopy(skip))
        result=self.run_case(1)
        self.assertFalse(result['selected_groups']['17-sequences']['skip_multisets_match'])

    def test_missing_pinned_skip_is_not_silently_removed(self):
        selected_names={n for g in self.selection['groups'].values() for n in g['namespaces']}
        skip=next(x for x in self.value['skips'] if x['namespace'] in selected_names)
        self.value['skips'].remove(skip);self.run_case(1)

    def test_wrong_independently_compared_operand_rejected(self):
        row=next(r for r in self.value['assertions'] if r['kind']=='predicate' and r['operands'] and r['operands'][0].get('tag')!='opaque')
        row['operands'][0]={'tag':'bool','value':False};s=self.run_case(1);self.assertEqual(s['status'],'failed')

    def test_wrong_verdict_rejected(self):
        row=self.value['assertions'][0];row['verdict']='fail'
        if row['kind']=='predicate':row['result']={'tag':'bool','value':False}
        self.run_case(1)

    def test_unknown_namespace_outcome_rejected(self):
        self.value['test-failures'].append({'test':'unknown.namespace/test','stage':'trap','diagnostic':'unknown context'})
        self.run_case(1)

    def test_guest_judged_wrong_verdict_still_fails(self):
        ref=next(a for a in self.reference['assertions'] if a['test'] in {t for g in self.selection['groups'].values() for t in g['tests']} and any(x.get('tag')=='opaque' for x in a.get('operands',[])))
        row=next(a for a in self.value['assertions'] if (a['test'],a['ordinal'])==(ref['test'],ref['ordinal']))
        row['verdict']='fail';row['result']={'tag':'bool','value':False};self.run_case(1)

    def test_boolean_integer_threw_rejected(self):
        next(r for r in self.value['assertions'] if r['kind']=='thrown')['threw']=1;self.run_case(1)

    def test_boolean_ordinal_rejected(self):
        self.value['assertions'][0]['ordinal']=True;self.run_case(1)

    def test_duplicate_json_failure_key_rejected(self):
        raw=json.dumps(self.value);raw=raw[:-1]+',"test-failures": []}'
        s=self.run_case(1,raw=raw);self.assertIn('duplicate JSON key',s['error'])

    def test_nonjson_nan_rejected(self):
        self.run_case(1,raw=json.dumps(self.value)[:-1]+',"extra": NaN}')

    def test_unselected_failure_retained_without_claiming_suite_pass(self):
        tests={t for g in self.selection['groups'].values() for t in g['tests']}
        test=next(t for t in self.reference['tests'] if t not in tests)
        self.value['test-failures'].append({'test':test,'stage':'read','diagnostic':'unrelated outcome explicitly retained'})
        s=self.run_case(2);self.assertEqual(len(s['unselected_test_failures']),1);self.assertIn('never full-suite',s['scope'])

    def test_stale_output_path_rejected(self):
        path=self.base/'stale-output';path.mkdir();(path/'summary.json').write_text('{"exit_code":0}')
        observed=self.base/'stale.observations.json';observed.write_text(json.dumps(self.value))
        with self.assertRaisesRegex(helper.InvalidEvidence,'already exists'):helper.evaluate(self.root,observed,path,self.bundle)

    def test_python_optimized_mode_does_not_disable_binding(self):
        obs=self.base/'optimized.observations.json';obs.write_text(json.dumps(self.value))
        path=self.root/'tests/oracle/clojure-test-suite-observations.json';old=path.read_bytes()
        try:
            path.write_bytes(old+b' ')
            cmd=[sys.executable,'-O',str(HERE/'compare-selected-jank.py'),str(self.root),str(obs),str(self.base/'optimized.results')]
            result=subprocess.run(cmd,capture_output=True,text=True)
            (self.base/'optimized.stdout').write_text(result.stdout);(self.base/'optimized.stderr').write_text(result.stderr)
            self.assertEqual(result.returncode,1,result.stdout+result.stderr)
        finally:path.write_bytes(old)

if __name__=='__main__':unittest.main(verbosity=2)
