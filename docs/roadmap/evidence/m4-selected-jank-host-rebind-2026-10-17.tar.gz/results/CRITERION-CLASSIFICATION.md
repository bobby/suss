# Selected Jank 1a85/76a: criterion classification

Strict host comparison remains FAILED (exit1), all three groups. This classifies reasons; it does not waive outcomes or impose whole-suite green as an issue criterion. No guest/source/Cargo/selection changes.

## Three missing reference skips

All belong to `clojure.core-test.realized-qmark/test-realized?`, phase `run`: promise once (upstream line23), future twice (lines41,79). Exact forms are `(when-var-exists promise` and `(when-var-exists future`. Reference IDs have no ordinal or location; future is a multiset multiplicity2, not two invented assertion IDs. Namespace macro transport fails at244..4118 before these skip events. The three fail counts are missing reference skip records, not three observed assertion failures, nor a requirement to implement promise/future.

## Failed namespace classification

| Group | Namespace | Actual failure | Criterion interpretation |
|---|---|---|---|
| 17-sequences | clojure.core-test.lazy-seq | macro transport structural cap | Direct #17 lazy/effect body remains unexecuted; focused lazy/chunk/forcing effect tests pass on76a. Not a demonstrated lazy semantic defect. |
| 17-sequences | clojure.core-test.list | reader prerequisite: 3N/4M in mixed-value list | Nonportable numeric literals block the body; they do not require JVM numeric support under #17. Other portable list assertions remain unexecuted here; portable_sequences evidence is separate. |
| 17-sequences | clojure.core-test.map | macro transport structural cap | Direct #17 map/chunk effects and #19 map/reduction supplemental body unexecuted. Native268 removes structural cap but unchanged current map still fails fuel: no69-ID execution credit. |
| 17-sequences | clojure.core-test.realized-qmark | macro transport structural cap | Direct #17 realization/once-only effects unexecuted in this body; portable_realized/lazy focused evidence is separate. Missing promise/future skips do not require those JVM APIs. |
| 17-sequences | clojure.core-test.seq | reader prerequisite: 440M/55000M | Nonportable numeric fixtures block #17 sequence assertions; focused seq/collection boundary/effect cases remain independent criterion evidence. |
| 17-sequences | clojure.core-test.subvec | reader prerequisite: ratio in unselected :default branch | 1/2,4/3 occur in #? :default branch explicitly excluded for CLJS. Reader conditional handling is a prerequisite, not requirement to execute JVM ratio semantics. #17 subvector boundary/sharing tests are separate. |
| 17-sequences | clojure.core-test.vector | reader prerequisite: 3N/4M | Nonportable mixed numeric fixture blocks body; #17 trie31/32/33/deeper boundary/share/metadata evidence comes from portable_vector_trie and compiled_macro_vectors, not this failed body. |
| 18-associative | clojure.core-test.assoc | namespace resolution: sorted? | Sorted? is a direct #18 sorted/iteration prerequisite. Does not show assoc/collision/nil/false assertions failed; portable_sorted/core_sorted and HAMT focused tests pass76a. |
| 18-associative | clojure.core-test.dissoc | namespace resolution: sorted? | Same sorted prerequisite; #18 deletion/collision tests have separate passing focused coverage; this complete body remains unexecuted. |
| 18-associative | clojure.core-test.empty | dependency reader: #cpp in unselected :jank branch of number-range | Unsupported Jank-only syntax in dependency blocks load. Not portable #18 empty/iteration or #19 metadata/equality defect. Focused collection tests cover specific clauses; full body unexecuted. |
| 18-associative | clojure.core-test.set | namespace routing: clojure.core source absent | Harness/import/namespace adaptation prerequisite, not observed set collision/equality error. #18 sets/HAMT focused coverage separate; no claim full-body acceptance. |
| 18-associative | clojure.core-test.sort | namespace resolution: sort | Sorting/comparator API relevant #18 but unresolved API on this capture is not comparator-effect mismatch. Existing portable sorted tree/comparator/iteration tests cover bounded clauses, not whole sort API equivalence. |
| 18-associative | clojure.core-test.sort-by | namespace resolution: sort | Same #18 sort/comparator prerequisite; no executed comparator/order mismatch in failed body. |
| 18-associative | clojure.core-test.sorted-qmark | reader prerequisite:1N | JVM numeric fixture blocks body before sorted? assertions; no requirement to implement arbitrary precision. #18 sorted interfaces/comparator tests separate. |
| 19-contracts | clojure.core-test.distinct | namespace resolution: distinct | Relevant #19 equality/hash/lazy-transducer behavior but unresolved public name does not establish a failure of issue clauses. Focused transducers/hash/Reduced tests separate; full original distinct body unexecuted. |
| 19-contracts | clojure.core-test.empty | dependency reader: #cpp in unselected :jank branch of number-range | Unsupported Jank-only syntax in dependency blocks load. Not portable #18 empty/iteration or #19 metadata/equality defect. Focused collection tests cover specific clauses; full body unexecuted. |
| 19-contracts | clojure.core-test.map | macro transport structural cap | Direct #17 map/chunk effects and #19 map/reduction supplemental body unexecuted. Native268 removes structural cap but unchanged current map still fails fuel: no69-ID execution credit. |
| 19-contracts | clojure.core-test.mapcat | namespace resolution: ->> | Threading macro prerequisite blocks #19 flatten/reduction/effect body. Focused transducers/reduction tests separately cover actual clauses; do not infer mapcat semantic failure. |
| 19-contracts | clojure.core-test.pop-bang | namespace resolution: pop! | Direct transient operation relevant #19; original pop! invalidation body remains unexecuted. portable_transient_errors covers bounded persistent!/post-invalidation errors; do not claim every transient API proven. |
| 19-contracts | clojure.core-test.reduce | namespace resolution: long-array | JVM primitive array constructor prerequisite; not required as portable API merely because present in corpus. #19 Reduced stop/all reduction dispatch already has focused portable_reduction/dispatch/reduce_kv/transducers evidence. No full-body execution here. |
| 19-contracts | clojure.core-test.transient | reader prerequisite:1N/10.0M | Nonportable incorrect-input fixture blocks body; #19 transient invalidation criterion has separate passing focused coverage, not this original body. |

## Next bounded work

#16 provenance/namespace-loading is assessed with core-import source validators plus actual CORE17/bootstrap gates; these Jank group failures do not replace that evidence. Main76a has those focused/CI passes; latest native CORE17 also passes, but eventual-head gates remain necessary.

#17–19 have specific focused criterion coverage already documented in the original audit and actual76a CI index. Do not turn these selected supplementary whole-body failures into automatic issue reopening or universal group-green requirements. Conversely, absent body outcomes are not passing evidence. Remaining broad API/operation coverage is bounded by actual test content, especially pop!/all reduction paths and sorted/comparator APIs.

Current268 may unblock macro transport bodies (lazy-seq/map/realized?) only after actual execution; latest unchanged map still0/69 from fuel. Performance repairs do not by themselves fix JVM-only numeric/read-conditional prerequisites, missing sort/sorted?/distinct/pop!, ->> resolution, namespace routing or long-array fixtures. Reuse approved unchanged criteria and pinned CLJS values/effects for applicable portable cases; do not edit selection here.

PR267 readiness/Closes266 is separate: verified final-source CI green and focused when-let/reconciliation evidence; required full command is running and must be retained with its actual eventual result. No full-green assertion, issue close or merge performed here.
