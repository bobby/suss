from pathlib import Path
import subprocess,os,json,hashlib,time,fcntl
C=Path('/home/bobby/.cache/suss-m4-work'); R=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace'); T=C/'m4-cost-diagnostic-target'; O=C/'coherent-private-project-cost-diagnostic-v1'
P=C/'coherent-private-project-execution-source-v1'; manifest=json.loads((P/'manifest.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a,root=R):return subprocess.check_output(['git','-C',str(root),*a])
def freeze():
 d={}
 for prefix,repo in [('',R),('clojurescript/',R/'clojurescript')]:
  for x in git('ls-files','-z','--cached','--others','--exclude-standard',root=repo).split(b'\0'):
   if not x:continue
   f=os.fsdecode(x)
   if not prefix and f=='clojurescript':continue
   d[prefix+f]=sha((repo/f).read_bytes())
 return d
assert not O.exists()
assert git('rev-parse','HEAD').decode().strip()==manifest['base']
for f,digest in manifest['files'].items():assert sha((R/f).read_bytes())==digest
leases=[]
for p in sorted(T.iterdir()):
 if p.is_file() and p.name.endswith(('.lease','.lock')) and p.name!='.cargo-lock':
  h=p.open('a+');fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(h)
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=str((p/'exe').resolve());cmd=(p/'cmdline').read_bytes()
 except (OSError,PermissionError):continue
 assert not exe.startswith(str(T)+'/'),f'target process {p.name}'
 if Path(exe).name in ('cargo','rustc'):assert str(T).encode() not in cmd
before=freeze();O.mkdir();(O/'before.json').write_text(json.dumps(before));(O/'driver.py').write_bytes(Path(__file__).read_bytes());(O/'source-manifest.json').write_bytes((P/'manifest.json').read_bytes())
argv=['cargo','test','--locked','-p','suss-compile','--lib',manifest['tests']['coherent']['prefix']+'coherent_native_alias_requires_exact_certified_child_not_equal_content_root','--','--exact','--test-threads=1','--nocapture']
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(T),SUSS_METADATA_FUEL_TRACE='1',SUSS_SOURCE_MATERIALIZE_FUEL_TRACE='1')
receipt={'command':argv,'head':manifest['base'],'source_inputs':len(before),'target':str(T),'scope':'one repeated admission test with existing native metadata fuel trace; diagnostic only, zero additional acceptance credit','start':time.time()}
with (O/'raw.log').open('wb') as log:
 proc=subprocess.Popen(argv,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT);receipt['pid']=proc.pid;(O/'receipt.json').write_text(json.dumps(receipt,indent=2));code=proc.wait()
after=freeze();(O/'after.json').write_text(json.dumps(after));receipt.update(exit=code,seconds=time.time()-receipt['start'],changed=[f for f in sorted(before.keys()|after.keys()) if before.get(f)!=after.get(f)])
(O/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));raise SystemExit(code or bool(receipt['changed']))
