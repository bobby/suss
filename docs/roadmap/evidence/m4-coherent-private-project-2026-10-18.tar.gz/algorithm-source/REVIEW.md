# Private native projection buffer optimization — unexecuted source packet

The measured current-base trace charges 5,300,742 units for 44 expectation projections and 1,199,431 for export projection. This packet changes only the private projection algorithm; it grants no key, storage, class, callback or memo authority and leaves all 17 coherent guards and the original metadata tests byte-identical. No Cargo/bootstrap executed; syntax/whitespace checks only. No measured saving is claimed.

Three paths: production metadata_expectations.rs plus two new cfg(test) modules. Before/after snapshots bind the complete eleven-path controller integration. Existing two-file diagnostic markers and previously generated bootstrap bytes are retained unchanged. source-freeze.json includes actual CLJS checkout files, not just the gitlink.

## Actual removed work and preserved traversal

Frames borrow recipe edges by ordinal instead of allocating/populating a Vec<Value>. The same checked edge count is established before descent; each borrowed edge read is prepaid. Alias frames, ancestor scans and complete left-to-right traversal remain, including repeated diamonds and siblings after unsupported children. No visited-node cache, alias collapsing or whole-DAG authority is introduced.

A frame now owns one Vec<Form> instead of growing Vec<Option<Form>> and then allocating/copying into another Vec<Form> at finish. Count/first-present/last-present retain the exact missing-position information required by metadata shape validation. Declined children do not short-circuit traversal. Finish checks metadata shape/map-or-nil in the original order, then discards every present child in source order if any child declined. Successful collections receive the existing buffer by move. Metadata Set's existing reconstruction/discard path is unchanged.

The existing reserve/push/text/UTF16/discard helpers and their tariffs are unchanged. Removed dependency arrays and the second successful-child array have no allocation/relocation/copy fee because that work no longer occurs. Borrowed edge reads pay one unit; child presence/count/move bookkeeping pays four before mutation and reserve pays actual growth/relocation. Existing frame entry, ancestor cycle scan, dispatch and finish charges remain. There is no promise to reproduce old out-of-fuel thresholds after removing actual work; logical traversal/error precedence and cancellation-before-work checks remain. All persistent state is untouched on any error.

## Three unexecuted differential tests

1. Reconstruct the exact two-arity coherent-alias-fn graph: assert 44 captures, compare all 44 native root projections plus the full export against the preserved algorithm. Each native-only comparison uses an independent default operation; no compiler request allowance is changed. Compare all Form spans/metadata/kinds/text/UTF16 plus numeric bits; print per-root costs and require aggregate removed work. This is a native differential test, not guest acceptance.
2. Unsupported results, missing/unfinished/cyclic siblings, malformed metadata receiver/set operands/map-or-nil, metadata replacement/nested metadata, metadata Sets, malformed native Form, repeated aliases, NaN payload/negative zero/unpaired UTF16.
3. Every fuel cut below each algorithm's measured small-fixture cost, active-operation IRQ at entry, exact successful retry, and repeated diamond expansion bounded by the default allowance. The old and new algorithms retain independent actual fees, not artificially matched quotas.

project_legacy.rs preserves the exact old dependencies-through-project body, with only source_facts paths fully qualified for the nested module. It shares unchanged low-level helper tariffs. The full pre-edit file is retained in before/. The original legacy callback-control materialization failure is separate and remains unresolved.

## Review / execution plan (root-owned; not launched)

After independent source review: normal four-output bootstrap regeneration, three exact new differential tests, then root's unchanged guard/probe plan. Freeze all source and actual pinned checkout files before bootstrap, allow only the four normal bootstrap outputs, refreeze and require no test-time changes. Preserve compile/selection/source anomalies and every semantic/fuel failure; no quotas, tariff discounts, fixture reduction or assertion changes. Pure tests passing alone does not establish 17 guards, six CLI rows or issue264 acceptance.
