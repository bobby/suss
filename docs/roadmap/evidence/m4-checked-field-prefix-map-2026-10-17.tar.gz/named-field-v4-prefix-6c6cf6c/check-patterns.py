from pathlib import Path
import ast,json
out=Path(__file__).parent;s=(out/'after/crates/suss-compile/src/runtime_abi/named_properties.rs').read_text();a='    // Named instance access must not mistake raw source names for munged fields.\n';i=s.index(a);j=s.index(a,i+len(a));k=s.index('    // Stride one');scopes={'checked':s[i:j].encode(),'generic':s[j:k].encode()};tree=ast.parse((out/'after/scripts/test_record_abi_provenance.py').read_text());fn=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='test_mutated_guard_rejected_after_refreshing_file_hash');base=ast.literal_eval(next(n.value for n in fn.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='mutations'));overrides={}
for n in ast.walk(fn):
 if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Subscript)and isinstance(n.targets[0].value,ast.Name)and n.targets[0].value.id=='route_mutations'and isinstance(n.targets[0].slice,ast.Constant):overrides[ast.literal_eval(n.targets[0].slice)]=ast.literal_eval(n.value)
rows=[]
for route in ['checked','generic']:
 m=base.copy()
 if route=='checked':
  for key in ['non_ascii_comparison','mask_word_selection','mask_bit_test','lowercase_bypass_reserved']:
   old,new=m[key];m[key]=(old.replace(b'\n',b'\n    '),new.replace(b'\n',b'\n    '))
  m.update(overrides)
 assert len(m)==12
 for name,(old,new)in m.items():
  count=scopes[route].count(old);assert count==1,(route,name,count)
  rows.append({'scope':route,'mutation':name,'occurrences':count})
fn=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='test_checked_prefix_cannot_skip_unit_or_reserved_validation');loop=next(n for n in fn.body if isinstance(n,ast.For));negatives=ast.literal_eval(loop.iter)
for old,new in negatives:
 count=scopes['checked'].count(old);assert count==1,(old,count)
rows.append({'prefix_fallback_unique_targets':len(negatives)})
(out/'static-pattern-proof.json').write_text(json.dumps({'limits':'AST/sourcepattern inspection only; not test orWasm execution','draft_issue':'Initialboundsnegative forindex matchedbothvalidation/equality; correctedcontextanchorscharacterblock; initialfailure not claimedpass','rows':rows},indent=2)+'\n');print('24 guard patterns and6 prefix/fallback negatives uniquely scoped')
