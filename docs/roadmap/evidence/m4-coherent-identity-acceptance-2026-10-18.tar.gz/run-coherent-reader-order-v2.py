from pathlib import Path
import json,hashlib,subprocess,os,time
root=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');out=Path('/home/bobby/.cache/suss-m4-work/coherent-identity-v2');files=json.loads((out/'source-manifest.json').read_text())['files']
def changed():return [x['path'] for x in files if hashlib.sha256((root/x['path']).read_bytes()).hexdigest()!=x['sha256']]
assert not changed();cmd=['cargo','test','--locked','-p','suss-compile','--lib','coherent_reader_before_every_source_alias_preserves_original_effect_order','--','--test-threads=1','--nocapture'];env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',SUSS_METADATA_FUEL_TRACE='1');r={'argv':cmd,'env_overrides':{k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS','SUSS_METADATA_FUEL_TRACE']},'terminal':False};(out/'reader-receipt.json').write_text(json.dumps(r,indent=2)+'\n');start=time.monotonic()
with (out/'reader-order-corrected.log').open('w') as log:
 proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);r['pid']=proc.pid;(out/'reader-receipt.json').write_text(json.dumps(r,indent=2)+'\n');r['exit']=proc.wait()
r.update(terminal=True,seconds=time.monotonic()-start,changed=changed());(out/'reader-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));assert not r['changed']
