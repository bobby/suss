from pathlib import Path
import os,subprocess,json,time,hashlib,tarfile,io
r=Path('/home/bobby/Work/code/bobby/suss-m4-old-record-audit');c=Path('/home/bobby/.cache/suss-m4-work');positive=json.loads((c/'old-record-audit-profile-result.json').read_text());assert positive['current'] is None and positive['source_unchanged'] and positive['exit']==0
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in positive['freeze'].items())
paths=['crates/suss-compile/src/portable_macro_graph/reuse.rs','crates/suss-compile/src/portable_session/certification_audit.rs','runtime/bootstrap/macro.json','runtime/bootstrap/macro.wasm','runtime/bootstrap/runtime.json','runtime/bootstrap/runtime.wasm'];saved={p:(r/p).read_bytes() for p in paths}
a=c/'old-record-audit-positive-snapshot.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for p,b in saved.items():i=tarfile.TarInfo(p);i.size=len(b);t.addfile(i,io.BytesIO(b))
(c/'old-record-audit-positive.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=r))
state={'current':'prepare','stages':[],'positive_snapshot_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'positive_freeze':positive['freeze']}
p=c/'old-record-audit-negative-result.json'
def save():p.write_text(json.dumps(state,indent=2)+'\n')
env=os.environ.copy();env.update(PATH='/home/bobby/.cargo/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'old-record-audit-target'),RAYON_NUM_THREADS='2')
try:
 source=r/paths[0];text=source.read_text();assert text.count('drop(audit.take());')==1;source.write_text(text.replace('drop(audit.take());','// Negative control: retain stale queries across the callback.'))
 state['negative_source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();save()
 commands=[('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('callback',['cargo','test','-p','suss-compile','--lib','--locked','reuse_later_rebuild_rechecks_earlier_old_and_does_not_retain_poisoned_fresh','--','--test-threads=2','--nocapture'])]
 for name,cmd in commands:
  state['current']=name;save();start=time.time()
  with (c/('old-record-audit-negative-'+name+'.log')).open('w') as f:child=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
  state['stages'].append({'name':name,'command':cmd,'exit':child.returncode,'seconds':time.time()-start});save()
  if name=='bootstrap' and child.returncode:break
 (c/'old-record-audit-negative.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=r))
finally:
 for name,data in saved.items():(r/name).write_bytes(data)
 state['current']=None;state['restored_positive_source']=all(hashlib.sha256((r/name).read_bytes()).hexdigest()==h for name,h in positive['freeze'].items());save()
