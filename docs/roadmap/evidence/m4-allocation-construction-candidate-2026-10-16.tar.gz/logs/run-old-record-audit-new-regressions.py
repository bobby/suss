from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-old-record-audit');c=Path('/home/bobby/.cache/suss-m4-work');positive=json.loads((c/'old-record-audit-profile-result.json').read_text());negative=json.loads((c/'old-record-audit-negative-result.json').read_text());assert negative['current'] is None and negative['restored_positive_source'];assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in positive['freeze'].items())
env=os.environ.copy();env.update(PATH='/home/bobby/.cargo/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'old-record-audit-target'),RAYON_NUM_THREADS='2')
cmd=['cargo','test','-p','suss-cli','--locked','--no-fail-fast','--test','compiled_public_records','--test','compiled_macro_control_source_asts','--test','compiled_macro_constructor_source_asts','--test','compiled_macro_core_environment','--','--test-threads=2','--nocapture']
state={'current':'new-regressions','command':cmd,'started':time.time(),'freeze':positive['freeze']};p=c/'old-record-audit-new-regressions-result.json';p.write_text(json.dumps(state,indent=2)+'\n')
with (c/'old-record-audit-new-regressions.log').open('w') as f:child=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
state.update(current=None,exit=child.returncode,seconds=time.time()-state['started'],source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in state['freeze'].items()));p.write_text(json.dumps(state,indent=2)+'\n')
