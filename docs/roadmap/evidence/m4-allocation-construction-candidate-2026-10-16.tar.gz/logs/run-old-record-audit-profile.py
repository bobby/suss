from pathlib import Path
import subprocess,os,json,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-old-record-audit');c=Path('/home/bobby/.cache/suss-m4-work');previous=json.loads((c/'old-record-audit-focused-result.json').read_text());assert previous['current'] is None and previous['source_unchanged']
env=os.environ.copy();env.update(PATH='/home/bobby/.cargo/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'old-record-audit-target'),RAYON_NUM_THREADS='2',SUSS_METADATA_FUEL_TRACE='1')
cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_declaration_functions','compiled_function_declarations_match_primary_presence_and_parameter_shapes','--','--test-threads=2','--nocapture']
result={'command':cmd,'started':time.time(),'current':'profile','freeze':previous['freeze'],'environment':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_TARGET_DIR','RAYON_NUM_THREADS','SUSS_METADATA_FUEL_TRACE']}}
p=c/'old-record-audit-profile-result.json';p.write_text(json.dumps(result,indent=2)+'\n')
with (c/'old-record-audit-profile.log').open('w') as f: child=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
result.update(current=None,exit=child.returncode,seconds=time.time()-result['started'],source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in result['freeze'].items()));p.write_text(json.dumps(result,indent=2)+'\n')
