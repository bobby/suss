from pathlib import Path
import os,subprocess,json,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-old-record-audit');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env.update(PATH='/home/bobby/.cargo/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'old-record-audit-target'),RAYON_NUM_THREADS='2')
profile=json.loads((c/'compiled-plan-record-input-profile-result.json').read_text());assert profile['current'] is None and profile['source_unchanged'];state={'current':None,'freeze':profile['freeze'],'stages':[]};p=c/'compiled-plan-semantics-result.json'
def save():p.write_text(json.dumps(state,indent=2)+'\n')
for name,cmd in [('compiled',['cargo','test','-p','suss-cli','--locked','--no-fail-fast','--test','persistent_session','--test','portable_array_constructor','--test','portable_error_constructors','constructor','--','--test-threads=2','--nocapture']),('host',['cargo','test','-p','suss-compile','--lib','--locked','compiler_data_constructor_plan','--','--test-threads=2','--nocapture'])]:
 state['current']=name;save();start=time.time()
 with (c/('compiled-plan-semantics-'+name+'.log')).open('w') as f:child=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 state['stages'].append({'name':name,'command':cmd,'exit':child.returncode,'seconds':time.time()-start});save()
state.update(current=None,source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in state['freeze'].items()));save()
