from pathlib import Path
import subprocess,os,json,hashlib,time
root=Path('/home/bobby/Work/code/bobby/suss-m4-old-record-audit');c=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env['PATH']='/home/bobby/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'old-record-audit-target')
files=[p for p in (root/'crates').rglob('*') if p.suffix in ('.rs','.sus')]+list((root/'runtime/bootstrap').glob('*'))
r={'freeze':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()},'stages':[],'current':None}
def save(): (c/'old-record-audit-focused-result.json').write_text(json.dumps(r,indent=2)+'\n')
for name,cmd in [
('callback',['cargo','test','-p','suss-compile','--lib','--locked','reuse_later_rebuild_rechecks_earlier_old_and_does_not_retain_poisoned_fresh','--','--test-threads=2','--nocapture']),
('fuel',['cargo','test','-p','suss-cli','--locked','--no-fail-fast','--test','compiled_macro_declaration_metadata','--test','compiled_macro_collection_source_asts','--test','compiled_record_factories','--test','compiled_macro_compiler_catalog','--test','compiled_macro_declaration_functions','--','--test-threads=2','--nocapture'])
]:
 r['current']=name;save();start=time.time()
 with (c/('old-record-audit-focused-'+name+'.log')).open('w') as f: p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start});save()
 if name=='callback' and p.returncode: break
r['current']=None;r['source_unchanged']=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in r['freeze'].items());save()
