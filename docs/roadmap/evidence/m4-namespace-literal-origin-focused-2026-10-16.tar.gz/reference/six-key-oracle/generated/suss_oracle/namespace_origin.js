// Compiled by ClojureScript 0.0.365323148 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('suss_oracle.namespace_origin');
goog.require('cljs.core');
goog.require('cljs.analyzer');
goog.require('cljs.env');
goog.require('cljs.js');
goog.require('cljs.tools.reader');
suss_oracle.namespace_origin.rows = [];
suss_oracle.namespace_origin.calls = [];
suss_oracle.namespace_origin.stage = ["controls"];
suss_oracle.namespace_origin.snap = (function suss_oracle$namespace_origin$snap(label,value){
var memo = value._hash;
return suss_oracle.namespace_origin.rows.push(({"stage": label, "ns": value.ns, "name": value.name, "memo": memo, "nil": (memo == null)}));
});
suss_oracle.namespace_origin._main = (function suss_oracle$namespace_origin$_main(){
var state = cljs.js.empty_state.call(null);
var target = new cljs.core.Symbol(null,"suss-oracle.namespace-target","suss-oracle.namespace-target",1402210640,null);
var kp = cljs.core.Keyword.prototype;
var method = "cljs$core$IHash$_hash$arity$1";
var original = (kp[method]);
try{(kp[method] = (function (coll){
var receiver = this;
var memo = receiver._hash;
var n = receiver.name;
if((((receiver.ns == null)) && (((cljs.core._EQ_.call(null,n,"require-macros")) || (((cljs.core._EQ_.call(null,n,"rename-macros")) || (((cljs.core._EQ_.call(null,n,"use-macros")) || (((cljs.core._EQ_.call(null,n,"excludes")) || (((cljs.core._EQ_.call(null,n,"uses")) || (cljs.core._EQ_.call(null,n,"defs")))))))))))))){
suss_oracle.namespace_origin.calls.push(({"stage": (suss_oracle.namespace_origin.stage[(0)]), "name": n, "memo": memo, "nil": (memo == null)}));
} else {
}

return original.call(receiver,coll);
}));

var seq__13021_13037 = cljs.core.seq.call(null,new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [":require-macros",":rename-macros",":use-macros",":excludes",":uses",":defs"], null));
var chunk__13022_13038 = null;
var count__13023_13039 = (0);
var i__13024_13040 = (0);
while(true){
if((i__13024_13040 < count__13023_13039)){
var s_13041 = cljs.core._nth.call(null,chunk__13022_13038,i__13024_13040);
suss_oracle.namespace_origin.snap.call(null,"reader-control",cljs.tools.reader.read_string.call(null,s_13041));


var G__13042 = seq__13021_13037;
var G__13043 = chunk__13022_13038;
var G__13044 = count__13023_13039;
var G__13045 = (i__13024_13040 + (1));
seq__13021_13037 = G__13042;
chunk__13022_13038 = G__13043;
count__13023_13039 = G__13044;
i__13024_13040 = G__13045;
continue;
} else {
var temp__5825__auto___13046 = cljs.core.seq.call(null,seq__13021_13037);
if(temp__5825__auto___13046){
var seq__13021_13047__$1 = temp__5825__auto___13046;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__13021_13047__$1)){
var c__12101__auto___13048 = cljs.core.chunk_first.call(null,seq__13021_13047__$1);
var G__13049 = cljs.core.chunk_rest.call(null,seq__13021_13047__$1);
var G__13050 = c__12101__auto___13048;
var G__13051 = cljs.core.count.call(null,c__12101__auto___13048);
var G__13052 = (0);
seq__13021_13037 = G__13049;
chunk__13022_13038 = G__13050;
count__13023_13039 = G__13051;
i__13024_13040 = G__13052;
continue;
} else {
var s_13053 = cljs.core.first.call(null,seq__13021_13047__$1);
suss_oracle.namespace_origin.snap.call(null,"reader-control",cljs.tools.reader.read_string.call(null,s_13053));


var G__13054 = cljs.core.next.call(null,seq__13021_13047__$1);
var G__13055 = null;
var G__13056 = (0);
var G__13057 = (0);
seq__13021_13037 = G__13054;
chunk__13022_13038 = G__13055;
count__13023_13039 = G__13056;
i__13024_13040 = G__13057;
continue;
}
} else {
}
}
break;
}

var _STAR_compiler_STAR__orig_val__13025_13058 = cljs.env._STAR_compiler_STAR_;
var _STAR_cljs_ns_STAR__orig_val__13026_13059 = cljs.analyzer._STAR_cljs_ns_STAR_;
var _STAR_analyze_deps_STAR__orig_val__13027_13060 = cljs.analyzer._STAR_analyze_deps_STAR_;
var _STAR_load_macros_STAR__orig_val__13028_13061 = cljs.analyzer._STAR_load_macros_STAR_;
var _STAR_compiler_STAR__temp_val__13029_13062 = state;
var _STAR_cljs_ns_STAR__temp_val__13030_13063 = new cljs.core.Symbol(null,"cljs.user","cljs.user",877795071,null);
var _STAR_analyze_deps_STAR__temp_val__13031_13064 = false;
var _STAR_load_macros_STAR__temp_val__13032_13065 = false;
(cljs.env._STAR_compiler_STAR_ = _STAR_compiler_STAR__temp_val__13029_13062);

(cljs.analyzer._STAR_cljs_ns_STAR_ = _STAR_cljs_ns_STAR__temp_val__13030_13063);

(cljs.analyzer._STAR_analyze_deps_STAR_ = _STAR_analyze_deps_STAR__temp_val__13031_13064);

(cljs.analyzer._STAR_load_macros_STAR_ = _STAR_load_macros_STAR__temp_val__13032_13065);

try{(suss_oracle.namespace_origin.stage[(0)] = "actual-parse-ns");

cljs.analyzer.analyze.call(null,cljs.analyzer.empty_env.call(null),cljs.tools.reader.read_string.call(null,"(ns suss-oracle.namespace-target (:refer-clojure :exclude [map]))"));

(suss_oracle.namespace_origin.stage[(0)] = "actual-ensure-defs");

cljs.analyzer.ensure_defs.call(null,target);

var seq__13033_13066 = cljs.core.seq.call(null,cljs.analyzer.get_namespace.call(null,target));
var chunk__13034_13067 = null;
var count__13035_13068 = (0);
var i__13036_13069 = (0);
while(true){
if((i__13036_13069 < count__13035_13068)){
var entry_13070 = cljs.core._nth.call(null,chunk__13034_13067,i__13036_13069);
if((cljs.core.key.call(null,entry_13070) instanceof cljs.core.Keyword)){
suss_oracle.namespace_origin.snap.call(null,"actual-namespace",cljs.core.key.call(null,entry_13070));
} else {
}


var G__13071 = seq__13033_13066;
var G__13072 = chunk__13034_13067;
var G__13073 = count__13035_13068;
var G__13074 = (i__13036_13069 + (1));
seq__13033_13066 = G__13071;
chunk__13034_13067 = G__13072;
count__13035_13068 = G__13073;
i__13036_13069 = G__13074;
continue;
} else {
var temp__5825__auto___13075 = cljs.core.seq.call(null,seq__13033_13066);
if(temp__5825__auto___13075){
var seq__13033_13076__$1 = temp__5825__auto___13075;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__13033_13076__$1)){
var c__12101__auto___13077 = cljs.core.chunk_first.call(null,seq__13033_13076__$1);
var G__13078 = cljs.core.chunk_rest.call(null,seq__13033_13076__$1);
var G__13079 = c__12101__auto___13077;
var G__13080 = cljs.core.count.call(null,c__12101__auto___13077);
var G__13081 = (0);
seq__13033_13066 = G__13078;
chunk__13034_13067 = G__13079;
count__13035_13068 = G__13080;
i__13036_13069 = G__13081;
continue;
} else {
var entry_13082 = cljs.core.first.call(null,seq__13033_13076__$1);
if((cljs.core.key.call(null,entry_13082) instanceof cljs.core.Keyword)){
suss_oracle.namespace_origin.snap.call(null,"actual-namespace",cljs.core.key.call(null,entry_13082));
} else {
}


var G__13083 = cljs.core.next.call(null,seq__13033_13076__$1);
var G__13084 = null;
var G__13085 = (0);
var G__13086 = (0);
seq__13033_13066 = G__13083;
chunk__13034_13067 = G__13084;
count__13035_13068 = G__13085;
i__13036_13069 = G__13086;
continue;
}
} else {
}
}
break;
}
}finally {(cljs.analyzer._STAR_load_macros_STAR_ = _STAR_load_macros_STAR__orig_val__13028_13061);

(cljs.analyzer._STAR_analyze_deps_STAR_ = _STAR_analyze_deps_STAR__orig_val__13027_13060);

(cljs.analyzer._STAR_cljs_ns_STAR_ = _STAR_cljs_ns_STAR__orig_val__13026_13059);

(cljs.env._STAR_compiler_STAR_ = _STAR_compiler_STAR__orig_val__13025_13058);
}
if(cljs.core.every_QMARK_.call(null,(function (r){
return (r["nil"]);
}),cljs.core.take.call(null,(6),cljs.core.array_seq.call(null,suss_oracle.namespace_origin.rows)))){
} else {
throw (new Error("Assert failed: (every? (fn [r] (aget r \"nil\")) (take 6 (array-seq rows)))"));
}

return console.log(JSON.stringify(({"pin": "c4295f303100bbf5afac449242d30bca1126f1a1", "rows": suss_oracle.namespace_origin.rows, "dispatches": suss_oracle.namespace_origin.calls})));
}finally {(kp[method] = original);
}});
(cljs.core._STAR_main_cli_fn_STAR_ = suss_oracle.namespace_origin._main);
