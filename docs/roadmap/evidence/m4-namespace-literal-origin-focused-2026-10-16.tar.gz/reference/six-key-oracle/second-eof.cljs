(ns suss-oracle.namespace-origin
 (:require [cljs.analyzer :as ana] [cljs.env :as env] [cljs.js :as cljs] [cljs.tools.reader :as reader]))
(def rows (array)) (def calls (array)) (def stage (array "controls"))
(defn snap [label value]
 (let [memo (.-_hash value)]
  (.push rows #js {:stage label :ns (.-ns value) :name (.-name value) :memo memo :nil (nil? memo)})))
(defn -main []
 (let [state (cljs/empty-state) target 'suss-oracle.namespace-target
       kp (.-prototype cljs.core/Keyword) method "cljs$core$IHash$_hash$arity$1" original (aget kp method)]
  (try
   (aset kp method (fn [coll] (this-as receiver
    (let [memo (.-_hash receiver) n (.-name receiver)]
     (when (and (nil? (.-ns receiver))
                (or (= n "require-macros") (= n "rename-macros") (= n "use-macros") (= n "excludes") (= n "uses") (= n "defs")))
      (.push calls #js {:stage (aget stage 0) :name n :memo memo :nil (nil? memo)}))
    (.call original receiver coll)))))
   (doseq [s [":require-macros" ":rename-macros" ":use-macros" ":excludes" ":uses" ":defs"]]
    (snap "reader-control" (reader/read-string s)))
   (binding [env/*compiler* state ana/*cljs-ns* 'cljs.user ana/*analyze-deps* false ana/*load-macros* false]
    (aset stage 0 "actual-parse-ns")
    (ana/analyze (ana/empty-env) (reader/read-string "(ns suss-oracle.namespace-target (:refer-clojure :exclude [map]))"))
    (aset stage 0 "actual-ensure-defs")
    (ana/ensure-defs target)
    (doseq [entry (ana/get-namespace target)] (when (keyword? (key entry)) (snap "actual-namespace" (key entry))))
   (assert (every? (fn [r] (aget r "nil")) (take 6 (array-seq rows))))
   (js/console.log (.stringify js/JSON #js {:pin "c4295f303100bbf5afac449242d30bca1126f1a1" :rows rows :dispatches calls}))
   (finally (aset kp method original)))))
(set! *main-cli-fn* -main)
