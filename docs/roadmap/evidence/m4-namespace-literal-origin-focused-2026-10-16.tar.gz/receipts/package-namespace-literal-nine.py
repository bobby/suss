from pathlib import Path
import hashlib,json,subprocess,tarfile,io
r=Path('/home/bobby/Work/code/bobby/suss-m4-namespace-literal-origin');c=Path('/home/bobby/.cache/suss-m4-work');s=json.loads((c/'namespace-literal-nine-result.json').read_text());assert s['current'] is None and s['source_unchanged'];payload={}
for f,h in s['freeze'].items():
 b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+f]=b
extra=['Cargo.toml','Cargo.lock','crates/suss-core/Cargo.toml','crates/suss-reader/Cargo.toml','crates/suss-compile/Cargo.toml','crates/suss-cli/Cargo.toml','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','runtime/core-import/LICENSE','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json','vendor/wasi/wasi-wit-0.3.1/cli/cli.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit']
for f in extra:assert (r/f).is_file();payload['snapshot/'+f]=(r/f).read_bytes()
paths=[f for f in s['freeze'] if f=='crates/suss-compile/build.rs' or any(f.startswith('crates/'+n+'/src/') and f.endswith(('.rs','.sus')) for n in ['suss-core','suss-reader','suss-compile'])]+extra[:5]+extra[9:];h=hashlib.sha256()
for f in sorted(set(paths),key=lambda p:tuple(p.split('/'))):
 b=payload['snapshot/'+f];n=f.encode();h.update(len(n).to_bytes(8,'little'));h.update(n);h.update(len(b).to_bytes(8,'little'));h.update(b)
checks={}
for phase in ['macro','runtime']:
 m=json.loads(payload[f'snapshot/runtime/bootstrap/{phase}.json']);checks[phase]={'compiler':h.hexdigest()==m['compiler_source_sha256'],'core':hashlib.sha256(payload['snapshot/runtime/core-import/suss/core.sus']).hexdigest()==m['source_sha256'],'dependencies':hashlib.sha256(payload['snapshot/runtime/core-import/manifest.json']).hexdigest()==m['dependency_graph_sha256'],'wasm':hashlib.sha256(payload[f'snapshot/runtime/bootstrap/{phase}.wasm']).hexdigest()==m['wasm_sha256']}
assert all(all(v.values()) for v in checks.values()),checks

for prefix in ['namespace-literal-nine-','namespace-literal-origin-','namespace-origin-compile']:
 for p in c.glob(prefix+'*'):
  if p.is_file():payload['receipts/'+p.name]=p.read_bytes()
for n in ['run-namespace-literal-origin.py','run-namespace-literal-nine.py','preserve-namespace-six.py','namespace-literal-six-preservation.json','namespace-literal-six-terminal.tar.gz','package-namespace-literal-nine.py']:
 payload['receipts/'+n]=(c/n).read_bytes()
o=c/'namespace-origin-oracle'
for p in o.rglob('*'):
 if p.is_file() and 'out' not in p.parts and 'clj-cache' not in p.parts:
  payload['reference/six-key-oracle/'+str(p.relative_to(o))]=p.read_bytes()
for f in ['cljs/analyzer.js','cljs/core.js','suss_oracle/namespace_origin.js']:
 payload['reference/six-key-oracle/generated/'+f]=(o/'out/cljs'/f).read_bytes()
pin=Path('/home/bobby/Work/code/bobby/suss/clojurescript');assert subprocess.check_output(['git','-C',str(pin),'rev-parse','HEAD'],text=True).strip()=='c4295f303100bbf5afac449242d30bca1126f1a1'
for f in ['src/main/clojure/cljs/analyzer.cljc','epl-v10.html']:
 payload['reference/pinned/'+f]=(pin/f).read_bytes()
for f in ['crates/suss-compile/src/portable_macro_data.rs','crates/suss-compile/src/portable/hir/quotes.rs']:
 assert subprocess.check_output(['git','show','be6a219:'+f],cwd=r)==(r/f).read_bytes()
payload['change.patch']=subprocess.check_output(['git','diff','be6a219','--','crates/suss-compile/src/portable_macro_graph.rs','crates/suss-compile/src/portable_macro_graph/analyzer_literal_tests.rs'],cwd=r)
audit={'base':'be6a219','freeze_count':len(s['freeze']),'fingerprints':checks,'scope':'Nine explicit namespace-record literal creation routes; all Suss-only fields, membership projection, reader data and dynamic symbols unchanged. No guest IHash bypass or memo authority change. Existing Key enum storage charge retained.','results':s['stages'],'support_inputs_capture':'Supporting fingerprint inputs captured after execution, not separately frozen beforehand. Runtime source/bootstrap freeze checked after execution; fingerprints recomputed from archived bytes.','limits':'No full baseline, Jank gate or final CI on this source; no acceptance or fuel-saving claim. Six-key oracle executed actual ns/ensure-defs; ns* source-audited. Full nine-key oracle is an independent component owned by Lagrange, not silently counted here. Six-field incomplete attempt and exact native result preserved in nested archive. Carver independently reviewed complete nine-key graph fcf6af977c0838c0585ec8ed694b7f49d1b9b25b3089491de6f2f1e47770244a without blockers, relayed by main. Independent runtime oracle supplied separately as m4-namespace-key-oracle-2026-10-16.tar.gz SHA256 e34cacfe993ca126e369747ed3a7d835f8f06b1457332b15b8a2ddb4010752ba; referenced, not duplicated here. No artifact audit or performance validation is inferred from source review.'}
payload['audit.json']=json.dumps(audit,indent=2).encode()
manifest={f:hashlib.sha256(b).hexdigest() for f,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode();out=r/'docs/roadmap/evidence/m4-namespace-literal-origin-focused-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f,b in sorted(payload.items()):
  info=tarfile.TarInfo(f);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:assert all(hashlib.sha256(t.extractfile(f).read()).hexdigest()==h for f,h in manifest.items())
report={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'freeze_count':len(s['freeze']),'fingerprints':checks};(c/'namespace-literal-nine-package-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
