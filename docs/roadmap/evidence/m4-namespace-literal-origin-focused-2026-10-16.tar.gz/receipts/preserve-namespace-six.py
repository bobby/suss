from pathlib import Path
import json,hashlib,tarfile,io
c=Path('/home/bobby/.cache/suss-m4-work');r=Path('/home/bobby/Work/code/bobby/suss-m4-namespace-literal-origin');s=json.loads((c/'namespace-literal-origin-result.json').read_text());assert s['current'] is None and s['source_unchanged'];payload={}
for f,h in s['freeze'].items():
 b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+f]=b
for n in ['result.json','bootstrap.log','native.log','env.log','source-tags.log']:
 p=c/('namespace-literal-origin-'+n);payload['receipts/'+p.name]=p.read_bytes()
p=c/'namespace-origin-compile.log';payload['receipts/'+p.name]=p.read_bytes()
for p in (c/'namespace-origin-oracle').rglob('*'):
 if p.is_file() and ('out' not in p.parts) and 'clj-cache' not in p.parts:payload['oracle/'+str(p.relative_to(c/'namespace-origin-oracle'))]=p.read_bytes()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in payload.items()};payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=c/'namespace-literal-six-terminal.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,b in payload.items():
  info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b))
print(json.dumps({'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'freeze':len(s['freeze'])}))
