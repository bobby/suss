from pathlib import Path
import hashlib,io,json,subprocess,tarfile
c=Path(__file__).parent
r=Path('/home/bobby/Work/code/bobby/suss-m4-cold-reader-identifiers')
s=json.loads((c/'cold-reader-full-baseline-result.json').read_text())
assert s.get('current') is None and 'exit' in s, 'Baseline still live'
assert s['source_unchanged'], 'Producer source changed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==s['head']
subprocess.run(['python3',str(c/'classify-cold-reader-baseline.py')],check=True)
payload={}
for f,h in s['freeze'].items():
 b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h,f
 payload['snapshot/'+f]=b
for name in ['cold-reader-full-baseline-result.json','cold-reader-full-baseline.log','cold-reader-baseline-metadata.json','cold-reader-full-baseline-classification.json','run-cold-reader-full-baseline.py','classify-cold-reader-baseline.py','package-cold-reader-baseline.py']:
 payload['receipts/'+name]=(c/name).read_bytes()
payload['audit.json']=json.dumps({'head':s['head'],'scope':'Exact full workspace baseline, with all raw outcomes retained. A started integration target need not have completed. Classification lists unexecuted integration targets separately; doctest and nonintegration enumeration is limited to raw logs. No inferred pass for absent outcomes.','frozen_paths':len(s['freeze']),'source_unchanged':True,'limits':'This archive adds baseline evidence to independently reviewed focused/oracle evidence. No final-head CI claim. Frozen Cargo manifests cover only explicitly listed paths; metadata and execution receipts are retained.'},indent=2).encode()
manifest={f:hashlib.sha256(b).hexdigest() for f,b in sorted(payload.items())}
payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=r/'docs/roadmap/evidence/m4-cold-reader-full-baseline-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f,b in sorted(payload.items()):
  info=tarfile.TarInfo(f);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:
 for f,h in manifest.items():assert hashlib.sha256(t.extractfile(f).read()).hexdigest()==h,f
result={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'frozen_paths':len(s['freeze']),'head':s['head'],'exit':s['exit']}
(c/'cold-reader-baseline-package-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
