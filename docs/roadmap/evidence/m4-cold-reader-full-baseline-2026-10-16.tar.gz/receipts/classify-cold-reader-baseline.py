from pathlib import Path
import hashlib,json,re
cache=Path(__file__).parent
receipt=json.loads((cache/'cold-reader-full-baseline-result.json').read_text())
if receipt.get('current') is not None or 'exit' not in receipt:
    raise SystemExit('Baseline is still live; no terminal classification emitted')
log_path=cache/'cold-reader-full-baseline.log'
log=log_path.read_text(errors='replace')
metadata=json.loads((cache/'cold-reader-baseline-metadata.json').read_text())
workspace=set(metadata['workspace_members'])
planned=[]
for package in metadata['packages']:
    if package['id'] not in workspace: continue
    for target in package['targets']:
        if 'test' in target['kind'] and target.get('test',True):
            planned.append({'package':package['name'],'name':target['name'],'source':target['src_path']})
started=set(re.findall(r'Running tests/([^ ]+)\.rs ',log))
counts=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',log)
results={'head':receipt['head'],'exit':receipt['exit'],'seconds':receipt['seconds'],
 'source_unchanged':receipt['source_unchanged'],
 'log_sha256':hashlib.sha256(log_path.read_bytes()).hexdigest(),
 'completed_harness_totals':{'passed':sum(int(x[1]) for x in counts),'failed':sum(int(x[2]) for x in counts),'ignored':sum(int(x[3]) for x in counts)},
 'individual_results':[{'name':n,'outcome':o} for n,o in re.findall(r'^test ([^\n]+?) \.\.\. (ok|FAILED|ignored)(?:[^\n]*)$',log,re.M)],
 'integration_targets':[dict(t,execution='started' if t['name'] in started else 'unexecuted') for t in planned],
 'limits':'Started does not imply completed or passing. Harness totals are pass executions, not unique cases. Unexecuted integration targets have no test result. Non-integration and doctest coverage is retained in the raw log; this list does not claim to enumerate them.'}
(cache/'cold-reader-full-baseline-classification.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:v for k,v in results.items() if k not in ('individual_results','integration_targets')},indent=2))
