from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-cold-reader-identifiers');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'cold-reader-identifiers-target'),RAYON_NUM_THREADS='2')
files=[p for p in (r/'crates').rglob('*') if p.suffix in ['.rs','.sus']]+list((r/'runtime/bootstrap').glob('*'))
freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:
 p=r/name
 if p.is_file():freeze[name]=hashlib.sha256(p.read_bytes()).hexdigest()
cmd=['cargo','test','--workspace','--locked','--','--test-threads=2'];state={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'command':cmd,'freeze':freeze,'started':time.time(),'current':'baseline'};receipt=c/'cold-reader-full-baseline-result.json';receipt.write_text(json.dumps(state,indent=2)+'\n')
metadata=subprocess.run(['cargo','metadata','--locked','--no-deps','--format-version','1'],cwd=r,env=env,capture_output=True,text=True);(c/'cold-reader-baseline-metadata.json').write_text(metadata.stdout);state['metadata_exit']=metadata.returncode
with (c/'cold-reader-full-baseline.log').open('w') as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
state.update(current=None,exit=p.returncode,seconds=time.time()-state['started'],source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in freeze.items()));receipt.write_text(json.dumps(state,indent=2)+'\n')
