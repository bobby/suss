from pathlib import Path
import json,hashlib,subprocess,tarfile,io
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss-m4-typed-scalar-complete-cost');O=C/'typed-scalar-complete-cost-evidence';run=C/'native-typed-scalar-complete-cost';H='bc70a7cf16eca1ca84cdd0613e780927c8ddde60';P='6a1d15e88103484d9c6fc73c50b08f88024ebf49';pin='c4295f303100bbf5afac449242d30bca1126f1a1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H
payload={};blobs={}
def put(n,b):assert n not in payload,n;payload[n]=b
receipt=json.loads((run/'receipt.json').read_text());assert receipt['current'] is None and receipt['final_changed']==[] and all(s['exit']==0 for s in receipt['stages'])
for f in run.rglob('*'):
 if f.is_file() and f.relative_to(run).parts[0] not in ['before','after-bootstrap'] and '__pycache__' not in f.parts:put('run/'+str(f.relative_to(run)),f.read_bytes())
for f in run.glob('*freeze.json'):
 freeze=json.loads(f.read_text());assert len(freeze)==2915
 for n,h in freeze.items():
  if h in blobs:continue
  for stage in ['before','after-bootstrap']:
   p=run/stage/n
   if p.is_file():
    b=p.read_bytes()
    if hashlib.sha256(b).hexdigest()==h:blobs[h]=b;break
  else:raise AssertionError((f,n,h))
final=json.loads((run/'after-bootstrap-freeze.json').read_text());normal=[n for n in final if not n.startswith('clojurescript/')];checked={}
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=R,input=''.join(H+':'+n+'\n' for n in normal).encode());stream=io.BytesIO(raw)
for n in normal:
 header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob';b=stream.read(int(header[2]));assert stream.read(1)==b'\n';assert hashlib.sha256(b).hexdigest()==final[n],n;checked[n]=final[n]
for n in final:
 if not n.startswith('clojurescript/'):continue
 b=subprocess.check_output(['git','show',pin+':'+n.removeprefix('clojurescript/')],cwd=R/'clojurescript');assert hashlib.sha256(b).hexdigest()==final[n],n;checked[n]=final[n]
put('final/source-binding.json',(json.dumps({'head':H,'parent':P,'checked':len(checked),'pinned_cljs':pin,'inputs':checked,'mismatches':[]},indent=2)+'\n').encode())
# Retain exact default10M V3 negative, all23outcomes, and complete source closure
# references; fill any missing default blobs directly from production Git6a.
default=C/'native-typed-scalar-witness-v3'
for n in ['focused-rust.log','receipt.json','before-freeze.json','after-bootstrap-freeze.json','source-commit-binding.json']:
 put('default6a/'+n,(default/n).read_bytes())
default_freezes=[json.loads((default/n).read_text()) for n in ['before-freeze.json','after-bootstrap-freeze.json']]
added_default_before=[]
for df in default_freezes:
 for n,h in df.items():
  if h in blobs:continue
  for stage in ['before','after-bootstrap']:
   f=default/stage/n
   if f.is_file():
    b=f.read_bytes()
    if hashlib.sha256(b).hexdigest()==h:
     blobs[h]=b;added_default_before.append({'path':n,'sha256':h,'actual_source':str(f)});break
  else:raise AssertionError(('missing default freeze bytes',n,h))
# Every retained freeze is independently reconstructible from this archive.
for df in default_freezes:
 for n,h in df.items():assert h in blobs and hashlib.sha256(blobs[h]).hexdigest()==h,(n,h)
put('assembly/default-prebootstrap-repair.json',(json.dumps({'rejected_archive_sha256':'f54de03e5be79b34adac1c6b94f79007cad47ef6a6e0c8ec1832c5b9b047cd9c','reason':'Four default before-freeze bootstrap blobs absent; execution/final binding unchanged','added_default_blobs':added_default_before,'old_archive_preserved_in_cache':True,'all_default_freeze_hashes_present':True},indent=2)+'\n').encode())
for h,b in blobs.items():put('frozen/sha256/'+h,b)
for directory in ['typed-scalar-complete-cost-plan-6a1d15e']:
 for f in (C/directory).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:put('packet/'+str(f.relative_to(C/directory)),f.read_bytes())
for n in ['run-typed-scalar-complete-cost.py','compare-typed-scalar-complete-cost.py']:
 put('commands/'+n,(C/n).read_bytes())
# Prior measured parent completecost/raw is distinct production source19326.
prior=C/'native-fresh-class-complete-cost'
for n in ['source-child.log','receipt.json','complete-cost-census.json','whole-phase-native-census.json','default-prefix-equivalence.json']:
 put('prior19326-complete/'+n,(prior/n).read_bytes())
put('assembly/package.py',Path(__file__).read_bytes())
comparison=json.loads((run/'comparison.json').read_text());assert [r['complete_cost'] for r in comparison['complete_diagnostic']]==[10291983,10291983]
summary={'source':H,'production_parent':P,'stages_exit':[s['exit'] for s in receipt['stages']],'rust_pass':1,'rust_fail':0,'ignored':0,'phase_markers':220,'complete_cost_each_phase':10291983,'gap_above_default10M_each':291983,'saving_vs19326_complete_each':1460362,'matched_default_runtime_markers':104,'default_macro_markers':0,'limits':['Fixed30M diagnostic notdefault acceptance','No helper refills','DefaultV3typedfuel retained;MacroSOURCEunexecuted underdefault','Separatebranch noPR/integration','Nestednativecosts not additive whole savings']}
put('summary.json',(json.dumps(summary,indent=2)+'\n').encode())
checks=''.join(hashlib.sha256(payload[n]).hexdigest()+'  '+n+'\n' for n in sorted(payload));put('SHA256SUMS',checks.encode())
archive=R/'docs/roadmap/evidence/m4-typed-scalar-complete-cost-2026-10-17.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for n in sorted(payload):
  b=payload[n];i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 ms=tar.getmembers();assert len(ms)==len(payload)==len({m.name for m in ms})
 for m in ms:assert m.isfile() and tar.extractfile(m).read()==payload[m.name]
j={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(payload),'manifested_payloads':len(payload)-1,'bytes':archive.stat().st_size,'source_head':H,'inputs_bound':len(checked)};(O/'package-result.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j))
