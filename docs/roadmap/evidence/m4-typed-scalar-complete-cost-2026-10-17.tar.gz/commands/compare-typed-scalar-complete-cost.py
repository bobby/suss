from pathlib import Path
import re,json
c=Path(__file__).parent
run=c/'native-typed-scalar-complete-cost'
def markers(path):
 rows=[]
 for line in path.read_text(errors='replace').splitlines():
  i=line.find('source-child-fuel source=')
  if i<0:continue
  text=line[i:]
  m=re.search(r' remaining=Some\((\d+)\)$',text)
  if not m:continue
  phase=re.search(r'source=(Runtime|Macro)',text).group(1)
  rows.append({'phase':phase,'key':text[:m.start()],'remaining':int(m.group(1))})
 return rows
before=markers(c/'native-typed-scalar-witness-v3/focused-rust.log')
after=markers(run/'source-child.log')
results=[];complete=[]
for phase in ['Runtime','Macro']:
 b=[x for x in before if x['phase']==phase];a=[x for x in after if x['phase']==phase]
 for i,x in enumerate(b):
  assert i<len(a),('missing marker',phase,i,x)
  y=a[i];assert y['key']==x['key'],('marker sequence',phase,i,x,y)
  assert y['remaining']-x['remaining']==20_000_000,('offset',phase,i,x,y)
 results.append({'phase':phase,'default_markers':len(b),'diagnostic_markers':len(a),'matched_default_markers':len(b),'all_offsets_20000000':True,'diagnostic_without_default_counterpart':len(a)-len(b)})
 starts=[x for x in a if 'stage=request-start ' in x['key']+' ']
 ends=[x for x in a if 'stage=final-validation result=Ok(())' in x['key']]
 assert len(starts)==1 and starts[0]['remaining']==30_000_000,(phase,starts)
 assert len(ends)==1,(phase,ends)
 cost=starts[0]['remaining']-ends[0]['remaining']
 complete.append({'phase':phase,'start':30_000_000,'final_remaining':ends[0]['remaining'],'complete_cost':cost,'gap_above_default10000000':cost-10_000_000,'saving_vs_previous_production19326_complete11752345':11_752_345-cost})
log=(run/'source-child.log').read_text(errors='replace')
assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in log
out={'production_parent':'6a1d15e88103484d9c6fc73c50b08f88024ebf49','default_markers_matched':results,'complete_diagnostic':complete,'limits':['Fixed30M diagnostic is NOT unchanged10M acceptance','Default Runtime failure retained; Macro-source half unexecuted under default','Every default marker compared in order with exact20M offset','No whole cost derived from prefix or layout model']}
(run/'comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
