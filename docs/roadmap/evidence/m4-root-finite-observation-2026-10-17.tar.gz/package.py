from pathlib import Path
import hashlib,json,subprocess,tarfile,io
cache=Path('/home/bobby/.cache/suss-m4-work');root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');out=Path(__file__).parent
run=cache/'native-root-observation-candidate-1';follow=cache/'native-root-observation-cli-core-followup-1';plan=cache/'root-observation-48-plan';packet=cache/'source-child-finite-observation-reuse';parent=cache/'native-named-field-loop-v2'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='c76543a92df218ebeadd1aedcc389568a744df47'
r=json.loads((run/'receipt.json').read_text());f=json.loads((follow/'receipt.json').read_text());assert r['current'] is None and r['final_changed']==[] and f['exact17pass'] and f['changed']==[]
report='''# Root-only finite source observation: default-fuel execution evidence

Source commit c76543a92df218ebeadd1aedcc389568a744df47, parent48cfd8378a295ce9fedd8306772c1a892aba518d. Exactly two Rust files plus four generated bootstrap artifacts. Approved patch db1ff3e8c386fb95fa9cdfb7893952a3299a2082ce0084d38010242c33c9f400 is applied unchanged. Source_facts SHA078d25fa02e3739ac48abba1d0e38a9784e86d160ae5c62dccf5c9c0b7315f99; source_roots SHA43b03980829dcbe52ce2be675516a5e7bdbdb90e8bcc70712efde1a781dec1c2.

The new root validation hands its actual decoded Form only through remaining authority checks to the immediate independent expected comparison. Descendants/standalone validation retain immediate observation drop; completed roots perform the original fresh current read. The done Vec remains unchanged, no cloned native Forms or observation cache, no source-owner pointer substituted for witness equality. All source/storage/method/class/prototype proofs and non-short-circuit error order remain live. Comparison entry charges/polls before source_valid, including false observations. A cfg(test) seam injects IRQ at the actual original current-witness position after authority checks; the test uses genuinely corrupted FQN storage and verifies interrupt propagation, clean rejection and exact-reference restoration/GC recovery. No quota, rate, production30M line, per-helper refill or crosspass/callback cache is introduced.

Released current48 tuple includes all published field/provenance changes, NOT historical2bc source. Both ordered regenerated Wasm noncustom section sequences equal48. All2915 after-bootstrap input hashes stay unchanged through tests and corrected CLI follow-up. Sole m4-cost-diagnostic-target, CARGO_BUILD_JOBS=2/RAYON_NUM_THREADS=2/testthreads2, externally managed RUSTFLAGS unchanged. Exact commands/env flags and full before/after source bytes are archived. Native compile0/24.660s; normal bootstrap0/25.124s changes only four allowed outputs. PID919052 original producer and PID932928 follow-up both terminal with empty process groups/leases released.

| Executed stage | Result | Command wall seconds |
|---|---|---:|
| new finite observation semantics/cancellation |2pass|61.268|
| new actual root-boundary IRQ |1pass|19.591|
| all source_facts guards |12pass|126.283|
| all source_roots guards, separate full source-child excluded |5pass|40.992|
| unchanged default10M full source-child |0pass/1fuel failure|51.754|
| corrected suss-cli core_import binary |17pass/0fail/0ignored|141.181|

37 passing test EXECUTIONS, not unique tests: the new2 repeat in facts12 and new IRQ1 repeats in roots5. The separate source-child fails. The original queued core command incorrectly selected suss-compile --test core_import and exited101 with NO tests because that target does not exist. This runner error is preserved, not counted as a core behavioral failure or CLI17 execution. A fresh, same-freeze follow-up ran the correct cargo test -p suss-cli --locked --test core_import -- --test-threads=2 --nocapture, requiring exact17pass; actual test time103.06s, command time141.181s includes compile. No source correction or bootstrap repeat was required between these commands.

## Actual default-fuel comparison

Parent is reviewed field-loop V2 raw source-child trace, with full parent frozen bytes and exact hashes retained. Current publication48 only refreshes its provenance metadata/verification relative to that production Rust tuple. Both have72 matching trace markers and no newly reached marker. Physical-child-checks entry564162->565709 (+1547); checks cost432562->432218 (344 less); physical-inputs entry131600->133491 (+1891 cumulative). Current test still exhausts in physical-inputs, source_roots.rs1762. This phase is established by actual markers, not a line/span inference.

Runtime-source variants0..4 all materialize and finish, but do not complete physical inputs. Macro-source, later physical bridge/materialization/factory checks and final-parent/final-validation remain UNEXECUTED in this default run. This is not the separate approved30M diagnostic and cannot claim its full-tail pass as default acceptance.

Materialization intervals are identical for variants0/1/3/4 (1490769/1473139/1473321/1473043). Variant2 costs1473023 vs1472823 (+200); no inner allocation observer isolates that variation, so it is not attributed to root decode fees or claimed saved work. The cumulative1891 gain is actual, small and insufficient; it does not close the prior complete-diagnostic3.289506M gap per phase. No new complete-phase current cost has been measured. Nested materializer/proof buckets are not added as exclusive costs.

## Limits and review

Carver independently approved the exact cache source before application (relayed by main); actual final source/artifact/evidence review is requested separately. No full workspace baseline, final-head CI, issue closure, merge, new PR or M4 acceptance is claimed. No unrequested subsequent optimization/test iteration is included. Original wrong-package command, raw fuel failure, partial tail, source effect audit and current typed-read addendum are preserved. Future algorithm work must preserve full original contract and be measured; this packet does not authorize source/storage proof shortcuts.
'''
(out/'REPORT.md').write_text(report)
files={}
def add(name,p):
 assert name not in files,name
 files[name]=Path(p).read_bytes()
for name,folder in [('run',run),('cli-followup',follow),('plan',plan)]:
 for p in sorted(folder.iterdir()):
  if p.is_file():add(name+'/'+p.name,p)
for name in ['candidate.patch','manifest.json','EFFECT-AUDIT.md','effect-source-hashes.json','REVIEW.txt']:
 add('approved-packet/'+name,packet/name)
for stage in ['before','after']:
 for rel in ['crates/suss-compile/src/portable_macro_graph/source_facts.rs','crates/suss-compile/src/portable_macro_graph/source_roots.rs']:add('approved-packet/'+stage+'/'+rel,packet/stage/rel)
for name in ['source-child.log','receipt.json','after-bootstrap-freeze.json','sourcechild-parent-comparison.json']:
 add('field-v2-parent/'+name,parent/name)
add('REPORT.md',out/'REPORT.md');add('package.py',__file__)
blobs={};snapshots={}
for label,folder,manifest,stage in [('before',run,'before-freeze.json','before'),('after-bootstrap',run,'after-bootstrap-freeze.json','after-bootstrap'),('field-v2-parent',parent,'after-bootstrap-freeze.json','after-bootstrap')]:
 index=json.loads((folder/manifest).read_text());assert len(index)==2915
 for rel,sha in index.items():
  b=(folder/stage/rel).read_bytes();assert hashlib.sha256(b).hexdigest()==sha,(label,rel);blobs.setdefault(sha,b)
 snapshots[label]={'manifest':('field-v2-parent/'+manifest if label=='field-v2-parent' else 'run/'+manifest),'count':len(index)}
for sha,b in blobs.items():files['frozen/sha256/'+sha]=b
index=json.loads((run/'after-bootstrap-freeze.json').read_text())
# Check source binding to the LOCAL commit, with frozen exact submodule inputs separately retained.
for rel,sha in index.items():
 if rel.startswith('clojurescript/'):continue
 b=subprocess.check_output(['git','show',head+':'+rel],cwd=root);assert hashlib.sha256(b).hexdigest()==sha,rel
binding={'source_commit':head,'parent':'48cfd8378a295ce9fedd8306772c1a892aba518d','snapshot_bindings':snapshots,'unique_frozen_blobs':len(blobs),'root_git_input_bytes_match_source_commit':True,'passing_executions':37,'source_child_fuel_failures':1,'runner_errors_without_tests':1,'zero_ignored':True,'CLI17_corrected_same_freeze':True,'limits':'No default source-child success, no30M/quota change, no whole-current-request completed cost, no full baseline/CI or acceptance claim.'}
files['source-binding.json']=(json.dumps(binding,indent=2)+'\n').encode();files['source-commit.patch']=subprocess.check_output(['git','show','--binary','--format=fuller',head],cwd=root)
manifest={name:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for name,b in sorted(files.items())}
files['MANIFEST.json']=(json.dumps({'payload_count':len(manifest),'payloads':manifest},indent=2)+'\n').encode()
archive=root/'docs/roadmap/evidence/m4-root-finite-observation-2026-10-17.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,b in sorted(files.items()):
  t=tarfile.TarInfo(name);t.size=len(b);t.mtime=0;t.mode=0o644;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)
 for name,entry in manifest.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==entry['sha256'],name
result={'source_commit':head,'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'manifested_payloads':len(manifest),'unique_frozen_blobs':len(blobs),'binding':binding}
(out/'package-result.json').write_text(json.dumps(result,indent=2)+'\n')
(root/'docs/roadmap/evidence/m4-root-finite-observation-2026-10-17.md').write_text(report)
print(json.dumps(result,indent=2))
