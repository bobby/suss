"""One corrected CLI17 follow-up. Execute only after original driver terminal."""
from pathlib import Path
import subprocess,json,hashlib,os,fcntl,time,re,shutil
cache=Path(__file__).parent.parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');parent=cache/'native-root-observation-candidate-1';target=cache/'m4-cost-diagnostic-target'
state=json.loads((parent/'receipt.json').read_text());assert state['current'] is None
assert state['final_changed']==[]
# Defend against launching before the old producer's actual process exit.
pid=state['process']['pid'];assert not Path(f'/proc/{pid}').exists(),'Original driver still live'
expected=json.loads((parent/'after-bootstrap-freeze.json').read_text())
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in expected}
assert freeze()==expected
lease=[]
for name in ['.suss-array-census.lock','.root-observation-target.lease']:
 f=open(target/name,'a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);lease.append(f)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:env=(proc/'environ').read_bytes();cmd=(proc/'cmdline').read_bytes().split(b'\0')[0]
 except OSError:continue
 if b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' in env and any(x in cmd for x in [b'cargo',b'rustc',b'suss_compile',b'suss-bootstrap']):raise RuntimeError('Target active '+proc.name)
run=cache/'native-root-observation-cli-core-followup-1';run.mkdir(exist_ok=False)
command=['cargo','test','-p','suss-cli','--locked','--test','core_import','--','--test-threads=2','--nocapture']
receipt={'current':'cli-core17','command':command,'source':'Exact original after-bootstrap2915 inputs, original wrong-package stage retained separately','parent_receipt':str(parent/'receipt.json'),'process':{'pid':os.getpid(),'pgid':os.getpgid(0),'target':str(target)},'input_count':len(expected)}
def save():(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(run/'before-freeze.json').write_text(json.dumps(expected,indent=2)+'\n');shutil.copyfile(__file__,run/'driver.py');save()
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(target))
for key in list(env):
 if key.startswith('SUSS_') and ('TRACE' in key or 'DIAGNOSTIC' in key):env.pop(key)
start=time.monotonic()
with (run/'cli-core17.log').open('w') as output:result=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
after=freeze();summary=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (run/'cli-core17.log').read_text())
receipt.update(current=None,exit=result.returncode,seconds=time.monotonic()-start,summaries=summary,exact17pass=result.returncode==0 and summary==[('17','0','0')],changed=[p for p in expected if expected[p]!=after[p]])
(run/'after-freeze.json').write_text(json.dumps(after,indent=2)+'\n');save();print(json.dumps(receipt),flush=True)
