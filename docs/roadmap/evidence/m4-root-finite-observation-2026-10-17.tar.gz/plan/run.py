"""PREPARED ONLY. Never apply source. Execute only after explicit main release."""
from pathlib import Path
import argparse,os,subprocess,json,hashlib,fcntl,time,re,shutil
parser=argparse.ArgumentParser()
parser.add_argument('--execute-after-main-release',action='store_true')
parser.add_argument('--release-head',required=True)
parser.add_argument('--result-label',required=True)
args=parser.parse_args()
if not args.execute_after_main_release:parser.error('Planning only; explicit main release is required')
if not re.fullmatch('[a-z0-9-]+',args.result_label):parser.error('Invalid result label')
plan=Path(__file__).parent;cache=plan.parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots')
base=json.loads((plan/'baseline.json').read_text());commands=json.loads((plan/'command-plan.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head==args.release_head,'Release HEAD changed'
subprocess.run(['git','merge-base','--is-ancestor',base['planning_head'],head],cwd=root,check=True)
assert not base['publication_required_before_execution'], 'Checkpoint not released'
patch=base['approved_patch'];expected=base['input_sha256'].copy()
for item in patch['files']:expected[item['path']]=item['after']
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(expected)}
assert freeze()==expected,'Current e1+pending-provenance baseline or approved patch drifted; recapture required'
tracked=subprocess.check_output(['git','ls-files','--recurse-submodules'],cwd=root,text=True).splitlines()
current_paths={p for p in tracked if (root/p).is_file() and (p.startswith(('crates/','runtime/','scripts/','tests/','vendor/','docs/compatibility/','.cargo/','.github/workflows/')) or p in ['Cargo.toml','Cargo.lock','clojurescript/deps.edn','clojurescript/project.clj'])}
current_paths.update(p for p in expected if (root/p).is_file())
current_paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
assert current_paths==set(expected),'Input closure changed; recapture required'

# Refuse accidental delivery of the independent diagnostic allowance.
s=(root/'crates/suss-compile/src/portable_macro_graph/source_roots.rs').read_text()
body=s.split('fn source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo()',1)[1]
assert 's.set_operation_fuel(30_000_000)' not in body
# Main must release this target separately. The lease and /proc checks are defensive,
# not authorization to compete for an active target.
target=cache/'m4-cost-diagnostic-target';target.mkdir(exist_ok=True)
leases=[]
for name in ['.suss-array-census.lock','.root-observation-target.lease']:
 f=open(target/name,'a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:envbytes=(proc/'environ').read_bytes();cmd=(proc/'cmdline').read_bytes().split(b'\0')[0]
 except OSError:continue
 if b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' in envbytes and any(t in cmd for t in [b'cargo',b'rustc',b'suss_compile',b'suss-bootstrap']):raise RuntimeError('Target active: '+proc.name)
run=cache/args.result_label;run.mkdir(exist_ok=False)
def snapshot(name,data):
 (run/(name+'-freeze.json')).write_text(json.dumps(data,indent=2)+'\n')
 for rel in data:
  p=run/name/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,p)
snapshot('before',expected)
shutil.copyfile(plan/'baseline.json',run/'planning-baseline.json');shutil.copyfile(plan/'command-plan.json',run/'command-plan.json');shutil.copyfile(plan/'run.py',run/'driver.py')
state={'current':None,'head':head,'process':{'pid':os.getpid(),'pgid':os.getpgid(0),'target':str(target)},'input_count':len(expected),'stages':[],'limits':'Original default10M outer fixture. No quota/tariff changes, no30M diagnostic; no source edits while live. New/guard failures hard-stop; original source-child fuel failure retained as failure.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(target))
# Preserve externally-managed RUSTFLAGS. Clear opt-in diagnostic observers for focused checks.
for k in list(env):
 if k.startswith('SUSS_') and ('TRACE' in k or 'DIAGNOSTIC' in k):env.pop(k)
allowed={f'runtime/bootstrap/{p}.{x}' for p in ['runtime','macro'] for x in ['wasm','json']}
for stage in commands:
 assert freeze()==expected,'Input changed before '+stage['name']
 name=stage['name'];entry={'name':name,'command':stage['command']};state['stages'].append(entry);state['current']=name;save();print('starting '+name,flush=True)
 stageenv=env.copy()
 if name=='core-import':stageenv['SUSS_HIR_COW_TRACE']='1'
 if name=='source-child':stageenv.update(SUSS_SOURCE_CHILD_FUEL_TRACE='1',SUSS_SOURCE_MATERIALIZE_FUEL_TRACE='1')
 start=time.monotonic()
 with (run/(name+'.log')).open('w') as out:
  result=subprocess.run(stage['command'],cwd=root,env=stageenv,stdout=out,stderr=subprocess.STDOUT)
 after=freeze();changed=[p for p in expected if after[p]!=expected[p]]
 entry.update(exit=result.returncode,seconds=time.monotonic()-start,changed=changed)
 text=(run/(name+'.log')).read_text();summaries=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);entry['summaries']=summaries
 if name=='bootstrap' and result.returncode==0 and set(changed)<=allowed:
  expected=after;snapshot('after-bootstrap',expected)
 elif changed:
  entry['unexpected_mutation']=True;snapshot('failed-after',after);save();break
 if 'exact_pass' in stage or isinstance(stage.get('min_pass'), int):
  entry['count_valid']=len(summaries)==1 and (int(summaries[0][0])==stage['exact_pass'] if 'exact_pass' in stage else int(summaries[0][0])>=stage['min_pass']) and summaries[0][1:] == ('0','0')
 save();print(json.dumps(entry),flush=True)
 if (result.returncode or entry.get('count_valid') is False) and not stage.get('retain_failure', False):
  state['stopped_after_failure']=name;break
state['current']=None;final=freeze();state['final_changed']=[p for p,h in expected.items() if final[p]!=h];save();print(json.dumps(state),flush=True)
