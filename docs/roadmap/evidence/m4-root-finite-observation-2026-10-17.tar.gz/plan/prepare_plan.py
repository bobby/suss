from pathlib import Path
import json,hashlib,subprocess
root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');out=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='48cfd8378a295ce9fedd8306772c1a892aba518d'
tracked=subprocess.check_output(['git','ls-files','--recurse-submodules'],cwd=root,text=True).splitlines()
paths={p for p in tracked if (root/p).is_file() and (p.startswith(('crates/','runtime/','scripts/','tests/','vendor/','docs/compatibility/','.cargo/','.github/workflows/')) or p in ['Cargo.toml','Cargo.lock','clojurescript/deps.edn','clojurescript/project.clj'])}
historical=json.loads(Path('/home/bobby/.cache/suss-m4-work/native-sourcechild-complete-cost/after-bootstrap-freeze.json').read_text())
paths.update(p for p in historical if (root/p).is_file())
paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
patch=json.loads(Path('/home/bobby/.cache/suss-m4-work/source-child-finite-observation-reuse/manifest.json').read_text())
for item in patch['files']:assert hashes[item['path']]==item['before'],item['path']
base={'planning_head':head,'pending_provenance_files':{p:hashes[p] for p in ['docs/compatibility/record-macro-foundations/abi-adaptations.json','scripts/check_record_macro_provenance.py','scripts/test_record_abi_provenance.py']},'input_count':len(hashes),'input_sha256':hashes,'approved_patch':patch,'publication_required_before_execution':True,'limits':'Planning only, not applied or executed. Baseline is current e1 plus these exact three pending provenance changes, NOT historical2bc compiler tuple. Future release HEAD must be supplied explicitly; any input drift requires a fresh plan.'}
(out/'baseline.json').write_text(json.dumps(base,indent=2)+'\n')
cargo=['cargo','test','-p','suss-compile','--locked','--lib']
commands=[{'name':'compile','command':cargo+['--no-run'],'min_pass':None}, {'name':'bootstrap','command':['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap'],'min_pass':None}, {'name':'new-facts','command':cargo+['portable_macro_graph::source_facts::tests::finite_observation_','--','--test-threads=2','--nocapture'],'exact_pass':2}, {'name':'new-root-irq','command':cargo+['portable_macro_graph::source_roots::tests::false_root_observation_still_polls_current_witness_after_authority_checks','--','--exact','--test-threads=2','--nocapture'],'exact_pass':1}, {'name':'source-facts','command':cargo+['portable_macro_graph::source_facts::tests::','--','--test-threads=2','--nocapture'],'min_pass':2}, {'name':'source-roots','command':cargo+['portable_macro_graph::source_roots::tests::','--','--test-threads=2','--nocapture'],'min_pass':2}, {'name':'source-child','command':cargo+['portable_macro_graph::source_roots::tests::source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo','--','--exact','--test-threads=2','--nocapture'],'min_pass':1,'retain_failure':True}]
(out/'command-plan.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps({k:v for k,v in base.items() if k not in ['input_sha256','approved_patch']},indent=2))
