from pathlib import Path
import re,json,hashlib,collections
cache=Path(__file__).parent.parent
parent=cache/'native-named-field-loop-v2';current=cache/'native-root-observation-candidate-1'
def markers(path):
 counts=collections.Counter();rows={};order=[]
 for n,line in enumerate(path.read_text().splitlines(),1):
  m=re.search(r'source-child-fuel source=(\S+) (?:variant=(.*?) )?stage=(.*?) remaining=Some\((\d+)\)',line)
  if not m:continue
  src,variant,stage,fuel=m.groups();base=(src,variant or 'None',stage);i=counts[base];counts[base]+=1;key=base+(i,)
  rows[key]={'source':src,'variant':variant,'stage':stage,'occurrence':i,'remaining':int(fuel),'line':n};order.append(key)
 return rows,order
p,po=markers(parent/'source-child.log');c,co=markers(current/'source-child.log')
comparison=[]
for key in co:
 row=dict(c[key]);old=p.get(key)
 row['parent_remaining']=old['remaining'] if old else None;row['remaining_gain']=row['remaining']-old['remaining'] if old else None
 comparison.append(row)
result={'parent_trace':str(parent/'source-child.log'),'current_trace':str(current/'source-child.log'),'parent_sha256':hashlib.sha256((parent/'source-child.log').read_bytes()).hexdigest(),'current_sha256':hashlib.sha256((current/'source-child.log').read_bytes()).hexdigest(),'parent_markers':len(p),'current_markers':len(c),'matched_markers':sum(k in p for k in c),'newly_reached_markers':[c[k] for k in co if k not in p],'matched_endpoint_comparison':comparison,'limits':'Actual endpoints, not exclusive costs. Parent raw is reviewed field-loop V2 tuple (production48 provenance-only refresh); no inference that source line/span establishes failure phase. Values after parent exhaustion have no matching default baseline. Parent/current scope and exact frozen hashes retained separately. Repeated stage keys matched by occurrence, never overwritten.'}
(current/'sourcechild-parent48-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'parent_markers':len(p),'current_markers':len(c),'matched_markers':result['matched_markers'],'last_current':c[co[-1]] if co else None,'last_matched':next((r for r in reversed(comparison) if r['parent_remaining'] is not None),None)},indent=2))
