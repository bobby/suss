# Partial completed-CoreEnv comparison

Control440 vs compact overlay published d38b59c. Both exact CoreEnv cases terminal typed fuel failures; candidate overall receipt remains live at collection-source. No collection/later-case/baseline result is claimed.

Both graph starts:9,991,174. All1,005 control declaration checkpoints match candidate owner/stage order. At last common EmptyList definition-origin: control7,681; candidate230,697 (+223,016).172 matched completed declarations cost223,000 less in candidate. Candidate completes182 declarations vs172 and starts183 vs173; last observed IChunkedSeq definition-origin2,173. Unfinished tail/whole required cost unknown.

Control completed-tail bucket definition-origin→finished6,684,143 is the next observer target. Candidate total completed-tail6,643,854 includes extra declarations and is NOT a matched savings comparison. Other completed bucket totals likewise have different coverage.

Source/log/receipt hashes, exact argv and completed-case zero-drift checks are retained in partial-core-environment-paired.json. Parser imported only completed CoreEnv stage; no overall-terminal assertion or claim made. Relevant source hash differences are exactly raw_keys.rs,raw_heads.rs,canonical_entries.rs; Graph and unchanged CoreEnv test source match.
