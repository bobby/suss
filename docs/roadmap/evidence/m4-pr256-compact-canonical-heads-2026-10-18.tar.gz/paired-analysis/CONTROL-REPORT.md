# Current440a0b7 CoreEnv control: completed native declaration stages

Source `440a0b7735a4c290eb7c291cfe29e239b5ac33d9`, terminal core-environment stage exit101; overall controller was still running collection when this independent analysis was prepared. No live collection/candidate bytes read. Raw log SHA256 `cdb310695a893dc09b2407a4be95c8651d9ee7a2c0266995008da7590eacae89`.

One metadata-graph request observed:173declarations start,172finish.164completed declarations have all six markers;8simple declarations go directly start->finished. These disjoint completed declaration totals exclude interdeclaration overhead and the open failed declaration.

| Completed interval | Count | Accepted fuel debit |
|---|---:|---:|
| start -> finished | 8 | 359 |
| start -> guarded | 164 | 164,135 |
| guarded -> declaration-origin | 164 | 2,159,528 |
| declaration-origin -> metadata | 164 | 697,489 |
| metadata -> definition-origin | 164 | 261,720 |
| definition-origin -> finished | 164 | 6,684,143 |

**Dominant current completed bucket: definition-origin → finished =6,684,143.** It includes definition/initializer transport, recipe/key planning and subsequent declaration fields; no further inner split is present. It is not established as all copying, all key hashing or all metadata normalization. Compact-head repair plausibly targets actual backing work inside this path, but its effect remains to be measured.

The2,159,528 guarded→declaration-origin subtotal includes a single2,128,392 cold source-origin event at `*print-dup*`, leaving31,136 elsewhere in that bucket. Source-origin snapshot label precedes it in rawlog. Preserve cold setup in paired comparisons; do not subtract it as removable work.

Borrowed guard bb22757 directly targets only the measured start→guarded164,135 completed subtotal (and whatever guard work is nested later, presently unpartitioned). It is NOT the largest outer bucket. Declaration-origin→metadata697,489 is a separate mixed native block; a lazy-normalization reuse repair cannot claim all6.684M tail without another exact source/label proof. Do not select it merely from later-base costs.

Largest completed tail windows (definition-origin→finished):
- suss.core/->ValSeq: 711,145; raw lines594–595.
- suss.core/->NodeIterator: 368,490; raw lines363–364.
- suss.core/->BitmapIndexedNode: 352,437; raw lines139–140.
- suss.core/->ArrayNode: 246,053; raw lines111–112.
- suss.core/BitmapIndexedNode: 213,278; raw lines1157–1158.
- suss.core/->ChunkBuffer: 181,368; raw lines174–175.

Open failed declaration: `suss.core/EmptyList`. Last observed checkpoint `definition-origin` has7,681 remaining. Its required total and work after this checkpoint are UNKNOWN; no zero/final cost invented. Actual Rust result0PASS1typedfuelFAIL during caller&env transport. No complete request or semantic-row pass.

## Prepared paired parser

`analyze.py` supports terminal single-stage control partition, and a full terminal paired comparison requiring explicit `--candidate-released --candidate DIR`. It reads receipt/freeze hashes, preserves rawlineanchors and exact argv, matches ordered checkpoint prefixes only, separately records completed declarations and open tails, and refuses changed source or live overall comparison. Request IDs are graph ordinals; metadata labels do not directly identify caller phases. No per-request forecast or historicalASeq substitutions.

Example after main release only: `python analyze.py --candidate /ABS/RELEASED-CANDIDATE --candidate-released`. Nothing applied or executed in the repository by this analysis.
