# Compact canonical heads: released focused comparison

Source d38b59cb1cbaff0def4aad257c79e4f28ebe339a (440a0b7 + reviewed compact source3 + regeneratedBOOT4). Both receipts terminal/current=None, all candidate stages executed. Candidate43PASS4typed fuelFAIL0ignored (22raw +20guards +1map passes). Identity check exit0. This is a focused result, not all compatibility or full baseline.

3526 recorded frozen files checked unchanged; source3+BOOT4 hashes match actual d38 Git blobs. Every stage receipt changed=[]; exact paired CoreEnv/collection argv match. Full baseline is separate/live; no outcome inferred and no source edits made.

| Critical stage | Actual result | Measured comparison/limit |
| --- | --- | --- |
| CoreEnv |0PASS1fuelFAIL caller &env0..33| All1005 old declaration markers ordered-identical. At EmptyList definition-origin7681→230697 (+223016).172 matched completed declarations save223000; candidate completes182vs172, starts183vs173. Last IChunkedSeq definition-origin2173. No required whole-cost estimate. |
| Collection source |0PASS1fuelFAIL compiled macro invocation709..738|11 graph-start groups; all134 old declaration markers same order. First graph start uses existing40M allowance (NOT default10M). Last common suss.core/+ finished5841985→5925007 (+83022). Matched declaration work saves7574 in each group; these are nested/repeated observations, not11 successful outer requests. No completed whole test or post-failure semantic assertions claimed. |
| Source tags |0PASS2fuelFAIL| Inference caller &env324..356 and invocation-tags caller &env388..413. Same historical failure criteria/spans; no matched work trace quantified here. |
| Pinned map |1PASS| Prior passing test remains passing; this receipt proves the Rust test, not a separately audited69-ID host census. No new cost claim. |

CoreEnv matched completed tail saves224406, offset by1417 extra earlier-stage work; matched complete-declaration net223000. Remaining223016 checkpoint benefit also includes scope before/between completed declarations. The old control definition-origin→finished aggregate6684143 remains next observer target. Comparing candidate aggregate6643854 directly would mix newly reached declarations and is invalid as a matched savings calculation.

Evidence: paired-summary.json retains all paired source/log/receipt hashes, source-stage rows, adjacent costs and raw line anchors. terminal-source-freeze-check.json records complete current-file check and Git correspondence. Unfinished required totals are null. Observer proposal remains cache-only and unapplied; baseline must finish before any source changes.
