from pathlib import Path
import sys,json,re,hashlib,subprocess,collections
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent;r=Path('/home/bobby/Work/code/bobby/suss');cache=p.parent;head='d38b59cb1cbaff0def4aad257c79e4f28ebe339a';rc=json.loads((p/'receipt.json').read_text());manifest=json.loads((p/'manifest.json').read_text());assert rc['terminal'] and rc['current'] is None and not rc['unexecuted']
paths=list(manifest);raw=subprocess.run(['git','-C',str(r),'cat-file','--batch'],input=''.join(head+':'+x+'\n' for x in paths).encode(),stdout=subprocess.PIPE,check=True).stdout;offset=0
for path in paths:
 end=raw.index(b'\n',offset);h=raw[offset:end].split();assert h[1]==b'blob',(path,h);size=int(h[2]);assert hashlib.sha256(raw[end+1:end+size+1]).hexdigest()==manifest[path],path;offset=end+size+2
packet=json.loads((cache/'pr256-compact-heads-downport-source-v1/manifest.json').read_text());assert all(manifest[x]==h for x,h in packet['files'].items())
counts=collections.Counter();names=collections.Counter();stages=[];failures={}
def diagnostic(text):
 m=re.search(r'span: (\d+\.\.\d+).*?Compiled macro expansion failed during ([^:]+):',text)
 return {'fuel':'all fuel consumed' in text,'span':m[1] if m else None,'stage':m[2] if m else None}
for s in rc['stages']:
 assert not s['changed'];text=(p/(s['name']+'.log')).read_text();summary=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 if s['name']=='identity':assert s['exit']==0;continue
 assert len(summary)==1;_,a,b,z=summary[0];a,b,z=map(int,(a,b,z));started=re.findall(r'^test (\S+) \.\.\.',text,re.M);assert len(started)==a+b+z;counts.update(passed=a,failed=b,ignored=z);names.update(started)
 if b:
  panics=list(re.finditer(r"thread '([^']+)' .*?panicked at",text));assert len(panics)==b
  for i,m in enumerate(panics):failures[m[1]]=diagnostic(text[m.start():panics[i+1].start() if i+1<len(panics) else len(text)])
 stages.append({'name':s['name'],'passed':a,'failed':b,'ignored':z,'selected_names':started,'log_sha256':hashlib.sha256(text.encode()).hexdigest()})
# Independent map comparison; invokes only host comparator over already-captured data.
sys.path.insert(0,str(r/'scripts'));import clojure_test_suite as suite
reference=json.loads((r/'tests/oracle/clojure-test-suite-observations.json').read_text());test='clojure.core-test.map/test-map';ns='clojure.core-test.map';reference.update(namespaces=[ns],tests=[test],assertions=[x for x in reference['assertions'] if x['test']==test],skips=[x for x in reference['skips'] if x['namespace']==ns]);observed=json.loads((p/'map-capture/map-transport-observations.json').read_text());expected_ids=[(x['test'],x['ordinal']) for x in reference['assertions']];actual_ids=[(x['test'],x['ordinal']) for x in observed['assertions']];assert len(actual_ids)==69 and expected_ids==actual_ids
mapcounts,mapfail=suite.compare(reference,observed);assert mapcounts['pass']==62 and mapcounts['guest-judged']==7 and all(mapcounts[k]==0 for k in ['fail','not-executed','skipped','namespaces-failed']);assert not any(mapfail[k] for k in ['namespaces','tests','assertions','skip-mismatches'])
comparison={};control=cache/'pr256-compact-heads-control'
for stage in ['core-environment','collection-source']:
 t=(control/(stage+'.log')).read_text();old=diagnostic(t);name=next(x['selected_names'][0] for x in stages if x['name']==stage);comparison[name]={'control':old,'candidate':failures[name],'same_fuel_stage_span':old==failures[name]}
ci=json.loads((cache/'pr256-440a0b7-ci/terminal-audit.json').read_text())
for j in ci['jobs']:
 for name,f in j.get('failed',{}).items():
  if name in failures and 'compiled_source_' in name:
   old={k:f.get(k) for k in ['fuel','span','stage']};comparison[name]={'control':'440a0b7 CI retained raw classification','control_diagnostic':old,'candidate':failures[name],'same_fuel_stage_span':old==failures[name]}
assert len(comparison)==4 and all(x['same_fuel_stage_span'] for x in comparison.values())
review={'verdict':'FOCUSED_EVIDENCE_VALID; FOUR_UNRESOLVED_FUEL_FAILURES; NOT_ACCEPTANCE_READY','source':head,'freeze_files':len(paths),'all_frozen_files_exact_git_commit':True,'three_rust_files_exact_approved_patch':packet['files'],'bootstrap_hashes':{x:h for x,h in manifest.items() if x.startswith('runtime/bootstrap/')},'normal_bootstrap_identity':'bootstrap.log normal completion, identity exit0','executions':{'total':sum(counts.values()),**dict(counts)},'distinct_test_names':len(names),'repeated_names':{n:v for n,v in names.items() if v>1},'stages':stages,'failures':failures,'control_comparison':comparison,'map_independent_compare':{'unchanged_allowance':200000000,'ordered69_ids_exact':True,'counts':mapcounts,'failures':mapfail,'capture_sha256':hashlib.sha256((p/'map-capture/map-transport-observations.json').read_bytes()).hexdigest()},'limits':['Only selected collection projection test executed; two other collection tests filtered, not pass credit.','Same four failure names/stages/spans relative440a controls; raw backtraces/amount of executed work may differ. This is not broad regression absence or proof direct observations executed.','Guard20 andraw22 pass; caught native overflow panic output in successfulrawtests is intentional catch_unwind, not extra failed tests.','Workspace baseline43114 is separate LIVE run and not included/declared terminal by this review.','No readiness, issue closure, promotion, merge or end-to-end performance claim.'],'reviewer_actions':'Read-only Git/rawlog inspection; pure host map comparator only; cache receipt/script. No Cargo/source writes.'}
(p/'independent-terminal-source-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({'receipt':str(p/'independent-terminal-source-review.json'),'source':head,'freeze':len(paths),'counts':dict(counts),'map':mapcounts,'controls_same':all(x['same_fuel_stage_span'] for x in comparison.values())}))
