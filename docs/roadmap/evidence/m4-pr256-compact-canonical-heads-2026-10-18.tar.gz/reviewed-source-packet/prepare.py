from pathlib import Path
import subprocess,difflib,json,hashlib,re
r=Path('/home/bobby/Work/code/bobby/suss');out=Path(__file__).parent
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();fix='4a5919da8b1a0c5d98f99fdc84fbc0b911b3affe'
paths=['crates/suss-compile/src/portable_macro_graph/raw_heads.rs','crates/suss-compile/src/portable_macro_graph/canonical_entries.rs','crates/suss-compile/src/portable_macro_graph/raw_keys.rs'];before={p:(r/p).read_text() for p in paths};after={};proof={};h=lambda s:hashlib.sha256(s.encode()).hexdigest()
for p in paths[:2]:
 old=subprocess.check_output(['git','show',fix+'^:'+p],cwd=r,text=True);assert before[p]==old,p
 after[p]=subprocess.check_output(['git','show',fix+':'+p],cwd=r,text=True)
 proof[p]={'exact_parent_preimage':True,'old_git_blob':subprocess.check_output(['git','rev-parse',fix+'^:'+p],cwd=r,text=True).strip(),'selected_after_git_blob':subprocess.check_output(['git','rev-parse',fix+':'+p],cwd=r,text=True).strip()}
p=paths[2];s=before[p]
old='pub(super) struct KeyId(pub(super) usize);\n';new=old+'''
/// Native canonical-entry index encoded as index+1. Production owners come ONLY
/// from Entries::prepare after checked next_len and native extent validation.
/// This is a storage domain, not source/guest identity or provenance authority.
#[repr(transparent)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) struct HeadIndex(std::num::NonZeroUsize);
impl HeadIndex {
    // Caller must prepay the decode before using the resulting entry index.
    fn index(self) -> usize { self.0.get() - 1 }
}
'''
assert s.count(old)==1;s=s.replace(old,new,1)
old='            self.heads.get(hash, &mut head_charge)?';new='''            match self.heads.get(hash, &mut head_charge)? {
                Some(head) => {
                    head_charge(1)?; // decode canonical index before use; included in lookup subtotal
                    Some(head.index())
                }
                None => None,
            }''';assert s.count(old)==1;s=s.replace(old,new,1)
old='''        if head.is_none() {
            let work = &mut self.profile_head_insert_work;''';new='''        if head.is_none() {
            let head_index = prepared.head_index(charge, &mut self.entry_stats)?;
            let work = &mut self.profile_head_insert_work;''';assert s.count(old)==1;s=s.replace(old,new,1)
old='self.heads.get_or_insert(hash, index, &mut head_charge)?;';new='self.heads.get_or_insert(hash, head_index, &mut head_charge)?;';assert s.count(old)==1;s=s.replace(old,new,1)
old='table.heads.get(7,&mut |_|Ok::<_,Error>(())).unwrap(),table.heads.get(2000,&mut |_|Ok::<_,Error>(())).unwrap()';new='table.heads.get(7,&mut |_|Ok::<_,Error>(())).unwrap().map(HeadIndex::index),table.heads.get(2000,&mut |_|Ok::<_,Error>(())).unwrap().map(HeadIndex::index)';assert s.count(old)==1;s=s.replace(old,new,1)
after[p]=s;proof[p]={'local_adaptation':'HeadIndex definition, get decode, prepared head conversion before insertion, typed call, test-state decode ONLY; other vector/Plan/key buffer/source unchanged','replacement_assertions':'five exact single-match replacements'}
patch='';tests={}
for p in paths:
 (out/('before-'+Path(p).name)).write_text(before[p]);(out/('after-'+Path(p).name)).write_text(after[p]);patch+=''.join(difflib.unified_diff(before[p].splitlines(True),after[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 names=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',after[p]);prefix='portable_macro_graph::raw_keys::'+('tests::' if p.endswith('/raw_keys.rs') else Path(p).stem+'::tests::');tests[p]=[prefix+n for n in names]
(out/'candidate.patch').write_text(patch)
check=subprocess.run(['git','apply','--check',str(out/'candidate.patch')],cwd=r,text=True,capture_output=True);assert check.returncode==0,check.stderr
(out/'apply-check.json').write_text(json.dumps({'argv':['git','apply','--check',str(out/'candidate.patch')],'cwd':str(r),'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr,'applied':False},indent=2)+'\n')
# Re-read only target files to exclude a raced preparation.
assert all((r/p).read_text()==before[p] for p in paths)
m={'prepared_head':base,'upstream_fix':fix,'files':{p:h(after[p]) for p in paths},'before':{p:h(before[p]) for p in paths},'source_proof':proof,'patch_sha256':h(patch),'focused_prefix':'portable_macro_graph::raw_keys::','source_derived_tests':tests,'test_count':sum(map(len,tests.values())),'git_apply_check':True,'applied':False,'executed':False,'excluded':'BOOT, docs, user AGENTS/policy, provenance followup, all other root source/index/refs remain untouched'};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({k:m[k] for k in ['prepared_head','files','patch_sha256','test_count','git_apply_check']},indent=2))
