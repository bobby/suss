# V3 lazy arity-capped child buffers — source only, UNEXECUTED

Relative to V2's actual post-bootstrap terminal freeze, only metadata_expectations.rs changes. All11 integration paths have before/after snapshots; actual pinned checkout is included in the4045-input freeze. All45-output differential assertions/three tests, old projector and all17 guards remain byte-identical. The exact four saved V2 bootstrap payloads still match the working dependencies. No further saving or allocation dominance is claimed; no Cargo/bootstrap executed.

## Narrow algorithm

The parent's dependency_count has already been checked on entry. After a non-alias child finishes, prepay one unit before reading that count and pass it to Inputs::push. None handling, count/presence bookkeeping and subsequent sibling traversal are unchanged. Only Some(Form) reaches reserve_child, at the exact old reserve call site; there is no preallocation, preliminary scan or skipped child.

reserve_child prepays two units before checked next-length/arity validation. If capacity already holds the new Form, no allocation happens. Otherwise request min(total, max(needed, checked(2*actual_capacity), min(4,total))). Needed must not exceed total. Existing allocation overflow/error text and allocation-failure text are retained; an additional internal impossible-arity error defends the helper contract. Allocation bytes use requested total capacity * sizeof(Form), relocation bytes use old live length * sizeof(Form), each charged before try_reserve_exact(count-len), exactly the generic reserve tariff. No discounts or changed quota. Actual allocator capacity is not assumed equal to requested capacity; growth checks use its actual capacity. New arity/limit bookkeeping is explicitly charged.

Arity1..3 requests only1..3 slots rather than four; final geometric growth caps unused tail at the checked arity. Huge arity still starts at at most four slots after its first successful child, not at the huge arity. An all-None parent never enters reserve_child and allocates no child buffer. A late malformed/unsupported child does not cause earlier whole-arity reservation. Earlier successful children still allocate at their old delivery point. Alias inlining and all alias frames/ancestor scans are unchanged. Metadata shape/map-or-nil checking still occurs after complete child traversal in the existing finish order, with original discard behavior. Generic stack/reference reserve, UTF16/text, metadata Set reconstruction and source/certificate authority are untouched.

Fee/IRQ failure occurs before the corresponding new reads, bound work, allocation and relocation. Error thresholds may change with actual allocation work removed and new bookkeeping added; this is not a promise of identical old fuel cut numbers. No persistent state is published by projection failures.

## Review and planned execution

After independent review only: normal bootstrap (four allowed generated outputs), same three differential tests and45rows, unchanged17 guards, unchanged conditional CLI probes. Compare per-root V3 totals to saved V2 rows (4,168,001) and original algorithm (6,500,173), without whole-Macro claims. Every compile/selection/source anomaly and fuel/semantic failure must be preserved. No new test selection, cap probes, tariff cuts or fixtures. Allocation-site census is not included and dominance is not asserted.
