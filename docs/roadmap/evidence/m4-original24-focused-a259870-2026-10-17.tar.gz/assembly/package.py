from pathlib import Path
import json,hashlib,subprocess,re,tarfile,io
C=Path('/home/bobby/.cache/suss-m4-work'); R=Path('/home/bobby/Work/code/bobby/suss-m4-raw-key-scratch'); O=Path(__file__).parent
H='a259870b2fe4ce3e8da3b267bf73c4d8c558622d'; SOURCE='5e0d9f273081ec3a5d7c04aa9e949a1a3c08a0f0'; PIN='c4295f303100bbf5afac449242d30bca1126f1a1'
sha=lambda x:hashlib.sha256(x).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H
payload={}; maps={}; attempts={}; observations=[]
def put(n,b):
 assert n not in payload,n
 payload[n]=b
def add_file(n,p):put(n,Path(p).read_bytes())
def add_tree(prefix,d,excluded=()):
 for p in sorted(d.rglob('*')):
  if p.is_file() and not any(x in p.relative_to(d).parts for x in ('__pycache__',)+tuple(excluded)):add_file(prefix+'/'+str(p.relative_to(d)),p)
selection=json.loads((C/'original-m4-acceptance-a259870/selection.json').read_text()); expected={n:g[0] for g in selection['groups'] for n in g[2]};assert len(expected)==24
for run in ['original-m4-acceptance-a259870','original-m4-unexecuted-a259870']:
 d=C/run; rec=json.loads((d/'receipt.json').read_text());assert rec['base']==H and rec['current'] is None and rec['final_changed']==[]
 add_tree('attempts/'+run,d,('before','terminal'))
 for phase in ('before','terminal'):
  fm=json.loads((d/(phase+'-freeze.json')).read_text());assert len(fm)==2915
  bind=json.loads((d/(phase+'-source-commit-binding.json')).read_text());assert bind['head']==H and bind['checked']==2915 and bind['mismatches']==[]
  maps[run+'/'+phase]=fm
  for path,h in fm.items():
   name='frozen/sha256/'+h
   if name not in payload:
    b=(d/phase/path).read_bytes();assert sha(b)==h,(path,h);put(name,b)
 results={}
 for stage in rec['stages']:
  text=(d/(stage['name']+'.log')).read_text()
  passed=re.findall(r'^test (\S+) \.\.\. ok\s*$',text,re.M)
  failed=re.findall(r"^thread '([^']+)' .* panicked at ",text,re.M)
  for name,status in [(x,'pass')for x in passed]+[(x,'fuel-fail')for x in failed]:
   assert name in expected and name not in results,(name,results)
   if status=='fuel-fail':
    section=text.split("thread '"+name+"'",1)[1].split('\nFAILED',1)[0]
    assert 'caller &env input transport' in section and 'all fuel consumed by WebAssembly' in section
   results[name]=status;observations.append({'test':name,'group':expected[name],'result':status,'attempt':run,'log':stage['name']+'.log'})
  assert sum(x['passed'] for x in stage['summaries'])==len(passed)
  assert sum(x['failed'] for x in stage['summaries'])==len(failed)
  assert all(x['ignored']==0 for x in stage['summaries'])
 attempts[run]={'pass':sum(v=='pass'for v in results.values()),'fuel_fail':sum(v=='fuel-fail'for v in results.values()),'unexecuted_from_original24':sorted(set(expected)-set(results)),'selected_count_flags':[x['selection_count_matches']for x in rec['stages']]}
assert all(fm==next(iter(maps.values()))for fm in maps.values())
assert attempts['original-m4-acceptance-a259870']['pass']==16 and attempts['original-m4-acceptance-a259870']['fuel_fail']==3
assert len(attempts['original-m4-acceptance-a259870']['unexecuted_from_original24'])==5
assert attempts['original-m4-unexecuted-a259870']['pass']==5 and attempts['original-m4-unexecuted-a259870']['fuel_fail']==0
assert len(observations)==24 and len({r['test']for r in observations})==24
union={'head':H,'source_equivalent_head':SOURCE,'pin':PIN,'unique_pass':21,'unique_fuel_fail':3,'ignored':0,'unexecuted':0,'duplicate_test_executions':0,'attempts':attempts,'tests':observations,'failure_scope':'Both public-record tests fail caller &env transport before value observations; reduction-dispatch fails runtime fixture caller &env transport before its observations. No semantic conformance verdict beyond those failures.','prior_fixture_comparison':'No independent Carver old-byte/Form-API-only equivalence receipt supplied to this packet; no assertion that the three failures reproduce an unchanged historical fixture.','scope':'Only the selected original24 focused Rust tests, not full collection/Jank/M4 acceptance.'}
put('classification/original24-union.json',(json.dumps(union,indent=2)+'\n').encode())
for n in ['run-original-m4-acceptance.py','run-original-m4-unexecuted.py','bind-suss-frozen-source.py']:add_file('commands/'+n,C/n)
# Retain earlier source-bound map/core/provenance outcomes as separate context; no new executions.
d=C/'native-raw-key-scratch-acceptance';assert json.loads((d/'terminal-freeze.json').read_text())==next(iter(maps.values()))
for n in ['receipt.json','source-commit-binding.json','map.log','core-import.log','map-independent-comparison.json','map-seven-guest-judged-reasons.json']:add_file('prior-5e0-focused/'+n,d/n)
add_tree('prior-5e0-focused/map-capture',d/'map-capture')
for n in ['compare-raw-key-scratch-map.py','run-raw-key-scratch-acceptance.py']:add_file('prior-5e0-focused/commands/'+n,C/n)
add_tree('prior-5e0-provenance',C/'raw-key-scratch-provenance')
# Current terminal CI, independently classified by Cicero; retain all ten logs plus polling/raw proofs.
ci=C/'pr268-a259870-ci/39043684092'; cr=json.loads((ci/'terminal-receipt.json').read_text());cmp=json.loads((ci/'terminal-comparison-vs-5e0-dc.json').read_text())
assert cr['head']==H and cr['conclusion']=='failure' and len(list(ci.glob('job-*.log')))==10
assert cmp['head']==H and cmp['foundation']['passing_executions']==514 and cmp['integration']=={'pass':106,'fail':14,'ignored':0,'completed_targets':29,'planned_targets':253,'unexecuted_targets':224}
add_tree('current-a259-ci39043684092',ci)
# Historical selection/classification is explicitly a different tuple; no claim of fresh full-body execution.
a=C/'original-m4-16-19-acceptance-audit'
for n in ['pinned-jank-selection.json','focused-test-index.json','source-manifest.json','original-issue-bodies.json']:add_file('historical-source-audit/'+n,a/n)
j=C/'function-owner-jank-classification'
for n in ['README.md','817-source-correspondence.json','snapshot-receipt.json','classification-receipt.json','original-m4-helper-command.json','original-m4-helper.stdout','original-m4-helper.stderr']:add_file('historical-817-jank/'+n,j/n)
add_tree('historical-817-jank/original-m4-groups',j/'original-m4-groups')
# Resolve historical producer freeze only via published companion, never label it as this packet's four current source maps.
context={'historical_jank_source':'817d48e8334a173888e328b8d9000f029649df06','historical_selection_audit_source':'d311f70f5b348876525fe66cd424adec8bd7c483','pinned_jank_suite':'95d4a9112cfc5fe6629be3d14bb99080ea00af2f','historical_raw_companion':'docs/roadmap/evidence/m4-function-form-owner-bootstrap-2026-10-16.tar.gz','historical_raw_companion_sha256':sha((R/'docs/roadmap/evidence/m4-function-form-owner-bootstrap-2026-10-16.tar.gz').read_bytes()),'current_5e0_focused_companion':'docs/roadmap/evidence/m4-raw-key-scratch-2026-10-17.tar.gz','current_5e0_focused_companion_sha256':'494aa46df38041286b93c912f7fe008951dcfbf321273daa5a7bc2d6d2babd45','historical_result':'Selected whole-body groups incomplete/failed; overlap, not additive. This packet does not repeat them. Full historical producer bytes remain in published companion.','current_prior_map':'Same code/source5e0, all69ordered62host7guest0fail/skip/unexecuted, not rerun in original24.','source16':'Prior six provenance checks,30Python regressions and CORE17 passing; counts not added to21 current union passes.','baseline':'5e0 full workspace baseline still live at assembly; no result/log copied.','other_prototypes':'Sparse/pure/semantic prototype work excluded entirely.'}
put('classification/context-and-companions.json',(json.dumps(context,indent=2)+'\n').encode())
# Prove docs-only HEAD does not change any tested input relative to5e0 using both actual independent bindings.
old=json.loads((d/'source-commit-binding.json').read_text());assert old['head']==SOURCE and old['checked']==2915 and old['mismatches']==[]
put('classification/source-correspondence.json',(json.dumps({'a259':H,'source5e0':SOURCE,'checked_input_count':2915,'four_current_git_bindings':True,'all_four_maps_identical':True,'equals_prior_5e0_terminal_map':True,'pinned_cljs':PIN,'scope':'Exact2915 recorded input bytes; not arbitrary unrecorded filesystem equivalence.'},indent=2)+'\n').encode())
put('assembly/package.py',Path(__file__).read_bytes())
put('SHA256SUMS',''.join(sha(payload[n])+'  '+n+'\n'for n in sorted(payload)).encode())
out=R/'docs/roadmap/evidence/m4-original24-focused-a259870-2026-10-17.tar.gz'
assert not out.exists(),'Preserve earlier packaging attempt before replacing'
with tarfile.open(out,'w:gz',compresslevel=6)as t:
 for n,b in sorted(payload.items()):
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
seen={}
with tarfile.open(out,'r|gz')as t:
 for m in t:
  assert m.isfile() and not m.name.startswith('/') and '..'not in Path(m.name).parts and m.name not in seen
  data=t.extractfile(m).read();assert data==payload[m.name];seen[m.name]=sha(data)
assert len(seen)==len(payload)
for fm in maps.values():
 for path,h in fm.items():assert seen.get('frozen/sha256/'+h)==h,path
result={'source_head':H,'archive':str(out),'sha256':sha(out.read_bytes()),'members':len(payload),'manifested_payloads':len(payload)-1,'bytes':out.stat().st_size,'current_freeze_maps':4,'inputs_per_map':2915,'unique_pass':21,'fuel_fail':3,'unexecuted':0,'ignored':0,'safe_unique_members_and_all_manifest_hashes_verified':True}
(O/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');(O/'original24-union.json').write_text(json.dumps(union,indent=2)+'\n');print(json.dumps(result,indent=2))
