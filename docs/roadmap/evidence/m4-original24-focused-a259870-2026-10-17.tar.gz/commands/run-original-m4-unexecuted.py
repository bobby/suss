from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,fcntl
cache=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-raw-key-scratch')
run=cache/'original-m4-unexecuted-a259870'
target=cache/'m4-cost-diagnostic-target'
lease=open(target/'.typed-scalar-witness.lease','w')
fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
lease.write(str(os.getpid()));lease.flush()
run.mkdir(exist_ok=False)
manifest={'base':'a259870b2fe4ce3e8da3b267bf73c4d8c558622d'}
paths=set(json.loads((cache/'native-fresh-class-complete-cost/before-freeze.json').read_text()))
paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
def freeze():
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snapshot(label,data):
 (run/(label+'-freeze.json')).write_text(json.dumps(data,indent=2))
 for p in data:
  dest=run/label/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,dest)
expected=freeze();assert expected==json.loads((cache/'native-raw-key-scratch-acceptance/terminal-freeze.json').read_text());snapshot('before',expected)
(run/'original-selection-context.json').write_text('{\n  "groups": [\n    [\n      "m4-02-sequences",\n      [\n        "compiled_macro_vectors",\n        "portable_vector_trie",\n        "portable_subvector",\n        "portable_lazy_transformations",\n        "portable_chunk_effects",\n        "portable_transducers"\n      ],\n      [\n        "compiled_macro_vectors_match_fresh_pinned_scalar_observations_in_both_phases",\n        "compiled_vectors_collapse_and_regrow_at_1057_preserving_contents_metadata_and_sharing",\n        "vector_trie_matches_independently_decoded_primary_values",\n        "association_copies_only_selected_path_across_fragments_and_gc",\n        "public_subvectors_match_pinned_facts_in_both_phases",\n        "subvector_retains_actual_backing_and_rooted_contents_across_gc",\n        "lazy_transformations_match_complete_pinned_observations_in_both_phases_after_gc",\n        "handed_chunk_preserves_actual_backing_array_identity_after_gc",\n        "chunk_effects_match_complete_pinned_observations_in_both_phases_after_gc",\n        "chunk_demand_cache_and_retry_survive_gc_between_source_fragments",\n        "public_transducers_match_all_pinned_values_effects_and_throws_in_both_phases"\n      ]\n    ],\n    [\n      "m4-03-associative",\n      [\n        "compiled_macro_hash_maps",\n        "portable_sorted_tree_collections",\n        "portable_queues",\n        "compiled_public_records"\n      ],\n      [\n        "compiled_macro_hash_maps_match_fresh_pinned_observations_in_both_phases",\n        "compiled_hash_map_deletion_crosses_collision_and_dense_boundaries_in_both_phases",\n        "complete_sorted_values_iterator_returns_and_range_arities_match_pinned_raw_values",\n        "tree_map_update_sharing_comparator_identity_and_old_tree_survive_gc",\n        "persistent_queues_match_pinned_fifo_and_value_contract_in_both_phases",\n        "queue_iterator_preserves_mutation_exhaustion_and_returned_error_contract",\n        "public_records_execute_jank_and_authored_contracts_with_two_nominal_classes",\n        "public_record_nominal_equality_and_predicate_decode_after_gc_in_both_phases"\n      ]\n    ],\n    [\n      "m4-04-contracts",\n      [\n        "portable_collection_hash",\n        "portable_transient_errors",\n        "portable_reduction_dispatch",\n        "portable_hash_map_sharing"\n      ],\n      [\n        "collection_hash_matches_independently_decoded_primary_values",\n        "cached_hash_suppresses_effects_and_recovers_after_a_throw",\n        "transient_mutation_errors_preserve_exact_pinned_messages_after_gc",\n        "public_reduce_dispatch_and_source_order_match_pinned_cljs_after_gc",\n        "persistent_hamt_update_copies_selected_path_and_retains_unrelated_child_after_gc"\n      ]\n    ]\n  ],\n  "expected_unique_tests": 24\n}')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target))
for k in list(env):
 if k.startswith('SUSS_') and k.endswith('TRACE'):env.pop(k)
base=['cargo','test','-p','suss-compile','--locked','--lib'];tail=['--','--test-threads=1','--nocapture']
commands=[('previously-unexecuted', ['cargo', 'test', '-p', 'suss-cli', '--locked', '--no-fail-fast', '--test', 'portable_sorted_tree_collections', '--test', 'portable_queues', '--test', 'portable_transient_errors', '--', '--exact', '--test-threads=1', '--nocapture', 'complete_sorted_values_iterator_returns_and_range_arities_match_pinned_raw_values', 'tree_map_update_sharing_comparator_identity_and_old_tree_survive_gc', 'persistent_queues_match_pinned_fifo_and_value_contract_in_both_phases', 'queue_iterator_preserves_mutation_exhaustion_and_returned_error_contract', 'transient_mutation_errors_preserve_exact_pinned_messages_after_gc'])]
state={'driver_pid':os.getpid(),'root':str(root),'base':manifest['base'],'input_count':len(expected),'target':str(target),'environment':{'jobs':1,'rayon':1,'test_threads':1,'RUSTFLAGS':'inherited, not assigned'},'current':None,'stages':[],'limits':'Original M4#17-19 focused criterion cohort on published a259 source-equivalent5e0. Retain each original fixture allowance, assertions and independently decoded pinned CLJS observations. Only five selected names that Cargo fail-fast left unexecuted in the original24; no repeat of the16passes/3fuel-failures; --no-fail-fast keeps other independent binaries running; no77 supporting repeats or map69 rerun. Independent groups continue after semantic failure; unavailable/zero selections never pass. #16sixprovenance/30Python/CORE17 already executed separately. Whole-body pinnedJank prior evidence stays historical until source-binding reconciliation; no whole-suite-green requirement.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for name,cmd in commands:
 assert freeze()==expected,'source changed before '+name

 state['current']=name;row={'name':name,'command':cmd};state['stages'].append(row);save();start=time.monotonic()
 with (run/(name+'.log')).open('w') as out:
  proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
 after=freeze();changed=[p for p in expected if expected[p]!=after[p]]
 row.update(exit=code,seconds=time.monotonic()-start,changed=changed)
 if name=='bootstrap' and code==0 and set(changed)<={f'runtime/bootstrap/{phase}.{ext}' for phase in ['macro','runtime'] for ext in ['wasm','json']}:
  expected=after;snapshot('after-bootstrap',expected)
 elif changed:
  row['unexpected_changes']=True;save();break
 save()
 # Independent issue groups continue after a semantic failure; preserve every outcome.
 import re
 counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (run/(name+'.log')).read_text(errors='replace'))
 row['summaries']=[dict(zip(['passed','failed','ignored'],map(int,x)))for x in counts]
 row['selected_expected_count']=5
 row['selected_observed_count']=sum(sum(map(int,x))for x in counts)
 row['selection_count_matches']=row['selected_expected_count']==row['selected_observed_count']
 save()

final=freeze();state['current']=None;state['final_changed']=[p for p,h in expected.items() if final[p]!=h];save()
snapshot('terminal',freeze())
