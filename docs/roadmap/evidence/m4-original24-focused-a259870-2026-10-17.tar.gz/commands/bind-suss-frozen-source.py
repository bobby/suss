from pathlib import Path
import sys,subprocess,json,hashlib
root,head,freeze_path,out_path=sys.argv[1:]
root=Path(root);expected=json.loads(Path(freeze_path).read_text());pin=subprocess.check_output(['git','rev-parse',head+':clojurescript'],cwd=root,text=True).strip();assert pin=='c4295f303100bbf5afac449242d30bca1126f1a1'
bad=[]
for path,wanted in expected.items():
 if path.startswith('clojurescript/'):
  data=subprocess.check_output(['git','show',pin+':'+path[len('clojurescript/'):]],cwd=root/'clojurescript')
 else:data=subprocess.check_output(['git','show',head+':'+path],cwd=root)
 if hashlib.sha256(data).hexdigest()!=wanted:bad.append(path)
assert not bad,bad
result={'head':head,'checked':len(expected),'mismatches':bad,'method':'actual committed Git blobs and pinned ClojureScript submodule','freeze':str(freeze_path)}
Path(out_path).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
