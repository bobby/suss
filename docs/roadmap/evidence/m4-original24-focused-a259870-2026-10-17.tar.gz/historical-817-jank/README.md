# Actual frozen817 Jank capture: strict host classification

One actual producer, function-owner-jank-run, native-capture exit101/326.469s;
pin-check0. All921 inputs unchanged in producer receipt, independently copied
and hash-verified here before cache overlay. Later source_roots diagnostics are
excluded. producer-source/ and producer-run/ retain exact executed bytes/raw log/
receipt/observations. Observations SHA256:
ec3e857e869483e456244e486220290a29af2fb5181f1e9b5f06cdc526125626.
The comparison checkout supplies matching corpus/comparator files, not a claim
that its later dirty source produced this capture. Every263 reviewed comparison
binding also matches the actual retained producer bytes. No Cargo/guest/CLJS
execution or baseline writes were performed for classification.

#264: four original complete bodies,35 expected ordered IDs.23 observed IDs,
23 host passes,0 guest judgments,0 executed verdict failures,12 not-executed,
0 skips and0 test-level failures. Entire identical?4/hash-map8/hash-set11 bodies
execute. when-let's12 assertions do not execute: namespace load reports
Unresolved Runtime name when-let at bytes244..2234. This failure is unchanged
from the retained baseline. No namespace records are missing; one selected
namespace has an explicit failure record. The complete35 ordered sequence does
NOT match and selected acceptance is false. 264-classification.json retains
exact expected/actual/missing IDs, namespace records and all failure/skip details.
This selection is supplemental, not proof of source/certificate/mutation/callback
or default-budget namespace identity acceptance.

Original M4 groups via unchanged approved helper e76c17...:
- #17:106 host,7 guest,165 not-executed;113/278 IDs. Comparator fail3 consists
  entirely of missing pinned realized? reference skips (future2/promise1), not
  executed assertion failures. Six explicit failed namespace records.
- #18:31 host,0 guest,161 not-executed;31/192 IDs;0 comparator failures,
  seven explicit failed namespace records. No complete acceptance.
- #19:323 host,10 guest,166 not-executed;333/499 IDs;0 comparator failures,
  six explicit failed namespace records. No complete acceptance.
All groups are failed/incomplete. Groups overlap; do not sum as distinct coverage.
Actual skips/test-level failure arrays are empty, not filtered away to claim pass.
The exact four-field skip multiset differences are in the helper's result files.
Helper invocation/exit1/stdout/stderr retained outside the frozen original audit.

Whole actual capture:248 namespace records,61 loaded/187 failed;1082 assertion
records. Production host comparator counts1055 host passes,25 guest judgments,
22 framework failures,4752 not-executed,0 matched skips. Framework failures split
into TWO actual assertion kind:error results and20 missing-reference-skip units
across19 multiset identities. Do not describe22 as22 executed failing assertions.
Raw test-failures/skips arrays are empty; namespace failures remain187.
- partial/test-partial#2:unchanged prior kind:error.
- update/test-update#48:newly executed kind:error after prior namespace:macro
  blocked the body. Both actual records retain opaque Unsupported ABI2 value
  layout diagnostics; no more specific semantic cause is inferred.

Against the exact retained known-failure baseline, no previously nonfailing
assertion becomes failed/unexecuted.124 new host passes and8 new guest judgments
were previously failed/unexecuted.4570 failure reasons unchanged,184 changed,
948 previously nonfailing remain nonfailing. Two previously failed namespaces
now load (map/update);six failed-namespace diagnostics change;181 are identical;
no newly failed namespace. Changed reasons include newly reached semantic/core
name gaps and a fuel trap, not a claim those namespaces were fixed. Full JSON
retains every ID/reason/diagnostic plus test and skip delta. Previous absence of
an assertion failure includes host or guest acceptance; it does not prove a whole
test passed. Baseline comparison is not matched isolated before/after causality,
and this does not classify all remaining M4 gaps as unrelated.

Capture uses existing200M harness stress allowance, not default10M transport
proof. Rust suite gate exit101 remains failed. No full-suite green, original M4,
#264 completion, full workspace baseline or final-head CI claim.

Source correspondence follow-up: all450 Gate3 native input SHA values independently
match committed817d48e; zero mismatches. See817-source-correspondence.json and
retained gate3-after-bootstrap-freeze.json. All921 actual producer inputs remain
retained separately; no claim that later dirty primary code produced these results.
