from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,fcntl
cache=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-raw-key-scratch')
run=cache/'native-raw-key-scratch-acceptance'
target=cache/'m4-cost-diagnostic-target'
lease=open(target/'.typed-scalar-witness.lease','w')
fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
lease.write(str(os.getpid()));lease.flush()
run.mkdir(exist_ok=False)
manifest={'base':'dc5096d49d47b36c9bfcef9ed04a530f13869190'}
paths=set(json.loads((cache/'native-fresh-class-complete-cost/before-freeze.json').read_text()))
paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
def freeze():
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snapshot(label,data):
 (run/(label+'-freeze.json')).write_text(json.dumps(data,indent=2))
 for p in data:
  dest=run/label/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,dest)
expected=freeze();assert expected==json.loads((cache/'native-raw-key-scratch-v2/terminal-freeze.json').read_text());snapshot('before',expected)
shutil.copytree(cache/'raw-key-scratch-design',run/'source-review-packet')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target))
for k in list(env):
 if k.startswith('SUSS_') and k.endswith('TRACE'):env.pop(k)
base=['cargo','test','-p','suss-compile','--locked','--lib'];tail=['--','--test-threads=1','--nocapture']
commands=[('source-domain-cohort',base+['--','--test-threads=1','--nocapture','portable_session::scalar_inputs::tests::','portable_session::write_domain::tests::','portable_session::construction_records::tests::','source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo','portable_session::storage_snapshot::tests::']),('core-import',['cargo','test','-p','suss-cli','--locked','--test','core_import']+tail),('map',['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--exact','--test-threads=1','--nocapture'])]
state={'driver_pid':os.getpid(),'root':str(root),'base':manifest['base'],'input_count':len(expected),'target':str(target),'environment':{'jobs':1,'rayon':1,'test_threads':1,'RUSTFLAGS':'inherited, not assigned'},'current':None,'stages':[],'limits':'Unchanged default quotas. Semantic gates fail-fast; original source-child terminal outcome retained separately. No whole saving inferred from prefixes.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for name,cmd in commands:
 assert freeze()==expected,'source changed before '+name
 if name=='source-domain-cohort':env['SUSS_SOURCE_CHILD_FUEL_TRACE']='1'
 if name=='map':env.pop('SUSS_SOURCE_CHILD_FUEL_TRACE',None);env.update(SUSS_CLOJURE_TEST_SUITE_CAPTURE=str(run/'map-capture'),SUSS_MACRO_FUEL_TRACE='1')
 state['current']=name;row={'name':name,'command':cmd};state['stages'].append(row);save();start=time.monotonic()
 with (run/(name+'.log')).open('w') as out:
  proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
 after=freeze();changed=[p for p in expected if expected[p]!=after[p]]
 row.update(exit=code,seconds=time.monotonic()-start,changed=changed)
 if name=='bootstrap' and code==0 and set(changed)<={f'runtime/bootstrap/{phase}.{ext}' for phase in ['macro','runtime'] for ext in ['wasm','json']}:
  expected=after;snapshot('after-bootstrap',expected)
 elif changed:
  row['unexpected_changes']=True;save();break
 save()
 if code:break
 if name in {'records','core-import','map'}:
  import re
  expected_count={'records':8,'core-import':17,'map':1}[name]
  assert re.search(r'test result: ok\. '+str(expected_count)+r' passed; 0 failed;', (run/(name+'.log')).read_text()), 'unexpected count for '+name
final=freeze();state['current']=None;state['final_changed']=[p for p,h in expected.items() if final[p]!=h];save()
snapshot('terminal',freeze())
