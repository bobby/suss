from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
root=Path('/home/bobby/Work/code/bobby/suss-m4-raw-key-scratch')
run=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/home/bobby/.cache/suss-m4-work/native-raw-key-scratch-acceptance')
sys.path.insert(0,str(root/'scripts'))
import clojure_test_suite as suite
capture=run/'map-capture/map-transport-observations.json'
refpath=root/'tests/oracle/clojure-test-suite-observations.json'
reference=json.loads(refpath.read_text());observed=json.loads(capture.read_text())
names=['clojure.core-test.map'];tests=['clojure.core-test.map/test-map']
reference.update(namespaces=names,tests=tests,
 assertions=[x for x in reference['assertions']if x['test']in tests],
 skips=[x for x in reference['skips']if x['namespace']in names])
expected=[(x['test'],x['ordinal'])for x in reference['assertions']]
actual=[(x['test'],x['ordinal'])for x in observed['assertions']]
counts,failures=suite.compare(reference,observed)
r={'selection':{'namespaces':names,'tests':tests},'counts':counts,'failures':failures,'expected_ids':expected,'actual_ids':actual,'ordered_ids_match':actual==expected,'namespace_observations':observed['namespaces'],'test_failures':observed['test-failures'],'skips':observed['skips'],'inputs':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [capture,refpath,root/'scripts/clojure_test_suite.py']},'limits':['Host-only postprocess of existing selected fullbody capture; no guest rerun','Transport/loading result is separate from independent assertion comparison','Guest-judged entries retain oracle verdict dependence; not independent operand passes','Absent/incomplete observations never credited as executed']}
(run/'map-independent-comparison.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'counts':counts,'ordered_ids_match':actual==expected,'namespace_failures':failures['namespaces'],'test_failures':observed['test-failures']}),flush=True)
if counts['fail'] or counts['not-executed'] or failures['namespaces']or failures['tests']or actual!=expected:sys.exit(1)
