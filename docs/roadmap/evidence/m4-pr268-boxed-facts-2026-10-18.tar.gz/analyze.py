from pathlib import Path
import json,re,hashlib
p=Path(__file__).parent;r=json.loads((p/'receipt.json').read_text());assert r['terminal'] and not r['final_changed'];tot=[0,0,0];stages=[]
for stage in r['stages']:
 assert not stage['changed']
 if stage['name']=='identity':continue
 matches=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', (p/(stage['name']+'.log')).read_text());assert len(matches)==1,stage['name'];counts=list(map(int,matches[0]));tot=[a+b for a,b in zip(tot,counts)];stages.append(dict(name=stage['name'],passed=counts[0],failed=counts[1],ignored=counts[2]))
assert tot==[53,4,0],tot
receipts={}
for l in (p/'public-identity.log').read_text().splitlines():
 for marker,name in [('CALLABLE_NAMESPACE_IDENTITY ','callable'),('NAMESPACE_IDENTITY ','namespace')]:
  if marker in l:
   obj=json.loads(l.split(marker,1)[1]);(p/(name+'.json')).write_text(json.dumps(obj,indent=2)+'\n');receipts[name]=obj;break
old=json.loads((p/'control/callable.json').read_text());assert receipts['callable']==old
assert sum(len(x['observations']['rows']) for x in receipts['callable']['phases'])==6
assert sum(len(x['rows']) for x in receipts['namespace']['phases'])==10
m=json.loads((p/'map-comparison.json').read_text());assert m['ordered_ids_match'] and m['counts']=={'pass':62,'guest-judged':7,'fail':0,'not-executed':0,'skipped':0,'namespaces-failed':0}
manifest=json.loads((p/'source-manifest.json').read_text());rows=dict(source='014e0f0d4072e36e6a3c9bb4e47dfcaa8553dc7f',counts=dict(passed=53,failed=4,ignored=0,unique=57),stages=stages,tracked_pre_run_files=len(manifest['files']),all_stage_inputs_unchanged=True,failures={'semantic':['public namespace sharing','public callable child identity'],'fuel':['collection projection851..882 at40M','unordered caller-&env510..531 at10M']},callable_historical_b846_equal=True,namespace_rows_decoded=10,namespace_current_identity_mismatches=104,namespace_b846_exact_control='unexecuted; no claim this patch introduced or exposed these mismatches',pinned_map=m['counts'],limitations=['no fresh upstream CLJS/Jank oracle run','full workspace baseline unexecuted while focused acceptance fails','no final-head CI success or closure/promotion'])
(p/'terminal-analysis.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows['counts']),len(manifest['files']))
