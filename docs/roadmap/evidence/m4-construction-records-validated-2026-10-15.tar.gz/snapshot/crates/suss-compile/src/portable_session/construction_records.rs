//! Construction records collected only by an explicitly recording FormBridge.
//! These audit direct facts; they are not a complete source/storage certificate.
use super::{
    ConstructorInputs, ScalarInputs, Session, SessionError, SessionValue, SourceArrayInputs,
};

pub(crate) enum Fact {
    Scalar(ScalarInputs),
    Array(SourceArrayInputs),
    Constructor(ConstructorInputs),
    ExternalSeed(&'static str),
}
pub(crate) struct Record {
    pub value: SessionValue,
    pub fact: Fact,
}
#[derive(Default)]
pub(crate) struct ConstructionRecords {
    records: Vec<Record>,
}
impl ConstructionRecords {
    pub(crate) fn push(
        &mut self,
        session: &mut Session,
        value: SessionValue,
        fact: Fact,
    ) -> Result<(), SessionError> {
        session.charge_host_work(1)?;
        if self.records.len() == self.records.capacity() {
            let count = self
                .records
                .capacity()
                .checked_mul(2)
                .ok_or_else(|| {
                    SessionError::Host(wasmtime::Error::msg(
                        "Construction record capacity overflow",
                    ))
                })?
                .max(4);
            let bytes = count
                .checked_add(self.records.len())
                .and_then(|n| n.checked_mul(std::mem::size_of::<Record>()))
                .ok_or_else(|| {
                    SessionError::Host(wasmtime::Error::msg(
                        "Construction record allocation overflow",
                    ))
                })?;
            session.charge_host_work(bytes as u64)?;
            self.records
                .try_reserve_exact(count - self.records.len())
                .map_err(|_| {
                    SessionError::Host(wasmtime::Error::msg(
                        "Construction record allocation failed",
                    ))
                })?;
        }
        self.records.push(Record { value, fact });
        Ok(())
    }
    pub(crate) fn len(&self) -> usize {
        self.records.len()
    }
    pub(crate) fn external_seeds(&self, session: &mut Session) -> Result<usize, SessionError> {
        let mut count = 0;
        for record in &self.records {
            session.charge_host_work(1)?;
            if let Fact::ExternalSeed(name) = &record.fact {
                session.charge_host_work(name.len() as u64)?;
                count += 1;
            }
        }
        Ok(count)
    }
    pub(crate) fn matches_direct_facts(&self, session: &mut Session) -> Result<bool, SessionError> {
        let _request = session.operation_budget_scope()?;
        let mut valid = true;
        for record in &self.records {
            session.charge_host_work(1)?;
            // Never short-circuit later inspection/budget/interrupt failures.
            valid &= match &record.fact {
                Fact::Scalar(fact) => fact.matches(session, &record.value)?,
                Fact::Array(fact) => fact.matches(session, &record.value)?,
                Fact::Constructor(fact) => fact.matches(session, &record.value)?,
                Fact::ExternalSeed(_) => false,
            };
        }
        Ok(valid)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn construction_records_false_seed_does_not_hide_later_fuel_error() {
        let mut session = Session::new().unwrap();
        let (value, fact) = session
            .data_scalar_with_inputs(&crate::portable::hir::Literal::Nil)
            .unwrap();
        let mut records = ConstructionRecords::default();
        records
            .push(
                &mut session,
                value.clone(),
                Fact::ExternalSeed("unverified"),
            )
            .unwrap();
        records
            .push(&mut session, value, Fact::Scalar(fact))
            .unwrap();
        let request = session.operation_budget_scope().unwrap();
        session.store.set_fuel(1).unwrap();
        let error = records.matches_direct_facts(&mut session).unwrap_err();
        assert!(
            matches!(error,SessionError::Trap(ref error) if error.downcast_ref::<wasmtime::Trap>()==Some(&wasmtime::Trap::OutOfFuel)),
            "{error:?}"
        );
        drop(request);
        assert!(!records.matches_direct_facts(&mut session).unwrap());
    }
}
