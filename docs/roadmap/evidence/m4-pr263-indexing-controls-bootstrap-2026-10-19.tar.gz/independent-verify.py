from pathlib import Path,PurePosixPath
import subprocess,json,zipfile,hashlib,struct,stat,re
P=Path(__file__).resolve().parent
ROOT=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access')
H=lambda b:hashlib.sha256(b).hexdigest()
source='a1d3c61f6c2611a21893d1bcb1ae189b1563eb0a';merge='a8151e0e91948a13b871994510a09fabdcefb76d'
def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(ROOT),*args])
def blob(path):return git('show',source+':'+path)
def uleb(data,p):
 start=p;value=0
 for shift in range(0,35,7):
  assert p<len(data);v=data[p];p+=1;value|=(v&127)<<shift
  if v<128:return value,p
 raise AssertionError('invalid section ULEB')
def sections(data):
 assert data[:8]==b'\0asm\x01\0\0\0';p=8;non=data[:8];custom=[]
 while p<len(data):
  start=p;kind=data[p];p+=1;n,p=uleb(data,p);end=p+n;assert end<=len(data)
  if kind:non+=data[start:end]
  else:
   size,q=uleb(data,p);assert q+size<=end
   custom.append({'name':data[q:q+size].decode(),'payload_sha256':H(data[q+size:end])})
  p=end
 return non,custom
api=json.loads((P/'artifact-api.json').read_text());run=json.loads((P/'run-api.json').read_text());bapi=json.loads((P/'branch-api.json').read_text());mapi=json.loads((P/'merge-api.json').read_text())
assert api['id']==12214683194 and api['workflow_run']['id']==39308835115 and api['workflow_run']['head_sha']==source
assert run['id']==39308835115 and run['head_sha']==source
assert bapi['sha']==source and mapi['sha']==merge
localtree=git('rev-parse',source+'^{tree}').decode().strip();assert bapi['commit']['tree']['sha']==mapi['commit']['tree']['sha']==localtree
assert git('rev-parse','HEAD').decode().strip()==source
assert not git('diff','HEAD','--name-only')
status=git('status','--porcelain','--untracked-files=normal').decode();assert not status,status
zbytes=(P/'artifact.zip').read_bytes();assert H(zbytes)==api['digest'].removeprefix('sha256:')=='9983d31446c408db9b5415675543e2928a866d752ce049cc90d776da8d4639cf'
z=zipfile.ZipFile(P/'artifact.zip');names=[i.filename for i in z.infolist()];assert len(names)==len(set(names))==9
expected={'receipt.json'}|{f'{part}/{phase}.{ext}' for part in ['first','second'] for phase in ['runtime','macro'] for ext in ['json','wasm']};assert set(names)==expected
for i in z.infolist():
 n=PurePosixPath(i.filename);assert not n.is_absolute() and '..' not in n.parts and not stat.S_ISLNK(i.external_attr>>16)
 assert z.read(i.filename)==(P/'files'/i.filename).read_bytes()
receipt=json.loads(z.read('receipt.json'));assert receipt['source']=={'head':merge,'tree':localtree,'working_tree_clean':True}
checks={};pairs={}
for name,entry in receipt['files'].items():
 data=z.read(name);assert H(data)==entry['sha256'] and len(data)==entry['bytes'];checks[name]={'sha256':H(data),'bytes':len(data)}
for phase in ['runtime','macro']:
 for ext in ['json','wasm']:
  n=phase+'.'+ext;assert z.read('first/'+n)==z.read('second/'+n)
 j=json.loads(z.read('first/'+phase+'.json'));old=json.loads(blob('runtime/bootstrap/'+phase+'.json'))
 assert j['phase']==phase and H(z.read('first/'+phase+'.wasm'))==j['wasm_sha256']
 ignored={'compiler_source_sha256','wasm_sha256'}
 assert {k:v for k,v in j.items() if k not in ignored}=={k:v for k,v in old.items() if k not in ignored}
 new_non,new_custom=sections(z.read('first/'+phase+'.wasm'));old_non,old_custom=sections(blob('runtime/bootstrap/'+phase+'.wasm'));assert new_non==old_non
 pairs[phase]={'reproductions_identical':True,'catalog_ABI_target_flags_source_dependencies_cells_identical':True,'noncustom_sections_identical':True,'noncustom_sha256':H(new_non),'custom_sections_new':new_custom,'custom_sections_shipped':old_custom}
build=blob('crates/suss-compile/build.rs').decode();fixed=re.findall(r'(?<![A-Za-z_])root\.join\("([^"]+)"\)',build.split('let mut files = vec![',1)[1].split('];',1)[0])
files=set(fixed+['crates/suss-compile/build.rs'])
tracked=git('ls-tree','-r','--name-only',source).decode().splitlines()
for crate in ['suss-core','suss-reader','suss-compile']:
 files.add(f'crates/{crate}/Cargo.toml')
 files.update(n for n in tracked if n.startswith(f'crates/{crate}/src/') and n.endswith(('.rs','.sus')))
hash=hashlib.sha256();inputs={}
for n in sorted(files,key=lambda value:PurePosixPath(value).parts):
 data=blob(n);enc=n.encode();hash.update(struct.pack('<Q',len(enc)));hash.update(enc);hash.update(struct.pack('<Q',len(data)));hash.update(data);inputs[n]={'git_blob':git('rev-parse',source+':'+n).decode().strip(),'sha256':H(data)}
fp=hash.hexdigest();assert len(inputs)==204 and fp=='2a05f7190c9910ef0c98c2d6275ae134991ff29c351d6e1fd93886cba2afb9e6'
for phase in ['runtime','macro']:assert json.loads(z.read('first/'+phase+'.json'))['compiler_source_sha256']==fp
log=(P/'foundation.log').read_text();assert merge in log and 'first/runtime.wasm' in log
r={'verdict':'GO_EXACT_FOUR_GENERATED_BOOT_ADOPTION_SOURCE_INTEGRITY_ONLY','source_head':source,'synthetic_checkout':merge,'source_api_merge_api_local_tree_equal':localtree,'local_source_head_clean':True,'artifact_id':api['id'],'run_id':run['id'],'zip_sha256':H(zbytes),'safe_zip_members':len(names),'eight_payload_hashes_and_sizes':checks,'four_reproduction_pairs_identical':True,'phase_catalog_and_noncustom_checks':pairs,'compiler_source_sha256':fp,'git_source_input_count':len(inputs),'git_source_input_bindings':inputs,'foundation_log_sha256':H((P/'foundation.log').read_bytes()),'scope':'Adopt ONLY files/first/{runtime,macro}.{json,wasm}, retaining exact bytes/hashes. Current CI failed stale shipped-byte comparison after generation; no new compiled_bootstrap test/library execution/link validation/acceptance credit. No Cargo/VM/binary execution or source/index/ref adoption by reviewer.'}
(P/'independent-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k in ['verdict','source_head','source_api_merge_api_local_tree_equal','zip_sha256','compiler_source_sha256','git_source_input_count','safe_zip_members']},indent=2))
