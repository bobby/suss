from pathlib import Path
import argparse,collections,hashlib,importlib.util,json,re,subprocess
C=Path('/home/bobby/.cache/suss-m4-work');BOOT=['runtime/bootstrap/'+n for n in ['macro.json','macro.wasm','runtime.json','runtime.wasm']]
spec=importlib.util.spec_from_file_location('prior',C/'pr256-compact-heads-paired-analysis/analyze.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def outcomes(text):
 rows=[];pending=None
 for i,line in enumerate(text.splitlines(),1):
  m=re.match(r'^test (\S+) \.\.\. (.*)',line)
  if m:
   assert pending is None,('unclosed test',pending)
   pending=(m[1],i);v=re.match(r'^(ok|FAILED|ignored)(?:$|,)',m[2])
   if v:rows.append({'name':pending[0],'status':v[1],'line':i});pending=None
  elif pending and line in ['ok','FAILED','ignored']:
   rows.append({'name':pending[0],'status':line,'line':pending[1],'status_line':i});pending=None
 assert pending is None
 sums=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)]
 counts=[sum(s[i] for s in sums) for i in range(3)];assert counts==[sum(x['status']==s for x in rows) for s in ['ok','FAILED','ignored']]
 assert len(rows)==len({x['name'] for x in rows})
 return rows,counts

def meta(path):
 out=[]
 for i,line in enumerate(path.read_text().splitlines(),1):
  at=line.find('metadata-')
  if at>=0:
   s=line[at:];out.append({'key':re.sub(r': \d+$',': FUEL',s),'raw':s,'line':i})
 return out

def load_candidate(p,stage,receipt,freeze):
 # Reuse tested declaration parser with a temporary cache-only adapter mapping.
 # No files changed in the executed run; adapter contains identical raw bytes.
 adapter=Path(__file__).parent/'parse-adapter'/stage;adapter.mkdir(parents=True,exist_ok=True)
 for name,data in [('receipt.json',(p/'receipt.json').read_bytes()),('manifest.json',json.dumps(freeze).encode()),(stage+'.log',(p/(stage+'.log')).read_bytes())]:
  (adapter/name).write_bytes(data)
 value=prior.load_stage(adapter,stage,True);value['log']=str(p/(stage+'.log'));value['receipt_sha256']=sha(p/'receipt.json');value['manifest_sha256']=sha(p/'post-bootstrap-freeze.json');return value

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,default=C/'pr256-private-slot-log-validation-controller');ap.add_argument('--control',type=Path,default=C/'pr256-raw-key-scratch-validation');args=ap.parse_args();p=args.run;out=Path(__file__).parent;r=read(p/'receipt.json')
 assert r.get('terminal') is True and r.get('current') is None,'WHOLE CONTROLLER LIVE: no final analysis permitted'
 assert r.get('owned_group_drained') is True and not r.get('drain_error'),'owned process drain not established'
 # Independent read-only PGID check. Ignore zombies; never signal any process.
 pgid=r.get('cargo_pid');live=[]
 for line in subprocess.check_output(['ps','-eo','pid=,pgid=,stat='],text=True).splitlines():
  parts=line.split()
  if pgid and len(parts)==3 and parts[1]==str(pgid) and not parts[2].startswith('Z'):live.append(line.strip())
 assert not live,'owned PGID still live'
 assert not r.get('error') and r.get('all_stages_executed') and r.get('unexecuted')==[],'controller incomplete/failed: inspect raw evidence instead of publication verdict'
 packet=p/'reviewed-source-packet';m=read(packet/'manifest.json');selection=read(packet/'focused-selection.json');assert sha(packet/'manifest.json')==r['source_manifest_sha256'];assert sha(packet/'candidate.patch')==m['patch_sha256']
 assert len(m['files'])==6 and selection['total_distinct_libtests']==17
 preoverlay=read(p/'before-source-freeze.json');assert all(preoverlay[n]==h for n,h in m['preimages'].items()),'base source preimage mismatch'
 before=read(p/'before-cargo-freeze.json');post=read(p/'post-bootstrap-freeze.json');terminal=read(p/'terminal-observed-freeze.json');assert post==terminal,'terminal full-input drift'
 assert set(before)==set(post) and set(k for k in before if before[k]!=post[k])<=set(BOOT)
 for n,h in m['files'].items():assert before[n]==post[n]==h==sha(p/'snapshots'/'before-bootstrap'/n)==sha(p/'snapshots'/'after-bootstrap'/n)==sha(packet/'after'/n)
 for n in BOOT:assert post[n]==sha(p/'snapshots'/'after-bootstrap'/n)
 by={s['name']:s for s in r['stages']};expected_stages={'bootstrap','identity','private-fixups','reuse','source-tags','core-environment','collection-source','pinned-map'};assert set(by)==expected_stages
 result={'base':r['base'],'source_manifest_sha256':r['source_manifest_sha256'],'patch_sha256':m['patch_sha256'],'owned_pgid_drained':True,'independent_last_pgid_scan_empty':True,'frozen_path_count':len(post),'all_source6_boot4_captured_and_bound':True,'new_module_in_before_first_cargo_freeze':'crates/suss-compile/src/portable_session/private_fixups/slot_log.rs' in before,'stages':{},'paired':{},'adverse_observations':[],'limits':['No historical4ab intervals treated as current measurements.','IRQ tests cover operation entry only, not exhaustive mid-operation interrupts.','Map RustPASS is separate from independent69-ID host comparator.','Only completed prefixes quantified; failed required tail and whole costs unknown.','Collection existing40M fixture is not default10M.','No walltime or general compatibility/fullbaseline claim.']}
 total=collections.Counter();native_names=[]
 for name,row in by.items():
  fbefore=read(p/(name+'-before-freeze.json'));fafter=read(p/(name+'-after-freeze.json'))
  if name=='bootstrap':assert set(row['changed'])<=set(BOOT) and fbefore==before and fafter==post
  else:assert row['changed']==[] and fbefore==post==fafter
  text=(p/(name+'.log')).read_text();tests,counts=outcomes(text);total.update(dict(zip(['pass','fail','ignored'],counts)))
  if name in ['private-fixups','reuse']:
   expected={n for g in selection['groups'] for n in g['names'] if (n.startswith('portable_session::private_fixups::') if name=='private-fixups' else n.startswith('portable_macro_graph::reuse::tests::'))}
   assert {x['name'] for x in tests}==expected and all(x['status']=='ok' for x in tests)
   native_names.extend(x['name'] for x in tests)
  errors=[s for s in text.splitlines() if 'Err' in s and ('Diagnostic' in s or 'Trap' in s)]
  result['stages'][name]={'exit':row['exit'],'tests':tests,'counts':counts,'errors':errors,'argv':row['argv'],'log_sha256':sha(p/(name+'.log'))}
 assert len(native_names)==len(set(native_names))==17
 result['native17_selection_exact']=True;result['execution_counts']=dict(total)
 # Original source-tags fixture must be identical in control and frozen run.
 controlfreeze=read(args.control/'manifest.json');tagpath='crates/suss-cli/tests/compiled_macro_source_tags.rs';assert controlfreeze[tagpath]==post[tagpath]
 oldtags,oldcounts=outcomes((args.control/'source-tags.log').read_text());newtags=result['stages']['source-tags']['tests'];assert {x['name'] for x in oldtags}=={x['name'] for x in newtags} and len(newtags)==2
 result['source_tags_same_fixture_sha256']=post[tagpath];result['source_tags_exact_name_comparison']=[{'name':x['name'],'control':x['status'],'candidate':next(y['status'] for y in newtags if y['name']==x['name'])} for x in oldtags]
 for stage in ['core-environment','collection-source']:
  x=prior.load_stage(args.control,stage,True);y=load_candidate(p,stage,r,post);assert x['stage_receipt']['argv']==y['stage_receipt']['argv']
  # Source equality proved independent of argv normalization.
  testpath='crates/suss-cli/tests/'+('compiled_macro_core_environment.rs' if stage=='core-environment' else 'compiled_macro_collection_source_asts.rs');assert controlfreeze[testpath]==post[testpath]
  limited={**x,'requests':x['requests'][:len(y['requests'])]};pairs=prior.pair(limited,y)
  old,new=meta(args.control/(stage+'.log')),meta(p/(stage+'.log'));n=0
  for u,v in zip(old,new):
   if u['key']!=v['key']:break
   n+=1
  order={'control':len(old),'candidate':len(new),'matched_prefix':n,'all_original_in_order':n==len(old),'entire_original_metadata_fuel_identical':len(old)==len(new) and [z['raw'] for z in old]==[z['raw'] for z in new],'first_divergence':{'control':old[n],'candidate':new[n]} if n<min(len(old),len(new)) else None}
  if n<len(old):result['adverse_observations'].append(stage+': original metadata prefix not fully reached/matched')
  if len(y['requests'])<len(x['requests']):result['adverse_observations'].append(stage+': fewer graph-start groups')
  for q in pairs:
   if q['last_common']['candidate_more_remaining']<0:result['adverse_observations'].append({'stage':stage,'request':q['id'],'last_common_fuel_delta':q['last_common']['candidate_more_remaining']})
  result['paired'][stage]={'control':x,'candidate':y,'ALL_original_metadata_order':order,'pairs':pairs,'per_group': [{'ordinal':i+1,'control_completed_declarations':a['completed_declarations'],'candidate_completed_declarations':b['completed_declarations'],'control_started':a['started_declarations'],'candidate_started':b['started_declarations'],'graph_start_fuel_unchanged':a['graph_start_fuel']==b['graph_start_fuel']} for i,(a,b) in enumerate(zip(x['requests'],y['requests']))]}
 result['bindings']={str(q):sha(q) for q in [p/'receipt.json',p/'before-cargo-freeze.json',p/'post-bootstrap-freeze.json',p/'terminal-observed-freeze.json',packet/'manifest.json',args.control/'receipt.json',args.control/'manifest.json']}
 (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'output':str(out/'summary.json'),'counts':result['execution_counts'],'tags':result['source_tags_exact_name_comparison'],'adverse_observations':result['adverse_observations']},indent=2))
if __name__=='__main__':main()
