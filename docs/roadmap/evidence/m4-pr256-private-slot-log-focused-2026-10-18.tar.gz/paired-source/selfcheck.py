import analyze,json
from pathlib import Path
fixture='''running 3 tests
test m::one ... extra printed measurement
ok
test m::two ... FAILED
test m::three ... ignored, preexisting reason

test result: FAILED. 1 passed; 1 failed; 1 ignored; 0 measured; 0 filtered out;
'''
rows,counts=analyze.outcomes(fixture);assert counts==[1,1,1] and [x['name'] for x in rows]==['m::one','m::two','m::three']
try:analyze.outcomes(fixture.replace('1 passed; 1 failed','2 passed; 1 failed'))
except AssertionError:pass
else:raise AssertionError('counts mismatch accepted')
try:analyze.outcomes('test m::unfinished ... extra output\n')
except AssertionError:pass
else:raise AssertionError('unfinished test accepted')
Path(__file__).with_name('selfcheck.json').write_text(json.dumps({'synthetic_only':True,'real_candidate_result_read':False,'checks':['interleaved measurement print retains pending fulltestname','pass/fail/ignored exactcounts','count mismatch rejects','unfinished test rejects'],'result':'PASS'},indent=2)+'\n')
print('Synthetic parser checks PASS')
