from pathlib import Path
import json,hashlib,subprocess,os,re,shutil,types,sys,tarfile
sys.dont_write_bytecode=True
P=Path(__file__).parent;C=P.parent;D=C/'pr256-private-slot-log-validation-controller';S=P/'staging';S.mkdir(exist_ok=True);BASE='4f48ea6bd7d2e198b9dd82086e4abf4e118e7a7b';REPO='/home/bobby/Work/code/bobby/suss';H=lambda b:hashlib.sha256(b).hexdigest();L=lambda p:json.loads(p.read_text());G=lambda path:subprocess.check_output(['git','-C',REPO,'show',BASE+':'+path]);BOOT=['runtime/bootstrap/'+n for n in ['macro.json','macro.wasm','runtime.json','runtime.wasm']]
r=L(D/'receipt.json');assert r['base']==BASE and r['terminal'] and r['owned_group_drained'] and r['all_stages_executed'] and not r['unexecuted'] and not r.get('error')
for pid in [r['controller_pid'],r['cargo_pid']]:
 try:os.kill(pid,0);raise AssertionError(('still live',pid))
 except ProcessLookupError:pass
stable={str(f):H(f.read_bytes()) for f in D.rglob('*') if f.is_file() and '__pycache__' not in f.parts}
def cpdir(src,label):
 for f in src.rglob('*'):
  if not f.is_file() or '__pycache__' in f.parts or f.name.endswith(('.tar.gz','.zip')):continue
  q=S/label/f.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,q)
cpdir(D,'executed-controller');cpdir(C/'pr256-private-slot-log-downport-source-v1','source-packet');cpdir(C/'pr256-private-slot-log-paired-analysis','paired-source')
m=L(D/'reviewed-source-packet/manifest.json');assert H((D/'reviewed-source-packet/manifest.json').read_bytes())==r['source_manifest_sha256'];before=L(D/'before-source-freeze.json');preboot=L(D/'before-cargo-freeze.json');post=L(D/'post-bootstrap-freeze.json');assert post==L(D/'terminal-observed-freeze.json') and len(post)==3533
assert set(k for k in preboot if preboot[k]!=post[k])<=set(BOOT)
for n,h in m['files'].items():assert preboot[n]==post[n]==h==H((D/'snapshots/after-bootstrap'/n).read_bytes())==H((D/'reviewed-source-packet/after'/n).read_bytes())
new='crates/suss-compile/src/portable_session/private_fixups/slot_log.rs';assert before[new] is None and preboot[new]==m['files'][new]
for n in BOOT:assert H((D/'snapshots/after-bootstrap'/n).read_bytes())==post[n]
# Every unchanged baseline file is independently bound to an exact Gitblob; six source/fourBOOT snapshots supply overrides.
overrides=set(m['files'])|set(BOOT);tree={}
for line in subprocess.check_output(['git','-C',REPO,'ls-tree','-r',BASE],text=True).splitlines():
 meta,path=line.split('\t',1);mode,typ,oid=meta.split();tree[path]=(typ,oid)
proc=subprocess.Popen(['git','-C',REPO,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);memo={};bindings={}
for path,h in post.items():
 if path==new:assert path not in tree;bindings[path]={'kind':'new_source_snapshot','sha256':h};continue
 typ,oid=tree[path];assert typ=='blob'
 if oid not in memo:
  proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();assert hdr[1]==b'blob';left=int(hdr[2]);d=hashlib.sha256()
  while left:
   b=proc.stdout.read(min(left,1048576));assert b;d.update(b);left-=len(b)
  assert proc.stdout.read(1)==b'\n';memo[oid]=d.hexdigest()
 assert memo[oid]==before[path],path
 if path in overrides:assert H((D/'snapshots/after-bootstrap'/path).read_bytes())==h
 else:assert memo[oid]==h,path
 bindings[path]={'kind':'retained_postimage' if path in overrides else 'unchanged_git_blob','base':BASE,'base_blob':oid,'executed_sha256':h}
proc.stdin.close();assert proc.wait()==0
(S/'SOURCE-GIT-BINDINGS.json').write_text(json.dumps({'base':BASE,'frozen_paths':3533,'all_match':True,'overrides':sorted(overrides),'new_module_before_first_Cargo':True,'bindings':bindings,'limits':'Candidate uncommitted overlay. Six exactsource + four normalBOOT snapshots and reviewedpatch supply executedpostimages. No currentroot hashes, no assumption of sourceauthority from byteequality.'},indent=2)+'\n')
# Fixed raw testcase statuses independently derive final22 names; only real failing tests interpreted as fuel.
alltests=[];fails={}
for row in r['stages']:
 t=(D/(row['name']+'.log')).read_text();tests=[];pending=None
 for line in t.splitlines():
  z=re.match(r'^test (\S+) \.\.\. (.*)',line)
  if z:
   assert pending is None;pending=z[1];v=re.match(r'^(ok|FAILED|ignored)(?:$|,)',z[2])
   if v:tests.append({'name':pending,'status':v[1]});pending=None
  elif pending and line in ['ok','FAILED','ignored']:tests.append({'name':pending,'status':line});pending=None
 assert pending is None
 sums=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)];counts=[sum(x[i] for x in sums) for i in range(3)];assert counts==[sum(x['status']==s for x in tests) for s in ['ok','FAILED','ignored']]
 if row['name']!='bootstrap':assert row['changed']==[]
 if 'tests' in row:assert tests==row['tests'] and counts==row['counts']
 chunks=re.split(r"^thread '([^']+)' .*?panicked at ([^\n]+):\s*$",t,flags=re.M)
 for i in range(1,len(chunks),3):
  n,loc,b=chunks[i:i+3]
  if n not in {x['name'] for x in tests if x['status']=='FAILED'}:continue
  b=b.split('\ntest ',1)[0];assert 'all fuel consumed' in b;st=re.search(r'Compiled macro expansion failed during ([^:]+):',b);sp=re.search(r'span:\s*(\d+\.\.\d+)',b);fails[n]={'class':'fuel','stage':st[1] if st else None,'span':sp[1] if sp else None,'panic':loc,'raw_body':b}
 alltests+=tests
assert len(alltests)==len({x['name'] for x in alltests})==22 and sum(x['status']=='ok' for x in alltests)==18 and len(fails)==4
# Map comparator and reference are from exact frozen Git4f, not changed candidate files.
for path in ['scripts/clojure_test_suite.py','scripts/oracle_compare.py','scripts/oracle_transport.py','tests/oracle/clojure-test-suite-observations.json','crates/suss-compile/tests/clojure_test_suite.rs','crates/suss-cli/tests/compiled_macro_source_tags.rs']:
 q=S/'supporting-inputs'/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(G(path));assert H(q.read_bytes())==post[path]
sp=S/'supporting-inputs/scripts/clojure_test_suite.py';sys.path.insert(0,str(sp.parent));mod=types.ModuleType('slot_suite');mod.__file__=str(sp);exec(compile(sp.read_text(),str(sp),'exec'),mod.__dict__);ref=L(S/'supporting-inputs/tests/oracle/clojure-test-suite-observations.json');act=L(D/'map-capture/map-transport-observations.json');ns='clojure.core-test.map';test=ns+'/test-map';ref.update(namespaces=[ns],tests=[test],assertions=[x for x in ref['assertions'] if x['test']==test],skips=[x for x in ref['skips'] if x['namespace']==ns]);ids=lambda a:[(x['test'],x['ordinal']) for x in a['assertions']];assert ids(act)==ids(ref) and len(ids(act))==69
cnt,details=mod.compare(ref,act);assert cnt=={'pass':62,'guest-judged':7,'fail':0,'not-executed':0,'skipped':0,'namespaces-failed':0} and not act['test-failures'] and not act['skips'] and all(not details[k] for k in ['namespaces','tests','assertions','skip-mismatches'])
comparison={'counts':cnt,'ordered_expected_ids':ids(ref),'ordered_actual_ids':ids(act),'failures':details,'capture_sha256':H((D/'map-capture/map-transport-observations.json').read_bytes()),'reference_sha256':post['tests/oracle/clojure-test-suite-observations.json'],'comparator_sha256':post['scripts/clojure_test_suite.py'],'guest_judgments_not_host_passes':True};(P/'map-independent-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');shutil.copyfile(P/'map-independent-comparison.json',S/'map-independent-comparison.json')
paired=L(P/'summary.json');assert paired['execution_counts']=={'pass':18,'fail':4,'ignored':0};shutil.copyfile(P/'summary.json',S/'paired-terminal-summary.json');shutil.copyfile(P/'analyze-paired.py',S/'analyze-paired.py');shutil.copyfile(C/'pr256-compact-heads-paired-analysis/analyze.py',S/'paired-parent-analyzer.py')
# Separate original4f scratch control only for paired-prefix reproduction; no merged totals.
for n in ['receipt.json','manifest.json','core-environment.log','collection-source.log','source-tags.log']:
 q=S/'paired-control4f'/n;q.parent.mkdir(exist_ok=True);shutil.copyfile(C/'pr256-raw-key-scratch-validation'/n,q)
core=paired['paired']['core-environment']['pairs'][0]['last_common'];coll=paired['paired']['collection-source']['pairs'][-1]['last_common'];inference=fails['compiled_source_inference_matches_pinned_tags_without_changing_executed_storage_or_effects'];assert inference['span']=='382..414'
review={'verdict':'VERIFIED_FOCUSED_PARTIAL_NOT_ACCEPTANCE','base':BASE,'executed_overlay':'reviewed6source+4BOOT exactpostimages','frozen_paths':3533,'new_module_pre_first_Cargo':True,'native':{'pass':17,'fail':0,'selection_exact':True},'counts':{'pass':18,'fail':4,'ignored':0,'unique_names':22,'unexecuted_stages':[]},'map':comparison,'failures':fails,'source_tags_inference':'Stillfuel, now latercaller&env382..414 versuscontrol324..356; no inferenceobservations/semanticfix established.','core_last_common_delta':core['candidate_more_remaining'],'collection_last_common_delta':coll['candidate_more_remaining'],'paired_adverse':paired['adverse_observations'],'limits':['IRQ controls prove tested operation-entry cuts, not exhaustive mid-operation interruption.','Collection existing40M wholefixture, CoreEnv default10M; no allowances changed.','Prefix savings are not wholefailed-request cost; allfourrequiredwitnesses remainfailed.','4f86/2 baseline and2Bdiagnostic results not merged into this candidate result.','Preparation/manifest executed=false strings are source-preparation metadata; later terminalreceipt is authoritative for execution.','No current sourcecommit binding claimed; sourcepostimages plus4fGit bind this overlay.']};(P/'independent-review.json').write_text(json.dumps(review,indent=2)+'\n');shutil.copyfile(P/'independent-review.json',S/'independent-review.json')
report=f'''# PR256 private-slot-log focused partial evidence\n\nExecuted exact4f base + reviewed6Rust overlay/normal4BOOT. Wholecontrollerterminal/drained; BOOT+identityPASS;17nativePASS(privatefixups11/reuse6)+mapwrapper1PASS,4fuelFAIL,0ignored/unexecutedstages;22distinctnames. All3533frozen inputs Git4f-bound or exact10postimages. Newslot_log included beforeFIRSTCargo, captured and recheckedallstages. Only4BOOT files changed duringnormalgeneration; no laterinputdrift. Overlay intentionally retained, not temporaryobserver.\n\nIndependentmap comparison69orderedIDs62hostPASS7guestjudged;0fail/skips/missing/test/namespacefailures. Guest outcomes remain guestjudgments.\n\nFourrequiredwitnesses remainfuelFAIL. Sourceinference nowlatercaller&env382..414 vsold324..356; invocationtagsstill388..413. CoreEnvandcollectionremainfailed. Exactnames/stages/spans raw in independent-review.json. No semanticrepair/acceptance/promotion claim.\n\nPaired against original4f scratch executedtuple only: Corelastcommon ISet checkpointdelta{core['candidate_more_remaining']}; collectionlastcommon+finished delta+{coll['candidate_more_remaining']}. Oneearliercollectiongraphgroup delta−91 preserved. Nested/repeatedgraphgroups not independentrequests; unfinishedtails/wholecostunknown. Existingcollection40M, Core10M unchanged. No walltime or wholebaseline claim.\n\n4f baseline86/2 and2Bdiagnostic keptseparate. Predecessorreceipts are gateproofs only, not extra candidatecoverage. Initialblockedcontrollerreview retained, thenexactfinalreview/17strengthenedselection. This archiveusesonly savedterminalsource/BOOT, no live-root hashing or newCargo/rootwrites.\n''';(P/'REPORT.md').write_text(report);shutil.copyfile(P/'REPORT.md',S/'REPORT.md');shutil.copyfile(P/'package.py',S/'package.py')
assert stable=={str(f):H(f.read_bytes()) for f in D.rglob('*') if f.is_file() and '__pycache__' not in f.parts}
manifest={str(f.relative_to(S)):{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size} for f in S.rglob('*') if f.is_file() and str(f.relative_to(S))!='MANIFEST.json'};(S/'MANIFEST.json').write_text(json.dumps({'schema':1,'payloads':manifest},indent=2)+'\n');out=C/'m4-pr256-private-slot-log-focused-2026-10-18.tar.gz'
with tarfile.open(out,'w:gz') as tf:
 for f in sorted(S.rglob('*')):
  if f.is_file():tf.add(f,arcname=str(f.relative_to(S)),recursive=False)
with tarfile.open(out) as tf:
 ms=tf.getmembers();assert len(ms)==len(manifest)+1==len({m.name for m in ms})
 for m in ms:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='MANIFEST.json':assert H(tf.extractfile(m).read())==manifest[m.name]['sha256']
res={'archive':str(out),'sha256':H(out.read_bytes()),'members':len(manifest)+1,'payloads':len(manifest),'bytes':out.stat().st_size,'frozen_paths':3533,'counts':[18,4,0],'native_pass':17,'map_counts':cnt,'core_prefix_delta':core['candidate_more_remaining'],'collection_prefix_delta':coll['candidate_more_remaining'],'independent_review':str(P/'independent-review.json')};(P/'package-result.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
