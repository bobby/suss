"""CACHE PREP ONLY. Production overlay intentionally retained, even after failure."""
from pathlib import Path
import argparse,os,signal,subprocess,time,json,hashlib,fcntl,re,traceback,shutil
P=Path(__file__).resolve().parent;C=P.parent;ROOT=Path('/home/bobby/Work/code/bobby/suss');SRC=C/'pr256-private-slot-log-downport-source-v1';BASE='4f48ea6bd7d2e198b9dd82086e4abf4e118e7a7b';B=C/'pr256-raw-key-scratch-workspace-baseline';PROBE=C/'pr256-coreenv-2b-completion-probe';BOOT=['runtime/bootstrap/'+n for n in ['macro.json','macro.wasm','runtime.json','runtime.wasm']]
H=lambda b:hashlib.sha256(b).hexdigest()
def read(p):
 for i in range(5):
  try:return json.loads(p.read_text())
  except json.JSONDecodeError:
   if i==4:raise
   time.sleep(.1)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def live(pid):
 if not pid:return False
 try:os.kill(pid,0);return True
 except ProcessLookupError:return False
def group_live(pgid):
 return any(x[0]==str(pgid) and not x[1].startswith('Z') for line in subprocess.check_output(['ps','-eo','pgid=,stat='],text=True).splitlines() if len(x:=line.split())==2)
def drain(child):
 if group_live(child.pid):
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 try:child.wait(timeout=10)
 except subprocess.TimeoutExpired:
  if group_live(child.pid):os.killpg(child.pid,signal.SIGKILL)
  child.wait()
 if group_live(child.pid):os.killpg(child.pid,signal.SIGKILL)
 for _ in range(100):
  if not group_live(child.pid):return
  time.sleep(.02)
 raise RuntimeError('Owned PGID not drained; manual attention required; overlay left intact')
def interrupted(s,f):raise KeyboardInterrupt('controller signal '+str(s))
def hashpaths(paths):return {n:H((ROOT/n).read_bytes()) if (ROOT/n).is_file() else None for n in paths}
def parse(t):
 out=[];pending=None
 for line in t.splitlines():
  m=re.match(r'^test (\S+) \.\.\. (.*)',line)
  if m:
   assert pending is None;pending=m[1];v=re.match(r'^(ok|FAILED|ignored)(?:$|,)',m[2])
   if v:out.append((pending,v[1]));pending=None
  elif pending and line in ['ok','FAILED','ignored']:out.append((pending,line));pending=None
 assert pending is None
 sums=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)];counts=[sum(x[i] for x in sums) for i in range(3)];assert counts==[sum(v==s for n,v in out) for s in ['ok','FAILED','ignored']]
 return out,counts

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--source-manifest-sha256',required=True);a=ap.parse_args();assert a.execute,'Not launched: explicit --execute required'
 approval=read(P/'carver-execution-review.json');assert approval['reviewer']=='Carver' and approval['approved_for_execution'] is True
 assert approval['controller_sha256']==H(Path(__file__).read_bytes()) and approval['source_manifest_sha256']==a.source_manifest_sha256
 assert H((SRC/'manifest.json').read_bytes())==a.source_manifest_sha256
 m=read(SRC/'manifest.json');sel=read(SRC/'focused-selection.json');assert approval['selection_sha256']==H((SRC/'focused-selection.json').read_bytes())
 assert m['source_base']==BASE and len(m['files'])==len(m['preimages'])==6 and set(m['files'])==set(m['preimages'])
 assert H((SRC/'candidate.patch').read_bytes())==m['patch_sha256'];assert sum(v is None for v in m['preimages'].values())==1
 assert m['preimages']['crates/suss-compile/src/portable_session/private_fixups/slot_log.rs'] is None
 patchpaths=set(re.findall(r'^\+\+\+ b/(.+)$',(SRC/'candidate.patch').read_text(),re.M));assert patchpaths==set(m['files']),'Unexpected patch paths'
 assert all(g['count']==len(g['names']) and all(n.startswith(g['prefix']) for n in g['names']) for g in sel['groups'])
 assert len({n for g in sel['groups'] for n in g['names']})==sel['total_distinct_libtests']
 for n,h in m['files'].items():assert H((SRC/'after'/n).read_bytes())==h
 lock=(P/'controller.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not (P/'receipt.json').exists(),'One-shot run: retain prior evidence; no overwrite/retry'
 r={'base':BASE,'terminal':False,'current':'waiting-for-predecessors','controller_pid':os.getpid(),'source_manifest_sha256':a.source_manifest_sha256,'stages':[],'overlay_policy':'Retain production candidate on every outcome; no automatic source/BOOT restore.'};child=None;applied=False;freeze={}
 def save():
  q=P/'receipt.tmp';q.write_text(json.dumps(r,indent=2)+'\n');q.replace(P/'receipt.json')
 def cachejson(name,d):(P/name).write_text(json.dumps(d,indent=2)+'\n')
 def snapshot(label,paths):
  for n in paths:
   f=ROOT/n
   if f.is_file():q=P/'snapshots'/label/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
 def checkfreeze():
  now=hashpaths(freeze);changed=[n for n,h in freeze.items() if now[n]!=h];assert not changed,('source/input drift',changed)
  assert git('rev-parse','HEAD').decode().strip()==BASE,'HEAD drift'
  assert set(git('ls-files').decode().splitlines())==tracked,'Tracked inventory changed'
  return changed
 signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted);save()
 try:
  while True:
   b=read(B/'receipt.json');q=read(PROBE/'receipt.json');assert b['base']==q['base']==BASE and b['pid']==1336361 and q['controller_pid']==1354974
   if not b['terminal'] and not live(1336348):raise RuntimeError('Baseline vanished without terminal receipt')
   if not q['terminal'] and not live(q['controller_pid']):raise RuntimeError('2B controller vanished without terminal receipt')
   if b['terminal'] and q['terminal'] and not any(live(x) for x in [1336348,b['pid'],q['controller_pid'],q.get('cargo_pid')]):break
   time.sleep(2)
  assert b['changed']==[] and 'exit' in b
  if q.get('production_restored') is not True:
   # A failed never-applied preflight requires explicit receipt-bound clearance; never silently skip it.
   clearance=read(P/'predecessor-clearance.json')
   assert clearance['approved_by']=='root' and clearance['reason'] and clearance['probe_receipt_sha256']==H((PROBE/'receipt.json').read_bytes())
   assert q.get('error') and not q.get('cargo_pid') and not (PROBE/'executed-source-freeze.json').exists() and not (PROBE/'execution.log').exists()
   tm=read(PROBE/'manifest.json');assert H((ROOT/tm['file']).read_bytes())==tm['original_sha256']==clearance['restored_test_sha256']
   r['failed_preflight_clearance']=clearance
  else:assert 'exit' in q and not q.get('changed') and not q.get('manual_restore_required') and not q.get('drain_error')
  cachejson('predecessor-baseline-receipt.json',b);cachejson('predecessor-2b-receipt.json',q)
  assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--name-only','HEAD').strip(),'Root not exact clean tracked4f'
  assert H((SRC/'manifest.json').read_bytes())==a.source_manifest_sha256,'Source packet changed while waiting'
  for n,h in m['preimages'].items():assert ((not (ROOT/n).exists()) if h is None else (ROOT/n).is_file() and H((ROOT/n).read_bytes())==h),n
  # Capture tracked UNION all six paths, including untracked slot_log, before first Cargo.
  tracked=set(git('ls-files').decode().splitlines());paths={n for n in tracked if (ROOT/n).is_file()}|set(m['files']);cachejson('before-source-freeze.json',hashpaths(paths));snapshot('before',list(m['files'])+BOOT)
  packet=P/'reviewed-source-packet';packet.mkdir();shutil.copyfile(SRC/'candidate.patch',packet/'candidate.patch');shutil.copyfile(SRC/'manifest.json',packet/'manifest.json');shutil.copyfile(SRC/'focused-selection.json',packet/'focused-selection.json');shutil.copyfile(P/'carver-execution-review.json',packet/'carver-execution-review.json')
  for n,h in m['files'].items():
   data=(SRC/'after'/n).read_bytes();assert H(data)==h;qpath=packet/'after'/n;qpath.parent.mkdir(parents=True,exist_ok=True);qpath.write_bytes(data)
  patch=packet/'candidate.patch';assert H(patch.read_bytes())==m['patch_sha256'];subprocess.run(['git','apply','--check',str(patch)],cwd=ROOT,check=True)
  r['current']='apply-production-overlay';save();subprocess.run(['git','apply',str(patch)],cwd=ROOT,check=True);applied=True;r['overlay_applied']=True
  assert hashpaths(m['files'])==m['files'];freeze=hashpaths(paths);assert all(h is not None for h in freeze.values());cachejson('before-cargo-freeze.json',freeze);snapshot('before-bootstrap',list(m['files'])+BOOT);(P/'applied-source.patch').write_bytes(git('diff','--binary','HEAD'))
  common={'CARGO_TARGET_DIR':'/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target','CARGO_BUILD_JOBS':'1','RAYON_NUM_THREADS':'1'}
  env=os.environ.copy();env.update(common)
  # Reject inherited diagnostic knobs capable of changing allowances, capture or execution semantics.
  assert not any(k.startswith('SUSS_') for k in os.environ),'Inherited SUSS_* environment requires reviewed explicit plan'
  def stage(name,argv,extra,expected=None,bootstrap=False,allow_fuel=False):
   nonlocal child,freeze
   checkfreeze();r['current']=name;save();cachejson(name+'-before-freeze.json',freeze);e=env.copy();e.update(extra);start=time.monotonic()
   with (P/(name+'.log')).open('w') as log:
    child=subprocess.Popen(argv,cwd=ROOT,env=e,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['cargo_pid']=child.pid;save();code=child.wait()
    if group_live(child.pid):drain(child)
    assert not group_live(child.pid);child=None
   after=hashpaths(freeze);changed=[n for n,h in freeze.items() if after[n]!=h];row={'name':name,'argv':argv,'environment_overrides':{**common,**extra},'exit':code,'seconds':time.monotonic()-start,'changed':changed};r['stages'].append(row);cachejson(name+'-after-freeze.json',after);save()
   if bootstrap:
    assert set(changed)<=set(BOOT),'Non-BOOT mutation during generation';assert hashpaths(m['files'])==m['files'];assert all(after[n] is not None for n in BOOT)
    freeze=after;cachejson('post-bootstrap-freeze.json',freeze);snapshot('after-bootstrap',list(m['files'])+BOOT)
    assert code==0,'Bootstrap failed; overlay and raw outputs retained';return
   assert not changed,'Unexpected input mutation';checkfreeze()
   if expected is not None:
    text=(P/(name+'.log')).read_text();tests,counts=parse(text);row.update(tests=[{'name':n,'status':v} for n,v in tests],counts=counts);save();assert len(tests)==len(set(n for n,v in tests)) and set(n for n,v in tests)==set(expected),'Selection anomaly';assert counts[2]==0
    if code:
     assert allow_fuel and counts[1]>0,'Native or non-fuel witness failure'
     chunks=re.split(r"^thread '([^']+)' .*?panicked at ([^\n]+):\s*$",text,flags=re.M);bodies={chunks[i]:chunks[i+2].split('\ntest ',1)[0] for i in range(1,len(chunks),3)}
     assert all('all fuel consumed' in bodies.get(n,'') for n,v in tests if v=='FAILED'),'Unknown/semantic witness failure: stop'
    else:assert counts[1]==0
   else:assert code==0,'Identity failure'
  cargo=['cargo','test','--locked'];tail=['--','--test-threads=1','--nocapture']
  stage('bootstrap',['cargo','run','--locked','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--','runtime/bootstrap'],{},bootstrap=True)
  stage('identity',['python3','scripts/verify_bootstrap_identity.py'],{})
  groups=sel['groups'];fix=[n for g in groups if g['prefix'].startswith('portable_session::private_fixups::') for n in g['names']];reuse=[n for g in groups if g['prefix']=='portable_macro_graph::reuse::tests::' for n in g['names']]
  assert fix and reuse and len(set(fix+reuse))==sel['total_distinct_libtests'] and all(g['count']==len(g['names']) for g in groups)
  stage('private-fixups',cargo+['-p','suss-compile','--lib','portable_session::private_fixups::']+tail,{},fix)
  stage('reuse',cargo+['-p','suss-compile','--lib','portable_macro_graph::reuse::tests::']+tail,{},reuse)
  stage('source-tags',cargo+['-p','suss-cli','--test','compiled_macro_source_tags']+tail,{},['compiled_source_inference_matches_pinned_tags_without_changing_executed_storage_or_effects','compiled_source_invocation_tags_distinguish_global_aggregate_and_local_methods'],allow_fuel=True)
  for name,target,test in [('core-environment','compiled_macro_core_environment','compiled_macro_core_namespace_keeps_complete_declaration_records'),('collection-source','compiled_macro_collection_source_asts','collection_source_nodes_retain_original_children_before_factory_lowering')]:
   stage(name,cargo+['-p','suss-cli','--test',target,test,'--','--exact','--test-threads=1','--nocapture'],{'SUSS_METADATA_FUEL_TRACE':'1'},[test],allow_fuel=True)
  stage('pinned-map',cargo+['-p','suss-compile','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--exact','--test-threads=1','--nocapture'],{'SUSS_CLOJURE_TEST_SUITE_CAPTURE':str(P/'map-capture')},['pinned_map_declaration_executes_without_transport_loss'])
  r['all_stages_executed']=True;checkfreeze()
 except BaseException:r['error']=traceback.format_exc();raise
 finally:
  signal.signal(signal.SIGTERM,signal.SIG_IGN);signal.signal(signal.SIGINT,signal.SIG_IGN)
  if child is not None:
   try:drain(child);r['owned_group_drained']=True
   except BaseException:r['drain_error']=traceback.format_exc()
  else:r['owned_group_drained']=True
  r['overlay_applied']=applied;r['overlay_retained']=applied;r['unexecuted']=[n for n in ['bootstrap','identity','private-fixups','reuse','source-tags','core-environment','collection-source','pinned-map'] if n not in {s['name'] for s in r['stages']}]
  if freeze:cachejson('terminal-observed-freeze.json',hashpaths(freeze))
  r.update(terminal=True,current=None);save()
 print(json.dumps(r),flush=True)
if __name__=='__main__':main()
