Prepared ONLY. No controller launch or root/source/Cargo writes.

Source packet is still evolving; no current source hash is execution-approved here. After final packet, Carver review must bind exact controller_sha256, source_manifest_sha256, selection_sha256 plus reviewer=Carver and approved_for_execution=true in carver-execution-review.json. Launch additionally requires manual --execute --source-manifest-sha256 HASH.

Wait baseline terminal+changed[] and driver1336348/Cargo1336361 absent; wait2B terminal and controller1354974/child absent and production_restored. Failed never-applied2Bpreflight requires separate root-approved receipt-bound predecessor-clearance.json and no execution artifacts, plus exact clean4f test preimage. Never silently bypass failure.

One-shot lock. Apply source overlay only after clean exact4f/preimage/absent-new-module checks. Tracked UNION six-source freeze includes new slot_log before firstCargo. Retain before/after snapshots and fullpatch. NormalBOOT allows changes onlyfourBOOT outputs; every laterphase allows no inputchanges. Native/identity/compile/selection failures stop; exact-known witness fuel failures continue. Candidate overlay/BOOT remain onfailure forreview; no automaticrestore. SIGTERM/INT drains ONLY ownedprocessgroup.

Stage order: BOOT, identity, privatefixups(parentprefix includes slotlog), reuse, original sourcetags, CoreEnv, collection, pinnedmap/capture. Expected libraryselection comes from exactreview-bound focused-selection.json. All argv/environment/exit/freezes retained. No raisedallowances or callback changes.
