from pathlib import Path
import subprocess,json,hashlib,difflib,re
root=Path('/home/bobby/Work/code/bobby/suss');out=Path(__file__).parent;base='4f48ea6bd7d2e198b9dd82086e4abf4e118e7a7b';origin='4ab8a76a48469b1138bba1dc14ad7deff5afcad6'
files=['crates/suss-compile/src/'+s for s in ['portable_macro_data.rs','portable_macro_graph.rs','portable_macro_graph/reuse.rs','portable_session.rs','portable_session/private_fixups.rs','portable_session/private_fixups/slot_log.rs']]
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
before={}
for n in files:
 p=subprocess.run(['git','show',base+':'+n],cwd=root,capture_output=True)
 if p.returncode==0:
  before[n]=p.stdout
  for folder in ['before','after']:
   q=out/folder/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.stdout)
 else:assert n.endswith('/slot_log.rs')
patch=git('diff',origin+'^',origin,'--',*files);(out/'original-4ab8a76.patch').write_bytes(patch)
p=subprocess.run(['git','apply','--check',str(out/'original-4ab8a76.patch')],cwd=out/'before',text=True,capture_output=True)
(out/'original-apply-check.json').write_text(json.dumps({'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2)+'\n');print(p.returncode,p.stderr)
# Apply only original changed hunks with minimal context trimming when old adjacent history differs.
text=patch.decode();adapt=[]
for n in files:
 if n not in before:
  q=out/'after'/n;q.parent.mkdir(parents=True,exist_ok=True);raw=git('show',origin+':'+n);(out/'original-slot_log.rs').write_bytes(raw);assert raw.count(b'mem::size_of::<Self>() + 2 * mem::size_of::<usize>()')==1;raw=raw.replace(b'mem::size_of::<Self>() + 2 * mem::size_of::<usize>()',b'mem::size_of::<RefCell<Self>>() + 2 * mem::size_of::<usize>()');q.write_bytes(raw);continue
 section=next(x for x in text.split('diff --git ') if x.startswith('a/'+n+' b/'+n+'\n'))
 s=before[n].decode()
 for idx,part in enumerate(re.split(r'^@@[^\n]*\n',section,flags=re.M)[1:]):
  lines=[x for x in part.splitlines(True) if x[:1] in (' ','+','-')]
  old=''.join(x[1:] for x in lines if x[0]!='+');new=''.join(x[1:] for x in lines if x[0]!='-')
  if old and s.count(old)==1:s=s.replace(old,new,1);continue
  pre=0
  while pre<len(lines) and lines[pre][0]==' ':pre+=1
  post=0
  while post<len(lines)-pre and lines[-1-post][0]==' ':post+=1
  found=False
  for cut in range(pre+post+1):
   for l in range(pre+1):
    rr=cut-l
    if not 0<=rr<=post:continue
    subset=lines[l:len(lines)-rr if rr else None];old=''.join(x[1:] for x in subset if x[0]!='+');new=''.join(x[1:] for x in subset if x[0]!='-')
    if old and s.count(old)==1:
     s=s.replace(old,new,1);adapt.append({'path':n,'hunk':idx,'leading_context_trimmed':l,'trailing_context_trimmed':rr,'original_changed_lines_unchanged':True});found=True;break
   if found:break
  assert found,(n,idx)
 (out/'after'/n).write_text(s)
# Compute a complete current-base proposal, including the new module.
candidate='';sha=lambda b:hashlib.sha256(b).hexdigest()
for n in files:
 old=before.get(n,b'');new=(out/'after'/n).read_bytes()
 candidate+=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+n if n in before else '/dev/null',tofile='b/'+n))
(out/'candidate.patch').write_text(candidate)
manifest={'source_base':base,'origin_commit':origin,'preimages':{n:sha(before[n]) if n in before else None for n in files},'files':{n:sha((out/'after'/n).read_bytes()) for n in files},'patch_sha256':sha(candidate.encode()),'original_delta_sha256':sha(patch),'adaptations':adapt+[{'path':files[-1],'change':'prepay actual RefCell<Self> allocation extent, including borrow-state word; original omitted this word'}],'new_module_byte_exact_origin':(out/'after'/files[-1]).read_bytes()==git('show',origin+':'+files[-1]),'executed':False}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
check=subprocess.run(['git','apply','--check',str(out/'candidate.patch')],cwd=out/'before',capture_output=True,text=True);(out/'apply-check.json').write_text(json.dumps({'returncode':check.returncode,'stdout':check.stdout,'stderr':check.stderr},indent=2)+'\n');assert check.returncode==0,check.stderr
# Extract all actual focused test declarations from retained/new test modules.
tests=[]
for n in files:
 old=before.get(n,b'').decode();new=(out/'after'/n).read_text()
 for name in re.findall(r'#\[test\]\s*fn\s+(\w+)',new):
  if name not in re.findall(r'#\[test\]\s*fn\s+(\w+)',old):tests.append({'path':n,'test':name})
(out/'new-tests.json').write_text(json.dumps(tests,indent=2)+'\n')
print(json.dumps(manifest,indent=2));print('new tests',tests)
