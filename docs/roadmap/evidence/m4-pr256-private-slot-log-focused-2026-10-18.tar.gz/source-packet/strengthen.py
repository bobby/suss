from pathlib import Path
p=Path(__file__).parent
rel='crates/suss-compile/src/portable_session/private_fixups/slot_log.rs';q=p/'after'/rel;s=q.read_text()
addition=r'''
    fn physical_slot_is(s: &mut Session, array: &SessionValue, index: u32, expected: &SessionValue) -> bool {
        s.inspect(array, |mut store, array| {
            let array = array.unwrap_anyref().unwrap().as_array(&store)?.unwrap();
            let actual = array.get(&mut store, index)?.unwrap_anyref().copied().unwrap();
            let expected = expected.value.to_rooted(&mut store);
            Ok(Rooted::ref_eq(&store, &actual, &expected)?)
        }).unwrap()
    }
    fn two_slot_fixture(s: &mut Session, capture: bool)
        -> (SharedSlotLog, SessionValue, SessionValue, Vec<(u32, usize)>)
    {
        let log = PrivateSlotLog::new(s).unwrap();
        let token = log.borrow_mut().token(s, 0).unwrap();
        let selected = log.borrow().inputs(s, &[&token, &token]).unwrap();
        let parent = s.data_array(&[&token, &token]).unwrap();
        if capture { log.borrow_mut().capture_dense(s, &parent, 2, &selected).unwrap(); }
        (log, token, parent, selected)
    }
    #[test]
    fn private_slot_log_late_poison_rejects_before_any_earlier_slot_write() {
        let mut s = Session::new_macro().unwrap();
        let op = s.operation_budget_scope().unwrap();
        let replacement = number(&mut s, 17.0);
        let (log, token, parent, _) = two_slot_fixture(&mut s, true);
        let physical = log.borrow().slots[0].array.clone();
        assert_eq!(log.borrow().slots.len(), 2);
        assert!(physical_slot_is(&mut s, &physical, 0, &token));
        // Poison the LATER physical slot after successful complete capture.
        set_slot(&mut s, &physical, 1, &replacement);
        s.collect().unwrap();
        let error = log.borrow().apply(&mut s, &parent, &[(&token, &replacement)]).unwrap_err();
        assert!(matches!(error, SessionError::Host(_)), "{error:?}");
        // Staging must reject before writing even the earlier valid location.
        assert!(physical_slot_is(&mut s, &physical, 0, &token));
        assert!(physical_slot_is(&mut s, &physical, 1, &replacement));
        set_slot(&mut s, &physical, 1, &token);
        assert_eq!(log.borrow().apply(&mut s, &parent, &[(&token, &replacement)]).unwrap(), 2);
        assert!(physical_slot_is(&mut s, &physical, 0, &replacement));
        assert!(physical_slot_is(&mut s, &physical, 1, &replacement));
        drop(op);
    }
    fn measured_operation(s: &mut Session, capture: bool) -> u64 {
        let op = s.operation_budget_scope().unwrap();
        let replacement = number(s, 17.0);
        let (log, token, parent, selected) = two_slot_fixture(s, !capture);
        let before = s.operation_fuel_remaining().unwrap();
        if capture {
            log.borrow_mut().capture_dense(s, &parent, 2, &selected).unwrap();
        } else {
            assert_eq!(log.borrow().apply(s, &parent, &[(&token, &replacement)]).unwrap(), 2);
        }
        let cost = before - s.operation_fuel_remaining().unwrap();
        drop(op);
        cost
    }
    #[test]
    fn private_slot_log_every_small_capture_apply_fuel_cut_discards_private_state_and_recovers() {
        let mut s = Session::new_macro().unwrap();
        let leaf = number(&mut s, 91.0);
        let public_source = s.data_array(&[&leaf]).unwrap();
        let get = s.eval("(fn [a] (aget a 0))").unwrap();
        for capture in [true, false] {
            let cost = measured_operation(&mut s, capture);
            let handles = s.stats().external_value_handles;
            let mut failures = 0;
            for allowance in 0..=cost {
                let op = s.operation_budget_scope().unwrap();
                let (log, token, parent, selected) = two_slot_fixture(&mut s, !capture);
                s.store.set_fuel(allowance).unwrap();
                let result = if capture {
                    log.borrow_mut().capture_dense(&mut s, &parent, 2, &selected)
                } else {
                    log.borrow().apply(&mut s, &parent, &[(&token, &public_source)]).map(|_| ())
                };
                // Apply target is an owned public array rather than the numeric
                // measuring target; its payload is never traversed or written.
                match result {
                    Ok(()) => assert_eq!(allowance, cost, "unexpected earlier success capture={capture} allowance={allowance} cost={cost}"),
                    Err(error) => {
                        failures += 1;
                        assert!(matches!(error, SessionError::Trap(ref error)
                            if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)),
                            "capture={capture} allowance={allowance}: {error:?}");
                    }
                }
                drop(op);
                // Any private write-prefix is intentionally discarded: there
                // is NO all-or-nothing guarantee for WRITE-phase interruption.
                drop(selected); drop(parent); drop(token); drop(log);
                assert_eq!(s.stats().external_value_handles, handles);
                let observed = s.invoke(&get, &[&public_source]).unwrap();
                assert!(same_value(&mut s, &observed, &leaf));
                drop(observed);
                let retry = s.operation_budget_scope().unwrap();
                let (log, token, parent, selected) = two_slot_fixture(&mut s, false);
                log.borrow_mut().capture_dense(&mut s, &parent, 2, &selected).unwrap();
                assert_eq!(log.borrow().apply(&mut s, &parent, &[(&token, &public_source)]).unwrap(), 2);
                drop(selected); drop(parent); drop(token); drop(log); drop(retry);
                assert_eq!(s.stats().external_value_handles, handles);
            }
            assert_eq!(failures, cost, "all insufficient integer allowances must fail capture={capture}");
            // Deterministic IRQ at operation entry, after budget installation.
            // This is NOT an exhaustive mid-operation IRQ-boundary sweep.
            let op = s.operation_budget_scope().unwrap();
            let (log, token, parent, selected) = two_slot_fixture(&mut s, !capture);
            s.interrupt_handle().interrupt();
            let error = if capture {
                log.borrow_mut().capture_dense(&mut s, &parent, 2, &selected).unwrap_err()
            } else {
                log.borrow().apply(&mut s, &parent, &[(&token, &public_source)]).unwrap_err()
            };
            assert!(error.is_interrupt(), "{error:?}");
            drop(op); drop(selected); drop(parent); drop(token); drop(log);
            assert_eq!(s.stats().external_value_handles, handles);
            let retry = s.operation_budget_scope().unwrap();
            let (log, token, parent, selected) = two_slot_fixture(&mut s, true);
            assert_eq!(log.borrow().apply(&mut s, &parent, &[(&token, &public_source)]).unwrap(), 2);
            drop(selected); drop(parent); drop(token); drop(log); drop(retry);
            s.collect().unwrap();
            let observed = s.invoke(&get, &[&public_source]).unwrap();
            assert!(same_value(&mut s, &observed, &leaf));
            drop(observed);
            assert_eq!(s.stats().external_value_handles, handles);
            eprintln!("private-slot-cuts capture={capture} measured={cost} insufficient-allowances={failures} irq=entry-only");
        }
    }
'''
anchor='\n}\n\nimpl PrivateSlotLog {';assert s.count(anchor)==1;s=s.replace(anchor,addition+anchor);q.write_text(s)
# Add explicit incomplete-flag loggedbridge route while keeping all old effect assertions.
q=p/'after/crates/suss-compile/src/portable_macro_graph/reuse.rs';s=q.read_text()
anchor='    fn rebuild_callback_routes(logged: bool) {\n'
new='''    #[test]
    fn reuse_incomplete_logged_parent_falls_back_to_walker_with_callback_outputs_preserved() {
        rebuild_callback_routes_with_incomplete(true, true);
    }
    fn rebuild_callback_routes(logged: bool) {
        rebuild_callback_routes_with_incomplete(logged, false);
    }
    fn rebuild_callback_routes_with_incomplete(logged: bool, incomplete: bool) {
'''
assert s.count(anchor)==1;s=s.replace(anchor,new)
anchor='            assert_eq!(build.logged_parent_route, logged);\n'
extra='''            if incomplete {
                assert!(build.logged_parent_route);
                build.note_slot_route(graph.session, false).unwrap();
                assert!(!build.slots.borrow().complete());
            }
'''
assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra);q.write_text(s)
