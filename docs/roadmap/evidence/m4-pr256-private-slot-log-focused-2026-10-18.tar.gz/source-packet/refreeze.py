from pathlib import Path
import json,re,hashlib,difflib,subprocess
p=Path(__file__).parent;m=json.loads((p/'manifest.json').read_text());patch='';sha=lambda b:hashlib.sha256(b).hexdigest()
for n in m['files']:
 old=(p/'before'/n).read_bytes() if m['preimages'][n] is not None else b'';new=(p/'after'/n).read_bytes();patch+=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+n if m['preimages'][n] is not None else '/dev/null',tofile='b/'+n));m['files'][n]=sha(new)
m['patch_sha256']=sha(patch.encode());m['revision']='v2 semantic-test strengthening';m['prestrengthening_packet']='../pr256-private-slot-log-downport-source-prestrengthening';m['prestrengthening_patch_sha256']='1c6b86fcd4b324d8603a63fe49568430a8892982b86dfcd29912862978dce3b5';m['tests_executed']=False
(p/'candidate.patch').write_text(patch);(p/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
check=subprocess.run(['git','apply','--check',str(p/'candidate.patch')],cwd=p/'before',capture_output=True,text=True);assert check.returncode==0,check.stderr;(p/'apply-check.json').write_text(json.dumps({'returncode':check.returncode,'stdout':check.stdout,'stderr':check.stderr},indent=2)+'\n')
oldpacket=p.parent/'pr256-private-slot-log-downport-source-prestrengthening';production_same={}
for n in m['files']:
 old=(oldpacket/'after'/n).read_text();new=(p/'after'/n).read_text()
 if n.endswith('/slot_log.rs'):
  # Strip test module, retain all production definitions byte-exact.
  def prod(s):return s[:s.index('#[cfg(test)]')]+s[s.index('\nimpl PrivateSlotLog {'):]
  production_same[n]=prod(old)==prod(new)
 elif n.endswith('/reuse.rs'):production_same[n]=old.split('#[cfg(test)]')[0]==new.split('#[cfg(test)]')[0]
 else:production_same[n]=old==new
assert all(production_same.values());(p/'production-unchanged-vs-prestrengthening.json').write_text(json.dumps(production_same,indent=2)+'\n')
groups=[];newtests=[]
for n,prefix in [('crates/suss-compile/src/portable_macro_graph/reuse.rs','portable_macro_graph::reuse::tests::'),('crates/suss-compile/src/portable_session/private_fixups.rs','portable_session::private_fixups::tests::'),('crates/suss-compile/src/portable_session/private_fixups/slot_log.rs','portable_session::private_fixups::slot_log::tests::')]:
 names=re.findall(r'#\[test\]\s*fn\s+(\w+)',(p/'after'/n).read_text());groups.append({'prefix':prefix,'count':len(names),'names':[prefix+x for x in names]});before=(p/'before'/n).read_text() if (p/'before'/n).exists() else '';prior=set(re.findall(r'#\[test\]\s*fn\s+(\w+)',before));newtests.extend({'path':n,'test':x} for x in names if x not in prior)
(p/'new-tests.json').write_text(json.dumps(newtests,indent=2)+'\n');(p/'focused-selection.json').write_text(json.dumps({'compile_and_bootstrap_executed':False,'groups':groups,'total_distinct_libtests':sum(g['count'] for g in groups),'unchanged_original_cli_target':'compiled_macro_source_tags','normalbootstrap_before_Sessiontests_required':True,'irq_limit':'operation-entry IRQ only; no exhaustive mid-operation IRQ injection claimed','fuel_limit':'all integer allowances0..measured capture/apply work, two-slot graph, discard each private attempt'},indent=2)+'\n');print(json.dumps({'patch_sha256':m['patch_sha256'],'files':m['files'],'total_libtests':sum(g['count'] for g in groups)},indent=2))
