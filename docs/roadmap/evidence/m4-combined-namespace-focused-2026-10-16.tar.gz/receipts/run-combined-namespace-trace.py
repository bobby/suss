from pathlib import Path
import json,hashlib,time,subprocess,os
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-literal-memos')
parent=json.loads((c/'combined-namespace-focused-result.json').read_text())
assert parent['current'] is None and parent['source_unchanged']
assert any(x['name']=='source-tags' and x['exit']!=0 for x in parent['stages']), 'No failed source-tag stage; trace unnecessary'
freeze=parent['freeze'];assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items())
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'),SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1')
cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_source_tags','compiled_source_invocation_tags_distinguish_global_aggregate_and_local_methods','--','--exact','--nocapture','--test-threads=1']
s={'base':'37991e3+nine-routes+c4-test','command':cmd,'current':'trace','freeze':freeze,'interpretation':'Unchanged production source, shipped bootstrap and default fuel. Existing stage trace toggles only; no receiver instrumentation or added guest hash calls. Remaining-fuel readings are raw inclusive stage breadcrumbs, not additive exclusive cost. Compare actual failure stage/span with untraced cohort.'};out=c/'combined-namespace-trace-result.json';out.write_text(json.dumps(s,indent=2)+'\n');start=time.time()
with (c/'combined-namespace-trace.log').open('w') as log:result=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
s.update(current=None,exit=result.returncode,seconds=time.time()-start,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items()));out.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='freeze'},indent=2))
