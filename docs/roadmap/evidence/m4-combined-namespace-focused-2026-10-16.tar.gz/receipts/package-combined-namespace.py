from pathlib import Path
import hashlib,json,subprocess,tarfile,io
r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-literal-memos');c=Path('/home/bobby/.cache/suss-m4-work');s=json.loads((c/'combined-namespace-focused-result.json').read_text());assert s['current'] is None and s['source_unchanged'];payload={}
for f,h in s['freeze'].items():
 b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+f]=b
extra=['Cargo.toml','Cargo.lock','crates/suss-core/Cargo.toml','crates/suss-reader/Cargo.toml','crates/suss-compile/Cargo.toml','crates/suss-cli/Cargo.toml','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','runtime/core-import/LICENSE','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json','vendor/wasi/wasi-wit-0.3.1/cli/cli.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit']
for f in extra:assert (r/f).is_file();payload['snapshot/'+f]=(r/f).read_bytes()
paths=[f for f in s['freeze'] if f=='crates/suss-compile/build.rs' or any(f.startswith('crates/'+n+'/src/') and f.endswith(('.rs','.sus')) for n in ['suss-core','suss-reader','suss-compile'])]+extra[:5]+extra[9:];h=hashlib.sha256()
for f in sorted(set(paths),key=lambda p:tuple(p.split('/'))):
 b=payload['snapshot/'+f];n=f.encode();h.update(len(n).to_bytes(8,'little'));h.update(n);h.update(len(b).to_bytes(8,'little'));h.update(b)
checks={}
for phase in ['macro','runtime']:
 m=json.loads(payload[f'snapshot/runtime/bootstrap/{phase}.json']);checks[phase]={'compiler':h.hexdigest()==m['compiler_source_sha256'],'core':hashlib.sha256(payload['snapshot/runtime/core-import/suss/core.sus']).hexdigest()==m['source_sha256'],'dependencies':hashlib.sha256(payload['snapshot/runtime/core-import/manifest.json']).hexdigest()==m['dependency_graph_sha256'],'wasm':hashlib.sha256(payload[f'snapshot/runtime/bootstrap/{phase}.wasm']).hexdigest()==m['wasm_sha256']}
assert all(all(v.values()) for v in checks.values()),checks
for receipt in ['combined-namespace-trace-result.json','combined-namespace-scoped-result.json']:
 d=json.loads((c/receipt).read_text());assert d['current'] is None and d['source_unchanged'] and d['freeze']==s['freeze']
for p in c.glob('combined-namespace-*'):
 if p.is_file() and 'package-result' not in p.name:payload['receipts/'+p.name]=p.read_bytes()
for p in (c/'combined-namespace-keyword-observations').glob('*'):
 if p.is_file():payload['observations/'+p.name]=p.read_bytes()
for name in ['run-combined-namespace-focused.py','run-combined-namespace-scoped.py','run-combined-namespace-trace.py','package-combined-namespace.py']:
 payload['receipts/'+name]=(c/name).read_bytes()
for f in ['scripts/clojure_test_suite.py','tests/oracle/clojure-test-suite-observations.json','vendor/clojure-test-suite/upstream/test/clojure/core_test/keyword.cljc']:
 payload['support/'+f]=(r/f).read_bytes()
payload['change.patch']=subprocess.check_output(['git','diff','37991e3','--','crates'],cwd=r)
for f in ['crates/suss-compile/src/portable/hir/quotes.rs','crates/suss-compile/src/portable_macro_data.rs','crates/suss-compile/src/portable_macro_graph/canonical_entries.rs','crates/suss-compile/src/portable_macro_graph/raw_keys.rs']:
 assert subprocess.check_output(['git','show','37991e3:'+f],cwd=r)==(r/f).read_bytes(),f
payload['audit.json']=json.dumps({'base':'37991e3','components':['483f26a nine namespace literal routes','c4bcd64 actual-env effect unit regression'],'parent_archive_sha256':'6580853319dd21126235678814e97d29ee744eb2c2ce0b172a6d862845fc0adb','freeze_count':len(s['freeze']),'fingerprints':checks,'stages':s['stages'],'scope':'Native7,CLIenv2,keyword1(60host),scoped13 pass; both unchanged source-tags fail defaultfuel. Same-source existingstage trace reproduces invocation failure. No new map execution, original six preservation rerun, full baseline or final-head CI on this source; parent outcomes retained separately not promoted.','authority':'Nine construction-site literal annotations only. Cold Suss/source/dynamic controls, compiled constant route, originally-nil receipt and source/storage authority unchanged; current paged canonical entries retained.','source_review':'Cicero source-integration no blockers; component Carver source/evidence reviews available independently. Final artifact/committed-head review pending.','support_inputs_capture':'Supporting fingerprint/comparator inputs captured after execution, not independently pre-frozen. Complete Rust/Suss/bootstrap source frozen before/after execution.','next':'Measure actual remaining memo-ledger work before selecting any further optimization. No speculative broader warming or quota/tariff change.'},indent=2).encode()
manifest={f:hashlib.sha256(b).hexdigest() for f,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode();out=r/'docs/roadmap/evidence/m4-combined-namespace-focused-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f,b in sorted(payload.items()):
  info=tarfile.TarInfo(f);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:
 for f,h in manifest.items():assert hashlib.sha256(t.extractfile(f).read()).hexdigest()==h,f
result={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'freeze_count':len(s['freeze']),'fingerprints':checks}
(c/'combined-namespace-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
