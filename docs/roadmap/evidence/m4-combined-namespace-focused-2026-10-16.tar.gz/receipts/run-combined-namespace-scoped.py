from pathlib import Path
import os,json,time,subprocess,hashlib
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-literal-memos');parent=json.loads((c/'combined-namespace-focused-result.json').read_text());assert parent['current'] is None and parent['source_unchanged'];freeze=parent['freeze'];assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items())
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'))
cmd=['cargo','test','-p','suss-compile','--lib','--locked','scoped_memo_stores','--','--test-threads=2','--nocapture'];state={'current':'scoped','command':cmd,'freeze':freeze};out=c/'combined-namespace-scoped-result.json';out.write_text(json.dumps(state,indent=2)+'\n');start=time.time()
with (c/'combined-namespace-scoped.log').open('w') as log:result=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
state.update(current=None,exit=result.returncode,seconds=time.time()-start,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items()));out.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({k:v for k,v in state.items() if k!='freeze'},indent=2))
