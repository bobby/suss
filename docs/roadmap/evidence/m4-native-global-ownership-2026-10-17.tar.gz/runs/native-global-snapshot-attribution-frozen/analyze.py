#!/usr/bin/env python3
"""Read-only trace parser. Output JSON on stdout; no compiler/guest execution.
Scope: one selected test, no concurrent trace writers; nested intervals use a
stack and are not summed twice. Failed/unexecuted branches remain explicit.
"""
from pathlib import Path
import collections, hashlib, json, re, sys
ROOT=Path('/home/bobby/.cache/suss-m4-work')
current=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'native-global-ownership-candidate/source-child.log'
baseline=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'native-fuel-third-repairs/source-child.log'

def read(path):
    data=path.read_bytes()
    return data.decode().splitlines(), hashlib.sha256(data).hexdigest()
def snapshot_event(line):
    m=re.search(r'source-snapshot phase=(\S+) count=(\d+) event=(before|after).*remaining=(?:Some\((\d+)\)|None)',line)
    if m:
        phase,count,event,fuel=m.groups()
        return phase,int(count),event,None if fuel is None else int(fuel)
    m=re.search(r'source-snapshot-atom event=(before|after).*remaining=(?:Some\((\d+)\)|None)',line)
    if m:
        event,fuel=m.groups()
        return 'atom',1,event,None if fuel is None else int(fuel)
    return None

def selected(lines):
    a=next(i for i,l in enumerate(lines) if 'source=Runtime variant=Some(0) stage=materialize:before' in l)
    b=next(i for i in range(a+1,len(lines)) if 'source=Runtime variant=Some(0) stage=materialize result=Ok(())' in lines[i])
    return a,b

def budget(lines):
    a,b=selected(lines)
    fuel=lambda l:int(re.search(r'remaining=Some\((\d+)\)',l)[1])
    stack=[]; agg=collections.defaultdict(lambda:[0,0])
    for l in lines[a+1:b]:
        m=re.search(r'source-materialize-call label=(\S+) event=(before|after).*remaining=Some\((\d+)\)',l)
        if not m:continue
        label,event,f=m.groups();f=int(f)
        if event=='before':stack.append((label,f))
        else:
            old,start=stack.pop();assert old==label
            agg[label][0]+=1;agg[label][1]+=start-f
    assert not stack
    stages={}
    for l in lines[:b+1]:
        m=re.search(r'source-child-fuel source=Runtime variant=(None|Some\(0\)) stage=(\S+).*remaining=Some\((\d+)\)',l)
        if m:stages[m[1]+'/'+m[2]]=int(m[3])
    return {'materialization_fuel':fuel(lines[a])-fuel(lines[b]),'bridge_intervals':dict(agg),'boundary_remaining':stages}

lines,sha=read(current)
# Validate every snapshot interval in the complete raw log, not only variant0.
stack=[];paired=collections.Counter();errors=[]
for number,line in enumerate(lines,1):
    event=snapshot_event(line)
    if not event:continue
    phase,count,kind,fuel=event
    if kind=='before':stack.append((phase,count,number))
    else:
        assert stack,('unopened-after',number)
        old=stack.pop();assert old[:2]==(phase,count),(number,old,line)
        paired[phase]+=1
        if 'result=Err' in line:errors.append({'line':number,'phase':phase})
assert not stack,stack
# Constructor enrollment captures only, within completed Runtime variant0.
a,b=selected(lines);active=False;st=[];agg=collections.defaultdict(lambda:[0,0,0]);cuts=collections.Counter();summaries=collections.Counter();alloc=collections.defaultdict(lambda:[0,0]);atom_types=collections.Counter();captured_fuel=0;capture_count=0
for line in lines[a+1:b]:
    m=re.search(r'source-domain-record .*fact=Constructor phase=snapshot-capture event=(before|after).*remaining=Some\((\d+)\)',line)
    if m:
        event,f=m.groups();f=int(f)
        if event=='before':
            assert not active
            active=True;start_capture=f
        else:
            assert active and not st
            active=False;capture_count+=1;captured_fuel+=start_capture-f
    if not active:continue
    event=snapshot_event(line)
    if event:
        phase,count,kind,fuel=event;assert fuel is not None
        if kind=='before':st.append([phase,count,fuel,0])
        else:
            old,n,start,children=st.pop();assert(old,n)==(phase,count)
            cost=start-fuel
            assert cost>=children
            agg[phase][0]+=1;agg[phase][1]+=cost;agg[phase][2]+=cost-children
            if st:st[-1][3]+=cost
            if phase=='atom':atom_types[re.search(r'kind=(\S+)',line)[1]]+=1
    m=re.search(r'source-snapshot-cuts input=(\d+) dedup=(\d+) complete=(\w+)',line)
    if m:cuts[m.groups()]+=1
    m=re.search(r'source-snapshot-summary input_cuts=(\d+) nodes=Some\((\d+)\) complete=(\w+)',line)
    if m:summaries[m.groups()]+=1
    m=re.search(r'source-snapshot-allocation type=(\S+) count=(\d+) element_bytes=(\d+) requested_bytes=(\d+)',line)
    if m:
        name,count,size,bytes_=m.groups()
        alloc[name.split('::')[-1]][0]+=1;alloc[name.split('::')[-1]][1]+=int(bytes_)
assert not active and not st
assert sum(agg[p][2] for p in agg)==agg['add-cuts'][1]+agg['finish'][1]
old,oldsha=read(baseline);newbudget=budget(lines);oldbudget=budget(old)
result={
 'scope':'Completed Runtime-source variant0 materialization; actual transport is Macro store. Nested interval totals are NOT additive; exclusive totals are disjoint.',
 'raw':str(current),'raw_sha256':sha,'baseline_raw':str(baseline),'baseline_raw_sha256':oldsha,
 'baseline_qualification':'Prior tested trace used for 14c2 cost comparison; this comparison does not independently certify every historical source fingerprint.',
 'all_log_snapshot_pairing':{'counts':dict(paired),'unmatched':[],'error_rows':errors},
 'constructor_snapshot_capture':{'count':capture_count,'fuel':captured_fuel,
  'owner_setup_outside_add_cuts_and_finish':captured_fuel-agg['add-cuts'][1]-agg['finish'][1],
  'phase_count_inclusive_exclusive':{k:{'count':v[0],'inclusive':v[1],'exclusive':v[2]} for k,v in agg.items()},
  'cuts':[{'input':int(i),'dedup':int(d),'complete':c=='true','captures':n} for (i,d,c),n in sorted(cuts.items())],
  'nodes':[{'input_cuts':int(i),'nodes':int(d),'complete':c=='true','captures':n} for (i,d,c),n in sorted(summaries.items())],
  'allocations':{k:{'debits':v[0],'requested_allocation_and_relocation_bytes':v[1]} for k,v in alloc.items()},
  'atom_results':dict(atom_types)},
 'budget_comparison':{'before':oldbudget,'after':newbudget,
  'materialization_delta':newbudget['materialization_fuel']-oldbudget['materialization_fuel'],
  'bridge_fuel_deltas':{k:newbudget['bridge_intervals'][k][1]-v[1] for k,v in oldbudget['bridge_intervals'].items()}},
 'coverage':{'completed_variants':[0,1,2],'failure':'Runtime-source variant3 materialization: Wasm OutOfFuel, remaining0; trace names wasm functions439/186/390.',
 'unexecuted':['Runtime-source variant3 finish','Runtime-source variant4','physical-lineage negative tail','forged-memo negative tail','all Macro-source owner iterations']},
 'limits':['Single selected test; trace logging wall time is not fuel attribution.',
 'Constructor snapshot captures are not complete source certificates by themselves.',
 'Index insertion totals include AVL allocation/rebalancing; those internal components are not separately measured.',
 'No linear-cut algorithm, node-index change, quota change or acceptance result is claimed.']}
print(json.dumps(result,indent=2))
