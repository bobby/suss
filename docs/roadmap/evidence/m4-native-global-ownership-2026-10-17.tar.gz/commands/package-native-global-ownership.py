from pathlib import Path
import json,hashlib,tarfile,io
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');run=cache/'native-global-ownership-candidate'
state=json.loads((run/'receipt.json').read_text());assert state['current'] is None,'Do not package a live cohort'
assert state['final_changed']==[]
files={};tuples={};sha=lambda b:hashlib.sha256(b).hexdigest()
for label in ['before','after-bootstrap']:
 frozen=json.loads((run/(label+'-freeze.json')).read_text());tuples[label]=frozen
 for rel,digest in frozen.items():
  data=(run/label/rel).read_bytes();assert sha(data)==digest
  files['inputs/'+digest]=data
for directory in ['native-global-ownership-candidate','native-global-compile-pilot-1','native-global-compile-pilot-2','native-global-core-oracle','native-global-core-oracle-2','native-global-foundation','native-global-snapshot-attribution-frozen']:
 base=cache/directory
 for path in base.rglob('*'):
  if path.is_file() and (directory!='native-global-ownership-candidate' or path.relative_to(base).parts[0] not in ['before','after-bootstrap']):
   files['runs/'+directory+'/'+str(path.relative_to(base))]=path.read_bytes()
for name in ['run-native-global-ownership-candidate.py','run-native-global-compile-pilot.py','run-native-global-core-oracle.py','run-native-global-core-oracle-2.py','run-native-global-foundation.py','native-global-candidate-command-plan.json','verify-global-bootstrap-variant-correspondence.py','package-native-global-ownership.py','compare-native-global-map.py']:
 files['commands/'+name]=(cache/name).read_bytes()
manifest={'parent':'14c2ad10c144663fbac433cdeb3920ff3913b6d8','scope':'Focused Global ownership repair; all raw failures preserved. Full workspace baseline and final-head CI not established by this archive. Custom30M compiler probe is diagnostics only, no user program execution.','input_storage':'Each tuple path/digest maps to exact bytes in inputs/<digest>. Duplicate bytes stored once.','pilot_storage':'Compile pilot manifests include repository documentation too. Their changed source is reconstructable by applying retained change.patch to parent14c2ad1; unchanged repository files are in that published Git tree. Main focused compiler/runtime/recipe/oracle tuples are stored as exact bytes here.','tuples':tuples,'payloads':{p:sha(b) for p,b in sorted(files.items())}}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=root/'docs/roadmap/evidence/m4-native-global-ownership-2026-10-17.tar.gz'
with tarfile.open(out,'w:gz') as archive:
 for name,data in sorted(files.items()):
  item=tarfile.TarInfo(name);item.size=len(data);archive.addfile(item,io.BytesIO(data))
with tarfile.open(out) as archive:
 for name,digest in manifest['payloads'].items():assert sha(archive.extractfile(name).read())==digest
result={'path':str(out),'sha256':sha(out.read_bytes()),'payloads':len(files),'bytes':out.stat().st_size}
(cache/'native-global-ownership-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
