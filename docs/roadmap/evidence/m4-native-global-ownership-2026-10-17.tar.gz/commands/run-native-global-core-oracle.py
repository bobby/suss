from pathlib import Path
import subprocess,os,json,hashlib,time,shutil
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');out=cache/'native-global-core-oracle';out.mkdir(exist_ok=False)
paths=['tests/oracle/core-import-cases.json','tests/oracle/src/suss_oracle/core_import.cljs','tests/oracle/deps.edn','scripts/core_import_oracle.py','scripts/oracle_cases.py','scripts/portable_oracle.py']
freeze=lambda:{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=freeze();(out/'inputs.json').write_text(json.dumps(before,indent=2)+'\n')
for p in paths:
 target=out/'before'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,target)
env=os.environ.copy();env.update(CLJ_CONFIG='/tmp/suss-oracle-clojure-config',CLJ_CACHE='/tmp/suss-oracle-clojure-cache')
commands=[('generate-base',['python3','scripts/oracle_cases.py'],root),('generate-core',['python3','scripts/core_import_oracle.py','generate'],root),('compile',['/home/bobby/.cache/suss-m4-oracle-tools/bin/clojure','-J-Xmx1g','-J-XX:ActiveProcessorCount=2','-Srepro','-M','-m','cljs.main','-co','{:force true :cache-analysis false :target :nodejs :output-to "out/core-import.js" :output-dir "out/core-import-cljs" :optimizations :none :source-map false}','-c','suss-oracle.core-import'],root/'tests/oracle'),('observe',['node','out/core-import.js'],root/'tests/oracle'),('compare',['python3','scripts/core_import_oracle.py','compare'],root)]
receipt={'pin':subprocess.check_output(['git','-C',str(root/'clojurescript'),'rev-parse','HEAD'],text=True).strip(),'scope':'Development-only pinned CLJS reference. No Suss execution or budget acceptance.','stages':[]}
for name,cmd,cwd in commands:
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  result=subprocess.run(cmd,cwd=cwd,env=env,stdout=stdout,stderr=stderr)
 receipt['stages'].append({'name':name,'command':cmd,'exit':result.returncode,'seconds':time.monotonic()-start});(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 if result.returncode:break
 if name=='observe':shutil.copyfile(out/'observe.stdout',root/'tests/oracle/out/core-import-observations.json')
receipt['inputs_unchanged']=freeze()==before;(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
