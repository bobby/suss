from pathlib import Path
import subprocess,json,hashlib
root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');rel='crates/suss-compile/src/portable/resolve.rs'
old=subprocess.check_output(['git','show','14c2ad1:'+rel],cwd=root,text=True);new=(root/rel).read_text()
def block(text):
 start=text.index('if let Some(operation) = ControlForm::from_name(name)')
 return text[start:text.index('\n    pub fn resolve(',start)].strip()
a=block(old);b=block(new)
expected=a.replace('Binding::BootstrapLoop(global.clone())','Binding::BootstrapLoop(global)')
actual=b.replace('\n        }))\n    }','\n        })\n    }')
assert actual==expected
r={'parent':'14c2ad10c144663fbac433cdeb3920ff3913b6d8','path':rel,'new_sha256':hashlib.sha256(new.encode()).hexdigest(),'variant_selection_block_preserved':True,'only_normalizations':['fallible Result wrapper closing parenthesis','move final-use loop Global instead of redundant clone'],'scope':'Static correspondence complements actual all55 availability/ownership and runtime resolution gates; not execution proof by itself.'}
Path('/home/bobby/.cache/suss-m4-work/native-global-ownership-candidate/bootstrap-variant-correspondence.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
