from pathlib import Path
import os, subprocess, hashlib, json, time, sys
root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots')
cache=Path('/home/bobby/.cache/suss-m4-work')
run=cache/('native-global-compile-pilot-'+sys.argv[1]);run.mkdir(exist_ok=False)
paths={p for p in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0') if p and (root/p).is_file()}
paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
def freeze(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
before=freeze();(run/'before-freeze.json').write_text(json.dumps(before,indent=2)+'\n')
(run/'change.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=root))
cmd=['cargo','test','-p','suss-compile','--locked','--lib','--no-run']
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(cache/'memo-proof-cost-target'))
receipt={'command':cmd,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'current':'compile','inputs':len(before),'environment':{'CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':env['CARGO_TARGET_DIR'],'RUSTFLAGS_set_by_driver':False},'scope':'Compile-only pilot; no execution/bootstrap/acceptance claim.'}
(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');start=time.monotonic()
with (run/'compile.log').open('w') as log: result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
after=freeze();(run/'after-freeze.json').write_text(json.dumps(after,indent=2)+'\n')
receipt.update(current=None,exit=result.returncode,seconds=time.monotonic()-start,source_unchanged=before==after,changed=[p for p in before if before[p]!=after[p]])
(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
