from pathlib import Path
import os, subprocess, hashlib, json, time
r=Path('/home/bobby/Work/code/bobby/suss-m4-scoped-memo-stores'); c=Path('/home/bobby/.cache/suss-m4-work')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
assert head=='107a736ffc5805aade486d826db7f42c7e6491b6'
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=r)
paths=subprocess.check_output(['git','ls-files','-z'],cwd=r).split(b'\0')
freeze={os.fsdecode(p):hashlib.sha256((r/os.fsdecode(p)).read_bytes()).hexdigest() for p in paths if p and (r/os.fsdecode(p)).is_file()}
cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_source_tags','--','--test-threads=2','--nocapture']
env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'scoped-memo-target')
result={'head':head,'command':cmd,'target':env['CARGO_TARGET_DIR'],'freeze':freeze,'exit':None,'source_unchanged':None}
out=c/'source-tags-107-result.json';out.write_text(json.dumps(result,indent=2));start=time.monotonic()
with (c/'source-tags-107.log').open('w') as f: proc=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
result.update(exit=proc.returncode,seconds=time.monotonic()-start,source_unchanged=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in freeze.items()),clean_after=not subprocess.check_output(['git','status','--porcelain=v1'],cwd=r))
out.write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='freeze'},indent=2));raise SystemExit(proc.returncode)
