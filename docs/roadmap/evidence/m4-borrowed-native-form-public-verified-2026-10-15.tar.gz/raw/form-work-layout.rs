#![allow(dead_code)]
use suss_reader::forms::Form;
type Value=usize;
struct KeyId(usize);
enum MetadataShape {
    Symbol,
    List { empty: bool },
    Vector,
    Map { large: bool },
    Set,
}
enum Shape {
            List,
            Vector,
            Set,
            Map,
            Form,
        }
enum OldWork {
            Visit(Form, usize),
            Finish {
                key: KeyId,
                shape: Shape,
                child_count: usize,
                metadata_shape: Option<MetadataShape>,
                set_item_count: usize,
                base_value: Option<Value>,
            },
        }
enum NewWork<'a> {
            Visit(Form, usize),
            BorrowedVisit(&'a Form, usize),
            Finish {
                key: KeyId,
                shape: Shape,
                child_count: usize,
                metadata_shape: Option<MetadataShape>,
                set_item_count: usize,
                base_value: Option<Value>,
            },
        }
fn main(){let a=std::mem::size_of::<OldWork>();let b=std::mem::size_of::<NewWork>();println!("modeled old/new work layout using actual reader Form: {a}/{b}");assert_eq!(a,b);}
