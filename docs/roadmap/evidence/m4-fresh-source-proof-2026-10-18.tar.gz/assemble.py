#!/usr/bin/env python3
"""Terminal-gated cache-only evidence assembler. No repository mutations or Cargo."""
from pathlib import Path,PurePosixPath
import argparse,subprocess,json,re,hashlib,tarfile,gzip,io
P=Path(__file__).resolve().parent;C=P.parent;R=C/'pr271-fresh-source-validation';repo='/home/bobby/Work/code/bobby/suss';head='f76ad9aa401672c5b0297a68ac89d5da779299cc';H=lambda b:hashlib.sha256(b).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--assemble',action='store_true');args=a.parse_args();receipt=json.loads((R/'receipt.json').read_text())
if not args.assemble:
 print(json.dumps({'state':'PREPARED_NO_ARCHIVE','source':head,'terminal':receipt.get('terminal'),'current':receipt.get('current'),'command':'python3 '+str(P/'assemble.py')+' --assemble'}));raise SystemExit()
assert receipt.get('terminal') is True and receipt.get('current') is None and receipt['base']==head,'Require actual terminal validation at f76'
pid=receipt.get('pid');proc=Path('/proc')/str(pid)
if pid and proc.exists():
 cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace');assert not any(x in cmd for x in ['cargo test','debug/deps/','suss-bootstrap']),('Recorded test producer still active',pid)
assert all(not s['changed'] for s in receipt['stages'])
review=json.loads((C/'pr271-fresh-source-controller-v1/independent-source-review.json').read_text());paths=subprocess.check_output(['git','-C',repo,'diff-tree','--no-commit-id','--name-only','-r',head],text=True).splitlines();assert len(paths)==10
blobs={f:subprocess.check_output(['git','-C',repo,'show',head+':'+f]) for f in paths};hashes={f:H(b) for f,b in blobs.items()};assert all(hashes[f]==h for f,h in review['files'].items())
freeze=json.loads((R/'run-manifest.json').read_text());oldfreeze=json.loads((R/'v2-manifest.json').read_text());assert all(freeze[f]==oldfreeze[f]==h for f,h in hashes.items())
inputs=[f for f in freeze if (f.endswith(('.rs','.sus','.clj','.cljs','.cljc','.wat')) or Path(f).name in ('Cargo.toml','Cargo.lock')) and f not in blobs]
raw=subprocess.run(['git','-C',repo,'cat-file','--batch'],input=('\n'.join(head+':'+f for f in inputs)+'\n').encode(),capture_output=True,check=True).stdout;pos=0
for f in inputs:
 end=raw.index(b'\n',pos);h=raw[pos:end].split();assert h[1]==b'blob';n=int(h[2]);assert H(raw[end+1:end+1+n])==freeze[f],f;pos=end+n+2
completed=[s['name'] for s in receipt['stages']];unexecuted=[n for n in receipt['planned'] if n not in completed];assert receipt.get('unexecuted',unexecuted)==unexecuted
unique={};counts=[];unestablished=[]
for name,file in [('new-proofs-v2',R/'new-proofs-v2.log')]+[(s['name'],R/(s['name']+'.log')) for s in receipt['stages'] if s['name']!='identity']:
 text=file.read_text();sums=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);starts=re.findall(r'^test (\S+) \.\.\.',text,re.M)
 if len(sums)!=1 or len(starts)!=sum(map(int,sums[0])):
  unestablished.append(name);counts.append({'name':name,'status':'UNESTABLISHED_COMPILE_SETUP_OR_SELECTION','starts':starts,'summaries':sums});continue
 triple=list(map(int,sums[0]));failed=set(re.findall(r"thread '([^']+)'[^\n]*panicked at",text));assert len(failed)==triple[1],('Failure parser needs bounded update; preserve raw',name)
 assert triple[2]==0,'Ignored outcomes require explicit classification; do not label passing'
 counts.append({'name':name,'counts':triple,'failed_names':sorted(failed),'names':starts,'log_sha256':H(file.read_bytes())})
 for t in starts:unique.setdefault(t,[]).append({'stage':name,'status':'FAIL' if t in failed else 'PASS'})
conflicts={n:v for n,v in unique.items() if len({x['status'] for x in v})>1};totals={'unique':len(unique),'pass':sum(all(x['status']=='PASS' for x in v) for v in unique.values()),'fail':sum(any(x['status']=='FAIL' for x in v) for v in unique.values()),'ignored':0}
D=P/'payload';assert not D.exists(),'Never overwrite an assembled packet silently'
def put(name,b):
 d=D/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
def js(name,obj):put(name,(json.dumps(obj,indent=2)+'\n').encode())
for f,b in blobs.items():put('source/'+f,b)
for src in sorted(R.rglob('*')):
 if src.is_file():put('validation/'+str(src.relative_to(R)),src.read_bytes())
for label in ['pr271-fresh-source-controller-v1','pr271-fresh-source-proof']:
 for src in sorted((C/label).rglob('*')):
  if src.is_file():put('reviews-and-source-packets/'+label+'/'+str(src.relative_to(C/label)),src.read_bytes())
# Include only immutable archived diagnostic context; none receives f76 acceptance credit.
for label in ['pr271-symbol-diagnostic','pr271-mixed-watch-probe']:
 for src in sorted((C/label).rglob('*')):
  if src.is_file():put('prior-diagnostics/'+label+'/'+str(src.relative_to(C/label)),src.read_bytes())
put('assemble.py',Path(__file__).read_bytes());put('REPORT.template.md',(P/'REPORT.template.md').read_bytes())
summary={'source':head,'totals':totals,'stages':counts,'unexecuted':unexecuted,'unestablished':unestablished,'duplicates':{n:v for n,v in unique.items() if len(v)>1},'conflicting_repeat_outcomes':conflicts,'unique_tests':unique,'limits':'Worst failure remains visible if repeated outcomes conflict; no unknown/ignored or unexecuted stage converted to success.'}
js('terminal-analysis.json',summary);js('source-binding.json',{'source':head,'parent':subprocess.check_output(['git','-C',repo,'rev-parse',head+'^'],text=True).strip(),'ten_source_boot_hashes':hashes,'full_run_manifest_entries':len(freeze),'unchanged_compiler_oracle_git_checked':len(inputs),'git_inputs':{f:{'git':head+':'+f,'sha256':freeze[f]} for f in inputs},'qualification':'Actual run started before/after source commit as recorded; these ten exact images match both corrected new-proof and validation manifests. No initial failed-attempt bootstrap payload reconstructed from hashes, no old-source CI/performance claim.'})
body='**Distinct executed tests: '+str(totals['unique'])+'; '+str(totals['pass'])+' PASS, '+str(totals['fail'])+' FAIL, '+str(totals['ignored'])+' ignored.**\n\n| Stage | PASS | FAIL | ignored |\n|---|---:|---:|---:|\n'
for s in counts:body+='| '+s['name']+' | '+(' | '.join(map(str,s['counts'])) if 'counts' in s else 'UNESTABLISHED | — | —')+' |\n'
body+='\nUnexecuted stages: '+(', '.join(unexecuted) or 'none in the validation driver')+'. Unestablished stages: '+(', '.join(unestablished) or 'none')+'.\n\nActual failed test names:\n'+('\n'.join('- `'+n+'`' for n,v in unique.items() if any(x['status']=='FAIL' for x in v)) or 'None in this bounded selection.')
if conflicts:body+='\n\nRepeated-name outcome conflicts remain explicit in terminal-analysis.json; a failing repeat is not hidden by an earlier PASS.'
put('REPORT.md',(P/'REPORT.template.md').read_text().replace('{{TERMINAL_RESULTS}}',body).encode())
files=sorted(f for f in D.rglob('*') if f.is_file());put('MANIFEST.sha256',('\n'.join(H(f.read_bytes())+'  '+str(f.relative_to(D)) for f in files)+'\n').encode())
archive=P/'m4-fresh-source-proof-2026-10-18.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as z:
  with tarfile.open(fileobj=z,mode='w',format=tarfile.PAX_FORMAT) as t:
   for f in sorted(D.rglob('*')):
    if f.is_file():
     b=f.read_bytes();i=tarfile.TarInfo(str(f.relative_to(D)));i.size=len(b);i.uid=i.gid=0;i.uname=i.gname='';i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
 ms=t.getmembers();assert len({m.name for m in ms})==len(ms)
 for m in ms:assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
 check={s.split('  ',1)[1]:s.split('  ',1)[0] for s in t.extractfile('MANIFEST.sha256').read().decode().splitlines()};assert set(check)=={m.name for m in ms}-{'MANIFEST.sha256'}
 for f,h in check.items():assert H(t.extractfile(f).read())==h
result={'source':head,'archive':str(archive),'sha256':H(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(ms),'payloads':len(check),'all_safe_payload_hashes_verified':True,'report':str(D/'REPORT.md'),'report_sha256':H((D/'REPORT.md').read_bytes()),'totals':totals,'unexecuted':unexecuted,'unestablished':unestablished,'limits':'Partial source-bound evidence only; no historical performance/CI results transferred, no readiness/adoption/issue closure verdict.'}
(P/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
