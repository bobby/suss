# Fresh source data health and strict reusable authority

Tested source `f76ad9aa401672c5b0297a68ac89d5da779299cc` changes six reviewed Rust files and four normally regenerated bootstrap outputs. The ten committed images match the completed new-proof freeze and validation-run freeze. This is partial Draft #271 evidence, not readiness, issue closure or a passing CI/full-baseline result.

Constructor validation returns separate current-data and strict-certificate predicates in one physical walk. Only the already registered, originally nil memo slot may classify an unauthenticated exact Number as fresh data; no receipt is minted and strict matching stays false. Wrong-field, string/reference, original-nonnil and foreign/reset cases do not gain that classification. Existing source/class/prototype/storage and memo authority checks remain required.

Private FreshSourceProof separates Certified from Uncached. Uncached values cannot become CheckedChild/domain authority or cache updates; uncertifiability propagates through their parents. The invocation-local explicit health walk preserves exact native source owner/child order, independent source witness and every current physical obligation. Certified paths still require the original Certificate validator. Construction order and later-callback old-root rebuilding are unchanged; final publication remains staged after all fallible checks. This is not a persistent validity cache, quota change or promise of linear-time or lower whole-request cost. Existing nested destruction/earlier-construction effect policies are not full transactional rollback or #252 completion.

## Source and attempt distinctions

Normal bootstrap and identity-v2 succeeded before the two new tests; raw commands/build logs and manifests are retained. The initial selected-test compilation failed E0616 on private SessionValue.value access in a fixture, so neither test executed in that attempt. The reviewed correction mutates the real UTF16 name array instead; production code is unchanged by that fixture correction. Initial/v2 manifests, patches and fixture source are separate. The packet does not invent missing initial generated-output payloads from hashes alone.

The corrected two-proof run passed 2/0/0 in 64.53s. It covers exact data/strict separation, typed host fuel/IRQ cuts in nil and numeric states, no receipt minting, GC/reset/invalid-field cases; the controller leaf proof preserves an independently cached strict sibling, rejects nonmemo poison and malformed alias lineage. The single controller fixture has no child boundary: by itself it is not the complete multi-parent, callback, lifecycle or final-publication-cut matrix.

The two unchanged original Symbol variants subsequently pass at the same f76 source: **24 complete observations × 13 fields**, all actual=expected, across Runtime/Macro, cold/warm, and baseline/custom-write/restored-method. The actual Rust time is 254.12s; driver wall time is recorded separately. Together with new proofs2 and strict negatives17 this establishes 21 distinct passing tests at that checkpoint. The Symbol terminal review verifies all ten source/BOOT hashes against the validation manifest; it does not credit the then-live Keyword/effect stage.

The final stopped cohort is **26 distinct tests: 24 PASS, 2 source-certification FAIL, 0 ignored**. Both original Symbol and Keyword variants pass **48 complete observations × 13 fields**, actual=expected; each kind contributes 24 rows across the two nil-aware modes, both caller phases, cold/warm, and baseline/custom-write/restored-method. The analyzer actual-environment effect test also passes.

The two replacement-hash tests fail during caller-&env transport with **Host error: Fresh coherent source failed non-memo certification**, not fuel errors. The direct replaced-method test fails span4..31. The canonically warmed test first retains eight matching canonical-warm/next-call rows, then all four custom-before-hit subcases fail at spans4..35 or4..34; later intended observations remain unexecuted. Tests:

- `source_metadata_keeps_identity_with_a_replaced_hash_method`
- `source_metadata_keeps_canonically_warmed_identity_after_hash_replacement`

Driver stops on that group. **constructors, source-child, pinned-map, cljs-observations, public-identity and coherent-guards are UNEXECUTED in the full validation run**. The earlier two-proof run is counted separately and does not substitute for those stopped suites.

{{TERMINAL_RESULTS}}

Full actual argv, stage trace overrides, timing, return codes and unexecuted stages appear in validation/run.py and receipt.json. Builds/tests use CARGO_BUILD_JOBS=1, RAYON_NUM_THREADS=1 and test-threads1; no RUSTFLAGS assignment or allowance changes. Normal regeneration logs are preserved; the validation driver checks identity and its existing negative/positive selections under the same source freeze. Counts deduplicate the new physical proof when it repeats in constructor tests. Identity and bootstrap are separate host checks, not Rust tests.

All successful new-source claims in this report derive from these actual logs. Earlier source proof, packed payload performance, partial memo-routing, public-identity failures or historical CI are not reclassified as results at f76. No prior source performance number or old CI success is credited here. Map/CLJS guest-to-oracle correspondence requires actual retained comparator output, not a Rust wrapper PASS alone.

## Earlier mixed-watch and actual-Symbol diagnostics

The packet also preserves earlier controlled mixed-watch and actual cold Runtime Symbol traces, bootstrap/identity logs, full source-hash manifests and transient patches. Their source variants precede f76. The first controlled probe failed its memo-reference/public-hash-return assertion before the aggregate denial assertion; that failure remains explicit. The corrected controlled probe and actual-Symbol diagnostic pass **because they expect the existing denial**: they are diagnostic successes, with zero semantic acceptance credit. Their recorded attribution is a Namespace constructor's Keyword memo slot3 (record19) becoming numeric with an unsafe receipt while an inactive Symbol obligation rejects original-method inspection. These were context for the split, not a claim that f76 still fails original Symbol tests. Original historical result text is retained unchanged.

`pr271-mixed-watch-probe/PLAN.md` and fixture.rs are prepared external context; no extra execution is credited merely because a fixture is archived. No additional diagnostic is run by assembling this packet. No earlier source performance or CI result is included as current success.

## Binding and limitations

Ten immutable source/BOOT images come from the committed Git tree, not the live author worktree. Source-binding.json verifies reviewed source hashes and compiler/oracle input inventories against explicit commit:path dependencies. This is a Git-dependent evidence packet, not a standalone complete source distribution. Per-stage changed=[] records remain driver evidence; they do not create an independently captured final/prebootstrap freeze if none was supplied.

Later unexecuted assertions in failed public/guard tests remain unexecuted. A false data/strict predicate is not an accepted cached certificate. Existing factory/schema effects can precede a later failure. No milestone status, full-baseline success, final-head CI, PR promotion, merge or issue acceptance follows from this packet. The assembler is cache-only and runs no Cargo/guest tests.
