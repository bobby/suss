from pathlib import Path
import json,re,hashlib
p=Path(__file__).parent;r=json.loads((p/'receipt.json').read_text());assert r['terminal'] and r['current'] is None and all(not s['changed'] for s in r['stages'])
H=lambda b:hashlib.sha256(b).hexdigest();unique={};stages=[]
for name,file in [('new-proofs-v2',p/'new-proofs-v2.log')]+[(s['name'],p/(s['name']+'.log')) for s in r['stages'] if s['name']!='identity']:
 text=file.read_text();sums=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert len(sums)==1;counts=list(map(int,sums[0]));names=re.findall(r'^test (\S+) \.\.\.',text,re.M);assert len(names)==sum(counts);failures=set(re.findall(r"thread '([^']+)'[^\n]*panicked at",text));assert len(failures)==counts[1]
 for n in names:assert n not in unique;unique[n]='FAIL' if n in failures else 'PASS'
 stages.append({'name':name,'counts':counts,'names':names,'failed_names':sorted(failures),'log_sha256':H(file.read_bytes())})
assert len(unique)==26 and sum(x=='PASS' for x in unique.values())==24
rows=[];summaries=[]
for n in ['symbol-originals','keyword-and-effects']:
 text=(p/(n+'.log')).read_text()
 for line in text.splitlines():
  if 'NATIVE_MEMO_LEAF {' in line:
   row=json.loads(line.split('NATIVE_MEMO_LEAF ',1)[1]);assert len(row['fields'])==len(row['actual'])==len(row['expected'])==13 and row['actual']==row['expected'];rows.append(row)
  if 'NATIVE_MEMO_LEAF_SUMMARY {' in line:summaries.append(json.loads(line.split('NATIVE_MEMO_LEAF_SUMMARY ',1)[1]))
assert len(rows)==48 and len({(x['case'],x['stage']) for x in rows})==48
assert len(summaries)==4 and all(x['rows']==12 and x['differences']==[] for x in summaries)
failed=(p/'replaced-hash.log').read_text();assert 'Fresh coherent source failed non-memo certification' in failed
assert 'span: 4..31' in failed and 'at bytes 4..35' in failed and 'at bytes 4..34' in failed
assert 'wasm trap: all fuel consumed' not in failed
expected=['constructors','source-child','pinned-map','cljs-observations','public-identity','coherent-guards'];assert r['unexecuted']==expected
initial=json.loads((p/'source-bound-initial-independent-review.json').read_text());m=json.loads((p/'run-manifest.json').read_text());assert all(m[f]==h for f,h in initial['ten_source_boot_hashes'].items())
result={'verdict':'VERIFIED_SOURCE_BOUND_PARTIAL_FRESH_PROOF_RECOVERY_WITH_REPLACED_HASH_CERTIFICATION_FAILURES','source':r['base'],'counts':{'unique':26,'pass':24,'certification_fail':2,'ignored':0},'stages':stages,'memo_observations':{'Symbol':24,'Keyword':24,'fields_per_row':13,'all_actual_equal_expected':True,'summaries':summaries},'replacement_failures':{'names':[n for n,v in unique.items() if v=='FAIL'],'stage':'caller &env input transport; Host error Fresh coherent source failed non-memo certification','spans':['4..31','4..35','4..34'],'classification':'Two actual source-certification test failures, not fuel/setup/compile failures. Warm test shows matching canonical-warm/next-call observations before all four custom-before-hit certification errors; later intended observation assertions remain unexecuted.'},'unexecuted':expected,'source_binding':'All ten commit images match corrected proof and validation manifests, independently verified initially; assembler rechecks committed images and remaining compiler/oracle Git dependencies. Every recorded validation stage changed=[]; no missing independent before/final freeze invented.','diagnostic_qualification':'Earlier mixed-watch/actual Symbol transient-trace sources are separate variants on pre-f76 source. Include raw bootstrap/source/manifests/results/fixtures; diagnostic PASS expects the existing denial, no acceptance credit. Initial probe assertion failure remains visible.','limits':['No current source-child/public/coherent/map/CLJS/fullbaseline/CI result in this stopped driver. Prior tuple results not transferred.','No performance, readiness, closure, adoption or promotion verdict; no reviewer runtime/Cargo/repository edits.']}
(p/'terminal-independent-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'source':r['base'],'counts':result['counts'],'memo_rows':48,'unexecuted':expected}))
