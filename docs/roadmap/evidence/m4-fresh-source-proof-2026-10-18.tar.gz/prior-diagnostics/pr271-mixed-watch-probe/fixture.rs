// Suggested temporary test in portable_session/memo_bridge/scoped_tests.rs.
// CACHE ONLY: diagnostic expectation is CURRENT DENIAL, not desired acceptance.
#[test]
fn diagnostic_mixed_symbol_watch_denies_canonical_keyword_source_receipt() {
    use crate::portable_session::memo_leaf_test_support::Method;
    let mut session = Session::new_macro().unwrap();
    session.eval("(def leaf-original-method nil) (def mixed-symbol-calls 0)").unwrap();
    let original = Method::capture(&mut session, "Symbol").unwrap();
    original.bind_delegate(&mut session).unwrap();

    let bridge = FormBridge::new(&mut session).unwrap().recording(&mut session).unwrap();
    // These are ordinary factory facts, not reader maps/sets. Neither identifier
    // is hashed during this setup; no Symbol is an input of the Keyword.
    let unused_symbol = bridge.identifier(&mut session, None, "unused-mixed-symbol", false, None).unwrap();
    let target = bridge.identifier(&mut session, None, "mixed-keyword-target", true, None).unwrap();
    let records = bridge.into_records().unwrap(); // ONE recording / WriteDomain
    assert!(records.matches_direct_facts(&mut session).unwrap());

    session.eval(r#"
      (extend-type Symbol IHash
        (-hash [self]
          (do (set! mixed-symbol-calls (inc mixed-symbol-calls))
              (leaf-original-method self))))
    "#).unwrap();
    // Method replacement by itself does not mutate these identifiers' fields.
    assert!(records.matches_direct_facts(&mut session).unwrap());
    session.collect().unwrap();
    let hash = session.eval("(fn [x] (suss.core/hash x))").unwrap();
    let result = session.invoke(&hash, &[&target]).unwrap();

    // Keep the actual guest computation/store even though its source receipt is
    // expected to be denied. No expected canonical hash is invented/prewarmed.
    let read = session.eval("(fn [x] [(number? (.-_hash x)) (.-_hash x)])").unwrap();
    let stored = session.invoke(&read, &[&target]).unwrap();
    let fields = session.data_fields(&target).unwrap();
    assert!(session.values_identical(&fields[3], &result).unwrap(),
        "canonical Keyword method must perform its actual numeric memo store");
    let calls = session.eval("mixed-symbol-calls").unwrap();
    assert_eq!(display(&mut session, &calls), "0",
        "unused Symbol's replacement must never execute in this probe");
    let stored_text = display(&mut session, &stored);
    assert!(stored_text.starts_with("[true "), "memo must be numeric: {stored_text}");
    let direct = records.matches_direct_facts(&mut session).unwrap();
    eprintln!("MIXED_WATCH_DIAGNOSTIC result={} stored={} direct={direct}",
        display(&mut session, &result), stored_text);
    assert!(!direct,
        "diagnostic expects current denial; a changed outcome requires evidence review, not relabeling");
    // Keep both genuine factory owners/facts alive through all checks.
    drop((unused_symbol, target, records));
    original.restore(&mut session).unwrap();
}
