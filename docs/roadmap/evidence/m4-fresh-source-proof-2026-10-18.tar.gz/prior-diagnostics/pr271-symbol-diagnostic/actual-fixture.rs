#[test]
fn diagnostic_actual_symbol_cold_runtime_certificate_failure() {
    let reference: Value = serde_json::from_str(include_str!(
        "../../../../tests/oracle/metadata-memo-leaf-observations.json"
    )).unwrap();
    let pinned = reference["cases"].as_array().unwrap().iter().find(|case|
        case["kind"] == "symbol" && case["nil-aware"] == false && case["explicit-warm"] == false
    ).unwrap();
    let mut caller = Session::new_repl().unwrap();
    caller.eval(pinned["source"].as_str().unwrap()).unwrap();
    let mut macros = CompiledMacros::new().unwrap();
    macros.session.eval("(def leaf-dispatches 0) (def leaf-writes 0) (def leaf-original-method nil)").unwrap();
    let original = Method::capture(&mut macros.session, "Symbol").unwrap();
    original.bind_delegate(&mut macros.session).unwrap();
    macros.define(OBSERVE).unwrap();
    caller.collect().unwrap();
    let baseline = caller.eval_with_macros("(observe-leaf 0 false)", &mut macros).unwrap();
    eprintln!("ACTUAL_SYMBOL_BASELINE {}", crate::portable_repl::display(&mut caller, &baseline).unwrap());
    macros.session.eval(r#"(extend-type Symbol IHash
      (-hash [self]
        (if (identical? self leaf-saved-value)
          (do (set! leaf-dispatches (inc leaf-dispatches))
            (let [memo (.-_hash self)]
              (if (and false (some? memo)) memo
                (do (set! leaf-writes (inc leaf-writes))
                    (set! (.-_hash self) 91) 91))))
          (leaf-original-method self))))"#).unwrap();
    caller.collect().unwrap();
    let error = caller.eval_with_macros("(observe-leaf 1 false)", &mut macros).unwrap_err();
    eprintln!("ACTUAL_SYMBOL_ERROR {error}");
    assert!(error.to_string().contains("Fresh coherent source failed certification"));
    original.restore(&mut macros.session).unwrap();
}
