from pathlib import Path
import re,json
c=Path('/home/bobby/.cache/suss-m4-work')
labels=['metadata-graph start','metadata-declaration suss.core/*print-dup* start','metadata-declaration suss.core/->ArrayChunk start','metadata-declaration suss.core/->RecordIter definition-origin','metadata-declaration suss.core/->RecordIter finished','metadata-declaration suss.core/->RedNode start','metadata-declaration suss.core/-nth definition-origin','metadata-declaration suss.core/BitmapIndexedNode definition-origin']
result={'base':'2b71b5e','original_reference':'65b565f','profiles':{},'scope':'One final avalanche only; 10 additional units precharged per hash, no other tariff or algorithm change. New/2b intern subtotals include miss encoding; original65 intern excludes prior temporary encoding. Compare actual remaining fuel and same-scope head operations.'}
for target in ['declaration-profile','core-environment']:
 logs={name:(c/f'{prefix}-{target}.log').read_text().splitlines() for name,prefix in [('original65','demand-origin'),('unfinalized2b','raw-view'),('finalized','raw-avalanche')]}
 rows=[]
 for label in labels:
  values={name:[int(line.rsplit(': ',1)[1]) for line in lines if line.startswith(label)] for name,lines in logs.items()}
  last={name:v[-1] if v else None for name,v in values.items()}
  if last['finalized'] is not None:
   rows.append({'boundary':label,**last,**{f'gain_vs_{name}':last['finalized']-last[name] if last[name] is not None else None for name in ['original65','unfinalized2b']}})
 same_calls={}
 for calls in [16128,23680]:
  values={}
  for name,lines in logs.items():
   match=[line for line in lines if line.startswith(f'raw-key-profile calls={calls} ')]
   values[name]={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',match[-1])} if match else None
  same_calls[calls]=values
 result['profiles'][target]={'boundaries':rows,'same_call_prefixes':same_calls,'finalized_tail':logs['finalized'][-25:]}
(c/'raw-avalanche-profile-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
