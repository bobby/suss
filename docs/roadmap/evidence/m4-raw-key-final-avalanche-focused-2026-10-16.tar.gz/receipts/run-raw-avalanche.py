from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-definition-initializer-plan');c=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'definition-initializer-target'),RAYON_NUM_THREADS='2')
files=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']]+[p for p in (r/'runtime/bootstrap').glob('*') if p.is_file()]
freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};state={'base':'2b71b5e','original_reference':'65b565f','freeze':freeze,'stages':[],'current':None}
out=c/'raw-avalanche-result.json'
def save():out.write_text(json.dumps(state,indent=2)+'\n')
stages=[('declaration-profile',['-p','suss-cli','--locked','--test','compiled_macro_declaration_metadata','declaration_metadata_merge_and_tag_precedence_match_pinned_analyzer'],False,True),('core-environment',['-p','suss-cli','--locked','--test','compiled_macro_core_environment'],False,True)]
for name,args,stop,trace in stages:
 cmd=['cargo','test']+args+['--','--test-threads=2','--nocapture'];state['current']=name;entry={'name':name,'command':cmd};state['stages'].append(entry);save()
 e=env.copy()
 if trace:e.update(SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1',SUSS_RAW_KEY_TRACE='1')
 start=time.time()
 with (c/f'raw-avalanche-{name}.log').open('w') as f:run=subprocess.run(cmd,cwd=r,env=e,stdout=f,stderr=subprocess.STDOUT)
 entry.update(exit=run.returncode,seconds=time.time()-start);save()
 if stop and run.returncode:state['stopped_on_unexpected_focused_failure']=name;break
state.update(current=None,source_unchanged=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in freeze.items()));save();print(json.dumps({k:v for k,v in state.items() if k!='freeze'},indent=2))
