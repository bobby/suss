//! Fingerprint the implementation that produces portable artifacts.
use sha2::{Digest, Sha256};
use std::{
    env, fs,
    path::{Path, PathBuf},
};
fn sources(directory: &Path, files: &mut Vec<PathBuf>) {
    for entry in fs::read_dir(directory).expect("compiler source directory") {
        let path = entry.expect("compiler source entry").path();
        if path.is_dir() {
            sources(&path, files);
        } else if path.extension().is_some_and(|extension| extension == "rs" || extension == "sus") {
            files.push(path);
        }
    }
}
fn main() {
    let crate_root = PathBuf::from(env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let root = crate_root.parent().unwrap().parent().unwrap();
    let mut files = vec![
        root.join("Cargo.toml"),
        root.join("Cargo.lock"),
        crate_root.join("build.rs"),
        // Executable runtime dependencies are part of the artifact identity,
        // even when their implementation is supplied as embedded bytes.
        root.join("runtime/numeric/artifact/numeric.wasm"),
        root.join("runtime/numeric/artifact/manifest.json"),
        // The shipped command embeds upstream WIT, so changed source/lock bytes
        // must invalidate compiled artifacts even without a Rust source edit.
        root.join("docs/roadmap/wasi-wit-lock.json"),
        root.join("vendor/wasi/wasi-wit-0.3.1/cli/cli.wit"),
        root.join("vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit"),
        root.join("vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit"),
        root.join("vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit"),
        root.join("vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit"),
    ];
    for name in ["suss-core", "suss-reader", "suss-compile"] {
        let directory = root.join("crates").join(name);
        files.push(directory.join("Cargo.toml"));
        sources(&directory.join("src"), &mut files);
        println!("cargo:rerun-if-changed={}", directory.join("src").display());
    }
    files.sort();
    let mut hash = Sha256::new();
    for path in files {
        println!("cargo:rerun-if-changed={}", path.display());
        let relative = path
            .strip_prefix(root)
            .unwrap()
            .components()
            .map(|component| component.as_os_str().to_str().expect("UTF-8 source path"))
            .collect::<Vec<_>>()
            .join("/");
        let bytes = fs::read(&path).expect("compiler fingerprint source");
        hash.update((relative.len() as u64).to_le_bytes());
        hash.update(relative.as_bytes());
        hash.update((bytes.len() as u64).to_le_bytes());
        hash.update(bytes);
    }
    println!(
        "cargo:rustc-env=SUSS_COMPILER_SOURCE_SHA256={:x}",
        hash.finalize()
    );
}
