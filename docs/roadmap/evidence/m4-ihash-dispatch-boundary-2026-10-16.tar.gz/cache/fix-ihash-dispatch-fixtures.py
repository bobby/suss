from pathlib import Path
p=Path('/home/bobby/Work/code/bobby/suss-m4-ihash-dispatch-boundary/crates/suss-compile/src/portable_session/dispatch_observer.rs')
s=p.read_text()
def replace(x,y):
 global s
 assert s.count(x)==1, (s.count(x),x)
 s=s.replace(x,y,1)
replace('    active: bool,\n}\nstruct State', '    active: bool,\n    nearest_ihash: Option<usize>,\n}\nstruct State')
replace('        self.frames.iter().rev().find(|frame| frame.active)', '        self.frames.last().and_then(|frame| frame.nearest_ihash)\n            .and_then(|index| self.frames.get(index))')
replace('            let nearest_ihash_depth = state.frames.iter().rposition(|f| f.active);', '            let nearest_ihash_depth = state.frames.last().and_then(|frame| frame.nearest_ihash);')
replace('''                #[cfg(test)]
                {
                    let depth = locked.frames.len();''','''                // Unrelated callbacks inherit the nearest actual IHash scope.
                // Cache its index: no uncharged linear walk of the native stack.
                let nearest_ihash = if active { Some(locked.frames.len()) }
                    else { locked.frames.last().and_then(|frame| frame.nearest_ihash) };
                #[cfg(test)]
                {
                    let depth = locked.frames.len();''')
replace('                        locked.frames.iter().rposition(|f| f.active)', '                        nearest_ihash')
replace('''                    _method: method,
                    active,
                });''','''                    _method: method,
                    active,
                    nearest_ihash,
                });''')
replace('''        session
            .eval("(ns suss.core) (def -hash (fn [_] 72)) (ns user)")
            .unwrap();''','''        let keyword = session.eval(":x").unwrap();
        let map = session.eval("{:x 7}").unwrap();
        let call_ifn = session.eval("(fn [k m] (k m))").unwrap();
        reset_trace(&session);
        let value = session.invoke(&call_ifn, &[&keyword, &map]).unwrap();
        assert_eq!(display(&mut session, &value), "7");
        assert!(events(&observer).is_empty(), "IFn adaptation does not enter the observer");
        session.enter_namespace("suss.core").unwrap();
        session.eval("(def -hash (fn [_] 72))").unwrap();
        session.enter_namespace("user").unwrap();''')
replace('''    fn ihash_dispatch_boundary_native_and_legacy_routes_and_key_mutation() {
        let mut session = Session::new_macro().unwrap();
        session.eval(SETUP).unwrap();''','''    fn ihash_dispatch_boundary_native_and_legacy_routes_and_key_mutation() {
        let mut session = Session::new_macro().unwrap();
        session.eval(SETUP).unwrap();
        // Core hash has a number fast path; direct -hash requires an explicit
        // native implementation. Its extra fixed parameter also proves that
        // this branch still uses native padding rather than ordinary invoke.
        session.eval("(extend-type number IHash (-hash [_ ignored] (if (undefined? ignored) 17 18)))").unwrap();''')
p.write_text(s)
print('applied checked fixture/nearest-index replacements')
