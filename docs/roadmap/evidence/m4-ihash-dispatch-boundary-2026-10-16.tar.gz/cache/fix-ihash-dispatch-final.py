from pathlib import Path
import shutil,tarfile
cache=Path('/home/bobby/.cache/suss-m4-work')
root=Path('/home/bobby/Work/code/bobby/suss-m4-ihash-dispatch-boundary')
for name in ['focused-result.json','observer.log','receipts.log','runtime-protocol.log']:
 p=cache/('ihash-dispatch-'+name)
 shutil.copy2(p,cache/('ihash-dispatch-second-'+name))
with tarfile.open(cache/'ihash-dispatch-second-source.tar.gz','w:gz') as t:
 for p in (root/'crates/suss-compile/src').rglob('*.rs'):t.add(p,arcname=str(p.relative_to(root)))
p=root/'crates/suss-compile/src/portable_session/dispatch_observer.rs'
s=p.read_text()
a='''        move |mut caller, arguments, results| {
            let route'''
b='''        move |mut caller, arguments, results| {
            // Charge common host bookkeeping even before bootstrap seals authority.
            // This covers route validation, locks, and the optional authority clone;
            // key inspection and frame/root allocation are charged separately below.
            Session::consume_host_work(caller.as_context_mut(), 4, &interrupt)?;
            let route'''
assert a in s;s=s.replace(a,b,1)
a='''        // Core hash has a number fast path; direct -hash requires an explicit
        // native implementation. Its extra fixed parameter also proves that
        // this branch still uses native padding rather than ordinary invoke.
        session
            .eval("(extend-type number IHash (-hash [_ ignored] (if (undefined? ignored) 17 18)))")
            .unwrap();'''
b='''        // Install through the native ABI to deliberately test differing arity:
        // source extend-type correctly rejects undeclared IHash arities. Native
        // dispatch must still pad this extra parameter with undefined.
        let dispatcher = session.eval("suss.core/-hash").unwrap();
        let method = session
            .eval("(fn [_ ignored] (if (undefined? ignored) 17 18))")
            .unwrap();
        let runtime = session.runtime;
        session.inspect(&dispatcher, |mut store, dispatcher| {
            let method = Val::AnyRef(Some(method.value.to_rooted(&mut store)));
            let setter = runtime.get_func(&mut store, "protocol-native-method-set").unwrap();
            setter.call(&mut store, &[dispatcher, Val::I32(2), method], &mut [Val::null_any_ref()])
        }).unwrap();'''
assert a in s;s=s.replace(a,b,1);p.write_text(s)
