from pathlib import Path
import os,subprocess,time,json,hashlib
root=Path('/home/bobby/Work/code/bobby/suss-m4-ihash-dispatch-boundary')
cache=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(cache/'ihash-dispatch-target')
paths=[p for p in (root/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']]
paths += list((root/'runtime/bootstrap').glob('*'))
freeze={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
result={'base':'9f951b0c26897df2986b3e2d79c97df062aafc56','current':None,'freeze':freeze,'stages':[],'environment':{'CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']}}
out=cache/'ihash-dispatch-focused-result.json'
stages=[('observer',['cargo','test','-p','suss-compile','--lib','--locked','ihash_dispatch_boundary_','--','--test-threads=2','--nocapture']),('receipts',['cargo','test','-p','suss-compile','--lib','--locked','receipt_tests','--','--test-threads=2']),('runtime-protocol',['cargo','test','-p','suss-compile','--locked','--test','runtime_abi','runtime_abi_nominal_identity_fields_and_live_protocols_cross_fragments_after_gc','--','--test-threads=2'])]
for name,cmd in stages:
 result['current']=name;out.write_text(json.dumps(result,indent=2)+'\n');start=time.time()
 with (cache/f'ihash-dispatch-{name}.log').open('w') as f: child=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 result['stages'].append({'name':name,'command':cmd,'exit':child.returncode,'seconds':time.time()-start})
 # Diagnostic continuation retains each actual failure and does not relabel it.
 result['source_unchanged']=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
 result['current']=None;out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='freeze'},indent=2))
