from pathlib import Path
import subprocess,os,json,time
r=Path('/home/bobby/Work/code/bobby/suss-m4-ihash-dispatch-boundary');c=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'ihash-dispatch-target')
cmd=['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']
start=time.time()
with (c/'ihash-dispatch-bootstrap-corrected.log').open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
(c/'ihash-dispatch-bootstrap-receipt.json').write_text(json.dumps({'command':cmd,'exit':p.returncode,'seconds':time.time()-start},indent=2)+'\n')
if p.returncode:raise SystemExit(p.returncode)
p=subprocess.run(['python3',str(c/'run-ihash-dispatch-focused.py')],cwd=r,env=env)
raise SystemExit(p.returncode)
