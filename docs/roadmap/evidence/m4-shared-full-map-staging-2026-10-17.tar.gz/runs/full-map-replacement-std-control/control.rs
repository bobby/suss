use std::{collections::HashMap, sync::Arc};
fn main() {
    let mut old = HashMap::new();
    old.try_reserve(3).unwrap();
    for i in 0..old.capacity() { old.insert(format!("key-{i}"), Arc::new(i)); }
    let mut staged = HashMap::with_hasher(old.hasher().clone());
    staged.try_reserve(old.capacity()).unwrap();
    for (k,v) in &old { staged.insert(k.clone(), v.clone()); }
    let before = staged.capacity();
    let returned = staged.insert("key-0".into(), Arc::new(42)).unwrap();
    println!("old_len={} old_capacity={} staged_capacity_before={} staged_capacity_after={} staged_len={} returned_same_owner={} old_value={} new_value={} untouched_same_owner={}", old.len(), old.capacity(), before, staged.capacity(), staged.len(), Arc::ptr_eq(&returned, &old["key-0"]), old["key-0"], staged["key-0"], Arc::ptr_eq(&old["key-1"], &staged["key-1"]));
}
