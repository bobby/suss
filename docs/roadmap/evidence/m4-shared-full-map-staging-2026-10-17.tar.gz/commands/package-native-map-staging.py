from pathlib import Path
import json,hashlib,tarfile,io,re
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots')
run=cache/'native-map-staging-repaired-candidate'
r=json.loads((run/'receipt.json').read_text());assert r['current'] is None and not r['final_changed']
stop=json.loads((cache/'native-map-staging-candidate/targeted-stop-receipt.json').read_text());assert stop['terminal_exit']==130 and stop['all2915inputs_unchanged_at_stop'] and not stop['group_ps_after'].strip()
files={};tuples={};sha=lambda b:hashlib.sha256(b).hexdigest()
for directory in ['native-map-staging-candidate','native-map-staging-repaired-candidate']:
 base=cache/directory
 for label in ['before','after-bootstrap']:
  frozen=json.loads((base/(label+'-freeze.json')).read_text());tuples[directory+'/'+label]=frozen
  for rel,digest in frozen.items():
   data=(base/label/rel).read_bytes();assert sha(data)==digest;files['inputs/'+digest]=data
for directory in ['native-map-staging-candidate','native-map-staging-foundation','native-map-staging-repaired-candidate','native-map-staging-repaired-foundation','full-map-replacement-std-control','native-map-staging-independent-review']:
 base=cache/directory
 for path in base.rglob('*'):
  if path.is_file() and path.relative_to(base).parts[0] not in ['before','after-bootstrap']:
   files['runs/'+directory+'/'+str(path.relative_to(base))]=path.read_bytes()
for name in ['run-native-map-staging-candidate.py','run-native-map-staging-foundation.py','native-map-staging-command-plan.json','run-native-map-staging-repaired-candidate.py','run-native-map-staging-repaired-foundation.py','native-map-staging-repaired-command-plan.json','compare-native-map-staging-repaired-map.py','package-native-map-staging.py']:
 files['commands/'+name]=(cache/name).read_bytes()
manifest={'parent':'2936205934d4e21fea97bbed25142150ae7b6400','source_checkpoint':'2462d5c85fd81096ee30dddedeef68ce67e10ba8','scope':'Shared full insertion stages final table once; existing-slot replacement avoids inherited implicit HashMap growth. Raw initial failed-control pilot, targeted termination, standalone parent control and revised terminal cohort retained. No full baseline/final-head CI acceptance inferred. Diagnostic30M compiler-only probe executes no user program.','tuples':tuples,'payloads':{p:sha(b) for p,b in sorted(files.items())}}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=root/'docs/roadmap/evidence/m4-shared-full-map-staging-2026-10-17.tar.gz'
with tarfile.open(out,'w:gz') as a:
 for name,data in sorted(files.items()):
  item=tarfile.TarInfo(name);item.size=len(data);a.addfile(item,io.BytesIO(data))
with tarfile.open(out) as a:
 for name,digest in manifest['payloads'].items():assert sha(a.extractfile(name).read())==digest
result={'path':str(out),'sha256':sha(out.read_bytes()),'payloads_including_manifest':len(files),'bytes':out.stat().st_size}
(cache/'native-map-staging-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
