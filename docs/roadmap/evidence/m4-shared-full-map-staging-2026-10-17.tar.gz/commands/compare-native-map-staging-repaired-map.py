from pathlib import Path
import json,sys
root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');sys.path.insert(0,str(root/'scripts'));import clojure_test_suite as suite
run=Path('/home/bobby/.cache/suss-m4-work/native-map-staging-repaired-candidate');reference=json.loads((root/'tests/oracle/clojure-test-suite-observations.json').read_text());ns='clojure.core-test.map';test=ns+'/test-map'
reference['namespaces']=[ns];reference['tests']=[test];reference['assertions']=[x for x in reference['assertions'] if x['test']==test];reference['skips']=[x for x in reference['skips'] if x['namespace']==ns]
observed=json.loads((run/'map-capture/map-transport-observations.json').read_text());counts,failures=suite.compare(reference,observed)
(run/'map-host-comparison.json').write_text(json.dumps({'counts':counts,'failures':failures},indent=2)+'\n');print(json.dumps(counts))
