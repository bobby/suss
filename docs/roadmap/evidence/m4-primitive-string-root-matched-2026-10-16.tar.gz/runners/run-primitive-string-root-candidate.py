from pathlib import Path
import json,hashlib,subprocess,os,time
r=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access');c=Path('/home/bobby/.cache/suss-m4-work');o=c/'primitive-string-root-before';fixture='crates/suss-compile/tests/portable_primitive_string_root_writes.rs';assert (r/fixture).read_bytes()==(o/'portable_primitive_string_root_writes.rs').read_bytes()
files=sorted([p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']]+[p for p in (r/'runtime/bootstrap').glob('*') if p.is_file()]);freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
inputs=['Cargo.toml','Cargo.lock','crates/suss-compile/build.rs','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json']+['vendor/wasi/wasi-wit-0.3.1/cli/'+f for f in ['cli.wit','deps/clocks.wit','deps/filesystem.wit','deps/random.wit','deps/sockets.wit']]
for name in ['suss-core','suss-reader','suss-compile']:
 inputs.append('crates/'+name+'/Cargo.toml');inputs.extend(str(p.relative_to(r)) for p in (r/'crates'/name/'src').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus'])
h=hashlib.sha256()
for f in sorted(inputs,key=lambda p:tuple(p.split('/'))):
 b=(r/f).read_bytes();n=f.encode();h.update(len(n).to_bytes(8,'little')+n+len(b).to_bytes(8,'little')+b)
checks={p:json.loads((r/f'runtime/bootstrap/{p}.json').read_text())['compiler_source_sha256']==h.hexdigest() for p in ['macro','runtime']};assert all(checks.values()),checks
cmd=['cargo','test','-p','suss-compile','--locked','--test','portable_primitive_string_root_writes','primitive_string_root_writes_observe_caught_boundaries_in_both_phases','--','--exact','--test-threads=2','--nocapture'];s={'current':'candidate','command':cmd,'fixture_sha256':freeze[fixture],'byte_exact_before_fixture':True,'fingerprint':h.hexdigest(),'fingerprint_phases_match':checks,'integration_tests_excluded':True,'freeze':freeze,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()};out=o/'candidate-result.json';out.write_text(json.dumps(s,indent=2));env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2');start=time.time()
with (o/'candidate.log').open('w') as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
s.update(current=None,exit=p.returncode,seconds=time.time()-start,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items()));out.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='freeze'},indent=2))
