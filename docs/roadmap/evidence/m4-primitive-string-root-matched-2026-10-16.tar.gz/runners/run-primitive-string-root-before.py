from pathlib import Path
import json,hashlib,subprocess,os,time,sys
r=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access-before');c=Path('/home/bobby/.cache/suss-m4-work');o=c/'primitive-string-root-before';name=sys.argv[1];test=sys.argv[2];filter=sys.argv[3];files=sorted([p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']]+[p for p in (r/'runtime/bootstrap').glob('*') if p.is_file()]);freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
for f in subprocess.check_output(['git','ls-files','crates','runtime/bootstrap'],cwd=r,text=True).splitlines():
 p=r/f
 if p.is_file():assert p.read_bytes()==subprocess.check_output(['git','show','8fda18a:'+f],cwd=r),f
cmd=['cargo','test','-p','suss-compile','--locked','--test',test,filter,'--','--exact','--test-threads=2','--nocapture'];s={'base':'8fda18a','current':name,'command':cmd,'freeze':freeze,'all_tracked_crates_bootstrap_equal_base':True,'fixture_sha256':freeze[f'crates/suss-compile/tests/{test}.rs']};out=o/(name+'-result.json');out.write_text(json.dumps(s,indent=2));env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(c/'primitive-string-access-before-target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2');start=time.time()
with (o/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
s.update(current=None,exit=p.returncode,seconds=time.time()-start,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items()));out.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='freeze'},indent=2))
