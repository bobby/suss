from pathlib import Path
import json,hashlib,tarfile,io
c=Path('/home/bobby/.cache/suss-m4-work');o=c/'primitive-string-root-before';before=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access-before');candidate=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access');payload={}
for name,r,tag in [('original',before,'before'),('caught',before,'before'),('candidate',candidate,'candidate')]:
 s=json.loads((o/(name+'-result.json')).read_text());assert s['current'] is None and s['source_unchanged']
 for f,h in s['freeze'].items():
  b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+tag+'/'+f]=b
for p in o.iterdir():
 if p.is_file() and not p.name.endswith('.tar.gz'):payload['raw/'+p.name]=p.read_bytes()
for f in ['run-primitive-string-root-before.py','run-primitive-string-root-candidate.py','compare-primitive-string-root.py','package-primitive-string-root-matched.py']:payload['runners/'+f]=(c/f).read_bytes()
for f in ['primitive-string-access-root-strings.log','primitive-string-access-root-detail-strings.log']:payload['support/candidate-prior-postexecution/'+f]=(c/f).read_bytes()
payload['support/before-compiler-fingerprint-verification.json']=(c/'primitive-string-access-before/fingerprint-verification.json').read_bytes()
for f in ['Cargo.toml','Cargo.lock','crates/suss-compile/build.rs']:payload['support/'+f]=(before/f).read_bytes()
m={n:hashlib.sha256(b).hexdigest() for n,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(m,indent=2).encode();out=o/'m4-primitive-string-root-matched-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,b in sorted(payload.items()):
  info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
result={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(m)};(c/'primitive-string-root-matched-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
