import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path('/home/bobby/Work/code/bobby/suss')
out=Path('/home/bobby/.cache/suss-m4-work/suss-m4-root-projection-result.json')
paths=sorted(p for p in (root/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus'])
paths += sorted((root/'runtime/bootstrap').glob('*'))
start={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}
state={'current':None,'stages':[],'source-hashes':start}
env=os.environ.copy();env.update(PATH='/home/bobby/.cargo/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(root/'target-m4-prototype'))
env['SUSS_MACRO_FUEL_TRACE']='1';env['SUSS_METADATA_FUEL_TRACE']='1'
env['TMPDIR']='/home/bobby/.cache/suss-m4-work'
env['SUSS_CLOJURE_TEST_SUITE_CAPTURE']='/home/bobby/.cache/suss-m4-work/map-after-intern-copy'
env['SUSS_CLOJURE_TEST_SUITE_CAPTURE']='/home/bobby/.cache/suss-m4-work/map-after-root-projection'
stages=[('source provenance','portable::origin'),('sharing semantics','portable_macro_graph::sharing_tests'),('declaration values and source metadata','declarations'),('full cumulative fuel','metadata'),('cross-invocation identity','identity'),('previous fuel failures','broad'),('pinned map','map')]
for name,filter_ in stages+[('provenance',None)]:
 if filter_=='map': cmd=['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--test-threads=2','--nocapture']
 elif filter_=='declarations': cmd=['cargo','test','--workspace','--locked','--no-fail-fast','--test','compiled_macro_declaration_metadata','--test','compiled_macro_form_source_metadata','--test','compiled_macro_declaration_functions','--','--test-threads=2','--nocapture']
 elif filter_=='metadata': cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_cumulative_fuel','--','--test-threads=2','--nocapture']
 elif filter_=='identity': cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_cross_invocation_identity_probe','--','--test-threads=2','--nocapture']
 elif filter_=='broad': cmd=['cargo','test','--workspace','--locked','--no-fail-fast','--test','compiled_macro_collection_source_asts','--test','compiled_macro_compiler_catalog','--test','compiled_record_factories','--','--test-threads=2','--nocapture']
 else: cmd=['cargo','test','-p','suss-compile','--locked','--lib',filter_,'--','--test-threads=2'] if filter_ else ['python3','scripts/check_record_macro_provenance.py']
 log=Path('/home/bobby/.cache/suss-m4-work/suss-m4-root-projection-'+(filter_ or 'provenance')+'.log')
 with log.open('wb') as f:
  process=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  state['current']={'name':name,'pid':process.pid,'log':str(log),'command':cmd};out.write_text(json.dumps(state,indent=2)+'\n')
  code=process.wait()
 state['stages'].append({**state['current'],'exit_code':code});state['current']=None
 state['source-unchanged']=all(p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==start[str(p.relative_to(root))] for p in paths if str(p.relative_to(root)) in start)
 out.write_text(json.dumps(state,indent=2)+'\n')
 print(json.dumps(state['stages'][-1]),flush=True)
 if (code and filter_ not in ['broad','declarations']) or not state['source-unchanged']:sys.exit(code or 1)
