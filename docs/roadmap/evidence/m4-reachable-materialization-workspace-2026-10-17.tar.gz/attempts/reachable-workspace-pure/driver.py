from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,fcntl,re
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace');target=cache/'memo-proof-cost-target';run=cache/'reachable-workspace-pure'
leases=[]
for name in ['.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease']:
 f=open(target/name,'a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit()or int(proc.name)==os.getpid():continue
 try:envb=(proc/'environ').read_bytes();cmd=(proc/'cmdline').read_bytes().split(b'\0')[0]
 except OSError:continue
 if b'CARGO_TARGET_DIR='+str(target).encode()+b'\0'in envb or str(target).encode()in cmd:raise RuntimeError('Target active '+proc.name)
manifest=json.loads((cache/'reachable-materialization-workspace-source/manifest.json').read_text())
for p,h in manifest['files'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
paths=set(json.loads((cache/'native-fresh-class-complete-cost/before-freeze.json').read_text()));paths.update(str(p.relative_to(root))for p in(root/'crates').rglob('*.rs'))
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest()for p in sorted(paths)}
expected=freeze();assert len(expected)==2916
run.mkdir(exist_ok=False)
def snapshot(label,data):
 (run/(label+'-freeze.json')).write_text(json.dumps(data,indent=2)+'\n')
 for p,h in data.items():
  dest=run/'frozen/sha256'/h
  if not dest.exists():dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,dest)
  assert hashlib.sha256(dest.read_bytes()).hexdigest()==h
snapshot('before',expected);shutil.copyfile(Path(__file__),run/'driver.py');shutil.copytree(cache/'reachable-materialization-workspace-source',run/'source-review-packet')
command=['cargo','test','-p','suss-compile','--locked','--lib','--','--test-threads=1','--nocapture','portable_macro_graph::materialization_index::tests::','portable_macro_graph::occurrence_work::tests::']
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
for k in list(env):
 if k.startswith('SUSS_')and('TRACE'in k or'DIAGNOSTIC'in k):env.pop(k)
state={'driver_pid':os.getpid(),'base':manifest['base'],'root':str(root),'input_count':len(expected),'target':str(target),'command':command,'current':'pure-rust','limits':'Pure native index/count tests only. Bootstrap not regenerated for this stage; no Session/guest artifact execution claimed. Expected eight tests. Compiler check/build failures and raw test failures retained. RUSTFLAGS inherited, jobs1/Rayon1/testthreads1.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
save();start=time.monotonic()
with(run/'pure-rust.log').open('w')as log:
 p=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);state['cargo_pid']=p.pid;save();code=p.wait()
after=freeze();snapshot('after',after)
text=(run/'pure-rust.log').read_text(errors='replace');counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
state.update(current=None,exit=code,seconds=time.monotonic()-start,changed=[p for p in expected if after[p]!=expected[p]],summaries=[dict(zip(['passed','failed','ignored'],map(int,x)))for x in counts]);save();print(json.dumps(state,indent=2))
