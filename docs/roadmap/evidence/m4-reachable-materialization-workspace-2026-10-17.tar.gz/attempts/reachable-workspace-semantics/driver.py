from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,fcntl,re
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace');target=cache/'memo-proof-cost-target';run=cache/'reachable-workspace-semantics'
leases=[]
for name in ['.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease']:
 f=open(target/name,'a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit()or int(proc.name)==os.getpid():continue
 try:envb=(proc/'environ').read_bytes();cmd=(proc/'cmdline').read_bytes().split(b'\0')[0]
 except OSError:continue
 if b'CARGO_TARGET_DIR='+str(target).encode()+b'\0'in envb or str(target).encode()in cmd:raise RuntimeError('Target active '+proc.name)
manifest=json.loads((cache/'reachable-workspace-semantic-source/manifest.json').read_text())
for p,h in manifest['files'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
paths=set(json.loads((cache/'native-fresh-class-complete-cost/before-freeze.json').read_text()));paths.update(str(p.relative_to(root))for p in(root/'crates').rglob('*.rs'))
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest()for p in sorted(paths)}
expected=freeze();assert len(expected)==2916
run.mkdir(exist_ok=False)
def snapshot(label,data):
 (run/(label+'-freeze.json')).write_text(json.dumps(data,indent=2)+'\n')
 for p,h in data.items():
  dest=run/'frozen/sha256'/h
  if not dest.exists():dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,dest)
  assert hashlib.sha256(dest.read_bytes()).hexdigest()==h
snapshot('before',expected);shutil.copyfile(Path(__file__),run/'driver.py');shutil.copytree(cache/'reachable-workspace-semantic-source',run/'source-review-packet')
commands=[('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('semantics',['cargo','test','-p','suss-compile','--locked','--lib','--','--test-threads=1','--nocapture','portable_macro_graph::materialization_index::tests::','portable_macro_graph::occurrence_work::tests::','portable_macro_graph::plan_scratch_tests::dense_and_sparse_materialization_','portable_macro_graph::source_roots::tests::source_parent_lineage_'])]
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
for k in list(env):
 if k.startswith('SUSS_')and('TRACE'in k or'DIAGNOSTIC'in k):env.pop(k)
state={'driver_pid':os.getpid(),'base':manifest['base'],'root':str(root),'input_count':len(expected),'target':str(target),'current':None,'stages':[],'limits':'Original default Session allowances. Normal bootstrap then12tests:8pure+2bothmodeDenseSparseAutomatic comparisons+original/paddedsource-lineage2. No helper refill, assertion/body removal or callback bypass. RUSTFLAGS inherited, jobs1/Rayon1/testthreads1. Failures and unexecuted later stages retained.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for name,command in commands:
 assert freeze()==expected,'Source changed before '+name
 if name=='semantics':env['SUSS_SOURCE_MATERIALIZE_FUEL_TRACE']='1'
 row={'name':name,'command':command};state['stages'].append(row);state['current']=name;save();start=time.monotonic()
 with(run/(name+'.log')).open('w')as log:
  p=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);row['pid']=p.pid;save();code=p.wait()
 after=freeze();changed=[p for p in expected if after[p]!=expected[p]];row.update(exit=code,seconds=time.monotonic()-start,changed=changed)
 if name=='bootstrap'and code==0 and set(changed)<={f'runtime/bootstrap/{phase}.{ext}'for phase in ['macro','runtime']for ext in ['json','wasm']}:
  expected=after;snapshot('after-bootstrap',expected)
 elif changed:row['unexpected_source_changes']=True;save();break
 if name=='semantics':
  text=(run/(name+'.log')).read_text(errors='replace');counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);row['summaries']=[dict(zip(['passed','failed','ignored'],map(int,x)))for x in counts]
 save()
 if code:break
actual=freeze();snapshot('terminal',actual);state.update(current=None,final_changed=[p for p in expected if actual[p]!=expected[p]]);save();print(json.dumps(state,indent=2))
