from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,fcntl
cache=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace')
run=cache/'reachable-workspace-acceptance'
target=cache/'memo-proof-cost-target'
lease=open(target/'.sourcechild-target.lease','a')
fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
lease.write(str(os.getpid()));lease.flush()
leases=[]
for name in ['.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease']:
 f=open(target/name,'a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit()or int(proc.name)==os.getpid():continue
 try:envb=(proc/'environ').read_bytes();cmd=(proc/'cmdline').read_bytes().split(b'\0')[0]
 except OSError:continue
 if b'CARGO_TARGET_DIR='+str(target).encode()+b'\0'in envb or str(target).encode()in cmd:raise RuntimeError('Target active '+proc.name)
run.mkdir(exist_ok=False)
manifest={'base':'a259870b2fe4ce3e8da3b267bf73c4d8c558622d'}
paths=set(json.loads((cache/'native-fresh-class-complete-cost/before-freeze.json').read_text()))
paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
def freeze():
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snapshot(label,data):
 (run/(label+'-freeze.json')).write_text(json.dumps(data,indent=2))
 for p in data:
  dest=run/label/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,dest)
expected=freeze();assert expected==json.loads((cache/'reachable-workspace-semantics/terminal-freeze.json').read_text());snapshot('before',expected)
shutil.copytree(cache/'reachable-workspace-semantic-source',run/'source-review-packet')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target))
for k in list(env):
 if k.startswith('SUSS_') and k.endswith('TRACE'):env.pop(k)
base=['cargo','test','-p','suss-compile','--locked','--lib'];tail=['--','--test-threads=1','--nocapture']
commands=[('regression-witnesses', ['cargo', 'test', '-p', 'suss-cli', '--locked', '--no-fail-fast', '--test', 'compiled_public_records', '--test', 'portable_reduction_dispatch', '--', '--exact', '--test-threads=1', '--nocapture', 'public_record_nominal_equality_and_predicate_decode_after_gc_in_both_phases', 'public_records_execute_jank_and_authored_contracts_with_two_nominal_classes', 'public_reduce_dispatch_and_source_order_match_pinned_cljs_after_gc']), ('source-domain-raw-key-cohort', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--lib', '--', '--test-threads=1', '--nocapture', 'portable_session::scalar_inputs::tests::', 'portable_session::write_domain::tests::', 'portable_session::construction_records::tests::', 'source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo', 'portable_session::storage_snapshot::tests::', 'portable_macro_graph::raw_keys::tests::', 'portable_macro_graph::initializer_plan::tests::']), ('core-import', ['cargo', 'test', '-p', 'suss-cli', '--locked', '--test', 'core_import', '--', '--test-threads=1', '--nocapture']), ('map', ['cargo', 'test', '-p', 'suss-compile', '--locked', '--test', 'clojure_test_suite', 'pinned_map_declaration_executes_without_transport_loss', '--', '--exact', '--test-threads=1', '--nocapture'])]
state={'driver_pid':os.getpid(),'root':str(root),'base':manifest['base'],'input_count':len(expected),'target':str(target),'environment':{'jobs':1,'rayon':1,'test_threads':1,'RUSTFLAGS':'inherited, not assigned'},'current':None,'stages':[],'limits':'Expanded focused candidate gates:3 previous M4record/reduce fuel failures,59 source/domain/rawkey,17coreimport,1fullmap. Preserve originalfixture allowances/assertions and independentfailure outcomes. No cap increase/callback suppression/fallback retry. Bootstrap and12semantic tests already executed on same2916source tuple; publication still requires independent review/baseline/finalCI.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for name,cmd in commands:
 assert freeze()==expected,'source changed before '+name
 if name=='source-domain-raw-key-cohort':env.update(SUSS_SOURCE_CHILD_FUEL_TRACE='1',SUSS_SOURCE_MATERIALIZE_FUEL_TRACE='1')
 else:env.pop('SUSS_SOURCE_CHILD_FUEL_TRACE',None);env.pop('SUSS_SOURCE_MATERIALIZE_FUEL_TRACE',None)
 if name=='map':env.update(SUSS_CLOJURE_TEST_SUITE_CAPTURE=str(run/'map-capture'),SUSS_MACRO_FUEL_TRACE='1')

 state['current']=name;row={'name':name,'command':cmd};state['stages'].append(row);save();start=time.monotonic()
 with (run/(name+'.log')).open('w') as out:
  proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
 after=freeze();changed=[p for p in expected if expected[p]!=after[p]]
 row.update(exit=code,seconds=time.monotonic()-start,changed=changed)
 if name=='bootstrap' and code==0 and set(changed)<={f'runtime/bootstrap/{phase}.{ext}' for phase in ['macro','runtime'] for ext in ['wasm','json']}:
  expected=after;snapshot('after-bootstrap',expected)
 elif changed:
  row['unexpected_changes']=True;save();break
 save()
 import re
 counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (run/(name+'.log')).read_text(errors='replace'))
 row['summaries']=[dict(zip(['passed','failed','ignored'],map(int,x)))for x in counts]
 row['expected_test_count']={'regression-witnesses':3,'source-domain-raw-key-cohort':59,'core-import':17,'map':1}[name]
 row['actual_test_count']=sum(sum(map(int,x))for x in counts)
 row['selection_matches']=row['expected_test_count']==row['actual_test_count'];save()
 # Independent gates continue after a semantic failure, retaining the failure.

final=freeze();state['current']=None;state['final_changed']=[p for p,h in expected.items() if final[p]!=h];save()
snapshot('terminal',freeze())
