from pathlib import Path
import json,hashlib,subprocess,tarfile,io,re,collections
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace');O=Path(__file__).parent;H='f56f1ab6bbb5e4796b443bd3e4997eba5f66d1ca';P='7f778958b414a42215bfc2216af524f1804feb24';OLD='5e0d9f273081ec3a5d7c04aa9e949a1a3c08a0f0';PIN='c4295f303100bbf5afac449242d30bca1126f1a1';sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H
payload={};maps={}
def put(n,b):assert n not in payload,n;payload[n]=b
def file(n,p):put(n,Path(p).read_bytes())
def tree(prefix,d,skip=()):
 for p in sorted(d.rglob('*')):
  if p.is_file() and not any(x in p.relative_to(d).parts for x in ('__pycache__',)+tuple(skip)):file(prefix+'/'+str(p.relative_to(d)),p)
def closure(n,mp,sources):
 fm=json.loads(mp.read_text());assert len(fm)in(2915,2916);maps[n]=fm
 for path,h in fm.items():
  if 'frozen/sha256/'+h in payload:continue
  for source in sources:
   for p in [source/path,source/'sha256'/h]:
    if p.is_file():
     b=p.read_bytes()
     if sha(b)==h:put('frozen/sha256/'+h,b);break
   else:continue
   break
  else:raise AssertionError((n,path,h))
 return fm
for run in ['reachable-workspace-pure','reachable-workspace-semantics','reachable-workspace-acceptance']:
 d=C/run;j=json.loads((d/'receipt.json').read_text());assert j['current']is None
 if run.endswith('pure'):assert j['exit']==0 and j['changed']==[] and j['summaries']==[{'passed':8,'failed':0,'ignored':0}]
 else:assert j['final_changed']==[]
 tree('attempts/'+run,d,('frozen','before','terminal'))
 for mp in d.glob('*freeze.json'):closure(run+'/'+mp.name,mp,[d/'frozen',d/'before',d/'terminal'])
final=json.loads((C/'reachable-workspace-acceptance/terminal-freeze.json').read_text());assert len(final)==2916
assert final==json.loads((C/'reachable-workspace-semantics/after-bootstrap-freeze.json').read_text())==json.loads((C/'reachable-workspace-semantics/terminal-freeze.json').read_text())==json.loads((C/'reachable-workspace-acceptance/before-freeze.json').read_text())
def git_bind(head,fm):
 assert subprocess.check_output(['git','rev-parse',head+':clojurescript'],cwd=R,text=True).strip()==PIN
 names=[n for n in fm if not n.startswith('clojurescript/')];stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=R,input=''.join(head+':'+n+'\n'for n in names).encode()))
 for n in names:
  header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob';data=stream.read(int(header[2]));assert stream.read(1)==b'\n';assert sha(data)==fm[n],n
 for n in fm:
  if n.startswith('clojurescript/'):
   data=subprocess.check_output(['git','show',PIN+':'+n.removeprefix('clojurescript/')],cwd=R/'clojurescript');assert sha(data)==fm[n],n
 return {'head':head,'checked':len(fm),'mismatches':[],'method':'Actual Git batch blobs and pinned submodule blobs; not receipt label alone.'}
put('source/final-independent-git-binding.json',(json.dumps(git_bind(H,final),indent=2)+'\n').encode())
put('source/final-nine-files.patch',subprocess.check_output(['git','diff','--binary',P,H],cwd=R));put('source/commit.txt',subprocess.check_output(['git','show','--format=fuller','--stat',H],cwd=R))
assert len(subprocess.check_output(['git','diff','--name-only',P,H],cwd=R,text=True).splitlines())==9
# Source packets and original review limits are immutable historical records.
for n in ['reachable-materialization-workspace-design','reachable-materialization-workspace-source','reachable-workspace-semantic-source','reachable-workspace-evidence-plan']:tree('review-and-plan/'+n,C/n)
for n in ['run-reachable-workspace-pure.py','run-reachable-workspace-semantics.py','run-reachable-workspace-acceptance.py','compare-reachable-workspace-map.py','explain-reachable-workspace-map-guest-judged.py','bind-suss-frozen-source.py']:file('commands/'+n,C/n)
for n in ['sourcechild-and-route-comparison.json','bootstrap-noncustom-correspondence.json','compare.py']:file('comparisons/'+n,O/n)
# Reconcile final12+expanded80 exact names independently; initial8 are repeated support, not eight more unique.
results={}
def test_rows(text):
 starts=list(re.finditer(r'^test (\S+) \.\.\. ',text,re.M));rows=[]
 for i,m in enumerate(starts):
  body=text[m.end():starts[i+1].start() if i+1<len(starts) else len(text)]
  body=body.split('\nfailures:\n',1)[0].split('\ntest result:',1)[0].strip()
  status=re.search(r'(?:^|\n)(ok|FAILED)\s*$',body);assert status,(m.group(1),body[-200:])
  if status[1]=='FAILED':assert 'caller &env input transport'in body and 'all fuel consumed by WebAssembly'in body
  rows.append((m.group(1),'pass'if status[1]=='ok'else'fuel-fail'))
 return rows
for run,logs in [('reachable-workspace-semantics',['semantics.log']),('reachable-workspace-acceptance',['regression-witnesses.log','source-domain-raw-key-cohort.log','core-import.log','map.log'])]:
 for name in logs:
  text=(C/run/name).read_text();rows=test_rows(text)
  counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
  assert len(rows)==sum(int(a)+int(b)for a,b,_ in counts) and all(int(i)==0 for _,_,i in counts)
  for n,status in rows:assert n not in results,n;results[n]=status
assert len(results)==92 and collections.Counter(results.values())=={'pass':89,'fuel-fail':3}
u=json.loads((C/'reachable-workspace-acceptance/focused-union.json').read_text());assert {r['name']for r in u['rows']}==set(results)
pure=set(re.findall(r'^test (\S+) \.\.\. ok\s*$',(C/'reachable-workspace-pure/pure-rust.log').read_text(),re.M));assert len(pure)==8 and all(results[n]=='pass'for n in pure)
put('classification/independent-final-union.json',(json.dumps({'source':H,'unique':92,'pass':89,'fuel_fail':3,'ignored':0,'unexecuted':0,'initial_pure8_repeated_not_added':True,'tests':results},indent=2)+'\n').encode())
# Measured parent control at unchanged10M, not new execution or sparse evidence.
d=C/'native-raw-key-scratch-acceptance'
for n in ['source-domain-cohort.log','default-source-child-result.json','source-commit-binding.json','terminal-freeze.json']:file('parent-5e0-focused/'+n,d/n)
closure('parent-5e0-focused/terminal-freeze.json',d/'terminal-freeze.json',[d/'terminal',d/'before'])
# Qualified completed parent baseline; all original frozenbytes retained, no live candidate baseline copied.
d=C/'raw-key-scratch-full-baseline-5e0d9f2';tree('parent-5e0-full-baseline',d,('frozen',))
before=closure('parent-5e0-full-baseline/before-freeze.json',d/'before-freeze.json',[d/'frozen']);after=closure('parent-5e0-full-baseline/after-freeze.json',d/'after-freeze.json',[d/'frozen']);assert before==after and len(before)==2915
put('parent-5e0-full-baseline/assembly-git-binding.json',(json.dumps(git_bind(OLD,before),indent=2)+'\n').encode())
s=json.loads((d/'terminal-summary.json').read_text());assert s['head']==OLD and s['exit']==101 and s['passing_executions']==83 and s['failed']==2 and s['ignored']==0 and s['inputs_unchanged']
context={'source':H,'parent_docs':P,'original24_archive':'m4-original24-focused-a259870-2026-10-17.tar.gz','original24_archive_sha256':'1bf660d918da84dc21ffc3d2732b49d3ececcb79b87a85ae1c442f9fc2848847','original24_scope':'a25921pass3fuel union; NOT final S24rerun. Three actual new failure witnesses retained in final acceptance.','prior_rawkey_archive_sha256':'494aa46df38041286b93c912f7fe008951dcfbf321273daa5a7bc2d6d2babd45','parent5e0_baseline':'83passingexecutions2fuel0ignored239unexecuted integration targets; later unit/doc packages unexecuted. Separate2915 tuple, not final S2916.','current_S_baseline':'Root-owned separate frozen full baseline; no outcome presumed, no changing logs copied.','current_S_CI':'Separate gate, not collected in this packet; no green/failure outcome inferred.','limits':['No budget probes or CoreEnv wholecost claim','Dense sourcechild remains dense; sparse demonstrated separately in semantic source-parent padded interception','No M4 completion/issueclosure/merge/readiness claim','Initial8pure prebootstrap is not Session execution and not8extra unique passes']}
put('classification/context.json',(json.dumps(context,indent=2)+'\n').encode())
tree('assembly/initial-inline-status-parser-attempt',O/'initial-inline-status-parser-attempt')
file('assembly/package.py',Path(__file__))
put('SHA256SUMS',''.join(sha(payload[n])+'  '+n+'\n'for n in sorted(payload)).encode())
out=R/'docs/roadmap/evidence/m4-reachable-materialization-workspace-2026-10-17.tar.gz';assert not out.exists(),'Preserve previous packaging attempt before replacement'
with tarfile.open(out,'w:gz',compresslevel=6)as t:
 for n,b in sorted(payload.items()):
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
seen={}
with tarfile.open(out,'r|gz')as t:
 for m in t:
  assert m.isfile()and not m.name.startswith('/')and '..'not in Path(m.name).parts and m.name not in seen
  data=t.extractfile(m).read();assert data==payload[m.name];seen[m.name]=sha(data)
assert len(seen)==len(payload)
for fm in maps.values():
 for n,h in fm.items():assert seen.get('frozen/sha256/'+h)==h,n
assert all(sha((R/n).read_bytes())==h for n,h in final.items())
result={'head':H,'archive':str(out),'sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'members':len(payload),'manifested_payloads':len(payload)-1,'retained_maps':{n:len(m)for n,m in maps.items()},'unique_pass':89,'fuel_fail':3,'ignored':0,'unexecuted':0,'safe_unique_manifest_and_closures_verified':True};(O/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
