from pathlib import Path
import re,json,hashlib,subprocess,collections
C=Path('/home/bobby/.cache/suss-m4-work');O=Path(__file__).parent;R=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace');H='f56f1ab6bbb5e4796b443bd3e4997eba5f66d1ca';P='7f778958b414a42215bfc2216af524f1804feb24';sha=lambda x:hashlib.sha256(x).hexdigest()
old=(C/'native-raw-key-scratch-acceptance/source-domain-cohort.log').read_text();new=(C/'reachable-workspace-acceptance/source-domain-raw-key-cohort.log').read_text();sem=(C/'reachable-workspace-semantics/semantics.log').read_text()
def markers(t):
 out=[]
 for l in t.splitlines():
  if 'source-child-fuel ' in l:
   s=l[l.index('source-child-fuel '):];m=re.search(r'remaining=Some\((\d+)\)',s);assert m,s;out.append((re.sub(r'remaining=Some\(\d+\)','remaining=Some(<fuel>)',s),int(m[1])))
 return out
a,b=markers(old),markers(new);assert len(a)==len(b)==220 and [x[0]for x in a]==[x[0]for x in b]
phases={}
for phase in ['Runtime','Macro']:
 def val(t,stage):return int(re.search(r'source-child-fuel source='+phase+r' variant=None stage='+stage+r' remaining=Some\((\d+)\)',t).group(1))
 assert val(new,'request-start')==val(old,'request-start')==10000000
 before=val(old,r'final-validation result=Ok\(\(\)\)');after=val(new,r'final-validation result=Ok\(\(\)\)');assert(before,after)==(21485,21401)
 phases[phase]={'actual_start':10000000,'remaining':after,'actual_cost':10000000-after,'parent_remaining':before,'added_actual_cost':before-after}
pattern=r'source-materialize-workspace root=(\d+) mode=(dense|sparse) graph=(\d+) reached=(\d+)'
def routes(t):return [dict(zip(['root','mode','graph','reached'],[int(r),m,int(g),int(n)]))for r,m,g,n in re.findall(pattern,t)]
pr=routes(new);sr=routes(sem);assert len(pr)==84 and all(r['mode']=='dense'for r in pr)
padded=[r for r in sr if r['graph']==4148];direct=[r for r in sr if r['graph']==4123];assert padded and all(r['mode']=='sparse'for r in padded) and min(r['reached']for r in padded)==2 and max(r['reached']for r in padded)==23;assert direct and all(r['mode']=='sparse'and r['reached']==26 for r in direct)
j={'source':H,'parent':P,'all_220_ordered_markers_match':True,'phase_results':phases,'sourcechild_routes':{'total':len(pr),'dense':84,'sparse':0,'scope':'Whole existing sourcechild fixture, both phases, no sparse coverage inferred'},'semantic_route_rows':sr,'padded_lineage_graph4148':{'rows':len(padded),'mode':'sparse','reached_min':2,'reached_max':23},'direct_automatic_graph4123':{'rows':len(direct),'mode':'sparse','reached':26},'trace_files':{'parent':sha(old.encode()),'candidate_sourcechild':sha(new.encode()),'semantic':sha(sem.encode())},'limits':'84costincrease perphase measured, not savings. Semantic asserts callback18 + metadata/alias/GC, not a benchmark/wholeCoreEnv result. Forcedmodehelper does not emit production route marker; preserve test source to distinguish paths.'}
(O/'sourcechild-and-route-comparison.json').write_text(json.dumps(j,indent=2)+'\n')
def leb(d,p):
 n=0;s=0
 while True:
  b=d[p];p+=1;n|=(b&127)<<s
  if b<128:return n,p
  s+=7;assert s<36

def sections(data):
 assert data[:8]==b'\0asm\x01\0\0\0';p=8;out=[]
 while p<len(data):
  start=p;sid=data[p];p+=1;size,p=leb(data,p);end=p+size;assert end<=len(data)
  if sid:out.append({'id':sid,'payload_size':size,'encoded_section_sha256':sha(data[start:end])})
  p=end
 return out
result={}
for phase in ['macro','runtime']:
 path='runtime/bootstrap/'+phase+'.wasm';before=subprocess.check_output(['git','show',P+':'+path],cwd=R);after=subprocess.check_output(['git','show',H+':'+path],cwd=R);x,y=sections(before),sections(after);assert x==y
 result[phase]={'parent_full_sha256':sha(before),'candidate_full_sha256':sha(after),'ordered_noncustom_sections_equal':True,'sections':y}
(O/'bootstrap-noncustom-correspondence.json').write_text(json.dumps({'source':H,'parent':P,'phases':result,'limits':'Artifact correspondence only; does not substitute for execution or source identity.'},indent=2)+'\n')
print('Verified220markers/84dense; semantic sparse4148/4123; bothphase noncustom sections equal')
