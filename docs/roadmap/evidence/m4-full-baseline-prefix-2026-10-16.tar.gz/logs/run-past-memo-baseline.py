from pathlib import Path
import subprocess,os,json,time,hashlib
root=Path('/home/bobby/Work/code/bobby/suss');c=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env['PATH']='/home/bobby/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(root/'target-m4-prototype')
focused=json.loads((c/'past-memo-focused-result.json').read_text())
assert focused['current'] is None and focused['source_unchanged']
cmd=['cargo','test','--workspace','--locked','--','--test-threads=2']
r={'command':cmd,'started':time.time(),'current':'workspace','freeze':focused['freeze']}
p=c/'past-memo-baseline-result.json';p.write_text(json.dumps(r,indent=2)+'\n')
with (c/'past-memo-baseline.log').open('w') as f: result=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
r.update(exit=result.returncode,seconds=time.time()-r['started'],current=None,source_unchanged=all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in r['freeze'].items()))
p.write_text(json.dumps(r,indent=2)+'\n')
