import pathlib,json,hashlib,tarfile,io,gzip
root=pathlib.Path('/home/bobby/.cache/suss-m4-work/pr263-ci-triage')
work=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access')
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((root/'terminal-cache-manifest.json').read_text())
assert len(manifest)==174
payload={}
for name,digest in manifest.items():
 b=(root/name).read_bytes();assert sha(b)==digest,name;payload['cache/'+name]=b
payload['cache/terminal-cache-manifest.json']=(root/'terminal-cache-manifest.json').read_bytes()
heads={k:json.loads(payload[f'cache/{k}/terminal-summary.json']) for k in ['4ab','e55']}
for h in heads.values():
 assert h['all_jobs_terminal'] and h['status']=='completed'
 p=h['source_proof'];assert p['synthetic_tree_equals_head'] and p['head_tree']==p['synthetic_tree']
 i=h['integration'];assert i['planned_targets']==i['completed_targets']+i['started_unfinished_targets']+i['unexecuted_targets']
comparison=json.loads(payload['cache/head-execution-comparison.json'])
assert all(comparison['newly_observed_previous_target_unexecuted'].values())
assert all(comparison['old_absent_current_target_unexecuted'].values())
readme='''# Analyzer identity CI evidence, 2026-10-16

Explicit packaging release received after both runs and every job were terminal.
This archive preserves 174 checksum-verified cache files, their original checksum
manifest, source proofs, raw logs, per-job plans/classifications and failure assertions.
No dirty worktree source snapshot is presented as CI source. No local build/test,
CI restart/cancellation, commit or push was performed for packaging.

Runs (independent source bases):
https://github.com/bobby/suss/actions/runs/38971935949 : 4ab8a76a48469b1138bba1dc14ad7deff5afcad6, cancelled.
https://github.com/bobby/suss/actions/runs/38973362610 : e55c0e2bd58a20cf01efa8f82808c981839d2b91, failure.

4ab integration: 252 planned targets =29 completed +1 started unfinished +222
unexecuted. Completed summaries:116 pass/16 fail/0 ignored. Unfinished
compiled_export_metadata announced5:3 explicit passes,2 unknown, no suite summary.
Cancelled foundation completed summaries:31 pass/0 fail/0 ignored across4 harness
records; unfinished suss_compile announced340:198 explicit passes,142 unknown.
Partial outcomes must not be added to completed-suite totals or treated as complete
passes. Unknown outcomes remain unknown rather than unexecuted target outcomes.

e55 integration:253 planned =29 completed +0 unfinished +224 unexecuted;
completed summaries106 pass/14 fail/0 ignored. Foundation succeeded:403 Rust
execution passes/0 fail/1 ignored, including verifier repeats, not distinct tests.
Foundation stdout/stderr Doc-tests interleaving prevents reliable per-target
association for one Running example line. The current classification qualifies
that ambiguity; it is not evidence of a cancelled/unfinished foundation harness.

Source: shard0 checkout logs identify synthetic commits; GitHub git commit JSON
proves each synthetic tree equals its published head tree. 4ab synthetic ce45a0143e39f84a0a50ce118fd64d64d52d680d,
tree950f652685246897469b93832ee34fb5dd641977. e55 synthetic bb34147f070ba2e49aa861126772bd6a9ad76224,
tree1229f664ad6339a291e8d3be400793cd0aaf7c1b. First runner-image Commit lines
are not checkout proofs. Full parents and API responses are preserved.

Failed-name comparison: constructor_source_nodes_match_pinned_children_tags_and_class_facts_after_gc
and quote_and_literal_child_records_match_pinned_without_datum_analysis newly
execute/fail in e55; their targets were unexecuted in4ab. Four previously failing
public_record* tests are absent because compiled_public_records is unexecuted in
e55, not because fixed. Exact names and boolean target checks are in
cache/head-execution-comparison.json. Plan252->253 reshuffles shard coverage.
No introduced-regression/resolution conclusion follows from changed failed lists.

Commands/derivation: cached watch-pr263-existing-ci.py performs read-only gh run
view RUN --repo bobby/suss --json status,conclusion,jobs,headSha polling and gh api
--allow-escape-sequences repos/bobby/suss/actions/jobs/JOB/logs retrieval;
per-job origin JSON records actual handles/commands. classify-pr263-partial-ci.py
parses actual Rust summaries separately from explicit partial test lines and
compares executed target names with the logged per-head target plans.
summarize-pr263-terminal-ci.py aggregates these classifications;
capture-pr263-ci-source-proof.py preserves GitHub git commit API GET responses.
Raw ANSI remains retained. Initial parser-incomplete files and preliminary
foundation association output are superseded, retained as failed tooling evidence;
use current *.classification.json and terminal-summary.json. CLI escape-byte
retrieval failures/retries are preserved; they are not guest/test failures.
Original cache summaries saying pending release describe their capture time;
this package records the subsequent explicit release without mutating originals.

No full workspace baseline, all-target CI pass, current dirty-source CI coverage,
acceptance completion or milestone/issue closure claim. Final aggregate test job
is a gate outcome, not a Rust test harness. Counts describe executions, not unique
test definitions. README/summary supplement the immutable raw cache.
'''
payload['README.md']=readme.encode()
payload['summary.json']=(json.dumps({'packaging_release':'explicit; both runs terminal','verified_original_cache_files':174,'heads':heads,'failed_name_execution_comparison':comparison,'limits':'See README.md; historical pending-release cache text retained unchanged. No dirty source snapshot or acceptance claim.'},indent=2)+'\n').encode()
payload['package-analyzer-identity-ci.py']=pathlib.Path(__file__).read_bytes()
checks={n:sha(b) for n,b in sorted(payload.items())}
payload['MANIFEST.json']=(json.dumps(checks,indent=2)+'\n').encode()
out=work/'docs/roadmap/evidence/m4-analyzer-identity-ci-2026-10-16.tar.gz'
assert not out.exists(),out
out.parent.mkdir(parents=True,exist_ok=True)
with out.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for n,b in sorted(payload.items()):
    i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(out,'r:gz') as t:
 actual={m.name:t.extractfile(m).read() for m in t.getmembers()}
 assert actual==payload
 for n,h in json.loads(actual['MANIFEST.json']).items():assert sha(actual[n])==h
result={'archive':str(out),'sha256':sha(out.read_bytes()),'original_cache_files':174,'payloads_excluding_manifest':len(checks),'total_archive_files':len(payload),'all_payload_hashes_verified':True,'no_dirty_source_snapshot':True}
pathlib.Path('/home/bobby/.cache/suss-m4-work/analyzer-identity-ci-package-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
section=f'''\n\n## Analyzer identity CI execution evidence (2026-10-16)\n\nArchive `evidence/{out.name}`, SHA256 `{result['sha256']}`;\n174 original cache files verified against the retained cache manifest;\n{len(checks)} payloads verified against archive MANIFEST.json (plus the manifest).\nPackaging command: `python /home/bobby/.cache/suss-m4-work/package-analyzer-identity-ci.py`.\nCached read-only watcher/classifier/source-proof scripts, job origins, raw logs,\nplans, terminal metadata and failed-assertion evidence are included. No local\nbuild/test, source/test/bootstrap edit, commit or push was performed for packaging.\n\nRun38971935949, head4ab8a76a48469b1138bba1dc14ad7deff5afcad6, cancelled:\nintegration252 planned =29 completed +1 unfinished +222 unexecuted targets;\ncompleted summaries116 pass/16 fail/0 ignored. Unfinished compiled_export_metadata\nannounced5:3 explicit passes/2 unknown, no suite summary. Cancelled foundation:\ncompleted summaries31/0/0 across4 harness records; unfinished suss_compile\nannounced340:198 explicit passes/142 unknown. Partial outcomes remain separate.\n\nRun38973362610, heade55c0e2bd58a20cf01efa8f82808c981839d2b91, failure:\nintegration253 planned =29 completed +0 unfinished +224 unexecuted;\ncompleted summaries106 pass/14 fail/0 ignored. Successful foundation403 Rust\nexecution passes/0 fail/1 ignored includes verifier repeats, not distinct tests.\nAn interleaved example/Doc-tests line has unconfirmed per-target summary\nassociation; current classification retains this qualification. Both runs and\nall jobs are terminal; no unfinished foundation claim follows from that ambiguity.\n\nCheckout/API proofs: synthetic ce45a0143e39f84a0a50ce118fd64d64d52d680d\ntree950f652685246897469b93832ee34fb5dd641977 equals4ab head tree; synthetic\nbb34147f070ba2e49aa861126772bd6a9ad76224\ntree1229f664ad6339a291e8d3be400793cd0aaf7c1b equalse55 head tree.\nRunner-image Commit lines are not checkout proof. No dirty worktree source was\nsnapshotted as CI source.\n\nNewly observed constructor_source_nodes_match_pinned_children_tags_and_class_facts_after_gc\nand quote_and_literal_child_records_match_pinned_without_datum_analysis failures\nwere previously unexecuted targets. Four absent public_record* failures are\ncurrently unexecuted, not fixed; the archive lists every exact name and target\ncomparison. Plan252->253 changes shard coverage. Cancelled partial test counts\nare not completed-suite passes. Initial parser/retrieval failures and superseded\nclassifications remain preserved and identified. No full baseline, complete\nall-target pass, current dirty-source CI coverage or acceptance conclusion is\nclaimed. Each published head has independent execution evidence.\n'''
with (work/'docs/roadmap/handoff.md').open('a') as f:f.write(section)
