from pathlib import Path
import json,re,subprocess,concurrent.futures,hashlib
root=Path('/home/bobby/.cache/suss-m4-work/pr263-ci-triage')
for tag in ['4ab','e55']:
 folder=root/tag;run=json.loads((folder/'run-latest.json').read_text());head=run['headSha'];log=(folder/'integration-0.log').read_text(errors='replace');matches=re.findall(r'\+([0-9a-f]{40}):refs/remotes/pull/263/merge',log);synthetic=matches[0] if matches else None
 result={'run':run['databaseId'],'head':head,'synthetic_checkout':synthetic,'proof_origin':'Terminal shard0 checkout raw log plus read-only GitHub git commit API. First runner-image Commit line is not used.'}
 for name,sha in [('head',head),('synthetic',synthetic)]:
  if not sha:continue
  p=subprocess.run(['gh','api',f'repos/bobby/suss/git/commits/{sha}'],capture_output=True)
  if p.returncode:result[name+'_api_error']=p.stderr.decode();continue
  (folder/(name+'-commit.json')).write_bytes(p.stdout);obj=json.loads(p.stdout);result[name+'_tree']=obj['tree']['sha'];result[name+'_parents']=[x['sha'] for x in obj['parents']]
 if 'head_tree' in result and 'synthetic_tree' in result:result['synthetic_tree_equals_head']=result['head_tree']==result['synthetic_tree']
 (folder/'source-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
