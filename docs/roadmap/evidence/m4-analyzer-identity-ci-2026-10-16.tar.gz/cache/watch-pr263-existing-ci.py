from pathlib import Path
import json,subprocess,time,hashlib,concurrent.futures,importlib.util
c=Path('/home/bobby/.cache/suss-m4-work');o=c/'pr263-ci-triage';o.mkdir(exist_ok=True);spec=importlib.util.spec_from_file_location('classifier',c/'classify-pr263-partial-ci.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
runs=[(38971935949,'4ab'),(38973362610,'e55')];iteration=max([int(p.stem.split('-')[-1]) for p in o.glob('*/poll-*.json')]+[-1])+1

def download(run,tag,job):
 label=('foundation' if job['name']=='foundation' else 'integration-'+job['name'].split('(')[1].rstrip(')') if job['name'].startswith('integration (') else 'job-'+job['name'].replace(' ','-'));folder=o/tag;folder.mkdir(exist_ok=True);dest=folder/(label+'.log');metadata={'run':run,'head':states[tag]['headSha'],'job':job['databaseId'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion']}
 if not dest.exists():
  existing=c/('pr263-slot-ci-'+label+'.log') if tag=='4ab' else None
  if existing and existing.exists():dest.write_bytes(existing.read_bytes());(folder/(label+'.origin.json')).write_text(json.dumps({'existing_cache':str(existing),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}))
  else:
   p=subprocess.run(['gh','api','--allow-escape-sequences',f'repos/bobby/suss/actions/jobs/{job["databaseId"]}/logs'],capture_output=True)
   if p.returncode:
    (folder/(label+'.download-errors.log')).open('ab').write(p.stderr);return {'job':job['name'],'download':'retry','error':p.stderr.decode(errors='replace')[:150]}
   dest.write_bytes(p.stdout);(folder/(label+'.origin.json')).write_text(json.dumps({'endpoint':f'repos/bobby/suss/actions/jobs/{job["databaseId"]}/logs','sha256':hashlib.sha256(p.stdout).hexdigest()}))
 (folder/(label+'.job.json')).write_text(json.dumps(metadata,indent=2)+'\n');result=module.classify(dest,metadata);dest.with_suffix('.classification.json').write_text(json.dumps(result,indent=2)+'\n');return {'job':job['name'],'conclusion':job['conclusion'],'completed_targets':result['completed_target_count'],'unfinished_targets':result['started_unfinished_target_count'],'completed_counts':result['completed_target_test_counts'],'partial_counts':result['unfinished_target_explicit_reported_test_counts'],'failed_tests':result['failed_test_names_explicit'],'unexecuted':None if result['unexecuted_targets'] is None else len(result['unexecuted_targets'])}
while True:
 states={};errors=[]
 for run,tag in runs:
  p=subprocess.run(['gh','run','view',str(run),'--json','databaseId,headSha,status,conclusion,event,jobs,url'],capture_output=True,text=True)
  if p.returncode:errors.append({'run':run,'error':p.stderr});continue
  state=json.loads(p.stdout);states[tag]=state;folder=o/tag;folder.mkdir(exist_ok=True);(folder/f'poll-{iteration:04}.json').write_text(p.stdout+'\n');(folder/'run-latest.json').write_text(p.stdout+'\n')
 downloads=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  futures=[pool.submit(download,run,tag,job) for run,tag in runs if tag in states for job in states[tag]['jobs'] if job['status']=='completed']
  for f in futures:
   try:downloads.append(f.result())
   except Exception as error:errors.append({'classification_error':__import__('traceback').format_exc()})
 summary={'iteration':iteration,'runs':{tag:{'run':s['databaseId'],'head':s['headSha'],'status':s['status'],'conclusion':s['conclusion'],'live_jobs':[{'job':j['databaseId'],'name':j['name'],'status':j['status']} for j in s['jobs'] if j['status']!='completed']} for tag,s in states.items()},'terminal_job_classification':downloads,'errors':errors};(o/'state.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
 if len(states)==2 and all(s['status']=='completed' for s in states.values()) and not errors and all(x.get('download')!='retry' for x in downloads):break
 iteration+=1;time.sleep(30)
