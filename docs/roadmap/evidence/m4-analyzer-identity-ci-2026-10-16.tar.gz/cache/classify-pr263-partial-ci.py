from pathlib import Path
import re,json,hashlib,collections

def classify(path,metadata):
 raw=Path(path).read_bytes();text=raw.decode(errors='replace');text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text).lstrip('\ufeff');lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ','',x) for x in text.splitlines()];plan=None
 for line in lines:
  if '"total_targets"' in line and '"targets"' in line:
   try:
    obj=json.loads(line)
    if isinstance(obj,dict) and 'targets' in obj:plan=obj;break
   except json.JSONDecodeError:pass
 records=[];current=None;loose=[]
 for line in lines:
  m=re.search(r'\bRunning\s+(tests/([^ /]+)\.rs|unittests\s+[^ ]+|[^ ]+\.rs)\s*\(([^)]+)\)',line)
  if m:
   current={'running':m[0],'target_name':m[2],'status':'started_unfinished','reported_tests':[],'started_tests':[],'summary':None};records.append(current)
  t=re.search(r'\btest\s+([^\s]+)\s+\.\.\.\s*(ok|FAILED|ignored)\b',line)
  start=re.search(r'\btest\s+([^\s]+)\s+\.\.\.',line)
  if start and current:current['started_tests'].append(start[1])
  if t:
   item={'name':t[1],'status':t[2]}
   if current:current['reported_tests'].append(item)
   else:loose.append(item)
  summary=re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',line)
  if summary:
   if current is None:current={'running':'<summary without captured Running line>','target_name':None,'reported_tests':[],'started_tests':[],'summary':None};records.append(current)
   current['summary']=dict(zip(['passed','failed','ignored','measured','filtered'],map(int,summary.groups()[1:])));current['status']='completed_'+summary[1].lower();current=None
 planned=plan['targets'] if plan else None;unmatched=[];remaining=list(enumerate(planned or []));cursor=0
 for record in records:
  if record['target_name'] is None:continue
  matches=[(i,target) for i,target in remaining if target[1]==record['target_name']]
  if matches:
   i,target=matches[0];record['planned_target']=target;record['plan_index']=i;remaining=[x for x in remaining if x[0]!=i]
  else:unmatched.append(record['target_name'])
 totals=collections.Counter();partial=collections.Counter();failed=[]
 for record in records:
  if record['summary']:totals.update(record['summary'])
  else:partial.update(x['status'] for x in record['reported_tests'])
  failed.extend(x['name'] for x in record['reported_tests'] if x['status']=='FAILED')
 out={'run':metadata['run'],'head':metadata['head'],'job':metadata['job'],'job_name':metadata['name'],'job_status':metadata['status'],'job_conclusion':metadata['conclusion'],'raw_log_sha256':hashlib.sha256(raw).hexdigest(),'plan':plan,'records':records,'started_target_count':len(records),'completed_target_count':sum(x['summary'] is not None for x in records),'started_unfinished_target_count':sum(x['summary'] is None for x in records),'completed_target_test_counts':dict(totals),'unfinished_target_explicit_reported_test_counts':dict(partial),'failed_test_names_explicit':failed,'unexecuted_targets':[target for i,target in remaining] if planned is not None else None,'unmatched_started_target_names':unmatched,'loose_reported_tests':loose,'limits':'Target completion requires captured Rust summary. Cancelled started targets without summary remain unfinished regardless of reported test outcomes. Unprinted test statuses unknown. Partial-target reported cases are NOT added as a full target pass. Foundation verifier repetitions are executions, not deduplicated tests. No acceptance/full-baseline claim.'}
 if metadata['name']=='foundation' and metadata['conclusion']=='success' and any(r['summary'] is None for r in records):
  out['completed_harness_summary_count']=out['completed_target_count']
  out['target_association_ambiguities']=[r['running'] for r in records if r['summary'] is None]
  out['completed_target_count']=None
  out['started_unfinished_target_count']=None
  for record in records:
   if record['summary'] is None:record['status']='summary_association_unconfirmed'
  out['limits']+=' Successful foundation stdout/stderr/Doc-tests interleaving leaves one target-summary association ambiguous; Rust summary execution totals remain exact. This is not classified as a cancelled/unfinished foundation target.'
 return out
if __name__=='__main__':
 import sys
 path=Path(sys.argv[1]);meta=json.loads(Path(sys.argv[2]).read_text());result=classify(path,meta);path.with_suffix('.classification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['plan','records','unexecuted_targets','loose_reported_tests']},indent=2))
