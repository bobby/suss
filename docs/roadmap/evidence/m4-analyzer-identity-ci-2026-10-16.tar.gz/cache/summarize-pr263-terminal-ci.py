from pathlib import Path
import json,re,collections,hashlib
root=Path('/home/bobby/.cache/suss-m4-work/pr263-ci-triage')
for tag in ['4ab','e55']:
 p=root/tag;run=json.loads((p/'run-latest.json').read_text());assert run['status']=='completed' and all(j['status']=='completed' for j in run['jobs']),tag
 xs=[json.loads((p/f'integration-{i}.classification.json').read_text()) for i in range(8)];counts=collections.Counter();partial=collections.Counter();failed=[];unfinished=[]
 for x in xs:
  counts.update(x['completed_target_test_counts']);partial.update(x['unfinished_target_explicit_reported_test_counts']);failed+=x['failed_test_names_explicit'];unfinished += [{'job':x['job_name'],'target':record['target_name'],'reported_tests':record['reported_tests']} for record in x['records'] if not record['summary']]
 planned=sum(len(x['plan']['targets']) for x in xs);completed=sum(x['completed_target_count'] for x in xs);started_unfinished=sum(x['started_unfinished_target_count'] for x in xs);unexecuted=sum(len(x['unexecuted_targets']) for x in xs);assert completed+started_unfinished+unexecuted==planned
 foundation=json.loads((p/'foundation.classification.json').read_text());unknown=[]
 for x in xs+[foundation]:
  path=p/('foundation.log' if x['job_name']=='foundation' else f"integration-{x['job_name'].split('(')[1].rstrip(')')}.log");announced=list(map(int,re.findall(r'\brunning (\d+) tests?',path.read_text())))
  if len(announced)==len(x['records']):
   for record,n in zip(x['records'],announced):
    if record['summary'] is None:
     known={v['name']:v['status'] for v in record['reported_tests']};unknown.append({'job':x['job_name'],'target':record['target_name'] or record['running'],'announced':n,'explicit_outcomes':len(known),'unknown_outcomes':n-len(known)})
 result={'run':run['databaseId'],'head':run['headSha'],'status':run['status'],'conclusion':run['conclusion'],'all_jobs_terminal':True,'integration':{'planned_targets':planned,'completed_targets':completed,'started_unfinished_targets':started_unfinished,'unexecuted_targets':unexecuted,'completed_target_test_counts':dict(counts),'unfinished_target_explicit_test_counts':dict(partial),'failed_test_names_explicit':failed,'unfinished_targets':unfinished,'failed_names_not_explicitly_captured':counts['failed']-len(failed)},'foundation':{k:v for k,v in foundation.items() if k in ['job_conclusion','completed_target_count','started_unfinished_target_count','completed_target_test_counts','unfinished_target_explicit_reported_test_counts']},'partial_unknown_outcomes':unknown,'source_proof':json.loads((p/'source-proof.json').read_text()),'limits':'Each published head is independent. Counts are execution observations, not deduplicated tests. Cancelled targets without Rust summary remain unfinished. Unknown test outcomes never promoted to passes/unexecuted. Raw unknowns retained. No full baseline or acceptance claim; cache-only pending main release.'};(p/'terminal-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and p.name!='terminal-cache-manifest.json'};(root/'terminal-cache-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
