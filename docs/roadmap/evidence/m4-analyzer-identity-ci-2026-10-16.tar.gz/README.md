# Analyzer identity CI evidence, 2026-10-16

Explicit packaging release received after both runs and every job were terminal.
This archive preserves 174 checksum-verified cache files, their original checksum
manifest, source proofs, raw logs, per-job plans/classifications and failure assertions.
No dirty worktree source snapshot is presented as CI source. No local build/test,
CI restart/cancellation, commit or push was performed for packaging.

Runs (independent source bases):
https://github.com/bobby/suss/actions/runs/38971935949 : 4ab8a76a48469b1138bba1dc14ad7deff5afcad6, cancelled.
https://github.com/bobby/suss/actions/runs/38973362610 : e55c0e2bd58a20cf01efa8f82808c981839d2b91, failure.

4ab integration: 252 planned targets =29 completed +1 started unfinished +222
unexecuted. Completed summaries:116 pass/16 fail/0 ignored. Unfinished
compiled_export_metadata announced5:3 explicit passes,2 unknown, no suite summary.
Cancelled foundation completed summaries:31 pass/0 fail/0 ignored across4 harness
records; unfinished suss_compile announced340:198 explicit passes,142 unknown.
Partial outcomes must not be added to completed-suite totals or treated as complete
passes. Unknown outcomes remain unknown rather than unexecuted target outcomes.

e55 integration:253 planned =29 completed +0 unfinished +224 unexecuted;
completed summaries106 pass/14 fail/0 ignored. Foundation succeeded:403 Rust
execution passes/0 fail/1 ignored, including verifier repeats, not distinct tests.
Foundation stdout/stderr Doc-tests interleaving prevents reliable per-target
association for one Running example line. The current classification qualifies
that ambiguity; it is not evidence of a cancelled/unfinished foundation harness.

Source: shard0 checkout logs identify synthetic commits; GitHub git commit JSON
proves each synthetic tree equals its published head tree. 4ab synthetic ce45a0143e39f84a0a50ce118fd64d64d52d680d,
tree950f652685246897469b93832ee34fb5dd641977. e55 synthetic bb34147f070ba2e49aa861126772bd6a9ad76224,
tree1229f664ad6339a291e8d3be400793cd0aaf7c1b. First runner-image Commit lines
are not checkout proofs. Full parents and API responses are preserved.

Failed-name comparison: constructor_source_nodes_match_pinned_children_tags_and_class_facts_after_gc
and quote_and_literal_child_records_match_pinned_without_datum_analysis newly
execute/fail in e55; their targets were unexecuted in4ab. Four previously failing
public_record* tests are absent because compiled_public_records is unexecuted in
e55, not because fixed. Exact names and boolean target checks are in
cache/head-execution-comparison.json. Plan252->253 reshuffles shard coverage.
No introduced-regression/resolution conclusion follows from changed failed lists.

Commands/derivation: cached watch-pr263-existing-ci.py performs read-only gh run
view RUN --repo bobby/suss --json status,conclusion,jobs,headSha polling and gh api
--allow-escape-sequences repos/bobby/suss/actions/jobs/JOB/logs retrieval;
per-job origin JSON records actual handles/commands. classify-pr263-partial-ci.py
parses actual Rust summaries separately from explicit partial test lines and
compares executed target names with the logged per-head target plans.
summarize-pr263-terminal-ci.py aggregates these classifications;
capture-pr263-ci-source-proof.py preserves GitHub git commit API GET responses.
Raw ANSI remains retained. Initial parser-incomplete files and preliminary
foundation association output are superseded, retained as failed tooling evidence;
use current *.classification.json and terminal-summary.json. CLI escape-byte
retrieval failures/retries are preserved; they are not guest/test failures.
Original cache summaries saying pending release describe their capture time;
this package records the subsequent explicit release without mutating originals.

No full workspace baseline, all-target CI pass, current dirty-source CI coverage,
acceptance completion or milestone/issue closure claim. Final aggregate test job
is a gate outcome, not a Rust test harness. Counts describe executions, not unique
test definitions. README/summary supplement the immutable raw cache.
