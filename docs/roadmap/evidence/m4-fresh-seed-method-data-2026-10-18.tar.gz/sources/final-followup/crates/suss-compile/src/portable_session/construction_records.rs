//! Construction records collected only by an explicitly recording FormBridge.
//! These audit direct facts; they are not a complete source/storage certificate.
use super::{
    ConstructorInputs, ScalarInputs, Session, SessionError, SessionValue, SourceArrayInputs,
};
use crate::portable::metered_map::Context;
use std::{cmp::Ordering, collections::hash_map::DefaultHasher, hash::Hasher};
use wasmtime::{AnyRef, RootScope, Rooted};

mod projection;
pub(crate) use projection::FactoryProjection;

// Invocation-local native identity-hash heads. No guest allocation or adapter
// call may occur while this table is live. Exact GC references decide membership.
#[derive(Default)]
struct InputHeads {
    slots: Vec<Option<(u64, usize)>>,
}
impl InputHeads {
    fn new(count: usize, meter: &mut InputIndex<'_>) -> Result<Self, SessionError> {
        if count == 0 { return Ok(Self::default()); }
        let capacity = count.checked_mul(2).and_then(usize::checked_next_power_of_two)
            .map(|n| n.max(4)).ok_or_else(|| SessionError::Host(wasmtime::Error::msg("Input table capacity overflow")))?;
        let bytes = capacity.checked_mul(std::mem::size_of::<Option<(u64, usize)>>())
            .filter(|n| *n <= isize::MAX as usize)
            .ok_or_else(|| SessionError::Host(wasmtime::Error::msg("Input table allocation overflow")))?;
        meter.charge(bytes as u64)?;
        let mut slots = Vec::new();
        slots.try_reserve_exact(capacity).map_err(|_| SessionError::Host(wasmtime::Error::msg("Input table allocation failed")))?;
        for _ in 0..capacity {
            meter.charge(1)?;
            slots.push(None);
        }
        Ok(Self { slots })
    }
    fn position(&self, hash: u64, meter: &mut InputIndex<'_>) -> Result<Option<usize>, SessionError> {
        if self.slots.is_empty() { meter.charge(1)?; return Ok(None); }
        meter.charge(3)?; // length, mask and initial placement arithmetic
        let mask = self.slots.len() - 1;
        let mut index = hash as usize & mask;
        for _ in 0..self.slots.len() {
            // Slot read, full hash comparison and bounded wrap arithmetic.
            meter.charge(4)?;
            match self.slots[index] {
                None => return Ok(Some(index)),
                Some((key, _)) if key == hash => return Ok(Some(index)),
                _ => index = (index + 1) & mask,
            }
        }
        Err(SessionError::Host(wasmtime::Error::msg("Input table probe bound exceeded")))
    }
    fn get(&self, hash: u64, meter: &mut InputIndex<'_>) -> Result<Option<usize>, SessionError> {
        let Some(index) = self.position(hash, meter)? else { return Ok(None); };
        meter.charge(2)?; // selected-slot reread and head extraction
        Ok(self.slots[index].map(|(_, head)| head))
    }
    fn insert(&mut self, hash: u64, head: usize, meter: &mut InputIndex<'_>) -> Result<Option<usize>, SessionError> {
        let index = self.position(hash, meter)?.ok_or_else(|| SessionError::Host(wasmtime::Error::msg("Empty input table insertion")))?;
        meter.charge(2)?;
        Ok(self.slots[index].replace((hash, head)).map(|(_, prior)| prior))
    }
}

struct InputIndex<'a> {
    session: &'a mut Session,
    hash_mask: u64,
}
impl Context<u64> for InputIndex<'_> {
    type Error = SessionError;
    fn charge(&mut self, units: u64) -> Result<(), SessionError> {
        self.session.charge_host_work(units)
    }
    fn compare(&mut self, a: &u64, b: &u64) -> Result<Ordering, SessionError> {
        self.charge(1)?;
        Ok(a.cmp(b))
    }
}
impl InputIndex<'_> {
    fn hash(&mut self, value: &SessionValue) -> Result<u64, SessionError> {
        self.session.check(value)?;
        self.charge(1)?;
        let mut scope = RootScope::new(&mut self.session.store);
        let value = value.value.to_rooted(&mut scope);
        let mut hash = DefaultHasher::new();
        value.ref_hash(&scope, &mut hash)?;
        Ok(hash.finish() & self.hash_mask)
    }
    fn same(&mut self, a: &SessionValue, b: &SessionValue) -> Result<bool, SessionError> {
        self.session.check(a)?;
        self.session.check(b)?;
        self.charge(1)?;
        let mut scope = RootScope::new(&mut self.session.store);
        let a = a.value.to_rooted(&mut scope);
        let b = b.value.to_rooted(&mut scope);
        Ok(Rooted::<AnyRef>::ref_eq(&scope, &a, &b)?)
    }
    fn contains_explicit<R: RecordAccess + ?Sized>(
        &mut self,
        index: &InputHeads,
        collisions: &[Option<usize>],
        records: &R,
        value: &SessionValue,
    ) -> Result<bool, SessionError> {
        let hash = self.hash(value)?;
        let mut cursor = index.get(hash, self)?;
        while let Some(id) = cursor {
            let record = records.record(id, self.session)?;
            if self.same(value, &record.value)? {
                return Ok(true);
            }
            cursor = collisions[id];
        }
        Ok(false)
    }
    fn contains<R: RecordAccess + ?Sized>(
        &mut self,
        index: &InputHeads,
        collisions: &[Option<usize>],
        records: &R,
        value: &SessionValue,
    ) -> Result<bool, SessionError> {
        if self.contains_explicit(index, collisions, records, value)? {
            return Ok(true);
        }
        // Copied fields of an EMPTY seed are covered by its pristine complete
        // storage witness, even when they were not bridge-created allocations.
        // Membership alone is not validation: direct seed checks remain required.
        for id in 0..records.len() {
            self.charge(1)?;
            let record = records.record(id, self.session)?;
            if let Fact::CanonicalSeed(seed) = &record.fact {
                if seed.contains_initial_reference(self.session, value)? {
                    return Ok(true);
                }
            }
        }
        Ok(false)
    }
}

pub(crate) enum Fact {
    Scalar(std::sync::Arc<ScalarInputs>),
    Array(Box<SourceArrayInputs>),
    Constructor(Box<ConstructorInputs>),
    CanonicalSeed(std::sync::Arc<super::canonical_seeds::CanonicalSeed>),
    ExternalSeed(&'static str),
}
// Keep the large immutable input owners out of every scalar/seed record slot.
// Charge the separate payload allocation and move before allocating it, plus
// bounded Box initialization/release controls. Existing nested input teardown
// keeps its prior policy. Page/directory fees use actual smaller slot sizes.
impl Fact {
    fn boxed<T>(session: &mut Session, inputs: T) -> Result<Box<T>, SessionError> {
        let bytes = record_bytes::<T>(1)?.checked_mul(2)
            .and_then(|bytes| bytes.checked_add(4))
            .ok_or_else(|| record_error("Construction fact allocation overflow"))?;
        session.charge_host_work(bytes)?;
        Ok(Box::new(inputs))
    }
    pub(crate) fn array(session: &mut Session, inputs: SourceArrayInputs) -> Result<Self, SessionError> {
        Ok(Self::Array(Self::boxed(session, inputs)?))
    }
    pub(crate) fn constructor(session: &mut Session, inputs: ConstructorInputs) -> Result<Self, SessionError> {
        Ok(Self::Constructor(Self::boxed(session, inputs)?))
    }
}
pub(crate) struct Record {
    pub value: SessionValue,
    pub fact: Fact,
}
impl AsRef<Record> for Record {
    fn as_ref(&self) -> &Record { self }
}
// Only ordinals index this native ledger. Pages/addresses never authorize a
// source edge. Logical page boundaries are independent of allocator capacity.
const RECORD_PAGE: usize = 32;
#[derive(Default)]
struct PagedRecords {
    pages: Vec<Vec<Record>>,
    len: usize,
    first_limit: usize,
}
fn record_error(message: &'static str) -> SessionError {
    SessionError::Host(wasmtime::Error::msg(message))
}
fn record_bytes<T>(count: usize) -> Result<u64, SessionError> {
    count
        .checked_mul(std::mem::size_of::<T>())
        .filter(|bytes| *bytes <= isize::MAX as usize)
        .and_then(|bytes| u64::try_from(bytes).ok())
        .ok_or_else(|| record_error("Construction record allocation overflow"))
}
fn record_reserve<T>(
    session: &mut Session,
    values: &mut Vec<T>,
    capacity: usize,
) -> Result<(), SessionError> {
    if capacity > values.capacity() {
        let bytes = record_bytes::<T>(capacity)?
            .checked_add(record_bytes::<T>(values.len())?)
            .ok_or_else(|| record_error("Construction record allocation overflow"))?;
        session.charge_host_work(bytes)?;
        values
            .try_reserve_exact(capacity - values.len())
            .map_err(|_| record_error("Construction record allocation failed"))?;
    }
    Ok(())
}
// Slice views keep differential tests and selected-ledger checks independent
// of the page representation. Every read is fallible and metered.
trait RecordAccess {
    fn len(&self) -> usize;
    fn record<'a>(&'a self, id: usize, session: &mut Session) -> Result<&'a Record, SessionError>;
}
impl<R: AsRef<Record>> RecordAccess for [R] {
    fn len(&self) -> usize {
        <[R]>::len(self)
    }
    fn record<'a>(&'a self, id: usize, session: &mut Session) -> Result<&'a Record, SessionError> {
        session.charge_host_work(1)?;
        self.get(id)
            .map(AsRef::as_ref)
            .ok_or_else(|| record_error("Unknown construction record"))
    }
}
impl RecordAccess for PagedRecords {
    fn len(&self) -> usize {
        self.len
    }
    fn record<'a>(&'a self, id: usize, session: &mut Session) -> Result<&'a Record, SessionError> {
        // Bounds, page/slot arithmetic, directory and slot reads.
        session.charge_host_work(5)?;
        if id >= self.len {
            return Err(record_error("Unknown construction record"));
        }
        self.pages
            .get(id / RECORD_PAGE)
            .and_then(|page| page.get(id % RECORD_PAGE))
            .ok_or_else(|| record_error("Incomplete construction record page"))
    }
}
impl PagedRecords {
    fn push(&mut self, session: &mut Session, record: Record) -> Result<(), SessionError> {
        // Length advance, offsets, last-page selection and reserve predicates.
        session.charge_host_work(8)?;
        let next_len = self
            .len
            .checked_add(1)
            .ok_or_else(|| record_error("Construction record length overflow"))?;
        let page_id = self.len / RECORD_PAGE;
        let offset = self.len % RECORD_PAGE;
        if offset == 0 {
            // Directory capacity can survive failure, but an empty page cannot
            // become visible. Stage the new page privately until all fees pass.
            if self.pages.len() == self.pages.capacity() {
                let capacity = self
                    .pages
                    .capacity()
                    .checked_mul(2)
                    .map(|n| n.max(4))
                    .ok_or_else(|| record_error("Construction record directory overflow"))?;
                record_reserve(session, &mut self.pages, capacity)?;
            }
            let limit = if page_id == 0 { 4 } else { RECORD_PAGE };
            let mut page = Vec::new();
            record_reserve(session, &mut page, limit)?;
            session.charge_host_work(5)?; // record/page pushes, len/initial-capacity publication
            page.push(record);
            self.pages.push(page);
            if page_id == 0 {
                self.first_limit = limit;
            }
        } else {
            if page_id == 0 && offset == self.first_limit {
                let limit = self
                    .first_limit
                    .checked_mul(2)
                    .filter(|n| *n <= RECORD_PAGE)
                    .ok_or_else(|| record_error("Construction record first-page overflow"))?;
                record_reserve(session, &mut self.pages[0], limit)?;
                // Reserve bookkeeping may survive a later debit failure.
                self.first_limit = limit;
            }
            session.charge_host_work(3)?; // page selection, reserved push, len publication
            self.pages[page_id].push(record);
        }
        self.len = next_len;
        Ok(())
    }
}
pub(crate) struct BridgeClassInput {
    pub name: &'static str,
    pub constructor: Option<SessionValue>,
    pub descriptor: SessionValue,
}
struct ChildBinding { value: SessionValue }
pub(crate) struct ConstructionRecords {
    domain: std::sync::Arc<super::write_domain::WriteDomain>,
    children: Vec<ChildBinding>,
    records: PagedRecords,
    bridge_classes: Vec<BridgeClassInput>,
    class_prechecks_valid: bool,
}
impl ConstructionRecords {
    pub(crate) fn with_bridge_classes(bridge_classes: Vec<BridgeClassInput>) -> Self {
        Self {
            domain: super::write_domain::WriteDomain::new(),
            children: Vec::new(),
            records: PagedRecords::default(),
            bridge_classes,
            class_prechecks_valid: true,
        }
    }
    pub(crate) fn note_class_precheck(&mut self, valid: bool) {
        self.class_prechecks_valid &= valid;
        if !valid {self.domain.invalidate();}
    }
    pub(crate) fn matches_class_schemas(
        &self, session: &mut Session,
    ) -> Result<bool, SessionError> {
        self.check_class_schemas(session, None)
    }
    pub(crate) fn matches_class_schemas_audited(
        &self, session: &mut Session, audit: &mut super::certification_audit::CertificationAudit,
    ) -> Result<bool, SessionError> {
        self.check_class_schemas(session, Some(audit))
    }
    fn check_class_schemas(
        &self, session: &mut Session, mut audit: Option<&mut super::certification_audit::CertificationAudit>,
    ) -> Result<bool, SessionError> {
        let _request = session.operation_budget_scope()?;
        let expected = crate::portable_macro_data::source_class_names().len() + 1;
        let mut valid = self.class_prechecks_valid && self.bridge_classes.len() == expected;
        let mut seen = Vec::new();
        session.charge_host_work(expected as u64 + 1)?;
        seen.try_reserve_exact(expected).map_err(|_| {
            SessionError::Host(wasmtime::Error::msg("Class coverage allocation failed"))
        })?;
        for _ in 0..expected {
            session.charge_host_work(1)?;
            seen.push(false);
        }
        let mut expected_names = crate::portable_macro_data::source_class_names()
            .chain(std::iter::once("SourceArray")).enumerate();
        for input in &self.bridge_classes {
            session.charge_host_work(1)?;
            let mut position = None;
            if let Some((index, name)) = expected_names.next() {
                session.charge_host_work(input.name.len() as u64 + name.len() as u64 + 1)?;
                if input.name == name { position = Some(index); }
            }
            if position.is_none() {
                for (index, name) in crate::portable_macro_data::source_class_names()
                    .chain(std::iter::once("SourceArray"))
                    .enumerate()
                {
                    session.charge_host_work(input.name.len() as u64 + name.len() as u64 + 1)?;
                    if input.name == name {
                        position = Some(index);
                        break;
                    }
                }
            }
            if let Some(index) = position {
                valid &= !seen[index];
                seen[index] = true;
            } else {
                valid = false;
            }
            // Do not suppress a later budget/interrupt error after a false audit.
            valid &= match audit.as_deref_mut() {
                Some(audit) => audit.class_at(session, input, position)?,
                None => session.initial_source_class_matches(
                    input.name, input.constructor.as_ref(), &input.descriptor,
                )?,
            };
        }
        for present in seen {
            session.charge_host_work(1)?;
            valid &= present;
        }
        Ok(valid)
    }
    pub(crate) fn matches_prototype_origins(&self, session: &mut Session) -> Result<bool, SessionError> {
        self.check_prototype_origins(session, None)
    }
    pub(crate) fn matches_prototype_origins_audited(
        &self, session: &mut Session, audit: &mut super::certification_audit::CertificationAudit,
    ) -> Result<bool, SessionError> {
        self.check_prototype_origins(session, Some(audit))
    }
    fn check_prototype_origins(
        &self, session: &mut Session, mut audit: Option<&mut super::certification_audit::CertificationAudit>,
    ) -> Result<bool, SessionError> {
        let _request = session.operation_budget_scope()?;
        let mut valid = true;
        for id in 0..self.records.len() {
            session.charge_host_work(1)?;
            let record = self.records.record(id, session)?;
            if let Fact::Constructor(inputs) = &record.fact {
                valid &= match audit.as_deref_mut() {
                    Some(audit) => inputs.matches_prototype_origin_audited(session, audit)?,
                    None => inputs.matches_prototype_origin(session)?,
                };
            }
        }
        Ok(valid)
    }
    // This closes only recorded constructor/array input edges, not all physical
    // storage. Descriptor state, seeds and memo transitions need separate proof.
    pub(crate) fn matches_recorded_inputs(
        &self,
        session: &mut Session,
        root: &SessionValue,
    ) -> Result<bool, SessionError> {
        self.check_recorded_inputs(session, root, u64::MAX)
    }
    fn check_recorded_inputs(
        &self,
        session: &mut Session,
        root: &SessionValue,
        hash_mask: u64,
    ) -> Result<bool, SessionError> {
        Self::check_selected_inputs(session, root, hash_mask, &self.records, &self.children)
    }
    fn check_selected_inputs<R: RecordAccess + ?Sized>(
        session: &mut Session, root: &SessionValue, hash_mask: u64,
        records: &R, children: &[ChildBinding],
    ) -> Result<bool, SessionError> {
        let _request = session.operation_budget_scope()?;
        let mut meter = InputIndex { session, hash_mask };
        let tracing = std::env::var_os("SUSS_INPUT_INDEX_TRACE").is_some();
        let trace = |meter: &InputIndex<'_>, stage: &str| {
            if tracing { eprintln!("input-index records={} stage={stage} fuel={:?}",
                records.len(), meter.session.operation_fuel_remaining()); }
        };
        trace(&meter, "start");
        let mut index = InputHeads::new(records.len(), &mut meter)?;
        let bytes = records
            .len()
            .checked_mul(std::mem::size_of::<Option<usize>>())
            .ok_or_else(|| SessionError::Host(wasmtime::Error::msg("Input index overflow")))?;
        meter.charge(bytes as u64)?;
        let mut collisions = Vec::new();
        collisions
            .try_reserve_exact(records.len())
            .map_err(|_| {
                SessionError::Host(wasmtime::Error::msg("Input index allocation failed"))
            })?;
        trace(&meter, "reserved");
        // No guest execution or guest allocation occurs while this ephemeral
        // identity-hash index is live. Collision chains always use ref_eq.
        for id in 0..records.len() {
            let record = records.record(id, meter.session)?;
            let hash = meter.hash(&record.value)?;
            // insert returns the previous head from the same charged probe.
            // Collision capacity was reserved above, so publication needs no
            // fallible work between updating the head and recording its link.
            let prior = index.insert(hash, id, &mut meter)?;
            collisions.push(prior);
            if tracing && (id + 1).is_multiple_of(64) {
                eprintln!("input-index indexed={} records={} fuel={:?}", id + 1,
                    records.len(), meter.session.operation_fuel_remaining());
            }
        }
        trace(&meter, "built");
        let mut valid = meter.contains_explicit(&index, &collisions, records, root)?;
        trace(&meter, "root");
        let edges = Self::check_selected_edges(&mut meter, &index, &collisions, records, children);
        trace(&meter, "edges-return");
        if tracing { eprintln!("input-index edge-result={:?}", edges.as_ref().map_err(|e| e.to_string())); }
        valid &= edges?;
        Ok(valid)
    }
    fn check_input_edges(
        &self,
        meter: &mut InputIndex<'_>,
        index: &InputHeads,
        collisions: &[Option<usize>],
    ) -> Result<bool, SessionError> {
        Self::check_selected_edges(meter, index, collisions, &self.records, &self.children)
    }
    fn check_selected_edges<R: RecordAccess + ?Sized>(
        meter: &mut InputIndex<'_>, index: &InputHeads, collisions: &[Option<usize>],
        records: &R, children: &[ChildBinding],
    ) -> Result<bool, SessionError> {
        let mut valid = true;
        for id in 0..records.len() {
            meter.charge(1)?;
            let record = records.record(id, meter.session)?;
            match &record.fact {
                Fact::Array(fact) => {
                    for value in fact.inputs() {
                        let mut member=meter.contains(index, collisions, records, value)?;
                        if !member {
                            for child in children {
                                meter.charge(1)?;
                                if meter.same(value,&child.value)? {member=true;break;}
                            }
                        }
                        valid &= member;
                    }
                }
                Fact::Constructor(fact) => {
                    for value in fact.inputs() {
                        let mut member=meter.contains(index, collisions, records, value)?;
                        if !member {
                            for child in children {
                                meter.charge(1)?;
                                if meter.same(value,&child.value)? {member=true;break;}
                            }
                        }
                        valid &= member;
                    }
                }
                Fact::ExternalSeed(_) => valid = false,
                Fact::Scalar(_) => {}
                Fact::CanonicalSeed(_) => {}
            }
        }
        Ok(valid)
    }
    pub(crate) fn attach_source_child(
        &mut self, session:&mut Session,
        child:&crate::portable_macro_graph::source_roots::CheckedChild,
    )->Result<(),SessionError> {
        session.check(child.value())?;
        if self.children.len()==self.children.capacity() {
            let count=self.children.len().checked_mul(2).unwrap_or(usize::MAX).max(4);
            let bytes=count.checked_add(self.children.len()).and_then(|n|n.checked_mul(std::mem::size_of::<ChildBinding>()))
                .ok_or_else(||SessionError::Host(wasmtime::Error::msg("Source-child capacity overflow")))?;
            session.charge_host_work(bytes as u64)?;
            self.children.try_reserve_exact(count-self.children.len())
                .map_err(|_|SessionError::Host(wasmtime::Error::msg("Source-child allocation failed")))?;
        }
        // A failed domain attachment publishes no closure membership.
        session.charge_host_work(1)?;
        self.domain.attach_child(session,child)?;
        self.children.push(ChildBinding {value:child.value().clone()});
        Ok(())
    }
    pub(crate) fn seal_source_domain(&self, session:&mut Session)->Result<(),SessionError> {
        self.domain.seal(session)
    }
    pub(crate) fn write_domain(&self)->std::sync::Arc<super::write_domain::WriteDomain> {self.domain.clone()}
    pub(crate) fn push(&mut self,session:&mut Session,value:SessionValue,fact:Fact)->Result<(),SessionError> {
        self.domain.record(session,&value,&fact)?;
        self.push_prepared(session,value,fact)
    }
    pub(crate) fn push_prepared(
        &mut self,
        session: &mut Session,
        value: SessionValue,
        fact: Fact,
    ) -> Result<(), SessionError> {
        self.records.push(session, Record { value, fact })
    }
    pub(crate) fn len(&self) -> usize {
        self.records.len()
    }
    pub(crate) fn external_seeds(&self, session: &mut Session) -> Result<usize, SessionError> {
        let mut count = 0;
        for id in 0..self.records.len() {
            session.charge_host_work(1)?;
            let record = self.records.record(id, session)?;
            if let Fact::ExternalSeed(name) = &record.fact {
                session.charge_host_work(name.len() as u64)?;
                count += 1;
            }
        }
        Ok(count)
    }
    // The second component remains the full strict certificate predicate.
    // A true first component alone grants no memo, child-domain or cache authority.
    pub(crate) fn fresh_direct_status(&self, session: &mut Session)
        -> Result<(bool, bool), SessionError> {
        let _request = session.operation_budget_scope()?;
        let mut source = true;
        let mut certified = true;
        for id in 0..self.records.len() {
            session.charge_host_work(1)?;
            let record = self.records.record(id, session)?;
            let (data, reusable) = match &record.fact {
                Fact::Constructor(fact) => fact.fresh_direct_status(session, &record.value)?,
                Fact::Scalar(fact) => { let valid = fact.matches(session, &record.value)?; (valid, valid) }
                Fact::Array(fact) => { let valid = fact.matches(session, &record.value)?; (valid, valid) }
                Fact::CanonicalSeed(fact) => fact.fresh_direct_status(session, &record.value)?,
                Fact::ExternalSeed(_) => (false, false),
            };
            session.charge_host_work(2)?;
            source &= data;
            certified &= reusable;
        }
        Ok((source, certified))
    }
    // Fresh proof values close only this transient input walk. They are never
    // attached to a write domain or converted into a CheckedChild.
    pub(crate) fn matches_fresh_source_inputs(
        &self, session: &mut Session, root: &SessionValue,
        children: &[crate::portable_macro_graph::source_roots::FreshSourceProof],
    ) -> Result<bool, SessionError> {
        let _request = session.operation_budget_scope()?;
        let count = self.children.len().checked_add(children.len())
            .ok_or_else(|| record_error("Fresh input coverage overflow"))?;
        let bytes = record_bytes::<ChildBinding>(count)?;
        session.charge_host_work(bytes.checked_add(count as u64)
            .ok_or_else(|| record_error("Fresh input allocation overflow"))?)?;
        let mut selected = Vec::new();
        selected.try_reserve_exact(count)
            .map_err(|_| record_error("Fresh input allocation failed"))?;
        for child in &self.children { selected.push(ChildBinding { value: child.value.clone() }); }
        for child in children {
            session.check(child.value())?;
            selected.push(ChildBinding { value: child.value().clone() });
        }
        Self::check_selected_inputs(session, root, u64::MAX, &self.records, &selected)
    }
    pub(crate) fn matches_direct_facts(&self, session: &mut Session) -> Result<bool, SessionError> {
        let _request = session.operation_budget_scope()?;
        let mut valid = true;
        for id in 0..self.records.len() {
            session.charge_host_work(1)?;
            let record = self.records.record(id, session)?;
            // Never short-circuit later inspection/budget/interrupt failures.
            valid &= match &record.fact {
                Fact::Scalar(fact) => fact.matches(session, &record.value)?,
                Fact::Array(fact) => fact.matches(session, &record.value)?,
                Fact::Constructor(fact) => fact.matches(session, &record.value)?,
                Fact::CanonicalSeed(fact) => fact.matches(session, &record.value)?,
                Fact::ExternalSeed(_) => false,
            };
        }
        Ok(valid)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn boxed_fact_cuts_release_unpublished_inputs_and_preserve_existing_records() {
        use crate::portable::{hir::Literal, resolve::Phase};
        enum Prepared { Array(SourceArrayInputs), Constructor(ConstructorInputs) }
        fn prepare(session: &mut Session, class: &SessionValue, input: &SessionValue, constructor: bool)
            -> (SessionValue, Prepared) {
            if constructor {
                let (value, inputs) = session.data_construct_with_inputs(class, &[input]).unwrap();
                (value, Prepared::Constructor(inputs.unwrap()))
            } else {
                let (value, inputs) = session.data_array_with_inputs(&[input]).unwrap();
                (value, Prepared::Array(inputs))
            }
        }
        fn rebox(session: &mut Session, fact: Prepared) -> Result<Fact, SessionError> {
            match fact {
                Prepared::Constructor(inputs) => Fact::constructor(session, inputs),
                Prepared::Array(inputs) => Fact::array(session, inputs),
            }
        }
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = match phase {
                Phase::Runtime => Session::new_repl().unwrap(),
                Phase::Macro => Session::new_macro().unwrap(),
            };
            session.eval("(deftype BoxedRecordInput [x])").unwrap();
            let class = session.eval("BoxedRecordInput").unwrap();
            let input = session.data_scalar(&Literal::Number(17.0)).unwrap();
            let mut prior = paged_prefix(&mut session, &input, 33);
            for constructor in [false, true] {
                let (value, fact) = prepare(&mut session, &class, &input, constructor);
                let request = session.operation_budget_scope().unwrap();
                let before = session.operation_fuel_remaining().unwrap();
                let fact = rebox(&mut session, fact).unwrap();
                let cost = before - session.operation_fuel_remaining().unwrap();
                drop((fact, value, request));
                let handles = session.stats().external_value_handles;
                for allowance in 0..cost {
                    let (value, fact) = prepare(&mut session, &class, &input, constructor);
                    let request = session.operation_budget_scope().unwrap();
                    session.store.set_fuel(allowance).unwrap();
                    let error = rebox(&mut session, fact).err().unwrap();
                    assert!(matches!(error, SessionError::Trap(ref e)
                        if e.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)));
                    drop((value, request));
                    assert_eq!(session.stats().external_value_handles, handles);
                    assert_eq!(prior.len(), 33);
                }
                let (value, fact) = prepare(&mut session, &class, &input, constructor);
                let request = session.operation_budget_scope().unwrap();
                session.interrupt_handle().interrupt();
                assert!(rebox(&mut session, fact).err().unwrap().is_interrupt());
                drop((value, request));
                assert_eq!(session.stats().external_value_handles, handles);
                let (value, fact) = prepare(&mut session, &class, &input, constructor);
                let fact = session.with_operation_budget(|session| rebox(session, fact)).unwrap();
                session.collect().unwrap();
                match &fact {
                    Fact::Array(inputs) => assert!(inputs.matches(&mut session, &value).unwrap()),
                    Fact::Constructor(inputs) => assert!(inputs.matches(&mut session, &value).unwrap()),
                    _ => unreachable!(),
                }
                prior.push(&mut session, Record { value, fact }).unwrap();
                assert_eq!(prior.len(), 34);
                // Removing only this private test append leaves every old slot.
                prior.pages.last_mut().unwrap().pop();
                prior.len -= 1;
                for id in 0..33 {
                    let old = prior.record(id, &mut session).unwrap().value.clone();
                    assert!(session.values_identical(&old, &input).unwrap());
                }
            }
        }
    }
    fn paged_prefix(session: &mut Session, value: &SessionValue, count: usize) -> PagedRecords {
        let mut records = PagedRecords::default();
        for _ in 0..count {
            records
                .push(
                    session,
                    Record {
                        value: value.clone(),
                        fact: Fact::ExternalSeed("page-fault-fixture"),
                    },
                )
                .unwrap();
        }
        records
    }
    #[test]
    fn paged_records_preserve_ordinals_boundaries_and_logical_pages_with_excess_capacity() {
        let mut session = Session::new().unwrap();
        let _request = session.operation_budget_scope().unwrap();
        let mut records = PagedRecords::default();
        let mut expected = Vec::new();
        for id in 0..133 {
            let value = session
                .data_scalar(&crate::portable::hir::Literal::Number(id as f64))
                .unwrap();
            records
                .push(
                    &mut session,
                    Record {
                        value: value.clone(),
                        fact: Fact::ExternalSeed("ordinal-fixture"),
                    },
                )
                .unwrap();
            expected.push(value);
            assert_eq!(records.len(), id + 1);
            assert_eq!(records.pages.len(), (id + RECORD_PAGE) / RECORD_PAGE);
            for page in &records.pages[..records.pages.len() - 1] {
                assert_eq!(page.len(), RECORD_PAGE);
            }
            assert!(!records.pages.last().unwrap().is_empty());
        }
        for id in (0..expected.len()).rev() {
            let record = records.record(id, &mut session).unwrap();
            let mut meter = InputIndex {
                session: &mut session,
                hash_mask: 0,
            };
            assert!(meter.same(&record.value, &expected[id]).unwrap());
        }
        assert!(records.record(records.len(), &mut session).is_err());
        assert!(record_bytes::<Record>(usize::MAX).is_err());
        // Allocator excess MUST NOT move the logical page boundary.
        let value = expected[0].clone();
        let mut excess = paged_prefix(&mut session, &value, 4);
        excess.pages[0].try_reserve_exact(128).unwrap();
        for _ in 4..33 {
            excess
                .push(
                    &mut session,
                    Record {
                        value: value.clone(),
                        fact: Fact::ExternalSeed("excess-capacity"),
                    },
                )
                .unwrap();
        }
        assert_eq!(excess.pages.len(), 2);
        assert_eq!(excess.pages[0].len(), RECORD_PAGE);
        assert_eq!(excess.pages[1].len(), 1);
    }
    #[test]
    fn paged_records_every_append_fuel_cut_and_irq_leave_no_partial_page_and_retry() {
        let mut session = Session::new().unwrap();
        let value = session
            .data_scalar(&crate::portable::hir::Literal::Number(17.0))
            .unwrap();
        for count in [0, 4, 8, 16, 32, 64, 128] {
            let cost = session
                .with_operation_budget(|session| {
                    let mut records = paged_prefix(session, &value, count);
                    let before = session.operation_fuel_remaining()?;
                    records.push(
                        session,
                        Record {
                            value: value.clone(),
                            fact: Fact::ExternalSeed("candidate"),
                        },
                    )?;
                    Ok(before - session.operation_fuel_remaining()?)
                })
                .unwrap();
            for allowance in 0..cost {
                let mut records = session.with_operation_budget(|session| {
                        let mut records = paged_prefix(session, &value, count);
                        let pages = records.pages.len();
                        session.store.set_fuel(allowance)?;
                        let error = records.push(session, Record { value: value.clone(), fact: Fact::ExternalSeed("candidate") }).unwrap_err();
                        assert!(matches!(error, SessionError::Trap(ref error)
                            if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)));
                        assert_eq!(records.len(), count);
                        assert_eq!(records.pages.len(), pages, "no empty page may be published on failure");
                        assert!(records.pages.iter().all(|page| !page.is_empty()));
                        Ok(records)
                    }).unwrap();
                session
                    .with_operation_budget(|session| {
                        for id in 0..count {
                            let record = records.record(id, session)?;
                            assert!(matches!(
                                &record.fact,
                                Fact::ExternalSeed("page-fault-fixture")
                            ));
                            let mut meter = InputIndex {
                                session,
                                hash_mask: 0,
                            };
                            assert!(meter.same(&record.value, &value)?);
                        }
                        records.push(
                            session,
                            Record {
                                value: value.clone(),
                                fact: Fact::ExternalSeed("candidate"),
                            },
                        )?;
                        assert_eq!(records.len(), count + 1);
                        assert!(matches!(
                            &records.record(count, session)?.fact,
                            Fact::ExternalSeed("candidate")
                        ));
                        Ok(())
                    })
                    .unwrap();
            }
            let mut records = session
                .with_operation_budget(|session| Ok(paged_prefix(session, &value, count)))
                .unwrap();
            session
                .with_operation_budget(|session| {
                    let pages = records.pages.len();
                    session.interrupt_handle().interrupt();
                    assert!(
                        records
                            .push(
                                session,
                                Record {
                                    value: value.clone(),
                                    fact: Fact::ExternalSeed("candidate")
                                }
                            )
                            .unwrap_err()
                            .is_interrupt()
                    );
                    assert_eq!(records.len(), count);
                    assert_eq!(records.pages.len(), pages);
                    Ok(())
                })
                .unwrap();
            session
                .with_operation_budget(|session| {
                    records.push(
                        session,
                        Record {
                            value: value.clone(),
                            fact: Fact::ExternalSeed("candidate"),
                        },
                    )
                })
                .unwrap();
            assert_eq!(records.len(), count + 1);
        }
    }
    #[test]
    fn construction_records_table_clustered_hashes_and_empty_overflow() {
        let mut session = Session::new().unwrap();
        let _request = session.operation_budget_scope().unwrap();
        let mut meter = InputIndex { session: &mut session, hash_mask: u64::MAX };
        let empty = InputHeads::new(0, &mut meter).unwrap();
        assert_eq!(empty.get(0, &mut meter).unwrap(), None);
        assert!(InputHeads::new(usize::MAX, &mut meter).is_err());
        for count in [1, 3, 4, 5, 17] {
            let mut table = InputHeads::new(count, &mut meter).unwrap();
            let stride = table.slots.len() as u64;
            // Distinct full hashes deliberately share one placement bucket.
            for id in 0..count {
                assert_eq!(table.insert(stride * id as u64 + stride - 1, id, &mut meter).unwrap(), None);
            }
            for id in 0..count {
                assert_eq!(table.get(stride * id as u64 + stride - 1, &mut meter).unwrap(), Some(id));
            }
            assert_eq!(table.get(stride * count as u64 + stride - 1, &mut meter).unwrap(), None);
            assert_eq!(table.insert(stride - 1, count, &mut meter).unwrap(), Some(0));
            assert_eq!(table.get(stride - 1, &mut meter).unwrap(), Some(count));
        }
    }

    #[test]
    fn construction_records_table_probe_failures_leave_heads_unchanged() {
        let mut session = Session::new().unwrap();
        let _request = session.operation_budget_scope().unwrap();
        let mut meter = InputIndex { session: &mut session, hash_mask: u64::MAX };
        let mut table = InputHeads::new(4, &mut meter).unwrap();
        for (id, hash) in [0, 8, 16].into_iter().enumerate() {
            table.insert(hash, id, &mut meter).unwrap();
        }
        // Fourth distinct collision and replacement of the third occupied slot.
        for hash in [24, 16] {
            meter.session.store.set_fuel(1_000_000).unwrap();
            let original = table.slots.clone();
            let before = meter.session.store.get_fuel().unwrap();
            table.insert(hash, 99, &mut meter).unwrap();
            let cost = before - meter.session.store.get_fuel().unwrap();
            table.slots.clone_from(&original);
            for allowance in 0..cost {
                meter.session.store.set_fuel(allowance).unwrap();
                let error = table.insert(hash, 99, &mut meter).unwrap_err();
                assert!(matches!(error, SessionError::Trap(ref e) if e.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)), "{error:?}");
                assert_eq!(table.slots, original);
            }
            meter.session.store.set_fuel(1_000_000).unwrap();
            assert_eq!(table.get(16, &mut meter).unwrap(), Some(2));
            meter.session.interrupt_handle().interrupt();
            assert!(table.insert(hash, 99, &mut meter).unwrap_err().is_interrupt());
            assert_eq!(table.slots, original);
        }
    }

    #[test]
    fn construction_records_missing_root_does_not_skip_later_edge_budget_errors() {
        let mut session = Session::new().unwrap();
        let root = session
            .data_scalar(&crate::portable::hir::Literal::Number(17.0))
            .unwrap();
        let mut records = ConstructionRecords::default();
        records
            .push(&mut session, root.clone(), Fact::ExternalSeed("unverified"))
            .unwrap();
        let index = InputHeads::default();
        for interrupted in [false, true] {
            let request = session.operation_budget_scope().unwrap();
            let mut meter = InputIndex {
                session: &mut session,
                hash_mask: u64::MAX,
            };
            assert!(
                !meter
                    .contains_explicit(&index, &[None], &records.records, &root)
                    .unwrap()
            );
            if interrupted {
                meter.session.interrupt_handle().interrupt();
            } else {
                meter.session.store.set_fuel(0).unwrap();
            }
            let error = records
                .check_input_edges(&mut meter, &index, &[None])
                .unwrap_err();
            if interrupted {
                assert!(error.is_interrupt(), "{error:?}");
            } else {
                assert!(
                    matches!(error, SessionError::Trap(ref e) if e.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)),
                    "{error:?}"
                );
            }
            drop(request);
        }
        assert!(
            !records
                .matches_recorded_inputs(&mut session, &root)
                .unwrap()
        );
    }
    #[test]
    fn construction_records_follow_normalized_constructor_fields_not_unused_arguments() {
        for phase in [
            crate::portable::resolve::Phase::Runtime,
            crate::portable::resolve::Phase::Macro,
        ] {
            let mut session = match phase {
                crate::portable::resolve::Phase::Runtime => Session::new_repl().unwrap(),
                crate::portable::resolve::Phase::Macro => Session::new_macro().unwrap(),
            };
            session.eval("(deftype RecordedInputProbe [a b])").unwrap();
            let class = session.eval("RecordedInputProbe").unwrap();
            let unused = session
                .data_scalar(&crate::portable::hir::Literal::Number(7.0))
                .unwrap();
            let (child, fact) = session
                .data_scalar_with_inputs(&crate::portable::hir::Literal::Number(11.0))
                .unwrap();
            let descriptor = session.data_descriptor(&class, true).unwrap();
            session
                .inspect(&descriptor, |mut store, value| {
                    let descriptor = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                    let schema = descriptor
                        .field(&mut store, 1)?
                        .unwrap_anyref()
                        .unwrap()
                        .as_array(&store)?
                        .unwrap();
                    let name = schema.get(&mut store, 0)?;
                    schema.set(&mut store, 1, name)?;
                    Ok(())
                })
                .unwrap();
            let (parent, inputs) = session
                .data_construct_with_inputs(&class, &[&unused, &child, &unused])
                .unwrap();
            let mut records = ConstructionRecords::default();
            records
                .push(
                    &mut session,
                    parent.clone(),
                    Fact::Constructor(Box::new(inputs.unwrap())),
                )
                .unwrap();
            assert!(
                !records
                    .matches_recorded_inputs(&mut session, &parent)
                    .unwrap()
            );
            // Last duplicate name wins; neither overwritten nor extra arguments
            // are retained inputs. Padding is the immutable Undefined sentinel.
            records
                .push(&mut session, child, Fact::Scalar(fact))
                .unwrap();
            session.collect().unwrap();
            assert!(
                records
                    .matches_recorded_inputs(&mut session, &parent)
                    .unwrap()
            );
            assert!(records.matches_direct_facts(&mut session).unwrap());
            let (padded, inputs) = session
                .data_construct_with_inputs(&class, &[&unused])
                .unwrap();
            let mut padded_records = ConstructionRecords::default();
            padded_records
                .push(
                    &mut session,
                    padded.clone(),
                    Fact::Constructor(Box::new(inputs.unwrap())),
                )
                .unwrap();
            assert!(
                padded_records
                    .matches_recorded_inputs(&mut session, &padded)
                    .unwrap()
            );
            assert!(padded_records.matches_direct_facts(&mut session).unwrap());
            session.reset().unwrap();
            assert!(matches!(
                records.matches_recorded_inputs(&mut session, &parent),
                Err(SessionError::ForeignValue)
            ));
        }
    }
    #[test]
    fn construction_records_require_independent_child_facts_and_exact_root() {
        let mut session = Session::new().unwrap();
        let (child, fact) = session
            .data_scalar_with_inputs(&crate::portable::hir::Literal::String(vec![17]))
            .unwrap();
        let (parent, array) = session.data_array_with_inputs(&[&child, &child]).unwrap();
        let mut records = ConstructionRecords::default();
        records
            .push(&mut session, parent.clone(), Fact::Array(Box::new(array)))
            .unwrap();
        session.collect().unwrap();
        assert!(records.matches_direct_facts(&mut session).unwrap());
        assert!(
            !records
                .matches_recorded_inputs(&mut session, &parent)
                .unwrap()
        );
        records
            .push(&mut session, child, Fact::Scalar(fact))
            .unwrap();
        session.collect().unwrap();
        assert!(
            records
                .matches_recorded_inputs(&mut session, &parent)
                .unwrap()
        );
        let other = session
            .data_scalar(&crate::portable::hir::Literal::String(vec![17]))
            .unwrap();
        assert!(
            !records
                .matches_recorded_inputs(&mut session, &other)
                .unwrap()
        );
        // Force distinct references into one bucket: hash equality must never
        // substitute for GC-reference equality, including after collection.
        assert!(
            records
                .check_recorded_inputs(&mut session, &parent, 0)
                .unwrap()
        );
        assert!(
            !records
                .check_recorded_inputs(&mut session, &other, 0)
                .unwrap()
        );
        for interrupted in [false, true] {
            let request = session.operation_budget_scope().unwrap();
            if interrupted {
                session.interrupt_handle().interrupt();
            } else {
                session.store.set_fuel(1).unwrap();
            }
            let error = records
                .matches_recorded_inputs(&mut session, &parent)
                .unwrap_err();
            if interrupted {
                assert!(error.is_interrupt(), "{error:?}");
            } else {
                assert!(
                    matches!(error, SessionError::Trap(ref e) if e.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)),
                    "{error:?}"
                );
            }
            drop(request);
            assert!(
                records
                    .matches_recorded_inputs(&mut session, &parent)
                    .unwrap()
            );
        }
        let mut foreign = Session::new().unwrap();
        let foreign_root = foreign
            .data_scalar(&crate::portable::hir::Literal::Nil)
            .unwrap();
        assert!(matches!(
            records.matches_recorded_inputs(&mut session, &foreign_root),
            Err(SessionError::ForeignValue)
        ));
        // A present child record is insufficient if its direct facts changed.
        // The low-level test below changes the UTF-16 storage directly; it does
        // not depend on source string indexing adapters or guest equality.
        let child_record = records.records.record(1, &mut session).unwrap();
        let child = match &child_record.fact {
            Fact::Scalar(_) => &child_record.value,
            _ => unreachable!(),
        };
        session
            .inspect(child, |mut store, value| {
                let array = value.unwrap_anyref().unwrap().as_array(&store)?.unwrap();
                array.set(&mut store, 0, wasmtime::Val::I32(99))?;
                Ok(())
            })
            .unwrap();
        assert!(
            records
                .matches_recorded_inputs(&mut session, &parent)
                .unwrap()
        );
        assert!(!records.matches_direct_facts(&mut session).unwrap());
    }
    #[test]
    fn construction_records_false_seed_does_not_hide_later_fuel_error() {
        let mut session = Session::new().unwrap();
        let (value, fact) = session
            .data_scalar_with_inputs(&crate::portable::hir::Literal::Nil)
            .unwrap();
        let mut records = ConstructionRecords::default();
        records
            .push(
                &mut session,
                value.clone(),
                Fact::ExternalSeed("unverified"),
            )
            .unwrap();
        records
            .push(&mut session, value, Fact::Scalar(fact))
            .unwrap();
        let request = session.operation_budget_scope().unwrap();
        session.store.set_fuel(1).unwrap();
        let error = records.matches_direct_facts(&mut session).unwrap_err();
        assert!(
            matches!(error,SessionError::Trap(ref error) if error.downcast_ref::<wasmtime::Trap>()==Some(&wasmtime::Trap::OutOfFuel)),
            "{error:?}"
        );
        drop(request);
        assert!(!records.matches_direct_facts(&mut session).unwrap());
    }
}

impl Default for ConstructionRecords {
 fn default()->Self {Self {domain:super::write_domain::WriteDomain::new(),children:Vec::new(),records:PagedRecords::default(),bridge_classes:Vec::new(),class_prechecks_valid:false}}
}
