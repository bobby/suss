from pathlib import Path
import json,re,hashlib,collections,shutil,datetime
r=Path('/home/bobby/.cache/suss-m4-work');v=r/'pr271-fresh-seed-validation';out=Path(__file__).parent;receipt=json.loads((v/'receipt.json').read_text());assert receipt['terminal'] and not receipt['unexecuted'];assert set(receipt['planned'])=={x['name'] for x in receipt['stages']}
rows=[];occ=collections.defaultdict(list);failures=[];tot=collections.Counter();snapshot=out/'staging'/'validation-v1';snapshot.mkdir(parents=True,exist_ok=True)
for s in receipt['stages']:
 f=v/(s['name']+'.log');t=f.read_text();summary=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)];counts=[sum(x[i] for x in summary) for i in range(3)]
 parsed=[];pending=None
 for line in t.splitlines():
  m=re.match(r'^test (\S+) \.\.\. (.*)$',line)
  if m:
   assert pending is None,(s['name'],pending);name,tail=m.groups();pending=name
   m2=re.match(r'^(ok|FAILED|ignored)(?:$|,)',tail)
   if m2:parsed.append((name,m2[1]));pending=None
  elif pending and line in ['ok','FAILED','ignored']:parsed.append((pending,line));pending=None
 assert pending is None
 assert [sum(z==k for n,z in parsed) for k in ['ok','FAILED','ignored']]==counts,(s['name'],counts,parsed)
 assert not s['changed']
 if s['name']!='identity':
  argv=s['argv'];exact='--exact' in argv
  sep=argv.index('--')
  if '--lib' in argv:
   filt=argv[argv.index('--lib')+1:sep]+[x for x in argv[sep+1:] if not x.startswith('--')]
  else:
   end=argv.index('--test')+2;filt=argv[end:sep]+[x for x in argv[sep+1:] if not x.startswith('--')]
  for n,z in parsed:
   assert not filt or any(n==a if exact else a in n for a in filt),(n,filt)
   occ[n].append({'stage':s['name'],'status':z});tot[z]+=1
 for i,n in enumerate(re.findall(r'^---- (.*?) stdout ----\s*$',t,re.M)):
  body=re.split(r'^---- '+re.escape(n)+r' stdout ----\s*$',t,flags=re.M)[1].split('\n---- ',1)[0]
  assert 'all fuel consumed' in body,n
  failures.append({'name':n,'stage':s['name'],'class':'fuel','panic':next((l for l in body.splitlines() if 'panicked at' in l),None),'raw_log':str(f)})
 rows.append({'stage':s['name'],'exit':s['exit'],'counts':counts,'tests':[{'name':n,'status':z} for n,z in parsed],'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'frozen_changed':s['changed']})
 shutil.copyfile(f,snapshot/f.name)
assert dict(tot)=={'ok':64,'FAILED':8}
unique=collections.Counter()
for n,vs in occ.items():
 assert len({x['status'] for x in vs})==1,n
 unique[vs[0]['status']]+=1
assert dict(unique)=={'ok':63,'FAILED':8}
dup={n:vs for n,vs in occ.items() if len(vs)>1};assert len(dup)==1
for name in ['receipt.json','run.py','initial-manifest.json','run-manifest.json','initial.patch','validated-source.patch','terminal-counts.json','bootstrap.log','namespace.json']:
 shutil.copyfile(v/name,snapshot/name)
shutil.copytree(v/'map-capture',snapshot/'map-capture',dirs_exist_ok=True)
manifest={str(f.relative_to(snapshot)):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in snapshot.rglob('*') if f.is_file()};(out/'staging-validation-v1-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
freeze=json.loads((snapshot/'run-manifest.json').read_text());initial=json.loads((snapshot/'initial-manifest.json').read_text());assert len(freeze)==3687
review={'verdict':'V1_terminal_counts_verified_archive_held','reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':receipt['base'],'executions':{'passed':64,'failed':8,'ignored':0,'total':72},'unique_tests':{'passed':63,'failed':8,'ignored':0,'total':71},'duplicate':dup,'all_planned_stages_executed':True,'all_recorded_after_stage_changes_empty':True,'run_freeze_paths':len(freeze),'initial_to_run_bootstrap_changes':[n for n in initial if initial[n]!=freeze.get(n)],'failures':failures,'stages':rows,'staging':str(snapshot),'staging_manifest':str(out/'staging-validation-v1-manifest.json'),'extra_followup':{'status':'SEPARATE_PENDING_TUPLE','root_handle':54656,'scope':'New negative test applied afterV1 terminal; normalBOOT+focusedtest pending; not included inV1 counts/sourcefreeze. No extra live logs or current source/BOOT captured.'},'limits':['3687run hashes and empty per-stage change lists preserved; live worktree has since changed and is deliberately not compared toV1.','Exact V1tested4BOOT bytes/source snapshot resolution must matchrunfreeze beforefinalarchive; no current extraBOOT substitution.','MapwrapperRust1pass verified; raw observations retained, no independent69IDhost comparison asserted by this audit.','Publicidentity0/2fuel: actualrows unexecuted; coherent12/6fuel, no identityacceptance/readiness claim.','No archivecreated, source/BOOTwrites orCargo; finalarchive requires explicitrootrelease.']}
(out/'terminal-v1-independent-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({'executions':review['executions'],'unique':review['unique_tests'],'duplicate':dup,'failures':failures,'staging_payloads':len(manifest)},indent=2))
