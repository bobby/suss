from pathlib import Path
import subprocess as s,json,os,time,hashlib
root=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');p=Path(__file__).parent
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
files=s.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
def hashes():return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if (root/f).is_file()}
freeze=hashes();p.joinpath('extra-manifest.json').write_text(json.dumps(freeze,indent=2)+'\n');p.joinpath('extra-source.patch').write_bytes(s.check_output(['git','diff','--binary'],cwd=root))
r={'terminal':False,'stages':[]};p.joinpath('extra-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
stages=[('extra-identity',['python3','scripts/verify_bootstrap_identity.py']),('extra-seed-and-method',['cargo','test','--locked','-p','suss-compile','--lib','--','canonical_seeds::tests::','fresh_seed_slot_','--test-threads=1','--nocapture'])]
for name,argv in stages:
 start=time.monotonic()
 with p.joinpath(name+'.log').open('w') as log: code=s.call(argv,cwd=root,env=env,stdout=log,stderr=s.STDOUT)
 changed=[f for f,h in freeze.items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h]
 r['stages'].append({'name':name,'argv':argv,'exit':code,'seconds':time.monotonic()-start,'changed':changed});print(r['stages'][-1],flush=True)
 assert not changed
 if code: break
r['terminal']=True;p.joinpath('extra-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
