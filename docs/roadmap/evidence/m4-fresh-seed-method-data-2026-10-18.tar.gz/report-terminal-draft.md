# Fresh seed validation — terminal, archive held

V1: **64 pass / 8 fuel failures / 0 ignored**,72executions; one repeated passing callback-poison test gives **63 unique pass /8fail /71unique**. All planned stages executed,3687 frozen paths and every stage changed[]. Public identity2 and coherent6 remain fuel failures before required observations.

Both original replaced-hash tests and all five original library certification regressions pass. Independent checks confirm220source-child events (110perphase), both finalvalidation successful with980173remaining;48memo rows ×13fields actual==expected; four12row summaries differences empty. Pinned map exactly69ordered IDs:62hostpass/7guestjudged,0fail/unexecuted/skip/namespace/testfailure. Guestjudgments remain qualified.

Separate post-V1 follow-up: identityPASS and11seed/helper testsPASS with changed[]. Recorded delta is canonical_seeds.rs plus four normalBOOT outputs. Both extra-bootstrap regenerations succeeded: the first before the test ref_eq assertion correction, the second afterward; no bootstrap compile failure was observed. Later11executions do not retroactively cover V1's original tuple.

Raw V1 and follow-up are staged separately. Archive is held pending explicit rootrelease and sourcecommitSHA. TestedBOOT exactbytes/source closure still require matching manifests; no live source/BOOT captured here. Old239CI remains failed, no fullbaseline/readiness/identityacceptance claim.
