# Fresh canonical seed method data — bounded execution evidence

Final source commit `9d2f19476959bc573c336871c746cbf9754adb19`, based on `239a4aa00be60916c61660167b4d7e8f6c13c339`. This packet preserves two tested tuples, the preceding diagnostic denial/failure, conditional design review, and failed239a4aaCI. No full baseline, final-headCIpass, identityacceptance, readiness or issuecompletion claimed.

V1: allstages executed;64PASS8fuelFAIL0ignored executions, with one passing callback-poison test repeated. Thus63uniquePASS8FAIL71unique. Publicidentity2 and coherentguards6 remainfuel failures before requiredidentityobservations.

AfterV1terminal, onecfgtestnegative wasadded with normalBOOTregeneration. FollowupidentityPASS and11testsPASS, changed[]. Across bothtuples the exactnameunion is72unique:64PASS8fuelFAIL0ignored. This is NOT72tests executed on oneidenticalcompiledtuple. Total83executions=75PASS8FAIL, with repetitions preserved. Newfollowuptest: `portable_session::canonical_seeds::tests::fresh_seed_hash_exception_does_not_excuse_prototype_or_other_protocol_poison`.

Allfive original librarycertification regressions and both originalreplaced-hash integration witnesses PASS inV1. No argument is inferred from diagnostic1PASS: that earlierdiagnostic observesdenial whileoriginalintegration0PASS1FAIL. Its twofalseCanonicalSeedfactids20/51 and limitedseed-onlyprototypeprobe remainraw.

Independent observationchecks:48memo rows,13fields each, actual==expected; four12row summaries emptydifferences. Sourcechild220events,110perphase, both finalvalidation successful with980173remaining. Pinnedmap69exactorderedIDs:62hostPASS7guestjudged,0fail/unexecuted/skips/namespacetestfailure. Sevenopaque outcomes remain guestqualified.

All3687finalfreeze paths independentlySHA256-match committedGitblobs. V1differs onlycanonical_seeds.rs cfgtest andfourBOOToutputs; allsevenchangedimplementation/sourceBOOTfiles areincluded foreachtuple. V1BOOTbytes recoveredfromsavedfull-indexbinarypatch and independentlyhash-matched theoriginalrunfreeze, neverregenerated. Common frozeninputs resolve exactGitcommit:blob in source-resolution.json; this is not a selfcontainedcopyofeveryvendorfile. InitialpreBOOTfreeze is separate fromrunfreeze.

ControlCI run39125469326 on239a4aa FAILED: foundation541PASS6fuelFAIL,353PythonPASS; integration71PASS20FAIL,22/259targetscompleted237unexecuted. Nine syntheticcheckouttrees equal239a4aa; checkoutSHA itselfisnotheadSHA. All10terminaljoblogs and rawproofs preserved. CurrentcandidatehasnoCIpassclaim.

Designreviewisconditional; reviewedseedsourcehash matches thetemporarydiagnostic, notclean239a4aa. Freshseedmethoddata is notstrictreuseauthority orcompletephysicalvalidationofreplacementclosureenvironment. Oldstrictsource/storage/domain/provenanceguards remain required. Both extra-bootstrap regenerations exited0: the first preceded the test ref_eq assertion review correction; the second followed it. No bootstrap compile failure was observed. Both raw logs are retained without inventing test execution credit. Exactcommands/rawoutputs are inthetworeceipts/runners.
