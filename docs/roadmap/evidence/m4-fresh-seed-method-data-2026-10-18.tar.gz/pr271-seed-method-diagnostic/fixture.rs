// Temporary diagnostic, append inside canonical_seeds.rs existing cfg(test)
// module. Not executed. A PASS establishes current conservative seed denial,
// not acceptance of ordinary transport or any future allowance implementation.
#[test]
fn diagnostic_empty_map_seed_method_replacement_is_strict_not_data_change() {
    use crate::portable_macro_data::FormBridge;
    use crate::portable_session::memo_leaf_test_support::Method;
    use suss_reader::forms::Kind;
    let mut session = Session::new_macro().unwrap();
    session.eval("(def leaf-original-method nil)").unwrap();
    let original = Method::capture(&mut session, "PersistentArrayMap").unwrap();
    original.bind_delegate(&mut session).unwrap();
    let bridge = FormBridge::new(&mut session).unwrap();
    let seed = session.canonical_seed("empty-map").unwrap().unwrap();
    let before_bridge = bridge.recording(&mut session).unwrap();
    let before = before_bridge.map_values(&mut session, &[]).unwrap();
    let before_records = before_bridge.into_records().unwrap();
    assert!(seed.matches(&mut session, &before).unwrap());
    assert_eq!(before_records.fresh_direct_status(&mut session).unwrap(), (true, true));
    let (before_form, before_valid) = bridge.read_finite(&mut session, &before).unwrap();
    assert!(before_valid && matches!(&before_form.kind, Kind::Map(v) if v.is_empty()));
    session.eval("(extend-type PersistentArrayMap IHash (-hash [self] (leaf-original-method self)))").unwrap();
    session.collect().unwrap();
    let after_bridge = bridge.recording(&mut session).unwrap();
    let after = after_bridge.map_values(&mut session, &[]).unwrap();
    let after_records = after_bridge.into_records().unwrap();
    assert!(session.values_identical(&before, &after).unwrap(), "same captured EMPTY root");
    let strict = seed.matches(&mut session, &after).unwrap();
    let direct = after_records.matches_direct_facts(&mut session).unwrap();
    let fresh = after_records.fresh_direct_status(&mut session).unwrap();
    let (form, source_valid) = bridge.read_finite(&mut session, &after).unwrap();
    let classes = after_records.matches_class_schemas(&mut session).unwrap();
    let prototypes = after_records.matches_prototype_origins(&mut session).unwrap();
    eprintln!("SEED_METHOD_DIAGNOSTIC strict={strict} direct={direct} fresh={fresh:?} source_valid={source_valid} classes={classes} prototypes={prototypes} empty={}",
        matches!(&form.kind, Kind::Map(v) if v.is_empty()));
    assert!(source_valid && matches!(&form.kind, Kind::Map(v) if v.is_empty()));
    assert!(classes && prototypes);
    assert!(!strict && !direct);
    assert_eq!(fresh, (false, false), "current policy: no soft seed classification yet");
    original.restore(&mut session).unwrap();
    assert!(seed.matches(&mut session, &after).unwrap(),
        "restoring ONLY the actual original method restores the strict witness");
}
