from pathlib import Path
import json,re,hashlib,types,collections,sys
sys.dont_write_bytecode=True
r=Path('/home/bobby/.cache/suss-m4-work');v=r/'pr271-fresh-seed-validation';out=Path(__file__).parent;review=json.loads((out/'terminal-v1-independent-review.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
# --nocapture panic output appears inline, without stdout section headers.
fail=[]
for row in review['stages']:
 t=(v/(row['stage']+'.log')).read_text();parts=re.split(r"^thread '([^']+)' .*?panicked at ([^\n]+):\s*$",t,flags=re.M)
 for i in range(1,len(parts),3):
  name,location,body=parts[i:i+3];body=body.split('\ntest ',1)[0]
  assert 'all fuel consumed' in body,(name,body[:300]);fail.append({'name':name,'stage':row['stage'],'class':'fuel','panic_location':location,'raw_error_excerpt':body.strip(),'log_sha256':row['sha256']})
assert len(fail)==8;review['failures']=fail
logs=[v/'symbol-originals.log',v/'keyword-and-effects.log'];memo=[];summaries=[]
for f in logs:
 for line in f.read_text().splitlines():
  for marker,target in [('NATIVE_MEMO_LEAF ',memo),('NATIVE_MEMO_LEAF_SUMMARY ',summaries)]:
   if marker in line:target.append(json.loads(line.split(marker,1)[1]))
assert len(memo)==48 and len(summaries)==4
keys=[]
for x in memo:
 assert len(x['fields'])==len(x['actual'])==len(x['expected'])==13
 assert x['actual']==x['expected'];keys.append((x['case'],x['stage']))
assert len(set(keys))==48 and all(s['differences']==[] and s['rows']==12 for s in summaries)
sclog=v/'source-child.log';events=[]
for l in sclog.read_text().splitlines():
 if 'source-child-fuel ' in l:events.append(l.split('source-child-fuel ',1)[1])
assert len(events)==220
source_summary={'events':220,'by_phase':dict(collections.Counter(re.search(r'source=(\S+)',e)[1] for e in events)),'final_validation_rows':[e for e in events if 'stage=final-validation result=' in e],'log_sha256':sha(sclog),'limits':'Actual current220events parsed; no priorcontrol sequence/cost equality asserted here.'}
repo=Path('/home/bobby/Work/code/bobby/suss');comp=repo/'scripts/clojure_test_suite.py';refpath=repo/'tests/oracle/clojure-test-suite-observations.json';actualpath=v/'map-capture/map-transport-observations.json';ref=json.loads(refpath.read_text());act=json.loads(actualpath.read_text());test='clojure.core-test.map/test-map';ns='clojure.core-test.map'
ref.update(namespaces=[ns],tests=[test],assertions=[x for x in ref['assertions'] if x['test']==test],skips=[x for x in ref['skips'] if x['namespace']==ns])
expected_ids=[(x['test'],x['ordinal']) for x in ref['assertions']];actual_ids=[(x['test'],x['ordinal']) for x in act['assertions']];assert expected_ids==actual_ids and len(expected_ids)==69
sys.path.insert(0,str(repo/'scripts'));mod=types.ModuleType('independent_suite_comparator');mod.__file__=str(comp);exec(compile(comp.read_text(),str(comp),'exec'),mod.__dict__);counts,failures=mod.compare(ref,act)
assert counts['pass']==62 and counts['guest-judged']==7 and counts['fail']==counts['not-executed']==counts['skipped']==counts['namespaces-failed']==0
assert all(not failures[k] for k in ['namespaces','tests','assertions','skip-mismatches']) and not act['test-failures'] and not act['skips'] and act['namespaces']==[{'namespace':ns,'status':'loaded'}] and act['suite']==ref['suite']
mapproof={'counts':counts,'expected_ordered_ids':expected_ids,'actual_ordered_ids':actual_ids,'ordered_equal':True,'actual_sha256':sha(actualpath),'reference_sha256':sha(refpath),'comparator_sha256':sha(comp),'reference_path':str(refpath),'comparator_path':str(comp),'namespace_and_test_failures_empty':True,'suite_pin':act['suite']}
(out/'map-independent-comparison-v1.json').write_text(json.dumps(mapproof,indent=2)+'\n')
review['memo_observations']={'rows':48,'fields_per_row':13,'all_actual_equal_expected':True,'unique_case_stage_pairs':48,'summary_rows':summaries,'log_hashes':{f.name:sha(f) for f in logs}}
review['source_child_observations']=source_summary;review['map_observations']=mapproof
review['limits']=[x for x in review['limits'] if not x.startswith('MapwrapperRust')]
(out/'terminal-v1-independent-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'counts':review['unique_tests'],'failures':len(fail),'memo':review['memo_observations']['rows'],'sourcechild':source_summary,'map':counts},indent=2))
