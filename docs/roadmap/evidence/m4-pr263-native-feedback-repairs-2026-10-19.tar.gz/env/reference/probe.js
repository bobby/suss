'use strict';
const path=require('path');
const base='/home/bobby/.cache/suss-m4-work/memo-call-boundary-draft/out';
require(path.join(base,'goog/bootstrap/nodejs.js'));
require(path.join(base,'cljs_deps.js'));
goog.global.CLOSURE_UNCOMPILED_DEFINES={'cljs.core._STAR_target_STAR_':'nodejs'};
for(const ns of ['cljs.core','cljs.analyzer','cljs.env','cljs.js','cljs.tools.reader','cljs.nodejs'])goog.require(ns);
cljs.nodejs.enable_util_print_BANG_();
const c=cljs.core,a=cljs.analyzer,kw=s=>c.keyword(s),vec=xs=>c.vec(xs),rows=[];
for(const [label,sources,expectedOp] of [
 ['function',['(fn* [] 17)'],'fn'],
 ['local',['(let* [watched 17] watched)'],'local'],
 ['global',['(def watched 17)','watched'],'var']
]){
 const state=cljs.js.empty_state(),target=c.symbol('suss-oracle.ast-env-origin');
 c.swap_BANG_(state,c.assoc_in,vec([kw('cljs.analyzer/namespaces'),target]),c.hash_map(kw('name'),target,kw('defs'),c.PersistentArrayMap.EMPTY));
 const saved=[cljs.env._STAR_compiler_STAR_,a._STAR_cljs_ns_STAR_,a._STAR_analyze_deps_STAR_,a._STAR_load_macros_STAR_];
 const proto=c.Keyword.prototype,slot='cljs$core$IHash$_hash$arity$1',original=proto[slot],events=[];
 try{
  cljs.env._STAR_compiler_STAR_=state;a._STAR_cljs_ns_STAR_=target;a._STAR_analyze_deps_STAR_=false;a._STAR_load_macros_STAR_=false;
  const forms=sources.map(s=>cljs.tools.reader.read_string(s));
  const reader=cljs.tools.reader.read_string(':env'),readerInitial=reader._hash;
  proto[slot]=function(coll){events.push({ref:this,memo:this._hash});return this._hash==null?original.call(this,coll):this._hash;};
  let ast=null;
  for(const form of forms)ast=a.analyze(c.assoc(a.empty_env(),kw('ns'),a.get_namespace(target)),form);
  if(label==='local'){
   ast=c.get(ast,kw('body'));
   while(c.get(ast,kw('op')).fqn==='do')ast=c.get(ast,kw('ret'));
  }
  const op=c.get(ast,kw('op')).fqn;
  if(op!==expectedOp)throw Error('wrong actual AST '+label+':'+op);
  const envKey=c.into_array(c.keys(ast)).find(k=>k.fqn==='env');
  if(!envKey)throw Error('missing actual env key');
  const hits=events.filter(e=>e.ref===envKey);
  const memoBeforeExplicit=envKey._hash,start=events.length,hash=c.hash(envKey);
  const explicit=events.slice(start).filter(e=>e.ref===envKey);
  if(explicit.length!==1)throw Error('explicit actual receiver dispatch missing');
  rows.push({label,sources,actualOp:op,memoBeforeExplicit,analysisReceiverCalls:hits.length,analysisFirstEntryMemo:hits.length?hits[0].memo:null,explicitEntryMemo:explicit[0].memo,hash,readerInitial,readerAfter:reader._hash,sameReaderObject:reader===envKey});
 }finally{
  proto[slot]=original;
  [cljs.env._STAR_compiler_STAR_,a._STAR_cljs_ns_STAR_,a._STAR_analyze_deps_STAR_,a._STAR_load_macros_STAR_]=saved;
  if(proto[slot]!==original)throw Error('method restoration failed');
 }
}
console.log(JSON.stringify({scope:'Retained pinned actual analyzer AST env-key receiver observations; not fresh build, macro transport or native Suss execution',cases:rows},null,2));
