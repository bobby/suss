# Function and resolved-reference AST :env key provenance

Base48de55e8536878d0c867e6b463f382a99a70a60d. Cache-only candidate; main working
source remains unchanged while CI39281973631 runs. Implements audit F1 from
pr261-constructor-audit-48de55e-v1. No Cargo/native Suss producer invoked.

Pinned analyzer.cljc2362-2368 explicitly creates the fn AST's literal :env;
analyze-symbol4108-4116 creates ret {:env env :form sym} before selecting a
resolved local/global/etc. Existing form-key guards already recognize those
native callable/resolved Symbol routes, but env_key falls through cold. The
candidate adds those same explicit native guards, paying8controls before the
checks. Unknown and SourceNode Future/Await routes retain the cold fallback.
No spelling-based selection, source/value suppression, guest constructor bypass,
authority receipt change, or compiled-constant change is introduced.

One new actual native analysis -> Graph AST -> materialize regression uses the
original function/local/global source programs plus Future and deliberately
unproved native source controls. It installs the live nil-aware Keyword IHash,
observes the actual root key's first receiver entry memo (including explicit
hashing), checks cold/distinct same-text reader key, GC, both Session phases and
restoration followed by a fresh canonical AST build. Typed fuel/IRQ negatives
and the rest of the source/literal authority suite remain existing required
coverage; this unexecuted regression does not claim to replace them.

The retained pinned reference in reference/ has two fresh measured Node exits0,
identical stdout d8bc9d56f8e31073af1a311ffa97214e59c24c3c563dd933c54a5afb08c97284,
and all115 retained generated inputs checked before/after. Actual fn/local
ASTs have env-key analysis entry memos -1815813235; actual global reference has
NO receiver analysis dispatch for that key, but its initial memo and explicit
hash entry are -1815813235. Same-text reader objects stay nil/distinct. These
are three actual observations, not a universal callback-count or order contract.
This reuses generated pinned JS, not a fresh reference build or native transport.

An initial authoring trial incorrectly required analysis-time hash dispatch for
every key and failed on the global case; its stderr and source-derived correction
are retained. Numeric process exits were not captured for authoring trials and
are not invented retrospectively. Only measured1/2 have explicit exit receipts.
The native regression was corrected before integration to explicitly hash the
actual root receiver, while retaining the first-entry observation. It does not
assert every map constructor hashes keys.

Rustfmt parsed both Rust postimages successfully. Source independent review,
actual native compilation and execution, normal regenerated source/BOOT tuple,
full acceptance/baseline and final-head CI remain required. No integration or
issue closure is claimed by this packet.
