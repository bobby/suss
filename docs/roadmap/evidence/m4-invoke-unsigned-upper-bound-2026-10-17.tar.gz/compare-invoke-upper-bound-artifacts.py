from pathlib import Path
import hashlib,json,subprocess,difflib
root=Path('/home/bobby/Work/code/bobby/suss-m4-unboxed-bitwise-ssa');run=Path(__file__).parent/'invoke-unsigned-upper-bound-focused';freeze=json.loads((run/'after-bootstrap-freeze.json').read_text())
class Reader:
 def __init__(self,b):self.b=b;self.p=0
 def byte(self):v=self.b[self.p];self.p+=1;return v
 def u(self):
  n=shift=0
  while True:
   v=self.byte();n|=(v&127)<<shift
   if v<128:return n
   shift+=7;assert shift<40
 def raw(self,n):v=self.b[self.p:self.p+n];assert len(v)==n;self.p+=n;return v
 def string(self):return self.raw(self.u()).decode()
def module(b):
 assert b[:8]==b'\x00asm\x01\0\0\0';r=Reader(b[8:]);sections={}
 while r.p<len(r.b):
  kind=r.byte();body=r.raw(r.u())
  if kind:assert kind not in sections;sections[kind]=body
 imports=0
 if 2 in sections:
  i=Reader(sections[2])
  for _ in range(i.u()):
   i.string();i.string();kind=i.byte()
   if kind==0:i.u();imports+=1
   elif kind==3:
    value_type=i.byte()
    if value_type in (0x63,0x64):i.u() # signed heaptype LEB: only consume bytes
    else:assert value_type in (0x7f,0x7e,0x7d,0x7c,0x7b,0x70,0x6f)
    assert i.byte() in (0,1)
   elif kind==4:assert i.byte()==0;i.u()
   else:raise AssertionError(('Unsupported import kind',kind))
 e=Reader(sections[7]);exports={}
 for _ in range(e.u()):
  name=e.string();kind=e.byte();idx=e.u()
  if kind==0:exports[name]=idx
 c=Reader(sections[10]);bodies=[c.raw(c.u())for _ in range(c.u())];assert c.p==len(c.b)
 return {'imports':imports,'invoke':exports['invoke']-imports,'bodies':bodies}
rows=[]
for phase in ['runtime','macro']:
 name=f'runtime/bootstrap/{phase}.wasm';old=subprocess.check_output(['git','show','71ded407be6ff27a7754cfc6ba7efc4347cf4e36:'+name],cwd=root);new=(root/name).read_bytes();assert hashlib.sha256(new).hexdigest()==freeze[name]
 a=module(old);b=module(new);assert a['imports']==b['imports'] and a['invoke']==b['invoke'] and len(a['bodies'])==len(b['bodies'])
 changed=[i for i,(x,y)in enumerate(zip(a['bodies'],b['bodies']))if x!=y];assert changed==[a['invoke']],changed
 before=a['bodies'][a['invoke']];after=b['bodies'][b['invoke']];deltas=[]
 for tag,i,j,k,l in difflib.SequenceMatcher(None,before,after,autojunk=False).get_opcodes():
  if tag!='equal':deltas.append({'tag':tag,'old_offset':i,'new_offset':k,'before_hex':before[i:j].hex(),'after_hex':after[k:l].hex()})
 # Exact encoding of local.get0/ref.cast_non_null4/struct.get4,3/i32.const-1/i32.ne,
 # followed later by i32.and. Require deletion only, never infer from byte count.
 assert [d['tag']for d in deltas]==['delete','delete'],deltas
 assert [d['before_hex']for d in deltas]==['2000fb1604fb020403417f47','71'],deltas
 rows.append({'phase':phase,'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest(),'defined_function_count':len(a['bodies']),'changed_defined_functions':changed,'invoke_body_before_bytes':len(before),'invoke_body_after_bytes':len(after),'deltas':deltas,'removed_instructions':6,'all_other_function_bodies_identical':True})
(run/'artifact-comparison.json').write_text(json.dumps({'phases':rows,'limits':'Independent structural code comparison. Runtime tests and actual source-child savings are separate; this is not a whole-request fuel inference.'},indent=2)+'\n');print(json.dumps(rows))
