from pathlib import Path
import os,json,hashlib,subprocess,time,fcntl,importlib.util,collections
c=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-unboxed-bitwise-ssa');run=c/'invoke-unsigned-upper-bound-followup';target=c/'memo-proof-cost-target';prior=c/'invoke-unsigned-upper-bound-focused'
spec=importlib.util.spec_from_file_location('helper',c/'run-boxed-integer-bits-focused.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((prior/'receipt.json').read_text());assert d['current']is None and d['final_changed']==[] and not d.get('stopped_anomaly')
patch=json.loads((c/'when-let-staged-diagnostic-full/manifest.json').read_text())
for n,v in patch['files'].items():assert sha(root/n)==v['after']
old=json.loads((prior/'terminal-freeze.json').read_text());paths=sorted(set(old)|set(patch['files']));expected={p:sha(root/p)for p in paths};changed=[p for p,h in old.items()if expected[p]!=h];assert set(changed)==set(patch['files'])-{'docs/compatibility/when-let/integration-provenance/compiled_when_let-before-stage-diagnostic.rs'}
leases=[]
for n in ['.invoke-upper-bound.lease','.full-workspace-baseline.lease']:
 f=open(target/n,'a+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit()or int(proc.name)==os.getpid():continue
 try:e=(proc/'environ').read_bytes();exe=str((proc/'exe').resolve())
 except OSError:continue
 assert b'CARGO_TARGET_DIR='+str(target).encode()+b'\0'not in e and not exe.startswith(str(target)+'/'),('Target live',proc.name)
run.mkdir(exist_ok=False);(run/'input-blobs').mkdir();(run/'before-freeze.json').write_text(json.dumps(expected,indent=2)+'\n');(run/'rebinding.json').write_text(json.dumps({'prior_run':str(prior),'changed_existing':changed,'new_files':sorted(set(expected)-set(old)),'unchanged_runtime_compiler_sources_and_bootstrap':True,'note':'Only reviewed diagnostic fixture/checker/provenance adaptation. Prior105execution source tuple retained separately.'},indent=2)+'\n')
for p,h in expected.items():
 dest=run/'input-blobs'/h
 if not dest.exists():dest.write_bytes((root/p).read_bytes())
(run/'driver.py').write_bytes(Path(__file__).read_bytes())
invalid='when_let_invalid_bindings_reject_in_compiled_expansion_and_allow_subsequent_work';bitwise='bitwise_hash_match_independently_decoded_primary_observations_after_gc'
tail=['--','--test-threads=1','--nocapture'];stages=[('provenance',['python3','scripts/check_when_let_provenance.py'],None),('corrected-diagnostic-and-pinned-bitwise',['cargo','test','-p','suss-cli','--locked','--no-fail-fast','--test','compiled_when_let','--test','portable_bitwise_hash','--','--exact','--test-threads=1','--nocapture',invalid,bitwise],[invalid,bitwise]),('core-import',['cargo','test','-p','suss-cli','--locked','--test','core_import']+tail,helper.tests(root/'crates/suss-cli/tests/core_import.rs')),('map',['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--exact','--test-threads=1','--nocapture'],['pinned_map_declaration_executes_without_transport_loss'])]
assert len(stages[2][2])==17
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target),PYTHONDONTWRITEBYTECODE='1')
for k in list(env):
 if k.startswith('SUSS_')and(k.endswith('TRACE')or'CAPTURE'in k):env.pop(k)
state={'driver_pid':os.getpid(),'base':'71ded407be6ff27a7754cfc6ba7efc4347cf4e36','root':str(root),'input_count':len(expected),'current':None,'stages':[],'limits':'Reviewed diagnostic expectation/provenance adaptation only after prior producer terminal. Runtime compiler and generated bootstrap unchanged. Original failure/raw oracle bytes retained. Pinned bitwise70/CORE17/map69 executed on new arity source; no new budgets. Semantic failures continue, anomalies stop. RUSTFLAGS inherited.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 for name,cmd,names in stages:
  assert all(sha(root/p)==h for p,h in expected.items());row={'name':name,'command':cmd};state['current']=name;state['stages'].append(row);save();started=time.monotonic();stage_env=env.copy()
  if name=='map':stage_env['SUSS_CLOJURE_TEST_SUITE_CAPTURE']=str(run/'map-capture')
  with(run/(name+'.log')).open('w')as out:
   proc=subprocess.Popen(cmd,cwd=root,env=stage_env,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
  row.update(exit=code,seconds=time.monotonic()-started);save();assert all(sha(root/p)==h for p,h in expected.items())
  if names is None:assert code==0;continue
  records,summaries=helper.parse_results((run/(name+'.log')).read_text(errors='replace'));row.update(records=records,summaries=summaries);save()
  assert collections.Counter(r['name'].split('::')[-1]for r in records)==collections.Counter(names),('Selection anomaly',name)
  total=collections.Counter()
  for s in summaries:total.update(s)
  assert total=={'pass':sum(r['status']=='ok'for r in records),'fail':sum(r['status']=='FAILED'for r in records),'ignore':0}
  assert code in(0,101)and(code==0)==(total['fail']==0)
except BaseException as e:state['stopped_anomaly']=repr(e);raise
finally:
 state['current']=None;state['final_changed']=[p for p,h in expected.items()if sha(root/p)!=h];save()
 if not state['final_changed']:(run/'terminal-freeze.json').write_text(json.dumps(expected,indent=2)+'\n')
