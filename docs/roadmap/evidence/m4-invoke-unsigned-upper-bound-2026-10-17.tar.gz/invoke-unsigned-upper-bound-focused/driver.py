from pathlib import Path
import os,json,hashlib,subprocess,time,fcntl,shutil,importlib.util,collections
c=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-unboxed-bitwise-ssa');run=c/'invoke-unsigned-upper-bound-focused';target=c/'memo-proof-cost-target';packet=c/'invoke-unsigned-upper-bound-source/manifest.json';review=json.loads(packet.read_text())
spec=importlib.util.spec_from_file_location('helper',c/'run-boxed-integer-bits-focused.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==review['base']
for p,h in review['files'].items():assert sha(root/p)==h
leases=[]
for name in ['.invoke-upper-bound.lease','.full-workspace-baseline.lease']:
 f=open(target/name,'a+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:e=(proc/'environ').read_bytes();exe=str((proc/'exe').resolve())
 except OSError:continue
 assert b'CARGO_TARGET_DIR='+str(target).encode()+b'\0'not in e and not exe.startswith(str(target)+'/'),('Target live',proc.name)
paths=sorted(json.loads((c/'boxed-integer-bits-focused-v3/terminal-freeze.json').read_text()));assert all((root/p).is_file()for p in paths)
freeze=lambda:{p:sha(root/p)for p in paths}
run.mkdir(exist_ok=False);(run/'input-blobs').mkdir();shutil.copyfile(__file__,run/'driver.py');shutil.copyfile(packet,run/'source-manifest.json')
def snapshot(label,data):
 (run/(label+'-freeze.json')).write_text(json.dumps(data,indent=2)+'\n')
 for n,h in data.items():
  dest=run/'input-blobs'/h
  if not dest.exists():shutil.copyfile(root/n,dest)
  assert sha(dest)==h
expected=freeze();snapshot('before',expected)
compiler=[]
for p in ['crates/suss-compile/tests/portable_closures.rs','crates/suss-compile/tests/runtime_abi.rs']:compiler+=helper.tests(root/p)
assert len(compiler)==101
witness=helper.WITNESSES
tail=['--','--test-threads=1','--nocapture']
stages=[('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap'],None),('closure-and-runtime-abi',['cargo','test','-p','suss-compile','--locked','--no-fail-fast','--test','portable_closures','--test','runtime_abi']+tail,compiler),('source-child',['cargo','test','-p','suss-compile','--locked','--lib','source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo']+tail,['source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo']),('regression-witnesses',['cargo','test','-p','suss-cli','--locked','--no-fail-fast','--test','compiled_public_records','--test','portable_reduction_dispatch','--','--exact','--test-threads=1','--nocapture']+witness,witness)]
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target),PYTHONDONTWRITEBYTECODE='1')
for k in list(env):
 if k.startswith('SUSS_')and(k.endswith('TRACE')or'CAPTURE'in k):env.pop(k)
state={'driver_pid':os.getpid(),'base':review['base'],'root':str(root),'target':str(target),'input_count':len(expected),'current':None,'stages':[],'limits':'Six redundant Wasm arity instructions removed; all guards, descriptors, ARGS allocations, call selection and allowances unchanged. Independent semantic gates continue; bootstrap/source/selection/process anomalies stop. Prototype ongoing preservation untouched. No RUSTFLAGS assignment.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 for name,cmd,names in stages:
  assert freeze()==expected;row={'name':name,'command':cmd};state['stages'].append(row);state['current']=name;save();started=time.monotonic();stage_env=env.copy()
  if name=='source-child':stage_env['SUSS_SOURCE_CHILD_FUEL_TRACE']='1'
  with (run/(name+'.log')).open('w')as out:
   proc=subprocess.Popen(cmd,cwd=root,env=stage_env,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
  after=freeze();changed=[p for p,h in expected.items()if after[p]!=h];row.update(exit=code,seconds=time.monotonic()-started,changed=changed);save()
  if name=='bootstrap':
   assert code==0 and set(changed)<=helper.BOOT;expected=after;snapshot('after-bootstrap',expected);continue
  assert not changed
  records,summaries=helper.parse_results((run/(name+'.log')).read_text(errors='replace'));row.update(records=records,summaries=summaries);save()
  assert collections.Counter(r['name'].split('::')[-1]for r in records)==collections.Counter(names),('Selection anomaly',name)
  total=collections.Counter()
  for s in summaries:total.update(s)
  assert total=={'pass':sum(r['status']=='ok'for r in records),'fail':sum(r['status']=='FAILED'for r in records),'ignore':0}
  assert code in (0,101)and(code==0)==(total['fail']==0)
except BaseException as e:state['stopped_anomaly']=repr(e);raise
finally:
 state['current']=None;state['final_changed']=[p for p,h in expected.items()if sha(root/p)!=h];save()
 if not state['final_changed']:snapshot('terminal',freeze())
