One-file production six-instruction removal plus one focused ABI regression.

For any i32 max and unsigned array length, (max != -1) AND (len >u max)
equals (len >u max): -1 is u32::MAX, above which no unsigned length exists.
Remove LocalGet closure / RefCast / StructGet maximum / I32Const -1 / I32Ne
and I32And only. Existing callable/ARGS guards, unsigned minimum/maximum tests,
error payload, environment validation and selected tail call remain unchanged.
Repeated maximum read is immutable and callback-free. No new local, metadata,
API, allocation, charge rate, public dispatch assumption or argument change.

Regression compiles actual (fn [] 17), retains its invoke funcref and extracts
its raw environment, then constructs raw closure-new arity metadata. Explicit
13 acceptance masks cover fixed/ranged/variadic and negative bit-pattern maxima,
invalid minima and min>max at argc0..3 (52 calls). Acceptances require actual
17; rejections require canonical descriptor1 Wrong arity and original nil fields.
GC before each invocation. Existing malformed callable/ARGS tests untouched.
Raw malformed metadata cases document inherited ABI behavior, not portable
source-language support. Actual test, validation and performance UNEXECUTED.

Source frozen on 71ded40 idle SSA leaf. Prototype preservation untouched.
git diff --check passed. Root owns review, lease, bootstrap and all execution.
