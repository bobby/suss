from pathlib import Path
import re,json,hashlib
cache=Path(__file__).parent
for p in sorted(cache.glob('pr263-ci-integration-[0-7].log')):
    shard=int(p.stem[-1]); raw=p.read_bytes(); log=raw.decode()
    plan=next(json.loads(line.split('Z ',1)[1]) for line in log.splitlines() if '"total_targets": 252' in line and '"targets"' in line)
    started=re.findall(r'Running.*? tests/([^ /]+)\.rs',log)
    summaries=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log)
    assert len(started)==len(summaries),(shard,started,summaries)
    assert started==[target[1] for target in plan['targets'][:len(started)]]
    out={'run':38959090355,'head':'7c08c91ce7da8376e4cd3037856d30a597e667af','shard':shard,'planned':plan['targets'],'completed':plan['targets'][:len(started)],'unexecuted':plan['targets'][len(started):],'counts':dict(zip(['passed','failed','ignored','measured','filtered'],map(sum,zip(*(map(int,row) for row in summaries))))),'failed_tests':re.findall(r'\btest (\S+) \.\.\. FAILED',log),'raw_log_sha256':hashlib.sha256(raw).hexdigest(),'scope':'Terminal shard only; no whole-run totals.'}
    (cache/f'pr263-ci-integration-{shard}-classification.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'shard':shard,'completed':len(started),'unexecuted':len(out['unexecuted']),'counts':out['counts'],'failed_tests':out['failed_tests']}))
