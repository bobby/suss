{
  "run": 38959090355,
  "head": "7c08c91ce7da8376e4cd3037856d30a597e667af",
  "conclusion": "failure",
  "planned_integration_targets": 252,
  "completed_integration_targets": 31,
  "unexecuted_integration_targets": 221,
  "integration_counts": {
    "passed": 122,
    "failed": 17,
    "ignored": 0,
    "measured": 0,
    "filtered": 0
  },
  "foundation_rust_execution_counts": {
    "passed": 400,
    "failed": 0,
    "ignored": 1,
    "measured": 0,
    "filtered": 0
  },
  "python_test_lines": [
    "Ran 348 tests in 26.964s"
  ],
  "failed_tests": [
    "control_source_nodes_match_genuine_primary_children_and_forms_after_gc",
    "compiled_macro_core_namespace_keeps_complete_declaration_records",
    "compiled_source_inference_matches_pinned_tags_without_changing_executed_storage_or_effects",
    "public_record_field_and_metadata_values_decode_independently_after_gc",
    "public_record_custom_protocols_and_record_input_factory_decode_after_gc",
    "public_record_nominal_equality_and_predicate_decode_after_gc_in_both_phases",
    "public_records_execute_jank_and_authored_contracts_with_two_nominal_classes",
    "collection_source_nodes_retain_original_children_before_factory_lowering",
    "unordered_literal_ast_edges_and_runtime_effects_preserve_textual_order",
    "compiled_wrapper_serializes_only_the_genuine_native_object_fact_in_both_phases",
    "compiler_catalog_policy_is_opt_in_and_invalid_metadata_keeps_old_macro",
    "failed_script_staging_restores_callable_and_catalog_policy_after_gc",
    "failed_macro_reload_keeps_published_policy_then_successful_reload_recovers",
    "source_macro_consumes_actual_other_namespace_and_protocol_revisions_after_gc",
    "declaration_metadata_merge_and_tag_precedence_match_pinned_analyzer",
    "compiled_declaration_records_match_actual_primary_snapshot_and_catalog_fields",
    "constructor_source_nodes_match_pinned_children_tags_and_class_facts_after_gc"
  ],
  "limits": "CI only for published7c08c91, not dirty slot-log source; repeated verifier executions counted as executions, not deduplicated tests. Full local baseline absent."
}