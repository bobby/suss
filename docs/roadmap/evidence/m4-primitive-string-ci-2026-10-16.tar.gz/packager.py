from pathlib import Path
import json,hashlib,tarfile,io,subprocess,re,collections
r=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access');c=Path('/home/bobby/.cache/suss-m4-work');e=r/'docs/roadmap/evidence';final=json.loads((c/'private-slot-log-final-focused-result.json').read_text());f=final['freeze'];assert final['current'] is None and final['source_unchanged']
for name in ['source-tags','inference-trace']:
 x=json.loads((c/f'private-slot-log-{name}-result.json').read_text());assert x['current'] is None and x['source_unchanged'] and x['freeze']==f
for p,h in f.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
extra=['Cargo.toml','Cargo.lock','crates/suss-core/Cargo.toml','crates/suss-reader/Cargo.toml','crates/suss-compile/Cargo.toml','crates/suss-cli/Cargo.toml','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','runtime/core-import/LICENSE','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json','vendor/wasi/wasi-wit-0.3.1/cli/cli.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit']
extra.extend(['crates/suss-compile/src/portable/stdlib/async.sus','crates/suss-compile/src/portable/stdlib/async-macros.sus'])
def fingerprints(d):
 paths=[p for p in d if p=='crates/suss-compile/build.rs' or any(p.startswith('crates/'+n+'/src/') and p.endswith(('.rs','.sus')) for n in ['suss-core','suss-reader','suss-compile'])]+extra[:5]+extra[9:];h=hashlib.sha256()
 for p in sorted(set(paths),key=lambda p:tuple(p.split('/'))):
  b=d[p];n=p.encode();h.update(len(n).to_bytes(8,'little')+n+len(b).to_bytes(8,'little')+b)
 out={}
 for phase in ['macro','runtime']:
  m=json.loads(d[f'runtime/bootstrap/{phase}.json']);out[phase]={'compiler':m['compiler_source_sha256']==h.hexdigest(),'core':m['source_sha256']==hashlib.sha256(d['runtime/core-import/suss/core.sus']).hexdigest(),'dependencies':m['dependency_graph_sha256']==hashlib.sha256(d['runtime/core-import/manifest.json']).hexdigest(),'wasm':m['wasm_sha256']==hashlib.sha256(d[f'runtime/bootstrap/{phase}.wasm']).hexdigest()}
 assert all(all(x.values()) for x in out.values()),out
 return out
def archive(name,payload):
 m={p:hashlib.sha256(b).hexdigest() for p,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(m,indent=2).encode();out=e/name
 with tarfile.open(out,'w:gz') as t:
  for p,b in sorted(payload.items()):
   info=tarfile.TarInfo(p);info.size=len(b);t.addfile(info,io.BytesIO(b))
 with tarfile.open(out) as t:
  for p,h in m.items():assert hashlib.sha256(t.extractfile(p).read()).hexdigest()==h
 return {'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(m)}
snap={p:(r/p).read_bytes() for p in f}
for p in extra:snap[p]=(r/p).read_bytes()
checks=fingerprints(snap);historical={}
for name in ['source','route','formatted']:
 old=json.loads((c/f'private-slot-log-{name}-freeze.json').read_text());missing={p:h for p,h in old.items() if p not in snap or hashlib.sha256(snap[p]).hexdigest()!=h};historical[name]={'count':len(old),'bytes_matching_final':len(old)-len(missing),'different_or_unavailable_historical_bytes':missing,'qualification':'Historical manifest preserved as recorded. Only final snapshots are complete. Overwritten preformat/source/bootstrap bytes are unavailable and were not reconstructed; do not claim those complete historical snapshots or final-source identity.'}
comparison=json.loads((c/'private-slot-log-trace-comparison.json').read_text());raw=(c/'private-slot-log-inference-trace.log').read_text();starts=list(map(int,re.findall(r'macro-fuel user/observe-tags start: (\d+)',raw)));decoded=list(map(int,re.findall(r'macro-fuel user/observe-tags decoded: (\d+)',raw)));assert decoded==comparison['after_decoded'] and len(starts)==4 and len(decoded)==3
pair=re.findall(r'metadata-graph pairs[^\n]*: (\d+)\nmetadata-graph fixed[^\n]*: (\d+)',raw)
# Independent stage extraction tolerates unrelated inclusive breadcrumbs between labels.
pairs=[];pending=None
for line in raw.splitlines():
 m=re.match(r'metadata-finish (pairs|fixed).*: (\d+)$',line)
 if m:
  if m[1]=='pairs':pending=int(m[2])
  elif pending is not None:pairs.append(pending-int(m[2]));pending=None
assert pairs==comparison['after_pairs_to_fixed_debits'],pairs
payload={'snapshot/final/'+p:b for p,b in snap.items()}
for p in c.glob('private-slot-log-*'):
 if p.is_file():payload['receipts/'+p.name]=p.read_bytes()
for p in c.glob('*private-slot-log*.py'):
 if p.is_file():payload['runners/'+p.name]=p.read_bytes()
for name in ['primitive-string-lookup-inference-trace.log','primitive-string-lookup-inference-trace-result.json']:payload['support/'+name]=(c/name).read_bytes()
payload['source-change.patch']=subprocess.check_output(['git','diff','7c08c91','--','crates'],cwd=r)
payload['audit.json']=json.dumps({'base':'7c08c91','freeze_count':len(f),'freeze_omission_limit':'Two tracked stdlib inputs async.sus/async-macros.sus absent from recorded freezes; captured post-execution, byte-equal7c08c91, included in fingerprint. No independent before/after freeze claim for these two.','cljs_frozen':{p:h for p,h in f.items() if p.endswith('.cljs')},'fingerprints':checks,'historical_freezes':historical,'final_results':'reuse5pass + private-fixups9pass (includes slot-log2), tags1pass1fuel-fail, trace0pass1fuel-fail. No deduplicated extra2 added to9.','trace':{'starts':starts,'decoded':decoded,'pairs_to_fixed':pairs,'comparison':comparison},'limits':'No extra completed inference observation; same fourth caller &env fuel failure span382..414. Intervals inclusive, not additive/exclusive total costs. No full baseline/CI on dirty slot-log source; critical supporting inputs captured after tests.'},indent=2).encode()
payload['README.txt']=b'Final formatted source snapshot complete; raw initial compile errors/bootstrap identity failure/reuse route failure and later passes retained. Commands and exact exits/durations live in runners/receipts. Historical preformat hash manifests are not complete historical byte snapshots; see audit.json unavailable-byte lists. Final formatted rerun executes reuse5 and private-fixups9 including slot-log2. Source-tags1pass1fuel-fail; traced inference still4starts3decodes and fails fourth env at382..414. No baseline/acceptance/dirty-source CI claim. Supporting fingerprint inputs captured after execution.\n'
a=archive('m4-private-slot-log-focused-2026-10-16.tar.gz',payload)
# CI is a distinct published source, never the dirty slot-log working tree.
head='7c08c91ce7da8376e4cd3037856d30a597e667af';run=json.loads((c/'pr263-ci-run.json').read_text());summary=json.loads((c/'pr263-ci-summary.json').read_text());synthetic=json.loads((c/'pr263-ci-synthetic-commit.json').read_text());tree=subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=r,text=True).strip();assert synthetic['tree']['sha']==tree=='979be870fa697c6d718c44d7038d2a98e153006b';assert run['headSha']==head and run['conclusion']=='failure'
counts=collections.Counter();planned=[];completed=[];unexec=[];failed=[]
for i in range(8):
 x=json.loads((c/f'pr263-ci-integration-{i}-classification.json').read_text());rawbytes=(c/f'pr263-ci-integration-{i}.log').read_bytes();assert hashlib.sha256(rawbytes).hexdigest()==x['raw_log_sha256'];text=rawbytes.decode();results=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text);computed=dict(zip(['passed','failed','ignored','measured','filtered'],map(sum,zip(*(map(int,z) for z in results)))));assert computed==x['counts'];assert len(results)==len(x['completed']);counts.update(computed);planned+=x['planned'];completed+=x['completed'];unexec+=x['unexecuted'];failed+=x['failed_tests']
assert len(planned)==252 and len(completed)==31 and len(unexec)==221;assert counts['passed']==122 and counts['failed']==17;assert len(failed)==17
foundation=(c/'pr263-ci-foundation.log').read_text();results=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',foundation);foundationcounts=tuple(map(sum,zip(*(map(int,z) for z in results))));assert foundationcounts==(400,0,1);assert 'Ran 348 tests in 26.964s' in foundation
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','crates','runtime/bootstrap'],cwd=r,text=True).splitlines();cisnap={p:subprocess.check_output(['git','show',head+':'+p],cwd=r) for p in paths if p.endswith(('.rs','.sus','.cljs')) or p.startswith('runtime/bootstrap/')}
for p in extra:cisnap[p]=subprocess.check_output(['git','show',head+':'+p],cwd=r)
cichecks=fingerprints(cisnap);ci={'snapshot/7c08c91/'+p:b for p,b in cisnap.items()}
for p in c.glob('pr263-ci-*'):
 if p.is_file():ci['receipts/'+p.name]=p.read_bytes()
ci['classifier.py']=(c/'classify-pr263-ci-shards.py').read_bytes();ci['packager.py']=Path(__file__).read_bytes()
ci['source/.github/workflows/ci.yml']=subprocess.check_output(['git','show',head+':.github/workflows/ci.yml'],cwd=r)
proof={'head':head,'checkout':synthetic['sha'],'tree':tree,'synthetic_tree_equals_head':True,'parents':[p['sha'] for p in synthetic['parents']],'head_is_runner_image_warning':'First job-image Commit line is not checked-out source; checkout log and cached GitHub synthetic commit record identify40f29f2.','counts':dict(counts),'targets':{'planned':len(planned),'completed':len(completed),'unexecuted':len(unexec)},'foundation_execution_counts':{'passed':400,'failed':0,'ignored':1},'foundation_count_limit':'Includes repeated bootstrap verifier executions; not distinct tests.','fingerprints':cichecks,'limits':'Published7c08c91 CI only, not dirty slot-log source. Eight shards terminate on failing targets;221 targets unexecuted. No full local baseline or exhaustive failure inventory; raw unknowns retained.'};ci['audit.json']=json.dumps(proof,indent=2).encode();ci['README.txt']=json.dumps(summary,indent=2).encode();b=archive('m4-primitive-string-ci-2026-10-16.tar.gz',ci)
result={'focused':a,'ci':b,'final_freeze_count':len(f),'fingerprints':checks,'historical_limits':historical};(c/'private-slot-log-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
