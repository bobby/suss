from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-invoke-checked-locals');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'invoke-checked-locals-target')
v={'base':'4ce5ddb421b820688ccf796e78a4d3f5c31fb64f','stages':[],'freeze':{},'source_unchanged':None,'current':None};out=c/'invoke-read-reuse-result.json'
def abi(filter):return ['cargo','test','-p','suss-compile','--locked','--test','runtime_abi',filter,'--','--test-threads=2']
stages=[('closures',abi('closure')),('arithmetic',abi('runtime_abi_arithmetic_function_values_check_arity_and_fold_in_order')),('nominal-errors',abi('runtime_abi_nominal_callables_reject_arity_missing_methods_and_non_objects')),('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('coercion-effects',['cargo','test','-p','suss-cli','--locked','--test','portable_object_coercion','--','--test-threads=2']),('source-tags',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_source_tags','--','--test-threads=2','--nocapture'])]
for name,cmd in stages:
 if name=='coercion-effects':
  paths=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.sus')]+list((r/'runtime/bootstrap').glob('*'));v['freeze']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 if name=='source-tags':env['SUSS_MACRO_FUEL_TRACE']='1'
 v['current']=name;out.write_text(json.dumps(v,indent=2));start=time.monotonic()
 with (c/f'invoke-read-reuse-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 v['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-start});v['current']=None
 if v['freeze']:v['source_unchanged']=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in v['freeze'].items())
 out.write_text(json.dumps(v,indent=2))
 if p.returncode and name not in ['source-tags']:break
(c/'invoke-read-reuse.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=r))
print(json.dumps({k:x for k,x in v.items() if k!='freeze'},indent=2));raise SystemExit(0 if all(s['exit']==0 for s in v['stages']) else 1)
