from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-memo-proof-cost');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'memo-proof-cost-target')
v={'stages':[],'freeze':{},'source_unchanged':None,'current':None};out=c/'memo-int32-repair-result.json'
stages=[('int32',['cargo','test','-p','suss-compile','--locked','--test','runtime_abi','runtime_abi_int32_coercion_wraps_finite_values_and_zeroes_nonfinite','--','--test-threads=2']),('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('source-tags',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_source_tags','--','--test-threads=2','--nocapture'])]
for name,cmd in stages:
 if name=='source-tags':
  env['SUSS_MACRO_FUEL_TRACE']='1'
  paths=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.sus')]+list((r/'runtime/bootstrap').glob('*'));v['freeze']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 v['current']=name;out.write_text(json.dumps(v,indent=2));start=time.monotonic()
 with (c/f'memo-int32-repair-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 v['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-start});v['current']=None
 if v['freeze']:v['source_unchanged']=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in v['freeze'].items())
 out.write_text(json.dumps(v,indent=2))
 if p.returncode and name!='source-tags':break
(c/'memo-int32-repair.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=r))
print(json.dumps({k:x for k,x in v.items() if k!='freeze'},indent=2))
raise SystemExit(0 if all(s['exit']==0 for s in v['stages']) else 1)
