//! Independent logical reader-data expectations, never a storage certificate.
//!
//! This layer deliberately does not authenticate memo/FQN/UID fields, set-map
//! values, representation or alias identity. Those need separate checked
//! storage/receipt validation before any retained candidate can be reused.
use super::{
    Result, preserve_source_error,
    raw_keys::{Interner, Plan},
    validate_form_data,
};
use crate::{
    portable_macro_data::FormBridge,
    portable_session::{Session, SessionValue},
};
use suss_reader::forms::{Form, Kind};

pub(crate) struct LogicalSourceWitness {
    // Built only from immutable native source; never refreshed from a guest read.
    expected: Form,
}

fn allocation<T>(session: &mut Session, count: usize) -> Result<()> {
    session.charge_host_work((count as u64).saturating_mul(std::mem::size_of::<T>() as u64))
}
fn normalize(session: &mut Session, mut form: Form) -> Result<Form> {
    stacker::maybe_grow(256 * 1024, 4 * 1024 * 1024, || {
        session.charge_host_work(1)?;
        let metadata = if form.metadata.is_empty() {
            None
        } else {
            Some(Form {
                span: form.span.clone(),
                metadata: vec![],
                kind: Kind::Map(preserve_source_error(
                    form.span.clone(),
                    &mut |work| session.charge_host_work(work),
                    |charge| {
                        crate::portable::hir::reader_metadata_pairs_metered(&form, &mut |work| {
                            charge(work)
                        })
                    },
                )?),
            })
        };
        form.metadata.clear();
        form.kind = match form.take_kind() {
            Kind::List(values) => Kind::List(normalize_children(session, values)?),
            Kind::Vector(values) => Kind::Vector(normalize_children(session, values)?),
            Kind::Map(values) => Kind::Map(normalize_children(session, values)?),
            Kind::Set(values) => Kind::Set(normalize_children(session, values)?),
            other => other,
        };
        if let Some(metadata) = metadata {
            allocation::<Form>(session, 1)?;
            form.metadata.push(normalize(session, metadata)?);
        }
        Ok(form)
    })
}
fn normalize_children(session: &mut Session, values: Vec<Form>) -> Result<Vec<Form>> {
    allocation::<Form>(session, values.len())?;
    values
        .into_iter()
        .map(|value| normalize(session, value))
        .collect()
}
fn text_equal<T: PartialEq>(session: &mut Session, left: &[T], right: &[T]) -> Result<bool> {
    session.charge_host_work(1)?;
    if left.len() != right.len() {
        return Ok(false);
    }
    for (left, right) in left.chunks(256).zip(right.chunks(256)) {
        session.charge_host_work((left.len() + right.len()) as u64)?;
        if left != right {
            return Ok(false);
        }
    }
    Ok(true)
}
fn keyword_equal(
    session: &mut Session,
    a: &suss_reader::Keyword,
    b: &suss_reader::Keyword,
) -> Result<bool> {
    session.charge_host_work(1)?;
    let namespace = match (&a.namespace, &b.namespace) {
        (None, None) => true,
        (Some(a), Some(b)) => text_equal(session, a.as_bytes(), b.as_bytes())?,
        _ => false,
    };
    Ok(namespace && text_equal(session, a.name.as_bytes(), b.name.as_bytes())?)
}
fn scalar_key(form: &Form, map: bool) -> bool {
    match form.kind {
        Kind::String(_) | Kind::Keyword(_) => true,
        Kind::Nil | Kind::Bool(_) => !map,
        Kind::Number(value) => !map && value.is_finite(),
        _ => false,
    }
}
fn key_equal(session: &mut Session, a: &Form, b: &Form) -> Result<bool> {
    session.charge_host_work(1)?;
    Ok(match (&a.kind, &b.kind) {
        (Kind::Nil, Kind::Nil) => true,
        (Kind::Bool(a), Kind::Bool(b)) => a == b,
        // Only finite set keys reach here. Signed zeros are duplicate keys,
        // although the logical source value check retains their exact bits.
        (Kind::Number(a), Kind::Number(b)) => a == b,
        (Kind::String(a), Kind::String(b)) => text_equal(session, a, b)?,
        (Kind::Keyword(a), Kind::Keyword(b)) => keyword_equal(session, a, b)?,
        _ => false,
    })
}
fn unambiguous(session: &mut Session, form: &Form) -> Result<bool> {
    allocation::<&Form>(session, 1)?;
    let mut pending = vec![form];
    while let Some(form) = pending.pop() {
        session.charge_host_work(1)?;
        if let Kind::Map(values) | Kind::Set(values) = &form.kind {
            let map = matches!(form.kind, Kind::Map(_));
            let stride = if map { 2 } else { 1 };
            for index in (0..values.len()).step_by(stride) {
                session.charge_host_work(1)?;
                if !scalar_key(&values[index], map) {
                    return Ok(false);
                }
                for previous in (0..index).step_by(stride) {
                    if key_equal(session, &values[previous], &values[index])? {
                        return Ok(false);
                    }
                }
            }
        }
        let children: &[Form] = match &form.kind {
            Kind::List(v) | Kind::Vector(v) | Kind::Map(v) | Kind::Set(v) => v,
            _ => &[],
        };
        // Reserve and charge before publishing pending traversal entries.
        let extra = children.len().saturating_add(form.metadata.len());
        session.charge_host_work(extra as u64)?;
        if extra > pending.capacity() - pending.len() {
            allocation::<&Form>(session, pending.len().saturating_add(extra))?;
            allocation::<&Form>(session, pending.len())?;
            pending.reserve_exact(extra);
        }
        pending.extend(children);
        pending.extend(&form.metadata);
    }
    Ok(true)
}
impl LogicalSourceWitness {
    /// None is conservative admission decline, never a successful certificate.
    /// Compound/ambiguous keys still need native portable key normalization.
    pub(crate) fn from_source(session: &mut Session, source: &Form) -> Result<Option<Self>> {
        let _request = session.operation_budget_scope()?;
        validate_form_data(source, &mut |units| session.charge_host_work(units))?;
        let copy = preserve_source_error(
            source.span.clone(),
            &mut |work| session.charge_host_work(work),
            |charge| crate::portable::clone_form_metered(source, &mut |work| charge(work)),
        )?;
        let expected = normalize(session, copy)?;
        if !unambiguous(session, &expected)? {
            return Ok(None);
        }
        Ok(Some(Self { expected }))
    }
    pub(crate) fn matches_logical_source(
        &self,
        session: &mut Session,
        bridge: &FormBridge,
        value: &SessionValue,
    ) -> Result<bool> {
        let _request = session.operation_budget_scope()?;
        let actual = bridge.read_finite(session, value)?;
        let mut keys = Interner::default();
        let mut plan = Plan::default();
        let expected = keys.unordered_plan(&self.expected, &mut plan, &mut |work| {
            session.charge_host_work(work)
        })?;
        let expected = plan.nodes[expected].key;
        let actual = keys.unordered_plan(&actual, &mut plan, &mut |work| {
            session.charge_host_work(work)
        })?;
        session.charge_host_work(1)?;
        Ok(expected == plan.nodes[actual].key)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        portable::{hir::Literal, resolve::Phase},
        portable_session::SessionError,
    };
    fn source(text: &str) -> Form {
        let mut forms =
            suss_reader::forms::resolve_conditionals(suss_reader::forms::read_forms(text).unwrap())
                .unwrap();
        assert_eq!(forms.len(), 1);
        forms.pop().unwrap()
    }
    fn session(phase: Phase) -> Session {
        match phase {
            Phase::Runtime => Session::new_repl().unwrap(),
            Phase::Macro => Session::new_macro().unwrap(),
        }
    }
    #[test]
    fn source_facts_compare_unordered_pairs_metadata_and_exact_numeric_bits() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = session(phase);
            let bridge = FormBridge::new(&mut session).unwrap();
            let witness = LogicalSourceWitness::from_source(
                &mut session,
                &source("^{:m 17} {:a [1 2] :b #{101 102 103}}"),
            )
            .unwrap()
            .unwrap();
            for (text, expected) in [
                ("(with-meta {:b #{103 101 102} :a [1 2]} {:m 17})", true),
                ("(with-meta {:a [1 3] :b #{101 102 103}} {:m 17})", false),
                ("(with-meta {:b [1 2] :a #{101 102 103}} {:m 17})", false),
                ("(with-meta {:a [1 2] :b #{101 102 103}} {:m 18})", false),
            ] {
                let value = session.eval(text).unwrap();
                session.collect().unwrap();
                assert_eq!(
                    witness
                        .matches_logical_source(&mut session, &bridge, &value)
                        .unwrap(),
                    expected,
                    "{phase:?}: {text}"
                );
            }
            for (text, value) in [
                ("[^:flag x]", "[(with-meta 'x {:flag true})]"),
                (
                    "^{:m 17} [^:flag x]",
                    "(with-meta [(with-meta 'x {:flag true})] {:m 17})",
                ),
                ("^{} []", "(with-meta [] {})"),
                ("^{:m 17} ^{:m 18} []", "(with-meta [] {:m 17})"),
            ] {
                let witness = LogicalSourceWitness::from_source(&mut session, &source(text))
                    .unwrap()
                    .unwrap();
                let value = session.eval(value).unwrap();
                assert!(
                    witness
                        .matches_logical_source(&mut session, &bridge, &value)
                        .unwrap(),
                    "{text}"
                );
            }
            let duplicate_witness =
                LogicalSourceWitness::from_source(&mut session, &source("{:a 1 :b 1}"))
                    .unwrap()
                    .unwrap();
            let duplicate = session
                .eval("(def source-dupe {:a 1 :b 1}) (aset (.-arr source-dupe) 2 :a) source-dupe")
                .unwrap();
            assert!(
                !duplicate_witness
                    .matches_logical_source(&mut session, &bridge, &duplicate)
                    .unwrap(),
                "malformed duplicate pairs cannot reuse one expected entry twice"
            );
            for bits in [
                0,
                (-0.0f64).to_bits(),
                0x7ff8_0000_0000_0017,
                0x7ff8_0000_0000_0018,
            ] {
                let mut form = source("0");
                form.kind = Kind::Number(f64::from_bits(bits));
                let witness = LogicalSourceWitness::from_source(&mut session, &form)
                    .unwrap()
                    .unwrap();
                let same = session
                    .data_scalar(&Literal::Number(f64::from_bits(bits)))
                    .unwrap();
                let other = session
                    .data_scalar(&Literal::Number(f64::from_bits(bits ^ 1)))
                    .unwrap();
                assert!(
                    witness
                        .matches_logical_source(&mut session, &bridge, &same)
                        .unwrap()
                );
                assert!(
                    !witness
                        .matches_logical_source(&mut session, &bridge, &other)
                        .unwrap()
                );
            }
            for text in ["{[1] 2}", "#{[1]}", "#{0 -0.0}", "{:a 1 :a 2}"] {
                assert!(
                    LogicalSourceWitness::from_source(&mut session, &source(text))
                        .unwrap()
                        .is_none()
                );
            }
        }
    }
    #[test]
    fn source_facts_reject_callback_poison_that_a_fresh_physical_snapshot_accepts() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = session(phase);
            let bridge = FormBridge::new(&mut session).unwrap();
            let witness =
                LogicalSourceWitness::from_source(&mut session, &source("{:audit {:x 17}}"))
                    .unwrap()
                    .unwrap();
            session.eval("(def source-root {:audit {:x 17}}) (def saved-source-hash suss.core/hash) (def source-hash-calls 0)").unwrap();
            let root = session.eval("source-root").unwrap();
            assert!(
                witness
                    .matches_logical_source(&mut session, &bridge, &root)
                    .unwrap()
            );
            session.enter_namespace("suss.core").unwrap();
            session.eval("(def hash (fn [key] (do (if (= key 101) (do (aset (.-arr (get user/source-root :audit)) 1 99) (set! user/source-hash-calls (+ user/source-hash-calls 1))) nil) (user/saved-source-hash key))))").unwrap();
            session.enter_namespace("user").unwrap();
            session
                .eval("(set [101 102 103 104 105 106 107 108 109])")
                .unwrap();
            let observed = session
                .eval("[(get (get source-root :audit) :x) source-hash-calls]")
                .unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &observed).unwrap(),
                "[99 1]"
            );
            let poisoned_snapshot = session.capture_storage(&root).unwrap();
            session.collect().unwrap();
            assert!(session.storage_matches(&root, &poisoned_snapshot).unwrap());
            assert!(
                !witness
                    .matches_logical_source(&mut session, &bridge, &root)
                    .unwrap()
            );
            let observed = session.eval("(get (get source-root :audit) :x)").unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &observed).unwrap(),
                "99",
                "validation must not repair old storage"
            );
        }
    }
    #[test]
    fn source_facts_do_not_realize_lazy_data_or_authorize_hash_memos() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = session(phase);
            let bridge = FormBridge::new(&mut session).unwrap();
            let witness = LogicalSourceWitness::from_source(&mut session, &source("(1 2)"))
                .unwrap()
                .unwrap();
            session
                .eval("(def logical-list (list 1 2)) (def finite-calls 0)")
                .unwrap();
            let value = session.eval("logical-list").unwrap();
            assert!(
                witness
                    .matches_logical_source(&mut session, &bridge, &value)
                    .unwrap()
            );
            session
                .eval("(hash logical-list) (set! (.-__hash logical-list) 999)")
                .unwrap();
            assert!(
                witness
                    .matches_logical_source(&mut session, &bridge, &value)
                    .unwrap(),
                "logical equality cannot certify a forged hash field"
            );
            let lazy = session
                .eval("(new cljs.core/LazySeq nil (fn [] (do (set! finite-calls 1) (list 1 2))) nil nil)")
                .unwrap();
            assert!(
                witness
                    .matches_logical_source(&mut session, &bridge, &lazy)
                    .unwrap_err()
                    .to_string()
                    .contains("Lazy data needs fueled source realization")
            );
            let effects = session.eval("finite-calls").unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &effects).unwrap(),
                "0"
            );
            let cycle = session.eval("(def finite-cycle (list 1 2)) (set! (.-rest finite-cycle) finite-cycle) finite-cycle").unwrap();
            session.collect().unwrap();
            assert!(
                witness
                    .matches_logical_source(&mut session, &bridge, &cycle)
                    .unwrap_err()
                    .to_string()
                    .contains("Cyclic")
            );
            let recovery = session.eval("42").unwrap();
            assert_eq!(
                crate::portable_repl::display(&mut session, &recovery).unwrap(),
                "42"
            );
            let mut other = Session::new().unwrap();
            assert!(matches!(
                witness.matches_logical_source(&mut other, &bridge, &value),
                Err(SessionError::ForeignValue)
            ));
        }
    }
    #[test]
    fn source_facts_construction_preserves_typed_fuel_and_interrupt_errors() {
        let mut session = session(Phase::Macro);
        let form = source("^{:m [1 2]} {:a [1 2 3]}");
        let cost = session
            .with_operation_budget(|session| {
                let before = session.operation_fuel_remaining()?;
                assert!(LogicalSourceWitness::from_source(session, &form)?.is_some());
                Ok(before - session.operation_fuel_remaining()?)
            })
            .unwrap();
        let allowance = 2 * cost - 1;
        assert!(allowance < crate::portable::DEFAULT_OPERATION_FUEL);
        session.set_operation_fuel(allowance);
        let error = session
            .with_operation_budget(|session| {
                assert!(LogicalSourceWitness::from_source(session, &form)?.is_some());
                LogicalSourceWitness::from_source(session, &form)
            })
            .err()
            .unwrap();
        assert!(
            matches!(error, SessionError::Trap(ref error) if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)),
            "{error:?}"
        );
        assert!(
            LogicalSourceWitness::from_source(&mut session, &form)
                .unwrap()
                .is_some()
        );
        // Force real Store-fuel exhaustion inside each diagnostic-returning API.
        for clone in [false, true] {
            let error = session
                .with_operation_budget(|session| {
                    session.charge_host_work(allowance)?;
                    preserve_source_error(
                        form.span.clone(),
                        &mut |work| session.charge_host_work(work),
                        |charge| {
                            if clone {
                                crate::portable::clone_form_metered(&form, &mut |work| charge(work))
                                    .map(|_| ())
                            } else {
                                crate::portable::hir::reader_metadata_pairs_metered(
                                    &form,
                                    &mut |work| charge(work),
                                )
                                .map(|_| ())
                            }
                        },
                    )
                })
                .unwrap_err();
            assert!(
                matches!(error, SessionError::Trap(ref error) if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)),
                "{error:?}"
            );
            assert!(
                LogicalSourceWitness::from_source(&mut session, &form)
                    .unwrap()
                    .is_some()
            );
        }
        let interrupt = session.host_work_interrupt();
        let error = session
            .with_operation_budget(|session| {
                interrupt.store(true, std::sync::atomic::Ordering::SeqCst);
                LogicalSourceWitness::from_source(session, &form)
            })
            .err()
            .unwrap();
        assert!(
            matches!(error, SessionError::Trap(ref error) if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::Interrupt)),
            "{error:?}"
        );
        assert!(
            LogicalSourceWitness::from_source(&mut session, &form)
                .unwrap()
                .is_some()
        );
    }
    #[test]
    fn source_facts_share_fuel_and_propagate_interrupt_without_publication() {
        let mut session = session(Phase::Macro);
        let bridge = FormBridge::new(&mut session).unwrap();
        let witness = LogicalSourceWitness::from_source(&mut session, &source("{:a [1 2 3]}"))
            .unwrap()
            .unwrap();
        let value = session.eval("{:a [1 2 3]}").unwrap();
        let cost = session
            .with_operation_budget(|session| {
                let before = session.operation_fuel_remaining()?;
                assert!(witness.matches_logical_source(session, &bridge, &value)?);
                Ok(before - session.operation_fuel_remaining()?)
            })
            .unwrap();
        let allowance = cost.checked_mul(2).unwrap() - 1;
        assert!(allowance < crate::portable::DEFAULT_OPERATION_FUEL);
        session.set_operation_fuel(allowance);
        let error = session
            .with_operation_budget(|session| {
                assert!(witness.matches_logical_source(session, &bridge, &value)?);
                witness.matches_logical_source(session, &bridge, &value)
            })
            .unwrap_err();
        assert!(
            matches!(error, SessionError::Trap(ref error) if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)),
            "{error:?}"
        );
        assert!(
            witness
                .matches_logical_source(&mut session, &bridge, &value)
                .unwrap()
        );
        let interrupt = session.host_work_interrupt();
        let error = session
            .with_operation_budget(|session| {
                interrupt.store(true, std::sync::atomic::Ordering::SeqCst);
                witness.matches_logical_source(session, &bridge, &value)
            })
            .unwrap_err();
        assert!(
            matches!(error, SessionError::Trap(ref error) if error.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::Interrupt)),
            "{error:?}"
        );
        assert!(
            witness
                .matches_logical_source(&mut session, &bridge, &value)
                .unwrap()
        );
    }
}
