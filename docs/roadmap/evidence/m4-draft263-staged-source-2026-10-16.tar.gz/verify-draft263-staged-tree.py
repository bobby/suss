from pathlib import Path
import subprocess,os,json,hashlib,time,re
c=Path(__file__).parent;r=c/'draft263-index-checkout';out=c/'draft263-index-verification';out.mkdir(exist_ok=False)
paths=json.loads((c/'indexed-form-copy-checkpoint/before-freeze.json').read_text())
def freeze():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths}
before=freeze();(out/'freeze-before.json').write_text(json.dumps(before,indent=2)+'\n')
state={'current':None,'stages':[],'input_count':len(before),'index_tree_at_checkout':'22729340b261ec5bb4b7abdce49cdd6ebff4f5c2','scope':'Actual staged source and HEAD bootstrap bytes, checkout-index snapshot; no later source edits. No full baseline or acceptance proof.'}
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'));env.pop('SUSS_HIR_COW_TRACE',None)
commands=[('compile',['cargo','test','-p','suss-compile','--locked','--lib','--no-run']),('ownership',['cargo','test','-p','suss-compile','--locked','--lib','portable::hir::local_bindings::ownership_tests::','--','--test-threads=2','--nocapture']),('origin',['cargo','test','-p','suss-compile','--locked','--lib','portable::origin::form_metadata::tests::','--','--test-threads=2','--nocapture']),('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--',str(out/'bootstrap-output')])]
def save():(out/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
for name,cmd in commands:
 assert freeze()==before
 entry={'name':name,'command':cmd};state['stages'].append(entry);state['current']=name;save();print('starting '+name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:result=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 entry.update(exit=result.returncode,seconds=time.monotonic()-start,summaries=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', (out/(name+'.log')).read_text()));save();print(json.dumps(entry),flush=True)
 if result.returncode:break
state['current']=None;after=freeze();state['changed']=[p for p in before if before[p]!=after[p]];(out/'freeze-after.json').write_text(json.dumps(after,indent=2)+'\n');save();print(json.dumps(state),flush=True)
