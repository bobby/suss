from pathlib import Path
import json,hashlib,tarfile,io,subprocess
C=Path('/home/bobby/.cache/suss-m4-work');P=Path(__file__).parent;R=C/'pr268-96bc8d7-ci/39093215076';H='96bc8d70ae447d0dba1e89a3c03e97ce0a0f84bb'
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((R/'carver-independent-terminal-review.json').read_text());assert r['head']==H
assert r['integration']['pass']==111 and r['integration']['fail']==14 and r['integration']['unexecuted_targets']==229
assert len(r['source_checkout_proofs'])==9
run=json.loads((R/'run.json').read_text());assert run['status']=='completed' and run['conclusion']=='failure'
g=lambda *a:subprocess.check_output(['git',*a],cwd='/home/bobby/Work/code/bobby/suss')
paths=['.github/workflows/ci.yml','scripts/verify-bootstrap.sh','scripts/ci_test_shards.py']+[f'runtime/bootstrap/{p}.{e}' for p in ['macro','runtime'] for e in ['json','wasm']]
bindings={}
for n in paths:
 b=g('show',H+':'+n);bindings[n]={'commit':H,'git_blob':g('rev-parse',H+':'+n).decode().strip(),'bytes':len(b),'sha256':sha(b)}
binding={'tested_head':H,'tree':g('rev-parse',H+'^{tree}').decode().strip(),'source_parent':'290e20eb8fa925d3e00faf99def0d4b7388aa684','repository':'https://github.com/bobby/suss','cljs_pin':'c4295f303100bbf5afac449242d30bca1126f1a1','files':bindings,'limits':'Explicit public Git dependencies, not a standalone compiler source bundle. Checkout proofs establish committed-tree identity, not clean-worktree or per-job artifact SHA measurements.'}
(P/'git-dependencies.json').write_text(json.dumps(binding,indent=2)+'\n')
report=f'''# Terminal CI evidence for PR #268 head 96bc8d7

Tested commit: `{H}`. GitHub Actions run [39093215076](https://github.com/bobby/suss/actions/runs/39093215076), event `push`, attempt 1, completed with **failure**. Foundation succeeded; all eight integration shards failed; the aggregate test job failed.

Foundation executed **536 passing Rust tests, 0 failures, 1 ignored**, and **353 passing Python tests**. The bootstrap verifier succeeded, including its two reproductions/four artifact comparisons and identity checks; four compiled-bootstrap tests passed.

Integration shards executed **111 passing tests, 14 failing tests, 0 ignored**. All fourteen failures are guest-fuel failures: eleven caller-&env input-transport failures and three compiled macro-invocation failures. Exact target/name/diagnostic rows are retained in `carver-independent-terminal-review.json`. All fourteen failed names and failure stages match the audited parent `ae28db396ee3050dedca812ff6993d7998e3e27f`; this is a comparison of observed failures, not proof that later targets pass.

The source-derived integration plan contains **259 targets**. **30 targets started and completed; 229 targets were unexecuted** because of fail-fast behavior. There are no started-but-unfinished targets in these terminal logs. Counts describe executions in this CI run, not a union with local focused tests.

The bundle retains the complete workflow ZIP (89 members), all ten root job logs, terminal API metadata, earlier pending-state metadata, eight early terminal shard log captures, the host audit script and review, and the parent comparison review. Nine actual checkout SHA proofs match the tested head. They are checkout/tree proofs, not nine custom source-hash or clean-worktree proofs. Committed compiler/runtime/scripts/workflow trees match source parent `290e20eb8fa925d3e00faf99def0d4b7388aa684`; the four committed bootstrap SHA-256 values and workflow/verifier/shard-script Git dependencies are recorded separately.

This is a Git-resolved evidence bundle, not a standalone source archive. The audit script uses the public Git objects and included parent review; its original absolute cache layout is retained in member paths. No CI rerun, source edit, Cargo execution, quota change, or passing-CI claim was made by the reviewer. This evidence does not include or credit the separate native-prefix 27-test result, its initial module-path compile failure, or the pending field-plan artifact codec. It does not establish issue acceptance, readiness, merge approval, or closure.
'''
(P/'REPORT.md').write_text(report)
files={}
for f in sorted(R.rglob('*')):
 if f.is_file():files['cache/'+str(f.relative_to(C))]=f.read_bytes()
old=C/'pr268-ae28db3-ci/39084668136/carver-independent-terminal-review.json';files['cache/'+str(old.relative_to(C))]=old.read_bytes()
for n in ['REPORT.md','git-dependencies.json','package.py']:files[n]=(P/n).read_bytes()
manifest={'schema':1,'tested_head':H,'run':39093215076,'files':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())}}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
a=P/'m4-pr268-96bc-terminal-ci-2026-10-17.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  assert not n.startswith('/') and '..' not in Path(n).parts
  i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 members=t.getmembers();assert len({m.name for m in members})==len(members)
 for m in members:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  if m.name!='MANIFEST.json':assert sha(t.extractfile(m).read())==manifest['files'][m.name]['sha256']
result={'archive':str(a),'sha256':sha(a.read_bytes()),'bytes':a.stat().st_size,'members':len(files),'payloads':len(files)-1,'tested_head':H,'safe_paths_and_all_payload_digests_verified':True,'repository_changes':False}
(P/'package-result.json').write_text(json.dumps(result,indent=2)+'\n')
(P/'handoff.ready.md').write_text(f'''\n### PR #268 terminal CI at 96bc8d7\n\nRead-only audit of `gh api repos/bobby/suss/actions/runs/39093215076`, job metadata and complete workflow logs verified tested head `{H}` and nine matching checkout SHA proofs. Foundation succeeded: Rust 536 pass/0 fail/1 ignored and Python 353 pass; bootstrap verification passed. All eight integration shards failed: 111 pass/14 guest-fuel failures/0 ignored (11 caller-&env, 3 macro invocation). Of 259 planned integration targets, 30 completed and 229 were unexecuted. Failed names/stages match parent ae28; later targets receive no pass credit.\n\nRaw logs, pending and terminal metadata, exact diagnostics, independent audit and explicit public-Git dependencies are preserved in `m4-pr268-96bc-terminal-ci-2026-10-17.tar.gz` (SHA-256 `{result['sha256']}`, {result['members']} members/{result['payloads']} payloads). This is failing CI evidence for 96bc, separate from native-prefix/codec work and local focused counts; no readiness, acceptance or closure claim. Publication on `experiment/m4-native-field-plans` does not change the tested head or PR #268 head.\n''')
print(json.dumps(result))
