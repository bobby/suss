from pathlib import Path
import re,json,subprocess,hashlib,zipfile
P=Path(__file__).parent;C=P.parents[1];H='96bc8d70ae447d0dba1e89a3c03e97ce0a0f84bb';OLD='ae28db396ee3050dedca812ff6993d7998e3e27f';PIN='c4295f303100bbf5afac449242d30bca1126f1a1'
g=lambda *a:subprocess.check_output(['git',*a]);sha=lambda b:hashlib.sha256(b).hexdigest()
def clean(raw):
 s=raw.decode('utf-8-sig',errors='replace');s=re.sub(r'\\u001b\[[0-9;]*m','',s);s=re.sub(r'\x1b\[[0-9;]*m','',s);return re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ?','',s,flags=re.M)
def parse(raw):
 s=clean(raw);lines=s.splitlines();current=None;pending=None;harnesses=[];rows=[];panics=[];plan=None;proof=[]
 for i,l in enumerate(lines):
  if 'git log -1 --format=%H' in l:
   found=re.fullmatch(r'[a-f0-9]{40}',lines[i+1].strip());assert found;proof.append(found[0])
  if l.startswith('{"index":'):plan=json.loads(l)
  m=re.search(r'Running (tests/\S+\.rs|unittests \S+) \(',l)
  if m:pending=m[1]
  if re.match(r'running \d+ tests?$',l):current=pending
  if l.startswith('   Doc-tests '):current=l.strip();pending=current
  m=re.match(r'test (.+?) \.\.\. (ok|FAILED|ignored)(?:\s|$)',l)
  if m:rows.append({'target':current,'name':m[1],'status':m[2]})
  m=re.match(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',l)
  if m:harnesses.append({'target':current,'pass':int(m[1]),'fail':int(m[2]),'ignore':int(m[3])})
  if 'panicked at' in l:
   name=re.search(r"thread '([^']+)'",l);diag='\n'.join(lines[i:i+5]);panics.append({'name':name[1] if name else None,'target':current,'diagnostic':diag,'kind':'guest-fuel' if 'all fuel consumed' in diag else 'other'})
 return {'text':s,'checkout':proof,'plan':plan,'harnesses':harnesses,'rows':rows,'panics':panics,'compile_errors':re.findall(r'error\[E\d+\]',s)}
run=json.loads((P/'run.json').read_text());jobs=json.loads((P/'jobs.json').read_text())['jobs'];assert run['head_sha']==H and run['status']=='completed' and run['conclusion']=='failure' and len(jobs)==10 and all(j['status']=='completed' for j in jobs)
logs={};proofs=[];ints=[];foundation=None
with zipfile.ZipFile(P/'workflow-logs.zip') as z:
 for f in sorted((P/'all-logs').glob('*.txt')):
  assert f.read_bytes()==z.read(f.name);d=parse(f.read_bytes());assert not d['compile_errors'];logs[f.name]={'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size};label=re.search(r'Complete job name: (.+)',d['text']);label=label[1] if label else f.name
  for checkout in d['checkout']:assert checkout==H and PIN in d['text'];proofs.append({'log':f.name,'checkout':checkout,'cljs_pin':PIN,'tree_equals_requested_head':True,'proof_kind':'Actual checkout git log -1 SHA; committed tree identity, not per-job clean-worktree or custom hash proof'})
  d['job']=label;d['log']=f.name
  if d['plan']:ints.append(d)
  if 'foundation' in label:foundation=d
assert len(logs)==10 and len(proofs)==9 and len(ints)==8 and foundation
counts=lambda hs:{k:sum(x[k] for x in hs) for k in ['pass','fail','ignore']}
plan={tuple(t) for d in ints for t in d['plan']['targets']};assert len(plan)==259 and all(d['plan']['total_targets']==259 for d in ints)
harnesses=[dict(x,job=d['job']) for d in ints for x in d['harnesses']];rows=[dict(x,job=d['job']) for d in ints for x in d['rows']];failed=[x for x in rows if x['status']=='FAILED'];panics=[x for d in ints for x in d['panics']];assert len(failed)==len(panics);assert all(x['kind']=='guest-fuel' for x in panics)
for x in failed:x['cause']=next(y['diagnostic'] for y in panics if y['name']==x['name'] and y['target']==x['target']);x['stage']='macro invocation' if 'compiled macro invocation' in x['cause'] else 'caller-&env' if 'caller &env' in x['cause'] else 'inspect diagnostic'
completed={('suss-cli',Path(x['target']).stem) for x in harnesses};started={('suss-cli',Path(x['target']).stem) for x in rows};assert completed<=plan and started<=plan
ic=counts(harnesses);assert ic=={'pass':sum(x['status']=='ok' for x in rows),'fail':len(failed),'ignore':sum(x['status']=='ignored' for x in rows)}
fc=counts(foundation['harnesses']);assert fc=={'pass':sum(x['status']=='ok' for x in foundation['rows']),'fail':sum(x['status']=='FAILED' for x in foundation['rows']),'ignore':sum(x['status']=='ignored' for x in foundation['rows'])};py=[int(x) for x in re.findall(r'^Ran (\d+) tests? in ',foundation['text'],re.M)]
old=json.loads((C/'pr268-ae28db3-ci/39084668136/carver-independent-terminal-review.json').read_text());key=lambda x:(Path(x['target']).stem,x['name']);oldfail={key(x) for x in old['failed_tests']};newfail={key(x) for x in failed}
changed=g('diff','--name-only',OLD,H).decode().splitlines()
source_parent='290e20eb8fa925d3e00faf99def0d4b7388aa684'
assert g('rev-parse',H+':crates')==g('rev-parse',source_parent+':crates')
assert g('rev-parse',H+':runtime')==g('rev-parse',source_parent+':runtime')
assert g('rev-parse',H+':scripts')==g('rev-parse',source_parent+':scripts')
assert g('rev-parse',H+':.github')==g('rev-parse',source_parent+':.github')

bootnames=[f'runtime/bootstrap/{p}.{e}' for p in ['macro','runtime'] for e in ['json','wasm']];boot={n:sha(g('show',H+':'+n)) for n in bootnames};assert 'verify-bootstrap.sh' in foundation['text'];assert len([x for x in foundation['rows'] if x['name'].startswith('compiled_bootstrap_') and x['status']=='ok'])==4
out={'verdict':'VERIFIED exact-head failing CI; no readiness or acceptance approval','run':run['id'],'head':H,'event':run['event'],'jobs':[{'name':x['name'],'id':x['id'],'status':x['status'],'conclusion':x['conclusion']} for x in jobs],'root_logs':logs,'workflow_zip_sha256':sha((P/'workflow-logs.zip').read_bytes()),'zip_member_count':len(zipfile.ZipFile(P/'workflow-logs.zip').namelist()),'source_checkout_proofs':proofs,'source_equivalence':{'compiler_source_head':source_parent,'comparison_parent_head':OLD,'changed_paths':changed,'crates_runtime_scripts_workflow_trees_identical_to_source_parent':True,'bootstrap_committed_sha256':boot,'limits':'Nine actual checkout SHA/tree proofs; no invented custom source-hash/clean-worktree proof. Foundation runs committed verifier; integration uses checked-out artifacts.'},'foundation':{'Rust':fc,'Python_test_total':sum(py),'Python_group_counts':py,'harnesses':foundation['harnesses'],'results':foundation['rows'],'bootstrap_verifier':'Foundation job success; verify-bootstrap.sh two reproductions/four comparisons/identity per unchanged script; four compiled_bootstrap tests passed.'},'integration':{**ic,'planned_targets':len(plan),'completed_targets':len(completed),'started_targets':len(started),'unfinished_targets':sorted(started-completed),'unexecuted_targets':len(plan-started)},'harnesses':harnesses,'results':rows,'failed_tests':failed,'planned_targets':sorted(plan),'unexecuted_targets':sorted(plan-started),'comparison_vs_ae28':{'same_failed_names':oldfail==newfail,'new_failed_names':sorted(newfail-oldfail),'old_failed_names_not_executed_as_failed':sorted(oldfail-newfail),'old_counts':old['integration']},'limits':'Counts are actual completed harness executions, not unique coverage across runs. Later fail-fast targets and namespace semantic probes get no pass credit. No source edits/Cargo/CI rerun by reviewer.'}
(P/'carver-independent-terminal-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'foundation':out['foundation']['Rust'],'Python':sum(py),'integration':out['integration'],'same_failed_names':oldfail==newfail,'failed_names':[x['name'] for x in failed]},indent=2))
