from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-acceptance');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'combined-acceptance-target'),RAYON_NUM_THREADS='2',SUSS_CLOJURE_TEST_SUITE_CAPTURE=str(c/'map-combined-cold'))
files=[p for p in (r/'crates').rglob('*') if p.suffix in ['.rs','.sus']]+list((r/'runtime/bootstrap').glob('*'));freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()};state={'base':'a182b98','integrated':'84eba2f','freeze':freeze,'stages':[]};receipt=c/'combined-cold-focused-result.json'
commands=[]
for name,filter in [('scoped','scoped_memo_stores_'),('leaf','native_memo_leaf_'),('raw-keys','portable_macro_graph::raw_keys::'),('initializer','initializer_plan::tests')]:commands.append((name,['cargo','test','-p','suss-compile','--lib','--locked',filter,'--','--test-threads=2','--nocapture']))
for name,package,target in [('direct','suss-compile','form_bridge_identifier_hash'),('public','suss-cli','compiled_macro_cumulative_fuel'),('identity','suss-cli','compiled_macro_cross_invocation_identity_probe')]:commands.append((name,['cargo','test','-p',package,'--locked','--test',target,'--','--test-threads=2','--nocapture']))
commands.append(('map',['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--test-threads=2','--nocapture']))
for name,cmd in commands:
 state['current']=name;receipt.write_text(json.dumps(state,indent=2)+'\n');start=time.time()
 with (c/('combined-cold-focused-'+name+'.log')).open('w') as log:child=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 state['stages'].append({'name':name,'command':cmd,'exit':child.returncode,'seconds':time.time()-start})
state.update(current=None,source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in freeze.items()));receipt.write_text(json.dumps(state,indent=2)+'\n')
