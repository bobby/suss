from pathlib import Path
r=Path('/home/bobby/Work/code/bobby/suss-m4-cold-identifier-receiver-diagnostic')
p=r/'crates/suss-compile/src/portable_session.rs';s=p.read_text().replace('mod dispatch_observer;','mod dispatch_observer;\npub(crate) mod cold_receiver_diagnostic;');p.write_text(s)
p=r/'crates/suss-compile/src/portable_session/canonical_methods.rs';s=p.read_text();idx=s.index('impl CanonicalMethods {')+len('impl CanonicalMethods {');s=s[:idx]+'''
    pub(super) fn diagnostic_owner(&self, store: &mut wasmtime::StoreContextMut<'_, ()>, descriptor: &Val) -> wasmtime::Result<Option<&'static str>> {
        let Some(actual) = descriptor.anyref().flatten() else { return Ok(None) };
        for class in &self.source_classes {
            let expected = class.descriptor.value.to_rooted(&mut *store);
            if Rooted::ref_eq(&*store, actual, &expected)? {return Ok(Some(class.owner))}
        }
        Ok(None)
    }
'''+s[idx:];p.write_text(s)
p=r/'crates/suss-compile/src/portable_session/dispatch_observer.rs';s=p.read_text().replace('if let Some(authority) = authority {','if let Some(authority) = &authority {');s=s.replace('function.call(&mut caller, &arguments[..2], results)','''let diagnostic = if active && super::cold_receiver_diagnostic::enabled() {
                Some(super::cold_receiver_diagnostic::enter(caller.as_context_mut(), &arguments[3], authority.as_deref()))
            } else { None };
            let result = function.call(&mut caller, &arguments[..2], results);
            if let Some(diagnostic) = diagnostic {
                diagnostic.finish(caller.get_fuel().ok(), result.is_ok());
            }
            result''');p.write_text(s)
p=r/'crates/suss-compile/src/portable_macro_graph.rs';s=p.read_text();needle='            let inputs = frame.inputs;';s=s.replace(needle,needle+'''
            // Diagnostic roots have exactly the dynamic extent of these existing inputs.
            let diagnostic_origins = if crate::portable_session::cold_receiver_diagnostic::enabled() {
                Some(crate::portable_session::cold_receiver_diagnostic::origins(
                    inputs.iter().zip(&frame.dependencies).map(|(input, id)| {
                        let recipe = self.recipes[*id].as_ref().unwrap();
                        let label = match recipe {
                            Recipe::Identifier {namespace, name, keyword, literal} => format!("recipe={id} identifier ns={namespace:?} name={name:?} keyword={keyword} literal={}", literal.is_some()),
                            Recipe::Form(form) => format!("recipe={id} reader span={:?} kind={:?}", form.span, std::mem::discriminant(&form.kind)),
                            Recipe::Metadata {value, ..} => format!("recipe={id} metadata base={value}"),
                            Recipe::Alias(value) => format!("recipe={id} alias={value}"),
                            _ => format!("recipe={id} composite"),
                        };
                        (input.clone(), label)
                    }).collect()
                ))
            } else {None};
''');needle='            let tainted = frame.tainted;';
# drop before moving inputs out/return; scope naturally extends loop but roots input clones must drop before cached publication
pos=s.index('            let tainted',s.index('let diagnostic_origins')) if '            let tainted' in s[s.index('let diagnostic_origins'):] else -1
if pos>=0:s=s[:pos]+'            drop(diagnostic_origins);\n'+s[pos:]
else:raise Exception('no tainted marker')
p.write_text(s)
