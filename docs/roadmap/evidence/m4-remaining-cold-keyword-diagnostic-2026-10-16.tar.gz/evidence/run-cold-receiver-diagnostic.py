import os,json,time,subprocess,hashlib
from pathlib import Path
r=Path('/home/bobby/Work/code/bobby/suss-m4-cold-identifier-receiver-diagnostic'); c=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(c/'cold-identifier-receiver-target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2')
out=c/'cold-receiver-result.json'; state={'stages':[]}
def save():out.write_text(json.dumps(state,indent=2)+'\n')
def run(name,cmd,trace=False):
 e=env.copy()
 if trace:e.update(SUSS_COLD_RECEIVER_TRACE='1',SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1')
 stage={'name':name,'command':cmd};state['stages'].append(stage);state['current']=name;save();start=time.time()
 with (c/f'cold-receiver-{name}.log').open('w') as log:p=subprocess.run(cmd,cwd=r,env=e,stdout=log,stderr=subprocess.STDOUT)
 stage.update(exit=p.returncode,seconds=time.time()-start);save();return p.returncode
if run('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']):
 state['current']=None;save();raise SystemExit(1)
files=[p for p in (r/'crates').rglob('*.rs')]+list((r/'runtime/bootstrap').glob('*'))
state['freeze']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()};save()
run('invocation-tags',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_source_tags','compiled_source_invocation_tags_distinguish_global_aggregate_and_local_methods','--','--exact','--nocapture','--test-threads=1'],True)
state['source_unchanged']=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in state['freeze'].items());state['current']=None;save()
print(json.dumps({k:v for k,v in state.items() if k!='freeze'},indent=2))
