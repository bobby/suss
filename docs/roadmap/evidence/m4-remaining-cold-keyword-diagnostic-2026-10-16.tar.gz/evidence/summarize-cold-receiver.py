from pathlib import Path
import re,json,collections
c=Path('/home/bobby/.cache/suss-m4-work');p=c/'cold-receiver-invocation-tags.log'
if not p.exists():raise SystemExit('log not yet created')
entries={};groups=collections.defaultdict(lambda:{'calls':0,'complete':0,'failed':0,'inclusive':0,'exclusive':0,'examples':[]});unparsed=[]
for line in p.read_text().splitlines():
 if line.startswith('cold-receiver enter '):
  m=re.search(r'id=(\d+) depth=(\d+).*detail=(.*)',line)
  if not m:unparsed.append(line);continue
  ident,depth,detail=m.groups();entries[int(ident)]=(detail,int(depth),line)
 elif line.startswith('cold-receiver exit '):
  m=re.search(r'id=(\d+).*ok=(true|false) inclusive=(Some\((\d+)\)|None).*exclusive=(Some\((\d+)\)|None)',line)
  if not m:unparsed.append(line);continue
  ident,ok,_,inc,_,exc=m.groups();detail,depth,enter=entries.pop(int(ident),('missing',-1,''))
  # Preserve original detail literally, rather than guessing receiver names on decode error.
  g=groups[detail];g['calls']+=1;g['complete']+=ok=='true';g['failed']+=ok=='false';g['inclusive']+=int(inc or 0);g['exclusive']+=int(exc or 0)
  if len(g['examples'])<2:g['examples'].append({'id':int(ident),'depth':depth,'enter':enter,'exit':line})
result={'groups':sorted([dict(detail=k,**v) for k,v in groups.items()],key=lambda v:-v['exclusive']),'unmatched_entries':list(entries.values()),'unparsed':unparsed}
(c/'cold-receiver-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for g in result['groups'][:20]:print(g['calls'],g['exclusive'],g['failed'],g['detail'])
print('unmatched',len(entries),'unparsed',len(unparsed))
