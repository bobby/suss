//! Isolated observational diagnostic; never issues authority or calls guest code.
use super::{SessionValue, canonical_methods::CanonicalMethods};
use std::cell::RefCell;
use wasmtime::{AnyRef, Rooted, StoreContextMut, Val};
thread_local! {
    static ORIGINS: RefCell<Vec<Vec<(SessionValue, String)>>> = const { RefCell::new(Vec::new()) };
    static CALLS: RefCell<Vec<(u64, u64)>> = const { RefCell::new(Vec::new()) };
    static SERIAL: RefCell<u64> = const { RefCell::new(0) };
}
pub(crate) fn enabled() -> bool {std::env::var_os("SUSS_COLD_RECEIVER_TRACE").is_some()}
pub(crate) struct Origins;
pub(crate) fn origins(values: Vec<(SessionValue, String)>) -> Origins {
    ORIGINS.with(|s|s.borrow_mut().push(values)); Origins
}
impl Drop for Origins {fn drop(&mut self) {ORIGINS.with(|s|{s.borrow_mut().pop();});}}
fn reference(value: &Val) -> wasmtime::Result<&Rooted<AnyRef>> {
    value.anyref().flatten().ok_or_else(||wasmtime::Error::msg("not reference"))
}
fn fields(store: &mut StoreContextMut<'_, ()>, value: &Val) -> wasmtime::Result<Vec<Val>> {
    let object = reference(value)?.as_struct(&*store)?.ok_or_else(||wasmtime::Error::msg("not struct"))?;
    Ok(object.fields(&mut *store)?.collect())
}
fn text(store: &mut StoreContextMut<'_, ()>, value: &Val) -> wasmtime::Result<String> {
    let value=reference(value)?;
    if let Some(i)=value.as_i31(&*store)? {return Ok(format!("sentinel:{}",i.get_u32()))}
    let array=value.as_array(&*store)?.ok_or_else(||wasmtime::Error::msg("not UTF16 array"))?;
    let units:Vec<u16>=array.elems(&mut *store)?.map(|v|v.unwrap_i32() as u16).collect();
    Ok(format!("{:?} units={units:?}",String::from_utf16_lossy(&units)))
}
fn inspect(store: &mut StoreContextMut<'_, ()>, receiver:&Val, authority:Option<&CanonicalMethods>) -> wasmtime::Result<String> {
    let storage=fields(store,receiver)?;
    let owner=authority.map(|a|a.diagnostic_owner(store,&storage[0])).transpose()?.flatten();
    if !matches!(owner,Some("Keyword"|"Symbol")) {return Ok(format!("owner={owner:?}"))}
    let array=reference(&storage[1])?.as_array(&*store)?.ok_or_else(||wasmtime::Error::msg("no fields"))?;
    let data:Vec<Val>=array.elems(&mut *store)?.collect();
    let ns=text(store,&data[0])?;let name=text(store,&data[1])?;
    let memo=if let Some(i)=reference(&data[3])?.as_i31(&*store)? {format!("sentinel:{}",i.get_u32())} else {format!("{:?}",fields(store,&data[3])?)};
    let origin=ORIGINS.with(|s|->wasmtime::Result<String>{
        for context in s.borrow().iter().rev() {for (value,label) in context {
            let rooted=value.value.to_rooted(&mut *store);
            if Rooted::ref_eq(&*store,reference(receiver)?,&rooted)? {return Ok(label.clone())}
        }} Ok("unmapped".into())
    })?;
    Ok(format!("owner={owner:?} ns={ns} name={name} memo={memo} origin={origin}"))
}
pub(super) struct Call {id:u64, before:Option<u64>,depth:usize}
pub(super) fn enter(mut store:StoreContextMut<'_, ()>, receiver:&Val,authority:Option<&CanonicalMethods>) -> Call {
    let id=SERIAL.with(|s|{let mut n=s.borrow_mut();*n+=1;*n});
    let before=store.get_fuel().ok();
    let detail=inspect(&mut store,receiver,authority);
    let depth=CALLS.with(|s|{let mut s=s.borrow_mut();let n=s.len();s.push((id,0));n});
    eprintln!("cold-receiver enter id={id} depth={depth} fuel={before:?} detail={detail:?}");
    Call{id,before,depth}
}
impl Call {pub(super) fn finish(self,after:Option<u64>,ok:bool) {
    let delta=self.before.zip(after).and_then(|(a,b)|a.checked_sub(b));
    let child=CALLS.with(|s|{let mut s=s.borrow_mut();let (id,child)=s.pop().expect("diagnostic frame");assert_eq!(id,self.id);if let (Some(parent),Some(delta))=(s.last_mut(),delta){parent.1=parent.1.saturating_add(delta)}child});
    let exclusive=delta.and_then(|d|d.checked_sub(child));
    eprintln!("cold-receiver exit id={} depth={} fuel={after:?} ok={ok} inclusive={delta:?} nested={child} exclusive={exclusive:?}",self.id,self.depth);
}}
