from pathlib import Path
import os,subprocess,json,hashlib,time
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-when-let');o=c/'when-let-76a-resource-bounded-full-baseline';o.mkdir(exist_ok=False)
expected=json.loads((c/'when-let-1a85-full-baseline/before-freeze.json').read_text())
def freeze():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in expected}
before=freeze();assert before==expected
(o/'before-freeze.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=['cargo','test','--workspace','--locked','--','--test-threads=2']
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'),RAYON_NUM_THREADS='2')
d={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'command':cmd,'input_count':len(before),'current':'workspace-baseline','environment':{'CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','CARGO_TARGET_DIR':str(c/'analyzer-literal-key-target'),'RUSTFLAGS_set_by_driver':False},'qualification':'Required full workspace baseline after unchanged8 lifecycle tests pass. Compiler Rayon workers bounded2; testthreads2, deadlines and fuel unchanged. Previous342pass4timeout baseline retained; no passing result until terminal.'}
(o/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');start=time.monotonic()
with (o/'workspace-baseline.log').open('w') as f:
 p=subprocess.Popen(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT);d['cargo_pid']=p.pid;(o/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');code=p.wait()
after=freeze();d.update(current=None,exit=code,seconds=time.monotonic()-start,changed=[p for p in before if before[p]!=after[p]],inputs_unchanged=before==after)
(o/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
