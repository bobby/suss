from pathlib import Path
import subprocess,hashlib,json,io,re,datetime
b=Path('/home/bobby/.cache/suss-m4-work');p=b/'when-let-76a-resource-bounded-full-baseline';repo=Path('/home/bobby/Work/code/bobby/suss-m4-when-let-baseline-reconcile');freeze=json.loads((p/'before-freeze.json').read_bytes());assert len(freeze)==1846
h=lambda x:hashlib.sha256(x).hexdigest();commits=['76a79718843741ead53f9432a2407cbcc4913c65','69dcc2fc4379c5b5d9980e63247f2d489159f8d3'];verified={}
for c in commits:
 raw=subprocess.check_output(['git','cat-file','--batch'],cwd=repo,input=''.join(c+':'+n+'\n' for n in freeze).encode());stream=io.BytesIO(raw)
 for n,expected in freeze.items():
  header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob',(c,n,header);value=stream.read(int(header[2]));assert stream.read(1)==b'\n';assert h(value)==expected,(c,n)
 verified[c]=len(freeze)
changes=subprocess.check_output(['git','diff','--name-only',*commits],cwd=repo,text=True).splitlines();assert all(n.startswith('docs/') for n in changes)
# Original live producer worktree retained; independently re-hash its final inputs.
root=Path('/home/bobby/Work/code/bobby/suss-m4-when-let');mismatch=[n for n,v in freeze.items() if not (root/n).is_file() or h((root/n).read_bytes())!=v];assert not mismatch,mismatch
raw=(p/'workspace-baseline.log').read_bytes();s=re.sub(r'\x1b\[[0-9;]*m','',raw.decode(errors='replace'));summ=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',s);assert len(summ)==256 and all(x[0]=='ok' and int(x[2])==0 for x in summ)
tot={'pass':sum(int(x[1]) for x in summ),'fail':sum(int(x[2]) for x in summ),'ignore':sum(int(x[3]) for x in summ)};assert tot=={'pass':1825,'fail':0,'ignore':18}
receipt=json.loads((p/'receipt.json').read_bytes());assert receipt['exit']==0 and receipt['current'] is None and receipt['changed']==[] and receipt['inputs_unchanged'] is True
running=re.findall(r'Running (tests/\S+\.rs|unittests \S+) \(',s);doc=re.findall(r'Doc-tests (\S+)',s);ignored=re.findall(r'^test (.+?) \.\.\. ignored(?:,.*)?$',s,re.M);assert len(ignored)==18
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'VERIFIED full required workspace command terminal success; publish qualified source-equivalent evidence, no merge/issue-close action','receipt_exit':0,'seconds':receipt['seconds'],'summaries':len(summ),'totals':tot,'unique_ignored_names':len(set(ignored)),'ignored_names':ignored,'integration_binary_invocations':sum(x.startswith('tests/') for x in running),'unit_binary_invocations':sum(x.startswith('unittests') for x in running),'doctest_crates':doc,'source_bindings':verified,'final_worktree_input_hashes_verified':len(freeze),'docs_only_changes_76a_to_69d':changes,'log_sha256':h(raw),'command':receipt['command'],'environment':receipt['environment'],'limits':['1825 are passing executions, not separately deduplicated semantic contracts','18 existing ignores retained, no universal suite conformance claim','jobs2/Rayon2/testthreads2; no deadline/fuel changes','Earlier342pass4timeout result and unchanged8pass rerun remain separate historical evidence','Final-headCIgreen remains separate retained69d evidence; no merge authorized']}
(p/'independent-terminal-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
