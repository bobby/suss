from pathlib import Path
import json,hashlib,subprocess,tarfile,io,re
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss-m4-when-let');O=C/'when-let-full-baseline-evidence';B=C/'when-let-76a-resource-bounded-full-baseline';P=C/'when-let-full-baseline-evidence-plan';TESTED='76a79718843741ead53f9432a2407cbcc4913c65';HEAD='69dcc2fc4379c5b5d9980e63247f2d489159f8d3';PIN='c4295f303100bbf5afac449242d30bca1126f1a1';payload={}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
allowed={'docs/roadmap/handoff.md','docs/roadmap/evidence/m4-when-let-full-workspace-baseline-2026-10-17.md','docs/roadmap/evidence/m4-when-let-full-workspace-baseline-2026-10-17.tar.gz'};assert set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R,text=True).splitlines())<=allowed
def put(n,b):assert n not in payload,n;payload[n]=b
receipt=json.loads((B/'receipt.json').read_text());assert receipt['head']==TESTED and receipt['exit']==0 and receipt['current'] is None and receipt['inputs_unchanged'] and not receipt['changed']
freeze=json.loads((B/'before-freeze.json').read_text());assert len(freeze)==1846
for f in B.iterdir():
 if f.is_file():put('baseline/'+f.name,f.read_bytes())
for f in P.iterdir():
 if f.is_file():put('assembly/'+f.name,f.read_bytes())
blobs={};bindings={}
for head in [TESTED,HEAD]:
 raw=subprocess.check_output(['git','cat-file','--batch'],cwd=R,input=''.join(head+':'+n+'\n' for n in freeze).encode());stream=io.BytesIO(raw);checked={}
 for n,h in freeze.items():
  header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob';b=stream.read(int(header[2]));assert stream.read(1)==b'\n';assert hashlib.sha256(b).hexdigest()==h,(head,n);checked[n]=h;blobs[h]=b
 bindings[head]={'checked':len(checked),'inputs':checked,'mismatches':[]}
for n,h in freeze.items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h,n
put('source-equivalence/bindings.json',(json.dumps(bindings,indent=2)+'\n').encode())
put('source-equivalence/docs-only-diff.patch',subprocess.check_output(['git','diff','--binary',TESTED,HEAD],cwd=R))
# Pinned four are SUPPLEMENTAL: original recorded1846 map omitted submodule
# leaves. Do not claim them as contemporaneously captured input1847..1850.
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R/'clojurescript',text=True).strip()==PIN
support={}
for n in ['deps.edn','project.clj','src/main/cljs/cljs/core.cljs','src/main/clojure/cljs/core.cljc']:
 b=subprocess.check_output(['git','show',PIN+':'+n],cwd=R/'clojurescript');assert (R/'clojurescript'/n).read_bytes()==b;support['clojurescript/'+n]=hashlib.sha256(b).hexdigest();put('pinned-support/'+n,b)
put('pinned-support/manifest.json',(json.dumps({'pin':PIN,'checked':4,'inputs':support,'qualification':'Separate supplemental pin verification, not counted in recorded1846 closure. Both tested/published Git links pointc429.'},indent=2)+'\n').encode())
for h,b in blobs.items():put('frozen/sha256/'+h,b)
for n in ['run-when-let-76a-resource-bounded-full-baseline.py','verify-whenlet-terminal-baseline.py','when-let-69dcc2f-independent-head-review.json','when-let-full-baseline-success-comment.md']:
 put('commands-and-independent-proof/'+n,(C/n).read_bytes())
# Retain prior timeout/retry history as EXACT immutable reviewed archive, not
# rewritten/regenerated content claiming its failures were successful.
old=R/'docs/roadmap/evidence/m4-when-let-local-timeouts-rerun-ci-2026-10-17.tar.gz';oldbytes=old.read_bytes();assert hashlib.sha256(oldbytes).hexdigest()=='f1c6ef12c2d4a99dc2d6e86f0555d35eff123acf3be98cbbfb99cc0dd47a82b1';put('prior-history/'+old.name,oldbytes)
# Current published69dCI raw/proofs remain separate exacthead evidence.
ci=C/'pr267-69dcc2f-ci'/'39013433075';term=json.loads((ci/'terminal-receipt.json').read_text());assert term['head']==HEAD and term['conclusion']=='success'
for f in ci.rglob('*'):
 if f.is_file() and '__pycache__' not in f.parts:put('ci69d/'+str(f.relative_to(ci)),f.read_bytes())
put('ci69d-source-correspondence.json',(C/'pr267-69dcc2f-ci'/'source-correspondence.json').read_bytes())
raw=(B/'workspace-baseline.log').read_text();plain=re.sub(r'\x1b\[[0-9;]*m','',raw);summ=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',plain);assert len(summ)==256 and all(x[0]=='ok' for x in summ)
totals=[sum(int(row[i]) for row in summ) for i in [1,2,3]];assert totals==[1825,0,18];ignored=re.findall(r'^test (.+?) \.\.\. ignored(?:,.*)?$',plain,re.M);assert len(ignored)==18
running=re.findall(r'Running (tests/\S+\.rs|unittests \S+) \(',plain);counts={'integration':sum(s.startswith('tests/') for s in running),'unit':sum(s.startswith('unittests') for s in running),'doctests':len(re.findall(r'Doc-tests (\S+)',plain))};assert counts=={'integration':246,'unit':6,'doctests':4}
summary={'tested_head':TESTED,'published_docs_head':HEAD,'command':receipt['command'],'exit':0,'seconds':receipt['seconds'],'completed_summaries':len(summ),'passing_executions':totals[0],'failed':totals[1],'ignored':totals[2],'ignored_names':ignored,'harnesses':counts,'recorded_inputs':1846,'supplemental_pinned_files':4,'source_equivalent_to69d':True,'limits':['1825passing executions, not independentlydeduplicated contracts','18existing ignores retained','AssemblyafterFFhashmap is not invented contemporaneousafterfreeze','Earlier342pass4timeouts/unchanged8rerun preserved historically','No tests/deadlines/fuel changes','Fullbaseline on76a source-equivalent69d; futuredocsheadCI separate','No merge/issueclose authorized']}
put('summary.json',(json.dumps(summary,indent=2)+'\n').encode());put('assembly/package.py',Path(__file__).read_bytes())
checks=''.join(hashlib.sha256(payload[n]).hexdigest()+'  '+n+'\n' for n in sorted(payload));put('SHA256SUMS',checks.encode())
a=R/'docs/roadmap/evidence/m4-when-let-full-workspace-baseline-2026-10-17.tar.gz'
with tarfile.open(a,'w:gz',compresslevel=6) as tar:
 for n in sorted(payload):
  b=payload[n];info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
hashes={};maps={}
with tarfile.open(a,'r|gz') as tar:
 for m in tar:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts and m.name not in hashes
  b=tar.extractfile(m).read();assert b==payload[m.name];hashes[m.name]=hashlib.sha256(b).hexdigest()
  if m.name.endswith('freeze.json'):maps[m.name]=json.loads(b)
for n,f in maps.items():
 assert len(f)==1846
 for source,h in f.items():assert hashes.get('frozen/sha256/'+h)==h,(n,source)
assert len(payload)==len(hashes)
j={'archive':str(a),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'members':len(payload),'manifested_payloads':len(payload)-1,'bytes':a.stat().st_size,'tested_head':TESTED,'docs_parent':HEAD,'source_bound_each':1846,'pinned_support':4,'freeze_closure_maps':list(maps)};(O/'package-result.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j))
