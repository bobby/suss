from pathlib import Path
import json,hashlib,time,subprocess,os
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access')
parent=json.loads((c/'private-slot-log-source-tags-result.json').read_text());assert parent['current'] is None and parent['source_unchanged'] and parent['exit']!=0
freeze=parent['freeze'];assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items())
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'),SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1')
cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_source_tags','compiled_source_inference_matches_pinned_tags_without_changing_executed_storage_or_effects','--','--exact','--nocapture','--test-threads=1']
s={'base':'7c08c91+private-slot-log','command':cmd,'current':'trace','freeze':freeze,'interpretation':'Existing stage trace toggles only, default cumulative fuel and unchanged source. Balances are inclusive breadcrumbs, not additive exclusive costs.'};out=c/'private-slot-log-inference-trace-result.json';out.write_text(json.dumps(s,indent=2)+'\n');start=time.time()
with (c/'private-slot-log-inference-trace.log').open('w') as log:result=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
s.update(current=None,exit=result.returncode,seconds=time.time()-start,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items()));out.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='freeze'},indent=2))
