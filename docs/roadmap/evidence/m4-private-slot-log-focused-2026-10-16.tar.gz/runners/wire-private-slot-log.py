from pathlib import Path
r=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access')
p=r/'crates/suss-compile/src/portable_session/private_fixups.rs';s=p.read_text().replace('use super::{Session,','pub(crate) mod slot_log;\nuse super::{Session,',1);p.write_text(s)
p=r/'crates/suss-compile/src/portable_session.rs';s=p.read_text().replace('mod private_fixups;','pub(crate) mod private_fixups;',1);p.write_text(s)
p=r/'crates/suss-compile/src/portable_macro_data.rs';s=p.read_text().replace('    private_arguments: bool,','    private_arguments: bool,\n    private_slots: Option<crate::portable_session::private_fixups::slot_log::SharedSlotLog>,',1)
s=s.replace('recording: None, private_arguments: true,','recording: None, private_arguments: true, private_slots: None,')
s=s.replace('            private_arguments: false,','            private_arguments: false, private_slots: None,')
needle='    pub(crate) fn recording(&self, session: &mut Session) -> Result<Self, SessionError> {'
s=s.replace(needle,'''    pub(crate) fn private_parent_bridge_with_slots(&self,session:&mut Session,log:&crate::portable_session::private_fixups::slot_log::SharedSlotLog)->Result<Self,SessionError>{
        let mut bridge=self.private_parent_bridge(session)?;
        session.charge_host_work(2)?;
        bridge.private_slots=Some(log.clone());Ok(bridge)
    }
'''+needle,1)
s=s.replace('''            return session.data_construct_without_guest_callbacks(class, arguments);''','''            let selected=match &self.private_slots {Some(log)=>Some(log.borrow().inputs(session,arguments)?),None=>None};
            let value=session.data_construct_without_guest_callbacks(class, arguments)?;
            if let (Some(log),Some(selected))=(&self.private_slots,selected) {log.borrow_mut().capture_nominal(session,&value,&selected)?;}
            return Ok(value);''',1)
s=s.replace('''        } else {
            session.data_array(values)
        }
    }
    fn seed''','''        } else {
            let selected=match &self.private_slots {Some(log)=>Some(log.borrow().inputs(session,values)?),None=>None};
            let value=session.data_array(values)?;
            if let (Some(log),Some(selected))=(&self.private_slots,selected) {log.borrow_mut().capture_dense(session,&value,values.len(),&selected)?;}
            Ok(value)
        }
    }
    fn seed''',1)
p.write_text(s)
p=r/'crates/suss-compile/src/portable_macro_graph/reuse.rs';s=p.read_text().replace('    cuts: Vec<SessionValue>,','    cuts: Vec<SessionValue>,\n    slots: crate::portable_session::private_fixups::slot_log::SharedSlotLog,',1)
s=s.replace('''        Ok(Self {
            cache,''','''        let slots=crate::portable_session::private_fixups::slot_log::PrivateSlotLog::new(graph.session)?;
        Ok(Self {
            slots,
            cache,''',1)
s=s.replace('''Some(graph.session.data_array(&[])?)''','''Some(self.slots.borrow_mut().token(graph.session,index)?)''',1)
s=s.replace('''            graph.session.fixup_private_placeholders_with_cuts(&value, &pairs, &self.cuts)?;''','''            if self.slots.borrow().complete() {
                self.slots.borrow().apply(graph.session,&value,&pairs)?;
            } else {
                graph.session.fixup_private_placeholders_with_cuts(&value, &pairs, &self.cuts)?;
            }''',1)
s=s.replace('''        let bridge = self.bridge.private_parent_bridge(self.session)?;
        trace_graph(self, "bridge")?;
        let mut build = Build::new(self, cache)?;''','''        let mut build = Build::new(self, cache)?;
        let bridge = self.bridge.private_parent_bridge_with_slots(self.session,&build.slots)?;
        trace_graph(self, "bridge")?;''',1)
p.write_text(s)
p=r/'crates/suss-compile/src/portable_session/private_fixups/slot_log.rs';s=p.read_text().replace('complete:bool }','complete:bool, identity:u64 }').replace('complete:true})))','complete:true,identity:s.identity})))')
s=s.replace('''    pub(crate) fn register(&mut self,s:&mut Session,id:usize,value:&SessionValue)->Result<()> {''','''    pub(crate) fn token(&mut self,s:&mut Session,id:usize)->Result<SessionValue> {
        self.check_session(s)?;
        let value=s.data_array(&[])?;
        self.register_created(s,id,&value)?;Ok(value)
    }
    fn check_session(&self,s:&mut Session)->Result<()> {s.charge_host_work(1)?;if s.identity!=self.identity {return Err(invalid("Foreign private slot log"));}Ok(())}
    fn register_created(&mut self,s:&mut Session,id:usize,value:&SessionValue)->Result<()> {''')
s=s.replace('''        for v in values{s.charge_host_work''','''        self.check_session(s)?;
        for v in values{s.charge_host_work''',1)
s=s.replace('''        if selected.is_empty(){return Ok(())}s.check(value)?;''','''        self.check_session(s)?;
        if selected.is_empty(){return Ok(())}s.check(value)?;''',1)
s=s.replace('''        s.charge_host_work(1)?;s.check(root)?;''','''        self.check_session(s)?;
        s.charge_host_work(1)?;s.check(root)?;''',1)
s=s.replace('''            if !super::super::memo_bridge_nil_for_slot_log(&m.store,&backing.get(&mut m.store,1)?)?{return Err(invalid("Private dense backing is not fresh"));}''','''            let head=backing.get(&mut m.store,1)?;
            if !matches!(head,Val::AnyRef(Some(v)) if v.as_i31(&m.store)?.is_some_and(|i|i.get_u32()==0)){return Err(invalid("Private dense backing is not fresh"));}''')
s=s.replace('''let token=self.tokens.iter().find(|t|t.id==id).ok_or_else(||invalid("Unknown private token"))?;''','''let mut token=None;for candidate in &self.tokens {m.charge(1)?;if candidate.id==id {token=Some(candidate);break;}}let token=token.ok_or_else(||invalid("Unknown private token"))?;''')
s=s.replace('''let (_,token,target)=bindings.iter().find(|(id,_,_)|*id==slot.token).ok_or_else(||invalid("Unknown private slot token"))?;''','''let mut binding=None;for candidate in &bindings {m.charge(1)?;if candidate.0==slot.token {binding=Some(candidate);break;}}let (_,token,target)=binding.ok_or_else(||invalid("Unknown private slot token"))?;''')
# tests use actual fresh-token factory, never arbitrary registration.
s=s.replace('''let token=s.data_array(&[]).unwrap();let replacement=number(&mut s,17.0);
        let log=PrivateSlotLog::new(&mut s).unwrap();log.borrow_mut().register(&mut s,7,&token).unwrap();''','''let replacement=number(&mut s,17.0);
        let log=PrivateSlotLog::new(&mut s).unwrap();let token=log.borrow_mut().token(&mut s,7).unwrap();''')
s=s.replace('''let token=s.data_array(&[]).unwrap();let target=number(&mut s,19.0);let log=PrivateSlotLog::new(&mut s).unwrap();log.borrow_mut().register(&mut s,0,&token).unwrap();''','''let target=number(&mut s,19.0);let log=PrivateSlotLog::new(&mut s).unwrap();let token=log.borrow_mut().token(&mut s,0).unwrap();''')
p.write_text(s)
