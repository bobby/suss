from pathlib import Path
import json,hashlib,time,subprocess,os
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access');freeze=json.loads((c/'private-slot-log-source-tags-result.json').read_text())['freeze'];assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items())
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'))
s={'current':None,'stages':[],'freeze':freeze};out=c/'private-slot-log-final-focused-result.json'
for name,filter in [('reuse','portable_macro_graph::reuse::tests::'),('private-fixups','portable_session::private_fixups::')]:
 cmd=['cargo','test','-p','suss-compile','--locked','--lib',filter,'--','--test-threads=2','--nocapture'];entry={'name':name,'command':cmd};s['stages'].append(entry);s['current']=name;out.write_text(json.dumps(s,indent=2)+'\n');start=time.time()
 with (c/f'private-slot-log-final-{name}.log').open('w') as log:result=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 entry.update(exit=result.returncode,seconds=time.time()-start)
 if result.returncode:break
s.update(current=None,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items()));out.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='freeze'},indent=2))
