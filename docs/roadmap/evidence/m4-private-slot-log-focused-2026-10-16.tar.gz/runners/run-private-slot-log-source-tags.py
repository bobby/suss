from pathlib import Path
import json,hashlib,time,subprocess,os
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access')
freeze=json.loads((c/'private-slot-log-formatted-freeze.json').read_text())
assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items()), 'Source changed after focused freeze'
freeze.update({str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'crates').rglob('*.cljs')});
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=str(c/'analyzer-literal-key-target'))
cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_source_tags','--','--test-threads=2','--nocapture']
s={'base':'7c08c91+private-slot-log','command':cmd,'current':'source-tags','freeze':freeze,'interpretation':'Both unchanged tests; default cumulative fuel; no trace toggles, fixture or quota changes.'};out=c/'private-slot-log-source-tags-result.json';out.write_text(json.dumps(s,indent=2)+'\n');start=time.time()
with (c/'private-slot-log-source-tags.log').open('w') as log:result=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
s.update(current=None,exit=result.returncode,seconds=time.time()-start,source_unchanged=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in freeze.items()));out.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='freeze'},indent=2))
