//! Source-owned metadata reuse; private parent values are fixed only after callbacks.
use super::{
    AnalysisGraph, Result, Value, construction::RecordedMetadata,
    metadata_expectations::MetadataExpectation,
};
use crate::{
    portable::{
        metered_map::{Context, TryOrderedMap},
        resolve::Global,
    },
    portable_session::{Session, SessionError, SessionValue},
};
use std::{cmp::Ordering, rc::Rc, sync::Arc};

type Key = (Global, usize);
struct Meter<'a>(&'a mut Session);
impl Context<Key> for Meter<'_> {
    type Error = SessionError;
    fn charge(&mut self, n: u64) -> Result<()> {
        self.0.charge_host_work(n)
    }
    fn compare(&mut self, a: &Key, b: &Key) -> Result<Ordering> {
        self.charge(
            (a.0.namespace().len() + a.0.name().len() + b.0.namespace().len() + b.0.name().len())
                as u64
                + 1,
        )?;
        Ok(a.0.cmp(&b.0).then(a.1.cmp(&b.1)))
    }
}
#[derive(Default)]
pub(crate) struct DeclarationValues {
    metadata: TryOrderedMap<Key, Option<Rc<RecordedMetadata>>>,
}
pub(super) fn reserve<T>(session: &mut Session, values: &mut Vec<T>, extra: usize) -> Result<()> {
    session.charge_host_work(1)?;
    if extra > values.capacity() - values.len() {
        let needed = values
            .len()
            .checked_add(extra)
            .ok_or_else(|| invalid("Metadata reuse allocation overflow"))?;
        let cap = values
            .capacity()
            .checked_mul(2)
            .unwrap_or(needed)
            .max(needed);
        let bytes = cap
            .checked_add(values.len())
            .and_then(|n| n.checked_mul(std::mem::size_of::<T>()))
            .and_then(|n| u64::try_from(n).ok())
            .ok_or_else(|| invalid("Metadata reuse allocation overflow"))?;
        session.charge_host_work(bytes)?;
        values
            .try_reserve_exact(cap - values.len())
            .map_err(|_| invalid("Metadata reuse allocation failed"))?;
    }
    Ok(())
}
fn invalid(s: &'static str) -> SessionError {
    wasmtime::Error::msg(s).into()
}
fn fresh(graph: &mut AnalysisGraph<'_>, index: usize) -> Result<Option<Rc<RecordedMetadata>>> {
    let record = graph.record_metadata(index)?;
    if record.is_some() {
        graph.session.charge_host_work(
            (std::mem::size_of::<RecordedMetadata>() + 2 * std::mem::size_of::<usize>()) as u64,
        )?;
    }
    Ok(record.map(Rc::new))
}
struct Pending {
    alias: Value,
    index: usize,
    key: Key,
    record: Option<Rc<RecordedMetadata>>,
    current: Option<MetadataExpectation>,
    value: SessionValue,
    placeholder: Option<SessionValue>,
    old: bool,
}
pub(super) struct Build<'a> {
    cache: &'a mut DeclarationValues,
    sources: Vec<Option<usize>>,
    pending: Vec<Pending>,
    cuts: Vec<SessionValue>,
}
impl<'a> Build<'a> {
    fn new(graph: &mut AnalysisGraph<'_>, cache: &'a mut DeclarationValues) -> Result<Self> {
        cache
            .metadata
            .retain(&mut Meter(graph.session), |_, record| {
                record
                    .as_ref()
                    .is_some_and(|record| Arc::strong_count(record.source().revision()) > 1)
            })?;
        let mut sources = Vec::new();
        reserve(graph.session, &mut sources, graph.recipes.len())?;
        graph.session.charge_host_work(graph.recipes.len() as u64)?;
        sources.resize(graph.recipes.len(), None);
        for (index, source) in graph.metadata_sources.iter().enumerate() {
            graph.session.charge_host_work(1)?;
            sources[source.recipe] = Some(index);
        }
        Ok(Self {
            cache,
            sources,
            pending: Vec::new(),
            cuts: Vec::new(),
        })
    }
    // An immediate untainted input of a tainted private factory parent cannot
    // contain this build's fresh, unexposed placeholder. Keep it opaque at fixup.
    pub(super) fn cut(&mut self, session: &mut Session, value: &SessionValue) -> Result<()> {
        reserve(session, &mut self.cuts, 1)?;
        self.cuts.push(value.clone());
        Ok(())
    }
    pub(super) fn last_is_private(&self, id: Value) -> bool {
        self.pending
            .last()
            .is_some_and(|p| p.alias == id && p.placeholder.is_some())
    }
    pub(super) fn intercepts(&self, id: Value) -> bool {
        self.sources[id].is_some()
    }
    pub(super) fn produce(
        &mut self,
        graph: &mut AnalysisGraph<'_>,
        alias: Value,
    ) -> Result<SessionValue> {
        let index = self.sources[alias].ok_or_else(|| invalid("Missing metadata reuse source"))?;
        let source = &graph.metadata_sources[index];
        graph.session.charge_host_work(
            (source.global.namespace().len() + source.global.name().len()) as u64 + 1,
        )?;
        let key = (
            source.global.clone(),
            Arc::as_ptr(&source.revision) as usize,
        );
        let current = graph.metadata_expectation(index)?;
        let candidate = self
            .cache
            .metadata
            .get(&key, &mut Meter(graph.session))?
            .and_then(Option::as_ref)
            .cloned();
        let mut old = false;
        let record = if let (Some(record), Some(expected)) = (candidate, current.as_ref()) {
            if record.matches_recorded_source(graph.session, graph.bridge)?
                && expected.matches_logical_source(graph.session, graph.bridge, &record.value)?
            {
                old = true;
                Some(record)
            } else {
                fresh(graph, index)?
            }
        } else {
            fresh(graph, index)?
        };
        let value = match &record {
            Some(record) => record.value.clone(),
            None => graph.materialize_using(alias, graph.bridge)?,
        };
        let placeholder = if old {
            Some(graph.session.data_array(&[])?)
        } else {
            None
        };
        let result = placeholder.as_ref().unwrap_or(&value).clone();
        reserve(graph.session, &mut self.pending, 1)?;
        self.pending.push(Pending {
            alias,
            index,
            key,
            record,
            current,
            value,
            placeholder,
            old,
        });
        Ok(result)
    }
    fn valid(graph: &mut AnalysisGraph<'_>, pending: &Pending) -> Result<bool> {
        let Some(record) = &pending.record else {
            return Ok(false);
        };
        let valid = record.matches_recorded_source(graph.session, graph.bridge)?;
        let current = match &pending.current {
            Some(expected) => {
                expected.matches_logical_source(graph.session, graph.bridge, &record.value)?
            }
            None => false,
        };
        Ok(valid && current)
    }
    fn finish(
        mut self,
        graph: &mut AnalysisGraph<'_>,
        root: Value,
        mut value: SessionValue,
    ) -> Result<SessionValue> {
        let tracing = std::env::var_os("SUSS_METADATA_FUEL_TRACE").is_some();
        let trace = |session: &Session, stage: &str| -> Result<()> {
            if tracing {
                eprintln!("metadata-finish {stage}: {}", session.operation_fuel_remaining()?);
            }
            Ok(())
        };
        trace(graph.session, "start")?;
        // Only Old -> Fresh transitions can invoke more construction callbacks.
        // Each owner transitions at most once; a poisoned fresh value is never
        // retained and is not repaired behind a guest's back.
        loop {
            let mut rebuilt = false;
            for pending in &mut self.pending {
                graph.session.charge_host_work(1)?;
                if pending.old && !Self::valid(graph, pending)? {
                    pending.record = fresh(graph, pending.index)?;
                    pending.value = match &pending.record {
                        Some(record) => record.value.clone(),
                        None => graph.materialize_using(pending.alias, graph.bridge)?,
                    };
                    pending.old = false;
                    rebuilt = true;
                }
            }
            if !rebuilt {
                break;
            }
        }
        trace(graph.session, "rechecked")?;
        let mut certified = Vec::new();
        reserve(graph.session, &mut certified, self.pending.len())?;
        for pending in &self.pending {
            certified.push(Self::valid(graph, pending)?);
        }
        trace(graph.session, "certified")?;
        let mut pairs = Vec::new();
        reserve(graph.session, &mut pairs, self.pending.len())?;
        for pending in &self.pending {
            graph.session.charge_host_work(1)?;
            if let Some(placeholder) = &pending.placeholder {
                if pending.alias == root {
                    value = pending.value.clone();
                } else {
                    pairs.push((placeholder, &pending.value));
                }
            }
        }
        trace(graph.session, "pairs")?;
        if !pairs.is_empty() {
            graph.session.fixup_private_placeholders_with_cuts(&value, &pairs, &self.cuts)?;
        }
        trace(graph.session, "fixed")?;
        // No guest callback occurs between certification, fixups and publication.
        // Every entry is an independently complete certificate; budget failure
        // cannot publish a partially initialized record or compilation binding.
        for (pending, valid) in self.pending.into_iter().zip(certified) {
            self.cache.metadata.insert(
                pending.key,
                if valid { pending.record } else { None },
                &mut Meter(graph.session),
            )?;
        }
        trace(graph.session, "published")?;
        Ok(value)
    }
}
impl AnalysisGraph<'_> {
    pub(super) fn materialize_reusing(
        &mut self,
        root: Value,
        cache: &mut DeclarationValues,
    ) -> Result<SessionValue> {
        self.finish_recipes()?;
        if self.metadata_sources.is_empty() || !self.private_metadata_placement(root)? {
            return self.materialize_using(root, self.bridge);
        }
        let bridge = self.bridge.private_parent_bridge(self.session)?;
        let mut build = Build::new(self, cache)?;
        let value = self.materialize_controlled(root, &bridge, Some(&mut build))?;
        build.finish(self, root, value)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        portable::{
            hir::{Literal, SourceNamespace},
            resolve::Phase,
        },
        portable_macro_data::FormBridge,
    };
    use wasmtime::{AnyRef, Rooted, Val};
    #[test]
    fn reuse_frontier_preserves_repeated_occurrences_cached_aliases_and_metadata_clones() {
        use super::super::Recipe;
        use crate::portable_macro_data::MetadataShape;
        let mut session = Session::new_macro().unwrap();
        session.eval("(def ^{:doc \"frontier\"} frontier-target 17)").unwrap();
        let bridge = FormBridge::new(&mut session).unwrap();
        let snapshot = session.compilation_snapshot();
        let namespace = SourceNamespace::capture(&snapshot.environment, Phase::Macro);
        let (global, revision) = namespace.declarations.iter().find(|(g, _)| g.name()=="frontier-target").unwrap();
        let mut cache = DeclarationValues::default();
        let saved = {
            let mut graph = AnalysisGraph::with_declaration_values(&bridge, &mut session, &mut cache);
            graph.declaration(global, Some(revision), 0).unwrap();
            let root = graph.metadata_sources[0].recipe;
            graph.materialize(root).unwrap()
        };
        session.collect().unwrap();
        let value = {
            let mut graph = AnalysisGraph::with_declaration_values(&bridge, &mut session, &mut cache);
            graph.declaration(global, Some(revision), 0).unwrap();
            let source = graph.metadata_sources[0].recipe;
            let alias = graph.recipe(Recipe::Alias(source)).unwrap();
            let m = graph.recipe(Recipe::Identifier{namespace:None,name:"m".into(),keyword:true}).unwrap();
            let branch_key = graph.recipe(Recipe::Identifier{namespace:None,name:"branch".into(),keyword:true}).unwrap();
            let x = graph.recipe(Recipe::Identifier{namespace:None,name:"x".into(),keyword:true}).unwrap();
            let scalar = graph.recipe(Recipe::Scalar(Literal::Number(17.0))).unwrap();
            let branch = graph.recipe(Recipe::ReaderMap(vec![(x,scalar)])).unwrap();
            let occurrence = graph.recipe(Recipe::ReaderMap(vec![(m,alias),(branch_key,branch)])).unwrap();
            let cloned = graph.recipe(Recipe::Metadata{shape:MetadataShape::Map{large:false},value:occurrence,metadata:alias,set_items:vec![]}).unwrap();
            let root = graph.recipe(Recipe::ReaderVector(vec![alias,cloned,cloned,occurrence])).unwrap();
            graph.materialize(root).unwrap()
        };
        session.collect().unwrap();
        let check = session.eval("(fn [v saved] (let [a (nth v 1) b (nth v 2) c (nth v 3)] [(identical? (nth v 0) saved) (identical? (:m a) saved) (identical? (:m b) saved) (identical? (:m c) saved) (identical? (meta a) saved) (identical? (meta b) saved) (not (identical? a b)) (not (identical? (:branch a) (:branch b))) (= (:x (:branch a)) 17) (= (:x (:branch b)) 17)]))").unwrap();
        let result = session.invoke(&check, &[&value,&saved]).unwrap();
        assert_eq!(crate::portable_repl::display(&mut session,&result).unwrap(),"[true true true true true true true true true true]");
    }
    #[test]
    fn reuse_cold_untainted_parent_preserves_special_constructor_callback() {
        let mut session = Session::new_macro().unwrap();
        session
            .eval("(def cold-route-calls 0) (def ^{:doc \"cold\"} cold-route-target 17)")
            .unwrap();
        let bridge = FormBridge::new(&mut session).unwrap();
        let snapshot = session.compilation_snapshot();
        let namespace = SourceNamespace::capture(&snapshot.environment, Phase::Macro);
        let (global, revision) = namespace
            .declarations
            .iter()
            .find(|(g, _)| g.name() == "cold-route-target")
            .unwrap();
        let error = session.eval("js/Error").unwrap();
        let descriptor = session.data_descriptor(&error, true).unwrap();
        let replacement=session.eval("(fn [meta first rest count hash] (do (set! cold-route-calls (+ cold-route-calls 1)) first))").unwrap();
        session
            .inspect(&descriptor, |mut store, value| {
                let descriptor = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                let cache = descriptor
                    .field(&mut store, 2)?
                    .unwrap_anyref()
                    .unwrap()
                    .as_array(&store)?
                    .unwrap();
                let original = error.rooted(&mut store);
                let mut changed = 0;
                for index in (1..cache.len(&store)?).step_by(2) {
                    if let Some(entry) = cache.get(&mut store, index)?.unwrap_anyref() {
                        if Rooted::<AnyRef>::ref_eq(&store, entry, &original)? {
                            let replacement = replacement.rooted(&mut store);
                            cache.set(&mut store, index, Val::AnyRef(Some(replacement)))?;
                            changed += 1;
                        }
                    }
                }
                assert_eq!(changed, 1);
                Ok(())
            })
            .unwrap();
        let list = session.eval("suss.core/List").unwrap();
        session
            .inspect(&list, |mut store, value| {
                let closure = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                let owner = closure
                    .field(&mut store, 0)?
                    .unwrap_anyref()
                    .unwrap()
                    .as_struct(&store)?
                    .unwrap();
                let fields = owner
                    .field(&mut store, 1)?
                    .unwrap_anyref()
                    .unwrap()
                    .as_array(&store)?
                    .unwrap();
                let descriptor = descriptor.rooted(&mut store);
                fields.set(&mut store, 0, Val::AnyRef(Some(descriptor)))
            })
            .unwrap();
        let mut values = DeclarationValues::default();
        let value = {
            let mut graph =
                AnalysisGraph::with_declaration_values(&bridge, &mut session, &mut values);
            graph.declaration(global, Some(revision), 0).unwrap();
            let scalar = graph
                .recipe(super::super::Recipe::Scalar(Literal::Number(17.0)))
                .unwrap();
            let root = graph
                .recipe(super::super::Recipe::List(vec![scalar]))
                .unwrap();
            assert!(!graph.metadata_sources.is_empty());
            graph.materialize(root).unwrap()
        };
        session
            .inspect(&value, |mut store, value| {
                assert_eq!(
                    value
                        .unwrap_anyref()
                        .unwrap()
                        .as_struct(&store)?
                        .unwrap()
                        .field(&mut store, 0)?
                        .unwrap_f64(),
                    17.0
                );
                Ok(())
            })
            .unwrap();
        let calls = session.eval("cold-route-calls").unwrap();
        assert_eq!(
            crate::portable_repl::display(&mut session, &calls).unwrap(),
            "1"
        );
        assert_eq!(values.metadata.len(), 0);
    }
}
