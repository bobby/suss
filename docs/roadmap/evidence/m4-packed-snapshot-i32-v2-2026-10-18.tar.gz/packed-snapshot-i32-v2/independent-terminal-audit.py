from pathlib import Path
import hashlib,json,re,subprocess
p=Path(__file__).parent;v1=p.parent/'packed-snapshot-i32-v1';base='aca5899c0fa5b875bd5441f7768ef564bd05eaa1';repo='/home/bobby/Work/code/bobby/suss';H=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((p/'receipt.json').read_text());assert r['terminal'] and r['current'] is None and r['base']==base
m=json.loads((p/'source-manifest.json').read_text());five=json.loads((p/'terminal-source-hashes.json').read_text())
for f,h in five.items():assert H((p/'terminal-source'/f).read_bytes())==h==m[f]
assert five['crates/suss-compile/src/portable_session/storage_snapshot.rs']==json.loads((p/'source-review.json').read_text())['source_sha256']
inputs=[f for f in m if (f.endswith(('.rs','.sus','.clj','.cljs','.cljc','.wat')) or Path(f).name in ('Cargo.toml','Cargo.lock','build.rs')) and f not in five]
cmd=['git','-C',repo,'cat-file','--batch'];o=subprocess.run(cmd,input=('\n'.join(base+':'+f for f in inputs)+'\n').encode(),capture_output=True,check=True).stdout
pos=0
for f in inputs:
 end=o.index(b'\n',pos);header=o[pos:end].split();assert header[1]==b'blob',(f,header);n=int(header[2]);b=o[end+1:end+1+n];pos=end+2+n;assert H(b)==m[f],f
stages=[];allnames=[];tot=[0,0,0];fails=[]
for st in r['stages']:
 assert not st['changed'];name=st['name'];text=(p/(name+'.log')).read_text()
 if name in ('bootstrap','identity'):assert st['exit']==0;continue
 sums=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert len(sums)==1,(name,sums)
 counts=list(map(int,sums[0]));starts=re.findall(r'^test (\S+) \.\.\.',text,re.M);assert len(starts)==sum(counts),(name,len(starts),counts)
 for i,n in enumerate(counts):tot[i]+=n
 allnames+=starts
 panics=[]
 for mm in re.finditer(r"thread '([^']+)'[^\n]*panicked at ([^\n]+)\n",text):
  snippet=text[mm.end():mm.end()+1600];panics.append({'test':mm.group(1),'location':mm.group(2),'fuel_in_error':bool(re.search(r'all fuel consumed|OutOfFuel',snippet))})
 assert len(panics)==counts[1],(name,counts,panics)
 for x in panics:assert x['fuel_in_error'];x['stage']=name
 fails+=panics;stages.append({'name':name,'counts':counts,'names':starts,'exit':st['exit'],'log_sha256':H((p/(name+'.log')).read_bytes())})
assert len(set(allnames))==len(allnames)==70 and tot==[57,13,0]
def child(file):return [x[x.index('source-child-fuel '):] for x in file.read_text().splitlines() if 'source-child-fuel ' in x]
a=child(v1/'parent-source-child.log');b=child(p/'source-child.log');assert len(a)==len(b)==220
norm=lambda xs:[re.sub(r'remaining=Some\(\d+\)','remaining=<fuel>',x) for x in xs]
assert norm(a)==norm(b)
final=lambda xs:[{'phase':re.search(r'source=(\w+)',x)[1],'remaining':int(re.search(r'remaining=Some\((\d+)\)',x)[1])} for x in xs if 'stage=final-validation result=Ok(())' in x]
fa,fb=final(a),final(b);assert [x['remaining'] for x in fa]==[870237]*2 and [x['remaining'] for x in fb]==[981572]*2
def constructors(file):
 runs=[];cur=None;pending={}
 for line in file.read_text().splitlines():
  z=re.search(r'coherent-stage stage=([\w-]+) boundary=(None|Some\(\d+\)).*remaining=Some\((\d+)\)',line)
  if not z:continue
  stage,b,n=z.groups();n=int(n)
  if stage=='entry':cur={'completed':[],'finalization':False};runs.append(cur);pending={}
  if cur is None:continue
  cur['last']=[stage,b,n]
  if stage=='construct-before':pending[b]=n
  if stage=='construct-after':cur['completed'].append({'boundary':b,'units':pending.pop(b)-n})
  if stage in ('finalize-before','export-before'):cur['finalization']=True
 return runs
before=constructors(v1/'control/callable.log');after=constructors(p/'callable.log');assert len(before)==len(after)==6
prefix=[]
for a,b in zip(before,after):
 assert len(a['completed'])==len(b['completed'])==51
 assert [x['boundary'] for x in a['completed']]==[x['boundary'] for x in b['completed']]
 old=sum(x['units'] for x in a['completed']);new=sum(x['units'] for x in b['completed']);assert not b['finalization']
 prefix.append({'matched_completed':51,'parent_units':old,'v2_units':new,'saved_units':old-new,'parent_last':a['last'],'v2_last':b['last']})
public=json.loads((p/'callable.json').read_text());assert len(public['phases'])==2
for phase in public['phases']:
 obs=phase['observations'];assert not obs['rows'] and len(obs['errors'])==3
 for error in obs['errors']:assert 'caller &env input transport' in error['error'] and 'all fuel consumed' in error['error']
parent_guards=(v1/'control/coherent-guards.log').read_text();parent_failed=set(re.findall(r"thread '([^']+)'[^\n]*panicked at",parent_guards));v2_failed={x['test'] for x in fails if x['stage']=='coherent-guards'};assert parent_failed==v2_failed
result={'verdict':'SOURCE_BOUND_V2_TERMINAL_EVIDENCE_VERIFIED_NO_ADOPTION_OR_READINESS_APPROVAL','base':base,'source_review':'source-review.json','terminal_five_verified':five,'frozen_manifest_entries':len(m),'nonchanged_compiler_and_oracle_inputs_git_bound_to_base':len(inputs),'stage_freezes':'Every recorded stage changed=[]; original driver hashes tracked files after bootstrap and every stage, not a prebootstrap five-output equality claim. Archived five payloads independently checked. No live author file used.','counts':{'unique':70,'pass':57,'fuel_fail':13,'ignored':0},'stages':stages,'failures':fails,'coherent_failed_names_equal_parent':True,'source_child':{'ordered_events_per_log':220,'labels_results_equal_parent':True,'parent_final':fa,'v2_final':fb,'whole_request_saved_units_each_phase':111335,'v1_more_units_each_phase':381353,'control_log_sha256':H((v1/'parent-source-child.log').read_bytes()),'v2_log_sha256':H((p/'source-child.log').read_bytes())},'constructor_prefix':prefix,'public':'Six caller&env fuel errors, zero decoded rows; still failed construction boundary26 before export/finalization. No identity verdict.','limits':['70 tests include six CI regression replays absent V1: all six still fail; V1 was64=57/7, V2 is70=57/13. This is not six new failures versus an executed V1 selection.','No whole callable cost or success established by completed51-prefix saving.','Six coherent candidate guard failures do not grant credit to later unexecuted assertions, including ORIGINAL control failures.','No V2 watched7/fused4/namespace/CLJS/map/fullbaseline/CI result supplied by this main cohort.','No adoption, push, readiness, promotion, merge or issue closure verdict. Source type proof remains separately approved.','Reviewed source snapshot is uncommitted delta on aca; archives bind bytes rather than inventing a tested commit.']}
(p/'terminal-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'source_bound_inputs':len(inputs),'sourcechild_saving':111335,'prefix_savings':[x['saved_units'] for x in prefix],'last':[x['v2_last'] for x in prefix],'receipt':str(p/'terminal-review.json')}))
