from pathlib import Path
import subprocess as s, os, json, hashlib, time, datetime
root=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');p=Path(__file__).parent
base=s.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();(p/'source.patch').write_bytes(s.check_output(['git','diff','--binary'],cwd=root))
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
cargo=['cargo','test','--locked'];tail=['--','--test-threads=1','--nocapture']
stages=[('bootstrap',['cargo','run','--profile','test','--locked','-p','suss-cli','--bin','suss-bootstrap','--','runtime/bootstrap'],{}),('identity',['python3','scripts/verify_bootstrap_identity.py'],{}),('integer-snapshots',cargo+['-p','suss-compile','--lib','i32_array_tests::']+tail,{}),('snapshot-preservation',cargo+['-p','suss-compile','--lib','storage_snapshot::tests::']+tail,{}),('regression-constructor',cargo+['-p','suss-cli','--test','compiled_macro_constructor_source_asts','constructor_operation_and_children_fit_default_fuel_in_both_caller_phases','--','--exact','--test-threads=1','--nocapture'],{'SUSS_METADATA_FUEL_TRACE':'1'}),('regression-control',cargo+['-p','suss-cli','--test','compiled_macro_control_source_asts','--','function_metadata_keeps_wrapper_and_inner_method_edges','function_name_asts_match_primary_identity_presence_and_shadow_after_gc','method_recurrence_flags_survive_gc_in_both_caller_phases','--test-threads=1','--nocapture'],{'SUSS_METADATA_FUEL_TRACE':'1'}),('regression-cross-invocation',cargo+['-p','suss-cli','--test','compiled_macro_cross_invocation_identity_probe','--','same_captured_declaration_metadata_across_distinct_macro_invocations','source_metadata_hash_maps_over_eight_entries_retain_identity_after_construction_warming','--test-threads=1','--nocapture'],{'SUSS_METADATA_FUEL_TRACE':'1'}),('constructor-preservation',cargo+['-p','suss-compile','--lib','constructor_inputs::tests::']+tail,{}),('prototype',cargo+['-p','suss-compile','--lib','--','prototype_origin::tests::','prototype_buffer_tests::','audit_prototype_uses_all_twelve_fields_and_survives_gc','--test-threads=1','--nocapture'],{}),('callable',cargo+['-p','suss-cli','--test','compiled_macro_namespace_identity','resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations','--','--exact','--test-threads=1','--nocapture'],{'SUSS_METADATA_FUEL_TRACE':'1','SUSS_NAMESPACE_IDENTITY_OUTPUT':str(p/'callable.json')}),('source-child',cargo+['-p','suss-compile','--lib','source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo']+tail,{'SUSS_SOURCE_CHILD_FUEL_TRACE':'1'}),('coherent-guards',cargo+['-p','suss-compile','--lib','--','source_roots::coherent::tests::','legacy_cache_retirement_is_atomic_and_not_sustained_by_its_own_native_references','--test-threads=1','--nocapture'],{})]
receipt={'base':base,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal':False,'stages':[],'current':None};freeze=None
files=s.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
def hashes():return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if (root/f).is_file()}
def save():(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name,cmd,extra in stages:
 if freeze is not None:assert hashes()==freeze
 receipt['current']=name;save();runenv=env.copy();runenv.update(extra);start=time.monotonic()
 with (p/(name+'.log')).open('w') as log:
  child=s.Popen(cmd,cwd=root,env=runenv,stdout=log,stderr=s.STDOUT);receipt['pid']=child.pid;save();code=child.wait()
 if name=='bootstrap':freeze=hashes();(p/'source-manifest.json').write_text(json.dumps(freeze,indent=2)+'\n')
 changed=[f for f,h in freeze.items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h]
 row={'name':name,'argv':cmd,'environment_overrides':extra,'exit':code,'seconds':round(time.monotonic()-start,3),'changed':changed};receipt['stages'].append(row);receipt['current']=None;save();print(json.dumps(row),flush=True)
 assert not changed
 if name in ['bootstrap','identity','integer-snapshots','snapshot-preservation','constructor-preservation','prototype','source-child'] and code:break
receipt['terminal']=True;receipt['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
