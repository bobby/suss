#!/usr/bin/env python3
"""Archive-only host replay. No Cargo, guest execution, network, or repository writes."""
from pathlib import Path
import json,re,hashlib
p=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest()
manifest={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (p/'MANIFEST.sha256').read_text().splitlines()}
for name,h in manifest.items():assert H((p/name).read_bytes())==h,name
v1=p/'packed-snapshot-i32-v1';v2=p/'packed-snapshot-i32-v2';review=json.loads((v2/'terminal-review.json').read_text())
for directory,expected in [(v1,(57,7,0)),(v2,(57,13,0))]:
 r=json.loads((directory/'receipt.json').read_text());assert r['terminal'] and r['current'] is None;names=[];tot=[0,0,0]
 for stage in r['stages']:
  assert not stage['changed']
  if stage['name'] in ('bootstrap','identity'):assert stage['exit']==0;continue
  text=(directory/(stage['name']+'.log')).read_text();summary=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert len(summary)==1
  counts=list(map(int,summary[0]));starts=re.findall(r'^test (\S+) \.\.\.',text,re.M);assert len(starts)==sum(counts);names.extend(starts)
  tot=[a+b for a,b in zip(tot,counts)]
 assert tuple(tot)==expected and len(set(names))==len(names)==sum(tot)
disp=json.loads((v1/'rejected-disposition.json').read_text())
for name,h in disp['five_source_bootstrap_files'].items():assert H((v1/'rejected-source'/name).read_bytes())==h
for name,h in json.loads((v2/'terminal-source-hashes.json').read_text()).items():assert H((v2/'terminal-source'/name).read_bytes())==h

def child(file):return [line[line.index('source-child-fuel '):] for line in file.read_text().splitlines() if 'source-child-fuel ' in line]
parent=child(v1/'parent-source-child.log')
for directory,remaining in [(v1,488884),(v2,981572)]:
 rows=child(directory/'source-child.log');assert len(rows)==len(parent)==220
 norm=lambda xs:[re.sub(r'remaining=Some\(\d+\)','remaining=<fuel>',line) for line in xs]
 assert norm(rows)==norm(parent)
 assert [int(re.search(r'remaining=Some\((\d+)\)',x)[1]) for x in rows if 'stage=final-validation result=Ok(())' in x]==[remaining]*2
assert [int(re.search(r'remaining=Some\((\d+)\)',x)[1]) for x in parent if 'stage=final-validation result=Ok(())' in x]==[870237]*2

def runs(file):
 out=[];current=None;pending={}
 for line in file.read_text().splitlines():
  m=re.search(r'coherent-stage stage=([\w-]+) boundary=(None|Some\(\d+\)).*remaining=Some\((\d+)\)',line)
  if not m:continue
  stage,b,n=m.groups();n=int(n)
  if stage=='entry':current=[];out.append(current);pending={}
  if current is None:continue
  if stage=='construct-before':pending[b]=n
  if stage=='construct-after':current.append((b,pending.pop(b)-n))
 return out
parent_runs=runs(v1/'control/callable.log');assert len(parent_runs)==6
savings=[]
for old,new in zip(parent_runs,runs(v2/'callable.log')):
 assert len(old)==len(new)==51 and [x[0] for x in old]==[x[0] for x in new]
 savings.append(sum(x[1] for x in old)-sum(x[1] for x in new))
assert savings==[x['saved_units'] for x in review['constructor_prefix']]
public=json.loads((v2/'callable.json').read_text());assert len(public['phases'])==2
for phase in public['phases']:
 o=phase['observations'];assert o['rows']==[] and len(o['errors'])==3
 for e in o['errors']:assert 'caller &env' in e['error'] and 'all fuel consumed' in e['error']
print(json.dumps({'manifest_payloads_verified':len(manifest),'V1_unique_results':[57,7,0],'V2_unique_results':[57,13,0],'ordered_sourcechild_events_each':220,'V1_EXTRA_whole_units_each_phase':381353,'V2_saved_whole_units_each_phase':111335,'V2_saved_completed51_prefix':savings,'public_errors':6,'public_rows':0,'no_tests_executed':True}))
