# Packed integer storage snapshots: V1 rejection and V2 bounded evidence

This is a cache-prepared report for a partial Draft #271 publication, not an adoption, readiness, issue-closure or performance-generalization verdict. Source base is `aca5899c0fa5b875bd5441f7768ef564bd05eaa1`. V2 ran as an uncommitted delta and is now bound byte-for-byte to source commit `ae50d2fddf1f3f817a05780cb06b3e1a60eb959e` (five changed source/BOOT files), source SHA256 `a3d2e23fc3d3a5d6bc2c619723e2da40cdf9da183263aef646f1d19d2be05c65`. committed-source-binding.json records the five exact Git blob hashes; reproduce-bootstrap.log and reproduce-identity.log retain the later normal regeneration and identity verification. No guest retest is inferred, and the later delegate regression/diagnostic is excluded. This Git-dependent packet is not a standalone repository/source archive.

The private snapshot representation stores intrinsically I8/I16/I32 array payloads as `Vec<i32>` instead of `Vec<Atom>`. Integer payload backing is four bytes per element instead of the observed 48-byte Atom; this is not a 48→4 claim for complete nodes or snapshots. Reference and other numeric array payloads keep generic atoms. Actual allocation/retirement sizes and extra capture, extraction, selection and cleanup controls remain charged. No guest representation, quota, numeric rate, source authority or cache policy changes.

## Commands and exact outcomes

V1 and V2 use normal bootstrap, then identity verification, jobs1/Rayon1/test-threads1. No RUSTFLAGS assignment. Full argv, per-stage environment overrides, wall durations, return codes and freezes are preserved in each run.py/receipt.json. The source-derived test names below are recorded from actual libtest starts; all 70 V2 tests executed, none ignored or silently skipped. Bootstrap and identity are separate successful host stages, not Rust test passes.

Normal bootstrap and identity commands:
```sh
CARGO_TARGET_DIR=/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target CARGO_BUILD_JOBS=1 RAYON_NUM_THREADS=1 cargo run --profile test --locked -p suss-cli --bin suss-bootstrap -- runtime/bootstrap
CARGO_TARGET_DIR=/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target python3 scripts/verify_bootstrap_identity.py
```

| V2 stage | PASS | fuel FAIL | ignored |
|---|---:|---:|---:|
| integer-snapshots | 4 | 0 | 0 |
| snapshot-preservation | 21 | 0 | 0 |
| regression-constructor | 0 | 1 | 0 |
| regression-control | 0 | 3 | 0 |
| regression-cross-invocation | 0 | 2 | 0 |
| constructor-preservation | 11 | 0 | 0 |
| prototype | 8 | 0 | 0 |
| callable | 0 | 1 | 0 |
| source-child | 1 | 0 | 0 |
| coherent-guards | 12 | 6 | 0 |
| **Total distinct** | **57** | **13** | **0** |

V1 ran **64 distinct: 57 PASS, 7 fuel FAIL, 0 ignored**. Its initial compile-only test API errors are retained in compile-initial.log; no runtime tests ran in that failed compile attempt. V2 also executed six previously unexecuted CI regression witnesses, all fuel failures. Thus the 64→70 denominator difference is six additional executions, not six new failures demonstrated against an executed V1 selection. V2 compile-only PASS is separate from these counts.

Exact V2 test commands (stage-specific trace variables are in receipt.json):
```sh
cargo test --locked -p suss-compile --lib i32_array_tests:: -- --test-threads=1 --nocapture
cargo test --locked -p suss-compile --lib storage_snapshot::tests:: -- --test-threads=1 --nocapture
cargo test --locked -p suss-cli --test compiled_macro_constructor_source_asts constructor_operation_and_children_fit_default_fuel_in_both_caller_phases -- --exact --test-threads=1 --nocapture
cargo test --locked -p suss-cli --test compiled_macro_control_source_asts -- function_metadata_keeps_wrapper_and_inner_method_edges function_name_asts_match_primary_identity_presence_and_shadow_after_gc method_recurrence_flags_survive_gc_in_both_caller_phases --test-threads=1 --nocapture
cargo test --locked -p suss-cli --test compiled_macro_cross_invocation_identity_probe -- same_captured_declaration_metadata_across_distinct_macro_invocations source_metadata_hash_maps_over_eight_entries_retain_identity_after_construction_warming --test-threads=1 --nocapture
cargo test --locked -p suss-compile --lib constructor_inputs::tests:: -- --test-threads=1 --nocapture
cargo test --locked -p suss-compile --lib -- prototype_origin::tests:: prototype_buffer_tests:: audit_prototype_uses_all_twelve_fields_and_survives_gc --test-threads=1 --nocapture
cargo test --locked -p suss-cli --test compiled_macro_namespace_identity resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations -- --exact --test-threads=1 --nocapture
cargo test --locked -p suss-compile --lib source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo -- --test-threads=1 --nocapture
cargo test --locked -p suss-compile --lib -- source_roots::coherent::tests:: legacy_cache_retirement_is_atomic_and_not_sustained_by_its_own_native_references --test-threads=1 --nocapture
```

## Measured controls, including adverse evidence

- Fresh actual aca SourceChild parent: both complete original 10M outer requests end at 870,237 remaining. V1 ends at 488,884: **381,353 more units spent per phase**, despite smaller integer buffers. V1 remains rejected for adoption; its exact five source/BOOT payloads and all raw failures are preserved.
- V2 ends at **981,572 remaining in each phase**, saving **111,335 units per complete outer request versus aca**. The parser independently matches all **220 ordered labels/results** against the parent, including both source phases, five variants and physical/memo tails. Only fuel numbers change.
- V1 six matched ordered 51-constructor prefixes spend **94,724–101,404 more units** than the prior compiled-equivalent parent. V2 six matched ordered 51-constructor prefixes spend **207,410–213,836 fewer units** than that parent, including retained new fees. These are sums of completed construction intervals, not whole public-request costs.
- All six V2 public requests still fail construction boundary26 before export/finalization: caller-&env fuel errors and **zero decoded public rows**. The independent callable control is the historical fused run, source-bound through compiled-input equality; no new aca callable control was executed.
- All six coherent guard failures match the parent failed names. Four fail initial build/materialization; two fail the ORIGINAL reader-control route before reaching coherent/callback comparisons. Their later assertions remain unexecuted. These are candidate-added guards, not inherited passing-base acceptance results.

## All V2 failures

- `constructor_operation_and_children_fit_default_fuel_in_both_caller_phases` — regression-constructor; fuel error at `crates/suss-cli/tests/compiled_macro_constructor_source_asts.rs:191:11:`.
- `function_metadata_keeps_wrapper_and_inner_method_edges` — regression-control; fuel error at `crates/suss-cli/tests/compiled_macro_control_source_asts.rs:251:14:`.
- `function_name_asts_match_primary_identity_presence_and_shadow_after_gc` — regression-control; fuel error at `crates/suss-cli/tests/compiled_macro_control_source_asts.rs:453:70:`.
- `method_recurrence_flags_survive_gc_in_both_caller_phases` — regression-control; fuel error at `crates/suss-cli/tests/compiled_macro_control_source_asts.rs:368:72:`.
- `same_captured_declaration_metadata_across_distinct_macro_invocations` — regression-cross-invocation; fuel error at `crates/suss-cli/tests/compiled_macro_cross_invocation_identity_probe.rs:36:14:`.
- `source_metadata_hash_maps_over_eight_entries_retain_identity_after_construction_warming` — regression-cross-invocation; fuel error at `crates/suss-cli/tests/compiled_macro_cross_invocation_identity_probe.rs:128:72:`.
- `resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations` — callable; fuel error at `crates/suss-cli/tests/compiled_macro_namespace_identity.rs:195:5:`.
- `portable_macro_graph::source_roots::coherent::tests::coherent_current_child_owner_ordinals_reject_equal_reference_swaps_missing_and_extra` — coherent-guards; fuel error at `crates/suss-compile/src/portable_macro_graph/source_roots/coherent_tests.rs:595:67:`.
- `portable_macro_graph::source_roots::coherent::tests::coherent_entrypoint_retains_raw_and_params_but_keeps_resolved_outer_fresh_after_gc` — coherent-guards; fuel error at `crates/suss-compile/src/portable_macro_graph/source_roots/coherent_tests.rs:80:33:`.
- `portable_macro_graph::source_roots::coherent::tests::coherent_later_reader_callback_rebinds_poisoned_old_raw_params_without_repair_or_replay` — coherent-guards; fuel error at `crates/suss-compile/src/portable_macro_graph/source_roots/coherent_tests.rs:148:72:`.
- `portable_macro_graph::source_roots::coherent::tests::coherent_native_alias_requires_exact_certified_child_not_equal_content_root` — coherent-guards; fuel error at `crates/suss-compile/src/portable_macro_graph/source_roots/coherent_tests.rs:372:59:`.
- `portable_macro_graph::source_roots::coherent::tests::coherent_reader_before_every_source_alias_preserves_original_effect_order` — coherent-guards; fuel error at `crates/suss-compile/src/portable_macro_graph/source_roots/coherent_tests.rs:1450:56:`.
- `portable_macro_graph::source_roots::coherent::tests::coherent_repeated_locals_views_preserve_reader_hash_effect_order_against_original_route` — coherent-guards; fuel error at `crates/suss-compile/src/portable_macro_graph/source_roots/coherent_tests.rs:1332:56:`.

## Identity/type proof and regression coverage

Locked primary source is **Wasmtime49.0.1**, not49.0.3. Full relevant registry files, hashes and upstream LICENSE are in primary/. `ArrayRef::get` zero-extends packed I8/I16 storage into Val::I32; capture retains those actual values, with no endian reinterpretation. The private node retains the exact original live GC object; its intrinsic heap type cannot change during its lifetime or across GC, even if a temporary Module/type wrapper is dropped. Incoming root/Node atoms still require rooted ref_eq. Mutable elements, nominal descriptors, source/class/prototype authority and memo contents are not assumed immutable.
Capture still queries declared type and prepays eight classification controls. V2 removes only the repeated matching element_type inspection/branch and its eight-unit fee. Matching retains fallible as_array and ty, current length, every I32 read/strict comparison, identical mismatch-hook order/index/value/error, and node/element fuel/IRQ polls. No type ID, epoch or native cache serves as authority.
Four new tests cover both minimal Session phases; packed high-bit I8/I16, negative I32, empty/immutable arrays, GC and per-slot mutation/restore; equal-content different-root rejection; independent old-generic-Atom fresh-read control; mismatch-hook true/false/error ordering and actual values; generic reference-array fallback, cut/root membership, I32 vs i31 and foreign-owner distinctions. Small three-element capture/check tests sweep every host fuel allowance and every Meter cancellation charge for all three integer storage kinds, retry and rooted-handle cleanup.
The generic Atom fixture is an unmetered correctness oracle, **not** an old/new allocation-cost benchmark. Cuts are not exhaustive for mismatch hooks, retirement, publication or a real watched enrollment interval. Existing snapshot21, constructor11 and prototype8 suites pass; this does not make later failed public/guard assertions execute.

## Source, replay and remaining unknowns

Each driver freezes tracked inputs after normal bootstrap and checks them after each stage; all changed lists are empty. This is not an independent prebootstrap equality claim or capture of every ignored/untracked file. The packet retains both postbootstrap manifests; V2 has 3680 tracked file hashes, 1649 unchanged compiler/oracle inputs independently checked against aca, and five exact archived changed source/BOOT payloads. No active author source is read to assemble this packet.
source-binding.json names explicit Git commit:path dependencies. Historical control source bindings and receipts are retained separately. `replay.py` checks every manifest digest, raw test counts, unique selections, source/BOOT hashes, 220 SourceChild events and six matched constructor prefixes without running guest tests. It uses only Python standard library and archived files. The original independent audit is retained as a historical script with original workstation/Git paths.
V2 watched7/fused4, the namespace probe, CLJS/map preservation, full baseline and final-head CI are **unexecuted in this cohort**. V1 corresponding unexecuted gates remain unexecuted. No oracle, CI or whole-operation claim is borrowed from another tuple. No general performance win follows: V1 is an explicit counterexample, V2 has two measured scopes and thirteen visible fuel failures. Any publication must remove transient diagnostics, bind exact candidate source, regenerate/verify bootstrap if source changes, and preserve tests actually executed under each tuple. This report does not grant a push, promotion, merge, adoption or issue-closure verdict.

## Executed V2 test-name inventory

### integer-snapshots

- `portable_session::storage_snapshot::i32_array_tests::i32_snapshot_all_fuel_and_irq_cuts_release_roots_and_retry`
- `portable_session::storage_snapshot::i32_array_tests::i32_snapshot_mismatch_hooks_keep_order_value_error_and_root_guard`
- `portable_session::storage_snapshot::i32_array_tests::i32_snapshot_packed_bits_empty_immutable_gc_and_replacement_match_generic_control`
- `portable_session::storage_snapshot::i32_array_tests::i32_snapshot_reference_arrays_keep_atoms_cuts_and_membership_distinctions`

### snapshot-preservation

- `portable_session::storage_snapshot::tests::adaptive_indexes_boundary_cycles_duplicates_and_wide_collisions_match_bfs`
- `portable_session::storage_snapshot::tests::adaptive_node_and_cut_promotion_irq_is_atomic_and_recovers`
- `portable_session::storage_snapshot::tests::borrowed_cut_boundaries_fuel_irq_unused_foreign_and_root_rejection_recover`
- `portable_session::storage_snapshot::tests::borrowed_cuts_keep_snapshot_handle_accounting_and_owned_leaves_after_inputs_drop`
- `portable_session::storage_snapshot::tests::native_cut_storage_forced_collision_cuts_do_not_hide_other_nodes_or_aliases`
- `portable_session::storage_snapshot::tests::native_cut_storage_fuel_irq_owner_and_failed_capture_cleanup`
- `portable_session::storage_snapshot::tests::native_cut_storage_opaque_identity_mutability_membership_and_own_spine`
- `portable_session::storage_snapshot::tests::native_cut_storage_slot_hook_is_exact_and_never_exempts_root_or_struct`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_checks_actual_owned_source_array_backing`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_compares_functions_not_only_their_signatures`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_covers_schema_and_reports_live_protocol_changes`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_follows_deep_graphs_iteratively`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_hash_collisions_preserve_distinct_nodes`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_mid_capture_and_check_interrupts_are_atomic`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_owned_nodes_survive_external_type_and_module_drop`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_owner_check_precedes_any_foreign_root_access`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_preserves_aliases_cycles_and_gc_identity`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_preserves_float_bits_and_all_scalar_variants`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_rejects_opaque_payload_without_leaking_roots`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_reports_uid_warming_without_repairing_it`
- `portable_session::storage_snapshot::tests::native_storage_snapshot_uses_fuel_for_capture_and_check_then_recovers`

### regression-constructor

- `constructor_operation_and_children_fit_default_fuel_in_both_caller_phases`

### regression-control

- `function_metadata_keeps_wrapper_and_inner_method_edges`
- `function_name_asts_match_primary_identity_presence_and_shadow_after_gc`
- `method_recurrence_flags_survive_gc_in_both_caller_phases`

### regression-cross-invocation

- `same_captured_declaration_metadata_across_distinct_macro_invocations`
- `source_metadata_hash_maps_over_eight_entries_retain_identity_after_construction_warming`

### constructor-preservation

- `portable_session::constructor_inputs::tests::checked_schema_cache_actual_constructor_stage_failures_do_not_publish`
- `portable_session::constructor_inputs::tests::checked_schema_cache_fuel_irq_staging_rollback_and_retry`
- `portable_session::constructor_inputs::tests::checked_schema_cache_retirement_failure_preserves_last_and_shared_owners_then_retries`
- `portable_session::constructor_inputs::tests::checked_schema_cache_seventeen_roots_evict_without_rejecting_and_reset_is_foreign`
- `portable_session::constructor_inputs::tests::checked_schema_cache_strict_hits_deep_mutation_distinct_roots_and_gc`
- `portable_session::constructor_inputs::tests::checked_schema_private_roots_preserve_external_stats_failures_and_fact_lifetimes`
- `portable_session::constructor_inputs::tests::constructor_inputs_bind_receiver_and_preconstruction_fields_after_gc`
- `portable_session::constructor_inputs::tests::constructor_inputs_decline_special_identity_and_preserve_shared_budget`
- `portable_session::constructor_inputs::tests::constructor_inputs_follow_padding_extras_duplicate_names_and_live_schema`
- `portable_session::constructor_inputs::tests::constructor_inputs_reject_properties_and_uid_changes_without_field_changes`
- `portable_session::constructor_inputs::tests::private_constructor_route_rejects_actual_guest_argument_escape`

### prototype

- `portable_session::prototype_origin::certification_audit_tests::audit_prototype_uses_all_twelve_fields_and_survives_gc`
- `portable_session::prototype_origin::prototype_buffer_tests::prototype_buffer_all_charge_boundaries_irq_retry_and_scoped_roots`
- `portable_session::prototype_origin::prototype_buffer_tests::prototype_buffer_late_null_precedes_early_reference_mismatch`
- `portable_session::prototype_origin::prototype_buffer_tests::prototype_buffer_real_origins_survive_gc_and_reject_mutated_key`
- `portable_session::prototype_origin::tests::prototype_origin_binds_creator_descriptor_before_restore_and_generic_writes_do_not_mint`
- `portable_session::prototype_origin::tests::prototype_origin_fuel_failures_recover_without_eager_getter_or_reconfiguration`
- `portable_session::prototype_origin::tests::prototype_origin_is_default_off_and_custom_direct_facts_remain_usable`
- `portable_session::prototype_origin::tests::prototype_origin_lazy_creation_and_copied_query_survive_gc_without_mint_export`

### callable

- `resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations`

### source-child

- `portable_macro_graph::source_roots::tests::source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo`

### coherent-guards

- `portable_macro_graph::reuse::retirement_tests::legacy_cache_retirement_is_atomic_and_not_sustained_by_its_own_native_references`
- `portable_macro_graph::source_roots::coherent::tests::coherent_changed_initial_class_authority_declines_before_any_construction_callback`
- `portable_macro_graph::source_roots::coherent::tests::coherent_current_child_owner_ordinals_reject_equal_reference_swaps_missing_and_extra`
- `portable_macro_graph::source_roots::coherent::tests::coherent_entrypoint_retains_raw_and_params_but_keeps_resolved_outer_fresh_after_gc`
- `portable_macro_graph::source_roots::coherent::tests::coherent_fuel_and_irq_failures_publish_no_partial_cache_then_retry`
- `portable_macro_graph::source_roots::coherent::tests::coherent_genuine_revision_distinguishes_equal_source_and_rejects_foreign_and_reset_handles`
- `portable_macro_graph::source_roots::coherent::tests::coherent_later_callback_poisoned_fresh_authority_aborts_without_partial_publication`
- `portable_macro_graph::source_roots::coherent::tests::coherent_later_reader_callback_rebinds_poisoned_old_raw_params_without_repair_or_replay`
- `portable_macro_graph::source_roots::coherent::tests::coherent_legacy_metadata_cache_snapshots_do_not_pin_native_revision_or_initializer_graph`
- `portable_macro_graph::source_roots::coherent::tests::coherent_locals_conflicting_nodes_and_reader_occurrences_still_decline_whole_plan`
- `portable_macro_graph::source_roots::coherent::tests::coherent_locals_repeated_owner_requires_exact_native_map_and_preserves_outer_context`
- `portable_macro_graph::source_roots::coherent::tests::coherent_native_alias_requires_exact_certified_child_not_equal_content_root`
- `portable_macro_graph::source_roots::coherent::tests::coherent_obsolete_revisions_retire_despite_cached_aliases_but_live_snapshots_survive`
- `portable_macro_graph::source_roots::coherent::tests::coherent_publication_preparation_is_atomic_at_every_fuel_irq_cut`
- `portable_macro_graph::source_roots::coherent::tests::coherent_reader_before_every_source_alias_preserves_original_effect_order`
- `portable_macro_graph::source_roots::coherent::tests::coherent_repeated_locals_views_preserve_reader_hash_effect_order_against_original_route`
- `portable_macro_graph::source_roots::coherent::tests::coherent_stack_population_prepays_every_fuel_irq_cut_with_reused_capacity`
- `portable_macro_graph::source_roots::coherent::tests::coherent_symbol_key_witnesses_cover_real_locals_defs_without_relaxing_duplicates_or_metadata`

