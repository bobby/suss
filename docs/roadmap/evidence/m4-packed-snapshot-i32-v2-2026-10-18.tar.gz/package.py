#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import hashlib,json,shutil,subprocess,gzip,tarfile,io,shlex
C=Path(__file__).resolve().parent.parent;P=Path(__file__).resolve().parent;D=P/'payload';D.mkdir(exist_ok=True)
H=lambda b:hashlib.sha256(b).hexdigest();source_commit=subprocess.check_output(['git','rev-parse','ae50d2f'],text=True).strip();base='aca5899c0fa5b875bd5441f7768ef564bd05eaa1'
def put(rel,b):
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def copy(src,rel):put(rel,src.read_bytes())
def js(rel,x):put(rel,(json.dumps(x,indent=2)+'\n').encode())
a=C/'packed-snapshot-i32-v1';b=C/'packed-snapshot-i32-v2';f=C/'fused-constructor-origin-v1'
for directory in [a,b]:
 receipt=json.loads((directory/'receipt.json').read_text());assert receipt['terminal'] and receipt['current'] is None
 assert all(not st['changed'] for st in receipt['stages'])
 for src in sorted(directory.rglob('*')):
  if src.is_file():copy(src,directory.name+'/'+str(src.relative_to(directory)))
# Separate, minimal previous-source provenance for byte-identical callable controls.
for n in ['receipt.json','source-head.json','merge-binding.json','final-head-review.json','terminal-review.json']:
 copy(f/n,'parent-fused-control/'+n)
for n in ['callable.log','callable.json','coherent-guards.log','namespace.json']:
 assert (a/'control'/n).read_bytes()==(f/n).read_bytes()
# Locked primary sources with upstream license, copied as evidence, never linked into product.
registry=Path('/home/bobby/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasmtime-49.0.1')
primary=['src/runtime/gc/enabled/arrayref.rs','src/runtime/gc/enabled/structref.rs','src/runtime/store/gc.rs','src/runtime/module/registry.rs','LICENSE','Cargo.toml']
for n in primary:copy(registry/n,'primary/wasmtime-49.0.1/'+n)
proof={'locked_version':'49.0.1','sources':{n:H((registry/n).read_bytes()) for n in primary},'contracts':[
 {'source':primary[0],'lines':'941-959','fact':'ArrayRef::get zero-extends packed I8/I16 elements into Val::I32; typed storage keeps the actual returned I32 bits.'},
 {'source':primary[0],'lines':'760-780','fact':'ArrayRef::ty returns the actual GC object type from the Store; intrinsic element storage is fixed for the same live object.'},
 {'source':primary[0],'lines':'70-85','fact':'Host GC allocation registers the shared type in the Store.'},
 {'source':primary[2],'lines':'880-895','fact':'Store retains the RegisteredType for host-allocated live GC objects; keeping the owned object preserves its intrinsic type across temporary type/module handle drops.'}],
 'binding':'Private capture selects I32Array only from actual I8/I16/I32 declared storage. Each snapshot node owns the original GC object. Root/Node incoming atoms compare exact rooted identity. V2 does not substitute a descriptor, ordinal, type ID, shape, epoch, or cached validation result for identity.',
 'preserved':'Fresh fallible as_array/ty and length query, every ascending element read/strict I32 comparison, mismatch-hook array/index/Val/order/errors, source/class/prototype/descriptor/Watch/domain checks and node/element polls remain.',
 'change':'Only repeated match-side element_type classification and its associated eight-unit fee are removed. Capture classification and eight-unit fee remain. No rate change.'}
js('primary/type-proof.json',proof)
# Verify only immutable committed objects, never active author source.
repo='/home/bobby/Work/code/bobby/suss'
five_expected=json.loads((b/'terminal-source-hashes.json').read_text())
changed=subprocess.check_output(['git','-C',repo,'diff-tree','--no-commit-id','--name-only','-r',source_commit],text=True).splitlines()
assert sorted(changed)==sorted(five_expected)
for name,h in five_expected.items():
 assert H(subprocess.check_output(['git','-C',repo,'show',source_commit+':'+name]))==h
js('committed-source-binding.json',{'source_commit':source_commit,'parent':subprocess.check_output(['git','-C',repo,'rev-parse',source_commit+'^'],text=True).strip(),'exact_five_terminal_images_equal_committed_blobs':five_expected,'reproduction_logs':['packed-snapshot-i32-v2/reproduce-bootstrap.log','packed-snapshot-i32-v2/reproduce-identity.log'],'qualification':'Run occurred as uncommitted delta; later source commit binds identical five images. No new guest test run inferred from reproduction. Later delegate test/diagnostic edits are excluded.'})
# Source closure references are explicit Git dependencies; this is not a standalone all-source archive.
manifest=json.loads((b/'source-manifest.json').read_text());five=json.loads((b/'terminal-source-hashes.json').read_text())
for n,h in five.items():assert H((b/'terminal-source'/n).read_bytes())==h==manifest[n]
selected={n:h for n,h in manifest.items() if (n.endswith(('.rs','.sus','.clj','.cljs','.cljc','.wat')) or Path(n).name in ('Cargo.toml','Cargo.lock','build.rs')) and n not in five}
js('source-binding.json',{'base':base,'v2_source_commit':source_commit,'commit_binding':'committed-source-binding.json verifies exact five archived terminal source/BOOT images. Runtime run preceded source commit; later delegate test/diagnostic edits excluded.',
 'full_tracked_freeze_count':len(manifest),'independently_git_checked_compiler_oracle_input_count':len(selected),'unchanged_git_inputs':{n:{'git':base+':'+n,'sha256':h} for n,h in selected.items()},'v2_source_bootstrap':{n:{'payload':'packed-snapshot-i32-v2/terminal-source/'+n,'sha256':h} for n,h in five.items()},
 'v1':'Rejected uncommitted variant on the same base; exact five payloads and hashes in rejected-source/ and rejected-disposition.json. Initial source.patch can include inherited prior bootstrap; terminal-source.patch/rejected-source.patch and snapshot payloads identify final variants.',
 'parent_callable':'Copied control bytes exactly equal fused-constructor-origin-v1 historical run at 9dcc4b0. Its source-head/merge-binding plus Git docs-only differences establish compiled-input equivalence to aca; not a fresh separate callable run at aca.',
 'parent_sourcechild':'Fresh actual aca run: packed-snapshot-i32-v1/parent-receipt.json + parent-inputs.json + parent-source-child.log.'})
review=json.loads((b/'terminal-review.json').read_text());r=json.loads((b/'receipt.json').read_text())
lines=['# Packed integer storage snapshots: V1 rejection and V2 bounded evidence','',
 'This is a cache-prepared report for a partial Draft #271 publication, not an adoption, readiness, issue-closure or performance-generalization verdict. Source base is `'+base+'`. V2 ran as an uncommitted delta and is now bound byte-for-byte to source commit `'+source_commit+'` (five changed source/BOOT files), source SHA256 `'+five['crates/suss-compile/src/portable_session/storage_snapshot.rs']+'`. committed-source-binding.json records the five exact Git blob hashes; reproduce-bootstrap.log and reproduce-identity.log retain the later normal regeneration and identity verification. No guest retest is inferred, and the later delegate regression/diagnostic is excluded. This Git-dependent packet is not a standalone repository/source archive.','',
 'The private snapshot representation stores intrinsically I8/I16/I32 array payloads as `Vec<i32>` instead of `Vec<Atom>`. Integer payload backing is four bytes per element instead of the observed 48-byte Atom; this is not a 48→4 claim for complete nodes or snapshots. Reference and other numeric array payloads keep generic atoms. Actual allocation/retirement sizes and extra capture, extraction, selection and cleanup controls remain charged. No guest representation, quota, numeric rate, source authority or cache policy changes.','',
 '## Commands and exact outcomes','',
 'V1 and V2 use normal bootstrap, then identity verification, jobs1/Rayon1/test-threads1. No RUSTFLAGS assignment. Full argv, per-stage environment overrides, wall durations, return codes and freezes are preserved in each run.py/receipt.json. The source-derived test names below are recorded from actual libtest starts; all 70 V2 tests executed, none ignored or silently skipped. Bootstrap and identity are separate successful host stages, not Rust test passes.','',
 'Normal bootstrap and identity commands:','```sh',
 'CARGO_TARGET_DIR=/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target CARGO_BUILD_JOBS=1 RAYON_NUM_THREADS=1 cargo run --profile test --locked -p suss-cli --bin suss-bootstrap -- runtime/bootstrap',
 'CARGO_TARGET_DIR=/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target python3 scripts/verify_bootstrap_identity.py','```','',
 '| V2 stage | PASS | fuel FAIL | ignored |','|---|---:|---:|---:|']
for s in review['stages']:lines.append('| '+s['name']+' | '+' | '.join(map(str,s['counts']))+' |')
lines+=['| **Total distinct** | **57** | **13** | **0** |','',
 'V1 ran **64 distinct: 57 PASS, 7 fuel FAIL, 0 ignored**. Its initial compile-only test API errors are retained in compile-initial.log; no runtime tests ran in that failed compile attempt. V2 also executed six previously unexecuted CI regression witnesses, all fuel failures. Thus the 64→70 denominator difference is six additional executions, not six new failures demonstrated against an executed V1 selection. V2 compile-only PASS is separate from these counts.','',
 'Exact V2 test commands (stage-specific trace variables are in receipt.json):','```sh']
for s in r['stages']:
 if s['name'] not in ('bootstrap','identity'):lines.append(shlex.join(s['argv']))
lines+=['```','','## Measured controls, including adverse evidence','',
 '- Fresh actual aca SourceChild parent: both complete original 10M outer requests end at 870,237 remaining. V1 ends at 488,884: **381,353 more units spent per phase**, despite smaller integer buffers. V1 remains rejected for adoption; its exact five source/BOOT payloads and all raw failures are preserved.',
 '- V2 ends at **981,572 remaining in each phase**, saving **111,335 units per complete outer request versus aca**. The parser independently matches all **220 ordered labels/results** against the parent, including both source phases, five variants and physical/memo tails. Only fuel numbers change.',
 '- V1 six matched ordered 51-constructor prefixes spend **94,724–101,404 more units** than the prior compiled-equivalent parent. V2 six matched ordered 51-constructor prefixes spend **207,410–213,836 fewer units** than that parent, including retained new fees. These are sums of completed construction intervals, not whole public-request costs.',
 '- All six V2 public requests still fail construction boundary26 before export/finalization: caller-&env fuel errors and **zero decoded public rows**. The independent callable control is the historical fused run, source-bound through compiled-input equality; no new aca callable control was executed.',
 '- All six coherent guard failures match the parent failed names. Four fail initial build/materialization; two fail the ORIGINAL reader-control route before reaching coherent/callback comparisons. Their later assertions remain unexecuted. These are candidate-added guards, not inherited passing-base acceptance results.','',
 '## All V2 failures','']
for x in review['failures']:lines.append('- `'+x['test']+'` — '+x['stage']+'; fuel error at `'+x['location']+'`.')
lines+=['','## Identity/type proof and regression coverage','',
 'Locked primary source is **Wasmtime49.0.1**, not49.0.3. Full relevant registry files, hashes and upstream LICENSE are in primary/. `ArrayRef::get` zero-extends packed I8/I16 storage into Val::I32; capture retains those actual values, with no endian reinterpretation. The private node retains the exact original live GC object; its intrinsic heap type cannot change during its lifetime or across GC, even if a temporary Module/type wrapper is dropped. Incoming root/Node atoms still require rooted ref_eq. Mutable elements, nominal descriptors, source/class/prototype authority and memo contents are not assumed immutable.',
 'Capture still queries declared type and prepays eight classification controls. V2 removes only the repeated matching element_type inspection/branch and its eight-unit fee. Matching retains fallible as_array and ty, current length, every I32 read/strict comparison, identical mismatch-hook order/index/value/error, and node/element fuel/IRQ polls. No type ID, epoch or native cache serves as authority.',
 'Four new tests cover both minimal Session phases; packed high-bit I8/I16, negative I32, empty/immutable arrays, GC and per-slot mutation/restore; equal-content different-root rejection; independent old-generic-Atom fresh-read control; mismatch-hook true/false/error ordering and actual values; generic reference-array fallback, cut/root membership, I32 vs i31 and foreign-owner distinctions. Small three-element capture/check tests sweep every host fuel allowance and every Meter cancellation charge for all three integer storage kinds, retry and rooted-handle cleanup.',
 'The generic Atom fixture is an unmetered correctness oracle, **not** an old/new allocation-cost benchmark. Cuts are not exhaustive for mismatch hooks, retirement, publication or a real watched enrollment interval. Existing snapshot21, constructor11 and prototype8 suites pass; this does not make later failed public/guard assertions execute.','',
 '## Source, replay and remaining unknowns','',
 'Each driver freezes tracked inputs after normal bootstrap and checks them after each stage; all changed lists are empty. This is not an independent prebootstrap equality claim or capture of every ignored/untracked file. The packet retains both postbootstrap manifests; V2 has '+str(len(manifest))+' tracked file hashes, '+str(len(selected))+' unchanged compiler/oracle inputs independently checked against aca, and five exact archived changed source/BOOT payloads. No active author source is read to assemble this packet.',
 'source-binding.json names explicit Git commit:path dependencies. Historical control source bindings and receipts are retained separately. `replay.py` checks every manifest digest, raw test counts, unique selections, source/BOOT hashes, 220 SourceChild events and six matched constructor prefixes without running guest tests. It uses only Python standard library and archived files. The original independent audit is retained as a historical script with original workstation/Git paths.',
 'V2 watched7/fused4, the namespace probe, CLJS/map preservation, full baseline and final-head CI are **unexecuted in this cohort**. V1 corresponding unexecuted gates remain unexecuted. No oracle, CI or whole-operation claim is borrowed from another tuple. No general performance win follows: V1 is an explicit counterexample, V2 has two measured scopes and thirteen visible fuel failures. Any publication must remove transient diagnostics, bind exact candidate source, regenerate/verify bootstrap if source changes, and preserve tests actually executed under each tuple. This report does not grant a push, promotion, merge, adoption or issue-closure verdict.','',
 '## Executed V2 test-name inventory','']
for s in review['stages']:
 lines+=['### '+s['name'],'']+['- `'+n+'`' for n in s['names']]+['']
put('REPORT.md',('\n'.join(lines)+'\n').encode());copy(P/'package.py','package.py');copy(P/'replay.py','replay.py')
# Source snapshots/patch reconstruction is intentionally from captured bytes, never live worktree.
manifest_lines=[]
for src in sorted(D.rglob('*')):
 if src.is_file() and src.name!='MANIFEST.sha256':manifest_lines.append(H(src.read_bytes())+'  '+str(src.relative_to(D)))
put('MANIFEST.sha256',('\n'.join(manifest_lines)+'\n').encode())
archive=P/'m4-packed-snapshot-i32-v2-2026-10-18.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for src in sorted(D.rglob('*')):
    if not src.is_file():continue
    rel=str(src.relative_to(D));data=src.read_bytes();info=tarfile.TarInfo(rel);info.size=len(data);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();names=[x.name for x in members];assert len(names)==len(set(names))
 for x in members:assert x.isfile() and not PurePosixPath(x.name).is_absolute() and '..' not in PurePosixPath(x.name).parts
 recorded={line.split('  ',1)[1]:line.split('  ',1)[0] for line in tar.extractfile('MANIFEST.sha256').read().decode().splitlines()}
 assert set(recorded)==set(names)-{'MANIFEST.sha256'}
 for n,h in recorded.items():assert H(tar.extractfile(n).read())==h,n
result={'archive':str(archive),'sha256':H(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(members),'payloads':len(recorded),'report':str(D/'REPORT.md'),'report_sha256':H((D/'REPORT.md').read_bytes()),'source_commit':source_commit,'base':base,'safe_all_manifest_payloads_verified':True,'determinism':'sorted regular files; uid/gid/mode/mtime fixed; gzip timestamp/name fixed','limits':'Cache only; executed delta now bound to exact ae50d2f source/BOOT images; no adoption/readiness approval.'}
(P/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
