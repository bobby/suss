from pathlib import Path
import subprocess as s,os,json,time,hashlib
root=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');p=Path(__file__).parent
assert not s.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
head=s.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();files=s.check_output(['git','ls-files'],cwd=root,text=True).splitlines();before={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if (root/f).is_file()};(p/'parent-inputs.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=['cargo','test','--locked','-p','suss-compile','--lib','source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo','--','--test-threads=1','--nocapture'];env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',SUSS_SOURCE_CHILD_FUEL_TRACE='1');r={'source':head,'argv':cmd,'terminal':False};start=time.monotonic()
with (p/'parent-source-child.log').open('w') as f:
 child=s.Popen(cmd,cwd=root,env=env,stdout=f,stderr=s.STDOUT);r['pid']=child.pid;(p/'parent-receipt.json').write_text(json.dumps(r,indent=2)+'\n');code=child.wait()
r.update(terminal=True,exit=code,seconds=round(time.monotonic()-start,3),changed=[f for f,h in before.items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h]);(p/'parent-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
