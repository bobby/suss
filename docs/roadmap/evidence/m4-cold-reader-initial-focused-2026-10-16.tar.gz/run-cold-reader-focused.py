from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-cold-reader-identifiers');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'cold-reader-identifiers-target'),RAYON_NUM_THREADS='2',SUSS_READER_IDENTIFIER_CAPTURE=str(c/'cold-reader-jank'))
files=[p for p in (r/'crates').rglob('*') if p.suffix in ['.rs','.sus']]+list((r/'runtime/bootstrap').glob('*'));freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
state={'base':'d58e693','issue':260,'production_fix':True,'freeze':freeze,'stages':[]};receipt=c/'cold-reader-focused-result.json'
commands=[('native',['cargo','test','-p','suss-compile','--lib','--locked','native_memo_leaf_','--','--test-threads=2','--nocapture']),('constants',['cargo','test','-p','suss-compile','--lib','--locked','compiled_identifier_constants_keep_pinned_warmed_memos','--','--test-threads=2','--nocapture']),('jank',['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','pinned_reader_identifier_predicates_keep_values','--','--test-threads=2','--nocapture']),('identity',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_cross_invocation_identity_probe','--','--test-threads=2','--nocapture']),('provenance',['python3','scripts/check_record_macro_provenance.py'])]
for name,cmd in commands:
 state['current']=name;receipt.write_text(json.dumps(state,indent=2)+'\n');start=time.time()
 with (c/('cold-reader-focused-'+name+'.log')).open('w') as log:child=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 state['stages'].append({'name':name,'command':cmd,'exit':child.returncode,'seconds':time.time()-start})
state.update(current=None,source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in freeze.items()));receipt.write_text(json.dumps(state,indent=2)+'\n')
