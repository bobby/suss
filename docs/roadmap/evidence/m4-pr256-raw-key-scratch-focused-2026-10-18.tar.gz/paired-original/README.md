# Scratch paired analysis

Control is published d38 production run pr256-compact-heads-validation. Candidate is pr256-raw-key-scratch-validation (executionbase e3a plus exact5e0d scratch downport/newBOOT). Inner observers are excluded.

analyze.py refuses final output until candidate receipt terminal/current=None. Explicit --partial-stage core-environment or collection-source can analyze only a completed case and preserves overall live state; no partial result is a final driver verdict.

Exact test argv must match. Every old metadata marker (not just declaration labels) is compared by ordered event key with final fuel replaced by a placeholder. Fuel changes are measured at matched declaration checkpoints; no assumption of noninterference for the repair. Last common balance, matched completed declarations, newly reached declaration counts and raw typed failure are retained. Fewer reached requests/negative delta/order divergence is flagged, not hidden. Graph ordinal groups do not prove separate outer budget installation. Existing collection40M is explicitly qualified.

Final report includes all stage summaries/errors and full sourcefreeze changed=[] receipts, changed paths against d38, sourcepatch/log/manifest digests. Counts remain actual Rust outcomes; pinnedmapRustPASS is not a separately audited69-ID host proof. No required failed-tail wholecost, extrapolation or elapsed-time claims.

Parser syntax checked only. No actual candidate result claimed before completed receipts. No Cargo or root edits.
