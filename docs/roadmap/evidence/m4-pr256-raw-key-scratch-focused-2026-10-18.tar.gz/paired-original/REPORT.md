# Scratch downport: final focused comparison

Executionbase e3a3850, d38 production compiler + exact5e0d raw-key-scratch source patch + own normalBOOT. Both controls/candidate terminal; candidate current=None, no unexecuted stages, every stage changed=[].28PASS4typedfuelFAIL0ignored: raw24, initializer3, pinnedmap1 pass; CoreEnv1, collection1, sourceTags2 fail. IdentityPASS. Unchanged selected test sources verified by frozen hashes. Only changed Rust path is raw_keys.rs; BOOT4 and publication docs also differ vs earlier d38 freeze. No broader compatibility/fullbaseline claim.

## Native gain

CoreEnv: all1074 old metadata event keys ordered-match. At last common IChunkedSeq definition-origin2173→374030 (+371857).182 matched completed declarations cost371862 less. Candidate completes214 vs182, starts215 vs183; final ISet definition-origin189. Still caller &env0..33 typed fuel failure. Full required cost remains unknown.

## Adverse measured result

Collection: all419 old metadata event keys ordered-match, across11 graph-start groups. First group's last checkpoint improves31, but10 later groups have less remaining. Final common suss.core/+ finished5925007→5917711 (-7296). At each group matched completed declaration work itself improves189; the adverse end-to-checkpoint result therefore lies outside that narrow declaration subtotal and is not attributable to guest-vs-native work from these traces. Do not hide it or claim a uniform request win. Existing40M fixture allowance, not default10M. Same compiled macro invocation709..738 typed fuel failure; no fullcost or later semantic assertion success.

SourceTags: inference324..356 and invocation388..413 remain caller &env fuel failures, same criteria/spans. No paired cost measurement for these. Pinnedmap remains RustPASS (separate69-ID census not performed here).

Conclusion: substantive measured CoreEnv prefix allocation repair with preserved selected outcomes, alongside small adverse collection fuel movement. Suitable evidence wording is partial progress, not restored acceptance or all-case performance improvement. Whether to publish is root's decision with both signs disclosed; no tariff/quota changes proposed to erase the adverse result.

summary.json retains full raw stage errors/log digests, paired requests/line anchors/source manifests and negative-delta flags. source-comparison-check.json verifies source scope. Inner diagnostic and200M probe remain separate. No Cargo/source edits by analyst; no elapsed-time claim.
