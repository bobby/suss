# PR256 raw-key scratch focused evidence

Execution tuple: Gitbase `e3a38501e6499ab2942d49f93239ae73e6c23092` plus retained exact5e0d scratch downport and normal4BOOT. Non-doc candidate source is not yet committed; all3532frozen inputs independently match baseGit or reconstructed savedpatch postimages (1Rust+4BOOT), no live-root hashing. Allstages terminal/drained changed[], no unexecuted stages. Bootstrap log and identity PASS retained.

Actual32distinctRust executions:28PASS4fuelFAIL0ignored. Rawkeys24PASS, initializer3PASS, mapwrapper1PASS. Required CoreEnv/collection/source-tags2 stillfail; full names/stages/spans and raw commands are in TERMINAL-COUNTS.json. These are not completed source-observation contracts.

Independent existing pinned comparator:69orderedIDs62hostpasses7guestjudged,0failure/skips/unexecuted/namespace/test failures. Guest judgments remain guest judgments. Exact capture/reference/comparator hashes included.

Paired control is d38's original focused tuple, not an observer run. Core last common IChunkedSeq definition-origin: control2173 vs candidate374030, +371857remaining; original marker sequence remains ordered. Collection last common +finished: control5925007 vs candidate5917711, -7296remaining. This is an adverse prefix result: ten of eleven collection graph groups end below control; preserve all, do not turn Core prefix improvement into whole-operation savings. Existing whole14case collection allowance remains40M; Core default10M. Graph groups are not proof of independent outer budgets; failedtails/wholecost unknown. No controlled wall-time improvement claim.

No observer tuple, live baseline, CI or older archives included. No acceptance/readiness/promotion/merge claim. No Cargo/rootwrites/push performed by packaging. Candidate publication later requires finalGitbinding; source reuse assumes neither clean mutable root nor runtime authority from equal bytes.
