from pathlib import Path
import json,hashlib,subprocess,shutil,re,types,sys,tarfile,os,datetime
sys.dont_write_bytecode=True
C=Path('/home/bobby/.cache/suss-m4-work');P=Path(__file__).parent;D=C/'pr256-raw-key-scratch-validation';S=P/'staging';S.mkdir(exist_ok=True);BASE='e3a38501e6499ab2942d49f93239ae73e6c23092';REPO='/home/bobby/Work/code/bobby/suss';L=lambda p:json.loads(p.read_text());H=lambda b:hashlib.sha256(b).hexdigest();G=lambda path:subprocess.check_output(['git','-C',REPO,'show',BASE+':'+path])
r=L(D/'receipt.json');assert r['terminal'] and r['current'] is None and not r['unexecuted'] and all(not x['changed'] for x in r['stages'])
try:os.kill(r['pid'],0);raise AssertionError('producer still alive')
except ProcessLookupError:pass
drivercheck=subprocess.run(['pgrep','-af','[p]r256-raw-key-scratch-validation/run.py'],capture_output=True,text=True)
assert drivercheck.returncode==1,drivercheck.stdout
stable={str(f):H(f.read_bytes()) for f in D.rglob('*') if f.is_file()}
def cpdir(src,label):
 for f in src.rglob('*'):
  if not f.is_file() or '__pycache__' in f.parts or f.name.endswith(('.tar.gz','.zip')):continue
  q=S/label/f.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,q)
cpdir(D,'candidate');cpdir(C/'pr256-raw-key-scratch-downport','downport-source-review');cpdir(C/'pr256-raw-key-scratch-paired-analysis','paired-original')
# Reconstruct only saved candidate delta in a cache directory, never root/index.
patch=(D/'source.patch').read_bytes();paths=re.findall(r'^diff --git i/(\S+) w/\S+$',patch.decode(),re.M);assert set(paths)=={'crates/suss-compile/src/portable_macro_graph/raw_keys.rs','runtime/bootstrap/macro.json','runtime/bootstrap/macro.wasm','runtime/bootstrap/runtime.json','runtime/bootstrap/runtime.wasm'}
for path in paths:
 q=S/'candidate-postimages'/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(G(path));b=S/'base-preimages'/path;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(G(path))
subprocess.run(['git','apply','--binary',str(D/'source.patch')],cwd=S/'candidate-postimages',check=True)
freeze=L(D/'manifest.json');pkt=L(C/'pr256-raw-key-scratch-downport/manifest.json');assert r['base']==pkt['base']==BASE
rawpath=pkt['path'];assert (S/'candidate-postimages'/rawpath).read_bytes()==(C/'pr256-raw-key-scratch-downport/after.rs').read_bytes();assert H((S/'base-preimages'/rawpath).read_bytes())==pkt['preimage_sha256']
tree={}
for line in subprocess.check_output(['git','-C',REPO,'ls-tree','-r',BASE],text=True).splitlines():
 meta,path=line.split('\t',1);mode,typ,oid=meta.split();tree[path]=(typ,oid)
proc=subprocess.Popen(['git','-C',REPO,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);memo={};binding={}
for path,h in freeze.items():
 typ,oid=tree[path];assert typ=='blob'
 if path in paths:
  assert H((S/'candidate-postimages'/path).read_bytes())==h;binding[path]={'kind':'retained_postimage_reconstructed_from_saved_binary_patch','sha256':h,'base_blob':oid};continue
 if oid not in memo:
  proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();assert hdr[1]==b'blob';left=int(hdr[2]);d=hashlib.sha256()
  while left:
   b=proc.stdout.read(min(left,1048576));assert b;d.update(b);left-=len(b)
  assert proc.stdout.read(1)==b'\n';memo[oid]=d.hexdigest()
 assert memo[oid]==h,path
 binding[path]={'kind':'base_git_blob','commit':BASE,'blob':oid,'sha256':h}
proc.stdin.close();assert proc.wait()==0;assert len(binding)==3532
(S/'SOURCE-BINDING.json').write_text(json.dumps({'base':BASE,'candidate_patch_sha256':H(patch),'paths':3532,'all_match':True,'postimages':paths,'bindings':binding,'limits':'Candidate non-doc source not yet committed. Exact savedpatch + Gitbase reconstructs all5changedfiles; allotherfreezeinputs resolveGitbase. No mutable root hashes used.'},indent=2)+'\n')
# Parse every actual selected name, including nocapture split status lines.
stages=[];alltests=[];failures={}
for st in r['stages']:
 t=(D/(st['name']+'.log')).read_text();tests=[];pending=None
 for line in t.splitlines():
  m=re.match(r'^test (\S+) \.\.\. (.*)',line)
  if m:
   assert pending is None;pending=m[1];v=re.match(r'^(ok|FAILED|ignored)(?:$|,)',m[2])
   if v:tests.append({'name':pending,'status':v[1]});pending=None
  elif pending and line in ['ok','FAILED','ignored']:tests.append({'name':pending,'status':line});pending=None
 assert pending is None
 summaries=[list(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)];counts=[sum(x[i] for x in summaries) for i in range(3)];assert counts==[sum(x['status']==v for x in tests) for v in ['ok','FAILED','ignored']]
 chunks=re.split(r"^thread '([^']+)' .*?panicked at ([^\n]+):\s*$",t,flags=re.M)
 for i in range(1,len(chunks),3):
  n,loc,b=chunks[i:i+3]
  if n not in {x['name'] for x in tests if x['status']=='FAILED'}:continue
  b=b.split('\ntest ',1)[0];assert 'all fuel consumed' in b;s=re.search(r'Compiled macro expansion failed during ([^:]+):',b);sp=re.search(r'span:\s*(\d+\.\.\d+)',b);failures[n]={'class':'fuel','stage':s[1] if s else None,'span':sp[1] if sp else None,'panic':loc,'raw_body':b}
 stages.append({**st,'counts':counts,'tests':tests,'log_sha256':H(t.encode())});alltests+=tests
counts=[sum(x['counts'][i] for x in stages) for i in range(3)];assert counts==[28,4,0] and len(alltests)==len({x['name'] for x in alltests})==32 and len(failures)==4
(S/'TERMINAL-COUNTS.json').write_text(json.dumps({'counts':counts,'unique_names':32,'stages':stages,'failures':failures,'ignored':0,'unexecuted_stages':[]},indent=2)+'\n')
# Bound existing pinned host comparator and exact source reference, retaining guest judgments.
for path in ['scripts/clojure_test_suite.py','scripts/oracle_compare.py','scripts/oracle_transport.py','tests/oracle/clojure-test-suite-observations.json','crates/suss-compile/tests/clojure_test_suite.rs','crates/suss-cli/tests/compiled_macro_core_environment.rs','crates/suss-cli/tests/compiled_macro_collection_source_asts.rs','crates/suss-cli/tests/compiled_macro_source_tags.rs']:
 q=S/'supporting-inputs'/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(G(path));assert H(q.read_bytes())==freeze[path]
sp=S/'supporting-inputs/scripts/clojure_test_suite.py';sys.path.insert(0,str(sp.parent));mod=types.ModuleType('scratch_suite');mod.__file__=str(sp);exec(compile(sp.read_text(),str(sp),'exec'),mod.__dict__)
ref=L(S/'supporting-inputs/tests/oracle/clojure-test-suite-observations.json');act=L(D/'map-capture/map-transport-observations.json');test='clojure.core-test.map/test-map';ns='clojure.core-test.map';ref.update(namespaces=[ns],tests=[test],assertions=[x for x in ref['assertions'] if x['test']==test],skips=[x for x in ref['skips'] if x['namespace']==ns]);ids=lambda a:[(x['test'],x['ordinal']) for x in a['assertions']]
assert ids(ref)==ids(act) and len(ids(act))==69
cnt,details=mod.compare(ref,act);assert cnt=={'pass':62,'guest-judged':7,'fail':0,'not-executed':0,'skipped':0,'namespaces-failed':0} and not act['test-failures'] and not act['skips'] and all(not details[k] for k in ['namespaces','tests','assertions','skip-mismatches'])
mapreview={'verdict':'MATCH','counts':cnt,'ordered_expected_ids':ids(ref),'ordered_actual_ids':ids(act),'failures':details,'actual_sha256':H((D/'map-capture/map-transport-observations.json').read_bytes()),'reference_sha256':freeze['tests/oracle/clojure-test-suite-observations.json'],'comparator_sha256':freeze['scripts/clojure_test_suite.py'],'limits':'Seven guest-judged observations are not host passes. No skipped or missing outcomes suppressed.'};(P/'map-independent-comparison.json').write_text(json.dumps(mapreview,indent=2)+'\n');shutil.copyfile(P/'map-independent-comparison.json',S/'map-independent-comparison.json')
# Separate d38 control raw data solely for paired-prefix reproduction; no merged counts.
q=S/'paired-control-d38';q.mkdir(exist_ok=True)
for n in ['receipt.json','manifest.json','core-environment.log','collection-source.log']:shutil.copyfile(C/'pr256-compact-heads-validation'/n,q/n)
for src,name in [(P/'summary.json','paired-terminal-summary.json'),(P/'analyze-paired.py','analyze-paired.py'),(C/'pr256-compact-heads-paired-analysis/analyze.py','paired-parent-analyzer.py')]:shutil.copyfile(src,S/name)
paired=L(P/'summary.json');core=paired['stages']['core-environment']['pairs'][0]['last_common'];coll=paired['stages']['collection-source']['pairs'][-1]['last_common']
report=f'''# PR256 raw-key scratch focused evidence\n\nExecution tuple: Gitbase `{BASE}` plus retained exact5e0d scratch downport and normal4BOOT. Non-doc candidate source is not yet committed; all3532frozen inputs independently match baseGit or reconstructed savedpatch postimages (1Rust+4BOOT), no live-root hashing. Allstages terminal/drained changed[], no unexecuted stages. Bootstrap log and identity PASS retained.\n\nActual32distinctRust executions:28PASS4fuelFAIL0ignored. Rawkeys24PASS, initializer3PASS, mapwrapper1PASS. Required CoreEnv/collection/source-tags2 stillfail; full names/stages/spans and raw commands are in TERMINAL-COUNTS.json. These are not completed source-observation contracts.\n\nIndependent existing pinned comparator:69orderedIDs62hostpasses7guestjudged,0failure/skips/unexecuted/namespace/test failures. Guest judgments remain guest judgments. Exact capture/reference/comparator hashes included.\n\nPaired control is d38's original focused tuple, not an observer run. Core last common IChunkedSeq definition-origin: control{core['control_fuel']} vs candidate{core['candidate_fuel']}, +{core['candidate_more_remaining']}remaining; original marker sequence remains ordered. Collection last common +finished: control{coll['control_fuel']} vs candidate{coll['candidate_fuel']}, {coll['candidate_more_remaining']}remaining. This is an adverse prefix result: ten of eleven collection graph groups end below control; preserve all, do not turn Core prefix improvement into whole-operation savings. Existing whole14case collection allowance remains40M; Core default10M. Graph groups are not proof of independent outer budgets; failedtails/wholecost unknown. No controlled wall-time improvement claim.\n\nNo observer tuple, live baseline, CI or older archives included. No acceptance/readiness/promotion/merge claim. No Cargo/rootwrites/push performed by packaging. Candidate publication later requires finalGitbinding; source reuse assumes neither clean mutable root nor runtime authority from equal bytes.\n''';(P/'REPORT.md').write_text(report);shutil.copyfile(P/'REPORT.md',S/'REPORT.md');shutil.copyfile(P/'package.py',S/'package.py')
assert stable=={str(f):H(f.read_bytes()) for f in D.rglob('*') if f.is_file()}
manifest={str(f.relative_to(S)):{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size} for f in S.rglob('*') if f.is_file() and str(f.relative_to(S))!='MANIFEST.json'};(S/'MANIFEST.json').write_text(json.dumps({'schema':1,'payloads':manifest},indent=2)+'\n');out=C/'m4-pr256-raw-key-scratch-focused-2026-10-18.tar.gz'
with tarfile.open(out,'w:gz') as tf:
 for f in sorted(S.rglob('*')):
  if f.is_file():tf.add(f,arcname=str(f.relative_to(S)),recursive=False)
with tarfile.open(out) as tf:
 ms=tf.getmembers();assert len(ms)==len(manifest)+1==len({m.name for m in ms})
 for m in ms:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='MANIFEST.json':assert H(tf.extractfile(m).read())==manifest[m.name]['sha256']
result={'archive':str(out),'sha256':H(out.read_bytes()),'members':len(manifest)+1,'payloads':len(manifest),'bytes':out.stat().st_size,'base':BASE,'frozen_paths':3532,'postimage_paths':len(paths),'rust_counts':counts,'map_counts':cnt,'core_prefix_delta':core['candidate_more_remaining'],'collection_prefix_delta':coll['candidate_more_remaining'],'observer_included':False,'baseline_included':False};(P/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
