from pathlib import Path
import re,json,hashlib,argparse,collections
C=Path('/home/bobby/.cache/suss-m4-work')
RX=re.compile(r'metadata-declaration (\S+) ([\w-]+): (\d+)')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load_stage(folder,stage,require_overall=False):
 receipt=json.loads((folder/'receipt.json').read_text())
 if require_overall:assert receipt['terminal'] and receipt['current'] is None
 row=next(r for r in receipt['stages'] if r['name']==stage)
 assert row['exit'] in (0,101) and not row['changed']
 manifest=json.loads((folder/'manifest.json').read_text());log=folder/(stage+'.log');requests=[];cur=None;test_summary=[]
 for n,line in enumerate(log.open(),1):
  start=re.search(r'metadata-graph start recipes=(\d+) sources=(\d+): (\d+)',line)
  if start:
   cur={'id':f'{stage}/request-{len(requests)+1}','graph_start_fuel':int(start[3]),'graph_start_line':n,'checkpoints':[],'declarations':[]};requests.append(cur)
  m=RX.search(line)
  if m:
   assert cur,'declaration before graph request boundary'
   cur['checkpoints'].append({'owner':m[1],'stage':m[2],'fuel':int(m[3]),'line':n})
  if 'test result:' in line:test_summary.append(line.strip())
 assert len(test_summary)==1 and re.search(r'(\d+) passed; (\d+) failed;',test_summary[0]);assert sum(map(int,re.search(r'(\d+) passed; (\d+) failed;',test_summary[0]).groups()))>0
 for req in requests:
  pending=None
  for mark in req['checkpoints']:
   if mark['stage']=='start':
    assert pending is None,'nested declaration: parser must be extended before claiming disjoint costs'
    pending={'owner':mark['owner'],'rows':[mark]}
   else:
    assert pending is not None and pending['owner']==mark['owner'];pending['rows'].append(mark)
    if mark['stage']=='finished':
     pending['complete']=True;pending['total_debit']=pending['rows'][0]['fuel']-mark['fuel'];req['declarations'].append(pending);pending=None
  if pending:pending.update(complete=False,total_debit=None);req['declarations'].append(pending)
  intervals=[]
  for d in req['declarations']:
   d['observed_intervals']=[{'from':a['stage'],'to':b['stage'],'debit':a['fuel']-b['fuel'],'lines':[a['line'],b['line']]} for a,b in zip(d['rows'],d['rows'][1:])]
   assert all(x['debit']>=0 for x in d['observed_intervals'])
   if d['complete']:
    assert sum(x['debit'] for x in d['observed_intervals'])==d['total_debit']
    intervals.extend((d['owner'],x) for x in d['observed_intervals'])
  buckets={}
  for owner,x in intervals:
   k=x['from']+' -> '+x['to'];b=buckets.setdefault(k,{'count':0,'debit':0,'largest':[]});b['count']+=1;b['debit']+=x['debit'];b['largest'].append({'owner':owner,**x})
  for b in buckets.values():b['largest']=sorted(b['largest'],key=lambda x:x['debit'],reverse=True)[:8]
  req['completed_buckets']=buckets;req['completed_declarations']=sum(d['complete'] for d in req['declarations']);req['started_declarations']=len(req['declarations']);req['last_marker']=req['checkpoints'][-1] if req['checkpoints'] else None
 return {'base':receipt.get('base',receipt.get('source')),'stage_receipt':row,'log':str(log),'log_sha256':sha(log),'receipt_sha256':sha(folder/'receipt.json'),'manifest_sha256':sha(folder/'manifest.json'),'source_hashes':{k:v for k,v in manifest.items() if k.startswith('crates/') and ('raw_' in k or 'canonical_entries' in k or 'portable_macro_graph' in k or k.endswith('compiled_macro_core_environment.rs') or k.endswith('compiled_macro_collection_source_asts.rs'))},'raw_result':test_summary[0],'requests':requests}
def pair(a,b):
 assert len(a['requests'])<=len(b['requests']),'candidate reached fewer requests; handle scope explicitly'
 pairs=[]
 for x,y in zip(a['requests'],b['requests']):
  xrows=x['checkpoints'];yrows=y['checkpoints'];n=0
  for u,v in zip(xrows,yrows):
   if (u['owner'],u['stage'])!=(v['owner'],v['stage']):break
   n+=1
  assert n>0
  # Do not match past any differing source order; retain divergence explicitly.
  matched=[]
  for i in range(1,n):
   u,v=xrows[i-1:i+1];s,t=yrows[i-1:i+1];matched.append({'from':[u['owner'],u['stage']],'to':[v['owner'],v['stage']],'control_debit':u['fuel']-v['fuel'],'candidate_debit':s['fuel']-t['fuel'],'saved':(u['fuel']-v['fuel'])-(s['fuel']-t['fuel']),'control_lines':[u['line'],v['line']],'candidate_lines':[s['line'],t['line']]})
  complete=[]
  by={(d['owner'],i):d for i,d in enumerate(y['declarations']) if d['complete']}
  for i,d in enumerate(x['declarations']):
   e=by.get((d['owner'],i))
   if d['complete'] and e and d['rows'][-1]['line']<=xrows[n-1]['line'] and e['rows'][-1]['line']<=yrows[n-1]['line']:
    complete.append({'owner':d['owner'],'ordinal':i,'control_debit':d['total_debit'],'candidate_debit':e['total_debit'],'saved':d['total_debit']-e['total_debit']})
  pairs.append({'id':x['id'],'matched_checkpoint_count':n,'control_checkpoint_count':len(xrows),'candidate_checkpoint_count':len(yrows),'prefix_order_exact_through_match':True,'first_divergence':None if n==min(len(xrows),len(yrows)) else {'control':xrows[n],'candidate':yrows[n]},'first_balance_gap':yrows[0]['fuel']-xrows[0]['fuel'],'last_common':{'owner':xrows[n-1]['owner'],'stage':xrows[n-1]['stage'],'control_fuel':xrows[n-1]['fuel'],'candidate_fuel':yrows[n-1]['fuel'],'candidate_more_remaining':yrows[n-1]['fuel']-xrows[n-1]['fuel']},'matched_completed_declarations':complete,'matched_adjacent_checkpoint_intervals':matched,'unfinished_required_totals':None})
 return pairs
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--control',type=Path,default=C/'pr256-compact-heads-control');ap.add_argument('--candidate',type=Path);ap.add_argument('--candidate-released',action='store_true');ap.add_argument('--control-only-stage',choices=['core-environment','collection-source']);args=ap.parse_args();out=Path(__file__).parent
 if args.control_only_stage:
  result=load_stage(args.control,args.control_only_stage);(out/('control-'+args.control_only_stage+'-partition.json')).write_text(json.dumps(result,indent=2)+'\n')
  for r in result['requests']:print(r['id'],r['completed_declarations'],r['started_declarations'],{k:(v['count'],v['debit']) for k,v in r['completed_buckets'].items()})
 else:
  assert args.candidate and args.candidate_released,'candidate path and explicit main release required; no live candidate reads'
  result={'stages':{},'limits':['Completed checkpoint/declaration prefixes only; no required whole-request cost or forecast.','Unknown failed tail and later request phases remain unknown.','Graph-request ordinals follow actual log order; trace does not emit caller phase.','Source tuple, test argv, results and hashes retained; nested cost labels not summed.']}
  for stage in ['core-environment','collection-source']:
   a=load_stage(args.control,stage,True);b=load_stage(args.candidate,stage,True);assert a['stage_receipt']['argv']==b['stage_receipt']['argv'],'different test invocation';result['stages'][stage]={'control':a,'candidate':b,'pairs':pair(a,b)}
  (out/'paired-summary.json').write_text(json.dumps(result,indent=2)+'\n')
