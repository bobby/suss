from pathlib import Path
import argparse,collections,hashlib,importlib.util,json,re
C=Path('/home/bobby/.cache/suss-m4-work');spec=importlib.util.spec_from_file_location('prior',C/'pr256-compact-heads-paired-analysis/analyze.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def metadata(path):
 result=[]
 for i,s in enumerate(path.read_text().splitlines(),1):
  pos=s.find('metadata-')
  if pos<0:continue
  s=s[pos:];key=re.sub(r': \d+$',': FUEL',s)
  result.append({'key':key,'raw':s,'line':i})
 return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--candidate',type=Path,default=C/'pr256-raw-key-scratch-validation');ap.add_argument('--control',type=Path,default=C/'pr256-compact-heads-validation');ap.add_argument('--partial-stage',choices=['core-environment','collection-source']);a=ap.parse_args();out=Path(__file__).parent;p=a.candidate;r=json.loads((p/'receipt.json').read_text())
 if not a.partial_stage:assert r.get('terminal') is True and r.get('current') is None,'candidate driver LIVE: final report withheld'
 else:assert any(x['name']==a.partial_stage and 'exit' in x for x in r['stages']),'requested case not terminal'
 result={'partial_case_only':bool(a.partial_stage),'candidate_base':r['base'],'overall_terminal':r.get('terminal'),'overall_current':r.get('current'),'stages':{},'adverse_observations':[],'limits':['Matched completed prefixes only; failed required tails unknown.','Graph-start ordinals are not independent outer requests or caller phases.','Existing collection40M allowance is not default10M.','No elapsed-time comparison or entire compatibility/acceptance claim.','Inner observer evidence kept separate.']}
 for name in ([a.partial_stage] if a.partial_stage else ['core-environment','collection-source']):
  x=prior.load_stage(a.control,name,True);y=prior.load_stage(p,name,not a.partial_stage);assert x['stage_receipt']['argv']==y['stage_receipt']['argv']
  # Retain fewer-request regression explicitly instead of parser's assumed nonregression.
  px={**x,'requests':x['requests'][:len(y['requests'])]};pairs=prior.pair(px,y)
  if len(y['requests'])<len(x['requests']):result['adverse_observations'].append(name+': fewer graph-start groups reached')
  old=metadata(a.control/(name+'.log'));new=metadata(p/(name+'.log'));n=0
  for u,v in zip(old,new):
   if u['key']!=v['key']:break
   n+=1
  if n<len(old):result['adverse_observations'].append(name+': original metadata sequence not entirely reached/matched')
  for q in pairs:
   if q['first_divergence'] is not None:result['adverse_observations'].append(name+': declaration order divergence')
   if q['last_common']['candidate_more_remaining']<0:result['adverse_observations'].append(name+': negative last-common fuel delta')
  result['stages'][name]={'control':x,'candidate':y,'pairs':pairs,'ALL_metadata_marker_order':{'production_count':len(old),'candidate_count':len(new),'matched_prefix':n,'all_original_reached_in_order':n==len(old),'first_divergence':{'production':old[n] if n<len(old) else None,'candidate':new[n] if n<len(new) else None} if n<min(len(old),len(new)) else None}}
 if not a.partial_stage:
  result['stage_outcomes']=[];total=collections.Counter()
  for row in r['stages']:
   assert not row.get('changed'),row['name']+' source drift'
   text=(p/(row['name']+'.log')).read_text();summaries=[{'pass':int(x),'fail':int(y),'ignored':int(z)} for x,y,z in re.findall(r'test result:.*?(\d+) passed; (\d+) failed; (\d+) ignored;',text)]
   for s in summaries:total.update(s)
   errors=[s for s in text.splitlines() if 'Err' in s and ('Diagnostic' in s or 'Trap' in s)]
   result['stage_outcomes'].append({'name':row['name'],'exit':row['exit'],'argv':row['argv'],'summaries':summaries,'errors':errors,'log_sha256':sha(p/(row['name']+'.log'))})
  result['raw_execution_counts']=dict(total);result['unexecuted']=r.get('unexecuted')
  cm=json.loads((a.control/'manifest.json').read_text());vm=json.loads((p/'manifest.json').read_text());result['changed_frozen_paths_vs_d38']=[k for k in cm.keys()|vm.keys() if cm.get(k)!=vm.get(k)];result['frozen_path_count']=len(vm);result['patch_sha256']=sha(p/'source.patch')
 result['bindings']={str(q):sha(q) for q in [p/'receipt.json',p/'manifest.json',a.control/'receipt.json',a.control/'manifest.json']}
 target=out/(('partial-'+a.partial_stage+'.json') if a.partial_stage else 'summary.json');target.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'output':str(target),'partial':result['partial_case_only'],'adverse_observations':result['adverse_observations']},indent=2))
if __name__=='__main__':main()
