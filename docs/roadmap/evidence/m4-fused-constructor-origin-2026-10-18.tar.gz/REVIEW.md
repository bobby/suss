# Closed construction interval — read-only review

Source tuple: coherent C worktree `suss-m4-coherent-identity-acceptance`, HEAD b55d122 (source checkpoint a09 ancestry). This review makes no production-head equivalence or execution claim. No Cargo, source edits, or new instrumentation.

## Verdict

Existing CertificationAudit is insufficient to authorize construction-to-enrollment reuse. A narrow private fused ordinary-construction/enrollment operation is plausible; sharing an audit across arbitrary FormBridge constructions is unsound. The measured prototype and snapshot totals are not removable-work estimates.

## Actual order / boundaries

- portable_macro_data.rs:477–505: precheck class; data_construct_with_inputs; Fact::constructor wrapping; record. record at452 obtains domain, enrolls, then publishes ledger. No hash/equality call in this immediate sequence.
- constructor_inputs.rs:297–392: owner checks and prepared route; special plan executes and returns no ordinary facts. Ordinary route captures/checks schema, derives duplicate-name last-winner input expectations BEFORE factory; executes factory; reads physical field/properties roots; invokes prototype getter at its original POST-factory point; captures PrototypeInputs; checks direct inputs; registers memo watch; publishes schema witness.
- runtime_abi/error_constructors.rs:451: descriptor plan selects nominal native construction; non-descriptor path calls invoke. Never carry observations across the latter.
- runtime_abi/nominal.rs:110–176: ordinary normalization performs native schema reads, copied argument normalization, prototype getter and allocation. Prototype getter can lazily WRITE constructor cache, prototype objects and provenance registry; it is a write boundary despite not being a user callback. Any earlier prototype observation is invalid here.
- prototype_origin.rs:107–125: post-getter query captures twelve independent recorded provenance references. runtime_abi/prototype_origins.rs:71–95 reads sealed registry/current carrier and allocates copied result; no setter or user invoke in this query.
- memo_bridge.rs:305–352: watch registration checks initial constructor authority, allocates zero/Watch, sweeps weak watch list, publishes Weak. It does not write receiver/schema/prototype storage or install a receipt. bind_source_domain at1135 writes native Weak/domain validity only.
- write_domain.rs:96–175: bind domain; direct match; ONLY if true prototype match; then edge/cut construction and receiver storage snapshot; node publication. Initial direct failure still invalidates domain and follows old fallback storage/publication semantics.
- portable_macro_data.rs:723/747 are actual hash/equality invokes for map construction. Any audit/observation must end BEFORE either invocation, including an error outcome. Set routes use this path too. Final construction of the nominal container does not make its earlier callbacks harmless.

## Concrete duplicate work

1. ConstructorInputs::matches is run at constructor_inputs.rs:376 and write_domain.rs:146. Both read schema snapshot, receiver/descriptor/field-array/properties identities, UID, prototype carrier, array length and EVERY expected field. The second call additionally sees a newly registered memo_watch, whose receipt is initially None (memo_bridge.rs:183–189). Therefore it is NOT safe to replace the second call by a stored boolean without separately preserving the post-registration receipt/IRQ path.
2. prototype_origin_inputs and PrototypeInputs::matches each call source_constructor_matches and prototype-origin-query. The latter additionally performs the independent twelve-field comparisons, complete physical prototype structure/key checks, initial-parent identity and parent storage validation (prototype_origin.rs:129–190). Capture alone does NOT perform those validations. Retaining the actual query observation within a closed pass could avoid a second query/copy and authority read; it cannot remove those independent checks or treat fresh captured data as initial authority.
3. Schema witness is fully checked in prepare_schema_witness, then both direct matches check it again. Reuse is only justified AFTER ordinary factory / lazy prototype writes have been proven not to modify the exact observed schema; preserving first failure/validation ordering matters. General constructors cannot receive this assumption.

## What is NOT duplicated

write_domain.rs captures the first receiver StorageSnapshot after direct/prototype proof and with cuts. ConstructorInputs holds a SCHEMA snapshot, not an equivalent receiver snapshot. No existing receiver snapshot can simply be moved into domain enrollment. The ~1.27M receiver capture cannot be claimed eliminated by CertificationAudit. Replacing it requires a separately proven complete physical witness, not a cached success.

## Bounded API candidate / required proof

Use a private ordinary-only operation which owns the mutable Session borrow and carries an exact receiver + immutable ConstructorInputs (or borrowed staged facts), never a reusable public success token. Execute special constructors unchanged and outside any pass. Create the read-only interval only AFTER the factory and original post-factory prototype getter; expose only fixed provenance/direct-check/watch/enrollment operations, no Session accessor or arbitrary closure. Consume/drop it before return to FormBridge, map/set hashing, fallback, or user code. No cross-construction audit, epoch, pointer-authority cache, or Watch lifetime extension.

Preserve first complete direct validation before registration, registration ordering, post-registration receipt/IRQ/error behavior, conditional prototype validation, every independent physical/source/parent predicate, exact cuts and original-value fallback. Full domain snapshot stays live initially. A retained query must own/root all GC references; raw scoped Val cannot escape its RootScope. Stage and prepay allocation/retains/release before publication; no partially installed domain node on error.

Before implementation approval, prove generated transitive adapter calls are fixed read-only on the post-getter success path and operation-budget restoration changes only dynamic checkpoint, not guest payload. Tests must cover lazy cache creation, custom/special callbacks changing schema/prototype, ReaderMap/Set hash/equality mutation between constructions, false direct facts with later error, watch receipt state, GC, reset/foreign, IRQ after first observation, every-charge failure/retry and unchanged effect counts/order. Cost evidence must split saved direct/query work from still-required prototype physical checks and receiver capture. No demonstrated whole-request savings yet.
