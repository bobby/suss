from pathlib import Path
import json,re,hashlib
p=Path(__file__).parent;main=json.loads((p/'receipt.json').read_text());supp=json.loads((p/'preserve-receipt.json').read_text());assert main['terminal'] and supp['terminal']
names=[];tot=[0,0,0];rows=[]
for stage in main['stages']+supp['stages']:
 assert not stage['changed']
 if stage['name'] in ['bootstrap','identity']:assert stage['exit']==0;continue
 log=(p/(stage['name']+'.log')).read_text();matches=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',log);assert len(matches)==1,stage['name'];counts=list(map(int,matches[0]));tot=[a+b for a,b in zip(tot,counts)];rows.append(dict(name=stage['name'],counts=counts));names+=re.findall(r'^test ([\w:]+) \.\.\.',log,re.M)
assert len(names)==len(set(names))==56 and tot==[48,8,0],(len(names),len(set(names)),tot)
m=json.loads((p/'map-comparison.json').read_text());assert m['ordered_ids_match'] and m['counts']=={'pass':62,'guest-judged':7,'fail':0,'not-executed':0,'skipped':0,'namespaces-failed':0}
comparison=json.loads((p/'public-prefix-comparison.json').read_text());assert len(comparison)==6
for r in comparison:assert r['old_completed']==r['new_completed']==r['common_completed_prefix']==51 and not r['new_finalization_reached']
savings=[r['old_prefix_units']-r['new_prefix_units'] for r in comparison]
a=json.loads((p/'callable.json').read_text());b=json.loads((p/'control/callable.json').read_text());errors=[]
for new,old in zip(a['phases'],b['phases']):
 assert new['phase']==old['phase'];assert new['observations']['rows']==old['observations']['rows']==[]
 for ne,oe in zip(new['observations']['errors'],old['observations']['errors']):
  assert ne['label']==oe['label'];assert 'all fuel consumed' in ne['error'];assert 'caller &env input transport' in ne['error'];errors.append({'phase':new['phase'],'label':ne['label'],'raw_equal':ne==oe,'old':oe['error'],'new':ne['error']})
assert len(errors)==6
binding=json.loads((p/'source-head.json').read_text());out={'source':binding['head'],'counts':dict(unique=56,passed=48,failed=8,ignored=0),'stages':rows,'tracked_inputs':binding['tracked_files'],'all_stages_unchanged':True,'matched51prefix_savings_min':min(savings),'matched51prefix_savings_max':max(savings),'public_receipts_equal':False,'callable_errors':errors,'map':m,'limits':['Allsixcallablerequests failconstruct26 beforeexport/finalization; noidentityrows','Namespacefailswithoutfullrows','Sixcoherentguardsfailfuel; originalreadercontrolsfailbeforecoherent/effectarms','NewexhaustiveenrollmentcutscoverArrayChunkwithoutWatch; existingwatchedwrite-domain7areboundedcoverage, notexhaustivewatchedcuts','No newupstreamoracle/fullworkspacebaseline/currentcandidateCIpass/issueclosure/promotion']}
(p/'terminal-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['callable_errors','map','stages']},indent=2))
