# Test-only qualification against actual pinned indexing-reader contract

Base `1bea05084ee38f4e442927bff4fa57d052a40c7d`. Patch `78770975eaddf61e9dbc19cca5f4fa8f8db6facaa0aa0199d52e8ef49342f6d2`, one cfg(test)-only Rust module. No production field/helper change; the former raw-scalar production patchc6e0... is WITHDRAWN via its explicit sidecar. No source/worktree/index/ref/remote mutation or native execution.

## Real reference

pr261-scalar-tag-indexing-reference-1bea-v1 contains2freshNode processes,15actualanalyzer→registered &env cases each, identical stdout SHA `e8301d66d8a82c7f63f8f64c08d9ca2a0cbee774ddec16bfe42397ad47d118e7`,115retainedJS/JSON inputs frozen before/after (82loadedsubset), cleanpinc4295f3. Plain read_string ^number is unlocated; indexing ^number preserves exact4position fields, optionalfile adds file; raw/final/inner tag is the same Symbol in every object-valued case. Explicitmarker survives. Stringtag has no metadata. Function explicit tag/ret-tag retain metadata. This is retained compiled reference, NOT a freshCLJSbuild/native/Cargo or hash-callback-order proof.

The native legacy route was a prototype: actualraw1bea left legacy outertagbare vsright sharedlocated proves mismatch, not that shared is wrong. New shared behavior for ^number matches actual indexing reference. All3routes were computed beforefirstcomparisonfailed; cold-helper comparison and later12Runtime/Macrocontrols were not established.

## Precise control correction

The independent original method and all14original programs stay byte-exact. Shared/cold still compare every presence/value and fullmetadata field across all22selectedfields. ONLY the exact observed `(def ^number subject 17)` gets a reference-qualified outertagmetadata expectation. First compare legacy scalar kind/data/presence independently, retain/assert its bare counterexample, then substitute only the exact observed indexing metadata (line1 col7 endline1 endcol13) in the expected copy. Allother21fields remain originallegacy, and allother13programs remain strict fulllegacy equality. This does not silently bless unexecuted cases or ignore allmetadata. Unknown future discrepancies must be independently adjudicated.

A new five-row bounded native regression, bothSessions/GC, checks plain/indexing/file, primitiveString, explicitmarker and explicitFunctiontag/retTag against exact retained-reference values, plus raw/finalinnerSymbol identity where actually proved. No physicalStringidentity or unknowncallbackcount assertions. Native source remains unchanged. Main's expected-vector span correction is separate and untouched.

Only parse/cache-apply checks ran. ActualNativeexecution, normal source-fingerprint bootstrap tuple and original strict core17/fullsourcechild/#270 remain required; no nativeacceptance/cost/promotion claim.

## Final V2 span and freeze check

Source and patch are byte-identical to V1; V2 corrects only the manifest's prose spelling to the exact original `(def ^number subject 17)`. The five-row test does not compare decoded guest Forms with a raw parsed expected vector: each expected scalar (including all nested metadata) is quoted through FormBridge and decoded with the same `0..0` span as the actual result. Thus full Form equality retains metadata while avoiding inevitable parsed-versus-decoded synthetic span differences. The original 22-field comparison uses `.kind` on the decoded outer container; all nested field Forms remain fully compared. No recursive metadata/span stripping is introduced.

All 14 original source programs and the entire independent legacy-method prefix were rechecked byte-exact. Only one exact program qualifies one metadata field; other 21 fields and other 13 programs remain strict independent comparisons. The sibling's separately reviewed type_value_regression_tests.rs is not included, copied, or modified. This packet is author-frozen for independent peer review before application; no independent approval or native execution is claimed.
