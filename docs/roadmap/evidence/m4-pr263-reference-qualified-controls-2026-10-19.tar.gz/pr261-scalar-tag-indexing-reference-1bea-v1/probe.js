'use strict';
const fs=require('fs'),path=require('path');
const base='/home/bobby/.cache/suss-m4-work/memo-call-boundary-draft/out';
const reads=new Set(),read=fs.readFileSync;
fs.readFileSync=function(p,...args){if(typeof p==='string'&&p.startsWith(base+'/'))reads.add(path.relative(base,p));return read.call(this,p,...args);};
require(path.join(base,'goog/bootstrap/nodejs.js'));
require(path.join(base,'cljs_deps.js'));
goog.global.CLOSURE_UNCOMPILED_DEFINES={'cljs.core._STAR_target_STAR_':'nodejs'};
for(const ns of ['cljs.core','cljs.analyzer','cljs.env','cljs.js','cljs.tools.reader','cljs.tools.reader.reader_types','cljs.nodejs'])goog.require(ns);
cljs.nodejs.enable_util_print_BANG_();
const c=cljs.core,a=cljs.analyzer,tr=cljs.tools.reader,rt=tr.reader_types;
const kw=x=>c.keyword(x),vec=xs=>c.vec(xs),get=(m,k)=>c.get(m,kw(k));
const cases=[
 ['symbol-tag','(def ^number subject 17)'],
 ['string-tag','(def ^"number" subject 17)'],
 ['function-explicit-tag','(def ^number subject (fn* [] 17))'],
 ['explicit-tag-metadata','(def ^{:tag ^{:marker :kept} number} subject 17)'],
 ['function-no-tag','(def subject (fn* [] 17))']
];
const modes=[['read_string',null],['indexing',null],['indexing-file','tag-oracle.cljs']];
function describe(value){const m=c.meta(value);return {value:c.pr_str(value),metadata:c.pr_str(m),metadataEntries:m==null?[]:c.into_array(c.seq(m)).map(e=>[c.pr_str(c.key(e)),c.pr_str(c.val(e))])};}
if(c.NS_CACHE==null)c.NS_CACHE=c.atom(c.PersistentArrayMap.EMPTY);
const originalCache=c.deref(c.NS_CACHE),rows=[];
for(const [mode,file]of modes)for(const[label,source]of cases){
 const state=cljs.js.empty_state(),target=c.symbol('suss-oracle.scalar-tag-metadata');
 const nsPath=vec([kw('cljs.analyzer/namespaces'),target]);
 c.swap_BANG_(state,c.assoc_in,nsPath,c.hash_map(kw('name'),target,kw('defs'),c.PersistentArrayMap.EMPTY));
 const saved=[cljs.env._STAR_compiler_STAR_,a._STAR_cljs_ns_STAR_,a._STAR_analyze_deps_STAR_,a._STAR_load_macros_STAR_,a._STAR_cljs_file_STAR_];
 try{
  cljs.env._STAR_compiler_STAR_=state;a._STAR_cljs_ns_STAR_=target;a._STAR_analyze_deps_STAR_=false;a._STAR_load_macros_STAR_=false;a._STAR_cljs_file_STAR_=file;
  const reader=mode==='read_string'?null:rt.indexing_push_back_reader(source,1,file);
  const form=reader==null?tr.read_string(source):tr.read(reader);
  const rawDeclaration=c.second(form),rawMeta=c.meta(rawDeclaration),rawTag=get(rawMeta,'tag');
  const before={rawDeclaration:describe(rawDeclaration),rawTag:describe(rawTag),rawTagPresent:!!c.contains_QMARK_(rawMeta,kw('tag'))};
  const ast=a.analyze(c.assoc(a.empty_env(),kw('ns'),a.get_namespace(target)),form);
  const decl=c.get_in(c.deref(state),vec([kw('cljs.analyzer/namespaces'),target,kw('defs'),c.symbol('subject')]));
  if(decl==null)throw Error('missing actual declaration');
  const macroNs=c.symbol('suss-oracle.scalar-tag-observer$macros');
  let entries=0,observed=null;
  const observe=function(macroForm,macroEnv){entries++;observed=c.get_in(macroEnv,vec([kw('ns'),kw('defs'),c.symbol('subject')]));return 17;};
  observe.cljs$lang$macro=true;
  c.swap_BANG_(state,c.assoc_in,vec([kw('cljs.analyzer/namespaces'),macroNs]),c.hash_map(kw('name'),macroNs,kw('defs'),c.hash_map(c.symbol('observe'),c.hash_map(kw('name'),c.symbol('suss-oracle.scalar-tag-observer$macros/observe'),kw('macro'),true,kw('method-params'),vec([vec([c.symbol('&form'),c.symbol('&env')])]),kw('max-fixed-arity'),2))));
  c.swap_BANG_(c.NS_CACHE,c.assoc,macroNs,c.create_ns(macroNs,{observe}));
  const macroAst=a.analyze(c.assoc(a.empty_env(),kw('ns'),a.get_namespace(target)),tr.read_string('(suss-oracle.scalar-tag-observer/observe)'));
  if(entries!==1||observed!==decl||get(macroAst,'val')!==17)throw Error('actual macro env/result mismatch');
  const outer=get(observed,'tag'),meta=get(observed,'meta'),inner=get(meta,'tag'),referenceComparable=rawTag!=null&&typeof rawTag==='object';
  rows.push({mode,file,label,source,readerType:reader==null?'string_push_back_reader via read_string':reader.constructor.name||'IndexingPushbackReader',macroEntries:entries,actualMacroSameDeclaration:observed===decl,macroResult:get(macroAst,'val'),before,
   finalTagPresent:!!c.contains_QMARK_(observed,kw('tag')),finalTag:describe(outer),retTagPresent:!!c.contains_QMARK_(observed,kw('ret-tag')),retTag:describe(get(observed,'ret-tag')),fnVar:get(observed,'fn-var'),
   innerTagPresent:!!c.contains_QMARK_(meta,kw('tag')),innerTag:describe(inner),metaSameRawDeclarationMetadata:meta===rawMeta,
   referenceComparable,rawTagSameFinal:referenceComparable?rawTag===outer:null,rawTagSameInner:referenceComparable?rawTag===inner:null,finalTagSameInner:referenceComparable?outer===inner:null,
   rawTagAfterAnalysis:describe(rawTag)});
 }finally{
  [cljs.env._STAR_compiler_STAR_,a._STAR_cljs_ns_STAR_,a._STAR_analyze_deps_STAR_,a._STAR_load_macros_STAR_,a._STAR_cljs_file_STAR_]=saved;
  c.reset_BANG_(c.NS_CACHE,originalCache);if(c.deref(c.NS_CACHE)!==originalCache)throw Error('NS cache restore failed');
 }
}
console.log(JSON.stringify({scope:'Retained pinned compiled analyzer+tools.reader actual macro &env; plain string vs indexing reader/file. No fresh CLJS build/native Suss or callback-order claim.',cases:rows,loadedRetainedInputs:[...reads].sort()},null,2));
