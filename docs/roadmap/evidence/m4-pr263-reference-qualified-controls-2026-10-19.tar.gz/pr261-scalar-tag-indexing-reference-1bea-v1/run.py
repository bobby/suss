from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).parent;C=r.parent;binding=json.loads((C/'pr261-type-inner-meta-reference-ca8-v1/terminal-receipt.json').read_text());base=Path(binding['retained_compiled_inputs_directory']);inputs=binding['inputs'];sha=lambda b:hashlib.sha256(b).hexdigest();assert len(inputs)==115
assert all(sha((base/p).read_bytes())==h for p,h in inputs.items())
(r/'inputs-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
pin=subprocess.check_output(['git','-C','/home/bobby/Work/code/bobby/suss/clojurescript','rev-parse','HEAD']).decode().strip();assert pin=='c4295f303100bbf5afac449242d30bca1126f1a1'
status=subprocess.check_output(['git','--no-optional-locks','-C','/home/bobby/Work/code/bobby/suss/clojurescript','status','--porcelain']);(r/'pinned-status-before.txt').write_bytes(status)
start=time.monotonic();q=subprocess.run(['node',str(r/'probe.js')],capture_output=True);duration=time.monotonic()-start
number=1
while (r/f'attempt{number}.json').exists():number+=1
(r/f'attempt{number}.json').write_bytes(q.stdout);(r/f'attempt{number}.stderr').write_bytes(q.stderr)
after={p:sha((base/p).read_bytes()) for p in inputs};assert after==inputs;(r/f'inputs-after-attempt{number}.json').write_text(json.dumps(after,indent=2)+'\n')
(r/f'attempt{number}-receipt.json').write_text(json.dumps({'argv':['node',str(r/'probe.js')],'exit':q.returncode,'seconds':duration,'stdout_sha256':sha(q.stdout),'stderr_sha256':sha(q.stderr),'program_sha256':sha((r/'probe.js').read_bytes()),'input_count':len(inputs),'before_after_exact':True,'pin':pin,'pinned_worktree_clean_before':not status,'scope':'Node retained reference only; no fresh CLJS build/native execution'},indent=2)+'\n')
print(json.dumps({'attempt':number,'exit':q.returncode,'seconds':duration,'stdout_bytes':len(q.stdout),'stderr_bytes':len(q.stderr)}))
