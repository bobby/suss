"""Cache-only assembly; requires TERMINAL run + root's committed Git binding."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,tarfile,re
C=Path('/home/bobby/.cache/suss-m4-work')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
p=argparse.ArgumentParser();p.add_argument('--source-commit');p.add_argument('--binding',type=Path);p.add_argument('--snapshot-only',action='store_true');p.add_argument('--review',type=Path,action='append',default=[]);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
R=Path('/home/bobby/Work/code/bobby/suss-m4-pr268-sparse-setter');run=C/'pr268-sparse-setter-focused-v1';prior=C/'sparse-array-set-repair-focused-v1';packet=C/'pr268-sparse-setter-source-v1';base='ae28db396ee3050dedca812ff6993d7998e3e27f';receipt=read(run/'receipt.json')
assert receipt['head']==base and receipt['current'] is None
assert not receipt.get('controller_error') and receipt.get('final_changed')==[]
assert not receipt.get('unexecuted_stages')
expected={'bootstrap':0,'new-sparse-set-tests':3,'existing-sparse-tests':12,'cli-core-import':17,'prior-baseline-collection-source-asts':3}
assert [r['name'] for r in receipt['stages']]==list(expected)
allnames=[];counts={'pass':0,'fail':0,'ignore':0}
for r in receipt['stages']:
 assert r['execution'] in ('PASS','FAIL')
 if r['name']=='bootstrap':assert r['exit']==0;continue
 assert r['selection_established'] and len(r['selected_names'])==expected[r['name']]
 assert sorted(r['selected_names'])==sorted(r['actual_test_starts'])
 assert sum(r['counts'].values())==expected[r['name']]
 if r['name']!='prior-baseline-collection-source-asts':assert r['execution']=='PASS'
 allnames.extend(r['actual_test_starts'])
 for k in counts:counts[k]+=r['counts'][k]
assert len(allnames)==len(set(allnames))==35
freeze=read(run/'terminal.json');assert freeze==read(run/'after-bootstrap.json')
assert a.snapshot_only or (a.source_commit and a.binding)
if not a.snapshot_only:
 binding=read(a.binding);assert binding['head']==a.source_commit and binding['mismatches']==[] and binding['checked']==len(freeze)
manifest=read(packet/'manifest.json')
boot=[f'runtime/bootstrap/{phase}.{ext}' for phase in ('macro','runtime') for ext in ('wasm','json')]
paths=list(manifest['files'])+boot
if not a.snapshot_only:
 changed=set(subprocess.check_output(['git','diff','--name-only',base,a.source_commit],cwd=R,text=True).splitlines());assert changed==set(paths),changed
# Independently bind each changed byte to the exact root-created commit.
blobs={}
for f in paths:
 b=((packet/'after'/f).read_bytes() if f in manifest['files'] else (run/'bootstrap'/f).read_bytes()) if a.snapshot_only else subprocess.check_output(['git','show',a.source_commit+':'+f],cwd=R)
 assert sha(b)==freeze[f];blobs[f]=b
for f,h in manifest['files'].items():assert sha(blobs[f])==h
assert not a.output.exists();a.output.mkdir(parents=True);payload=a.output/'payload';payload.mkdir()
def copytree(src,dst):shutil.copytree(src,dst)
copytree(run,payload/'ae28-run');copytree(packet,payload/'ae28-source-packet');copytree(prior,payload/'ce6-run');copytree(C/'sparse-array-set-repair-source-v1',payload/'ce6-source-packet')
copytree(C/'legacy-reader-hash-cost-v1',payload/'ce6-original-control-before-repair')
for label in ['sparse-array-set-repair-focused-v1-independent-terminal-review.json','sparse-array-set-repair-source-v1-independent-review.json','pr268-sparse-setter-source-v1-independent-review.json']:
 shutil.copy2(C/label,payload/label)
for i,review in enumerate(a.review):shutil.copy2(review,payload/f'additional-review-{i}-{review.name}')
if a.binding:shutil.copy2(a.binding,payload/'source-commit-binding.json')
for name in ['run-pr268-sparse-setter-focused-v1.py','pr268-sparse-setter-focused-plan-v1.json','bind-suss-frozen-source.py']:
 shutil.copy2(C/name,payload/name)
shutil.copy2(Path(__file__),payload/'packager.py')
for f,b in blobs.items():
 dst=payload/('frozen-source' if a.snapshot_only else 'committed-source')/f;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
summary={'source_commit':a.source_commit,'source_commit_status':'PENDING root commit/binding' if a.snapshot_only else 'Git bound','source_base':base,'source_inputs':len(freeze),'ae28_unique_test_counts':counts,'ae28_unique_tests':35,'ce6_context':'Separate source variant; 15 sparse PASS and original control typed fuel FAIL; coherent/effect assertions unexecuted. Not additive to ae28 counts.','git_source_closure':('Full before/post-bootstrap/terminal freeze retained. Six frozen source/BOOT blobs included. Root commit and Git binding PENDING; base ae28 and pinned submodule identify unchanged bytes.' if a.snapshot_only else 'Full freeze and root Git binding retained; unchanged sources resolved through exact public commit and pinned submodule. Six changed committed blobs included.'),'limits':'No full baseline; no milestone/issue completion; no CI claim. ae28 collection-source-asts outcomes retained even if failed. No quota changes.'}
(payload/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
commands='\n'.join(' '.join(r['command']) for r in receipt['stages'])
report=f'''# Sparse-array setter focused evidence\n\nSource snapshot (commit {a.source_commit or 'PENDING root commit/binding'}) is ae28 plus the two reviewed source files and four normally regenerated BOOT artifacts. The setter reuses its complete first validation and performs one ordered sparse search; validation coverage and write order are retained.\n\nae28 exact focused results: {counts['pass']} PASS, {counts['fail']} FAIL, {counts['ignore']} ignored; 35 unique tests. The unchanged three-test collection-source-asts binary exit is {receipt['stages'][-1]['exit']}. Raw individual outcomes and commands are archived. This is not a full baseline or a claim that prior acceptance fuel failures are resolved.\n\nThe ce6 contextual run is a different tuple: 15 sparse tests passed; the original nine-local route failed with typed fuel exhaustion before coherent/effect assertions. Do not combine its counts or BOOT with ae28. No full performance or callback-criterion success is inferred.\n\nFull source freezes, six exact captured source/BOOT blobs, approved source snapshots, raw bootstrap/test logs and available terminal reviews are retained. Root source commit and full Git binding remain PENDING in snapshot-only mode; this is not a fabricated commit binding. Unchanged input bytes identify base ae28 and pinned submodule.\n\nCommands:\n```text\n{commands}\n```\n\nNo quota, tariff, callback, or test-source edits beyond the three new regressions; no merge/closure/readiness assertion.\n'''
(a.output/'evidence.md').write_text(report);(a.output/'handoff.md').write_text(report)
entries={str(f.relative_to(payload)):sha(f.read_bytes()) for f in sorted(payload.rglob('*')) if f.is_file()};(payload/'MANIFEST.json').write_text(json.dumps(entries,indent=2)+'\n')
archive=a.output/'m4-sparse-array-setter-focused.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for f in sorted(payload.rglob('*')):
  if f.is_file():tar.add(f,arcname=str(f.relative_to(payload)),recursive=False)
result=dict(summary,archive=str(archive),archive_sha256=sha(archive.read_bytes()),members=len(entries)+1,manifested_payloads=len(entries));(a.output/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
