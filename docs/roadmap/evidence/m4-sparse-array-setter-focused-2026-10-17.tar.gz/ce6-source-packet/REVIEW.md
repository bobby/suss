# Sparse setter: validated backing reuse and one ordered search

Source-only proposal; no Cargo, bootstrap, Wasm validation or guest execution performed.

The setter still calls the complete `fields` validator first. The logical length is read from its validated backing using the same NUMBER extraction as `length`; there is no callback, mutation or suspension between validation and reuse. No unchecked public entrypoint, cache, epoch, new ABI or quota change is introduced.

The sparse branch uses the existing predecessor traversal once, then checks its stopping node for equality. Full validation still precedes an early match, including late shape/range/duplicate/cycle failures. The lookup helper and all other APIs are unchanged. Allocation and write order remain original: missing-node key box, node allocation, link update, then possible length box/write; replacement writes the value before the common length handling. No stronger rollback guarantee for exhaustion after a write is claimed. Existing engine fuel/epoch interruption mechanisms remain active; fewer executed Wasm operations intentionally change fuel consumption. Exact interruption timing is not promised.

Three appended tests cover ordered head/middle/tail insertion and replacement, aliasing/GC/uint32-max property; late corruption before an early-match write with restoration/retry and typed language errors; malformed/null/typed and foreign-store receivers with recovery. These tests have NOT run. Existing malformed-length/dense-overlap/shrink tests remain untouched. No new fuel/IRQ execution evidence is claimed: root should include the existing cancellation/source-store gates if broader verification is needed.

All original test-file bytes before the appended module are retained. The nine-local original control source is unchanged and must run unchanged at default allowances with both existing trace flags. The old control failed before coherent/effect assertions; this proposal does not establish a repaired outcome.

Root execution order: normal bootstrap regeneration FIRST (ABI generator changed), then new raw ABI tests and existing sparse-array regressions; then the exact original nine-local control at default allowance. Preserve all raw failures. No producer is launched by this packet.
