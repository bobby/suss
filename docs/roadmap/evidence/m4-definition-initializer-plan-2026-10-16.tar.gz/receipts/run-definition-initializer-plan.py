from pathlib import Path
import subprocess,os,json,hashlib,time
root=Path('/home/bobby/Work/code/bobby/suss-m4-definition-initializer-plan')
cache=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(cache/'definition-initializer-target'),RAYON_NUM_THREADS='2')
files=[p for p in (root/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']]+[p for p in (root/'runtime/bootstrap').glob('*') if p.is_file()]
freeze={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
state={'base':'8fa6c3f','started':time.time(),'freeze':freeze,'stages':[],'current':None}
out=cache/'definition-initializer-plan-result.json'
def save():out.write_text(json.dumps(state,indent=2)+'\n')
stages=[
 ('native',['cargo','test','-p','suss-compile','--locked','--lib','initializer_plan','--','--test-threads=2','--nocapture'],True),
 ('sharing',['cargo','test','-p','suss-compile','--locked','--lib','portable_macro_graph::sharing_tests','--','--test-threads=2','--nocapture'],True),
 ('authored',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_initializer_plan','--','--test-threads=2','--nocapture'],True),
 ('source-asts',['cargo','test','-p','suss-cli','--locked','--no-fail-fast','--test','compiled_macro_constructor_source_asts','--test','compiled_macro_global_reference_asts','--test','compiled_macro_cross_invocation_identity_probe','--','--test-threads=2','--nocapture'],False),
 ('declaration-profile',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_declaration_metadata','declaration_metadata_merge_and_tag_precedence_match_pinned_analyzer','--','--test-threads=2','--nocapture'],False),
]
for name,cmd,stop in stages:
 if name in ['native','sharing']:continue
 state['current']=name;save();log=cache/f'definition-initializer-{name}.log';stage={'name':name,'command':cmd,'log':str(log)};state['stages'].append(stage);save()
 runenv=env.copy()
 if name=='declaration-profile':runenv.update(SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1',SUSS_RAW_KEY_TRACE='1')
 started=time.time()
 with log.open('w') as f:r=subprocess.run(cmd,cwd=root,env=runenv,stdout=f,stderr=subprocess.STDOUT)
 stage.update(exit=r.returncode,seconds=time.time()-started);save()
 if stop and r.returncode:state['stopped_on_unexpected_focused_failure']=name;break
state.update(current=None,seconds=time.time()-state['started'],source_unchanged=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in freeze.items()));save()
print(json.dumps({k:v for k,v in state.items() if k!='freeze'},indent=2))
