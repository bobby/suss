from pathlib import Path
import hashlib,json,tarfile,io,subprocess
r=Path('/home/bobby/Work/code/bobby/suss-m4-definition-initializer-plan'); c=Path('/home/bobby/.cache/suss-m4-work')
state=json.loads((c/'definition-initializer-plan-result.json').read_text());assert state['current'] is None and state['source_unchanged']
payload={}
for p,h in state['freeze'].items():
 b=(r/p).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+p]=b
extra=['Cargo.toml','Cargo.lock','crates/suss-core/Cargo.toml','crates/suss-reader/Cargo.toml','crates/suss-compile/Cargo.toml','crates/suss-cli/Cargo.toml','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','runtime/core-import/LICENSE','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json','vendor/wasi/wasi-wit-0.3.1/cli/cli.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit']
for p in extra:
 if (r/p).is_file():payload['snapshot/'+p]=(r/p).read_bytes()
compiler_paths=[p.removeprefix('snapshot/') for p in payload if p.startswith('snapshot/') and (p.removeprefix('snapshot/') in extra[:5] or p=='snapshot/crates/suss-compile/build.rs' or any(p.startswith('snapshot/crates/'+n+'/src/') and p.endswith(('.rs','.sus')) for n in ['suss-core','suss-reader','suss-compile']) or p.removeprefix('snapshot/') in extra[9:])]
h=hashlib.sha256()
for p in sorted(compiler_paths,key=lambda p:tuple(p.split("/"))):
 b=payload['snapshot/'+p];n=p.encode();h.update(len(n).to_bytes(8,'little'));h.update(n);h.update(len(b).to_bytes(8,'little'));h.update(b)
checks={}
for phase in ['macro','runtime']:
 m=json.loads(payload[f'snapshot/runtime/bootstrap/{phase}.json']);checks[phase]={'compiler':h.hexdigest()==m['compiler_source_sha256'],'core':hashlib.sha256(payload['snapshot/runtime/core-import/suss/core.sus']).hexdigest()==m['source_sha256'],'dependencies':hashlib.sha256(payload['snapshot/runtime/core-import/manifest.json']).hexdigest()==m['dependency_graph_sha256'],'wasm':hashlib.sha256(payload[f'snapshot/runtime/bootstrap/{phase}.wasm']).hexdigest()==m['wasm_sha256']}
assert all(all(v.values()) for v in checks.values()),checks
for p in c.glob('definition-initializer*'):
 if p.is_file() and p.suffix in ['.log','.json','.rs','.py']:payload['receipts/'+p.name]=p.read_bytes()
for n in ['run-definition-initializer-plan.py','compare-definition-initializer-base.py','compare-definition-initializer-base-global.py','package-definition-initializer.py','compact-raw-keys-declaration-profile.log','compact-raw-keys-declaration-profile-result.json','compact-raw-keys-regressions.log','compact-raw-keys-regressions-result.json']:
 payload['receipts/'+n]=(c/n).read_bytes()
payload['change.patch']=subprocess.check_output(['git','diff','--','crates/suss-compile/src/portable_macro_graph.rs'],cwd=r)
payload['audit.json']=json.dumps({'base':'8fa6c3f','freeze_count':len(state['freeze']),'fingerprints':checks,'support_inputs_capture':'post-test current bytes; test source freeze checked before/after; supporting inputs not separately frozen before execution','scope':'Focused bounded change; no full workspace baseline or acceptance claim; prior declaration profile supplied for progress context only.'},indent=2).encode()
manifest={p:hashlib.sha256(b).hexdigest() for p,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=r/'docs/roadmap/evidence/m4-definition-initializer-plan-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for p,b in sorted(payload.items()):
  i=tarfile.TarInfo(p);i.size=len(b);t.addfile(i,io.BytesIO(b))
with tarfile.open(out) as t:
 assert all(hashlib.sha256(t.extractfile(p).read()).hexdigest()==h for p,h in manifest.items())
print(json.dumps({'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'freeze':len(state['freeze']),'fingerprints':checks},indent=2))
