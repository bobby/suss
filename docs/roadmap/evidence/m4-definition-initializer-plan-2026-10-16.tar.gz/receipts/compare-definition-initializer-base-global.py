from pathlib import Path
import subprocess,os,json,hashlib,time,shutil
r=Path('/home/bobby/Work/code/bobby/suss-m4-definition-initializer-plan');c=Path('/home/bobby/.cache/suss-m4-work')
paths=['crates/suss-compile/src/portable_macro_graph.rs','crates/suss-compile/src/portable_macro_graph/initializer_plan.rs']+[f'runtime/bootstrap/{phase}.{ext}' for phase in ['macro','runtime'] for ext in ['json','wasm']]
old={p:(r/p).read_bytes() for p in paths};receipt={'base':'8fa6c3f','command':['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_global_reference_asts','captured_global_declarations_supply_var_ast_fields_without_catalog_mutation','--','--test-threads=2','--nocapture']}
try:
 for p in paths:
  if p.endswith('/initializer_plan.rs'):(r/p).unlink()
  else:(r/p).write_bytes(subprocess.check_output(['git','show','8fa6c3f:'+p],cwd=r))
 env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'definition-initializer-target'),RAYON_NUM_THREADS='2')
 with (c/'definition-initializer-base-global-comparison.log').open('w') as f:
  start=time.time();run=subprocess.run(receipt['command'],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT);receipt.update(exit=run.returncode,seconds=time.time()-start)
finally:
 for p,b in old.items():(r/p).write_bytes(b)
 receipt['restored']=all((r/p).read_bytes()==b for p,b in old.items());receipt['restored_hashes']={p:hashlib.sha256(b).hexdigest() for p,b in old.items()};(c/'definition-initializer-base-global-comparison.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
