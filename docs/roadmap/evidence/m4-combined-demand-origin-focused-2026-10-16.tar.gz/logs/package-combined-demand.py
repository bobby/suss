from pathlib import Path
import json,hashlib,tarfile,io,re
c=Path(__file__).parent;r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-acceptance')
d=json.loads((c/'combined-demand-focused-result.json').read_text());assert d['current'] is None and d['source_unchanged'];assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in d['freeze'].items())
rows=[]
for stage in d['stages']:
 s=(c/('combined-demand-focused-'+stage['name']+'.log')).read_text(errors='replace');totals=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored',s);assert len(totals)==1
 rows.append(dict(stage,passed=int(totals[0][0]),failed=int(totals[0][1]),ignored=int(totals[0][2])))
summary={'stages':rows,'totals':{k:sum(x[k] for x in rows) for k in ['passed','failed','ignored']},'source_freeze_paths':len(d['freeze']),'limits':'Focused run only; six retained fuel failures. No full baseline or CI at this combined source. Source-tag regression tests not included.'}
assert summary['totals']==dict(passed=62,failed=6,ignored=0)
(c/'combined-demand-classification.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[c/('combined-demand-focused-'+s['name']+'.log') for s in rows]+[c/n for n in ['combined-demand-bootstrap.log','combined-demand-focused-result.json','combined-demand-classification.json','run-combined-demand-focused.py','combined-demand-origin.patch','combined-demand-comparator-setup.txt']]+[c/'map-combined-demand'/n for n in ['map-transport-observations.json','comparison.json']]+[Path(__file__)]
a=r/'docs/roadmap/evidence/m4-combined-demand-origin-focused-2026-10-16.tar.gz';manifest={}
with tarfile.open(a,'w:gz') as t:
 for p in files:
  name='logs/'+p.name;manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest();t.add(p,arcname=name)
 for n in sorted(d['freeze']):
  p=r/n;name='snapshot/'+n;manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest();t.add(p,arcname=name)
 b=(json.dumps(manifest,indent=2)+'\n').encode();i=tarfile.TarInfo('SHA256.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
sha=hashlib.sha256(a.read_bytes()).hexdigest();print(sha,len(manifest),summary['totals'])
with (r/'docs/roadmap/handoff.md').open('a') as f:f.write('\n### Combined demand-located reader validation (2026-10-16)\n\nApplied the reviewed `3055a56..65b565f` source delta to `4ce5ddb` and regenerated both bootstraps (terminal exit0). The focused runner completed with 62 pass executions, six retained fuel failures and zero ignored. Reader24, origin16, source locations10, public cumulative10, collection empty-do1 and pinned map1 passed. The core environment, collection original children and unordered effects, control, constructor and captured-global preservation cases still exhausted default fuel. These six gaps remain unresolved; the two source-tag cases were not included in this cohort. No full baseline or CI success is claimed for this combined source.\n\nThe complete unchanged pinned Jank map body produced69 ordered assertions: independent comparison62 host passes,7 guest judgments,0fail/missing/skipped/namespace/test failures. All '+str(len(d['freeze']))+' frozen Rust/Suss/bootstrap paths remained unchanged. The initial standalone comparator import lacked the scripts search path; the corrected invocation used the unchanged comparator and observations.\n\nCommands, terminal stage receipts, raw failures, observations, comparison and source snapshots are in `'+str(a.relative_to(r))+'`, SHA-256 `'+sha+'` ('+str(len(manifest))+' payloads). This is focused transport evidence, not milestone completion. Next unblocked work: repair the cold-identifier source-tag fuel regression and measure the separate paged-entry storage experiment; require issue acceptance, independent review and final-head CI before readiness.\n')
