from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-combined-acceptance');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'combined-acceptance-target'),RAYON_NUM_THREADS='2',SUSS_CLOJURE_TEST_SUITE_CAPTURE=str(c/'map-combined-demand'))
files=[p for p in (r/'crates').rglob('*') if p.suffix in ['.rs','.sus']]+list((r/'runtime/bootstrap').glob('*'));freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()};state={'base':'4ce5ddb','integrated':'65b565f','freeze':freeze,'stages':[]};receipt=c/'combined-demand-focused-result.json'
commands=[('reader',['cargo','test','-p','suss-reader','--lib','--locked','--','--test-threads=2','--nocapture']),('origin',['cargo','test','-p','suss-compile','--lib','--locked','portable::origin','--','--test-threads=2','--nocapture'])]
for name,target,filter in [('locations','compiled_macro_form_source_metadata',''),('core','compiled_macro_core_environment',''),('collection','compiled_macro_collection_source_asts',''),('control','compiled_macro_control_source_asts','control_source_nodes_match_genuine_primary_children_and_forms_after_gc'),('constructor','compiled_macro_constructor_source_asts','constructor_source_nodes_match_pinned_children_tags_and_class_facts_after_gc'),('globals','compiled_macro_global_reference_asts','captured_global_declarations_supply_var_ast_fields_without_catalog_mutation'),('public','compiled_macro_cumulative_fuel','')]:
 commands.append((name,['cargo','test','-p','suss-cli','--locked','--test',target]+([filter] if filter else [])+['--','--test-threads=2','--nocapture']))
commands.append(('map',['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--test-threads=2','--nocapture']))
for name,cmd in commands:
 state['current']=name;receipt.write_text(json.dumps(state,indent=2)+'\n');start=time.time()
 with (c/('combined-demand-focused-'+name+'.log')).open('w') as log:child=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 state['stages'].append({'name':name,'command':cmd,'exit':child.returncode,'seconds':time.time()-start})
state.update(current=None,source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in freeze.items()));receipt.write_text(json.dumps(state,indent=2)+'\n')
