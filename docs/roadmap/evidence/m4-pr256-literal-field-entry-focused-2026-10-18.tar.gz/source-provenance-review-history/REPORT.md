# Literal-provenance dependency on the frozen slot port

CACHE-ONLY source proposal; no repository/index/branch/BOOT changes, no Cargo or guest tests. Base4f48ea6 plus EXACT frozen slot packet manifestSHA4b0b51efce0e18475cc79e2190edc556306098f7330bd6b2f0e448a566de42f3 (patch0d2324b0…). That sourcepacket remains untouched. Candidate current-slotafter preimages captured into before/, proposed files into after/. Originalsourcepatches+hashes+context adaptation recorded. Cache gitapply--checkPASS; Rustfmtparse is syntax-only only, no typecheck or execution.

## What dependency is actually identifiable

The isolated slot port's currently reported source-tags0/2 result cannot inherit the historical combined4ab1/1 result. Inference reportedly advances324..356→382..414; invocation stays388..413. These are stage outcomes supplied by root, not a final new-controller analysis; whole-run parser remains separately gated.

Smallest SELF-CONTAINED historical provenance implementation found: **ec0eea2 +be6a219 +483f26a**, rather than ec+namespace alone. ec supplies private literal-origin distinction+construction; be6 supplies exact binding/parameter/field constructor eligibility and vector/AST literal positions;483 supplies namespaceconstructor positions. They constitute one coherent pinned constructor-provenance repair. Minimal subset of individual annotations sufficient for invocationPASS is UNKNOWN; do not arbitrarily select favorable names or claim threecommits provennecessary/sufficient for currenttestPASS.

After these three source deltas are layered over current slotafter, Before the metering correction, proposed Graph, FormBridge and metadata_expectations.rs were byte-exact historical4ab source. Graph now additionally routes literal-aware entry storage through prepaid builders; original expression and literal-annotation order remain unchanged. The old historical diff belongs to the preserved pre-meter-fix packet. No unrelated full-file replacement occurred: each original changed hunk applied to captured currentafter; only FormBridge addedhelper insertion trimmed two leading contextlines around the extra slotlogfield. Sourceprovenance exactcommits inmanifest.

Other historical inputs still differ: primitive emitter has89line difference vs current4f, HIR has main's destructuring changes; these are deliberately NOT imported (reference diffs retained). Thus recreating these three keypaths is NOT proof currentfirstPR reproduces historicalinvocationPASS. Trial must run the unchangedoriginaltag test and actualcriteria. If still0/2, additional historical dependency remains unknown; do not substitute prefixgains.

## Seven-path dependency set / criterion mapping

| Path | Required contribution | Contract proof/gate |
|---|---|---|
| portable_macro_graph.rs | Private AnalyzerLiteralKeyword constructor; FieldKey Cold/Literal; separate2keytables; explicit pinned constructor sites; literal recipeflag | Same text reader/dynamic/cold keys never share initial-memo literalrecipe; actual immutable bindingrole guards; originalsource-tags criteria remain unchanged |
| portable_macro_data.rs | Private literalconstructor initializes memo to metered pinnedcompileconstant hash; ordinaryidentifier stillNone | Nativehash matches existing hirconstant code; typedfuelIRQ; actualliveIHash stillcalled for collectionconstruction |
| portable_macro_graph/metadata_expectations.rs | Ignore originflag ONLY in logical Form construction | Initialphysicalmemo stillcaptured/validated by originalfacts; no logicalguestsyntax substitution |
| portable_macro_graph/reuse.rs | Test-only literalNone explicit in3ordinaryRecipe constructors | No change to private-slot/cert/fallback productionlogic |
| portable_macro_graph/analyzer_literal_tests.rs NEW | Five focused sourceorigin/memo tests | Same-text coldreader/symbol/dynamic/Suss controls, GC/livehashorder, originalnonnil cannotgainniltransitionauthority, role exclusions, parameter sourcefieldcold, namespacefixedpositions |
| suss-cli/tests/compiled_macro_analyzer_literal_memos.rs NEW | Two actualenv/vector memo observation tests, unchangedhistoricalfixtures | Bothcallerphases, repeated afterGC, sourceargument/source-metadatacold, actualfields/values retained |

One new identity test plus Graph5 and entry-builder2 =>8new native tests; CLI2 =>10new tests total. Existing17slotnative safety tests remain mandatoryunchanged. Frozen source-tags fixture NOT in patch. No primitivebackend/ABI/method/Watch/controller changes needed to typewire this proposal. NormalBOOT4 mustregenerate on eventualappliedsource; no laterBOOT copied.

## Exact provenance and authority boundaries

Pinned ClojureScriptc4295f303100bbf5afac449242d30bca1126f1a1, matches4fsubmodule entry AND actualindependentpinnedcheckout. provenance.json retains sourceSHA, sourceanchors; originalcomments retain compiler.cljc368–381 emits-keyword initialization contract and analyzer literalcreation sites. This is compiler-generatedliteral INITIALSTATE, not evaluatinghashesearly for arbitraryreader values. License/pin established by existingrepository portablecore provenance; no JVMcode imported.

Explicit origins: empty-envcontext/ns/locals/fn-scope; local/AST field literals; be6 role-gated genuineLet/Loop/Argument/MethodArgument constructors; actualparse-typefield constants; namespace ns-info/require-info/defs constructor fields. Namespace suss/refers remainsCold. FieldKey::From<&str> ALWAYS Cold. Native token constructor's innerfield is private to Graph; guestForm/SessionValue cannotmintit; annotations reside atsourceconstruction, not allowlistlookup. literal-sites.json enumerates103annotatedlines for review; this count includes helper/testsites and is NOT dynamiccount/coverage.

Identifier recipes have explicit optionalorigin; keywordtable split prevents same-text coldkey inadvertentlyhitting literalrecipe or viceversa. Symbols and arbitrarysource Forms retainNone; literalnamespace fields only actualfixedcreationpositions. Fullfactory/method/class/sourcefacts and allcoldmemo/authentication policies unchanged. Originalnilprotected eligibility unchanged in constructor/watch code (thosefiles absent). Initialnonnil literal state is ordinaryexactcaptureddata, NOT a protectedwrite receipt. No numericresult mintsreceipt and no replacedIHashauthority allowance. Livehash/equalitydispatch and map/set construction/order still execute. Nativehash charges iterator/UTF16packing/arithmetic; maps charge actualextraFieldKey representation. No new quota or lower tariff.

Known limitation: literalinitializednumeric memo is NOT eligible for originallynil protectedtransition. Clearing/rewarming it later must not silentlycertify; focusednegative explicitlyrejects. Does not fix generalnonnilcustomIHash/sourcecachecert limitations from latercoherent work. Hashcollision/reader-effects/sourcealias validations remain original. Do not broadenliteralannotation by name to forceperformance.

## Review and execution gate

Keep current controller/sourcefrozen until terminal+drained; do NOT apply now. Independentreview exactproposedsource first. BeforeFIRSTCargo eventualfreeze uniontracked+ALLmanifestpaths; two newfiles untracked (Graphmodule+CLItarget), plus existing slot_log.rs from dependency. Capture all beforeBOOT+afterBOOT and terminal. Run sourceorigin/entry-builder8native+CLI2 semanticgates, old17slotguards, then BOTH unchangedsource-tags (exactnames) under originalallowances. At least invocationmustACTUALLYPASS before claiming reproduced historicalacceptance progress. Full firstPR252/241 closure remains separate; no broad acceptanceclaim.

Original8fda18a actualenv effectfixture is preserved in reference/ for possiblefocusedtest-only followup, NOT included in candidate or claimed executed. Graphnative tests already assertliveIHash observednon-nil/coldmix and namespace9callbacks; actualenvcustom-effect coverage would strengthenlaterindependentreview. Do not treat this referencefile as automaticallyregisteredtest.


## Main takeover: allocation-order correction

The original six-path packet is preserved under pre-meter-fix-packet with all six original afterimage hashes verified. The current seven-path candidate adds field_entry_work.rs and rewrites27 initial buffers plus86 push/extend sites. Fixed arrays count syntax without evaluating entries, prepay the added tuple backing extent and initialization/builder controls, allocate capacity, then evaluate the original expressions once in order. Dynamic growth prepays extra requested backing plus live relocation before reserve_exact; ordinary Value-pair buffers are unchanged. Both former late map fees are removed to avoid double charging. Generic payload support covers borrowed-HIR group entries as well as Value entries. No literal positions are added, no baseline fee is reduced, and no previously tested behavior is claimed here.

Two added representative regressions cover initial acquisition, later growth and fallible form construction; they retain source/cache integrity, exercise entry IRQ, and require fresh retry. Their allowances are derived from actual fresh-graph costs. They do not claim exhaustive whole-compiler or mid-operation IRQ coverage. Native8/CLI2 plus the existing17 slot/reuse guards and both original source-tag tests must execute after review.

Author agent stopped with a model-capacity error after preserving the implementation. Main reviewed the cached code, verified the transformation audit and re-froze this packet. Syntax parsing/apply-check is not typechecking or guest execution. No repository/index/BOOT changes or Cargo have occurred.
