from pathlib import Path
import re,json
P=Path(__file__).parent;q=P/'after/crates/suss-compile/src/portable_macro_graph.rs';s=q.read_text();sites=[]
# Bracket matcher which ignores comments and Rust string/char literals.
skip=re.compile(r'//[^\n]*|/\*.*?\*/|r(?P<h>\#*)".*?"(?P=h)|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\\n])\'',re.S)
def end_bracket(text,start):
 chars={'[':']','(':')','{':'}'};stack=[chars[text[start]]];i=start+1
 while stack:
  m=skip.match(text,i)
  if m:i=m.end();continue
  c=text[i]
  if c in chars:stack.append(chars[c])
  elif c in '])}':assert c==stack.pop(),(i,c)
  i+=1
 return i
# All nonempty Vec initializers whose first tuple explicitly establishes FieldKey.
ranges=[]
for m in re.finditer(r'vec!\[',s):
 start=m.end()-1;end=end_bracket(s,start);body=s[start+1:end-1]
 if re.match(r'\s*\(\s*FieldKey::',body):ranges.append((m.start(),end,body));sites.append({'kind':'initial Vec','old_line':s.count('\n',0,m.start())+1,'sample':body.strip()[:120]})
for start,end,body in reversed(ranges):s=s[:start]+'field_entries!(self; ['+body+'])'+s[end:]
# Mutation sites in ONLY functions whose locals are FieldKey-entry vectors.
functions=['local_record','field_record','scope_record','ast_record']
for fn in functions:
 m=re.search(r'    fn '+fn+r'\b',s);assert m;brace=s.index('{',m.end());end=end_bracket(s,brace);body=s[brace+1:end-1];edits=[]
 # AST has a nested resolved-global `entries` Vec<(Value,Value)>: exclude it.
 fieldvars={'local_record':{'entries','env'},'field_record':{'entries'},'scope_record':{'info','entries'},'ast_record':{'fields','constant'}}[fn]
 for match in re.finditer(r'\b('+ '|'.join(sorted(fieldvars))+r')\.(push|extend)\(',body):
  var,op=match[1],match[2];start=match.end()-1;finish=end_bracket(body,start);expr=body[start+1:finish-1]
  if op=='push':new='field_push!(self, '+var+'; '+expr+')'
  else:
   assert expr.lstrip().startswith('[') and expr.rstrip().endswith(']');new='field_extend!(self, '+var+'; '+expr.strip()+')'
  edits.append((match.start(),finish,new));sites.append({'kind':op,'function':fn,'variable':var,'sample':expr.strip()[:100]})
 for a,b,new in reversed(edits):body=body[:a]+new+body[b:]
 s=s[:brace+1]+body+s[end-1:]
# Remove ONLY the two obsolete late charges, never any baseline fee.
late='        self.charge(entries.len().saturating_mul(std::mem::size_of::<K>().saturating_sub(std::mem::size_of::<&str>())))?;\n';assert s.count(late)==2;s=s.replace(late,'')
anchor='mod occurrence_work;\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'#[macro_use]\nmod field_entry_work;\n')
q.write_text(s);(P/'field-entry-site-audit.json').write_text(json.dumps({'rewritten_sites':sites,'initializers':len(ranges),'mutation_count':len(sites)-len(ranges),'notes':['All FieldKey tuple vector initializers explicitly start with FieldKey; empty group Vecs allocate nothing.','Mutation vars localized per function; AST inner resolved-declaration entries are Vec<(Value,Value)> and unchanged.','No FieldKey Vec clone/retain/collect/reserve calls remain outside helpers; final collect converts to smaller Value pairs, not FieldKey tuples.','Cold &str buffers and ordinary Value/Value recipe buffers unchanged.']},indent=2)+'\n');print('initializers',len(ranges),'mutations',len(sites)-len(ranges))
