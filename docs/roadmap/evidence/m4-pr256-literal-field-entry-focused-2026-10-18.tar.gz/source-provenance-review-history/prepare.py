from pathlib import Path
import subprocess,json,hashlib,re,difflib
R=Path('/home/bobby/Work/code/bobby/suss');P=Path(__file__).parent;S=P.parent/'pr256-private-slot-log-downport-source-v1';base='4f48ea6bd7d2e198b9dd82086e4abf4e118e7a7b';commits=['ec0eea2655c71f9e4957cf1b0cbd8727c7ec97b1','be6a219b714ea9730c88c66c9a098ea60bb989d3','483f26a7e42f1575fb415f7514da1ecfb24e94cf']
files=['crates/suss-compile/src/portable_macro_data.rs','crates/suss-compile/src/portable_macro_graph.rs','crates/suss-compile/src/portable_macro_graph/metadata_expectations.rs','crates/suss-compile/src/portable_macro_graph/reuse.rs','crates/suss-compile/src/portable_macro_graph/analyzer_literal_tests.rs','crates/suss-cli/tests/compiled_macro_analyzer_literal_memos.rs']
G=lambda *a:subprocess.check_output(['git',*a],cwd=R);H=lambda b:hashlib.sha256(b).hexdigest();before={};state={};adapt=[]
slot=json.loads((S/'manifest.json').read_text())
for n in files:
 if n in slot['files']:
  data=(S/'after'/n).read_bytes();assert H(data)==slot['files'][n]
 else:
  r=subprocess.run(['git','show',base+':'+n],cwd=R,capture_output=True);data=r.stdout if r.returncode==0 else None
 before[n]=data
 if data is not None:state[n]=data.decode()
for commit in commits:
 patch=G('diff',commit+'^',commit,'--',*files).decode();(P/(commit[:7]+'.original.patch')).write_text(patch)
 for section in patch.split('diff --git ')[1:]:
  head=section.splitlines()[0];n=head.split(' b/',1)[1]
  if n not in state:
   assert before[n] is None;state[n]=G('show',commit+':'+n).decode();continue
  s=state[n]
  for idx,part in enumerate(re.split(r'^@@[^\n]*\n',section,flags=re.M)[1:]):
   lines=[x for x in part.splitlines(True) if x[:1] in (' ','+','-')];old=''.join(x[1:] for x in lines if x[0]!='+');new=''.join(x[1:] for x in lines if x[0]!='-')
   if old and s.count(old)==1:s=s.replace(old,new,1);continue
   pre=0
   while pre<len(lines) and lines[pre][0]==' ':pre+=1
   post=0
   while post<len(lines)-pre and lines[-1-post][0]==' ':post+=1
   found=False
   for cut in range(pre+post+1):
    for l in range(pre+1):
     rr=cut-l
     if not 0<=rr<=post:continue
     subset=lines[l:len(lines)-rr if rr else None];old=''.join(x[1:] for x in subset if x[0]!='+');new=''.join(x[1:] for x in subset if x[0]!='-')
     if old and s.count(old)==1:
      s=s.replace(old,new,1);adapt.append({'commit':commit,'path':n,'hunk':idx,'trim_prefix':l,'trim_suffix':rr});found=True;break
    if found:break
   assert found,(commit,n,idx,old[:120])
  state[n]=s
patch=''
for n in files:
 if before[n] is not None:
  q=P/'before'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(before[n])
 q=P/'after'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(state[n])
 patch+=''.join(difflib.unified_diff((before[n] or b'').decode().splitlines(True),state[n].splitlines(True),fromfile='a/'+n if before[n] is not None else '/dev/null',tofile='b/'+n))
(P/'candidate.patch').write_text(patch)
m={'base':base,'overlay_dependency':str(S/'manifest.json'),'overlay_manifest_sha256':H((S/'manifest.json').read_bytes()),'overlay_patch_sha256':slot['patch_sha256'],'origin_commits':commits,'preimages':{n:H(v) if v is not None else None for n,v in before.items()},'files':{n:H(state[n].encode()) for n in files},'patch_sha256':H(patch.encode()),'adaptations':adapt,'executed':False,'authority_limit':'literal constructor initial state only; no receipts/method/source-authority guard changes'};(P/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
r=subprocess.run(['git','apply','--check',str(P/'candidate.patch')],cwd=P/'before',text=True,capture_output=True);(P/'apply-check.json').write_text(json.dumps({'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n');assert r.returncode==0,r.stderr
print(json.dumps(m,indent=2))
