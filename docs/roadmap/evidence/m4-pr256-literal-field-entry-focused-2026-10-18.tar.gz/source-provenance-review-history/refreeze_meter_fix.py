from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
p=Path(__file__).resolve().parent
h=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((p/'manifest.json').read_text())
old=p/'pre-meter-fix-packet';old.mkdir(exist_ok=True)
for name in ['candidate.patch','manifest.json','REPORT.md','focused-selection.json','provenance.json','literal-sites.json']:
 if not (old/name).exists():shutil.copyfile(p/name,old/name)
if not (old/'after').exists():
 shutil.copytree(p/'before',old/'after')
 subprocess.run(['git','apply','--no-index',str(old/'candidate.patch')],cwd=old/'after',check=True)
 for n,digest in m['files'].items():assert h((old/'after'/n).read_bytes())==digest,n
new='crates/suss-compile/src/portable_macro_graph/field_entry_work.rs'
m['preimages'][new]=None
m['files']={n:h((p/'after'/n).read_bytes()) for n in m['preimages']}
parts=[]
for n,pre in m['preimages'].items():
 before=(p/'before'/n).read_text() if pre is not None else ''
 after=(p/'after'/n).read_text()
 parts.append(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+n if pre is not None else '/dev/null',tofile='b/'+n)))
(p/'candidate.patch').write_text(''.join(parts));m['patch_sha256']=h((p/'candidate.patch').read_bytes());m['metering_correction']='Added FieldKey backing/init/relocation and builder controls prepaid before every allocation/fill/growth; both old late fees removed; original literal annotation sequence preserved.'
(p/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
sel=json.loads((old/'focused-selection.json').read_text());sel.append({'path':new,'new_names':['literal_entry_builders_prepaid_failures_preserve_source_and_fresh_retry','literal_entry_late_invalid_source_keeps_original_guard_and_recovers']})
(p/'focused-selection.json').write_text(json.dumps(sel,indent=2)+'\n')
s=(old/'REPORT.md').read_text().replace('Six-path dependency set','Seven-path dependency set').replace('Rustfmtparse6pathsPASS','Rustfmtparse is syntax-only').replace('proposed Graph, FormBridge and metadata_expectations.rs are BYTE-EXACT historical4ab source. vs-historical-4ab-Graph.diff is EMPTY.','Before the metering correction, proposed Graph, FormBridge and metadata_expectations.rs were byte-exact historical4ab source. Graph now additionally routes literal-aware entry storage through prepaid builders; original expression and literal-annotation order remain unchanged. The old historical diff belongs to the preserved pre-meter-fix packet.').replace('One newidentitylibtest (analyzer_literal_stream_hash_matches_constants_and_recovers_after_fuel_irq) plus Graph5 =>6newnative tests; CLI2 =>8new tests total.','One new identity test plus Graph5 and entry-builder2 =>8new native tests; CLI2 =>10new tests total.').replace('Run sourceorigin6native+CLI2 semanticgates','Run sourceorigin/entry-builder8native+CLI2 semanticgates')
s+='''\n\n## Main takeover: allocation-order correction\n\nThe original six-path packet is preserved under pre-meter-fix-packet with all six original afterimage hashes verified. The current seven-path candidate adds field_entry_work.rs and rewrites27 initial buffers plus86 push/extend sites. Fixed arrays count syntax without evaluating entries, prepay the added tuple backing extent and initialization/builder controls, allocate capacity, then evaluate the original expressions once in order. Dynamic growth prepays extra requested backing plus live relocation before reserve_exact; ordinary Value-pair buffers are unchanged. Both former late map fees are removed to avoid double charging. Generic payload support covers borrowed-HIR group entries as well as Value entries. No literal positions are added, no baseline fee is reduced, and no previously tested behavior is claimed here.\n\nTwo added representative regressions cover initial acquisition, later growth and fallible form construction; they retain source/cache integrity, exercise entry IRQ, and require fresh retry. Their allowances are derived from actual fresh-graph costs. They do not claim exhaustive whole-compiler or mid-operation IRQ coverage. Native8/CLI2 plus the existing17 slot/reuse guards and both original source-tag tests must execute after review.\n\nAuthor agent stopped with a model-capacity error after preserving the implementation. Main reviewed the cached code, verified the transformation audit and re-froze this packet. Syntax parsing/apply-check is not typechecking or guest execution. No repository/index/BOOT changes or Cargo have occurred.\n'''
(p/'REPORT.md').write_text(s)
trial=p/'meter-apply-check';shutil.rmtree(trial,ignore_errors=True);shutil.copytree(p/'before',trial)
r=subprocess.run(['git','apply','--no-index','--check',str(p/'candidate.patch')],cwd=trial,capture_output=True,text=True)
(p/'meter-fix-apply-check.json').write_text(json.dumps({'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n');assert r.returncode==0
subprocess.run(['git','apply','--no-index',str(p/'candidate.patch')],cwd=trial,check=True)
assert all(h((trial/n).read_bytes())==digest for n,digest in m['files'].items())
freeze={'author':'main after preserved agent capacity failure','source_base':'c170e116216ba26d3cb9b48b7c778ae6f185d4c8','source_preimages_equal_c170':True,'manifest_sha256':h((p/'manifest.json').read_bytes()),'patch_sha256':m['patch_sha256'],'selection_sha256':h((p/'focused-selection.json').read_bytes()),'paths':len(m['files']),'new_native_tests':8,'new_cli_tests':2,'executed':False}
for n,digest in m['preimages'].items():
 actual=subprocess.run(['git','show','c170e11:'+n],cwd='/home/bobby/Work/code/bobby/suss',capture_output=True)
 assert (actual.returncode!=0) if digest is None else h(actual.stdout)==digest,n
(p/'author-final-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');print(json.dumps(freeze,indent=2))
