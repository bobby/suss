Prepared ONLY; no source/Cargo/BOOT writes or execution. Source manifest280439… patch285885… at author-final-freeze.

Main mustapply exact7sourcefiles atop cleantrackedc170 AFTERCarver sourceGO. Driver verifies preimages againstGitc170 (including3pathsABSENTinbase), actualinstalledpostimages andnoothertrackedchanges. Before FIRSTCargo capturetrackedUNIONALL7paths, includingnew analyzer_literal_tests.rs, field_entry_work.rs, CLItest. Onlynormal4BOOToutputdelta allowed duringgeneration; allsubsequentphases immutable. Fullsourcepatch+postimages+before/after snapshots retained.

Selection: lib8=Graph5+field_entry_work2+data streamhash1; newCLI2 mandatoryPASS; oldslot17=fixups11/reuse6 mandatoryPASS; ORIGINALtags2 exactnames (onlytypedfuel allowedcontinue); CoreEnv1/collection1/map1 mandatoryPASS. If allrun32uniqueRustexecutions. Mandatoryfailure stops withremainingUNEXECUTED; no hidden success. Invocation-tags mustPASS before focused_required_targets_success, eveniftagsfuelcontinued. entire_focused_suite_green isseparate, noissue/promotion claim.

Allargv/env/starts/exits/errors/freezes captured; lock+manualexecute+exactCarver source/script/planapproval; SIGTERM/INTdrainONLYownedPGID; productionoverlay intentionallyleft evenonfailure. No newworkspacebaseline. Mapcapture availablefor independent69-ID comparator afterterminal, RustwrapperPASS isnotbyitselfhostproof.
