"""Prepared only. Main installs reviewed production overlay; this driver never applies/restores source."""
from pathlib import Path
import argparse,os,signal,subprocess,time,json,hashlib,fcntl,re,traceback,shutil
P=Path(__file__).resolve().parent;C=P.parent;ROOT=Path('/home/bobby/Work/code/bobby/suss');SRC=C/'pr256-literal-slot-dependency-source-v1';BASE='c170e116216ba26d3cb9b48b7c778ae6f185d4c8';BOOT=['runtime/bootstrap/'+n for n in ['macro.json','macro.wasm','runtime.json','runtime.wasm']];H=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def hashes(paths):return {n:H((ROOT/n).read_bytes()) if (ROOT/n).is_file() else None for n in paths}
def group_live(pgid):return any(x[0]==str(pgid) and not x[1].startswith('Z') for line in subprocess.check_output(['ps','-eo','pgid=,stat='],text=True).splitlines() if len(x:=line.split())==2)
def drain(child):
 if group_live(child.pid):
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 try:child.wait(timeout=10)
 except subprocess.TimeoutExpired:
  if group_live(child.pid):os.killpg(child.pid,signal.SIGKILL)
  child.wait()
 if group_live(child.pid):os.killpg(child.pid,signal.SIGKILL)
 for _ in range(100):
  if not group_live(child.pid):return
  time.sleep(.02)
 raise RuntimeError('Owned process group did not drain')
def interrupt(s,f):raise KeyboardInterrupt('controller signal '+str(s))
def parse(t):
 tests=[];pending=None
 for line in t.splitlines():
  m=re.match(r'^test (\S+) \.\.\. (.*)',line)
  if m:
   assert pending is None;pending=m[1];status=re.match(r'^(ok|FAILED|ignored)(?:$|,)',m[2])
   if status:tests.append({'name':pending,'status':status[1]});pending=None
  elif pending and line in ['ok','FAILED','ignored']:tests.append({'name':pending,'status':line});pending=None
 assert pending is None
 sums=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)];counts=[sum(x[i] for x in sums) for i in range(3)];assert counts==[sum(x['status']==v for x in tests) for v in ['ok','FAILED','ignored']];return tests,counts

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');a=ap.parse_args();assert a.execute,'Prepared ONLY; requires manual --execute and reviewed source/script'
 plan=read(P/'plan.json');review=read(P/'carver-execution-review.json');assert review['reviewer']=='Carver' and review['approved_for_execution'] is True
 assert review['controller_sha256']==H(Path(__file__).read_bytes()) and review['plan_sha256']==H((P/'plan.json').read_bytes())
 assert H((SRC/'manifest.json').read_bytes())==plan['source_manifest_sha256']==review['source_manifest_sha256'];m=read(SRC/'manifest.json')
 assert H((SRC/'candidate.patch').read_bytes())==m['patch_sha256']==plan['source_patch_sha256']
 assert H((SRC/'author-final-freeze.json').read_bytes())==plan['author_final_freeze_sha256'];assert H((SRC/'focused-selection.json').read_bytes())==plan['source_selection_sha256']
 assert len(m['files'])==7 and set(m['files'])==set(m['preimages']) and sum(x is None for x in m['preimages'].values())==3
 assert set(plan['stages'][i]['name'] for i in range(len(plan['stages'])))=={'bootstrap','identity','literal-graph5','field-entry2','literal-stream-hash1','literal-cli2','old-private-fixups11','old-reuse6','source-tags2','core-environment','collection-source','pinned-map'}
 lock=(P/'controller.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not (P/'receipt.json').exists(),'One-shot run; preserve earlier receipts in a new reviewed run directory'
 r={'base':BASE,'terminal':False,'current':'preflight-source-overlay','controller_pid':os.getpid(),'source_manifest_sha256':plan['source_manifest_sha256'],'stages':[],'overlay_policy':'Production code remains installed after all outcomes; NO auto-restore.'};child=None;freeze={};tracked=set()
 def save():
  q=P/'receipt.tmp';q.write_text(json.dumps(r,indent=2)+'\n');q.replace(P/'receipt.json')
 def cache(n,v):(P/n).write_text(json.dumps(v,indent=2)+'\n')
 def snapshot(label,paths):
  for n in paths:
   q=P/'snapshots'/label/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((ROOT/n).read_bytes())
 def unchanged():
  changed=[n for n,h in hashes(freeze).items() if h!=freeze[n]];assert not changed,('source drift',changed)
  assert git('rev-parse','HEAD').decode().strip()==BASE and set(git('ls-files').decode().splitlines())==tracked,'HEAD/tracked inventory drift'
 signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt);save()
 try:
  assert git('rev-parse','HEAD').decode().strip()==BASE,'Root HEAD not c170'
  # Main applies the reviewed source separately. Verify all source-preimages against Git and all installed-postimages.
  assert hashes(m['files'])==m['files'],'Main has not installed exact reviewed7source overlay'
  for n,h in m['preimages'].items():
   v=subprocess.run(['git','cat-file','-e',BASE+':'+n],cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   if h is None:assert v.returncode!=0,n
   else:assert v.returncode==0 and H(git('show',BASE+':'+n))==h,n
   assert H((SRC/'after'/n).read_bytes())==m['files'][n]
  assert set(git('diff','--name-only','HEAD').decode().splitlines())<=set(m['files']),'Unknown tracked changes'
  for n in BOOT:assert H((ROOT/n).read_bytes())==H(git('show',BASE+':'+n)),'BOOT modified before controlled generation'
  tracked=set(git('ls-files').decode().splitlines());paths={n for n in tracked if (ROOT/n).is_file()}|set(m['files']);freeze=hashes(paths);assert all(h is not None for h in freeze.values())
  assert all(n in freeze for n,h in m['preimages'].items() if h is None),'Three newfiles missing before FIRSTCargo'
  cache('before-first-cargo-freeze.json',freeze);cache('installed-source-preimages.json',m['preimages']);snapshot('before-bootstrap',list(m['files'])+BOOT);(P/'tracked-source.patch').write_bytes(git('diff','--binary','HEAD'))
  q=P/'reviewed-source-packet';q.mkdir()
  for n in ['manifest.json','candidate.patch','focused-selection.json','author-final-freeze.json'] :shutil.copyfile(SRC/n,q/n)
  for n in m['files']:
   f=q/'after'/n;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SRC/'after'/n,f)
  assert not any(k.startswith('SUSS_') for k in os.environ),'Unreviewed inherited SUSS environment'
  env=os.environ.copy();env.update(plan['common_environment']);invocation_pass=False
  for st in plan['stages']:
   unchanged();r['current']=st['name'];save();cache(st['name']+'-before-freeze.json',freeze);e=env.copy();e.update(st['environment']);row={'name':st['name'],'argv':st['argv'],'environment_overrides':{**plan['common_environment'],**st['environment']},'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'terminal':False,'policy':st['policy']};r['stages'].append(row);save();start=time.monotonic()
   with (P/(st['name']+'.log')).open('w') as log:
    child=subprocess.Popen(st['argv'],cwd=ROOT,env=e,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['cargo_pid']=child.pid;row['pid']=child.pid;save();code=child.wait()
    if group_live(child.pid):drain(child)
    assert not group_live(child.pid);child=None
   after=hashes(freeze);changed=[n for n,h in freeze.items() if after[n]!=h];row.update(terminal=True,exit=code,seconds=time.monotonic()-start,changed=changed);cache(st['name']+'-after-freeze.json',after);save()
   if st['name']=='bootstrap':
    assert set(changed)<=set(BOOT),'Generation changed nonBOOT input';assert hashes(m['files'])==m['files'] and all(after[n] for n in BOOT)
    freeze=after;cache('post-bootstrap-freeze.json',freeze);snapshot('after-bootstrap',list(m['files'])+BOOT);assert code==0,'BOOT failed';continue
   assert not changed;unchanged()
   if st['name']=='identity':assert code==0,'Identity failure';continue
   text=(P/(st['name']+'.log')).read_text();tests,counts=parse(text);row.update(tests=tests,counts=counts);save()
   assert len(tests)==len(set(x['name'] for x in tests)) and {x['name'] for x in tests}==set(st['expected_names']),'Selection anomaly'
   assert counts[2]==0,'Unexpected ignore'
   if st['name']=='source-tags2':
    name='compiled_source_invocation_tags_distinguish_global_aggregate_and_local_methods';invocation_pass=next(x['status'] for x in tests if x['name']==name)=='ok';r['source_tags_invocation_restored']=invocation_pass;save()
   if code:
    assert st['policy']=='known-fuel-continue' and code==101 and counts[1]>0,'MandatoryPASS gate failure'
    c=re.split(r"^thread '([^']+)' .*?panicked at ([^\n]+):\s*$",text,flags=re.M);bodies={c[i]:c[i+2].split('\ntest ',1)[0] for i in range(1,len(c),3)}
    assert all('all fuel consumed' in bodies.get(x['name'],'') for x in tests if x['status']=='FAILED'),'Unknown/nonfuel failure stops'
   else:assert counts[1]==0
  unchanged();r['all_stages_executed']=True
  r['focused_required_targets_success']=invocation_pass and all(s['exit']==0 for s in r['stages'] if s['name']!='source-tags2')
  r['entire_focused_suite_green']=all(s['exit']==0 for s in r['stages']);r['issue_acceptance_or_promotion_claim']=False
 except BaseException:r['error']=traceback.format_exc();raise
 finally:
  signal.signal(signal.SIGTERM,signal.SIG_IGN);signal.signal(signal.SIGINT,signal.SIG_IGN)
  if child is not None:
   try:drain(child);r['owned_group_drained']=True
   except BaseException:r['drain_error']=traceback.format_exc()
  else:r['owned_group_drained']=True
  r['unexecuted']=[x['name'] for x in plan['stages'] if not any(s['name']==x['name'] and s['terminal'] for s in r['stages'])]
  if freeze:cache('terminal-observed-freeze.json',hashes(freeze))
  r.update(terminal=True,current=None);save()
 print(json.dumps(r),flush=True)
if __name__=='__main__':main()
