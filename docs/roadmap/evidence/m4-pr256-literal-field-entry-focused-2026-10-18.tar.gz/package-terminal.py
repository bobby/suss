"""Terminal-only cache evidence packaging; no source writes, builds, signals or posting."""
from pathlib import Path
import json,re,hashlib,subprocess,os,shutil,tarfile,types,sys,datetime
sys.dont_write_bytecode=True
P=Path(__file__).parent;C=P.parent;D=C/'pr256-literal-slot-validation-controller';SRC=C/'pr256-literal-slot-dependency-source-v1';S=P/'archive-staging';BASE='c170e116216ba26d3cb9b48b7c778ae6f185d4c8';REPO='/home/bobby/Work/code/bobby/suss';H=lambda b:hashlib.sha256(b).hexdigest();L=lambda p:json.loads(p.read_text());G=lambda p:subprocess.check_output(['git','-C',REPO,'show',BASE+':'+p]);BOOT=['runtime/bootstrap/'+n for n in ['macro.json','macro.wasm','runtime.json','runtime.wasm']]
def live(pid):
 try:os.kill(pid,0);return True
 except ProcessLookupError:return False
r=L(D/'receipt.json')
if not r['terminal'] or live(r['controller_pid']) or live(r.get('cargo_pid',r['controller_pid'])):
 pending={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal':r['terminal'],'current':r['current'],'status':'PENDING_TERMINAL_DRAIN_NO_FINAL_ARCHIVE'};(P/'packaging-pending.json').write_text(json.dumps(pending,indent=2)+'\n');print(json.dumps(pending));sys.exit(0)
assert r['owned_group_drained'] and not r.get('drain_error') and r['base']==BASE
S.mkdir(exist_ok=True)
stable={str(f):H(f.read_bytes()) for f in D.rglob('*') if f.is_file() and '__pycache__' not in f.parts}
def cpdir(source,label):
 for f in source.rglob('*'):
  if not f.is_file() or '__pycache__' in f.parts or f.name.endswith(('.tar.gz','.zip')):continue
  q=S/label/f.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,q)
cpdir(D,'executed-controller');cpdir(SRC,'source-provenance-review-history')
packet=D/'reviewed-source-packet';m=L(packet/'manifest.json');plan=L(D/'plan.json');assert H((packet/'manifest.json').read_bytes())==r['source_manifest_sha256']==plan['source_manifest_sha256'];assert H((packet/'candidate.patch').read_bytes())==m['patch_sha256'];assert len(m['files'])==7 and sum(v is None for v in m['preimages'].values())==3
before=L(D/'before-first-cargo-freeze.json');post=L(D/'post-bootstrap-freeze.json');terminal=L(D/'terminal-observed-freeze.json');assert post==terminal and set(post)==set(before) and set(n for n in before if before[n]!=post[n])<=set(BOOT)
assert len(post)==3542
for n,h in m['files'].items():assert before[n]==post[n]==h==H((D/'snapshots/before-bootstrap'/n).read_bytes())==H((D/'snapshots/after-bootstrap'/n).read_bytes())==H((packet/'after'/n).read_bytes())
for n,h in m['preimages'].items():
 if h is None:assert n in before # Actual absence in Gitbase verified by the full tree binding below.
boot={}
for n in BOOT:
 b=(D/'snapshots/after-bootstrap'/n).read_bytes();assert H(b)==post[n];boot[n]={'sha256':H(b),'bytes':len(b)}
(S/'BOOT-SHA256.json').write_text(json.dumps({'kind':'exact_normal_generated_as_tested_outputs','hashes':boot,'current_mutable_root_read':False},indent=2)+'\n')
# Source preimages and all unchanged fullfreeze bytes resolve only exact Gitbase; no mutable root hashes.
tree={}
for line in subprocess.check_output(['git','-C',REPO,'ls-tree','-r',BASE],text=True).splitlines():
 meta,path=line.split('\t',1);mode,typ,oid=meta.split();tree[path]=(typ,oid)
proc=subprocess.Popen(['git','-C',REPO,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);memo={};binding={};overrides=set(m['files'])|set(BOOT)
for path,h in post.items():
 if path not in tree:
  assert path in m['files'] and m['preimages'][path] is None;binding[path]={'kind':'new_untracked_source_before_first_Cargo','executed_sha256':h};continue
 typ,oid=tree[path];assert typ=='blob'
 if oid not in memo:
  proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();assert hdr[1]==b'blob';left=int(hdr[2]);d=hashlib.sha256()
  while left:
   b=proc.stdout.read(min(left,1048576));assert b;d.update(b);left-=len(b)
  assert proc.stdout.read(1)==b'\n';memo[oid]=d.hexdigest()
 if path in m['files']:assert memo[oid]==m['preimages'][path]
 elif path not in BOOT:assert memo[oid]==h,path
 binding[path]={'base':BASE,'blob':oid,'kind':'retained_source_or_normalBOOT_postimage' if path in overrides else 'unchanged_git_blob','executed_sha256':h}
proc.stdin.close();assert proc.wait()==0
(S/'SOURCE-GIT-BINDINGS.json').write_text(json.dumps({'base':BASE,'paths':len(binding),'all_match':True,'overrides':sorted(overrides),'new_sources':[n for n,h in m['preimages'].items() if h is None],'bindings':binding,'live_worktree_hashed':False},indent=2)+'\n')
def parse(t):
 rows=[];pending=None
 for line in t.splitlines():
  z=re.match(r'^test (\S+) \.\.\. (.*)',line)
  if z:
   assert pending is None;pending=z[1];v=re.match(r'^(ok|FAILED|ignored)(?:$|,)',z[2])
   if v:rows.append({'name':pending,'status':v[1]});pending=None
  elif pending and line in ['ok','FAILED','ignored']:rows.append({'name':pending,'status':line});pending=None
 assert pending is None
 sums=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)];counts=[sum(x[i] for x in sums) for i in range(3)];assert counts==[sum(x['status']==s for x in rows) for s in ['ok','FAILED','ignored']];return rows,counts
alltests=[];stages=[];failures={};expected={s['name']:s for s in plan['stages']}
for row in r['stages']:
 name=row['name'];assert row['terminal'],'Interrupted stage requires partial packaging extension';raw=(D/(name+'.log')).read_bytes();t=raw.decode();tests,counts=parse(t)
 if name not in ['bootstrap','identity']:
  assert row['tests']==tests and row['counts']==counts and {x['name'] for x in tests}==set(expected[name]['expected_names'])
  assert L(D/(name+'-before-freeze.json'))==post==L(D/(name+'-after-freeze.json')) and not row['changed']
 elif name=='bootstrap':assert row['exit']==0 and set(row['changed'])<=set(BOOT) and L(D/'bootstrap-before-freeze.json')==before and L(D/'bootstrap-after-freeze.json')==post
 else:assert row['exit']==0 and not row['changed']
 chunks=re.split(r"^thread '([^']+)' .*?panicked at ([^\n]+):\s*$",t,flags=re.M)
 for i in range(1,len(chunks),3):
  n,loc,b=chunks[i:i+3]
  if n not in {x['name'] for x in tests if x['status']=='FAILED'}:continue
  b=b.split('\ntest ',1)[0];st=re.search(r'Compiled macro expansion failed during ([^:]+):',b);sp=re.search(r'span:\s*(\d+\.\.\d+)',b) or re.search(r'at bytes (\d+\.\.\d+)',b);failures[n]={'class':'fuel' if 'all fuel consumed' in b else 'unknown_failure_requires_review','stage':st[1] if st else None,'span':sp[1] if sp else None,'panic':loc,'raw_body':b}
 stages.append({'name':name,'counts':counts,'tests':tests,'argv':row['argv'],'environment':row['environment_overrides'],'exit':row['exit'],'seconds':row['seconds'],'raw_sha256':H(raw)});alltests+=tests
counts=[sum(x['counts'][i] for x in stages) for i in range(3)];assert len(alltests)==len({x['name'] for x in alltests});allnames={x['name']:x['status'] for x in alltests};inv='compiled_source_invocation_tags_distinguish_global_aggregate_and_local_methods';assert allnames[inv]=='ok'
# Existing pinned comparator, frozen source and captured actual observations. Preserve every failure/missing/skip outcome.
maprow=next((s for s in stages if s['name']=='pinned-map'),None);mapresult={'state':'UNEXECUTED','counts':None}
if maprow and maprow['exit']==0:
 for path in ['scripts/clojure_test_suite.py','scripts/oracle_compare.py','scripts/oracle_transport.py','tests/oracle/clojure-test-suite-observations.json']:
  b=G(path);assert H(b)==post[path];q=S/'map-support'/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 sp=S/'map-support/scripts/clojure_test_suite.py';sys.path.insert(0,str(sp.parent));mod=types.ModuleType('literal_suite');mod.__file__=str(sp);exec(compile(sp.read_text(),str(sp),'exec'),mod.__dict__)
 ref=L(S/'map-support/tests/oracle/clojure-test-suite-observations.json');act=L(D/'map-capture/map-transport-observations.json');ns='clojure.core-test.map';test=ns+'/test-map';ref.update(namespaces=[ns],tests=[test],assertions=[x for x in ref['assertions'] if x['test']==test],skips=[x for x in ref['skips'] if x['namespace']==ns]);ids=lambda a:[(x['test'],x['ordinal']) for x in a['assertions']];cnt,details=mod.compare(ref,act)
 mapresult={'state':'COMPARED','counts':cnt,'expected_ids':ids(ref),'actual_ids':ids(act),'ordered_ids_equal':ids(ref)==ids(act),'details':details,'actual_test_failures':act['test-failures'],'actual_skips':act['skips'],'reference_sha256':post['tests/oracle/clojure-test-suite-observations.json'],'comparator_sha256':post['scripts/clojure_test_suite.py']}
 assert ids(act)==ids(ref) and len(ids(act))==69 and cnt=={'pass':62,'guest-judged':7,'fail':0,'not-executed':0,'skipped':0,'namespaces-failed':0} and not act['test-failures'] and not act['skips'] and all(not details[k] for k in ['namespaces','tests','assertions','skip-mismatches']),'Host map mismatch: preserved review required before publication'
(P/'map-independent-comparison.json').write_text(json.dumps(mapresult,indent=2)+'\n');shutil.copyfile(P/'map-independent-comparison.json',S/'map-independent-comparison.json')
review={'verdict':'VERIFIED_FOCUSED_PARTIAL_NOT_ACCEPTANCE','source_base':BASE,'source_manifest_sha256':r['source_manifest_sha256'],'normalBOOT_hashes':boot,'source_freeze':{'paths':len(post),'all_match_Git_or_exact_postimages':True,'all_three_newfiles_before_first_Cargo':True,'subsequent_changes':[],'live_root_hashed':False},'counts':dict(zip(['pass','fail','ignored'],counts)),'unique_names':len(alltests),'stages':stages,'failures':failures,'unexecuted':r['unexecuted'],'original_invocation_restored':True,'map':mapresult,'source_commit_final':None,'final_CI':None,'limits':['Seven-path candidate overlay not finalGitbound yet; exactGitbase plus reviewedsource and normalBOOT snapshots establish testedtuple.','Original invocation-tags PASS is actual unchangedcriterion restoration; inference/CoreEnv/collection failures remain actual failures.','Macro allowance defaults unchanged; no2Bdiagnostic source in thisrun.','Parentc170CI and2B are separate referencedtuples, not currentliteralCI or extra candidatecoverage.','No new fullworkspacebaseline/promotion/closure claim.']};(P/'independent-final-review.json').write_text(json.dumps(review,indent=2)+'\n');shutil.copyfile(P/'independent-final-review.json',S/'independent-final-review.json')
refs=L(P/'historical-reference-bindings.json');(S/'historical-reference-bindings.json').write_text(json.dumps(refs,indent=2)+'\n')
failtext='\n'.join('- '+n+': '+str(v['class'])+', '+str(v['stage'])+' '+str(v['span'])+'.' for n,v in failures.items());report=f'''# PR256 literal construction and field-entry metering — terminalfocusedpartial\n\nExecutionbase `{BASE}` plus exactreviewed7Rustsourcepaths/normal4BOOT, manifest{r['source_manifest_sha256']}. Sourcepostimages/provenance/pre-meteringblockedhistory/finalGO retained. Wholecontrollerterminal+PGIDdrained. BeforeFIRSTCargo trackedUNION7source freeze includesall3newfiles; all{len(post)}executedinputs bindGitc170 or exactsource/BOOTpostimages. FourgeneratedBOOT SHA256hashes in BOOT-SHA256.json. No currentroot hashes.\n\nActual{len(alltests)}distinctRusttests: {counts[0]}PASS/{counts[1]}FAIL/{counts[2]}ignored; unexecutedstages={r['unexecuted']}. Native8PASS (Graph5/field_entry2/streamhash1), newCLI2PASS, oldslot17PASS. ORIGINAL invocation-tags PASS underunchangedlimits: a real restoredoriginalregression criterion. Inference stillFAILS caller&env382..414. Additionalfailures preserved:\n\n{failtext}\n\nMap: {json.dumps(mapresult['counts'])}; existingcomparator checks69orderedIDs,62hostPASS/7guestjudged ifverified. Guestjudgments are nothostpasses. Rawcapture/reference/comparator preserved.\n\nNo globalcompatibility/acceptance/promotion/merge/closure claim. CoreEnv/collection unchangedallowances (collectionexisting40M; CoreEnvdefault10M); any remainingfailure prevents originalcontractcompletion. Exactfullworkspacebaseline remains finalacceptancegate, not rerunonpartialsource duringknownfocusedfailures.\n\nParentc170CI39162616532: foundationSUCCESS, integrations124PASS18fuelFAIL,31/251completed220unexecuted; actualsourcec170 only. c1702Bseparatearchive467ce857… firstmacro1,701,286,018units(+91vs4f), second2Benv0..36fails. Wholecompileunknown; no walltimespeedclaim. Priorlargearchives referencedbyexactSHA, notduplicated. Neitherparentresult is literalcandidateCI.\n\nFinalsourcecommit/PUBLISHEDblobcorrespondence=PENDING; finalheadCI=PENDING. Source/provenance and normalBOOTsnapshots are executabletestedinputs, not authorityreceipts bythemselves. No testcriteria/budget cuts. Archivecontainsfullcommands/env/starts/exits/freezes/errors andinitialreview/blockerhistory, no targets/vendorarchive recursion.\n''';(P/'REPORT.md').write_text(report);shutil.copyfile(P/'REPORT.md',S/'REPORT.md')
comment=f'''PR256 focused partial checkpoint on c170 + reviewed literal/field-entry metering overlay: {counts[0]}PASS/{counts[1]}FAIL/{counts[2]}ignored across {len(alltests)}distincttests. Newnative8, CLI2 and oldslot17 pass. The ORIGINAL invocation-tags regression now passes under unchanged limits; inference remains caller&env382..414 fuel failure. Remainingfailednames/stages/spans are retained in the report. Map independent comparison: {json.dumps(mapresult['counts'])},69orderedIDs. All{len(post)}frozeninputs source-bound including3newmodules beforefirstCargo; onlynormal4BOOT changed duringgeneration.\n\nPartial progress only; no promotion/closure. Parentc170CI/2Bdiagnostic and priorbaseline results are separatetuple evidence, not currentcandidateacceptance. Finalpublishedsourcebinding and finalheadCI remain required. Next repair the remaining actual focused transport failures; no repeatedworkspacebaseline until relevantfocusedgates clear.\n''';(P/'PR-ISSUE-COMMENT-DRAFT.txt').write_text(comment);shutil.copyfile(P/'PR-ISSUE-COMMENT-DRAFT.txt',S/'PR-ISSUE-COMMENT-DRAFT.txt');shutil.copyfile(P/'package-terminal.py',S/'package-terminal.py')
assert stable=={str(f):H(f.read_bytes()) for f in D.rglob('*') if f.is_file() and '__pycache__' not in f.parts}
manifest={str(f.relative_to(S)):{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size} for f in S.rglob('*') if f.is_file() and str(f.relative_to(S))!='MANIFEST.json'};(S/'MANIFEST.json').write_text(json.dumps({'schema':1,'payloads':manifest},indent=2)+'\n');out=C/'m4-pr256-literal-field-entry-focused-2026-10-18.tar.gz'
with tarfile.open(out,'w:gz') as tf:
 for f in sorted(S.rglob('*')):
  if f.is_file():tf.add(f,arcname=str(f.relative_to(S)),recursive=False)
with tarfile.open(out) as tf:
 ms=tf.getmembers();assert len(ms)==len(manifest)+1==len({m.name for m in ms})
 for m in ms:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='MANIFEST.json':assert H(tf.extractfile(m).read())==manifest[m.name]['sha256']
result={'archive':str(out),'sha256':H(out.read_bytes()),'members':len(manifest)+1,'payloads':len(manifest),'bytes':out.stat().st_size,'counts':counts,'unique_tests':len(alltests),'frozen_paths':len(post),'invocation_tags_restored':True,'map_counts':mapresult['counts'],'review':str(P/'independent-final-review.json')};(P/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
