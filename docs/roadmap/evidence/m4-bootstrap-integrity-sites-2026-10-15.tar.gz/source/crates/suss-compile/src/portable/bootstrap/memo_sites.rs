//! Canonical source sites eligible for future authenticated memo writes.
//! Source spelling alone grants no authority: this catalog is consumed only by
//! embedded-bootstrap generation and must match its actual lowered field stores.
use super::super::{
    Diagnostic,
    hir::Nominal,
    ir::{Function, Operation},
};
use std::{collections::BTreeMap, ops::Range};
use suss_reader::forms::{Form, Kind};

// Reviewed canonical owner/slot/method identities; changes require explicit review.
const EXPECTED: &[(&str, usize, &str)] = &[
    (
        "List",
        4,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "Cons",
        3,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "Symbol",
        3,
        "f0a590441ca9a32f8e4b04eb958380c07b5cea155c12249991a4705e2e786aa7",
    ),
    (
        "Keyword",
        3,
        "43ce5179180441ba2be0d4e76b92b72e4ae7f7fa621c692f0b903dac984bde8a",
    ),
    (
        "PersistentVector",
        5,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "MapEntry",
        2,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "PersistentArrayMap",
        3,
        "18aa0fbfb8d715c11f3ef34d9653a0d5b233d55968dca684d0efbcf3042f349b",
    ),
    (
        "ChunkedSeq",
        5,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "NodeSeq",
        4,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "ArrayNodeSeq",
        4,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "PersistentHashMap",
        5,
        "18aa0fbfb8d715c11f3ef34d9653a0d5b233d55968dca684d0efbcf3042f349b",
    ),
    (
        "PersistentHashSet",
        2,
        "18aa0fbfb8d715c11f3ef34d9653a0d5b233d55968dca684d0efbcf3042f349b",
    ),
    (
        "LazySeq",
        3,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "ChunkedCons",
        3,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "Subvec",
        4,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "PersistentQueueSeq",
        3,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "PersistentQueue",
        4,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "BlackNode",
        4,
        "0e5bfe1fa67edceafcfdbc28cba52331de9a4c57f83990ae58a4bb9a61cf2dca",
    ),
    (
        "RedNode",
        4,
        "0e5bfe1fa67edceafcfdbc28cba52331de9a4c57f83990ae58a4bb9a61cf2dca",
    ),
    (
        "PersistentTreeMapSeq",
        4,
        "49122b135c3b37c4face574129605de7febe21350c86d75b4b390f33a39aeb2e",
    ),
    (
        "PersistentTreeMap",
        4,
        "f810c31b8eec23163fffb59883f673bc158bb8c8faf0d085a9eab5ac47ff6c9d",
    ),
    (
        "PersistentTreeSet",
        2,
        "f810c31b8eec23163fffb59883f673bc158bb8c8faf0d085a9eab5ac47ff6c9d",
    ),
    (
        "Repeat",
        4,
        "b5a883d8e19f08ef6e82fa48ac64d623be413e2cd0ec56ea4dde3401d20efd7a",
    ),
    (
        "IntegerRange",
        5,
        "25c228ba1e06ec272b37193d7cce517436237813dba98969ceadde679d3c7bc8",
    ),
    (
        "Range",
        6,
        "25c228ba1e06ec272b37193d7cce517436237813dba98969ceadde679d3c7bc8",
    ),
];

#[derive(Debug)]
pub(super) struct MemoSite {
    pub owner: String,
    pub field: usize,
    pub span: Range<usize>,
    method_sha256: String,
}
fn symbol(form: &Form, expected: &str) -> bool {
    matches!(&form.kind, Kind::Symbol(name) if name.namespace.is_none() && name.name == expected)
}
fn error(span: Range<usize>, message: &str) -> Diagnostic {
    Diagnostic {
        span,
        message: message.into(),
    }
}
fn catalog(source: &str) -> Result<Vec<MemoSite>, Diagnostic> {
    let forms = suss_reader::forms::read_forms(source)
        .and_then(suss_reader::forms::resolve_conditionals)
        .map_err(|failure| error(failure.span, &failure.message))?;
    let mut sites = Vec::new();
    for form in forms {
        let Kind::List(items) = &form.kind else {
            continue;
        };
        if !items.first().is_some_and(|head| symbol(head, "deftype")) {
            continue;
        }
        let [_, owner, fields, methods @ ..] = items.as_slice() else {
            return Err(error(form.span.clone(), "Malformed canonical type"));
        };
        let (Kind::Symbol(owner), Kind::Vector(fields)) = (&owner.kind, &fields.kind) else {
            return Err(error(form.span.clone(), "Malformed canonical type fields"));
        };
        let mut hash_protocol = false;
        for method in methods {
            if matches!(method.kind, Kind::Symbol(_)) {
                hash_protocol = symbol(method, "IHash");
                continue;
            }
            let Kind::List(parts) = &method.kind else {
                continue;
            };
            if !hash_protocol || !parts.first().is_some_and(|head| symbol(head, "-hash")) {
                continue;
            }
            let mut pending: Vec<_> = parts.iter().skip(2).collect();
            while let Some(form) = pending.pop() {
                let Kind::List(parts) = &form.kind else {
                    if let Kind::Vector(parts) = &form.kind {
                        pending.extend(parts);
                    }
                    continue;
                };
                let key = match parts.as_slice() {
                    [head, _, _, key] if symbol(head, "caching-hash") => Some(key),
                    [head, key, _]
                        if symbol(head, "set!")
                            && (symbol(key, "__hash") || symbol(key, "_hash")) =>
                    {
                        Some(key)
                    }
                    _ => None,
                };
                if let Some(key) = key {
                    if !(symbol(key, "__hash") || symbol(key, "_hash")) {
                        return Err(error(key.span.clone(), "Unknown canonical hash memo field"));
                    }
                    let field = fields
                        .iter()
                        .position(|field| field.kind == key.kind)
                        .ok_or_else(|| {
                            error(
                                key.span.clone(),
                                "Canonical hash memo is not a declared field",
                            )
                        })?;
                    sites.push(MemoSite {
                        owner: owner.name.clone(),
                        field,
                        span: form.span.clone(),
                        method_sha256: super::sha256(source[method.span.clone()].as_bytes()),
                    });
                }
                if !parts.first().is_some_and(|head| symbol(head, "quote")) {
                    pending.extend(parts);
                }
            }
        }
    }
    sites.sort_by_key(|site| site.span.start);
    let actual: Vec<_> = sites
        .iter()
        .map(|site| (site.owner.as_str(), site.field, site.method_sha256.as_str()))
        .collect();
    if actual != EXPECTED {
        let mismatch = actual
            .iter()
            .zip(EXPECTED)
            .position(|(actual, expected)| actual != expected)
            .unwrap_or(actual.len().min(EXPECTED.len()));
        return Err(error(
            0..source.len(),
            &format!(
                "Canonical memo owner/slot/method inventory mismatch at {mismatch}: actual {:?}, expected {:?}",
                actual.get(mismatch),
                EXPECTED.get(mismatch)
            ),
        ));
    }
    Ok(sites)
}

pub(super) fn verify(source: &str, function: &Function) -> Result<Vec<MemoSite>, Diagnostic> {
    let sites = catalog(source)?;
    let mut expected = BTreeMap::new();
    for site in &sites {
        if expected
            .insert((site.span.start, site.span.end), (site, 0usize))
            .is_some()
        {
            return Err(error(site.span.clone(), "Duplicate canonical memo site"));
        }
    }
    let mut pending = vec![function];
    while let Some(function) = pending.pop() {
        for block in &function.blocks {
            for inst in &block.instructions {
                match &inst.operation {
                    Operation::MakeClosure { body, .. } => pending.push(&body.function),
                    Operation::MakeGeneralClosure { body, .. } => {
                        pending.extend(body.methods.iter().map(|method| &method.function))
                    }
                    Operation::MakeFuture { body, .. } => pending.push(&body.continuation.function),
                    Operation::Nominal {
                        operation: Nominal::FieldSet(field),
                        ..
                    } => {
                        if let Some((site, count)) =
                            expected.get_mut(&(inst.span.start, inst.span.end))
                        {
                            if *field != site.field {
                                return Err(error(
                                    inst.span.clone(),
                                    "Canonical memo store targets the wrong field",
                                ));
                            }
                            *count += 1;
                        }
                    }
                    _ => {}
                }
            }
        }
    }
    for (site, count) in expected.values() {
        if *count != 1 {
            return Err(error(
                site.span.clone(),
                &format!(
                    "Canonical {} memo site must lower to exactly one field store, found {count}",
                    site.owner
                ),
            ));
        }
    }
    Ok(sites)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn canonical_memo_store_verification_rejects_changed_and_missing_lowered_writes() {
        let analyzed = super::super::catalog(super::super::Phase::Macro).unwrap();
        let mut ir = super::super::super::ir::lower(&analyzed.hir).unwrap();
        let sites = verify(super::super::SOURCE, &ir).unwrap();
        let site = &sites[0];
        fn replace(function: &mut Function, span: &Range<usize>, operation: Operation) -> bool {
            for block in &mut function.blocks {
                for inst in &mut block.instructions {
                    if inst.span == *span
                        && matches!(
                            inst.operation,
                            Operation::Nominal {
                                operation: Nominal::FieldSet(_),
                                ..
                            }
                        )
                    {
                        inst.operation = operation;
                        return true;
                    }
                    match &mut inst.operation {
                        Operation::MakeClosure { body, .. } => {
                            if replace(&mut body.function, span, operation.clone()) {
                                return true;
                            }
                        }
                        Operation::MakeGeneralClosure { body, .. } => {
                            for method in &mut body.methods {
                                if replace(&mut method.function, span, operation.clone()) {
                                    return true;
                                }
                            }
                        }
                        _ => {}
                    }
                }
            }
            false
        }
        // Preserve the genuine operands while changing only the destination.
        fn change_field(function: &mut Function, span: &Range<usize>) -> bool {
            for block in &mut function.blocks {
                for inst in &mut block.instructions {
                    if inst.span == *span {
                        if let Operation::Nominal {
                            operation: Nominal::FieldSet(field),
                            ..
                        } = &mut inst.operation
                        {
                            *field += 1;
                            return true;
                        }
                    }
                    match &mut inst.operation {
                        Operation::MakeClosure { body, .. } => {
                            if change_field(&mut body.function, span) {
                                return true;
                            }
                        }
                        Operation::MakeGeneralClosure { body, .. } => {
                            for method in &mut body.methods {
                                if change_field(&mut method.function, span) {
                                    return true;
                                }
                            }
                        }
                        _ => {}
                    }
                }
            }
            false
        }
        assert!(change_field(&mut ir, &site.span));
        assert!(
            verify(super::super::SOURCE, &ir)
                .unwrap_err()
                .message
                .contains("wrong field")
        );
        assert!(replace(
            &mut ir,
            &site.span,
            Operation::Literal(super::super::super::hir::Literal::Nil)
        ));
        assert!(
            verify(super::super::SOURCE, &ir)
                .unwrap_err()
                .message
                .contains("found 0")
        );
    }

    #[test]
    fn canonical_memo_catalog_rejects_same_count_method_substitution() {
        let source = super::super::SOURCE;
        let site = &catalog(source).unwrap()[0];
        let mut changed = source.to_owned();
        changed.replace_range(
            site.span.clone(),
            "(caching-hash coll hash-unordered-coll __hash)",
        );
        assert!(
            catalog(&changed)
                .unwrap_err()
                .message
                .contains("inventory mismatch")
        );
    }

    #[test]
    fn canonical_hash_memo_sites_include_expanded_tree_methods() {
        let sites = catalog(super::super::SOURCE).unwrap();
        assert_eq!(sites.len(), 25);
        assert!(sites.iter().any(|site| site.owner == "Symbol"));
        assert!(sites.iter().any(|site| site.owner == "Keyword"));
        let direct = sites
            .iter()
            .filter(|site| super::super::SOURCE[site.span.clone()].starts_with("(set!"))
            .count();
        assert_eq!(direct, 5);
    }
}
