//! Graph-local exact raw reader-data identities. No guest objects or callbacks.
use std::cmp::Ordering;
use suss_reader::forms::{Form, Kind};
use crate::portable::metered_map::{Context, TryOrderedMap};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) struct KeyId(pub(super) usize);
pub(super) struct Node {
    pub(super) key: KeyId,
    pub(super) metadata_count: usize,
    pub(super) children: Vec<usize>,
}
#[derive(Default)]
pub(super) struct Plan {
    pub(super) nodes: Vec<Node>,
}
#[derive(Default)]
pub(super) struct Interner {
    keys: TryOrderedMap<Vec<u8>, KeyId>,
    #[cfg(test)]
    key_bytes: usize,
}
fn bytes<T>(count: usize) -> u64 {
    (count as u64).saturating_mul(std::mem::size_of::<T>() as u64)
}
// Precharge capacity and possible relocation before allocation, then publication.
fn reserve<T, E>(
    v: &mut Vec<T>,
    extra: usize,
    charge: &mut impl FnMut(u64) -> Result<(), E>,
) -> Result<(), E> {
    charge(0)?;
    if extra > v.capacity() - v.len() {
        let capacity = v
            .len()
            .saturating_add(extra)
            .max(v.capacity().saturating_mul(2))
            .max(4);
        charge(bytes::<T>(capacity).saturating_add(bytes::<T>(v.len())))?;
        v.reserve_exact(capacity - v.len());
    }
    Ok(())
}
fn push<T, E>(
    v: &mut Vec<T>,
    value: T,
    charge: &mut impl FnMut(u64) -> Result<(), E>,
) -> Result<(), E> {
    charge(1)?;
    reserve(v, 1, charge)?;
    v.push(value);
    Ok(())
}
fn append<E>(
    out: &mut Vec<u8>,
    value: &[u8],
    charge: &mut impl FnMut(u64) -> Result<(), E>,
) -> Result<(), E> {
    // Bounded chunks poll cancellation without a single unbounded native copy.
    for chunk in value.chunks(256) {
        charge(chunk.len() as u64)?;
        reserve(out, chunk.len(), charge)?;
        out.extend_from_slice(chunk);
    }
    charge(0)
}
fn size<E>(
    out: &mut Vec<u8>,
    value: usize,
    charge: &mut impl FnMut(u64) -> Result<(), E>,
) -> Result<(), E> {
    append(out, &(value as u64).to_le_bytes(), charge)
}
fn text<E>(
    out: &mut Vec<u8>,
    value: &str,
    charge: &mut impl FnMut(u64) -> Result<(), E>,
) -> Result<(), E> {
    size(out, value.len(), charge)?;
    append(out, value.as_bytes(), charge)
}
struct Meter<'a, F>(&'a mut F);
impl<E, F: FnMut(u64) -> Result<(), E>> Context<Vec<u8>> for Meter<'_, F> {
    type Error = E;
    fn charge(&mut self, work: u64) -> Result<(), E> {
        (self.0)(work)
    }
    fn compare(&mut self, left: &Vec<u8>, right: &Vec<u8>) -> Result<Ordering, E> {
        compare_bytes(left, right, self.0)
    }
}
// Every inspected byte of both inputs is billed before reading it. Lengths are
// immutable and compared only after the common prefix. No native slice cmp.
fn compare_bytes<E>(
    left: &[u8],
    right: &[u8],
    charge: &mut impl FnMut(u64) -> Result<(), E>,
) -> Result<Ordering, E> {
    charge(1)?;
    for index in 0..left.len().min(right.len()) {
        charge(2)?;
        match left[index].cmp(&right[index]) {
            Ordering::Equal => {}
            order => return Ok(order),
        }
    }
    Ok(left.len().cmp(&right.len()))
}
impl Interner {
    fn intern<E>(
        &mut self,
        key: Vec<u8>,
        charge: &mut impl FnMut(u64) -> Result<(), E>,
    ) -> Result<KeyId, E> {
        let mut meter = Meter(charge);
        let id = KeyId(self.keys.len());
        // The AVL search, comparison and allocation charges finish before any
        // insertion mutation. Failure neither publishes nor consumes this ID.
        #[cfg(test)]
        let key_bytes = key.len();
        let (canonical, inserted) = self.keys.get_or_insert(key, id, &mut meter)?;
        let canonical = *canonical;
        #[cfg(test)]
        if inserted {
            self.key_bytes += key_bytes;
        }
        #[cfg(not(test))]
        let _ = inserted;
        Ok(canonical)
    }
    pub(super) fn plan<E>(
        &mut self,
        form: &Form,
        plan: &mut Plan,
        charge: &mut impl FnMut(u64) -> Result<(), E>,
    ) -> Result<usize, E> {
        enum Work<'a> {
            Enter(&'a Form, Option<usize>),
            Finish(&'a Form, usize),
        }
        let root = plan.nodes.len();
        let result = (|| {
            let mut pending = Vec::new();
            push(&mut pending, Work::Enter(form, None), charge)?;
            while let Some(work) = pending.pop() {
                charge(1)?;
                match work {
                    Work::Enter(form, parent) => {
                        let id = plan.nodes.len();
                        push(
                            &mut plan.nodes,
                            Node {
                                key: KeyId(0),
                                metadata_count: form.metadata.len(),
                                children: Vec::new(),
                            },
                            charge,
                        )?;
                        if let Some(parent) = parent {
                            push(&mut plan.nodes[parent].children, id, charge)?;
                        }
                        push(&mut pending, Work::Finish(form, id), charge)?;
                        // Push in reverse: metadata visits precede kind children.
                        match &form.kind {
                            Kind::List(v)
                            | Kind::Vector(v)
                            | Kind::Map(v)
                            | Kind::Set(v)
                            | Kind::Conditional(v)
                            | Kind::SplicingConditional(v) => {
                                for child in v.iter().rev() {
                                    push(&mut pending, Work::Enter(child, Some(id)), charge)?;
                                }
                            }
                            Kind::Discard(child) => {
                                push(&mut pending, Work::Enter(child, Some(id)), charge)?
                            }
                            Kind::Prefix { operator, target } => {
                                push(&mut pending, Work::Enter(target, Some(id)), charge)?;
                                push(&mut pending, Work::Enter(operator, Some(id)), charge)?;
                            }
                            _ => {}
                        }
                        for child in form.metadata.iter().rev() {
                            push(&mut pending, Work::Enter(child, Some(id)), charge)?;
                        }
                    }
                    Work::Finish(form, id) => {
                        let mut key = Vec::new();
                        let node = &plan.nodes[id];
                        size(&mut key, node.metadata_count, charge)?;
                        for child in &node.children[..node.metadata_count] {
                            charge(1)?;
                            size(&mut key, plan.nodes[*child].key.0, charge)?;
                        }
                        let tag = match &form.kind {
                            Kind::Nil => 0,
                            Kind::Bool(_) => 1,
                            Kind::Number(_) => 2,
                            Kind::String(_) => 3,
                            Kind::Symbol(_) => 4,
                            Kind::Keyword(_) => 5,
                            Kind::List(_) => 6,
                            Kind::Vector(_) => 7,
                            Kind::Set(_) => 8,
                            Kind::Map(_) => 9,
                            Kind::Conditional(_) => 10,
                            Kind::Discard(_) => 11,
                            Kind::Prefix { .. } => 12,
                            Kind::SplicingConditional(_) => 13,
                        };
                        append(&mut key, &[tag], charge)?;
                        match &form.kind {
                            Kind::Bool(v) => append(&mut key, &[u8::from(*v)], charge)?,
                            Kind::Number(v) => {
                                append(&mut key, &v.to_bits().to_le_bytes(), charge)?
                            }
                            Kind::String(v) => {
                                size(&mut key, v.len(), charge)?;
                                for unit in v {
                                    append(&mut key, &unit.to_le_bytes(), charge)?;
                                }
                            }
                            Kind::Symbol(v) => {
                                append(&mut key, &[u8::from(v.namespace.is_some())], charge)?;
                                if let Some(ns) = &v.namespace {
                                    text(&mut key, ns, charge)?;
                                }
                                text(&mut key, &v.name, charge)?;
                            }
                            Kind::Keyword(v) => {
                                append(&mut key, &[u8::from(v.namespace.is_some())], charge)?;
                                if let Some(ns) = &v.namespace {
                                    text(&mut key, ns, charge)?;
                                }
                                text(&mut key, &v.name, charge)?;
                            }
                            Kind::List(v)
                            | Kind::Vector(v)
                            | Kind::Map(v)
                            | Kind::Set(v)
                            | Kind::Conditional(v)
                            | Kind::SplicingConditional(v) => size(&mut key, v.len(), charge)?,
                            _ => {}
                        }
                        for child in &node.children[node.metadata_count..] {
                            charge(1)?;
                            size(&mut key, plan.nodes[*child].key.0, charge)?;
                        }
                        let canonical = self.intern(key, charge)?;
                        plan.nodes[id].key = canonical;
                    }
                }
            }
            Ok(root)
        })();
        // Completed child keys remain valid canonical entries. Incomplete plan
        // nodes are private scratch and must not escape a failed build.
        if result.is_err() {
            plan.nodes.truncate(root);
        }
        result
    }
}
pub(super) fn bind<T: Copy, E>(
    values: &mut Vec<Option<T>>,
    key: KeyId,
    value: T,
    charge: &mut impl FnMut(u64) -> Result<(), E>,
) -> Result<(), E> {
    charge(1)?;
    if key.0 >= values.len() {
        let extra = key.0 - values.len() + 1;
        charge(extra as u64)?;
        reserve(values, extra, charge)?;
        values.resize(key.0 + 1, None);
    }
    values[key.0] = Some(value);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[derive(Clone, Copy, Debug, Eq, PartialEq)]
    enum Error {
        Fuel,
        Cancel,
    }
    fn form(kind: Kind) -> Form {
        Form {
            span: 0..0,
            metadata: vec![],
            kind,
        }
    }
    fn corpus() -> Vec<Form> {
        let mut values = vec![
            form(Kind::Nil),
            form(Kind::Bool(false)),
            form(Kind::Bool(true)),
        ];
        for bits in [
            0,
            (-0.0f64).to_bits(),
            42f64.to_bits(),
            0x7ff8_0000_0000_0001,
            0x7ff8_0000_0000_0002,
        ] {
            values.push(form(Kind::Number(f64::from_bits(bits))));
        }
        for units in [
            vec![],
            vec![0],
            vec![0xd800],
            vec![0xdc00],
            vec![0xd800, 0xdc00],
            vec![97],
        ] {
            values.push(form(Kind::String(units)));
        }
        for namespace in [None, Some(String::new()), Some("ns".into())] {
            values.push(form(Kind::Symbol(suss_reader::Symbol {
                namespace: namespace.clone(),
                name: "x".into(),
            })));
            values.push(form(Kind::Keyword(suss_reader::Keyword {
                namespace,
                name: "x".into(),
            })));
        }
        let leaves = values.clone();
        for items in [
            vec![],
            vec![leaves[0].clone()],
            vec![leaves[1].clone(), leaves[2].clone()],
            vec![leaves[2].clone(), leaves[1].clone()],
        ] {
            for constructor in [
                Kind::List,
                Kind::Vector,
                Kind::Map,
                Kind::Set,
                Kind::Conditional,
                Kind::SplicingConditional,
            ] {
                values.push(form(constructor(items.clone())));
            }
        }
        values.push(form(Kind::Discard(Box::new(leaves[0].clone()))));
        values.push(form(Kind::Prefix {
            operator: Box::new(leaves[1].clone()),
            target: Box::new(leaves[2].clone()),
        }));
        for metadata in [
            vec![leaves[1].clone(), leaves[2].clone()],
            vec![leaves[2].clone(), leaves[1].clone()],
            vec![leaves[1].clone(), leaves[1].clone()],
        ] {
            let mut value = form(Kind::Vector(vec![leaves[0].clone()]));
            value.metadata = metadata;
            values.push(value);
        }
        let mut moved = values.last().unwrap().clone();
        moved.span = 100..200;
        values.push(moved);
        let mut nested_metadata = form(Kind::Symbol(suss_reader::Symbol {
            namespace: None,
            name: "tag".into(),
        }));
        nested_metadata
            .metadata
            .push(values.last().unwrap().clone());
        values.push(nested_metadata);
        // Same normalized :x=true metadata, different raw representation.
        let keyword = form(Kind::Keyword(suss_reader::Keyword {
            namespace: None,
            name: "x".into(),
        }));
        let mut short = form(Kind::Vector(vec![]));
        short.metadata = vec![keyword.clone()];
        let mut expanded = short.clone();
        expanded.metadata = vec![form(Kind::Map(vec![keyword, form(Kind::Bool(true))]))];
        values.extend([short, expanded]);
        values
    }
    fn key(interner: &mut Interner, value: &Form) -> KeyId {
        let mut plan = Plan::default();
        let root = interner
            .plan(value, &mut plan, &mut |_| Ok::<_, Error>(()))
            .unwrap();
        plan.nodes[root].key
    }
    #[test]
    fn raw_ids_match_legacy_exact_equivalence_pairwise() {
        let mut interner = Interner::default();
        let corpus = corpus();
        let ids: Vec<_> = corpus.iter().map(|form| key(&mut interner, form)).collect();
        let legacy: Vec<_> = corpus
            .iter()
            .map(|form| super::super::form_key(form).unwrap())
            .collect();
        for i in 0..corpus.len() {
            for j in 0..corpus.len() {
                assert_eq!(
                    ids[i] == ids[j],
                    legacy[i] == legacy[j],
                    "raw equivalence {i}/{j}"
                );
            }
        }
        // Interning order may change numeric IDs, never equivalence.
        let mut reversed = Interner::default();
        for value in corpus.iter().rev() {
            key(&mut reversed, value);
        }
        for i in 0..corpus.len() {
            for j in 0..corpus.len() {
                assert_eq!(
                    key(&mut reversed, &corpus[i]) == key(&mut reversed, &corpus[j]),
                    legacy[i] == legacy[j]
                );
            }
        }
    }
    #[test]
    fn comparator_bills_only_inspected_bytes_and_polls_empty_input() {
        for (left, right, expected, work) in [
            (&b""[..], &b""[..], Ordering::Equal, 1),
            (&b"abc"[..], &b"abd"[..], Ordering::Less, 7),
            (&b"abc"[..], &b"abcZ"[..], Ordering::Less, 7),
            (&b"aZZZZ"[..], &b"bZZZZ"[..], Ordering::Less, 3),
        ] {
            let mut charged = 0;
            assert_eq!(
                compare_bytes(left, right, &mut |n| {
                    charged += n;
                    Ok::<_, Error>(())
                })
                .unwrap(),
                expected
            );
            assert_eq!(charged, work);
        }
        assert_eq!(
            compare_bytes(b"", b"", &mut |_| Err(Error::Cancel)),
            Err(Error::Cancel)
        );
    }
    #[test]
    fn every_intern_failure_point_preserves_table_and_next_id() {
        let seed = vec![97; 300];
        let mut candidate = seed.clone();
        candidate.push(98);
        let mut baseline = Interner::default();
        baseline
            .intern(seed.clone(), &mut |_| Ok::<_, Error>(()))
            .unwrap();
        let mut calls = 0;
        baseline
            .intern(candidate.clone(), &mut |_| {
                calls += 1;
                Ok::<_, Error>(())
            })
            .unwrap();
        for stop in 1..=calls {
            let mut interner = Interner::default();
            let old = interner
                .intern(seed.clone(), &mut |_| Ok::<_, Error>(()))
                .unwrap();
            let mut index = 0;
            let failed = interner.intern(candidate.clone(), &mut |_| {
                index += 1;
                if index == stop {
                    Err(Error::Cancel)
                } else {
                    Ok(())
                }
            });
            assert_eq!(failed, Err(Error::Cancel), "charge point {stop}");
            assert_eq!(interner.keys.len(), 1);
            assert_eq!(
                interner
                    .intern(seed.clone(), &mut |_| Ok::<_, Error>(()))
                    .unwrap(),
                old
            );
            assert_eq!(
                interner
                    .intern(candidate.clone(), &mut |_| Ok::<_, Error>(()))
                    .unwrap(),
                KeyId(1)
            );
        }
    }
    #[test]
    fn fuel_exhaustion_in_long_comparison_does_not_publish() {
        let mut interner = Interner::default();
        interner
            .intern(vec![97; 4096], &mut |_| Ok::<_, Error>(()))
            .unwrap();
        let mut remaining = 100u64;
        let result = interner.intern(vec![97; 4097], &mut |n| {
            remaining = remaining.checked_sub(n).ok_or(Error::Fuel)?;
            Ok(())
        });
        assert_eq!(result, Err(Error::Fuel));
        assert_eq!(interner.keys.len(), 1);
        assert_eq!(
            interner
                .intern(vec![97; 4097], &mut |_| Ok::<_, Error>(()))
                .unwrap(),
            KeyId(1)
        );
    }
    #[test]
    fn deep_plan_has_linear_direct_edges_and_flat_key_storage() {
        let mut value = form(Kind::Nil);
        for _ in 0..256 {
            value = form(Kind::Vector(vec![value]));
        }
        let mut interner = Interner::default();
        let mut plan = Plan::default();
        interner
            .plan(&value, &mut plan, &mut |_| Ok::<_, Error>(()))
            .unwrap();
        assert_eq!(plan.nodes.len(), 257);
        assert_eq!(
            plan.nodes
                .iter()
                .map(|node| node.children.len())
                .sum::<usize>(),
            256
        );
        // Empty metadata length (8), tag (1), collection count (8), child ID (8).
        // No descendant payload is embedded in parent keys.
        assert_eq!(interner.keys.len(), 257);
        assert_eq!(interner.key_bytes, 9 + 256 * 25);
        let mut legacy_bytes = 0;
        let mut cursor = &value;
        loop {
            legacy_bytes += super::super::form_key(cursor).unwrap().len();
            match &cursor.kind {
                Kind::Vector(items) => cursor = &items[0],
                Kind::Nil => break,
                _ => unreachable!(),
            }
        }
        assert_eq!(legacy_bytes, 561_545);
        assert_eq!(interner.key_bytes, 6_409);
        let bytes_before = interner.key_bytes;
        let mut warm = Plan::default();
        let old = key(&mut interner, &value);
        let root = interner
            .plan(&value, &mut warm, &mut |_| Ok::<_, Error>(()))
            .unwrap();
        assert_eq!(warm.nodes[root].key, old);
        assert_eq!(interner.keys.len(), 257);
        assert_eq!(interner.key_bytes, bytes_before);
    }
    #[test]
    fn failed_plan_discards_incomplete_nodes_and_recovers() {
        let value = form(Kind::Vector(vec![
            form(Kind::String(vec![97; 300])),
            form(Kind::Bool(true)),
        ]));
        let mut baseline = Interner::default();
        let mut count = 0;
        baseline
            .plan(&value, &mut Plan::default(), &mut |_| {
                count += 1;
                Ok::<_, Error>(())
            })
            .unwrap();
        for stop in 1..=count {
            let mut interner = Interner::default();
            let mut plan = Plan::default();
            let existing = interner
                .plan(&form(Kind::Nil), &mut plan, &mut |_| Ok::<_, Error>(()))
                .unwrap();
            let old_key = plan.nodes[existing].key;
            let old_len = plan.nodes.len();
            let mut index = 0;
            let result = interner.plan(&value, &mut plan, &mut |_| {
                index += 1;
                if index == stop {
                    Err(Error::Cancel)
                } else {
                    Ok(())
                }
            });
            if result.is_err() {
                assert_eq!(plan.nodes.len(), old_len);
                assert_eq!(plan.nodes[existing].key, old_key);
            }
            let root = interner
                .plan(&value, &mut plan, &mut |_| Ok::<_, Error>(()))
                .unwrap();
            assert_eq!(plan.nodes[root].key, key(&mut interner, &value));
        }
    }
    #[test]
    fn binding_failure_does_not_publish_and_sparse_ids_recover() {
        let mut values = vec![Some(17usize)];
        assert_eq!(
            bind(&mut values, KeyId(100), 42, &mut |_| Err(Error::Fuel)),
            Err(Error::Fuel)
        );
        assert_eq!(values, vec![Some(17)]);
        bind(&mut values, KeyId(100), 42, &mut |_| Ok::<_, Error>(())).unwrap();
        assert_eq!(values[0], Some(17));
        assert_eq!(values[99], None);
        assert_eq!(values[100], Some(42));
    }
}
