# PR263 missing CI trigger: bounded read-only diagnosis

Actual PR base portable/m4-cumulative-expansion-fuel=a3c158ceb942fefd559f90d4b8e25405f971a954.
Head portable/m4-primitive-string-access=9d14186532eeda99fcb00f697b9179d7096ba15d.
PR remains open/draft. Final head Actions query returns zero runs; checks/statuses
also zero. Last repository run remains completed e55 run38973362610.

No concrete workflow/configuration regression found:
- Actions enabled, allowed_actions=all, workflow370493261 active; repository not archived/disabled.
- Exact workflow blob94a42938b0918a5267542cc922dabd21e32cb96b identical at main, actual base, prior triggering e55 and current head.
- pull_request trigger has no types/branch/path filters; opened/synchronize/reopened are default activities.
- push trigger is main-only, so feature-branch pushes rely on pull_request triggering. No workflow_dispatch fallback is configured. This is unchanged, not a demonstrated cause of the regression.
- All eight PR commit messages inspected; no skip CI/actions directive or skip-checks:true trailer found.
- Actual same-repository PR, no fork boundary. Read default workflow permissions do not disable workflow creation.
- PR reopened event recorded at2026-10-16T23:42:13Z. Event presence proves event recording, not delivery/acceptance by the Actions scheduler. API does not expose credentials used for earlier pushes or a trigger-suppression reason; no token hypothesis asserted.

Mergeability findings:
- GitHub repeatedly reports PR263 mergeable=null, mergeable_state=unknown, merge_commit_sha=null.
- git ls-remote shows pull/263/head at9d14186 but NO pull/263/merge ref.
- GitHub compare says ahead8/behind0 and merge-base=a3c158c. Local read-only git merge-base --is-ancestor base head exits0 and merge-base returns the same actual base.
- Therefore a source conflict AGAINST263'S ACTUAL BASE is not supported: that base is an ancestor of head. This is distinct from GitHub failing to provide a mergeability verdict/test merge ref.
- PR256 separately reports mergeable=false/dirty against main; its conflict is not PR263's base relationship. It does not demonstrate that263 conflicts with its base.

Official GitHub behavior reference:
https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#pull_request
Pull-request workflows normally use the PR merge ref and do not run for conflicted PRs.
Here missing merge-ref/unknown mergeability is a concrete GitHub-side observation,
NOT proof that a conflict exists or that this state caused skipped trigger creation.
The API cannot establish why mergeability/test-merge generation or Actions scheduling
has not completed. No service outage or stuck-worker diagnosis is asserted.

Actionable unresolved gate: GitHub must produce a final-head run/check; first
investigate its missing PR263 test-merge/mergeability processing. Current source
has no demonstrated conflict/configuration defect to repair from this evidence.
A GitHub-side diagnostic/support investigation can use the exact head/base,
recorded reopened event, absent merge ref, unchanged workflow blob and zero-run
API responses. No additional trigger mutation, rerun, merge, rebase, branch edit,
source/build/test/production change was performed. Existing local bootstrap
failure remains independent of missing CI and was not re-executed here.

Raw API responses, workflow copies, commit messages, event metadata, remote refs,
ancestry exits and timestamped commands are retained alongside diagnosis-receipt.json.
