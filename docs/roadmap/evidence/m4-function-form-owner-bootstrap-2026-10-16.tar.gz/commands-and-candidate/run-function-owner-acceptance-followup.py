from pathlib import Path
import subprocess,os,time,json,hashlib,re
cache=Path(__file__).parent;root=cache/'frozen-compiler-inputs';run=cache/'function-owner-acceptance-followup';run.mkdir(exist_ok=False)
expected=json.loads((cache/'function-form-owner-check-3/after-bootstrap-freeze.json').read_text())
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in expected}
assert freeze()==expected
(run/'before-freeze.json').write_text(json.dumps(expected,indent=2)+'\n')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(cache/'analyzer-literal-key-target'));env.pop('SUSS_HIR_COW_TRACE',None)
state={'current':None,'stages':[],'input_count':len(expected),'scope':'Actual regenerated bootstrap tuple; separate unchanged default-fuel source-tag and namespace probes, failures preserved. Not full acceptance or baseline.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
commands=[('bootstrap-verifier',['sh','scripts/verify-bootstrap.sh']),('source-tags-default',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_source_tags','--','--test-threads=2','--nocapture']),('namespace-identity-default',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_namespace_identity','--','--test-threads=2','--nocapture'])]
for name,cmd in commands:
 assert freeze()==expected
 entry={'name':name,'command':cmd};state['current']=name;state['stages'].append(entry);save();print('starting '+name,flush=True);start=time.monotonic()
 with (run/(name+'.log')).open('w') as f:result=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 entry.update(exit=result.returncode,seconds=time.monotonic()-start,changed=[p for p,h in expected.items() if freeze()[p]!=h])
 entry['summaries']=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', (run/(name+'.log')).read_text())
 save();print(json.dumps(entry),flush=True)
 if entry['changed'] or (name=='bootstrap-verifier' and result.returncode):break
state['current']=None;state['final_unchanged']=freeze()==expected;save();print(json.dumps(state),flush=True)
