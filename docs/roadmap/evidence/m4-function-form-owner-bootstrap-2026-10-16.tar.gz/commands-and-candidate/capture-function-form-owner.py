from pathlib import Path
import subprocess,os,json,hashlib,sys
cache=Path('/home/bobby/.cache/suss-m4-work')
primary=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access')
root=cache/'frozen-compiler-inputs'
label=sys.argv[1]
paths=set(json.loads((cache/'draft263-unpublished-source-inputs.json').read_text()))
paths.update(str(p.relative_to(primary)) for p in (primary/'crates').rglob('*.rs'))
hashes={}
for rel in sorted(paths):
 data=(subprocess.check_output(['git','show','HEAD:'+rel],cwd=primary) if rel.startswith('runtime/bootstrap/') else (primary/rel).read_bytes())
 target=root/rel
 target.parent.mkdir(parents=True,exist_ok=True)
 if not target.is_file() or target.read_bytes()!=data:
  temp=target.with_name(target.name+'.function-owner-tmp')
  temp.write_bytes(data);os.replace(temp,target)
 hashes[rel]=hashlib.sha256(data).hexdigest()
(cache/(label+'-inputs.json')).write_text(json.dumps(hashes,indent=2)+'\n')
(cache/(label+'-primary-diff.patch')).write_bytes(subprocess.check_output(['git','diff','--','crates'],cwd=primary))
(cache/(label+'-base.txt')).write_bytes(subprocess.check_output(['git','rev-parse','HEAD'],cwd=primary))
print('Captured',len(hashes),'compiled inputs with HEAD bootstrap; primary source agents paused.')
