from pathlib import Path
import os,json,subprocess,time,hashlib
root=Path('/home/bobby/Work/code/bobby/suss');cache=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(root/'target-m4-prototype'),RAYON_NUM_THREADS='2')
files=[p for p in (root/'crates').rglob('*') if p.suffix in ['.rs','.sus']]+list((root/'runtime/bootstrap').glob('*'))
freeze={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
state={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'freeze':freeze,'stages':[]};receipt=cache/'current107-binding-locations-result.json'
targets=[('compiled_macro_local_reference_asts','reference_asts_keep_initializer_scope_metadata_and_variadic_self_identity'),('compiled_macro_form_source_metadata','compiled_source_macro_form_retains_reader_positions_on_nested_syntax'),('compiled_macro_form_source_metadata','compiled_source_macro_file_metadata_uses_the_loaded_source_path'),('compiled_macro_declaration_functions','compiled_argument_lists_preserve_quoted_data_and_actual_file_positions')]
for target,name in targets:
 cmd=['cargo','test','-p','suss-cli','--locked','--test',target,name,'--','--test-threads=2','--nocapture'];state['current']=name;receipt.write_text(json.dumps(state,indent=2)+'\n');start=time.time()
 with (cache/('current107-'+name+'.log')).open('w') as log: child=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 state['stages'].append({'name':name,'command':cmd,'exit':child.returncode,'seconds':time.time()-start})
state.update(current=None,source_unchanged=all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in freeze.items()));receipt.write_text(json.dumps(state,indent=2)+'\n')
