import os,json,hashlib,subprocess
from pathlib import Path
root=Path('/home/bobby/Work/code/bobby/suss');cache=Path('/home/bobby/.cache/suss-m4-work')
paths=[p for b in ['crates','runtime'] for p in (root/b).rglob('*') if p.is_file() and (p.suffix in ['.rs','.sus','.wasm'] or str(p.relative_to(root)).startswith('runtime/bootstrap/'))]
frozen={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
state={'current':None,'stages':[],'source-hashes':frozen}
out=cache/'raw-key-head-focused-result.json'
env=os.environ.copy();env.update(PATH='/home/bobby/.cargo/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(root/'target-m4-prototype'),SUSS_INPUT_INDEX_TRACE='1',SUSS_METADATA_FUEL_TRACE='1',SUSS_MACRO_FUEL_TRACE='1')
stages=[('raw-keys',['cargo','test','-p','suss-compile','--locked','--lib','raw_keys','--','--test-threads=2','--nocapture']),('original-function',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_declaration_functions','compiled_function_declarations_match_primary_presence_and_parameter_shapes','--','--test-threads=2','--nocapture'])]
stages.append(('catalog',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_compiler_catalog','compiler_catalog_policy_is_opt_in_and_invalid_metadata_keeps_old_macro','--','--test-threads=2','--nocapture']))
env['SUSS_RAW_KEY_TRACE']='1'
for name,cmd in stages:
 log=cache/('raw-key-head-tariff-'+name+'.log')
 with log.open('wb') as stream:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
  state['current']={'name':name,'pid':p.pid,'log':str(log),'command':cmd};out.write_text(json.dumps(state,indent=2)+'\n');code=p.wait()
 state['stages'].append({**state['current'],'exit_code':code});state['current']=None
 state['source-unchanged']=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in frozen.items());out.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state['stages'][-1]),flush=True)
 if (code and name=='raw-keys') or not state['source-unchanged']:raise SystemExit(code or 1)
