from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-ihash-dispatch-boundary');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env.update(PATH='/home/bobby/.cargo/bin:'+env['PATH'],CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'ihash-dispatch-target'),RAYON_NUM_THREADS='2')
files=[p for p in (r/'crates').rglob('*') if p.suffix in ['.rs','.sus']]+list((r/'runtime/bootstrap').glob('*'));freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_cumulative_fuel','--','--test-threads=2','--nocapture'];state={'current':'profile','command':cmd,'started':time.time(),'freeze':freeze,'limits':['First Runtime caller aborts before second Macro caller on failure.','Realization delta includes callback-triggered host work; not pure Wasm instructions.']};p=c/'ihash-dispatch-public-cumulative-result.json';p.write_text(json.dumps(state,indent=2)+'\n')
with (c/'ihash-dispatch-public-cumulative.log').open('w') as f:child=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
state.update(current=None,exit=child.returncode,seconds=time.time()-state['started'],source_unchanged=all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in freeze.items()));p.write_text(json.dumps(state,indent=2)+'\n')
