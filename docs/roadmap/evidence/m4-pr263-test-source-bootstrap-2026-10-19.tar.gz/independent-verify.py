from pathlib import Path,PurePosixPath
import hashlib,json,subprocess,zipfile,io,stat
r=Path(__file__).parent;head='19f62117ff686a7b11b59710fb69721bb9c0c303';runid=39298297611;artifactid=12209851821
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args])
def obj(p):return git('show',head+':'+p)
blob=(r/'artifact.zip').read_bytes();z=zipfile.ZipFile(io.BytesIO(blob))
names=[f'{phase}.{ext}' for phase in ['runtime','macro'] for ext in ['wasm','json']]
allowed={'receipt.json'}|{f'{rep}/{name}' for rep in ['first','second'] for name in names}
assert len(z.infolist())==len(allowed)==9 and set(z.namelist())==allowed
for e in z.infolist():
 assert not e.is_dir() and not PurePosixPath(e.filename).is_absolute() and '..' not in PurePosixPath(e.filename).parts
 assert stat.S_IFMT(e.external_attr>>16) in [0,stat.S_IFREG]
assert sum(e.file_size for e in z.infolist())<32*1024*1024
files={name:z.read(name) for name in allowed};receipt=json.loads(files['receipt.json']);assert (r/'files/receipt.json').read_bytes()==files['receipt.json']
assert receipt['reproductions_match'] and receipt['source']['working_tree_clean'] and not receipt['shipped_matches_first']
assert set(receipt['files'])==allowed-{'receipt.json'}
for name,d in receipt['files'].items():
 assert sha(files[name])==d['sha256'] and len(files[name])==d['bytes']
 assert (r/'files'/name).read_bytes()==files[name]
for name in names:assert files['first/'+name]==files['second/'+name]
run=json.loads((r/'run-api.json').read_text());art=json.loads((r/'artifact-api.json').read_text());merge=json.loads((r/'merge-api.json').read_text());branch=json.loads((r/'branch-api.json').read_text());binding=json.loads((r/'source-binding.json').read_text())
assert run['id']==runid and run['head_sha']==head
assert art['id']==artifactid and not art['expired'] and art['workflow_run']['id']==runid and art['workflow_run']['head_sha']==head
assert merge['sha']==receipt['source']['head'] and branch['sha']==head
assert any(p['sha']==head for p in merge['parents'])
tree=git('rev-parse',head+'^{tree}').decode().strip()
assert tree==merge['commit']['tree']['sha']==branch['commit']['tree']['sha']==receipt['source']['tree']=='a8385a71994c2cf2cd031ee158a5d60251e5b13b'
assert art['name']=='bootstrap-reproduction-'+merge['sha'] and art['size_in_bytes']==len(blob)
assert binding['zip_sha256']==sha(blob) and binding['head']==head and binding['run']==runid and binding['artifact_id']==artifactid
# Independent source fingerprint from immutable Git objects, matching build.rs.
fixed=['Cargo.toml','Cargo.lock','crates/suss-compile/build.rs','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json']
fixed += ['vendor/wasi/wasi-wit-0.3.1/cli/'+n+'.wit' for n in ['cli','deps/clocks','deps/filesystem','deps/random','deps/sockets']]
paths=git('ls-tree','-r','--name-only',head,'--','crates/suss-core','crates/suss-reader','crates/suss-compile').decode().splitlines()
inputs=fixed+[f'crates/{c}/Cargo.toml' for c in ['suss-core','suss-reader','suss-compile']]
for p in paths:
 if any(p.startswith('crates/'+c+'/src/') for c in ['suss-core','suss-reader','suss-compile']) and PurePosixPath(p).suffix in ['.rs','.sus']:inputs.append(p)
assert len(inputs)==len(set(inputs))
# Rust PathBuf Ord compares components, not a flattened slash-delimited string.
h=hashlib.sha256();source_hashes={}
for p in sorted(inputs,key=lambda p:PurePosixPath(p).parts):
 data=obj(p);pbytes=p.encode();h.update(len(pbytes).to_bytes(8,'little'));h.update(pbytes);h.update(len(data).to_bytes(8,'little'));h.update(data);source_hashes[p]=sha(data)
assert len(inputs)==204
fp=h.hexdigest();assert fp==binding['compiler_source_sha256']=='d7bdce3f2208c5102f3173e0b0ce091437957cf3d60cb5f6ef98e3c476e0274b'
def sections(b):
 assert b[:8]==b'\0asm\x01\0\0\0';i=8;out=[]
 while i<len(b):
  start=i;kind=b[i];i+=1;n=0;shift=0
  while True:
   v=b[i];i+=1;n|=(v&127)<<shift
   if v<128:break
   shift+=7;assert shift<35
  assert i+n<=len(b)
  if kind:out.append((kind,b[start:i+n]))
  i+=n
 return out
adopt={};comparison={}
for phase in ['runtime','macro']:
 new=json.loads(files['first/'+phase+'.json']);oldbytes=obj('runtime/bootstrap/'+phase+'.json');old=json.loads(oldbytes)
 assert (r/'previous-shipped'/f'{phase}.json').read_bytes()==oldbytes
 assert new['phase']==phase and new['compiler_source_sha256']==fp and new['wasm_sha256']==sha(files['first/'+phase+'.wasm'])
 assert {k:v for k,v in new.items() if k not in ['compiler_source_sha256','wasm_sha256']}=={k:v for k,v in old.items() if k not in ['compiler_source_sha256','wasm_sha256']}
 before=obj('runtime/bootstrap/'+phase+'.wasm');assert (r/'previous-shipped'/f'{phase}.wasm').read_bytes()==before
 # Previous3c shipped bytes are also verified, not inferred from filenames.
 assert git('show','3c0ed52:runtime/bootstrap/'+phase+'.wasm')==before
 old_sections=sections(before);new_sections=sections(files['first/'+phase+'.wasm']);assert old_sections==new_sections
 comparison[phase]={'noncustom_sections_identical':True,'section_ids':[x[0] for x in new_sections],'previous_full_sha256':sha(before),'generated_full_sha256':sha(files['first/'+phase+'.wasm'])}
 for ext in ['wasm','json']:
  name=phase+'.'+ext;adopt['runtime/bootstrap/'+name]={'artifact_path':'first/'+name,'sha256':sha(files['first/'+name]),'bytes':len(files['first/'+name])}
log=Path('/home/bobby/.cache/suss-m4-work/pr263-19f-native-feedback/foundation.log').read_bytes();text=log.decode()
assert 'first/runtime.wasm runtime/bootstrap/runtime.wasm differ: byte 2107602' in text
assert 'test result:' not in text
assert text.count('target/debug/suss-bootstrap /tmp/')==2
review={'verdict':'GO_ADOPT_EXACT_FOUR_NORMAL_GENERATED_OUTPUTS_SOURCE_BINDING_ONLY','head':head,'tree':tree,'run':runid,'artifact':artifactid,'merge_checkout':merge['sha'],'zip_sha256':sha(blob),'safe_exact_zip_members':9,'all8_hashes_sizes_and_extracted_copies_verified':True,'four_pairs_byte_identical':True,'source_fingerprint_independently_recomputed':fp,'fingerprint_input_count':len(inputs),'fingerprint_policy':'Exact immutable Git bytes, build.rs fixed inputs and three crate src trees, Rust component-path ordering','source_binding_matches_cached_official_run_artifact_merge_branch_API':True,'all_other_manifest_fields_exact_old':True,'previous_saved_outputs_match_git_head_and3c':True,'noncustom_sections':comparison,'adopt_only':adopt,'foundation_raw_sha256':sha(log),'raw_scope':'Two normal native generator invocations complete; unchanged shipped cmp fails at byte2107602. No test result/execution acceptance from foundation. GitHub Node-based actions are not claimed Node-free; the native generator itself is not a JS/Java oracle.','limits':['No Cargo, bootstrap regeneration, VM/linking/validation or runtime tests performed by reviewer','Artifact adoption is not checked restoration or default core17/strict sourcechild proof','Does not approve source author correctness, full request cost, issue closure, CI completion or promotion','BOOT adoption changes only four exact byte outputs; successor source/fingerprint identity and native execution gates still required']}
# The only source delta from3c is one cfg(test) input dereference.
prior='3c0ed52'
changed=git('diff','--name-only',prior,head,'--','*.rs').decode().splitlines()
assert changed==['crates/suss-compile/src/portable_macro_graph/type_value_regression_tests.rs']
old_test=git('show',prior+':'+changed[0]);new_test=obj(changed[0])
assert b'let origin = portable::SourceOrigin::new(source, None);' in old_test
assert old_test.replace(b'SourceOrigin::new(source, None)',b'SourceOrigin::new(*source, None)',1)==new_test
review['source_delta_from_previous3c']='Only cfg(test) SourceOrigin::new(source,None) -> SourceOrigin::new(*source,None); exact whole-file inverse verified'
(r/'independent-source-input-hashes.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
(r/'independent-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'verdict':review['verdict'],'receipt':str(r/'independent-review.json'),'fp':fp,'inputs':len(inputs),'adopt':adopt},indent=2))
