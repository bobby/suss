"""Pair opt-in native intervals; keep inclusive parents separate from children."""
import re,json,sys,hashlib,collections
from pathlib import Path
raw=Path(sys.argv[1]);stage=None;stack=[];events=[];warnings=[]
patterns=[
 ('constructor',re.compile(r'source-constructor-fact phase=(\S+) event=(before|after).*remaining=Some\((\d+)\)')),
 ('domain',re.compile(r'source-domain-record domain=\S+ fact=Constructor phase=(direct-fact) event=(before|after).*remaining=Some\((\d+)\)')),
 ('factory',re.compile(r'source-materialize-call label=(constructor-and-native-fact) event=(before|after).*remaining=Some\((\d+)\)')),
]
for lineno,line in enumerate(raw.open(),1):
 m=re.search(r'source-child-fuel source=(\S+) variant=(None|Some\(\d+\)) stage=(\S+)',line)
 if m:stage='/'.join(m.groups())
 for kind,pattern in patterns:
  m=pattern.search(line)
  if not m:continue
  label,event,fuel=m[1],m[2],int(m[3])
  if event=='before':
   context='other'
   if label=='schema-matches':
    for parent in reversed(stack):
     if parent['kind']=='constructor' and parent['label']=='postconstructor-matches':context='postconstructor';break
     if parent['kind']=='domain':context='enrollment';break
   stack.append(dict(kind=kind,label=label,context=context,stage=stage,start_line=lineno,start_fuel=fuel))
  else:
   assert stack and (stack[-1]['kind'],stack[-1]['label'])==(kind,label),(lineno,kind,label,stack[-1] if stack else None)
   e=stack.pop();e.update(end_line=lineno,end_fuel=fuel,inclusive_fuel=e['start_fuel']-fuel,result='error' if 'result=Err' in line else ('false' if 'Ok(false)' in line else 'ok'))
   if e['inclusive_fuel']<0:warnings.append({'line':lineno,'reason':'fuel increased within interval'})
   events.append(e)
  break
by={}
for e in events:
 st=e['stage'].split('/') if e['stage'] else ['unassigned','unassigned']
 key=(st[0],st[1],e['kind'],e['label'],e['context'],e['result'])
 g=by.setdefault(key,{'count':0,'inclusive_fuel':0,'min':None,'max':None});v=e['inclusive_fuel'];g['count']+=1;g['inclusive_fuel']+=v;g['min']=v if g['min'] is None else min(g['min'],v);g['max']=v if g['max'] is None else max(g['max'],v)
r={'raw':str(raw),'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'groups':[dict(zip(['phase','variant','kind','label','context','result'],k),**v) for k,v in by.items()],'events':events,'open_intervals':stack,'warnings':warnings,'qualification':'Inclusive measurements; parent and nested schema costs overlap and must not be added. Phase/variant use last observed source-child marker; setup is unassigned. Errors/open intervals retained. No unique-object/source-authority/cache-reuse claim.'}
print(json.dumps(r,indent=2))
