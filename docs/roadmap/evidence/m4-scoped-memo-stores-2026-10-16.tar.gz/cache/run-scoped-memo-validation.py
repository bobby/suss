from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-scoped-memo-stores');c=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'scoped-memo-target')
paths=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.sus')]+list((r/'runtime/bootstrap').glob('*'))
freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
out=c/'scoped-memo-validation-result.json';result={'base':'bb0a3b0','freeze':freeze,'stages':[],'current':None,'source_unchanged':True}
stages=[]
for name,selector in [('receipts','receipt_tests'),('domain','write_domain::tests'),('observer','ihash_dispatch_boundary_'),('canonical-errors','private_memo_bridge_preserves_')]:
 stages.append((name,['cargo','test','-p','suss-compile','--lib','--locked',selector,'--','--test-threads=2','--nocapture']))
stages += [('runtime',['cargo','test','-p','suss-compile','--locked','--test','runtime_abi','runtime_abi_nominal_identity_fields_and_live_protocols_cross_fragments_after_gc','--','--test-threads=2']),('public',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_cumulative_fuel','--','--test-threads=2','--nocapture']),('provenance',['python3','scripts/check_record_macro_provenance.py'])]
for name,cmd in stages:
 result['current']=name;out.write_text(json.dumps(result,indent=2));start=time.time()
 with (c/f'scoped-memo-validation-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 result['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start});result['current']=None
 result['source_unchanged']=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in freeze.items());out.write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='freeze'},indent=2))
