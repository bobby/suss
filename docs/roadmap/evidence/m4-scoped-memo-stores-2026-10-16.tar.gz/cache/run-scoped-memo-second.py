from pathlib import Path
import os,subprocess,time,json,hashlib,tarfile
r=Path('/home/bobby/Work/code/bobby/suss-m4-scoped-memo-stores');c=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'scoped-memo-target')
receipt={'stages':[]};out=c/'scoped-memo-second-result.json'
for name,cmd in [('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('native',['cargo','test','-p','suss-compile','--lib','--locked','scoped_memo_stores_','--','--test-threads=2','--nocapture'])]:
 start=time.time();receipt['current']=name;out.write_text(json.dumps(receipt,indent=2))
 with (c/f'scoped-memo-second-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 receipt['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start});receipt['current']=None;out.write_text(json.dumps(receipt,indent=2))
 if p.returncode:break
print(json.dumps(receipt,indent=2))
