from pathlib import Path
r=Path('/home/bobby/Work/code/bobby/suss-m4-scoped-memo-stores')
def edit(n,a,b):
 p=r/n;s=p.read_text();assert a in s,(n,a[:60]);p.write_text(s.replace(a,b,1))
p='crates/suss-compile/src/runtime_abi/dispatch_observer.rs'
edit(p,'    ty: u32,','    ty: u32,\n    store_ty: u32,')
edit(p,'    b.dispatch_observer = Some(Hooks { ty });','''    let store_ty = b.next_type;
    b.next_type += 1;
    b.types.ty().function([reference(ARGS), ValType::I32, VALUE], []);
    b.dispatch_observer = Some(Hooks { ty, store_ty });''')
with (r/p).open('a') as f:f.write('''
// Operand preparation, casts and guards stay at their original sites.
pub(super) fn store(b: &Builder, body: &mut Vec<Instruction<'static>>) {
    if let Some(hook) = b.dispatch_observer {
        body.extend([GlobalGet(CALLBACK + 1), CallRef(hook.store_ty)]);
    } else { body.push(ArraySet(ARGS)); }
}
''')
edit(p,'    b.function(SETTER, &[reference(hook.ty)], &[], &code);','''    b.function(SETTER, &[reference(hook.ty)], &[], &code);
    globals.global(GlobalType {
        val_type: ValType::Ref(RefType { nullable: true, heap_type: HeapType::Concrete(hook.store_ty) }),
        mutable: true, shared: false,
    }, &ConstExpr::ref_null(HeapType::Concrete(hook.store_ty)));
    let mut code = vec![GlobalGet(CALLBACK + 1), RefIsNull, I32Eqz, If(BlockType::Empty)];
    nominal::error(&mut code);
    code.extend([End, LocalGet(0), GlobalSet(CALLBACK + 1)]);
    b.function("macro-memo-store-install", &[reference(hook.store_ty)], &[], &code);
    b.function("macro-memo-array-store", &[reference(ARGS), ValType::I32, VALUE], &[],
        &[LocalGet(0), LocalGet(1), LocalGet(2), ArraySet(ARGS)]);''')
p='crates/suss-compile/src/runtime_abi/nominal.rs'
edit(p,'            body.extend([LocalGet(2), ArraySet(ARGS)]);','''            body.push(LocalGet(2));
            if b.dispatch_observer.is_some() {
                let mut raw = body.clone();
                raw.push(ArraySet(ARGS));
                b.function_with_locals("macro-memo-field-set", &[VALUE, ValType::I32, VALUE], &[], &[(1, VALUE)], &raw);
            }
            dispatch_observer::store(b, &mut body);''')
p='crates/suss-compile/src/runtime_abi/named_properties.rs'
# unique target after payload/slot, not callable property table store
edit(p,'            body.extend([LocalGet(2), ArraySet(ARGS), LocalGet(2), Return]);\n        } else {\n            body.extend([ArrayGet(ARGS), Return]);\n        }\n        body.push(End);\n        if writing {\n            nominal::error(&mut body); // Dynamic extra instance fields','''            body.push(LocalGet(2));
            dispatch_observer::store(b, &mut body);
            body.extend([LocalGet(2), Return]);
        } else {
            body.extend([ArrayGet(ARGS), Return]);
        }
        body.push(End);
        if writing {
            nominal::error(&mut body); // Dynamic extra instance fields''')
p='crates/suss-compile/src/portable_session/dispatch_observer.rs'
edit(p,'impl Observer {','''impl Observer {
    // Returned root belongs to the caller's active Wasmtime rooting scope.
    pub(super) fn receiver(&self, mut store: wasmtime::StoreContextMut<'_, ()>) -> Option<Val> {
        registry_lock(&self.state).nearest_ihash().map(|frame|
            Val::AnyRef(Some(frame._receiver.value.to_rooted(&mut store))))
    }
''')
p='crates/suss-compile/src/portable_session.rs'
edit(p,'        let environment = Environment::default();','''        if let Some(observer) = &dispatch_observer {
            memo_bridge::install_scoped(&mut store, runtime, interrupt.clone(), memo_ledger.clone(), observer.clone())?;
        }
        let environment = Environment::default();''')
edit(p,'import.name() == "macro-dispatch-observer-install"','''matches!(import.name(), "macro-dispatch-observer-install" | "macro-memo-store-install" | "macro-memo-array-store" | "macro-memo-field-set")''')
p='crates/suss-compile/src/portable_session/memo_bridge.rs'
edit(p,'let setter = runtime.get_func(&mut *store, "object-field-set")','''let setter = runtime.get_func(&mut *store, "macro-memo-field-set")
        .or_else(|| runtime.get_func(&mut *store, "object-field-set"))''')
# scoped domain policy argument canonical None
edit(p,'irq,authority,prototype,staged.map(|receipt|(self,receipt)))','irq,authority,prototype,staged.map(|receipt|(self,receipt)),None)')
# add helper usable write_domain
edit(p,'    pub(super) fn slot(&self)', '''    pub(super) fn domain_method(&self, mut store: StoreContextMut<'_, ()>, runtime: Instance,
        authority: &CanonicalMethods, irq: &AtomicBool, layout_descriptor: Option<&Val>,
    ) -> wasmtime::Result<bool> {
        Session::consume_host_work(store.as_context_mut(), 1, irq)?;
        let descriptor = Val::AnyRef(Some(self.descriptor.value.to_rooted(&mut store)));
        let relaxed = if let Some(active) = layout_descriptor { same(&store, &descriptor, active)? } else { false };
        self.method_valid(store, runtime, authority, irq, !relaxed)
    }
    pub(super) fn slot(&self)''')
p='crates/suss-compile/src/portable_session/write_domain.rs'
edit(p,'        staged: Option<(&Watch, &Receipt)>,','''        staged: Option<(&Watch, &Receipt)>,
        layout_descriptor: Option<&Val>,''')
edit(p,'canonical &= watch.canonical(store.as_context_mut(), runtime, methods, irq)?;','canonical &= watch.domain_method(store.as_context_mut(), runtime, methods, irq, layout_descriptor)?;')
