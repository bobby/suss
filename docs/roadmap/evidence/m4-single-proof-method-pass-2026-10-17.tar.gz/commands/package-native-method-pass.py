#!/usr/bin/env python3
"""Cache-only evidence packager. No Cargo, git writes, or source modifications.
Default prints a manifest outline. --package requires every producer terminal.
"""
from pathlib import Path
import argparse,hashlib,io,json,re,tarfile,subprocess
CACHE=Path(__file__).resolve().parent
ATTEMPTS=[('native-method-pass-candidate','Bounded invocation-local method-query reuse; terminal raw results authoritative')]
FOUNDATIONS=['native-method-pass-foundation']
COMMANDS=['run-native-method-pass-candidate.py','native-method-pass-command-plan.json','run-native-method-pass-foundation.py','package-native-method-pass.py','method-pass-bootstrap-correspondence.json']
BOOT={f'runtime/bootstrap/{phase}.{ext}' for phase in ['macro','runtime'] for ext in ['wasm','json']}
sha=lambda data:hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text())
def safe_read(path):
 assert not path.is_symlink(),('symlink not packaged',str(path))
 return path.read_bytes()
REPO=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots')

def checkpoint_binding(repo, checkpoint, expected, input_bytes):
 """Resolve exact committed blobs, following pinned gitlinks, never worktree bytes."""
 resolved=subprocess.check_output(['git','-C',str(repo),'rev-parse','--verify',checkpoint+'^{commit}'],text=True).strip()
 assert resolved==checkpoint,'checkpoint must name an exact commit'
 result=dict(checkpoint=resolved,paths=len(expected),matched=[],missing=[],changed=[],object_sources=[])
 def walk(directory, revision, prefix, requests):
  tree=subprocess.run(['git','-C',str(directory),'ls-tree','-rz','--full-tree',revision],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if tree.returncode:
   result['missing'].extend(dict(path=p,reason='pinned repository/tree unavailable',repository=str(directory),revision=revision) for p,_ in requests);return
  entries={}
  for row in tree.stdout.split(b'\0'):
   if row:
    meta,path=row.split(b'\t',1);mode,kind,oid=meta.decode().split();entries[path.decode()]=(mode,kind,oid)
  blobs=[];submodules={}
  for full,local in requests:
   entry=entries.get(local)
   if entry is not None and entry[1]=='blob':blobs.append((full,local,entry));continue
   links=[p for p,e in entries.items() if e[0]=='160000' and local.startswith(p+'/')]
   if links:
    link=max(links,key=len);submodules.setdefault(link,[]).append((full,local[len(link)+1:]));continue
   result['missing'].append(dict(path=full,reason='no committed blob at path',repository=str(directory),revision=revision))
  # communicate() drains stdout while supplying commands; no pipe deadlock on
  # large paths/blob output. No object writes, filters, fetches or working files.
  if blobs:
   assert all('\n' not in local and '\r' not in local for _,local,_ in blobs)
   command=''.join(revision+':'+local+'\n' for _,local,_ in blobs).encode()
   proc=subprocess.run(['git','-C',str(directory),'cat-file','--batch'],input=command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   assert proc.returncode==0,proc.stderr.decode(errors='replace')
   output=io.BytesIO(proc.stdout)
   for full,local,entry in blobs:
    header=output.readline().decode().rstrip('\n').split()
    assert len(header)==3 and header[1]=='blob',(full,header)
    size=int(header[2]);data=output.read(size);assert len(data)==size and output.read(1)==b'\n'
    digest=sha(data);archived=input_bytes[expected[full]]
    source=dict(path=full,repository_prefix=prefix,revision=revision,git_blob=header[0])
    result['object_sources'].append(source)
    if digest==expected[full] and data==archived:result['matched'].append(full)
    else:result['changed'].append(dict(**source,expected_sha256=expected[full],committed_sha256=digest,archived_bytes=len(archived),committed_bytes=len(data)))
   assert not output.read(),'unparsed batch output'
  for link,children in submodules.items():
   pinned=entries[link][2]
   walk(directory/link,pinned,prefix+link+'/',children)
 walk(Path(repo),resolved,'',[(p,p) for p in sorted(expected)])
 result['matched_count']=len(result['matched']);result['missing_count']=len(result['missing']);result['changed_count']=len(result['changed'])
 result['exact_match']=result['matched_count']==len(expected) and not result['missing'] and not result['changed']
 return result

def foundation_hash_binding(base, correspondence, expected, freeze_bytes):
 """Check supplied path hashes; explicitly qualify historical count-only receipts."""
 report=dict(verified_maps=[],verified_manifest_digests=[],mismatches=[],hash_maps_supplied=False)
 fields={'hashes','input_hashes','source_hashes','expected_hashes','actual_hashes','before_hashes','after_hashes','inputs','expected','actual','before','after','frozen','tuple'}
 def visit(value, label, recognized=False):
  if not isinstance(value,dict):return
  mapped={}
  for k,v in value.items():
   digest=v if isinstance(v,str) else v.get('sha256') if isinstance(v,dict) else None
   if isinstance(digest,str) and re.fullmatch('[0-9a-f]{64}',digest):mapped[k]=digest
  # A named hash map or any map containing known input paths is evidence that
  # must be checked, not silently ignored on partial/malformed coverage.
  for path in set(value)&set(expected):
   if path not in mapped:report['mismatches'].append(dict(path=path,location=label,reason='supplied source hash is malformed or missing'))
  if recognized and label.split('/')[-1] in {'hashes','input_hashes','source_hashes','expected_hashes','actual_hashes','before_hashes','after_hashes'}:
   for path in set(value)-set(mapped):report['mismatches'].append(dict(path=path,location=label,reason='malformed hash entry'))
  if mapped and (recognized or set(mapped)&set(expected)):
   report['hash_maps_supplied']=True;bad=[]
   for path,digest in mapped.items():
    if path not in expected or expected[path]!=digest:bad.append(dict(path=path,reported=digest,expected=expected.get(path)))
   report['verified_maps'].append(dict(location=label,paths=len(mapped),full_tuple_coverage=set(mapped)==set(expected),matched=len(mapped)-len(bad)))
   report['mismatches'].extend(bad)
  for k,v in value.items():
   if k in {'freeze_sha256','source_freeze_sha256','input_manifest_sha256','source_manifest_sha256'} and isinstance(v,str):
    actual=sha(freeze_bytes);report['verified_manifest_digests'].append(dict(location=label+'/'+k,reported=v,actual=actual))
    if v!=actual:report['mismatches'].append(dict(location=label+'/'+k,reported=v,expected=actual))
   if isinstance(v,dict):visit(v,label+'/'+k,k in fields)
 visit(correspondence,'source-correspondence.json')
 for path in sorted(base.glob('*.json')):
  if path.name!='source-correspondence.json' and ('freeze' in path.name or 'hashes' in path.name):visit(load(path),path.name,True)
 report['qualification']='Supplied hashes verified against archived source tuple; partial maps remain partial.' if report['hash_maps_supplied'] or report['verified_manifest_digests'] else 'No per-path hashes or manifest digest supplied. Original input-count/unchanged assertion is preserved; not promoted to independent hash proof.'
 return report

def attempted_stages(base,receipt):
 plan=load(base/'command-plan.json');observed={s['name']:s for s in receipt['stages']}
 rows=[]
 for item in plan:
  s=observed.get(item['name']);raw=base/(item['name']+'.log')
  rows.append(dict(name=item['name'],command=item['command'],receipt_exit=None if s is None else s.get('exit'),
   status='unexecuted' if s is None else ('terminal-recorded' if 'exit' in s else 'no-stage-exit-recorded'),
   raw_log_present=raw.exists(),raw_test_summaries=[] if not raw.exists() else
    re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw.read_text())))
 return rows

def terminal_attempt(base):
 receipt=load(base/'receipt.json');stopfile=base/'targeted-stop-receipt.json'
 if stopfile.exists():
  stop=load(stopfile)
  assert stop['terminal_exit']==130,('unexpected targeted-stop exit',base)
  assert not stop['group_ps_after'].strip(),('stop does not prove group empty',base)
  assert stop.get('group_ps_exit')==1,('unexpected process group check',base)
  flags=[v for k,v in stop.items() if re.fullmatch(r'all\d+inputs_unchanged_at_stop',k)]
  assert flags==[True],('stop source unchanged proof missing',base)
  disposition='targeted-stop; receipt.current may remain stale; raw failures and unfinished stages preserved'
 else:
  assert receipt.get('current') is None,('PRODUCER NOT TERMINAL',str(base),receipt.get('current'))
  assert receipt.get('final_changed')==[],('final source check missing/changed',base)
  assert receipt['stages'] and all('exit' in s for s in receipt['stages']),('unfinished stage receipt',base)
  disposition='terminal receipt (may contain failures; not acceptance)'
 assert all(not s.get('unexpected_input_changes') for s in receipt['stages'])
 return receipt,disposition

def outline():
 return dict(attempts=ATTEMPTS,foundations=FOUNDATIONS,limits=['110 pass executions/5 failures include five repeated new tests, not unique counts','Foundation13 count-only correspondence remains qualified','Sourcechild Runtime4 and map invocation fuel failure retained; map0assertions69unexecuted','No full baseline/CI or issue completion claim','Historical source-review documents include pre-execution wording; final logs authoritative','d21 map trace is parent evidence, not a ce88795 execution'])

def package(args):
 assert args.source_checkpoint=='ce88795e8174937e64de3a8457266d29e8520950','Exact committed ce88795 required'
 out=Path(args.output).resolve();assert out.is_relative_to(CACHE),'cache-only output required'
 assert not out.exists(),'refuse overwrite'
 files={};origins={};tuples={};attempts={};foundation={};bootstrap_deltas={}
 def add(name,data,origin=None):
  assert name not in files or files[name]==data,('payload conflict',name)
  files[name]=data
  if origin:origins[str(origin)]=sha(data)
 for directory,qualification in ATTEMPTS:
  base=CACHE/directory;receipt,disposition=terminal_attempt(base)
  before=load(base/'before-freeze.json');assert len(before)==receipt['input_count']
  labels=['before']
  if (base/'after-bootstrap-freeze.json').exists():labels.append('after-bootstrap')
  else:assert not any(s['name']=='bootstrap' and s.get('exit')==0 for s in receipt['stages']),('successful bootstrap lacks snapshot',base)
  for label in labels:
   frozen=load(base/(label+'-freeze.json'));tuples[directory+'/'+label]=frozen
   for rel,digest in frozen.items():
    assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
    assert re.fullmatch('[0-9a-f]{64}',digest),('invalid tuple digest',rel)
    path=base/label/rel;data=safe_read(path);assert sha(data)==digest,('tuple mismatch',path)
    add('inputs/'+digest,data,path)
  if len(labels)==2:
   after=tuples[directory+'/after-bootstrap'];assert set(after)==set(before)
   changed=[p for p in before if before[p]!=after[p]];assert set(changed)<=BOOT,('unexpected bootstrap source changes',directory,changed)
   bootstrap_deltas[directory]=changed
  else:bootstrap_deltas[directory]=None
  attempts[directory]=dict(qualification=qualification,disposition=disposition,stages=attempted_stages(base,receipt),
   after_bootstrap_snapshot_present=len(labels)==2)
 for directory in FOUNDATIONS:
  base=CACHE/directory;receipt=load(base/'receipt.json');cor=load(base/'source-correspondence.json')
  assert len(receipt)==cor['commands']==13 and all('exit' in row for row in receipt),('foundation not terminal',directory)
  assert cor['inputs_unchanged'] and cor['changed']==[]
  assert cor['all_exit0']==all(row['exit']==0 for row in receipt)
  source_attempt='native-method-pass-candidate'
  assert cor['input_count']==len(tuples[source_attempt+'/after-bootstrap'])
  hash_binding=foundation_hash_binding(base,cor,tuples[source_attempt+'/after-bootstrap'],safe_read(CACHE/source_attempt/'after-bootstrap-freeze.json'))
  if hash_binding['mismatches']:
   report=out.with_name(out.stem+'-'+directory+'-hash-mismatch.json');report.write_text(json.dumps(hash_binding,indent=2)+'\n')
   raise AssertionError(('foundation hash mismatch',str(report)))
  assert all((base/(str(i)+'.log')).is_file() for i in range(13))
  foundation[directory]=dict(source_tuple=source_attempt+'/after-bootstrap',command_count=len(receipt),actual_exits=[row['exit'] for row in receipt],source_correspondence=cor,hash_binding=hash_binding)
 # Preserve all raw evidence files, excluding only full byte snapshots already
 # stored content-addressed above. Freeze manifests themselves are retained.
 for directory in [d for d,_ in ATTEMPTS]+FOUNDATIONS:
  base=CACHE/directory
  for path in sorted(base.rglob('*')):
   if path.is_file() and path.relative_to(base).parts[0] not in ['before','after-bootstrap']:
    add('runs/'+directory+'/'+path.relative_to(base).as_posix(),safe_read(path),path)
 for name in COMMANDS:
  path=CACHE/name;add('commands/'+name,safe_read(path),path)
 # Optional external correspondence/probe/cache reviews must be explicitly
 # named; no silently included unsnapshotted source tree or binary target.
 for directory in ['single-proof-method-pass','method-pass-runtime0-reconciliation','method-pass-publication-verification','native-d21-map-attribution','method-pass-parent-map-evidence','method-pass-review-record']+args.supplement:
  base=(CACHE/directory).resolve();assert base.is_relative_to(CACHE) and base.is_dir()
  for path in sorted(base.rglob('*')):
   if path.is_file():add('supplements/'+directory+'/'+path.relative_to(base).as_posix(),safe_read(path),path)
 binding=None
 if args.source_checkpoint:
  final=tuples['native-method-pass-candidate/after-bootstrap'];assert len(final)==2915
  binding=checkpoint_binding(REPO,args.source_checkpoint,final,{digest:files['inputs/'+digest] for digest in set(final.values())})
  report=out.with_name(out.stem+'-checkpoint-binding.json');report.write_text(json.dumps(binding,indent=2)+'\n')
  if not binding['exact_match']:raise AssertionError(('committed checkpoint does not bind final tuple',str(report),binding['matched_count'],binding['missing_count'],binding['changed_count']))
  add('checkpoint-binding.json',(json.dumps(binding,indent=2)+'\n').encode())
 assert load(CACHE/'native-method-pass-candidate/receipt.json')['current'] is None
 manifest=dict(parent='d21b410a3f3f6051cf88959606f5a72660599703',source_checkpoint=args.source_checkpoint,
  source_state='committed checkpoint byte-bound to complete final tuple' if args.source_checkpoint else 'uncommitted candidate; exact source tuples are authoritative',
  user_reported_handles={'final_method_pass':'terminal16stages'},
  scope='Invocation-local callback-free method inspection reuse; all other source/storage/prototype proofs retained; partial #252/#264, no acceptance claim.',
  checkpoint_binding=binding,limits=outline()['limits'],attempts=attempts,foundation=foundation,bootstrap_deltas=bootstrap_deltas,tuples=tuples,
  payloads={p:sha(b) for p,b in sorted(files.items())})
 add('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())
 # No live receipts/logs may change while archive is assembled.
 for path,digest in origins.items():assert sha(safe_read(Path(path)))==digest,('evidence changed during packaging',path)
 tmp=out.with_suffix(out.suffix+'.partial');assert not tmp.exists()
 try:
  with tarfile.open(tmp,'w:gz') as archive:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;archive.addfile(info,io.BytesIO(data))
  with tarfile.open(tmp,'r:gz') as archive:
   assert set(archive.getnames())==set(files)
   for name,digest in manifest['payloads'].items():assert sha(archive.extractfile(name).read())==digest
  for path,digest in origins.items():assert sha(safe_read(Path(path)))==digest,('evidence changed before publication',path)
  tmp.rename(out)
 except BaseException:
  # Keep partial output for investigation; never label it verified.
  raise
 result=dict(path=str(out),sha256=sha(out.read_bytes()),bytes=out.stat().st_size,payloads_including_manifest=len(files),tuples=len(tuples),unique_inputs=sum(n.startswith('inputs/') for n in files))
 result_path=out.with_suffix(out.suffix+'.result.json');result_path.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--package',action='store_true');ap.add_argument('--source-checkpoint');ap.add_argument('--output',default=str(CACHE/'m4-single-proof-method-pass-2026-10-17.tar.gz'));ap.add_argument('--supplement',action='append',default=[]);args=ap.parse_args()
 if args.package:package(args)
 else:print(json.dumps(outline(),indent=2))
