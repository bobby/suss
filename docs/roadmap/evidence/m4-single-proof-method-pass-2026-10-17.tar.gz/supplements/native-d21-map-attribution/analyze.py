from pathlib import Path
import re,json,collections,hashlib
b=Path('/home/bobby/.cache/suss-m4-work/native-d21-map-macro-fuel-trace');out=Path(__file__).parent
raw=(b/'map-trace.log').read_text(); events=[(m[1],m[2],int(m[3])) for m in re.finditer(r'^macro-fuel (\S+) ([\w-]+): (\d+)$',raw,re.M)]
groups=json.loads((b/'ordered-macro-balances.json').read_text())['groups']
assert [(g['target'],s['stage'],s['remaining']) for g in groups for s in g['stages']]==events
stages=['start','provenance','caller-form','caller-environment','arguments','invoked','decoded'];sums=collections.Counter();by={}; rows=[]; intervals=[]
for g in groups:
 names=[x['stage'] for x in g['stages']];assert names==stages[:len(names)]
 t=g['target'];v=by.setdefault(t,{'count':0,'complete':0,'deltas':collections.Counter()});v['count']+=1;v['complete']+=names[-1]=='decoded';d={}
 for a,z in zip(g['stages'],g['stages'][1:]):
  assert a['remaining']>=z['remaining'];n=z['stage'];cost=a['remaining']-z['remaining'];sums[n]+=cost;v['deltas'][n]+=cost;d[n]=cost;intervals.append((a['remaining'],z['remaining']))
 rows.append(dict(ordinal=g['ordinal'],target=t,deltas=d,observed_total=sum(d.values()),last_stage=names[-1]))
# Consecutive intervals disjoint; no nested addition of lazy calls/host decode.
assert all(z>=a for (_,z),(a,_) in zip(intervals,intervals[1:]))
lazy=re.findall(r'^macro-lazy-invoke call=\d+ stage=after fuel=Some\(\d+\) delta=Some\((\d+)\) success=(\w+)$',raw,re.M)
host=re.findall(r'^macro-decode host-fuel=(\d+) lazy-calls=(\d+) success=(\w+)$',raw,re.M)
report=dict(inputs={n:hashlib.sha256((b/n).read_bytes()).hexdigest() for n in ['map-trace.log','ordered-macro-balances.json']},groups=len(groups),complete=sum(x['last_stage']=='decoded' for x in rows),disjoint_stage_sums=dict(sums),observed_stage_sum=sum(sums.values()),between_expansion_gaps=sum(a['stages'][-1]['remaining']-z['stages'][0]['remaining'] for a,z in zip(groups,groups[1:])),first_start=groups[0]['stages'][0]['remaining'],last_observation=groups[-1]['stages'][-1],by_target=by,largest=sorted(rows,key=lambda x:x['observed_total'],reverse=True)[:12],terminal=rows[-1],nested_decode_diagnostics_not_added=dict(lazy_count=len(lazy),lazy_delta=sum(int(x[0]) for x in lazy),host_rows=len(host),host_fuel=sum(int(x[0]) for x in host)),limits=['Terminal arguments->invoke trap has no invoked balance; missing delta is not zero.','Stage boundaries are inclusive of callback host work; invocation is not pure guest work.','Lazy realization intervals are nested inside decode and are not added to stage totals.','No source mutation or code execution/build.'])
(out/'attribution.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2)[:6500])
