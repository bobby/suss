# d21 map attribution (read-only)

143 starts,142 decoded completions. Exact ordered JSON/raw trace agreement; stage intervals are monotone and nonoverlapping.

| Disjoint observed phase | Fuel |
|---|---:|
| Provenance |4,443,389|
| Caller form |143|
| Caller environment |143|
| Explicit arguments |35,395,261|
| Completed invocation |81,955,510|
| Completed decode |61,581,173|

Observed phase sum183,375,619; between-expansion gaps3,784,632. Before first traced start11,589,519 of200M already spent. Remaining1,250,230 at terminal arguments boundary; subsequent invocation traps without completion balance. These reconcile exactly to200M including terminal remainder; do not describe missing invocation as zero.

Dominant target is `is`:134 starts/133 completions,79,722,572 completed invocation and60,473,052 decode. Low-cost invocation cluster67 calls at68,791; high clusters25 at1,138,346 and24 at1,143,856, with other high cases. Harness source has a one-argument `is` emitting `(is form nil)` and two-argument `is` emitting full try/let/report expansion. Trace does not itself record arity/cond branch, so clusters are not proven arity labels. Largest single intervals overall are deftest10,129,439 and when-var-exists8,460,245, mostly argument transport; testing ordinal97 costs3,304,376.

Decode includes3799 completed lazy realization calls totaling60,531,220.142 host-decode reports total1,027,159. These are NESTED diagnostics, not added to61,581,173. Host reports+lazy deltas leave22,794 boundary/bookkeeping fuel. Invocation deltas include callback host charges, not pure Wasm.

Source routes:
- `crates/suss-compile/tests/clojure_test_suite.rs:29,127`:TEST_MACROS/rewrite; OPERATION_FUEL200M at36.
- `tests/clojure-test-suite/suss/suss/harness/test_macros.cljc`: testing44,deftest50,are75,is102..138; actual source macros, no fixture changes.
- `portable_macros.rs:779..817`: caller_form_free/environment_free => nil; explicit args quote_ref. All143 observed implicit stages cost1 each, so no AnalysisGraph environment materialization in these expansions.
- `portable_macro_data.rs:662`: initial bridge recording=None; quote_ref1103->form_value; construct normal branch calls data_construct, not data_construct_with_inputs/domain.record. Array route similarly data_array.
- memo_bridge scoped store checks Watch.source_domain Weak before calling scoped_domain (916..918,935..937). Plain datum watches may exist, but are not source-bound domains merely by being quoted/hashed. Thus observed argument transport does not enroll source DomainProofs; this is not the prior retained-source domain bottleneck. Trace lacks per-domain-call counters, so do not assert universal zero DomainProof work during all setup/compiler analysis solely from absence of log lines.

0 assertions/69 unexecuted; source compilation fails before namespace tests run. Source/Cargo untouched. JSON/parser retain exact input hashes.
