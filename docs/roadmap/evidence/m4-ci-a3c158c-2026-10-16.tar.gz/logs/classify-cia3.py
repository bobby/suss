from pathlib import Path
import json,re,subprocess,hashlib,tarfile
c=Path('/home/bobby/.cache/suss-m4-work');root=Path('/home/bobby/Work/code/bobby/suss');run=json.loads((c/'cia3-run.json').read_text());assert run['status']=='completed' and run['conclusion']=='failure'
summary={'run':38908029824,'head':run['headSha'],'jobs':[],'failures':[],'limits':['Rust counts are executions per job, not unique tests across overlapping foundation/integration checks.','Each integration partition stops at its first failing target; remaining planned targets are unexecuted.','No passing-prefix or foundation result makes the complete workflow green.']}
for j in run['jobs']:
 raw=c/('cia3-job-'+str(j['databaseId'])+'-raw.log')
 if not raw.exists():
  with raw.open('wb') as f:subprocess.run(['gh','api',f"repos/bobby/suss/actions/jobs/{j['databaseId']}/logs",'--allow-escape-sequences'],stdout=f,check=True)
 text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.read_text(errors='replace'));clean=c/('cia3-job-'+str(j['databaseId'])+'-clean.log');clean.write_text(text)
 counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 failures=re.findall(r'\btest (\S+) \.\.\. FAILED',text);panics=list(re.finditer(r"thread '([^']+)'[^\n]*panicked at",text));causes={}
 for n,m in enumerate(panics):
  block=text[m.start():panics[n+1].start() if n+1<len(panics) else len(text)]
  causes[m[1]]='fuel-exhaustion' if 'all fuel consumed' in block or 'out of fuel' in block.lower() else ('metadata-identity' if m[1]=='source_metadata_keeps_identity_with_a_replaced_hash_method' else 'unclassified')
 entry={'name':j['name'],'job':j['databaseId'],'status':j['status'],'conclusion':j['conclusion'],'rust_suites_completed':len(counts),'rust_pass_executions':sum(int(v[0]) for v in counts),'rust_fail_executions':sum(int(v[1]) for v in counts),'rust_ignored_executions':sum(int(v[2]) for v in counts),'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}
 for name in failures:summary['failures'].append({'job':j['databaseId'],'test':name,'cause':causes.get(name,'unclassified')})
 if j['name'].startswith('integration ('):
  line=next(l for l in text.splitlines() if '{"index":' in l);plan=json.loads(line[line.index('{"index":'):]);targets=[{'package':p,'target':n,'status':'not-executed'} for p,n in plan['targets']]
  for line in text.splitlines():
   m=re.search(r'\bRunning tests/[^ ]+ \(([^)]+)\)',line)
   if m:
    stem=m[1].rsplit('/',1)[-1].rsplit('-',1)[0];matching=[t for t in targets if t['target'].replace('-','_')==stem];assert len(matching)==1,(stem,matching);matching[0]['status']='executed'
  entry.update(targets=targets,planned=len(targets),executed=sum(t['status']=='executed' for t in targets),unexecuted=sum(t['status']=='not-executed' for t in targets))
 summary['jobs'].append(entry)

prior=json.loads((c/'cif1-classification.json').read_text())
old={x['test']:x['cause'] for x in prior['failures']};new={x['test']:x['cause'] for x in summary['failures']}
summary['prior_failure_names_not_failed_in_this_run']=sorted(set(old)-set(new))
summary['newly_failed_in_ci']=sorted(set(new)-set(old))
summary['combined_known_fuel_failure_names']=sorted({x['test'] for x in prior['failures'] if x['cause']=='fuel-exhaustion'} | {x['test'] for x in summary['failures'] if x['cause']=='fuel-exhaustion'} | {'captured_global_declarations_supply_var_ast_fields_without_catalog_mutation'})
historical=json.loads((c/'ci4ce-classification.json').read_text())
summary['combined_known_fuel_failure_names']=sorted(set(summary['combined_known_fuel_failure_names'])|set(prior.get('combined_known_fuel_failure_names',[]))|set(historical.get('combined_known_fuel_failure_names',[])))
summary['combined_known_fuel_failure_count']=len(summary['combined_known_fuel_failure_names'])
summary['limits'].append('Known failures are a union, not an exhaustive catalog; prior names absent from failures require pass/unexecuted classification.')
summary['checkout']=json.loads((c/'cia3-checkout.json').read_text())
assert summary['checkout']['complete_trees_equal']
summary['integration_planned']=sum(j.get('planned',0) for j in summary['jobs']);summary['integration_executed']=sum(j.get('executed',0) for j in summary['jobs']);summary['integration_unexecuted']=sum(j.get('unexecuted',0) for j in summary['jobs'])
(c/'cia3-classification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'failures':summary['failures'],'prior_not_failed':summary['prior_failure_names_not_failed_in_this_run'],'newly_failed_in_ci':summary['newly_failed_in_ci'],'planned':summary['integration_planned'],'executed':summary['integration_executed'],'unexecuted':summary['integration_unexecuted'],'foundation':[{k:v for k,v in j.items() if k!='targets'} for j in summary['jobs'] if j['name']=='foundation']},indent=2))

logs='\n'.join(p.read_text() for p in c.glob('cia3-job-*-clean.log'))
prior=summ=summary['prior_failure_names_not_failed_in_this_run']
summary['prior_failures_observed_passing']=[n for n in prior if 'test '+n+' ... ok' in logs]
summary['prior_failures_not_executed']=[n for n in prior if n not in summary['prior_failures_observed_passing']]
(c/'cia3-classification.json').write_text(json.dumps(summary,indent=2)+'\n')
