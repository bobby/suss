#!/usr/bin/env python3
"""Host-only, fail-closed V5 evidence packager. Never runs builds or changes repository files."""
import argparse, collections, hashlib, io, json, os, pathlib, re, subprocess, tarfile
C=pathlib.Path('/home/bobby/.cache/suss-m4-work')
REPO=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace')
PIN='c4295f303100bbf5afac449242d30bca1126f1a1'
RUNS=['short-literal-key-probe-map','short-literal-key-probe-focused']
def digest(b): return hashlib.sha256(b).hexdigest()
def load(p): return json.loads(p.read_bytes())
def git(*args,repo=REPO): return subprocess.check_output(['git','-C',str(repo),*args])
def require(ok,msg):
    if not ok: raise SystemExit('REFUSED: '+msg)
def alive(pid):
    try: return pathlib.Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[0] not in ('Z','X')
    except FileNotFoundError: return False

def check_idle(receipts):
    pids=[]
    for receipt in receipts:
        if receipt.get('driver_pid'): pids.append(receipt['driver_pid'])
        for stage in receipt['stages']:
            if stage.get('pid'): pids.append(stage['pid'])
    require(not any(alive(p) for p in pids),'a recorded producer PID still exists (PID reuse also requires manual resolution)')
    targets={str(r['target']).encode() for r in receipts}
    roots={str(r['root']).encode() for r in receipts}
    for p in pathlib.Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid(): continue
        try:
            cmd=(p/'cmdline').read_bytes(); env=(p/'environ').read_bytes()
            exe=pathlib.Path(os.readlink(p/'exe')).name
            cwd=os.readlink(p/'cwd')
        except (FileNotFoundError,PermissionError,ProcessLookupError): continue
        producer=(exe in ('cargo','rustc') or any(t+b'/debug/' in cmd or t+b'/test/' in cmd for t in targets))
        if producer:
            require(not (any(t in cmd or b'CARGO_TARGET_DIR='+t+b'\0' in env for t in targets) or cwd.encode() in roots),f'active producer {p.name}: {cmd[:160]!r}')

def git_bindings(maps,source,base):
    # Final maps MUST bind to source454; before maps may contain exact prior bootstrap bytes.
    wants={}
    for member,values in maps.items():
        for path,sha in values.items():
            require(isinstance(sha,str) and re.fullmatch('[0-9a-f]{64}',sha),f'invalid freeze hash {member}:{path}')
            require(not pathlib.PurePosixPath(path).is_absolute() and '..' not in pathlib.PurePosixPath(path).parts,'unsafe freeze path')
            wants[(path,sha)]=None
    requests={}
    for path,sha in wants:
        sub=path.startswith('clojurescript/')
        repo=REPO/'clojurescript' if sub else REPO
        rel=path.removeprefix('clojurescript/') if sub else path
        for commit in ([PIN] if sub else [source,base]): requests[(str(repo),commit,rel)]=None
    for repo in sorted({k[0] for k in requests}):
        keys=[k for k in requests if k[0]==repo]
        proc=subprocess.run(['git','-C',repo,'cat-file','--batch'],input=('\n'.join(k[1]+':'+k[2] for k in keys)+'\n').encode(),stdout=subprocess.PIPE,check=True)
        stream=io.BytesIO(proc.stdout)
        for key in keys:
            header=stream.readline().decode().strip().split()
            if len(header)==2 and header[1]=='missing': continue
            require(len(header)==3 and header[1]=='blob',f'not a blob: {key}')
            raw=stream.read(int(header[2]));require(stream.read(1)==b'\n','bad Git batch framing')
            requests[key]={'repository':'clojure/clojurescript' if repo.endswith('/clojurescript') else 'bobby/suss','commit':key[1],'path':key[2],'blob_oid':header[0],'sha256':digest(raw),'bytes':len(raw)}
    for key in wants:
        path,sha=key; sub=path.startswith('clojurescript/');repo=str(REPO/'clojurescript' if sub else REPO);rel=path.removeprefix('clojurescript/') if sub else path
        matches=[requests[(repo,ref,rel)] for ref in ([PIN] if sub else [source,base]) if requests[(repo,ref,rel)] and requests[(repo,ref,rel)]['sha256']==sha]
        require(bool(matches),f'unbound frozen bytes: {path}@{sha}')
        wants[key]=matches[0]
    for member,values in maps.items():
        if member.endswith(('after-bootstrap-freeze.json','terminal-freeze.json')):
            for path,sha in values.items(): require(wants[(path,sha)]['commit'] in (source,PIN),f'final bytes not source454: {member}:{path}')
    return {'source_commit':source,'historical_before_commit':base,'cljs_pin':PIN,'snapshots':maps,'bindings':{p+'@'+s:v for (p,s),v in wants.items()},'limits':'Git-resolved evidence: source blobs are external dependencies, not embedded standalone source.'}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=pathlib.Path,required=True);args=ap.parse_args()
    require(args.output.is_absolute() and args.output.is_relative_to(C),'output must be an absolute cache path')
    require(not args.output.exists(),'output already exists')
    source=git('rev-parse','4541f9d^{commit}').decode().strip()
    packet=C/'short-literal-key-probe-source-final'; manifest=load(packet/'manifest.json'); base=manifest['base']
    require(digest((packet/'candidate.patch').read_bytes())==manifest['patch_sha256'],'source patch digest changed')
    for path,sha in manifest['files'].items(): require(digest(git('show',source+':'+path))==sha,'source454 disagrees with reviewed file '+path)
    receipts=[];maps={};receipt_bytes={}
    for name in RUNS:
        run=C/name; receipt_bytes[name]=(run/'receipt.json').read_bytes(); r=json.loads(receipt_bytes[name]);receipts.append(r)
        require('current' in r and r['current'] is None,name+' is still live/unestablished')
        require((run/'terminal-freeze.json').is_file(),name+' terminal freeze missing')
        require(r.get('stages'),name+' missing stage records')
        executed=[s['name'] for s in r['stages']]
        require(executed==r['planned_stages'][:len(executed)],name+' stage order differs')
        require(r.get('unexecuted_stages')==r['planned_stages'][len(executed):],name+' missing explicit unexecuted classification')
        for stage in r['stages']:
            require(isinstance(stage.get('exit'),int) and 'seconds' in stage,name+': unfinished '+stage['name'])
            require(stage.get('execution') not in (None,'UNEXECUTED'),name+': missing terminal classification '+stage['name'])
            changed=stage.get('changed')
            require(isinstance(changed,list),name+': missing changed-input list '+stage['name'])
            boot={'runtime/bootstrap/macro.json','runtime/bootstrap/macro.wasm',
                  'runtime/bootstrap/runtime.json','runtime/bootstrap/runtime.wasm'}
            if stage['name']=='bootstrap' and stage['exit']==0 and stage['execution']=='PASS':
                require(set(changed)<=boot,name+': bootstrap changed non-allowlisted inputs')
            else:
                require(changed==[],name+': inputs changed during '+stage['name'])
            require((run/(stage['name']+'.log')).is_file(),name+': missing raw log '+stage['name'])
        require('final_changed' in r and r['final_changed']==[],name+': terminal changed-input assertion absent or nonempty')
        for fn in ('before-freeze.json','after-bootstrap-freeze.json','terminal-freeze.json'):
            require((run/fn).is_file(),name+': missing '+fn);maps[name+'/'+fn]=load(run/fn)
        require(maps[name+'/after-bootstrap-freeze.json']==maps[name+'/terminal-freeze.json'],name+' postboot/terminal mismatch')
    check_idle(receipts)
    require(maps[RUNS[0]+'/terminal-freeze.json']==maps[RUNS[1]+'/terminal-freeze.json'],'map and focused final tuples differ')
    bindings=git_bindings(maps,source,base)
    oracle=C/'short-property-probe-oracle-no-cache'; old=C/'short-property-probe-oracle'; bindings_file=C/'short-property-oracle-source-bindings.json'
    for name,sha in load(bindings_file).items():
        path=pathlib.Path('/tmp/suss-short-property-observations.rs') if name=='prepared_test' else C/name
        require(digest(path.read_bytes())==sha,'oracle durable binding changed: '+name)
    require((old/'src/suss_oracle/short_property.cljs').read_bytes()==(oracle/'src/suss_oracle/short_property.cljs').read_bytes(),'oracle attempt source differs')
    require([(s['name'],s['exit']) for s in load(oracle/'receipt.json')['stages']]==[('compile',0),('observe',0)],'oracle not successful')
    require(load(old/'receipt.json')['stages'][0]['exit']==143,'original interrupted attempt missing')
    raw=load(oracle/'observe.stdout'); shared=load(oracle/'verified-shared-cases.json'); cases=load(oracle/'cases.json')
    require(raw['schema']==shared['schema']==1 and raw['upstream']==shared['upstream']==PIN,'oracle schema/pin mismatch')
    require(len(cases)==len(raw['cases'])==len(shared['cases'])==4,'oracle case count')
    for case,obs,want in zip(cases,raw['cases'],shared['cases']):
        require(case['id']==obs['id']==want['id'] and case['source']==want['source'] and obs['value']==want['expected'],'oracle case correspondence')
    payload={}; excluded=[]
    def add_tree(folder):
        for path in sorted(folder.rglob('*')):
            if path.is_symlink(): raise SystemExit('REFUSED symlink '+str(path))
            if not path.is_file(): continue
            rel=path.relative_to(folder)
            if any(part in ('out','.cpcache','__pycache__','.git') for part in rel.parts): excluded.append(str(path.relative_to(C)));continue
            payload[str(path.relative_to(C))]=path.read_bytes()
    for folder in [packet,*(C/name for name in RUNS),oracle,old]: add_tree(folder)
    # Include the exact review receipts, successful/failing provenance logs, prepared test and durable hashes.
    for name in ['short-literal-key-probe-source-review.json','short-literal-key-probe-map-independent-review.json','short-property-probe-oracle-independent-review.json','short-property-oracle-source-bindings.json','short-literal-key-probe-provenance.log']:
        path=C/name;require(path.is_file(),'required evidence missing '+name);payload[name]=path.read_bytes()
    payload['prepared-tests/suss-short-property-observations.rs']=pathlib.Path('/tmp/suss-short-property-observations.rs').read_bytes()
    payload['git-input-bindings.json']=(json.dumps(bindings,indent=2)+'\n').encode()
    summary={}
    for name,r in zip(RUNS,receipts):
        rows=[{'stage':s['name'],'exit':s['exit'],'execution':s['execution'],'counts':s.get('counts'),'selected_names':s.get('selected_names',[])} for s in r['stages']]
        summary[name]=rows
    payload['publication-summary.json']=(json.dumps({'source':source,'runs':summary,'prepared_oracle_test':'NOT INSTALLED/NOT EXECUTED by this package unless separately proven','external_controls':{'V3':'4dbf0c877bffe56135b790344f2863753be41bf9','V4':base},'excluded_generated_files':excluded,'limits':['Failed raw logs retained without success filtering.','Counts are executions by stage; no automatic distinct-test union or latest-result inference.','Map fixture allowance 200M unchanged. SourceChild/CoreEnv default10M are separate tests.','Oracle successful compile0/Node0; original interrupted143 not a semantic failure.','No passing full baseline/final CI, issue closure or readiness claim.','Git dependencies required; previous complete archives not duplicated.']},indent=2)+'\n').encode()
    payload['packager.py']=pathlib.Path(__file__).read_bytes()
    # Recheck drain and receipts after reading, before writing any publication output.
    check_idle(receipts)
    for name,raw_receipt in receipt_bytes.items(): require((C/name/'receipt.json').read_bytes()==raw_receipt,'receipt changed during packaging')
    index={name:{'sha256':digest(raw),'bytes':len(raw)} for name,raw in sorted(payload.items())}
    payload['MANIFEST.json']=(json.dumps({'schema':1,'files':index},indent=2)+'\n').encode()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('xb') as output:
        with tarfile.open(fileobj=output,mode='w:gz') as archive:
            for name,raw in sorted(payload.items()):
                info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(raw))
    result={'archive':str(args.output),'sha256':digest(args.output.read_bytes()),'members':len(payload),'payloads':len(index),'source':source,'source_inputs':len(maps[RUNS[1]+'/terminal-freeze.json'])}
    args.output.with_suffix(args.output.suffix+'.result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__': main()
