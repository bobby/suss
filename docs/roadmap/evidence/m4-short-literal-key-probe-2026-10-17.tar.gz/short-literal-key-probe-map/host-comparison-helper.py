"""Prepared preservation gates. No execution without --execute and root authorization."""
from pathlib import Path
import argparse,collections,fcntl,hashlib,importlib.util,json,os,re,shutil,subprocess,time
CACHE=Path(__file__).resolve().parent
WITNESSES={'public_record_nominal_equality_and_predicate_decode_after_gc_in_both_phases','public_records_execute_jank_and_authored_contracts_with_two_nominal_classes','public_reduce_dispatch_and_source_order_match_pinned_cljs_after_gc'}
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def names(path):return re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',path.read_text())
def parse(text):
    starts=list(re.finditer(r'^test (\S+) \.\.\.',text,re.M));rows=[]
    for i,m in enumerate(starts):
        segment=text[m.start():starts[i+1].start() if i+1<len(starts) else len(text)]
        status=re.findall(r'(?:^|\n)\s*(?:test \S+ \.\.\. )?(ok|FAILED|ignored)\s*(?=\n|$)',segment)
        assert status,('Missing terminal status',m[1]);rows.append({'name':m[1],'status':status[-1]})
    summaries=[dict(zip(('pass','fail','ignore'),map(int,x))) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)]
    return rows,summaries

def build_stages(root,selection):
    tail=['--','--test-threads=1','--nocapture'];cargo=['cargo','test','--locked'];lib=['-p','suss-compile','--lib'];cli=['-p','suss-cli']
    prefixes=['portable_session::scalar_inputs::tests::','portable_session::write_domain::tests::','portable_session::construction_records::tests::','source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo','portable_session::storage_snapshot::tests::','portable_macro_graph::raw_keys::tests::','portable_macro_graph::initializer_plan::tests::']
    source_names=[]
    for n in ['portable_session/scalar_inputs.rs','portable_session/write_domain.rs','portable_session/construction_records.rs','portable_session/storage_snapshot.rs','portable_macro_graph/raw_keys.rs','portable_macro_graph/initializer_plan.rs']:
        source_names+=names(root/'crates/suss-compile/src'/n)
    source_names+=['source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo'];assert len(source_names)==59,('Source cohort changed',len(source_names))
    core=names(root/'crates/suss-cli/tests/core_import.rs')
    core_text=(root/'crates/suss-cli/tests/core_import.rs').read_text()
    if 'mod portable_decode;' in core_text:core+=names(root/'crates/suss-compile/tests/support/portable_decode.rs')
    assert len(core)==17,('CORE selection changed',core)
    cold=names(root/'crates/suss-compile/src/portable_macros/memo_leaf_tests.rs');assert len(cold)==5,('Merged native cold identifier selection changed',cold)
    bridge=names(root/'crates/suss-compile/tests/form_bridge_identifier_hash.rs');assert len(bridge)==1
    stages=[
      {'name':'source-domain-raw-key','command':cargo+lib+tail+prefixes,'names':source_names,'trace':True},
      {'name':'core-import','command':cargo+cli+['--test','core_import']+tail,'names':core},
      {'name':'map','command':cargo+['-p','suss-compile','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--exact','--test-threads=1','--nocapture'],'names':['pinned_map_declaration_executes_without_transport_loss'],'capture':True},
      {'name':'when-let-validation','command':cargo+lib+['portable_macros::when_let_validation_tests::compiled_when_let_validation_matches_pinned_messages_and_phase_after_gc','--','--exact','--test-threads=1','--nocapture'],'names':['compiled_when_let_validation_matches_pinned_messages_and_phase_after_gc']},
      {'name':'cold-identifier-native','command':cargo+lib+['portable_macros::memo_leaf_tests::']+tail,'names':cold},
      {'name':'cold-identifier-bridge','command':cargo+['-p','suss-compile','--test','form_bridge_identifier_hash']+tail,'names':bridge}]
    remaining=[]
    for group,targets,selected in selection['groups']:
        chosen=[n for n in selected if n not in WITNESSES];remaining+=chosen
        # Keep original targets and exact names; no-fail-fast completes later binaries.
        cmd=cargo+cli+['--no-fail-fast']
        for target in targets:cmd+=['--test',target]
        cmd+=['--','--exact','--test-threads=1','--nocapture']+chosen
        stages.append({'name':group+'-remaining','command':cmd,'names':chosen})
    original={n for _,_,selected in selection['groups'] for n in selected};assert len(original)==24 and len(remaining)==len(set(remaining))==21 and set(remaining)==original-WITNESSES
    return stages

def map_compare(root,run):
    # Host-only comparison of the actual capture; no guest rerun.
    import sys
    sys.dont_write_bytecode=True;sys.path.insert(0,str(root/'scripts'))
    import clojure_test_suite as suite
    obs=run/'map-capture/map-transport-observations.json';refpath=root/'tests/oracle/clojure-test-suite-observations.json'
    reference=json.loads(refpath.read_text());actual=json.loads(obs.read_text());test='clojure.core-test.map/test-map';ns='clojure.core-test.map'
    assert reference['suite']=='95d4a9112cfc5fe6629be3d14bb99080ea00af2f' and reference['upstream']=='c4295f303100bbf5afac449242d30bca1126f1a1'
    reference.update(namespaces=[ns],tests=[test],assertions=[a for a in reference['assertions'] if a['test']==test],skips=[s for s in reference['skips'] if s['namespace']==ns])
    expected=[[test,i] for i in range(1,70)];refids=[[a['test'],a['ordinal']] for a in reference['assertions']];ids=[[a['test'],a['ordinal']] for a in actual['assertions']]
    counts,failures=suite.compare(reference,actual)
    result={'counts':counts,'failures':failures,'expected_ids':expected,'actual_ids':ids,'ordered_ids_match':ids==refids==expected,'raw_namespaces':actual['namespaces'],'raw_test_failures':actual['test-failures'],'raw_skips':actual['skips'],'capture_sha256':sha(obs.read_bytes()),'reference_sha256':sha(refpath.read_bytes()),'limits':'Guest judgments are not host-decided passes; current actual body only.'}
    dump(run/'map-independent-comparison.json',result)
    assert ids==refids==expected and actual['namespaces']==[{'namespace':ns,'status':'loaded'}] and not actual['test-failures'] and not actual['skips'] and not reference['skips']
    assert counts=={'pass':62,'guest-judged':7,'fail':0,'not-executed':0,'skipped':0,'namespaces-failed':0} and all(not failures[k] for k in ['tests','namespaces','assertions','skip-mismatches'])

def sourcechild_compare(run,control):
    pat=re.compile(r'source-child-fuel source=(Runtime|Macro)(?: variant=(.*?))? stage=(\S+)(?: result=(.*?))? remaining=Some\((\d+)\)')
    candidate=pat.findall((run/'source-domain-raw-key.log').read_text());old=pat.findall(control.read_text())
    report={'candidate_markers':len(candidate),'control_markers':len(old),'ordered_labels_results_match':len(candidate)==len(old) and all(a[:4]==b[:4] for a,b in zip(candidate,old)),'candidate_rows':candidate,'control_rows':old,'phase_results':{},'limits':'Actual default source-child requests only; no CoreEnv/record saving inferred.'}
    for phase in ['Runtime','Macro']:
        a=[x for x in candidate if x[0]==phase];b=[x for x in old if x[0]==phase]
        if a and b:report['phase_results'][phase]={'candidate_start':int(a[0][4]),'candidate_final_stage':a[-1][2],'candidate_final_result':a[-1][3],'candidate_remaining':int(a[-1][4]),'control_remaining':int(b[-1][4]),'net_removed_at_final_marker':int(a[-1][4])-int(b[-1][4])}
    dump(run/'sourcechild-comparison.json',report)
    return report # Failed source tests retain partial markers, never fabricate completion.

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--plan',type=Path,default=CACHE/'boxed-integer-bits-preservation-plan.json');ap.add_argument('--execute',action='store_true');args=ap.parse_args();plan=json.loads(args.plan.read_text())
    if not args.execute:print('PREPARED ONLY; no Cargo/target lease/snapshots. Await focusedV3terminal and explicit root authorization.');return
    assert plan.get('expected_base'),'Unbound expected base'
    root=Path(plan['root']);focus=Path(plan['focused_run']);target=Path(plan['target']);run=Path(plan['run']);receipt=json.loads((focus/'receipt.json').read_text())
    assert receipt['current'] is None and receipt.get('final_changed')==[] and not receipt.get('stopped_anomaly'),'Focused run incomplete/anomalous'
    assert receipt['base']==plan['expected_base']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
    assert any(s['name']=='bootstrap' and s['exit']==0 for s in receipt['stages']) and receipt['stages'][-1]['name']=='regression-witnesses'
    assert all(s['exit'] in (0,101) for s in receipt['stages'])
    focused_plan=json.loads((focus/'bound-plan.json').read_text());packet=Path(focused_plan['packet_manifest']);assert sha(packet.read_bytes())==focused_plan['packet_manifest_sha256']
    expected=json.loads((focus/'terminal-freeze.json').read_text());assert expected==json.loads((focus/'after-bootstrap-freeze.json').read_text());assert not subprocess.check_output(['git','ls-files','-u'],cwd=root)
    def freeze():return {n:sha((root/n).read_bytes()) for n in expected}
    assert freeze()==expected
    cas=focus/'frozen/sha256'
    for h in set(expected.values()):assert sha((cas/h).read_bytes())==h
    selection_path=Path(plan['original24_selection']);selection_bytes=selection_path.read_bytes();assert sha(selection_bytes)==plan['original24_selection_sha256'];selection=json.loads(selection_bytes);stages=build_stages(root,selection)
    leases=[]
    for name in ['.typed-scalar-witness.lease','.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease']:
        f=open(target/name,'a+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
        try:env=(proc/'environ').read_bytes();exe=str((proc/'exe').resolve())
        except OSError:continue
        assert b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' not in env and not exe.startswith(str(target)+'/'),f'Target active PID{proc.name}'
    run.mkdir(exist_ok=False);dump(run/'before-freeze.json',expected);shutil.copyfile(__file__,run/'driver.py');shutil.copyfile(args.plan,run/'bound-plan.json');(run/'original24-selection.json').write_bytes(selection_bytes)
    dump(run/'source-CAS-reference.json',{'source_blob_store':str(cas),'focus_terminal_freeze':str(focus/'terminal-freeze.json'),'freeze_sha256':sha((focus/'terminal-freeze.json').read_bytes()),'focused_receipt_sha256':sha((focus/'receipt.json').read_bytes()),'scope':'Reuse verified immutable focused CAS bytes. This run does not pretend to duplicate those blobs; publication packager must resolve full closure.'})
    env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target),PYTHONDONTWRITEBYTECODE='1')
    for k in list(env):
        if k.startswith('SUSS_') and (k.endswith('TRACE') or 'CAPTURE' in k):env.pop(k)
    state={'driver_pid':os.getpid(),'root':str(root),'base':plan['expected_base'],'input_count':len(expected),'current':None,'stages':[],'environment':{'jobs':1,'rayon':1,'test_threads':1,'RUSTFLAGS':'inherited, not assigned'},'limits':'No bootstrap rerun. Exact focusedV3 closure including merged267inputs/CAS reused. Semantic failures continue; source mutation/compile/selection/process anomalies stop. Original24remaining21exclude3alreadyfocused; repeated decoder/support executions not extra unique criteria.'};save=lambda:dump(run/'receipt.json',state)
    try:
        for spec in stages:
            name=spec['name'];assert freeze()==expected,('Source mutation before',name)
            row={'name':name,'command':spec['command'],'expected_names':spec['names'],'expected_count':len(spec['names'])};state['stages'].append(row);state['current']=name;save();started=time.monotonic();stage_env=env.copy()
            if spec.get('trace'):stage_env['SUSS_SOURCE_CHILD_FUEL_TRACE']='1'
            if spec.get('capture'):stage_env['SUSS_CLOJURE_TEST_SUITE_CAPTURE']=str(run/'map-capture')
            with (run/(name+'.log')).open('w') as out:
                proc=subprocess.Popen(spec['command'],cwd=root,env=stage_env,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
            row.update(exit=code,seconds=time.monotonic()-started,changed=[n for n,h in expected.items() if not (root/n).is_file() or sha((root/n).read_bytes())!=h]);save();assert not row['changed'],('Source mutation',name)
            records,summaries=parse((run/(name+'.log')).read_text(errors='replace'));row.update(records=records,summaries=summaries);save()
            assert collections.Counter(r['name'].split('::')[-1] for r in records)==collections.Counter(spec['names']),('Selection anomaly',name)
            total=collections.Counter()
            for s in summaries:total.update(s)
            assert total=={'pass':sum(r['status']=='ok' for r in records),'fail':sum(r['status']=='FAILED' for r in records),'ignore':0},('Record/summary anomaly',name,total)
            assert code in (0,101) and (code==0)==(total['fail']==0),('Compile/process anomaly',name,code)
            if name=='source-domain-raw-key':row['sourcechild']=sourcechild_compare(run,Path(plan['sourcechild_control_log']))
            if name=='map':
                obs=run/'map-capture/map-transport-observations.json'
                if obs.exists():row['capture_sha256']=sha(obs.read_bytes())
                if code==0:map_compare(root,run)
                else:row['independent_assertion_comparison']='Unexecuted after Rust test failure; raw/partial capture retained, not pass'
            save() # No semantic-failure break: all independent gates continue.
    except BaseException as error:state['stopped_anomaly']=repr(error);raise
    finally:
        state['current']=None;state['final_changed']=[n for n,h in expected.items() if not (root/n).is_file() or sha((root/n).read_bytes())!=h];save()
        if not state['final_changed']:dump(run/'terminal-freeze.json',freeze())
if __name__=='__main__':main()
