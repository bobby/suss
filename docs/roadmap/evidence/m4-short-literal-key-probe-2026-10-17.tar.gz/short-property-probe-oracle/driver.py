from pathlib import Path
import hashlib,json,os,subprocess,time
C=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace')
run=C/'short-property-probe-oracle';run.mkdir(exist_ok=False)
pin='c4295f303100bbf5afac449242d30bca1126f1a1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root/'clojurescript',text=True).strip()==pin
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root/'clojurescript').strip()
cases=[
 {'id':'nominal-nil-false-value','source':'(let [read (fn [o] (.-ns o))] [(read (ShortLiteralFields. nil 0)) (read (ShortLiteralFields. false 0)) (read (ShortLiteralFields. 23 0))])'},
 {'id':'replaced-getter-ordered-owner-effects','source':'(let [events (atom []) o (js-obj) read (fn [v] (.-ns v))] (.__defineGetter__ o "ns" (fn [] (swap! events conj 2) 17)) (let [a (read (do (swap! events conj 1) o))] (.__defineGetter__ o "ns" (fn [] (swap! events conj 3) 19)) (let [b (read (do (swap! events conj 1) o))] [a b @events])))'},
 {'id':'fallback-nil-false-getters-run-once','source':'(let [events (atom []) o (js-obj) read (fn [v] (.-ns v))] (.__defineGetter__ o "ns" (fn [] (swap! events conj 1) nil)) (let [a (read o)] (.__defineGetter__ o "ns" (fn [] (swap! events conj 2) false)) [a (read o) @events]))'},
 {'id':'fallback-thrown-nil-false-preserve-effects','source':'(let [events (atom []) o (js-obj) read (fn [v] (.-ns v))] (.__defineGetter__ o "ns" (fn [] (swap! events conj 2) (throw nil))) (let [a (try (read (do (swap! events conj 1) o)) [false 0] (catch :default value [true value]))] (.__defineGetter__ o "ns" (fn [] (swap! events conj 4) (throw false))) (let [b (try (read (do (swap! events conj 3) o)) [false 0] (catch :default value [true value]))] [a b @events])))'}]
(run/'src/suss_oracle').mkdir(parents=True)
(run/'deps.edn').write_text('{:paths ["src"] :mvn/local-repo "/tmp/suss-oracle-m2" :deps {org.clojure/clojure {:mvn/version "1.12.1"} org.clojure/clojurescript {:local/root '+json.dumps(str(root/'clojurescript'))+'}}}\n')
source='''(ns suss-oracle.short-property)
(deftype ShortLiteralFields [ns name])
(defn bits [value] (let [view (js/DataView. (js/ArrayBuffer. 8))] (.setFloat64 view 0 value false) (str (.padStart (.toString (.getUint32 view 0 false) 16) 8 "0") (.padStart (.toString (.getUint32 view 4 false) 16) 8 "0"))))
(defn encode [value] (cond (nil? value) #js {:tag "nil"} (boolean? value) #js {:tag "bool" :value value} (number? value) #js {:tag "f64" :bits (bits value)} (vector? value) #js {:tag "vector" :items (into-array (map encode value))} :else (throw (ex-info "unsupported value" {}))))
(defn -main [] (println (.stringify js/JSON #js {:schema 1 :upstream "'''+pin+'''" :cases (into-array [
'''+ '\n'.join('#js {:id '+json.dumps(c['id'])+' :value (encode '+c['source']+')}' for c in cases)+'''
])})))
(set! *main-cli-fn* -main)
'''
(run/'src/suss_oracle/short_property.cljs').write_text(source);(run/'cases.json').write_text(json.dumps(cases,indent=2)+'\n');(run/'driver.py').write_bytes(Path(__file__).read_bytes())
state={'pin':pin,'clojure':'1.12.1','driver_pid':os.getpid(),'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'current':None,'stages':[],'limits':'Development-only fresh pinned CLJS observations. No Suss result or opaque success inferred.'}
save=lambda:(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
env=os.environ.copy();env.update(JAVA_HOME='/home/bobby/.cache/suss-m4-oracle-tools/jdk-21.0.8+9-jre',CLJ_CONFIG='/tmp/suss-oracle-clojure-config',CLJ_CACHE='/tmp/suss-oracle-clojure-cache')
commands=[('compile',['/home/bobby/.cache/suss-m4-oracle-tools/bin/clojure','-J-Xmx1g','-J-XX:ActiveProcessorCount=2','-Srepro','-M','-m','cljs.main','-co','{:target :nodejs :output-to "out/main.js" :output-dir "out/cljs" :optimizations :none :source-map false}','-c','suss-oracle.short-property']),('observe',['node','out/main.js'])]
try:
 for name,cmd in commands:
  row={'name':name,'command':cmd};state['stages'].append(row);state['current']=name;save();start=time.monotonic()
  with (run/(name+'.stdout')).open('w') as out,(run/(name+'.stderr')).open('w') as err:
   proc=subprocess.Popen(cmd,cwd=run,env=env,stdout=out,stderr=err);row['pid']=proc.pid;save();row['exit']=proc.wait()
  row['seconds']=time.monotonic()-start;save()
  if row['exit']:break
finally:state['current']=None;save()
print(json.dumps(state))
