from pathlib import Path
import json,hashlib,subprocess,tarfile,io,re
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss-m4-typed-scalar-witness');O=C/'typed-scalar-production-evidence-6a';HEAD='6a1d15e88103484d9c6fc73c50b08f88024ebf49'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
runs=['native-typed-scalar-witness','native-typed-scalar-witness-v2','native-typed-scalar-witness-v3','native-typed-scalar-witness-acceptance'];payload={};blobs={};freezes={}
def put(n,b):
 assert n not in payload,n;payload[n]=b
for run in runs:
 root=C/run;j=json.loads((root/'receipt.json').read_text());assert j['current'] is None and j['final_changed']==[]
 for f in root.rglob('*'):
  if not f.is_file():continue
  rel=f.relative_to(root)
  if rel.parts[0] in ['before','after-bootstrap']:continue
  put('runs/'+run+'/'+str(rel),f.read_bytes())
 for f in root.glob('*freeze.json'):
  data=json.loads(f.read_text());assert len(data)==2915;freezes[run+'/'+f.name]=data
  for name,h in data.items():
   if h in blobs:continue
   for stage in ['before','after-bootstrap']:
    p=root/stage/name
    if p.is_file():
     b=p.read_bytes()
     if hashlib.sha256(b).hexdigest()==h:blobs[h]=b;break
   else:raise AssertionError((run,f.name,name,h))
final=json.loads((C/runs[2]/'after-bootstrap-freeze.json').read_text());assert final==json.loads((C/runs[3]/'before-freeze.json').read_text())
# Independently bind every final input to the source commit; submodule bytes
# are checked against pinned c429, not borrowed from mutable main worktrees.
pin='c4295f303100bbf5afac449242d30bca1126f1a1';normal=[n for n in final if not n.startswith('clojurescript/')]
proc=subprocess.run(['git','cat-file','--batch'],cwd=R,input=''.join(HEAD+':'+n+'\n' for n in normal).encode(),stdout=subprocess.PIPE,check=True);stream=io.BytesIO(proc.stdout);checked={}
for n in normal:
 header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob',(n,header)
 b=stream.read(int(header[2]));assert stream.read(1)==b'\n';assert hashlib.sha256(b).hexdigest()==final[n],n;checked[n]=final[n]
for n in final:
 if not n.startswith('clojurescript/'):continue
 b=subprocess.check_output(['git','show',pin+':'+n.removeprefix('clojurescript/')],cwd=R/'clojurescript');assert hashlib.sha256(b).hexdigest()==final[n],n;checked[n]=final[n]
put('final/source-binding.json',(json.dumps({'head':HEAD,'checked':len(checked),'pinned_cljs':pin,'inputs':checked,'mismatches':[]},indent=2)+'\n').encode())
# Parent fullbaseline is a DIFFERENT exact source tuple, not current6a.
parent=C/'class-audit-full-baseline-19326ae'
pbefore=json.loads((parent/'before-freeze.json').read_text());pafter=json.loads((parent/'after-freeze.json').read_text());assert pbefore==pafter and len(pafter)==2915
for f in parent.iterdir():
 if f.is_file():put('parent19326-full-baseline/'+f.name,f.read_bytes())
pnorm=[n for n in pafter if not n.startswith('clojurescript/')];ph='19326ae38522e9c339f78ff22a5dd96dc54fd228';pchecked={}
pproc=subprocess.run(['git','cat-file','--batch'],cwd=R,input=''.join(ph+':'+n+'\n' for n in pnorm).encode(),stdout=subprocess.PIPE,check=True);pstream=io.BytesIO(pproc.stdout)
for n in pnorm:
 header=pstream.readline().decode().split();assert len(header)==3 and header[1]=='blob',(n,header)
 b=pstream.read(int(header[2]));assert pstream.read(1)==b'\n';assert hashlib.sha256(b).hexdigest()==pafter[n],n;pchecked[n]=pafter[n]
for n in pafter:
 if not n.startswith('clojurescript/'):continue
 b=subprocess.check_output(['git','show',pin+':'+n.removeprefix('clojurescript/')],cwd=R/'clojurescript');assert hashlib.sha256(b).hexdigest()==pafter[n],n;pchecked[n]=pafter[n]
put('parent19326-full-baseline/source-binding.json',(json.dumps({'head':ph,'checked':len(pchecked),'inputs':pchecked,'mismatches':[]},indent=2)+'\n').encode())
for n,h in pafter.items():
 if h in blobs:continue
 b=(parent/'frozen'/'sha256'/h).read_bytes();assert hashlib.sha256(b).hexdigest()==h;blobs[h]=b
# Parent default-sourcechild raw and matching-marker comparison are retained as
# prefix context only; no source6a whole-cost claim is inferred.
old=C/'native-class-audit-fresh-inspection'
for n in ['source-child.log','receipt.json','root-sourcechild-comparison.json']:
 put('parent19326-default/'+n,(old/n).read_bytes())
import collections
pat=re.compile(r'source-child-fuel source=(Runtime|Macro) variant=(.*?) stage=(\S+)(?: result=(.*?))? remaining=Some\((\d+)\)')
def markers(path):
 counts=collections.Counter();out={}
 for line in path.read_text().splitlines():
  m=pat.search(line)
  if not m:continue
  phase,var,stage,result,fuel=m.groups();key=(phase,var,stage,result);ordinal=counts[key];counts[key]+=1;out[key+(ordinal,)]=int(fuel)
 return out
prior=markers(old/'source-child.log');current=markers(C/runs[2]/'focused-rust.log');key=('Runtime','None','final-parent:before',None,0);assert prior[key]==76024 and current[key]==1355673
comparison={'parent_head':'19326ae38522e9c339f78ff22a5dd96dc54fd228','current_head':HEAD,'matched_stage':'Runtime/None/final-parent:before','parent_remaining':prior[key],'current_remaining':current[key],'prefix_more_remaining':current[key]-prior[key],'current_parent_map_after':718,'limits':'prefix only; currentwholegap unknown, MacroSOURCEhalf unexecuted; root-owned highercap diagnostic separate'}
put('comparisons/parent19326-prefix.json',(json.dumps(comparison,indent=2)+'\n').encode())
for h,b in blobs.items():put('frozen/sha256/'+h,b)
for n in ['run-typed-scalar-witness.py','run-typed-scalar-witness-v2.py','run-typed-scalar-witness-v3.py','run-typed-scalar-witness-acceptance.py','compare-typed-scalar-map.py','explain-typed-scalar-map-guest-judged.py','typed-scalar-source-review-approval.txt']:
 put('commands-and-comparators/'+n,(C/n).read_bytes())
for directory in ['typed-scalar-domain-candidate-19326','typed-scalar-domain-design-19326']:
 for f in (C/directory).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts and f.name!='layout-probe':put('packets/'+directory+'/'+str(f.relative_to(C/directory)),f.read_bytes())
# Matching comparator implementation/pinned reference are already part of all
# frozen input closures. Actual scripts, captures and JSON results included.
put('assembly/package.py',Path(__file__).read_bytes())
summary={'head':HEAD,'source_input_count':2915,'attempts':{'v1':{'scalar_pass':6,'fixture_fail':1,'domain_sourcechild':'unexecuted'},'v2':{'scalar_pass':7,'domain_pass':6,'fixture_fail':1,'sourcechild':'unexecuted'},'v3':{'scalar_pass':7,'domain_pass':7,'records_pass':8,'sourcechild_typed_fuel_fail':1},'followup':{'cli_core_pass':17,'map_rust_pass':1,'host_pass':62,'guest_judged':7,'ordered_ids':69}},'current_unique_rust_pass':40,'current_unique_sourcechild_fuel_fail':1,'repeated_passing_executions_all_attempts':59,'current_whole_cost_gap':'unknown; complete diagnostic separate','qualified_prefix_more_remaining':1279649,'layout_actual':{'Node':16,'ComplexNode':160,'ScalarInputs':112,'Fact':312},'limitations':['No full baseline6a run','Parent19326baseline terminal83pass2fuel;239integrationtargets unexecuted; separate from6a. Whenlet baseline separate.','No final-head CI green claim','No PR268 integration or default sourcechild acceptance','Do not count7guestjudged ashostpass']}
put('summary.json',(json.dumps(summary,indent=2)+'\n').encode())
checks=''.join(hashlib.sha256(payload[n]).hexdigest()+'  '+n+'\n' for n in sorted(payload));put('SHA256SUMS',checks.encode())
archive=R/'docs/roadmap/evidence/m4-typed-scalar-witness-2026-10-17.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for n in sorted(payload):
  data=payload[n];info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(payload)==len({m.name for m in members})
 for m in members:assert m.isfile() and tar.extractfile(m).read()==payload[m.name]
result={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(payload),'manifested_payloads':len(payload)-1,'bytes':archive.stat().st_size,'head':HEAD,'inputs_bound':len(checked),'frozen_distinct_blobs':len(blobs)};(O/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
