from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,fcntl
cache=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-typed-scalar-witness')
run=cache/'native-typed-scalar-witness'
target=cache/'m4-cost-diagnostic-target'
lease=open(target/'.typed-scalar-witness.lease','w')
fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
lease.write(str(os.getpid()));lease.flush()
run.mkdir(exist_ok=False)
manifest=json.loads((cache/'typed-scalar-domain-candidate-19326/manifest.json').read_text())
for p,v in manifest['files'].items():
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==v['after_sha256'],p
paths=set(json.loads((cache/'native-fresh-class-complete-cost/before-freeze.json').read_text()))
paths.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs'))
def freeze():
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snapshot(label,data):
 (run/(label+'-freeze.json')).write_text(json.dumps(data,indent=2))
 for p in data:
  dest=run/label/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,dest)
expected=freeze();snapshot('before',expected)
shutil.copytree(cache/'typed-scalar-domain-candidate-19326',run/'source-review-packet')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target))
for k in list(env):
 if k.startswith('SUSS_') and k.endswith('TRACE'):env.pop(k)
base=['cargo','test','-p','suss-compile','--locked','--lib'];tail=['--','--test-threads=1','--nocapture']
commands=[('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('scalars',base+['portable_session::scalar_inputs::tests::']+tail),('domains',base+['portable_session::write_domain::tests::']+tail),('source-child',base+['source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo']+tail)]
state={'driver_pid':os.getpid(),'root':str(root),'base':manifest['base'],'input_count':len(expected),'target':str(target),'environment':{'jobs':1,'rayon':1,'test_threads':1,'RUSTFLAGS':'inherited, not assigned'},'current':None,'stages':[],'limits':'Unchanged default quotas. Semantic gates fail-fast; original source-child terminal outcome retained separately. No whole saving inferred from prefixes.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for name,cmd in commands:
 assert freeze()==expected,'source changed before '+name
 if name=='source-child':env.update(SUSS_SOURCE_CHILD_FUEL_TRACE='1',SUSS_SOURCE_MATERIALIZE_FUEL_TRACE='1')
 state['current']=name;row={'name':name,'command':cmd};state['stages'].append(row);save();start=time.monotonic()
 with (run/(name+'.log')).open('w') as out:
  proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;save();code=proc.wait()
 after=freeze();changed=[p for p in expected if expected[p]!=after[p]]
 row.update(exit=code,seconds=time.monotonic()-start,changed=changed)
 if name=='bootstrap' and code==0 and set(changed)<={f'runtime/bootstrap/{phase}.{ext}' for phase in ['macro','runtime'] for ext in ['wasm','json']}:
  expected=after;snapshot('after-bootstrap',expected)
 elif changed:
  row['unexpected_changes']=True;save();break
 save()
 if code:break
final=freeze();state['current']=None;state['final_changed']=[p for p,h in expected.items() if final[p]!=h];save()
