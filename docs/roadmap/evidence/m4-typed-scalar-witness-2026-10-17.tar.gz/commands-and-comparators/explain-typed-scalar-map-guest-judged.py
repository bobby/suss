from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
root=Path('/home/bobby/Work/code/bobby/suss-m4-typed-scalar-witness');run=Path('/home/bobby/.cache/suss-m4-work/native-typed-scalar-witness-acceptance');sys.path.insert(0,str(root/'scripts'));import clojure_test_suite as suite
reference=json.loads((root/'tests/oracle/clojure-test-suite-observations.json').read_text());observed=json.loads((run/'map-capture/map-transport-observations.json').read_text());actual={f"{x['test']}#{x['ordinal']}":x for x in observed['assertions']};rows=[]
def opaque_paths(x,path='$'):
 out=[]
 if isinstance(x,dict):
  if x.get('tag')=='opaque':out.append({'path':path,'node':x})
  for k,v in x.items():out+=opaque_paths(v,path+'.'+k)
 elif isinstance(x,list):
  for i,v in enumerate(x):out+=opaque_paths(v,path+f'[{i}]')
 return out
for e in reference['assertions']:
 if e['test']!='clojure.core-test.map/test-map':continue
 a=actual[e['id']];reason,judged=suite.decide(e,a);assert reason is None,(e['id'],reason)
 if not judged:continue
 if e['id']in suite.VERDICT_ONLY:r={'class':'reviewed-verdict-only','reason':suite.VERDICT_ONLY[e['id']]}
 elif not e['deterministic']:r={'class':'nondeterministic-reference','reason':'kind/head/verdict checked; deterministicoperandmatchnotrequired'}
 else:r={'class':'opaque-reference-operands','reason':'Reference could not represent these operand subvalues; comparator retains guest verdict for those while matching nonopaque parts','opaque_paths':opaque_paths(e.get('operands',e.get('value')))}
 rows.append({'id':e['id'],'classification':r,'reference':e,'observed':a})
assert len(rows)==7
(run/'map-seven-guest-judged-reasons.json').write_text(json.dumps({'count':len(rows),'cases':rows,'limits':['No guest-judged case promoted to host-decided pass','Actual existing suite.decide used; complete reference and observed rows retained']},indent=2)+'\n');print(json.dumps([{'id':x['id'],'class':x['classification']['class']}for x in rows]))
