from pathlib import Path
import subprocess,os,time,json,hashlib,fcntl,shutil,sys
cache=Path('/home/bobby/.cache/suss-m4-work');root=Path('/home/bobby/Work/code/bobby/suss-m4-class-audit-ordinals');target=cache/'memo-proof-cost-target';run=cache/'class-audit-full-baseline-19326ae';head='19326ae38522e9c339f78ff22a5dd96dc54fd228'
# Execution is deferred until main relays Carver's final committed scope confirmation.
assert '--published-reviewed-head' in sys.argv
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''
remote=subprocess.check_output(['git','ls-remote','--heads','origin','refs/heads/portable/m4-native-fuel-hotspots'],cwd=root,text=True).split();assert remote==[head,'refs/heads/portable/m4-native-fuel-hotspots'],remote
leases=[]
for name in ['.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock']:
 f=open(target/name,'a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:envb=(proc/'environ').read_bytes();cmd=(proc/'cmdline').read_bytes().split(b'\0')[0]
 except OSError:continue
 if b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' in envb or str(target).encode() in cmd:raise RuntimeError('Target active '+proc.name)
expected=json.loads((cache/'native-class-audit-fresh-inspection/after-freeze.json').read_text());freeze=lambda:{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in expected};assert freeze()==expected
run.mkdir(exist_ok=False);(run/'frozen/sha256').mkdir(parents=True)
for h in sorted(set(expected.values())):
 src=cache/'native-class-audit-fresh-inspection/frozen/sha256'/h;assert hashlib.sha256(src.read_bytes()).hexdigest()==h
 os.link(src,run/'frozen/sha256'/h)
(run/'before-freeze.json').write_text(json.dumps(expected,indent=2)+'\n');shutil.copyfile(Path(__file__),run/'run-baseline.py')
command=['cargo','test','--workspace','--locked','--','--test-threads=2'];env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
for k in list(env):
 if k.startswith('SUSS_') and ('TRACE' in k or 'DIAGNOSTIC' in k):env.pop(k)
receipt={'head':head,'git_tree':subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=root,text=True).strip(),'pid':os.getpid(),'pgid':os.getpgid(0),'sid':os.getsid(0),'target':str(target),'command':command,'environment':{'CARGO_BUILD_JOBS':'1','RAYON_NUM_THREADS':'1','test_threads':2,'RUSTFLAGS':'inherited, not assigned'},'input_count':len(expected),'current':'workspace','limits':'Exact published reviewed head, default budgets. Cargo standard fail-fast may leave later harnesses/doctests unexecuted. No fixture/rate/quota changes or old baseline restart.'}
def save():(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save();print(json.dumps(receipt),flush=True);start=time.monotonic()
try:
 with (run/'workspace.log').open('w') as log:
  child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);receipt['cargo_pid']=child.pid;save();code=child.wait()
 receipt.update(exit=code,seconds=time.monotonic()-start)
finally:
 actual=freeze();(run/'after-freeze.json').write_text(json.dumps(actual,indent=2)+'\n');receipt.update(current=None,changed=[p for p in expected if actual[p]!=expected[p]],git_status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),actual_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip());save();print(json.dumps(receipt),flush=True)
