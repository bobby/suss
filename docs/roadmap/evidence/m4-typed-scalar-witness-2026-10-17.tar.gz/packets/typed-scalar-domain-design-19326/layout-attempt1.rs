#![allow(dead_code)]
// Exact SessionValue fields from bb44105; private fields prevent direct introspection.
#[derive(Debug)]
struct SessionValue {
    identity: u64,
    value: wasmtime::OwnedRooted<wasmtime::AnyRef>,
    handles: std::sync::Arc<std::sync::atomic::AtomicUsize>,
}
use wasmtime::{Func, StructType, ArrayType};
use std::mem::{size_of, align_of};
#[derive(Debug)]
enum Atom {
    I32(i32),
    I64(i64),
    F32(u32),
    F64(u64),
    V128(u128),
    I31(u32),
    NullAny,
    NullFunc,
    NullExtern,
    NullExn,
    NullCont,
    Function(Func),
    Node(usize),
    Opaque(SessionValue),
}

#[derive(Debug)]
enum Contents {
    Struct(StructType, Vec<Atom>),
    Array(ArrayType, Vec<Atom>),
}

#[derive(Debug)]
struct Node {
    value: SessionValue,
    // Same-hash references still require actual GC-reference equality.
    collision: Option<usize>,
    contents: Option<Contents>,
}

#[derive(Debug)]
enum ArcAtom {
    I32(i32),
    I64(i64),
    F32(u32),
    F64(u64),
    V128(u128),
    I31(u32),
    NullAny,
    NullFunc,
    NullExtern,
    NullExn,
    NullCont,
    Function(Func),
    ArcNode(usize),
    Opaque(std::sync::Arc<SessionValue>),
}

#[derive(Debug)]
enum ArcContents {
    Struct(StructType, Vec<ArcAtom>),
    Array(ArrayType, Vec<ArcAtom>),
}

#[derive(Debug)]
struct ArcNode {
    value: SessionValue,
    // Same-hash references still require actual GC-reference equality.
    collision: Option<usize>,
    contents: Option<ArcContents>,
}


struct Cut { value: SessionValue, collision: Option<usize> }
struct ArcCut { value: std::sync::Arc<SessionValue>, collision: Option<usize> }

use std::sync::{Arc,Weak};
enum PhysicalExpected { Sentinel(u32), Number(StructType,u64), String(ArrayType,Vec<u16>) }
struct ScalarInputs { receiver: SessionValue, expected: PhysicalExpected }
struct Seed; struct Watch;
struct StorageSnapshot { owner:u64, root:Atom, nodes:Vec<Node> }
struct OldDomainNode { value:SessionValue,snapshot:Option<StorageSnapshot>,seed:Option<Arc<Seed>>,edges:Vec<SessionValue>,watch:Option<Weak<Watch>> }
enum DomainNode { Scalar(Arc<ScalarInputs>), Complex(Box<OldDomainNode>) }
fn main(){macro_rules! row {($t:ty)=>{println!("{} {} {}",stringify!($t),size_of::<$t>(),align_of::<$t>()));}}
row!(SessionValue);row!(StructType);row!(ArrayType);row!(PhysicalExpected);row!(ScalarInputs);row!(StorageSnapshot);row!(OldDomainNode);row!(DomainNode);
println!("scalar_arc_payload_header {}",size_of::<ScalarInputs>()+2*size_of::<usize>());
}
