(ns suss-oracle.namespace-constructor-callback
 (:require [cljs.analyzer :as ana] [cljs.env :as env] [cljs.js :as cljs]
           [cljs.tools.reader :as reader]))
(def rows (array))
(def events (array))
(defn map-slot [m key]
 (letfn [(walk [node]
           (when node
            (let [a (aget node "arr")]
             (when a
              (or (first (keep (fn [i] (when (= (aget a i) key) #js [a (inc i)]))
                               (range 0 (.-length a) 2)))
                  (first (keep walk (array-seq a))))))))]
  (or (walk m) (walk (aget m "root"))
      (throw (js/Error. (str "unsupported map slot " key))))))
(def method-key "cljs$core$IHash$_hash$arity$1")
(defn descriptor= [a b]
 (and (some? a) (some? b)
      (every? (fn [k] (identical? (aget a k) (aget b k)))
              ["value" "get" "set" "writable" "enumerable" "configurable"])))
(defn construct [route subject]
 ;; These are distinct actual construction APIs; no explicit hash in this fn.
 (case route
  "env-only" nil
  "array-map-fromArray" (.fromArray cljs.core/PersistentArrayMap #js [subject 17] true true)
  "hash-map-fromArray" (.fromArray cljs.core/PersistentHashMap #js [subject 17] true)
  "hash-map-fromArrays" (.fromArrays cljs.core/PersistentHashMap #js [subject] #js [17])
  "hash-map-fn" (hash-map subject 17)
  "set-fromArray-small" (.fromArray cljs.core/PersistentHashSet #js [subject] true)
  "set-fromArray-large" (.fromArray cljs.core/PersistentHashSet #js [subject :a :b :c :d :e :f :g :h] true)
  "hash-set-fn-large" (hash-set subject :a :b :c :d :e :f :g :h)
  "literal-map-large" {subject 17 :a 1 :b 2 :c 3 :d 4 :e 5 :f 6 :g 7 :h 8}
  "literal-set-large" #{subject :a :b :c :d :e :f :g :h}
  "reader-map-large" (binding [reader/*data-readers* {'suss/subject (fn [_] subject)}]
                       (reader/read-string "{#suss/subject nil 17 :a 1 :b 2 :c 3 :d 4 :e 5 :f 6 :g 7 :h 8}"))
  "reader-set-large" (binding [reader/*data-readers* {'suss/subject (fn [_] subject)}]
                       (reader/read-string "#{#suss/subject nil :a :b :c :d :e :f :g :h}"))))
(defn run-case [route]
 (let [state (cljs/empty-state) cache cljs.core/NS_CACHE cache-before @cache
       target (symbol (str "suss-oracle.construct-" route))
       macro-ns 'suss-oracle.construct-macros$macros
       proto (.-prototype cljs.core/PersistentArrayMap)
       descriptor (js/Object.getOwnPropertyDescriptor proto method-key)
       original (aget proto method-key) saved (array nil) subject-box (array nil)
       slot-box (array nil) old-box (array nil) memo-box (array nil)
       selected-count (array 0) other-count (array 0) stage (array "setup")
       results (array) restored (array false) macro-count (array 0)
       emit (fn [event details]
              (let [s (aget saved 0)
                    entry #js {:route route :event event :stage (aget stage 0)
                       :selected-count (aget selected-count 0)
                       :saved-doc (when s (:doc (.-raw s))) :details details}]
               (.push events entry)
               (js/console.log (.stringify js/JSON #js {:observation entry}))))
       replacement
       (fn [coll]
        (this-as receiver
         (if (identical? receiver (aget subject-box 0))
          (do
           (aset selected-count 0 (inc (aget selected-count 0)))
           (emit "selected-hash-enter" #js {:physical-this-is-subject true
                          :formal-null (nil? coll) :formal-is-subject (identical? coll receiver)
                          :memo-before (aget receiver "__hash")})
           (let [slot (aget slot-box 0)] (aset (aget slot 0) (aget slot 1) "callback-poison"))
           (emit "poison-written" nil)
           (let [result (.call original receiver coll)]
            (.push results result)
            (emit "selected-hash-return" #js {:value result :memo-after (aget receiver "__hash")})
            result))
          (do (aset other-count 0 (inc (aget other-count 0))) (.call original receiver coll)))))
       analyze (fn [text]
        (binding [env/*compiler* state ana/*cljs-ns* target ana/*analyze-deps* false ana/*load-macros* false]
         (ana/analyze (assoc (ana/empty-env) :ns (ana/get-namespace target)) (reader/read-string text))))
       observer
       (fn [_ macro-env label]
        (aset macro-count 0 (inc (aget macro-count 0)))
        (emit (str "macro-entry-" label) nil)
        (let [ns (:ns macro-env) raw (get-in ns [:defs 'watched])
              subject (get-in raw [:meta :audit])]
         (if (= label "capture")
          (do
           (assert (instance? cljs.core/PersistentArrayMap subject))
           (aset saved 0 #js {:env macro-env :ns ns :raw raw :subject subject})
           (aset subject-box 0 subject)
           (let [slot (map-slot raw :doc)]
            (aset slot-box 0 slot) (aset old-box 0 (aget (aget slot 0) (aget slot 1))))
           (aset memo-box 0 (aget subject "__hash")))
          (let [s (aget saved 0) canonical-control
                ;; Separate equal map, direct original method, outside constructor window.
                (.call original {:token 41} nil)
                prior (aget selected-count 0) other-prior (aget other-count 0)]
           (aset stage 0 "constructor")
           (emit "constructor-enter" #js {:route route :subject-memo (aget subject "__hash")})
           (let [value (construct route subject)
                 selected (- (aget selected-count 0) prior)]
            (emit "constructor-return" #js {:count (when value (count value))})
            (aset stage 0 "post-constructor")
            (.push rows #js {:route route :macro-entries (aget macro-count 0)
                :pre-constructor-selected prior :constructor-selected selected
                :other-dispatches-in-constructor (- (aget other-count 0) other-prior)
                :result-count (when value (count value))
                :same-subject (identical? subject (.-subject s))
                :same-raw (identical? raw (.-raw s)) :same-ns (identical? ns (.-ns s))
                :fresh-env (not (identical? macro-env (.-env s)))
                :initial-subject-memo (aget memo-box 0)
                :canonical-control canonical-control :selected-returns (.slice results 0)
                ;; Read count/value without key lookup (which could hash subject again).
                :result-has-exact-subject (when value (boolean (some #(identical? subject %)
                                                      (if (map? value) (keys value) value))))
                :saved-doc (:doc (.-raw s)) :current-doc (:doc raw)
                :compiler-doc (get-in (ana/get-namespace target) [:defs 'watched :doc])
                :selected-method-installed (identical? replacement (aget proto method-key))})
            (emit "post-constructor-observation" #js {:saved-doc (:doc (.-raw s)) :current-doc (:doc raw)
                 :compiler-doc (get-in (ana/get-namespace target) [:defs 'watched :doc])}))))
        (emit (str "macro-exit-" label) nil)
        17)]
  (try
   (assert (fn? original))
   (assert (some? descriptor))
   (analyze (str "(ns " target ")"))
   (analyze "(def ^{:doc \"original-doc\" :audit {:token 41}} watched 17)")
   (swap! state assoc-in [::ana/namespaces macro-ns]
     {:name macro-ns :defs {'observe {:name 'suss-oracle.construct-macros$macros/observe
       :macro true :method-params [['&form '&env 'label]] :max-fixed-arity 3}}})
   (set! (.-cljs$lang$macro observer) true)
   (swap! cache assoc macro-ns (create-ns macro-ns #js {:observe observer}))
   (analyze "(suss-oracle.construct-macros/observe \"capture\")")
   (aset proto method-key replacement)
   (aset stage 0 "later-macro-handoff")
   (analyze "(suss-oracle.construct-macros/observe \"construct\")")
   (finally
    ;; Explicit cleanup only after second macro returns (or throws).
    (js/Object.defineProperty proto method-key descriptor)
    (when-let [slot (aget slot-box 0)]
     (aset (aget slot 0) (aget slot 1) (aget old-box 0)))
    (when-let [subject (aget subject-box 0)] (aset subject "__hash" (aget memo-box 0)))
    (reset! cache cache-before)
    (aset restored 0 (and (descriptor= descriptor (js/Object.getOwnPropertyDescriptor proto method-key))
      (identical? original (aget proto method-key)) (identical? cache-before @cache)
      (or (nil? (aget saved 0))
          (and (= "original-doc" (:doc (.-raw (aget saved 0))))
               (identical? (aget memo-box 0) (aget (aget subject-box 0) "__hash"))))))
    (aset stage 0 "cleanup")
    (emit "restoration" #js {:method-descriptor-and-storage-and-memo-and-cache (aget restored 0)})))
  (assert (aget restored 0))
  (assert (= 2 (aget macro-count 0)))))
(defn -main []
 (when (nil? cljs.core/NS_CACHE) (set! cljs.core/NS_CACHE (atom {})))
 (try
  (doseq [route ["env-only" "array-map-fromArray" "hash-map-fromArray" "hash-map-fromArrays"
                "hash-map-fn" "set-fromArray-small" "set-fromArray-large" "hash-set-fn-large"
                "literal-map-large" "literal-set-large" "reader-map-large" "reader-set-large"]]
   (run-case route))
  (finally
   ;; Raw partial observations also survive unexpected errors; no catch/swallow.
   (js/console.log (.stringify js/JSON #js {:pin "c4295f303100bbf5afac449242d30bca1126f1a1"
      :rows rows :events events :limits "Automatic IHash dispatch from distinct later construction APIs inside actual macro body; no explicit hash. Tagged reader returns exact selected compiler metadata map. Not automatic compiler env retransport; direct pinned host storage mutation. Each case restores only after later macro returns. Canonical selected-method delegation, other receivers delegate unchanged. Native authority/publication validation not established."})))))
(set! *main-cli-fn* -main)
