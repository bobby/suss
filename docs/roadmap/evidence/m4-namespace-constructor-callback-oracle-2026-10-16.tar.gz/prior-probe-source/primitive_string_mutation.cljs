(ns suss-oracle.primitive-string-mutation)
(def rows (array))
(defn -main []
 (let [root (.-charCodeAt "AB")
       old-call (js/Object.getOwnPropertyDescriptor root "call")
       old-apply (js/Object.getOwnPropertyDescriptor root "apply")
       old-prototype (js/Object.getOwnPropertyDescriptor root "prototype")
       events (array) reads (array)
       replacement (fn [] (.push events "replacement-method") 701)
       string-proto (.-prototype js/String)
       old-method (js/Object.getOwnPropertyDescriptor string-proto "charCodeAt")
       poison (fn [name]
        (js/Object.defineProperty root name
         #js {:configurable true :get (fn [] (.push reads name)
                                       (throw (js/Error. (str "unexpected-root-property-read/" name))))}))]
  (try
   (let [value (.charCodeAt
                (do (.push events "receiver") "AB")
                (do (.push events "index")
                    (poison "call") (poison "apply") (poison "prototype") 1))]
    (.push rows #js {:id "root-call-apply-prototype-mutation-during-index"
                    :result value :events (.slice events 0) :root-property-reads (.slice reads 0)
                    :root-identity-preserved (identical? root (.-charCodeAt "AB"))})
    (assert (= value 66))
    (assert (= (.join events ",") "receiver,index"))
    (assert (= 0 (.-length reads))))
   ;; A direct call selects its method before evaluating the index expression.
   (set! (.-length events) 0)
   (let [selected-call (.charCodeAt
                        (do (.push events "receiver") "AB")
                        (do (.push events "index")
                            (js/Object.defineProperty string-proto "charCodeAt"
                             #js {:configurable true :writable true :value replacement}) 1))
         after-call (.charCodeAt "AB" 1)]
    (.push rows #js {:id "string-prototype-method-replacement-during-index"
                    :selected-result selected-call :next-result after-call
                    :events (.slice events 0) :root-property-reads (.slice reads 0)})
    (assert (= selected-call 66)) (assert (= after-call 701))
    (assert (= (.join events ",") "receiver,index,replacement-method"))
    (assert (= 0 (.-length reads))))
   (finally
    (js/Object.defineProperty string-proto "charCodeAt" old-method)
    (doseq [[name descriptor] [["call" old-call] ["apply" old-apply] ["prototype" old-prototype]]]
     (if (some? descriptor) (js/Object.defineProperty root name descriptor)
         (js/Reflect.deleteProperty root name)))))
  ;; Verify restoration before emitting any output; don't invoke the poisoned properties.
  (assert (= 66 (.charCodeAt "AB" 1)))
  (assert (identical? root (.-charCodeAt "AB")))
  (js/console.log (.stringify js/JSON #js {:pin "c4295f303100bbf5afac449242d30bca1126f1a1"
                  :rows rows :restored true}))))
(set! *main-cli-fn* -main)
