import pathlib,json,hashlib,subprocess,tarfile,io,datetime
p=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads((p/'run1-observations.json').read_text());b=json.loads((p/'run2-observations.json').read_text());assert a==b
counts={'env-only':0,'array-map-fromArray':0,'hash-map-fromArray':1,'hash-map-fromArrays':1,'hash-map-fn':1,'set-fromArray-small':0,'set-fromArray-large':1,'hash-set-fn-large':1,'literal-map-large':1,'literal-set-large':1,'reader-map-large':2,'reader-set-large':1}
actual_apis={'env-only':'No construction; later actual macro env handoff control', 'array-map-fromArray':'PersistentArrayMap.fromArray([subject,17],true,true)', 'hash-map-fromArray':'PersistentHashMap.fromArray([subject,17],true)', 'hash-map-fromArrays':'PersistentHashMap.fromArrays([subject],[17])', 'hash-map-fn':'SOURCE LABEL QUALIFIED: direct hash-map call expands as macro to PersistentHashMap.fromArrays, not hash_map function', 'set-fromArray-small':'PersistentHashSet.fromArray([subject],true)', 'set-fromArray-large':'PersistentHashSet.fromArray([subject,:a..:h],true)', 'hash-set-fn-large':'SOURCE LABEL QUALIFIED: direct hash-set call expands as macro to PersistentHashSet.createAsIfByAssoc, not hash_set function','literal-map-large':'Map literal emits PersistentHashMap.fromArrays with compiler-selected key order', 'literal-set-large':'Set literal emits PersistentHashSet.createAsIfByAssoc with compiler-selected item order','reader-map-large':'tools.reader read-map: duplicate-key set construction followed by PersistentHashMap.fromArray (9 entries); tagged reader supplies exact subject', 'reader-set-large':'tools.reader read-set: set construction (9 items); tagged reader supplies exact subject'}
base=['macro-entry-capture','macro-exit-capture','macro-entry-construct','constructor-enter']
tail=['constructor-return','post-constructor-observation','macro-exit-construct','restoration']
for r in a['rows']:
 route=r['route'];n=counts[route];assert r['constructor-selected']==n and r['pre-constructor-selected']==0
 assert r['macro-entries']==2
 assert r['initial-subject-memo'] is None
 for key in ['same-subject','same-raw','same-ns','fresh-env','selected-method-installed']:assert r[key]
 if route!='env-only':assert r['result-has-exact-subject']
 assert all(v==r['canonical-control']==124169561 for v in r['selected-returns'])
 assert len(r['selected-returns'])==n
 doc='callback-poison' if n else 'original-doc'
 assert all(r[k]==doc for k in ['saved-doc','current-doc','compiler-doc'])
 ev=[e for e in a['events'] if e['route']==route]
 assert [e['event'] for e in ev]==base+['selected-hash-enter','poison-written','selected-hash-return']*n+tail
 assert ev[-1]['details']['method-descriptor-and-storage-and-memo-and-cache'] is True
 assert ev[-2]['saved-doc']==doc and ev[-1]['saved-doc']=='original-doc'
 for e in ev:
  if e['event']=='selected-hash-enter':
   assert e['stage']=='constructor'
   assert e['details']['physical-this-is-subject'] and e['details']['formal-null'] and not e['details']['formal-is-subject']
  if e['event']=='selected-hash-return':assert e['details']['value']==124169561 and e['details']['memo-after']==124169561
assert len(a['rows'])==12 and len(a['events'])==126
pin=pathlib.Path('/home/bobby/Work/code/bobby/suss/clojurescript')
head=subprocess.check_output(['git','-C',str(pin),'rev-parse','HEAD'],text=True).strip();status=subprocess.check_output(['git','-C',str(pin),'status','--porcelain'],text=True);assert head==a['pin'] and not status
for f in ['src/main/clojure/cljs/analyzer.cljc','src/main/clojure/cljs/compiler.cljc','src/main/clojure/cljs/core.cljc','src/main/cljs/cljs/core.cljs','LICENSE','epl-v10.html','deps.edn']:
 dest=p/'upstream'/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((pin/f).read_bytes())
reader=p/'out/cljs/cljs/tools/reader.cljs';dest=p/'upstream/tools-reader.cljs';dest.write_bytes(reader.read_bytes())
for f in ['tests/oracle/src/suss_oracle/metadata_custom_hash_order.cljs','tests/oracle/src/suss_oracle/metadata_memo_call_boundary.cljs']:
 root=pathlib.Path('/home/bobby/Work/code/bobby/suss');dest=p/'prior-probe-source'/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((root/f).read_bytes())
f=pathlib.Path('/home/bobby/.cache/suss-m4-work/primitive-string-mutation-oracle/src/suss_oracle/primitive_string_mutation.cljs');(p/'prior-probe-source/primitive_string_mutation.cljs').write_bytes(f.read_bytes())
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pin':head,'pin_clean_after':True,'two_runs_equal':True,'macro_calls_per_run':24,'constructor_selected_callbacks_per_run':10,'events_per_run':126,'cold_selected_subject_each_case':True,'selected_method_return':124169561,'method_storage_memo_cache_restoration_all_verified':True,'all_current_run_receipts_source_unchanged':all(json.loads((p/f).read_text())['source_unchanged'] for f in ['compile-receipt.json','run1-receipt.json','run2-receipt.json']),'actual_apis':actual_apis,'constructor_counts_by_route':counts,'rows':a['rows'],'first_failure':'compile exit1 unmatched delimiter; all cases unexecuted, source/log/full compiler report/receipt retained under first-attempt','limits':['No explicit core/hash in constructor path; canonical control directly calls original method on a separate equal map outside constructor window.','hash-map-fn and hash-set-fn-large labels denote source forms macro-expanded to fromArrays/createAsIfByAssoc; no function-entry coverage claimed.','Exact subject automatic callbacks only; other receiver dispatch count is not a complete global hash trace.','Reader tagged-literal handler supplies exact known retained map; not a default reader behavior or an arbitrary serialized host reference.','Pinned compiler owns and shares mutated maps; native immutable-source clean-transport restoration is a separate integrity requirement.','No callback induced solely by ordinary pinned macro env handoff in env-only control. No pinned native-style env transport/reconstruction exists in tested path.','No native execution, final certificate/publication proof, IRQ/fuel, reset/foreign owner, unrelated source revision, or issue acceptance claim.','Constructed result count/key identity and hash returns observed; arbitrary full map payload projection not recorded.','Native source snapshots are read-only audit bytes from a concurrently edited worktree, not a frozen/executed candidate or CI source proof.','First instrumentation compile failure preserved; initial source contains labels qualified in this receipt and README rather than relabeling/reexecuting frozen probe.']}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(p/'README.md').write_text('''# Pinned constructor-triggered namespace invalidation, 2026-10-16

Cache-only command: python /home/bobby/.cache/suss-m4-work/namespace-constructor-callback-oracle/runner.py
Clean CLJS c4295f303100bbf5afac449242d30bca1126f1a1, cached CLI/JRE/Maven inputs.
First compile exits1 unmatched delimiter; no cases execute. Source/log/compiler
report/receipt retained under first-attempt. Delimiter corrected without changing
observation criteria; subsequent compile0 and two independent Node runs0, outputs
identical. All four frozen probe/runner/deps/run-script hashes unchanged in runs.

Policy candidate executed: first actual macro captures actual compiler-owned raw
watched declaration and its nested :meta/:audit map {:token41}. Before second macro
handoff, install PersistentArrayMap IHash wrapper by exact descriptor property
cljs$core$IHash$_hash$arity$1. Only physical this identical to that audit map mutates
the earlier captured declaration's existing :doc slot to callback-poison; then
calls original.call(receiver,coll) and returns original result. All other receivers
delegate original.call(receiver,coll) unchanged. No explicit hash call in construct;
a separate canonical control directly calls original method on equal independent
map outside the constructor window. All selected formal args are null while
physical this is subject; conflating formal receiver and this would be wrong.

Separate twelve routes with fresh compiler state per route. There are24 actual
macro invocations/run,10 automatic selected callbacks and126 ordered events.
Selected subject is initially cold in every case. Original delegated return and
written memo are124169561. All constructed collections retain exact subject;
counts are1 or9 as recorded (env-only result nil). Earlier saved/current/live
compiler docs all become callback-poison on triggered routes. They stay poisoned
through macro-exit and restore after later analyze returns. Fresh env maps remain
distinct; namespace/raw/subject identity retained.

Actual APIs and per-route callback counts:
- env-only0; PersistentArrayMap.fromArray small0; PersistentHashSet.fromArray small0.
- PersistentHashMap.fromArray1; PersistentHashMap.fromArrays1.
- Direct source hash-map form1, but generated code is fromArrays: label hash-map-fn
  in raw rows is not evidence of runtime hash_map function entry.
- PersistentHashSet.fromArray nine1.
- Direct source hash-set form nine1, generated createAsIfByAssoc: label
  hash-set-fn-large is not evidence of runtime hash_set function entry.
- Compiled map literal nine1 -> fromArrays; compiled set literal nine1 ->
  createAsIfByAssoc. Generated JS preserves actual compiler-selected order.
- tools.reader map nine2: duplicate-key set plus map construction; tools.reader
  set nine1. Bound tagged-reader returns exact subject without hashing it itself.
  These reader operations are distinct from runtime literal APIs; do not combine
  their callback counts. Exact generated JS, core/compiler/reader sources retained.

Order per route: macro-entry-capture -> macro-exit-capture -> macro-entry-construct
-> constructor-enter -> [selected-hash-enter -> poison-written ->
selected-hash-return] repeated observed count -> constructor-return ->
post-constructor-observation -> macro-exit-construct -> restoration. There are no
selected callbacks before constructor-enter. Controls keep original-doc. All
restorations explicitly check method descriptor fields/value, saved physical slot
semantic readback, subject hash memo identity and cache atom contents identity.
No method replacement, memo or poisoned storage survives the run. Unknown errors
are not swallowed; top finally prints partial observations even if a case throws.

Output: live {observation:{route,event,stage,selected-count,saved-doc,details}};
final {pin,rows,events,limits}. Values here use native JSON numbers/booleans, not
pr-str event strings from the earlier explicit-hash oracle. Details contain actual
receiver/formal/memo at entry, delegated value/memo at return, or restoration flag.
Row schema and per-route API map are preserved in receipt.json.

Substantive boundary: automatic construction-triggered callback is reproducible
without explicit macro-body hash. Later map/set reconstruction can invalidate an
earlier compiler-owned object while preserving canonical selected-method results.
However pinned analyzer get-namespace/macroexpand-1* directly shares host maps;
ordinary subsequent env handoff has no selected callback in this probe and is not
native transport reconstruction. Tagged reader returns a retained object by an
explicit extension, not by decoding an ordinary source literal. This does not
establish which callbacks native env materialization must trigger, nor permit
retries that duplicate a proven constructor's effects.

Native sourceRoots audit rationale (read-only snapshots, NOT executed/frozen source):
postorder materialization can construct a later sibling after retaining an earlier
child; Map/ReaderMap funnel into map_values and Set/ReaderSet into set_values.
map_values invokes retained core hash on nonnil keys when input entries>8; set_values
funnels through that map path. Therefore later construction can invalidate earlier
children, and pre-callback child validation is insufficient. Source-root child
rechecks/final parent/shared-export validation must use independent immutable native
facts. Native clean NEW transport with poisoned OLD guest objects is a distinct
integrity contract: pinned host poisoning also contaminates its compiler-owned live
map, so this oracle is not a clean-source restoration reference. No native cache
repair, final publication, fuel/IRQ, GC/reset/foreign owner or full #264 acceptance
proof. Existing native obligations and original criteria remain unchanged.

No Cargo, production/test/bootstrap/source-worktree edits, commits, pushes, PR/issue
posts or CI mutations. Probe-generated output/source and read-only source excerpts
remain cache-only. Other agents' edited source was never snapshotted as CI source.
''')
files={str(f.relative_to(p)):f.read_bytes() for f in p.rglob('*') if f.is_file() and not any(s in f.relative_to(p).parts for s in ['clj-cache','.cpcache']) and f.name!='MANIFEST.json'}
manifest={n:sha(v) for n,v in sorted(files.items())};files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=p.parent/'m4-namespace-constructor-callback-oracle-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,v in sorted(files.items()):
  i=tarfile.TarInfo(n);i.size=len(v);i.mode=0o644;t.addfile(i,io.BytesIO(v))
with tarfile.open(out,'r:gz') as t:
 for m in t.getmembers():
  if m.name!='MANIFEST.json':assert sha(t.extractfile(m).read())==manifest[m.name]
result={'archive':str(out),'sha256':sha(out.read_bytes()),'payloads_excluding_manifest':len(manifest),'all_payload_hashes_verified':True,'receipt':str(p/'receipt.json')}
(p.parent/'namespace-constructor-callback-oracle-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
