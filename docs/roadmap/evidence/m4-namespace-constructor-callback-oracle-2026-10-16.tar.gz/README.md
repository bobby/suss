# Pinned constructor-triggered namespace invalidation, 2026-10-16

Cache-only command: python /home/bobby/.cache/suss-m4-work/namespace-constructor-callback-oracle/runner.py
Clean CLJS c4295f303100bbf5afac449242d30bca1126f1a1, cached CLI/JRE/Maven inputs.
First compile exits1 unmatched delimiter; no cases execute. Source/log/compiler
report/receipt retained under first-attempt. Delimiter corrected without changing
observation criteria; subsequent compile0 and two independent Node runs0, outputs
identical. All four frozen probe/runner/deps/run-script hashes unchanged in runs.

Policy candidate executed: first actual macro captures actual compiler-owned raw
watched declaration and its nested :meta/:audit map {:token41}. Before second macro
handoff, install PersistentArrayMap IHash wrapper by exact descriptor property
cljs$core$IHash$_hash$arity$1. Only physical this identical to that audit map mutates
the earlier captured declaration's existing :doc slot to callback-poison; then
calls original.call(receiver,coll) and returns original result. All other receivers
delegate original.call(receiver,coll) unchanged. No explicit hash call in construct;
a separate canonical control directly calls original method on equal independent
map outside the constructor window. All selected formal args are null while
physical this is subject; conflating formal receiver and this would be wrong.

Separate twelve routes with fresh compiler state per route. There are24 actual
macro invocations/run,10 automatic selected callbacks and126 ordered events.
Selected subject is initially cold in every case. Original delegated return and
written memo are124169561. All constructed collections retain exact subject;
counts are1 or9 as recorded (env-only result nil). Earlier saved/current/live
compiler docs all become callback-poison on triggered routes. They stay poisoned
through macro-exit and restore after later analyze returns. Fresh env maps remain
distinct; namespace/raw/subject identity retained.

Actual APIs and per-route callback counts:
- env-only0; PersistentArrayMap.fromArray small0; PersistentHashSet.fromArray small0.
- PersistentHashMap.fromArray1; PersistentHashMap.fromArrays1.
- Direct source hash-map form1, but generated code is fromArrays: label hash-map-fn
  in raw rows is not evidence of runtime hash_map function entry.
- PersistentHashSet.fromArray nine1.
- Direct source hash-set form nine1, generated createAsIfByAssoc: label
  hash-set-fn-large is not evidence of runtime hash_set function entry.
- Compiled map literal nine1 -> fromArrays; compiled set literal nine1 ->
  createAsIfByAssoc. Generated JS preserves actual compiler-selected order.
- tools.reader map nine2: duplicate-key set plus map construction; tools.reader
  set nine1. Bound tagged-reader returns exact subject without hashing it itself.
  These reader operations are distinct from runtime literal APIs; do not combine
  their callback counts. Exact generated JS, core/compiler/reader sources retained.

Order per route: macro-entry-capture -> macro-exit-capture -> macro-entry-construct
-> constructor-enter -> [selected-hash-enter -> poison-written ->
selected-hash-return] repeated observed count -> constructor-return ->
post-constructor-observation -> macro-exit-construct -> restoration. There are no
selected callbacks before constructor-enter. Controls keep original-doc. All
restorations explicitly check method descriptor fields/value, saved physical slot
semantic readback, subject hash memo identity and cache atom contents identity.
No method replacement, memo or poisoned storage survives the run. Unknown errors
are not swallowed; top finally prints partial observations even if a case throws.

Output: live {observation:{route,event,stage,selected-count,saved-doc,details}};
final {pin,rows,events,limits}. Values here use native JSON numbers/booleans, not
pr-str event strings from the earlier explicit-hash oracle. Details contain actual
receiver/formal/memo at entry, delegated value/memo at return, or restoration flag.
Row schema and per-route API map are preserved in receipt.json.

Substantive boundary: automatic construction-triggered callback is reproducible
without explicit macro-body hash. Later map/set reconstruction can invalidate an
earlier compiler-owned object while preserving canonical selected-method results.
However pinned analyzer get-namespace/macroexpand-1* directly shares host maps;
ordinary subsequent env handoff has no selected callback in this probe and is not
native transport reconstruction. Tagged reader returns a retained object by an
explicit extension, not by decoding an ordinary source literal. This does not
establish which callbacks native env materialization must trigger, nor permit
retries that duplicate a proven constructor's effects.

Native sourceRoots audit rationale (read-only snapshots, NOT executed/frozen source):
postorder materialization can construct a later sibling after retaining an earlier
child; Map/ReaderMap funnel into map_values and Set/ReaderSet into set_values.
map_values invokes retained core hash on nonnil keys when input entries>8; set_values
funnels through that map path. Therefore later construction can invalidate earlier
children, and pre-callback child validation is insufficient. Source-root child
rechecks/final parent/shared-export validation must use independent immutable native
facts. Native clean NEW transport with poisoned OLD guest objects is a distinct
integrity contract: pinned host poisoning also contaminates its compiler-owned live
map, so this oracle is not a clean-source restoration reference. No native cache
repair, final publication, fuel/IRQ, GC/reset/foreign owner or full #264 acceptance
proof. Existing native obligations and original criteria remain unchanged.

No Cargo, production/test/bootstrap/source-worktree edits, commits, pushes, PR/issue
posts or CI mutations. Probe-generated output/source and read-only source excerpts
remain cache-only. Other agents' edited source was never snapshotted as CI source.
