import pathlib,subprocess,time,json,hashlib
p=pathlib.Path(__file__).parent
files=['src/suss_oracle/namespace_callback.cljs','run.sh','deps.edn','runner.py']
def freeze():return {f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in files}
before=freeze();(p/'source-freeze.json').write_text(json.dumps(before,indent=2)+'\n')
for name,cmd in [('compile',['bash',str(p/'run.sh')]),('run1',['node','out/probe.js']),('run2',['node','out/probe.js'])]:
 start=time.monotonic()
 with (p/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=p,stdout=log,stderr=subprocess.STDOUT)
 receipt={'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start,'source_unchanged':before==freeze()}
 (p/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(name,json.dumps(receipt),flush=True)
 if r.returncode:break
 if name!='compile':
  obs=json.loads(next(l for l in reversed((p/(name+'.log')).read_text().splitlines()) if l.startswith('{"pin"')))
  (p/(name+'-observations.json')).write_text(json.dumps(obs,indent=2)+'\n')
