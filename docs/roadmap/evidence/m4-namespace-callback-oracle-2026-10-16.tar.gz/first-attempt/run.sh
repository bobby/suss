#!/usr/bin/env bash
set -euo pipefail
probe=/home/bobby/.cache/suss-m4-work/namespace-callback-oracle
pin=/home/bobby/Work/code/bobby/suss/clojurescript
export JAVA_HOME=/home/bobby/.cache/suss-m4-oracle-tools/jdk-21.0.8+9-jre
export PATH="$JAVA_HOME/bin:$PATH"
test "$(git -C "$pin" rev-parse HEAD)" = c4295f303100bbf5afac449242d30bca1126f1a1
test -z "$(git -C "$pin" status --porcelain)"
cd "$probe"
CLJ_CONFIG=/tmp/suss-oracle-clojure-config CLJ_CACHE="$probe/clj-cache" /home/bobby/.cache/suss-m4-oracle-tools/bin/clojure -J-Xmx1g -J-XX:ActiveProcessorCount=2 -Srepro -M -m cljs.main -co '{:force true :cache-analysis false :target :nodejs :output-to "out/probe.js" :output-dir "out/cljs" :optimizations :none :source-map false}' -c suss-oracle.namespace-callback
