(ns suss-oracle.namespace-callback
 (:require [cljs.analyzer :as ana] [cljs.env :as env] [cljs.js :as cljs]
           [cljs.tools.reader :as reader]))
(def rows (array))
(def events (array))
;; Pinned implementation storage inspection, deliberately bypassing persistence.
;; Locate an existing map value slot only; never assoc a replacement parent.
(defn map-slot [m key]
 (letfn [(walk [node]
           (when node
            (let [a (aget node "arr")]
             (when a
              (or (first (keep (fn [i] (when (= (aget a i) key) #js [a (inc i)]))
                               (range 0 (.-length a) 2)))
                  (first (keep walk (array-seq a))))))))]
  (or (walk m) (walk (aget m "root"))
      (throw (js/Error. (str "unsupported map slot " key))))))
(defn record! [kind stage value]
 (.push events #js {:case kind :event stage :value (pr-str value)}))
(defn run-case [kind]
 (let [state (cljs/empty-state) cache cljs.core/NS_CACHE cache-before @cache
       target (symbol (str "suss-oracle.callback-" kind))
       macro-ns 'suss-oracle.callback-macros$macros
       saved (array) count (array 0) restored (array false)
       analyze (fn [s]
        (binding [env/*compiler* state ana/*cljs-ns* target ana/*analyze-deps* false ana/*load-macros* false]
         (ana/analyze (assoc (ana/empty-env) :ns (ana/get-namespace target)) (reader/read-string s))))
       observer
       (fn [_ macro-env label]
        (record! kind (str "entry-" label) (aget count 0))
        (let [ns (:ns macro-env) defs (:defs ns) raw (get defs 'watched)
              params (get-in defs ['callable :method-params])
              child (first params)
              audit (get-in raw [:meta :audit])
              resolved (:info (ana/analyze macro-env 'callable))
              owner (case kind "namespace" ns "defs" defs "declaration" raw "metadata-child" audit "method-child" child)
              key (case kind "namespace" :name "defs" 'watched "declaration" :doc "metadata-child" :token "method-child" nil)
              slot (if (= kind "method-child")
                     (do (assert (and (vector? child) (= 1 (count child)))) #js [(aget child "tail") 0])
                     (map-slot owner key))
              storage (aget slot 0) index (aget slot 1)
              view (fn [n]
                     (case kind "namespace" (:name n) "defs" (get-in n [:defs 'watched])
                       "declaration" (get-in n [:defs 'watched :doc])
                       "metadata-child" (get-in n [:defs 'watched :meta :audit :token])
                       "method-child" (first (first (get-in n [:defs 'callable :method-params])))))]
         (if (= label "capture")
          (.push saved #js {:env macro-env :ns ns :owner owner :storage storage :index index :original (aget storage index)})
          (let [s (aget saved 0) old (aget (.-storage s) (.-index s))
                poison (case kind "namespace" 'poisoned.namespace "defs" {:poison 702}
                         "declaration" "poisoned-doc" "metadata-child" 704 "method-child" 'poisoned-param)
                callback (reify IHash
                          (-hash [_]
                           (aset count 0 (inc (aget count 0)))
                           (record! kind "hash-enter" (aget count 0))
                           (aset (.-storage s) (.-index s) poison)
                           (record! kind "captured-during" (view (.-ns s)))
                           (record! kind "current-during" (view ns))
                           (record! kind "compiler-during" (view (ana/get-namespace target)))
                           (record! kind "hash-exit" 719)
                           719))]
           (try
            (let [hash-result (hash callback)]
             (.push rows #js {:case kind :hash-result hash-result
               :callback-count (aget count 0) :fresh-env (not (identical? macro-env (.-env s)))
               :same-ns (identical? ns (.-ns s)) :same-owner (identical? owner (.-owner s))
               :same-storage (identical? storage (.-storage s))
               :resolved-method-child-shared (identical? params (:method-params resolved))
               :before (pr-str old) :captured-after (pr-str (view (.-ns s)))
               :current-after (pr-str (view ns)) :compiler-after (pr-str (view (ana/get-namespace target)))}))
            (finally
             (aset (.-storage s) (.-index s) old)
             (aset restored 0 (and (identical? old (aget (.-storage s) (.-index s)))
                                   (= old (view (.-ns s))) (= old (view ns))
                                   (= old (view (ana/get-namespace target)))))
             (record! kind "restored" (aget restored 0)))))))
        (record! kind (str "exit-" label) (aget count 0))
        17)]
  (try
   (analyze (str "(ns " target ")"))
   (analyze "(def ^{:doc \"original-doc\" :audit {:token 41}} watched 17)")
   (analyze "(def callable (fn* [x] x))")
   (swap! state assoc-in [::ana/namespaces macro-ns]
     {:name macro-ns :defs {'observe {:name 'suss-oracle.callback-macros$macros/observe :macro true
                                    :method-params [['&form '&env 'label]] :max-fixed-arity 3}}})
   (set! (.-cljs$lang$macro observer) true)
   (swap! cache assoc macro-ns (create-ns macro-ns #js {:observe observer}))
   (analyze "(let* [held watched] (suss-oracle.callback-macros/observe \"capture\") (suss-oracle.callback-macros/observe \"invalidate\") nil)")
   (finally (reset! cache cache-before)))
  (.push events #js {:case kind :event "cache-restored" :value (identical? cache-before @cache)})
  (assert (aget restored 0))
  (assert (identical? cache-before @cache))
  (assert (= 1 (aget count 0)))))
(defn -main []
 (when (nil? cljs.core/NS_CACHE) (set! cljs.core/NS_CACHE (atom {})))
 (doseq [kind ["namespace" "defs" "declaration" "metadata-child" "method-child"]] (run-case kind))
 (js/console.log (.stringify js/JSON #js {:pin "c4295f303100bbf5afac449242d30bca1126f1a1" :rows rows :events events
 :limits "Actual macro body explicitly calls hash on a dedicated IHash object; no replacement global method. Direct implementation storage mutation of compiler-owned objects. Not automatic transport/reconstruction callback evidence or native cache authority. Maps mutated one existing slot; restoration asserted after callback and NS_CACHE restored by identity. Separate isolated compiler state per case."})))
(set! *main-cli-fn* -main)
