import pathlib,json,hashlib,subprocess,tarfile,io
p=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads((p/'run1-observations.json').read_text());b=json.loads((p/'run2-observations.json').read_text());assert a==b
for row in a['rows']:
 assert row['callback-count']==1 and row['hash-result']==719
 assert all(row[k] for k in ['fresh-env','same-storage','same-owner','same-ns','resolved-method-child-shared'])
 assert row['captured-after']==row['current-after']==row['compiler-after']
for kind in [r['case'] for r in a['rows']]:
 ev=[e for e in a['events'] if e['case']==kind]
 assert [e['event'] for e in ev]==['entry-capture','exit-capture','entry-invalidate','hash-enter','captured-during','current-during','compiler-during','hash-exit','restored','exit-invalidate','cache-restored']
 assert ev[-3]['value']=='true' and ev[-1]['value'] is True
pin=pathlib.Path('/home/bobby/Work/code/bobby/suss/clojurescript')
head=subprocess.check_output(['git','-C',str(pin),'rev-parse','HEAD'],text=True).strip();clean=not subprocess.check_output(['git','-C',str(pin),'status','--porcelain'],text=True)
assert head==a['pin'] and clean
up=p/'upstream';up.mkdir(exist_ok=True)
for f in ['src/main/clojure/cljs/analyzer.cljc','src/main/clojure/cljs/env.cljc','src/main/cljs/cljs/core.cljs','LICENSE','epl-v10.html']:
 content=(pin/f).read_bytes();(up/pathlib.Path(f).name).write_bytes(content)
old=pathlib.Path('/home/bobby/.cache/suss-m4-work/namespace-sharing-oracle')
for f in ['receipt.json','run1-observations.json','run2-observations.json','src/suss_oracle/namespace_sharing.cljs']:
 dest=p/'prior-oracle'/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((old/f).read_bytes())
receipt={'pin':head,'pin_clean_after':clean,'runs_identical':a==b,'macro_calls_per_run':10,'explicit_IHash_callbacks_per_run':5,'event_count_per_run':len(a['events']),'all_storage_and_cache_restorations_verified':True,'source_unchanged_all_receipts':all(json.loads((p/f).read_text())['source_unchanged'] for f in ['compile-receipt.json','run1-receipt.json','run2-receipt.json']),'cases':a['rows'],'initial_failure':'First compile0/run1 exit1: local counter shadowed count in method-child case. Original source/generated probe JS/log/receipts preserved under first-attempt; no complete observations claimed for that attempt.','limits':'No native execution or reconstruction-triggered callback evidence. No persistent poison across macro return, no unrelated-definition revision advance, GC/reset/foreign-owner or failure-publication verdict. No global hash override. Dedicated object implements actual IHash, explicitly hashed once in each second macro body; no delegation obligation because no existing/global method is replaced.'}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(p/'README.md').write_text('''# #264 pinned namespace callback observations

Command: python /home/bobby/.cache/suss-m4-work/namespace-callback-oracle/runner.py
Cached CLI/JRE, local Maven cache, pinned clean CLJS c4295f303100bbf5afac449242d30bca1126f1a1. No Cargo or source-worktree edits. Source freeze covers probe/runner/deps/run script. Both corrected Node runs exit0; compile0. First failure retained separately; current output/receipt supersedes it.

Plan executed: separate compiler state for five cases; capture actual namespace/defs/raw declaration/metadata child/method child in first macro; in second macro explicitly hash a dedicated IHash object exactly once. Callback mutates one physical existing slot, observes captured/current/live-compiler values, returns719; macro reads values after callback then restores storage in finally. Cache restored by identity in outer finally. Actual events and values printed before restoration assertion. Compare two independent Node processes exactly, not expected-value-only summaries.

Every corrected case has fresh outer caller env but identical namespace, owner and physical storage. Poison visible in all three views: poisoned.namespace; {:poison 702}; "poisoned-doc";704;poisoned-param. Exactly one callback and return719. Callable method-params are shared with a freshly resolved info map before mutation. Storage and cache restoration asserted; 55 ordered events/run. Raw before values retained.

Supported equivalent policy: unchanged source-owned children can retain observed aliases and fresh outer maps. An explicit guest hash must retain its return value, once-only callback and observed ordering. Old exposed objects must not be silently repaired by a native cache. Independent immutable-source validation/rebinding must not infer facts from their modified storage or add observable callback invocations.

Important divergence: CLJS analyzer get-namespace retrieves maps directly from compiler state; macroexpand-1* directly applies macro with that env. These observed objects are compiler-owned host objects, not isolated reconstructed guest snapshots. Physical poisoning therefore contaminates the live pinned compiler lookup itself. This does NOT support copying that contamination into native immutable source authority, nor a claim pinned CLJS demonstrates clean native retransport after poisoning. Native integrity policy and primary mutation observations need separate, explicit assertions.

Unproven: automatic IHash callback during later native reconstruction, final affected-parent/shared-export validation, persistent poison across macro return, revision advance, failure publication, GC/reset/foreign-owner, complete #264 acceptance. This probe restores before returning and invokes hash in macro body. No quota, tariff, source facts or acceptance criteria changed. Receipt lists these limits. Original issue body, prior identity observations, pinned upstream source/license and exact generated JS included. No issue/PR posts or CI mutations.
''')
files={str(f.relative_to(p)):f.read_bytes() for f in p.rglob('*') if f.is_file() and not any(s in f.relative_to(p).parts for s in ['clj-cache','.cpcache'])}
files.pop('MANIFEST.json',None)
manifest={n:sha(v) for n,v in sorted(files.items())};files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=p.parent/'m4-namespace-callback-oracle-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,v in sorted(files.items()):
  i=tarfile.TarInfo(n);i.size=len(v);i.mode=0o644;t.addfile(i,io.BytesIO(v))
with tarfile.open(out,'r:gz') as t:
 for m in t.getmembers():
  data=t.extractfile(m).read()
  if m.name!='MANIFEST.json':assert sha(data)==manifest[m.name]
result={'archive':str(out),'sha256':sha(out.read_bytes()),'payloads_excluding_manifest':len(manifest),'verified':True,'receipt':str(p/'receipt.json')}
(p.parent/'namespace-callback-oracle-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
