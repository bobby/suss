(ns suss-oracle.namespace-sharing
 (:require [cljs.analyzer :as ana] [cljs.env :as env] [cljs.js :as cljs]
           [cljs.tools.reader :as reader]))
(def snapshots (array))
(def windows (array))
(def numeric-hashes (array))
(def markers (array))
(def total (array 0))
(def stage (array "setup"))
(defn window [label f]
 (aset stage 0 label)
 (let [before (aget total 0) n (.-length numeric-hashes) result (f)]
  (.push windows #js {:stage label :hash-calls (- (aget total 0) before)
                     :selected-numeric-hashes (.slice numeric-hashes n)})
  result))
(defn present-path [value path]
 (if (empty? path) #js {:present true :value value}
  (if (and (map? value) (contains? value (first path)))
   (recur (get value (first path)) (rest path))
   #js {:present false})))
(defn capture [label macro-env live]
 ;; Store actual references. No identity comparison against freshly projected maps.
 (let [ast (ana/analyze macro-env 'watched)
       second-ast (ana/analyze macro-env 'watched)
       callable-ast (ana/analyze macro-env 'callable)
       local-init (get-in macro-env [:locals 'localfn :init])
       method (first (:methods local-init))
       paths [["env" []] ["ns" [:ns]] ["defs" [:ns :defs]]
              ["raw-watched" [:ns :defs 'watched]] ["raw-callable" [:ns :defs 'callable]]
              ["watched-meta" [:ns :defs 'watched :meta]]
              ["watched-audit" [:ns :defs 'watched :meta :audit]]
              ["callable-meta" [:ns :defs 'callable :meta]]
              ["callable-method-params" [:ns :defs 'callable :method-params]]
              ["callable-arglists" [:ns :defs 'callable :arglists]]
              ["callable-arglists-meta" [:ns :defs 'callable :arglists-meta]]
              ["locals" [:locals]] ["captured-local" [:locals 'captured]]
              ["captured-init" [:locals 'captured :init]]
              ["captured-info" [:locals 'captured :init :info]]
              ["localfn" [:locals 'localfn]] ["localfn-init" [:locals 'localfn :init]]
              ["localfn-methods" [:locals 'localfn :init :methods]]]
       values (array)]
  (doseq [[name path] paths]
   (.push values #js {:name name :slot (present-path macro-env path)}))
  (doseq [[name value] [["live-ns" live] ["live-defs" (:defs live)]
                        ["live-watched" (get-in live [:defs 'watched])]
                        ["live-callable" (get-in live [:defs 'callable])]
                        ["resolved-ast" ast] ["resolved-info" (:info ast)]
                        ["resolved-meta" (get-in ast [:info :meta])]
                        ["second-resolved-info" (:info second-ast)]
                        ["resolved-callable-info" (:info callable-ast)]
                        ["resolved-callable-method-params" (get-in callable-ast [:info :method-params])]]]
   (.push values #js {:name name :slot #js {:present true :value value}}))
  (doseq [[name key] [["localfn-first-method" nil] ["localfn-first-params" :params] ["localfn-first-body" :body]]]
   (.push values #js {:name name :slot (if (nil? method) #js {:present false}
                                      (if (nil? key) #js {:present true :value method}
                                          (present-path method [key])))}))
  (.push snapshots #js {:label label :env macro-env :live live :ast ast :values values})))
(defn shape-keys [m]
 (if (map? m) (into-array (map str (keys m))) nil))
(defn -main []
 (when (nil? cljs.core/NS_CACHE) (set! cljs.core/NS_CACHE (atom {})))
 (let [state (cljs/empty-state) cache cljs.core/NS_CACHE old-cache @cache
       original-hash cljs.core/hash target 'suss-oracle.sharing-target
       macro-ns 'suss-oracle.sharing-macros$macros
       analyze (fn [form]
        (binding [env/*compiler* state ana/*cljs-ns* target ana/*analyze-deps* false ana/*load-macros* false]
         (ana/analyze (assoc (ana/empty-env) :ns (ana/get-namespace target)) form)))
       observer (fn [form macro-env label]
        (.push markers #js {:event "macro-entry" :label label :hash-count (aget total 0)
                           :selected-numeric-count (.-length numeric-hashes)})
        (let [old (aget stage 0)]
         (aset stage 0 (str "observer/" label))
         (capture label macro-env (ana/get-namespace target))
         (aset stage 0 old))
        (.push markers #js {:event "macro-exit" :label label :hash-count (aget total 0)
                           :selected-numeric-count (.-length numeric-hashes)})
        17)]
  (try
   ;; Core cache setup is outside the hash-observed interval.
   (set! cljs.core/hash (fn [value]
     (aset total 0 (inc (aget total 0)))
     (when (and (number? value) (<= 101 value 109))
      (.push numeric-hashes #js {:stage (aget stage 0) :value value}))
     (original-hash value)))
   (window "analyze-ns" #(analyze (reader/read-string "(ns suss-oracle.sharing-target)")))
   (window "read-and-analyze-watched" #(analyze (reader/read-string
      "(def ^{:audit #{101 102 103 104 105 106 107 108 109}} watched 17)")))
   (window "read-and-analyze-callable" #(analyze (reader/read-string
      "(def ^{:doc \"callable-doc\"} callable (fn* ([x] x) ([x y] y)))")))
   (swap! state assoc-in [::ana/namespaces macro-ns]
     {:name macro-ns :defs {'observe {:name 'suss-oracle.sharing-macros$macros/observe
       :macro true :method-params [['&form '&env 'label]] :max-fixed-arity 3}}})
   (set! (.-cljs$lang$macro observer) true)
   (swap! cache assoc macro-ns (create-ns macro-ns #js {:observe observer}))
   (let [form (window "read-lexical-form" #(reader/read-string
       "(let* [captured watched localfn (fn* [v] v)] (suss-oracle.sharing-macros/observe \"same-1\") (suss-oracle.sharing-macros/observe \"same-2\") (def unrelated 23) (suss-oracle.sharing-macros/observe \"post-def-1\") (suss-oracle.sharing-macros/observe \"post-def-2\") nil)"))]
    (window "analyze-lexical-form" #(analyze form)))
   (window "analyze-new-env-after-def" #(analyze (reader/read-string
       "(suss-oracle.sharing-macros/observe \"new-env-after-def\")")))
   (finally (set! cljs.core/hash original-hash) (reset! cache old-cache)))
  ;; All projections/comparisons/printing below are outside observed hash windows.
  (assert (= 5 (.-length snapshots)))
  (let [ids (js/WeakMap.) next-id (array 0) rows (array)
        ref-view (fn [v]
         (cond (nil? v) #js {:kind "nil"}
               (or (= "object" (js* "typeof ~{}" v)) (= "function" (js* "typeof ~{}" v)))
               (let [id (if (.has ids v) (.get ids v)
                         (let [id (inc (aget next-id 0))] (aset next-id 0 id) (.set ids v id) id))]
                #js {:kind (cond (map? v) "map" (vector? v) "vector" (set? v) "set"
                                 (symbol? v) "symbol" (keyword? v) "keyword" :else "object") :id id})
               :else #js {:kind (js* "typeof ~{}" v) :value v}))]
   (doseq [s (array-seq snapshots)]
    (let [refs (array)]
     (doseq [entry (array-seq (.-values s))]
      (let [slot (.-slot entry)]
       (.push refs (if (.-present slot)
                     #js {:name (.-name entry) :present true :reference (ref-view (.-value slot))}
                     #js {:name (.-name entry) :present false}))))
     (.push rows #js {:label (.-label s) :references refs
                     :env-keys (shape-keys (.-env s))
                     :namespace-keys (shape-keys (:ns (.-env s)))
                     :watched-declaration-keys (shape-keys (get-in (.-env s) [:ns :defs 'watched]))
                     :callable-declaration-keys (shape-keys (get-in (.-env s) [:ns :defs 'callable]))
                     :locals-keys (shape-keys (:locals (.-env s)))})))
   (js/console.log (.stringify js/JSON #js {:pin "c4295f303100bbf5afac449242d30bca1126f1a1"
      :rows rows :hash-windows windows :macro-markers markers :selected-numeric-hashes numeric-hashes
      :limits "Reference IDs assigned to actual retained objects after analysis, not projected maps. Hash windows include observer lookups/resolution and reader work where labeled; selected-number traces are not a universal constructor event stream. No guest constructors replaced. Missing paths explicit. No Suss storage authority/cache acceptance."})))))
(set! *main-cli-fn* -main)
