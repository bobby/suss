from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,shutil,tarfile
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss');run=C/'native-field-plan-focused-v1';O=C/'native-field-plan-owned-proof-publication-v1';parent='3d546a92378eae94fabe22f3ac26cf25422926ce';base='96bc8d70ae447d0dba1e89a3c03e97ce0a0f84bb'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
assert not O.exists();rec=read(run/'receipt.json');assert rec['current'] is None and rec['final_changed']==[];assert rec['stages'][1]['counts']=={'pass':32,'fail':0,'ignore':0};freeze=read(run/'terminal.json');assert len(freeze)==4046 and freeze==read(run/'after-bootstrap.json');manifest=read(run/'source-manifest.json')
source=run/'tested-source';private={str(p.relative_to(source)):p.read_bytes() for p in source.rglob('*') if p.is_file()};assert len(private)==8
assert set(private)==set(manifest['files'])|{f'runtime/bootstrap/{ph}.{ex}' for ph in ['macro','runtime'] for ex in ['wasm','json']}
for f,b in private.items():assert sha(b)==freeze[f]
for f,h in manifest['files'].items():assert sha(private[f])==h
# Resolve all non-private inputs from immutable source Git, NOT an author view.
pin='c4295f303100bbf5afac449242d30bca1126f1a1';sub=Path('/home/bobby/Work/code/bobby/suss-m4-pr268-sparse-setter/clojurescript')
procs={False:subprocess.Popen(['git','-C',str(R),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE),True:subprocess.Popen(['git','-C',str(sub),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)}
for f,h in freeze.items():
 if f in private:b=private[f]
 else:
  issub=f.startswith('clojurescript/');q=procs[issub];name=f[len('clojurescript/'):] if issub else f;ref=pin if issub else base
  q.stdin.write((ref+':'+name+'\n').encode());q.stdin.flush();header=q.stdout.readline().split();assert len(header)==3 and header[1]==b'blob',(f,header)
  b=q.stdout.read(int(header[2]));assert q.stdout.read(1)==b'\n'
 assert sha(b)==h,f
for q in procs.values():q.stdin.close();q.wait()
O.mkdir();payload=O/'payload';payload.mkdir()
for label,src in [('tested-run',run),('combined-source-v1',C/'native-field-plan-combined-source-v1'),('combined-source-v2',C/'native-field-plan-combined-source-v2'),('initial-native-prefix-attempts',C/'native-prefix-source-v1')]:shutil.copytree(src,payload/label)
for name in ['native-field-plan-artifact-source-v2-independent-review.json','native-field-plan-focused-v1-independent-terminal-review.json','create-experiment-snapshot.py']:
 shutil.copy2(C/name,payload/name)
shutil.copy2(Path(__file__),payload/'packager.py')
# Copy all source-approval receipts retained with this immutable run, no current sources.
proof={'base':base,'snapshot_parent':parent,'checked':len(freeze),'mismatches':[],'pin':pin,'method':'original Git base/pinned dependency + eight exact tested-source private blobs; no author worktree files read'};(payload/'immutable-source-binding.json').write_text(json.dumps(proof,indent=2)+'\n')
report='''# Native field-plan owned artifact proof — rejected runtime load\n\nTested source is96bc8d70 plus the four frozen Rust files and their four normal BOOT artifacts. Snapshot parent3d546a9 retains the previous diagnostic backup; this snapshot adds only the tested native proof, BOOT and handoff/evidence. Current borrowed/view prototypes are different unexecuted source and excluded.\n\nNormal bootstrap PASS; exact32 unique native tests PASS:24 existing+3 prefix+5 field artifact. Earlier27 prefix tests overlap these32 and are not added. V1 compile E0277 and initial missing-module-path attempt remain separate failed setup attempts with no execution credit.\n\nBoth Runtime and Macro phases:615 actual completed shipped owners,1577 fields,10041 canonical keys,619690 encoded bytes. Original BYTE planner is the oracle: full row/root/key IDs, independent cold rebuild, warm traversal, and encode/decode comparisons passed. All spans/metadata remain on the actual owner-bound borrowed Form. Malformed shape/provenance/occurrence, collision, copied/reanalyzed/restored owners and native failure/retry negatives passed.\n\nIdentical actual per-phase native proxy costs:\n\n|Stage|Units|\n|---|---:|\n|Original cold plan+clear|14,219,065|\n|Original warm plan+clear|11,843,439|\n|Snapshot storage|5,948,879|\n|Encode|6,056,408|\n|Owned decode+validate+storage|28,464,962|\n|Decode backing (subset, not additive)|18,914,698|\n|Exact correspondence replan|15,116,808|\n|Bind|291,004|\n|Lookup all fields|77,016|\n|Template row reads|325,415|\n|Reference/flat cleanup|382,233|\n\nDecode+correspondence+bind alone43,872,774. Reject this owned per-request runtime load. No Graph field admission or runtime prefix is enabled. A future checked borrowed view would require separate source/cost/effect proof; no measured saving is inferred here.\n\nIdentity/input setup2,910,729 and comparison assertions2,575,537 are separately reported; stages are not indiscriminately additive. Catalog discovery, fixture clones/assertions and early-error/recursive last-owner cleanup exclusions remain explicit. Injected StopFuel/Irq are native surrogates, not Session fuel/epoch observations. This is a native-field proxy, not completed caller &env transport, default acceptance, whole-request savings, full baseline or CI result.\n\nCommands and exact selection are retained in tested-run/driver.py, selection.json and raw logs: normal suss-bootstrap first, then cargo test --locked -p suss-compile --lib portable_macro_graph::raw_keys:: -- --test-threads=1 --nocapture. All4046postbootstrap inputs remained unchanged.\n'''
(O/'REPORT.md').write_text(report)
handoff='''\n\nNative field-plan owned proof (diagnostic experiment): normal bootstrap then cargo test --locked -p suss-compile --lib portable_macro_graph::raw_keys:: -- --test-threads=1 --nocapture:32 uniquePASS (24old+3prefix+5artifact), not32+27. Each source phase615owners/1577fields/10041keys; exact originalBYTE rows/IDs/codec/binding negatives passed. Owned decode28,464,962 +complete correspondence15,116,808 +bind291,004 perphase rejects per-request owned runtime loading. No Graph prefix/admission/guest acceptance enabled. V1E0277 and initial missing-module-path attempt retained as failed setup/no execution credit. Later borrowed/view code is DIFFERENT/unexecuted and excluded from this backup. Source input maps4046unchanged; only captured fourRust/fourBOOT included.\n'''
paths={}
for f,b in private.items():paths[f]={'payload':'tested-run/tested-source/'+f,'sha256':sha(b)}
f='docs/roadmap/handoff.md';b=subprocess.check_output(['git','-C',str(R),'show',parent+':'+f])+handoff.encode();dst=payload/'snapshot'/f;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);paths[f]={'payload':str(dst.relative_to(payload)),'sha256':sha(b)}
files={str(f.relative_to(payload)):sha(f.read_bytes()) for f in sorted(payload.rglob('*')) if f.is_file()};(payload/'MANIFEST.json').write_text(json.dumps(files,indent=2)+'\n');archive=O/'m4-native-field-plan-owned-proof-2026-10-17.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(payload.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(payload)),recursive=False)
result={'archive':str(archive),'sha256':sha(archive.read_bytes()),'report_sha256':sha((O/'REPORT.md').read_bytes()),'members':len(files)+1,'manifested_payloads':len(files),'snapshot_parent':parent,'snapshot_paths':paths,'binding':proof,'verdict':'32nativePASS; owned per-request loading rejected on cost; no runtime acceptance claim'};(O/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='snapshot_paths'},indent=2))
