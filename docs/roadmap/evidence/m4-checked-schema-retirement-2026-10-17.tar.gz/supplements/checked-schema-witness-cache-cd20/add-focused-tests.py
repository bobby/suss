from pathlib import Path
p=Path('/home/bobby/.cache/suss-m4-work/checked-schema-witness-cache-cd20/after/crates/suss-compile/src/portable_session/constructor_inputs.rs');s=p.read_text()
pos=s.index('impl Session {\n    fn prepare_schema_witness')
s=s[:pos]+'''// Test-only stage seam: cancellation is consumed by the REAL following
// operation. It grants no authority and replaces no validation/publication.
#[cfg(test)]
thread_local! {
    static SCHEMA_CANCEL_STAGE: std::cell::Cell<Option<&'static str>> = const { std::cell::Cell::new(None) };
}
#[cfg(test)]
fn cancel_schema_stage(session: &Session, stage: &'static str) {
    SCHEMA_CANCEL_STAGE.with(|armed| {
        if armed.get() == Some(stage) {
            armed.set(None);
            session.host_work_interrupt().store(true, std::sync::atomic::Ordering::SeqCst);
        }
    });
}

'''+s[pos:]
s=s.replace('''        let (schema_storage, schema_publication) = self.prepare_schema_witness(&schema)?;
        let names''','''        let (schema_storage, schema_publication) = self.prepare_schema_witness(&schema)?;
        #[cfg(test)] cancel_schema_stage(self, "names");
        let names''')
s=s.replace('''        let value = self.data_construct_from_plan(&plan, arguments)?;
        let field_storage''','''        #[cfg(test)] cancel_schema_stage(self, "factory");
        let value = self.data_construct_from_plan(&plan, arguments)?;
        let field_storage''')
s=s.replace('''        inputs.memo_watch = self.watch_constructor_memo(''','''        #[cfg(test)] cancel_schema_stage(self, "watch");
        inputs.memo_watch = self.watch_constructor_memo(''')
pos=s.index('    #[test]\n    fn private_constructor_route')
tests='''    fn schema_test_session(phase: Phase) -> Session {
        match phase { Phase::Runtime => Session::new_repl().unwrap(), Phase::Macro => Session::new_macro().unwrap() }
    }
    fn schema_test_array(session: &mut Session, values: &[&SessionValue]) -> SessionValue {
        session.budget().unwrap();
        let mut scope = RootScope::new(&mut session.store);
        let mut output = [Val::null_any_ref()];
        session.runtime.get_func(&mut scope, "args-new").unwrap()
            .call(&mut scope, &[Val::I32(values.len() as i32)], &mut output).unwrap();
        let array = output[0].unwrap_anyref().unwrap().as_array(&scope).unwrap().unwrap();
        for (i, value) in values.iter().enumerate() {
            array.set(&mut scope, i as u32, Val::AnyRef(Some(value.value.to_rooted(&mut scope)))).unwrap();
        }
        super::super::own(&mut scope, output[0].clone(), session.identity, &session.handles).unwrap()
    }
    fn schema_test_child(session: &mut Session, schema: &SessionValue, index: u32) -> SessionValue {
        let mut scope = RootScope::new(&mut session.store);
        let array = schema.value.to_rooted(&mut scope).as_array(&scope).unwrap().unwrap();
        let value = array.get(&mut scope, index).unwrap();
        super::super::own(&mut scope, value, session.identity, &session.handles).unwrap()
    }
    fn schema_test_prepare(session: &mut Session, schema: &SessionValue) -> (
        std::sync::Arc<StorageSnapshot>, Option<SchemaWitnessPublication>,
    ) {
        let _request = session.operation_budget_scope().unwrap();
        session.prepare_schema_witness(schema).unwrap()
    }

    #[test]
    fn checked_schema_cache_strict_hits_deep_mutation_distinct_roots_and_gc() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = schema_test_session(phase);
            session.eval("(deftype CheckedSchemaProbe [alpha beta])").unwrap();
            let class = session.eval("CheckedSchemaProbe").unwrap();
            let input = session.eval("17").unwrap();
            let (receiver, prior) = session.data_construct_with_inputs(&class, &[&input, &input]).unwrap();
            let prior = prior.unwrap();
            let schema = prior.schema.clone();
            session.collect().unwrap();
            let (hit, pending) = schema_test_prepare(&mut session, &schema);
            assert!(pending.is_none());
            assert!(std::sync::Arc::ptr_eq(&hit, &prior.schema_storage));
            // Same child references and content, genuinely different array root.
            let a = schema_test_child(&mut session, &schema, 0);
            let b = schema_test_child(&mut session, &schema, 1);
            let equal = schema_test_array(&mut session, &[&a, &b]);
            assert!(!same(&mut session, &schema, &equal).unwrap());
            let (distinct, pending) = schema_test_prepare(&mut session, &equal);
            assert!(pending.is_some());
            assert!(!std::sync::Arc::ptr_eq(&distinct, &hit));
            drop(pending); // private preparation cannot publish on its own
            // Mutate a reachable UTF16 child; root identity remains the same.
            session.inspect(&a, |mut store, value| {
                value.unwrap_anyref().unwrap().as_array(&store)?.unwrap().set(&mut store, 0, Val::I32(98))
            }).unwrap();
            assert!(!prior.matches(&mut session, &receiver).unwrap());
            let (fresh, pending) = schema_test_prepare(&mut session, &schema);
            assert!(!std::sync::Arc::ptr_eq(&fresh, &hit));
            assert!(!session.storage_matches(&schema, &hit).unwrap());
            assert!(session.storage_matches(&schema, &fresh).unwrap());
            pending.unwrap().publish(&mut session.schema_witness_cache);
            session.collect().unwrap();
            let (again, pending) = schema_test_prepare(&mut session, &schema);
            assert!(pending.is_none());
            assert!(std::sync::Arc::ptr_eq(&again, &fresh));
            assert!(!prior.matches(&mut session, &receiver).unwrap());
            // Restore original data; an old fact is not permanently tainted.
            session.inspect(&a, |mut store, value| {
                value.unwrap_anyref().unwrap().as_array(&store)?.unwrap().set(&mut store, 0, Val::I32(97))
            }).unwrap();
            assert!(prior.matches(&mut session, &receiver).unwrap());
        }
    }

    #[test]
    fn checked_schema_cache_fuel_irq_staging_rollback_and_retry() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = schema_test_session(phase);
            let name = session.data_scalar(&crate::portable::hir::Literal::String(vec![97])).unwrap();
            let schema = schema_test_array(&mut session, &[&name]);
            session.schema_witness_cache = SchemaWitnessCache::default();
            let capture_cost = {
                let _request = session.operation_budget_scope().unwrap();
                let before = session.store.get_fuel().unwrap();
                drop(session.capture_storage(&schema).unwrap());
                before - session.store.get_fuel().unwrap()
            };
            let owner = (std::mem::size_of::<StorageSnapshot>() + 2*std::mem::size_of::<usize>()) as u64;
            let growth = (4*std::mem::size_of::<SchemaWitnessEntry>()) as u64;
            // Actual cold path: lookup entry, original capture, owner, Vec, retains.
            for allowance in [0, 1, 1+capture_cost, 1+capture_cost+owner,
                1+capture_cost+owner+growth, 1+capture_cost+owner+growth+2] {
                let handles = session.stats().external_value_handles;
                let _request = session.operation_budget_scope().unwrap();
                session.store.set_fuel(allowance).unwrap();
                let error = session.prepare_schema_witness(&schema).err().expect("incomplete staging budget");
                assert!(matches!(error, SessionError::Trap(ref e) if e.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)));
                assert!(session.schema_witness_cache.entries.is_empty());
                assert_eq!(session.stats().external_value_handles, handles);
            }
            let (old, pending) = schema_test_prepare(&mut session, &schema);
            pending.unwrap().publish(&mut session.schema_witness_cache);
            let handles = session.stats().external_value_handles;
            for allowance in [0, 1, 2] {
                let _request = session.operation_budget_scope().unwrap();
                session.store.set_fuel(allowance).unwrap();
                assert!(session.prepare_schema_witness(&schema).is_err());
                assert!(std::sync::Arc::ptr_eq(&session.schema_witness_cache.entries[0].snapshot, &old));
                assert_eq!(session.stats().external_value_handles, handles);
            }
            {
                let _request = session.operation_budget_scope().unwrap();
                session.host_work_interrupt().store(true, std::sync::atomic::Ordering::SeqCst);
                let error = session.prepare_schema_witness(&schema).err().unwrap();
                assert!(error.is_interrupt());
                assert!(std::sync::Arc::ptr_eq(&session.schema_witness_cache.entries[0].snapshot, &old));
            }
            let (retry, pending) = schema_test_prepare(&mut session, &schema);
            assert!(pending.is_none());
            assert!(std::sync::Arc::ptr_eq(&old, &retry));
        }
    }

    #[test]
    fn checked_schema_cache_actual_constructor_stage_failures_do_not_publish() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = schema_test_session(phase);
            let class = session.eval("suss.core/List").unwrap();
            let nil = session.eval("nil").unwrap();
            let stages: &[&str] = if phase == Phase::Macro { &["names", "factory", "watch"] } else { &["names", "factory"] };
            for &stage in stages {
                session.schema_witness_cache = SchemaWitnessCache::default();
                SCHEMA_CANCEL_STAGE.with(|armed| armed.set(Some(stage)));
                let error = session.data_construct_with_inputs(&class, &[&nil, &nil, &nil, &nil, &nil]).unwrap_err();
                SCHEMA_CANCEL_STAGE.with(|armed| assert!(armed.get().is_none(), "actual requested stage reached"));
                assert!(error.is_interrupt(), "{stage}: {error:?}");
                assert!(session.schema_witness_cache.entries.is_empty(), "{stage}");
                let (value, fact) = session.data_construct_with_inputs(&class, &[&nil, &nil, &nil, &nil, &nil]).unwrap();
                let fact = fact.unwrap();
                assert!(fact.matches(&mut session, &value).unwrap());
                if phase == Phase::Macro { assert!(fact.memo_watch.is_some()); }
                assert!(session.schema_witness_cache.entries.iter().any(|entry| std::sync::Arc::ptr_eq(&entry.snapshot, &fact.schema_storage)));
            }
        }
    }

    #[test]
    fn checked_schema_cache_seventeen_roots_evict_without_rejecting_and_reset_is_foreign() {
        for phase in [Phase::Runtime, Phase::Macro] {
            let mut session = schema_test_session(phase);
            let name = session.data_scalar(&crate::portable::hir::Literal::String(vec![97])).unwrap();
            let schemas: Vec<_> = (0..17).map(|_| schema_test_array(&mut session, &[&name])).collect();
            let mut witnesses = Vec::new();
            session.schema_witness_cache = SchemaWitnessCache::default();
            for schema in &schemas {
                let (witness, pending) = schema_test_prepare(&mut session, schema);
                pending.unwrap().publish(&mut session.schema_witness_cache);
                assert!(session.schema_witness_cache.entries.len() <= SCHEMA_WITNESS_LIMIT);
                witnesses.push(witness);
            }
            assert_eq!(session.schema_witness_cache.entries.len(), 16);
            session.collect().unwrap();
            for (schema, witness) in schemas.iter().zip(&witnesses) {
                assert!(session.storage_matches(schema, witness).unwrap());
            }
            let (recaptured, pending) = schema_test_prepare(&mut session, &schemas[0]);
            assert!(pending.is_some(), "eviction is a cache miss, never rejection");
            assert!(!std::sync::Arc::ptr_eq(&recaptured, &witnesses[0]));
            pending.unwrap().publish(&mut session.schema_witness_cache);
            let mut foreign = schema_test_session(phase);
            let foreign_schema = schema_test_array(&mut foreign, &[]);
            {
                let _request = session.operation_budget_scope().unwrap();
                assert!(matches!(session.prepare_schema_witness(&foreign_schema), Err(SessionError::ForeignValue)));
            }
            session.reset().unwrap();
            assert!(session.schema_witness_cache.entries.is_empty());
            {
                let _request = session.operation_budget_scope().unwrap();
                assert!(matches!(session.prepare_schema_witness(&schemas[0]), Err(SessionError::ForeignValue)));
            }
        }
    }

'''
s=s[:pos]+tests+s[pos:]
# Exact old cleanup assertions remain; release intentional cache roots first.
s=s.replace('''            let handles = session.stats().external_value_handles;
            {''','''            session.schema_witness_cache = SchemaWitnessCache::default();
            let handles = session.stats().external_value_handles;
            {''')
s=s.replace('''            assert_eq!(session.stats().external_value_handles, handles);
            // Sample failure cleanup''','''            // Cache retention is intentional; release its owners before the
            // existing exact no-leak assertion (the new tests check retention).
            session.schema_witness_cache = SchemaWitnessCache::default();
            assert_eq!(session.stats().external_value_handles, handles);
            // Sample failure cleanup''')
s=s.replace('''                assert_eq!(session.stats().external_value_handles, handles);
                drop(request);''','''                session.schema_witness_cache = SchemaWitnessCache::default();
                assert_eq!(session.stats().external_value_handles, handles);
                drop(request);''')
p.write_text(s)
