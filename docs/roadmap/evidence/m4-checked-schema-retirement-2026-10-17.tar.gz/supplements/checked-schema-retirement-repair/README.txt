Cache-only additive repair against exact current candidate plus E0499 test fix;
manifest identifies every before/after byte. No actual-tree edits or producers.

Two-file scope, no snapshot layout field/Drop implementation. Counting method
charges8 work before root bookkeeping and8 before each node contents/length
read/checked arithmetic. Checked release bound includes snapshot payload+Arc
header, each live Node payload (root/type/control), each initialized Atom payload
(worst-case opaque root/variant release), and nodes/atom-buffer release controls.
No scan/charge for unused Vec capacity. This conservative owned-bytes-as-work
bound is prepaid even when an old ConstructorInputs shares the witness. Cache
entry schema-root/Arc release is separately prepaid. Temporary retained Arc is
prepaid2 for retain/drop and is dropped before factory; cache still owns old Arc.
Any count overflow/IRQ/fuel failure occurs while all cache state is unchanged.
No fallible Drop and no universal cleanup/accounting claim: general RAII failure
cleanup and Session teardown remain the previously disclosed partial#252 gap.

New native test covers both phases and both actual last owner and a genuine
older ConstructorInputs retaining schema_storage. Fill16, target17th schema,
measure preparation privately, fail within retirement bulk prepayment and final
staging, assert same vector/entry/witness/next/handles, cancel counting walk,
retry and commit; old fact still validates until dropped, last owner then retires.
No manual publish substitute for the separately existing actual watch-failure
test. New test UNCOMPILED/UNEXECUTED; syntax parse+patch applicability only.

Stopped22550 bootstrap wrote runtime.json/runtime.wasm only and is NOT complete.
Fresh bootstrap regeneration after approved repair is required; no partial output
is supplied by this patch. Main controls compile/focused execution and target.
