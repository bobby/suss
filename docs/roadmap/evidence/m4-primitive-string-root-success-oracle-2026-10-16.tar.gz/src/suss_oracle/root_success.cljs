(ns suss-oracle.root-success)
(defn -main []
 (let [root (.-charCodeAt "AB")
       old (js/Object.getOwnPropertyDescriptor root "auditMutationField")
       rows (array)]
  (try
   (let [observed (do
(def root-success-events [])
(def root-success-method (.-charCodeAt "AB"))
(let [selected (.charCodeAt
                 (do (set! root-success-events (conj root-success-events 1)) "AB")
                 (do (set! root-success-events (conj root-success-events 2))
                     (set! (.-auditMutationField root-success-method) 17)
                     (set! root-success-events (conj root-success-events 3))
                     1))]
  [selected
   (.-auditMutationField root-success-method)
   (identical? root-success-method (.-charCodeAt "AB"))
   (.call root-success-method "AB"
     (do (set! root-success-events (conj root-success-events 4)) 1))
   root-success-events])

   )
    captured (array (nth observed 0) (nth observed 1) (nth observed 2)
                    (nth observed 3) (to-array (nth observed 4)))]
    (.push rows captured))
   (finally
    (if (some? old) (js/Object.defineProperty root "auditMutationField" old)
        (js/Reflect.deleteProperty root "auditMutationField"))))
  (let [now (js/Object.getOwnPropertyDescriptor root "auditMutationField")
        restored (if (nil? old) (nil? now)
                   (and (identical? (.-value old) (.-value now))
                        (= (.-writable old) (.-writable now))
                        (= (.-enumerable old) (.-enumerable now))
                        (= (.-configurable old) (.-configurable now))
                        (identical? (.-get old) (.-get now))
                        (identical? (.-set old) (.-set now))))]
   (assert restored)
   (assert (identical? root (.-charCodeAt "AB")))
   (js/console.log (.stringify js/JSON #js {:pin "c4295f303100bbf5afac449242d30bca1126f1a1"
      :guest-sha256 "33fde62f0f7eea4377c1b642afbb2d7370a0fb961b11989a6dacc299c17e6f53"
      :rows rows :restored restored :original-own-field-present (some? old)})))))
(set! *main-cli-fn* -main)
