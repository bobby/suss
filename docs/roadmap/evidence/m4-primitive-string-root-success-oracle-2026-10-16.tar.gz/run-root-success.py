import pathlib,hashlib,json,subprocess,time,os
p=pathlib.Path(__file__).parent
paths=[p/'cicero-root-success-guest.cljs',p/'src/suss_oracle/root_success.cljs']
for label in ['root-success-run1','root-success-run2']:
 before={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in paths}
 cmd=['bash',str(p/'run-root-success.sh')]
 (p/'root-success-current.json').write_text(json.dumps({'current':label,'pid':os.getpid(),'command':cmd,'source_hashes':before},indent=2)+'\n')
 start=time.time()
 with (p/(label+'.log')).open('wb') as log:code=subprocess.call(cmd,stdout=log,stderr=subprocess.STDOUT)
 after={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in paths}
 r={'exit':code,'seconds':time.time()-start,'source_hashes':before,'unchanged':before==after,'command':cmd}
 (p/(label+'-receipt.json')).write_text(json.dumps(r,indent=2)+'\n');print(label,json.dumps(r),flush=True)
 if code:break
 lines=(p/(label+'.log')).read_text().splitlines();x=json.loads(next(s for s in reversed(lines) if s.startswith('{"pin"')))
 (p/(label+'-observations.json')).write_text(json.dumps(x,indent=2)+'\n')
(p/'root-success-current.json').write_text(json.dumps({'current':None,'last':label,'exit':code},indent=2)+'\n')
