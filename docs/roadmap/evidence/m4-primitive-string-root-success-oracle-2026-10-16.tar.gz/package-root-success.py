import pathlib,json,hashlib,subprocess,tarfile,io
p=pathlib.Path(__file__).parent
xs=[json.loads((p/f'root-success-run{i}-observations.json').read_text()) for i in [1,2]]
assert xs[0]==xs[1];x=xs[0];assert x['rows']==[[66,17,True,66,[1,2,3,4]]] and x['restored'] and not x['original-own-field-present']
g=(p/'cicero-root-success-guest.cljs').read_bytes();assert hashlib.sha256(g).hexdigest()=='33fde62f0f7eea4377c1b642afbb2d7370a0fb961b11989a6dacc299c17e6f53'
wrapper=(p/'src/suss_oracle/root_success.cljs').read_bytes();assert wrapper.count(g)==1
pin=pathlib.Path('/home/bobby/Work/code/bobby/suss/clojurescript');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=pin,text=True).strip();clean=not subprocess.check_output(['git','status','--porcelain'],cwd=pin,text=True);assert head==x['pin'] and clean
receipt={'pin':head,'pin_clean':clean,'guest_sha256':x['guest-sha256'],'guest_original_path':'/home/bobby/.cache/suss-m4-work/primitive-string-root-success/guest.cljs','exact_guest_bytes_embedded_once':True,'runs':[json.loads((p/f'root-success-run{i}-receipt.json').read_text()) for i in [1,2]],'ordered_observations_identical':True,'observed_row':x['rows'][0],'cleanup_verified':x['restored'],'original_own_field_present':x['original-own-field-present'],'failed_attempts':[],'limits':'One exact guest body, two pinned CLJS/Node runs only. Descriptor capture, native-array observation and cleanup occur outside unchanged guest bytes. No Suss/native candidate execution or acceptance claim. Earlier ordinary-root draft unused; original mutation and numeric/error oracle traces unchanged.'}
(p/'root-success-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(p/'root-success-README.txt').write_text('Exact Cicero ordinary root-field fixture, pinned CLJS reference only.\nGuest SHA25633fde62f0f7eea4377c1b642afbb2d7370a0fb961b11989a6dacc299c17e6f53. Source copied verbatim and embedded once without formatting/substitution. Wrapper captures original auditMutationField descriptor before guest, snapshots final values to native JS arrays before printing, restores original descriptor or deletes originally absent property in finally, and verifies cleanup/root identity. Guest exceptions escape; no blanket catch success.\nTwo ordered stable rows: [66,17,true,66,[1,2,3,4]], exits0. One successful field write during index evaluation; exact guest readback, shared root identity and saved .call preserved. No broader fixture, Suss build or production edit. No failed attempts; unused earlier draft not executed. Cached CLI/JRE/Maven prerequisites external, not an independent toolchain archive. Earlier oracle traces not overwritten.\n')
names=['deps.edn','run-root-success.sh','run-root-success.py','package-root-success.py','cicero-root-success-guest.cljs','src/suss_oracle/root_success.cljs','root-success-current.json','root-success-receipt.json','root-success-README.txt']
names += [f'root-success-run{i}{suffix}' for i in [1,2] for suffix in ['.log','-receipt.json','-observations.json']]
names += ['out/root-success.js']+[str(f.relative_to(p)) for f in (p/'out/root-success-cljs').rglob('*') if f.is_file()]+[str(f.relative_to(p)) for f in (p/'upstream').iterdir() if f.is_file()]
files=sorted(set(names));m={'schema':1,'files':{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in files}}
out=p.parent/'m4-primitive-string-root-success-oracle-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n in files:t.add(p/n,arcname=n)
 data=(json.dumps(m,indent=2)+'\n').encode();i=tarfile.TarInfo('MANIFEST.json');i.size=len(data);t.addfile(i,io.BytesIO(data))
with tarfile.open(out,'r:gz') as t:
 assert len(t.getmembers())==len(files)+1
 for n,h in m['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
print(json.dumps({'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(files),'receipt':receipt},indent=2))
