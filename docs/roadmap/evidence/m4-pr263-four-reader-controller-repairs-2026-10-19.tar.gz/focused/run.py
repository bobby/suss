from pathlib import Path
import json,subprocess,os,time,hashlib
out=Path(__file__).resolve().parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-primitive-string-access')
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',TMPDIR='/home/bobby/.cache/suss-m4-work/workspace-tmp-65e9718-ccpsnhdq')
selectors=[('native-ownership','portable::resolve::completed_values::'),('binding-memo','portable_macro_graph::completed_bindings::'),('ordinary-controls','portable_macro_graph::completed_value_control::'),('reader-properties','portable_macro_graph::completed_type_values::reader_property_value_tests::')]
results=[]
for label,selector in selectors:
 cmd=['cargo','test','-p','suss-compile','--locked','--lib',selector,'--','--nocapture','--test-threads=2']
 start=time.monotonic()
 with (out/(label+'.log')).open('x') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 result={'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'log_sha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()}
 results.append(result);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True);print((out/(label+'.log')).read_text()[-3500:],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
