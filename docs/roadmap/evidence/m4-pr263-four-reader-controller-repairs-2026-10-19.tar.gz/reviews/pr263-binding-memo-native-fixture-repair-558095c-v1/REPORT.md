# Memo native fixture repairs — source-only author candidate

Base558095c578105f5524c5b5435151395737a99ad0. One cfg(test)-only file; production prefix exact. No Cargo/rustc/bootstrap/VM or shared source mutation. Cache patch replay succeeds; no typecheck/runtime credit or independent author approval.

## Actual failures and causes

The retained original binding-memo.log has3PASS/2FAIL. `NoExpansion` does not expand public `(ns foreign)`; native prepare therefore fails before foreign-owner assertions. Use the existing genuine shipped Macro environment, then Environment::enter_namespace(Macro,"foreign") before analyzing unchanged `(def subject17)` (actual source includes separating spaces). Assert real foreign Global namespace/phase/difference. Existing foreign Global and independent foreign owner rejection assertions remain unchanged. This is fixture setup, not a production memo repair.

Session::consume_host_work (portable_session.rs1233+) consumes cancellation and sets fuel0 deliberately; clearing its flag cannot recover the same active operation. Keep that boundary and explicitly require typed OutOfFuel on same-scope retry. Drop the request guard and establish a new ordinary outer scope, which installs the already-configured unchanged allowance through begin_operation_budget/budget. Retry the same graph and same retained entry; do not manually set Store fuel, nest a refill, raise a cap, split an actual acceptance fixture or alter production behavior. Existing hit-1 fuel failure and following normal retry remain unchanged.

## Preserved scope

One helper namespace argument and two targeted fixture call/control edits; all original source/owner/revision poison, equal-native-copy, weak initializer, foreign-owner and foreign-Global checks stay. Sampled zero/1/cold-1 and hit-1 cuts unchanged. Current source/BOOT source fingerprint will change from cfg bytes: main must bind/regenerate as appropriate before Session fixture execution. Actual failed log remains immutable; no new PASS claim.

## Main-owned focused replay after review and correct tuple

`cargo test -p suss-compile --locked --lib portable_macro_graph::completed_bindings::tests:: -- --test-threads=1 --nocapture`

All five tests, including three earlier passes and two repaired fixtures. No new baseline or allowance requested. Original ordinary controls may run first per main scheduling; do not apply during a live producer.
