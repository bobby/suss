# Reader-property quoted-prefix fixture correction

One cfg-test-only wrapper in prepare(source,...). Keep the SAME original quoted arglists source, entire case table, all assertions, allowances, SourceOrigin and NoExpansion. No production change.

read_forms returns Kind::Prefix for the original quote syntax; native hir::prepare_with_origin is a later analyzer stage and does not perform the reader-selection stage itself. Production prepare_fragment/modules routes first call forms::resolve_conditionals[_metered]. That standard selector recursively visits metadata and converts Kind::Prefix into a List [operator,target] while retaining spans/metadata. Existing ordinary full14 control uses exactly this read_forms→resolve_conditionals sequence and actually passes. This fixture omitted it; Graph rejects unselected reader prefixes rather than granting transport authority.

The repair uses that real existing stage instead of removing the quoted case, accepting unsupported Prefix or rewriting its source. Exact inverse restores the complete file. SourceOrigin still sees the original source text; standard source provenance selection/fallback remains responsible for correspondence. No new provenance or fake native binding is introduced.

Actual prior reader-properties result remains3PASS2FAIL. This addresses only the resolved-prefix setup error at569. The separate healthy DATA decline at616 is Lagrange-owned and unchanged. Other downstream outcomes remain unknown. Cache applycheck/syntax parse PASS; no typecheck/BOOT/VM/test execution. Root owns composition, normal source identity and replay after the current producer drains.
