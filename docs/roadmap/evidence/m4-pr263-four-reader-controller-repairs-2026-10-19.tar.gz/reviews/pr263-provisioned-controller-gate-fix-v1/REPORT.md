# Provisioned source-controller eligibility gate

SOURCE FINDING: Session::provision_core installs the genuine private canonical methods/seeds and then sets bootstrap_core=true (portable_session.rs538..564). The flag denotes installed core, also used by reset to decide reprovisioning; it is not a currently-compiling-bootstrap marker. source_controller_ready incorrectly required its negation. Therefore normal new_macro/new_repl sessions fail the activated first-use eligibility gate before native admission.

The one-line production correction requires bootstrap_core AND both original private registries. Fee6, registry creation/provenance, all physical/memo/source checks, callback ordering and cache publication remain unchanged. Bare Session::new remains ineligible. No authority is minted by readiness.

One focused regression obtains actual new_repl/new_macro provisioning and checks readiness, then separately removes and restores each exact original private registry and verifies denial/recovery. It never sets bootstrap_core or fabricates a registry. This is a private test-module access only, not a production accessor. It does not claim exhaustive fuel/IRQ behavior or downstream source admission success.

Observed controller callback-order tests fail0/3 at initial whole-controller decline, before a controlled callback trace exists. First-use-data9 failures likewise report initial decline; the provisioning inversion explains that early route. The environment-producer test calls admit_reader_controller directly and bypasses this readiness method: its separate admission decline is NOT fixed or explained by this patch. Logical witness currently rejects Symbol map keys and strict private admission rejects ReaderSelector::Value; further diagnosis must preserve those distinct mechanisms. No callback-order mismatch has been observed.

Peer requested: Lagrange independently review this patch before application; overlaps DATA616 early gate diagnosis only. All production and tests are UNEXECUTED. No Cargo, VM, shared source/index/ref change.
