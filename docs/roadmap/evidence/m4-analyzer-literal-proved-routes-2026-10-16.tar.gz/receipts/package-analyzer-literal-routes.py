from pathlib import Path
import hashlib,json,subprocess,tarfile,io
r=Path('/home/bobby/Work/code/bobby/suss-m4-analyzer-literal-key-memos');c=Path('/home/bobby/.cache/suss-m4-work');s=json.loads((c/'analyzer-literal-routes-result.json').read_text());assert s['current'] is None and s['source_unchanged'];payload={}
for f,h in s['freeze'].items():
 b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+f]=b
extra=['Cargo.toml','Cargo.lock','crates/suss-core/Cargo.toml','crates/suss-reader/Cargo.toml','crates/suss-compile/Cargo.toml','crates/suss-cli/Cargo.toml','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','runtime/core-import/LICENSE','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json','vendor/wasi/wasi-wit-0.3.1/cli/cli.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit']
for f in extra:assert (r/f).is_file();payload['snapshot/'+f]=(r/f).read_bytes()
paths=[f for f in s['freeze'] if f=='crates/suss-compile/build.rs' or any(f.startswith('crates/'+n+'/src/') and f.endswith(('.rs','.sus')) for n in ['suss-core','suss-reader','suss-compile'])]+extra[:5]+extra[9:];h=hashlib.sha256()
for f in sorted(set(paths),key=lambda p:tuple(p.split('/'))):
 b=payload['snapshot/'+f];n=f.encode();h.update(len(n).to_bytes(8,'little'));h.update(n);h.update(len(b).to_bytes(8,'little'));h.update(b)
checks={}
for phase in ['macro','runtime']:
 m=json.loads(payload[f'snapshot/runtime/bootstrap/{phase}.json']);checks[phase]={'compiler':h.hexdigest()==m['compiler_source_sha256'],'core':hashlib.sha256(payload['snapshot/runtime/core-import/suss/core.sus']).hexdigest()==m['source_sha256'],'dependencies':hashlib.sha256(payload['snapshot/runtime/core-import/manifest.json']).hexdigest()==m['dependency_graph_sha256'],'wasm':hashlib.sha256(payload[f'snapshot/runtime/bootstrap/{phase}.wasm']).hexdigest()==m['wasm_sha256']}
assert all(all(v.values()) for v in checks.values()),checks
for p in c.glob('analyzer-literal-routes-*'):
 if p.is_file() and p.name!='analyzer-literal-routes-package-result.json':payload['receipts/'+p.name]=p.read_bytes()
for name in ['extend-analyzer-literal-routes.py','run-analyzer-literal-routes.py','package-analyzer-literal-routes.py']:payload['receipts/'+name]=(c/name).read_bytes()
f='crates/suss-compile/src/portable/hir/quotes.rs';assert subprocess.check_output(['git','show','ec0eea2:'+f],cwd=r)==(r/f).read_bytes()
f='crates/suss-compile/src/portable_macro_data.rs';assert subprocess.check_output(['git','show','ec0eea2:'+f],cwd=r)==(r/f).read_bytes()
payload['change.patch']=subprocess.check_output(['git','diff','ec0eea2','--','crates/suss-compile/src/portable_macro_graph.rs','crates/suss-compile/src/portable_macro_graph/analyzer_literal_tests.rs','crates/suss-cli/tests/compiled_macro_analyzer_literal_memos.rs'],cwd=r)
pin=Path('/home/bobby/Work/code/bobby/suss/clojurescript');assert subprocess.check_output(['git','-C',str(pin),'rev-parse','HEAD'],text=True).strip()=='c4295f303100bbf5afac449242d30bca1126f1a1'
a=pin/'src/main/clojure/cljs/analyzer.cljc';lines=a.read_text().splitlines(keepends=True);excerpt='Pinned analyzer.cljc SHA256 '+hashlib.sha256(a.read_bytes()).hexdigest()+'\n\n'
for start,end in [(2208,2235),(2258,2298),(2484,2532),(3614,3631),(4388,4393)]:excerpt+=f'\nLines{start}-{end}:\n'+''.join(lines[start-1:end])
payload['reference/pinned-constructor-citations.txt']=excerpt.encode()
parent=r/'docs/roadmap/evidence/m4-analyzer-literal-key-memos-focused-2026-10-16.tar.gz';assert hashlib.sha256(parent.read_bytes()).hexdigest()=='f2a243e222f67d7aad54be2d05cee51f64d061f0e02d97755fb3c18ae6f6c5d4'
payload['audit.json']=json.dumps({'base':'ec0eea2655c71f9e4957cf1b0cbd8727c7ec97b1','parent_archive_sha256':'f2a243e222f67d7aad54be2d05cee51f64d061f0e02d97755fb3c18ae6f6c5d4','freeze_count':len(s['freeze']),'fingerprints':checks,'scope':'Authorized explicit route corrections only. Native5 and actual CLI env/vector2 pass; both unchanged source-tags still default-fuel fail. No measured fuel saving, acceptance or closure claim. No Jank gate or full baseline/final CI executed on this source. Parallel Jank component remains separate, not counted here.','authority':'Reader Forms/dynamic symbols/metadata-derived values/Suss-only fields unchanged; originally-nil receipt eligibility unchanged. Shared binding route requires actual Plain let/loop/param or MethodArgument role; adapted catch/receiver/self names remain Cold. Self-binding-only callable-field lookalikes are not promoted under the cited let-binding proof. Existing constant/hash/bridge code byte-identical to ec0. Six primitive units charged for each new binding selector.','source_review':'Carver no blockers at graph a6ed3936a07cc7fc08fc30e72b2f87dc5a0fd26ea0522aa29422a0ab8fccfdfe, relayed by main; source-only verdict, not artifact/runtime/performance audit.','support_inputs_capture':'Supporting fingerprint inputs captured after tests, not independently frozen before tests. Runtime source/bootstrap freeze checked before/after; fingerprint calculations recomputed from archived bytes.','limits':'No detailed receiver-level cold Keyword/Symbol profile collected yet. Remaining cold receiver source and budget deficit unknown; next diagnostic must use actual receiver fields before dispatch with nesting-aware counts and unchanged guest calls. Earlier failed nested-borrow compile retained. Parent1391-payload archive and semantic before/after comparison preserved unchanged.'},indent=2).encode()
manifest={f:hashlib.sha256(b).hexdigest() for f,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode();out=r/'docs/roadmap/evidence/m4-analyzer-literal-proved-routes-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f,b in sorted(payload.items()):
  info=tarfile.TarInfo(f);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:assert all(hashlib.sha256(t.extractfile(f).read()).hexdigest()==h for f,h in manifest.items())
print(json.dumps({'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'freeze_count':len(s['freeze']),'fingerprints':checks},indent=2))
