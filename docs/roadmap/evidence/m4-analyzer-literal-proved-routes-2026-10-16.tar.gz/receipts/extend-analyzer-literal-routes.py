from pathlib import Path
r=Path('/home/bobby/Work/code/bobby/suss-m4-analyzer-literal-key-memos');p=r/'crates/suss-compile/src/portable_macro_graph.rs';s=p.read_text()
# The shared local record also represents adapted catch/receiver/self slots.
# Only actual parameter/let/loop roles acquire the newly proved field tokens.
a=s.index('    fn local_record(');b=s.index('    fn field(',a);part=s[a:b]
for name in ['form','local','binding-form?','line','column','arg-id','init','children','shadow','info']:
 part=part.replace(f'FieldKey::Cold("{name}")',f'self.binding_literal_key(binding, AnalyzerLiteralKeyword("{name}"))?')
part=part.replace('let init = self.keyword("init")?;', 'let init_key = self.binding_literal_key(binding, AnalyzerLiteralKeyword("init"))?;\n            let init = self.keyword(init_key)?;')
# The exact two parameter env field positions are compiler literals, not a
# runtime spelling classifier. Values remain existing position/source values.
part=part.replace('for key in ["line", "column"] {','for token in [AnalyzerLiteralKeyword("line"), AnalyzerLiteralKeyword("column")] {\n                let key = token.name();').replace('env.push((FieldKey::Cold(key), *value));','env.push((FieldKey::Literal(token), *value));')
# FunctionName-only callable fields are not let/loop bindings in this frontend;
# leave them cold pending a matching source-role proof (no by-name promotion).
s=s[:a]+part+s[b:]
pos=s.index('    fn local_record(')
s=s[:pos]+'''    // c4295f3 analyzer.cljc2220-2235 (params),2500-2530 (let/loop).
    // Adapted CatchBinding/MethodThis report source_kind Let but do not establish
    // these constructors. Inspect the actual immutable role/kind pair instead.
    fn binding_literal_key(&mut self, binding: &LocalBinding, token: AnalyzerLiteralKeyword) -> Result<FieldKey<'static>> {
        self.charge(6)?; // role/kind reads, bounded matches, payload and selection
        Ok(match (&binding.source_role, binding.kind) {
            (SourceRole::Plain, hir::LocalKind::Let | hir::LocalKind::Loop | hir::LocalKind::Argument { .. })
            | (SourceRole::MethodArgument { .. }, _) => FieldKey::Literal(token),
            _ => FieldKey::Cold(token.name()),
        })
    }
''' + s[pos:]
a=s.index('    fn field_record(');b=s.index('    fn scope(',a);part=s[a:b]
for name in ['local','field','shadow','line','column']:
 part=part.replace(f'FieldKey::Cold("{name}")',f'FieldKey::Literal(AnalyzerLiteralKeyword("{name}"))')
part=part.replace('''for key in [
            "mutable",
            "unsynchronized-mutable",
            "volatile-mutable",
            "tag",
        ] {''','''// c4295f3 analyzer.cljc3619-3628 parse-type: literal keys;
        // metadata-derived values still use the original reader Form route.
        for token in [
            AnalyzerLiteralKeyword("mutable"),
            AnalyzerLiteralKeyword("unsynchronized-mutable"),
            AnalyzerLiteralKeyword("volatile-mutable"),
            AnalyzerLiteralKeyword("tag"),
        ] {
            let key = token.name();''').replace('entries.push((FieldKey::Cold(key), value));','entries.push((FieldKey::Literal(token), value));')
s=s[:a]+part+s[b:]
a=s.index('    fn scope_record(');b=s.index('    fn ast(',a);part=s[a:b]
for name in ['fn-self-name','shadow','form','local','info','ret-tag']:
 part=part.replace(f'FieldKey::Cold("{name}")',f'FieldKey::Literal(AnalyzerLiteralKeyword("{name}"))')
part=part.replace('        let mut info = vec![','        // c4295f3 analyzer.cljc2285-2297 fn-name-var.\n        let mut info = vec![',1)
s=s[:a]+part+s[b:]
a=s.index('                hir::SourceNode::Vector(items) => {',s.index('    fn ast_record('));b=s.index('                hir::SourceNode::Set(items)',a);part=s[a:b].replace('FieldKey::Cold("items")','FieldKey::Literal(AnalyzerLiteralKeyword("items"))');s=s[:a]+part+s[b:]
a=s.index('            fields.push((FieldKey::Cold("children"), self.vector(&names)?));',a)
s=s[:a]+'''            // c4295f3 analyzer.cljc4392: vector keys AND [:items] are literals.
            // Map/set routes are outside this correction and retain Cold.
            let children_key = match collection.as_ref() {
                hir::SourceNode::Vector(_) => FieldKey::Literal(AnalyzerLiteralKeyword("children")),
                _ => FieldKey::Cold("children"),
            };
            fields.push((children_key, self.vector(&names)?));'''+s[a+len('            fields.push((FieldKey::Cold("children"), self.vector(&names)?));'):]
a=s.index('                for method in &callable.methods {',s.index('    fn ast_record('));b=s.index('                fields.push((FieldKey::Cold("methods")',a);part=s[a:b]
for name in ['form','params','body','children','variadic?','fixed-arity','recurs']:
 part=part.replace(f'FieldKey::Cold("{name}")',f'FieldKey::Literal(AnalyzerLiteralKeyword("{name}"))')
part=part.replace('let params = self.keyword("params")?;', 'let params = self.keyword(FieldKey::Literal(AnalyzerLiteralKeyword("params")))?;').replace('let body_key = self.keyword("body")?;', 'let body_key = self.keyword(FieldKey::Literal(AnalyzerLiteralKeyword("body")))?;')
part='                // c4295f3 analyzer.cljc2263-2275 analyze-fn-method.\n'+part
s=s[:a]+part+s[b:];p.write_text(s)
