//! Native counters only. No GC roots, Watch fields, guest calls or budget changes.
use super::*;
use std::{cell::RefCell,collections::BTreeMap};
#[derive(Default)] struct State {stack:Vec<(u64,&'static str)>,counts:BTreeMap<u64,BTreeMap<String,u64>>}
thread_local! {static STATE:RefCell<State>=RefCell::new(State::default());}
pub(super) fn enabled()->bool {std::env::var_os("SUSS_MEMO_LEDGER_TRACE").is_some()}
pub(super) struct Scope(bool);
impl Scope {pub(super) fn new(id:u64,kind:&'static str)->Self {let on=enabled();if on {STATE.with(|s|s.borrow_mut().stack.push((id,kind)));}Self(on)}}
impl Drop for Scope {fn drop(&mut self){if self.0 {STATE.with(|s|{s.borrow_mut().stack.pop();});}}}
pub(super) fn add(key:impl AsRef<str>,n:u64) {if !enabled(){return} STATE.with(|s|{let mut s=s.borrow_mut();let (id,kind)=s.stack.last().copied().unwrap_or((0,"outside"));let key=format!("{kind}.{}",key.as_ref());*s.counts.entry(id).or_default().entry(key).or_default()+=n;});}
pub(super) fn max(key:&str,n:u64) {if !enabled(){return} STATE.with(|s|{let mut s=s.borrow_mut();let (id,kind)=s.stack.last().copied().unwrap_or((0,"outside"));let v=s.counts.entry(id).or_default().entry(format!("{kind}.{key}")).or_default();*v=(*v).max(n);});}
pub(super) fn dump(id:u64,label:&str) {if enabled(){STATE.with(|s|{let s=s.borrow();eprintln!("memo-ledger {}",serde_json::json!({"identity":id,"label":label,"counts":s.counts.get(&id)}));});}}
#[track_caller]
pub(super) fn charge(mut store:StoreContextMut<'_,()>,units:u64,irq:&AtomicBool)->wasmtime::Result<()> {
 if !enabled(){return Session::consume_host_work(store,units,irq)}
 let line=std::panic::Location::caller().line();let before=store.get_fuel().ok();
 let result=Session::consume_host_work(store.as_context_mut(),units,irq);
 let after=store.get_fuel().ok();record_charge(line,units,before,after,result.is_ok());result
}
pub(super) fn record_charge(line:u32,units:u64,before:Option<u64>,after:Option<u64>,ok:bool) {
 if !enabled(){return} add("charge.calls",1);add("charge.requested",units);
 if let Some(delta)=before.zip(after).and_then(|(a,b)|a.checked_sub(b)){add("charge.actual",delta);add(format!("charge.line{line}.actual"),delta);}else{add("charge.unknown_delta",1);}
 if !ok{add("charge.errors",1);}
}
