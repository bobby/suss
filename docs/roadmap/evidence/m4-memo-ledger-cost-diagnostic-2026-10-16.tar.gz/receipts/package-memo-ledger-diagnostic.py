from pathlib import Path
import hashlib,json,subprocess,tarfile,io
r=Path('/home/bobby/Work/code/bobby/suss-m4-memo-ledger-diagnostic');c=Path('/home/bobby/.cache/suss-m4-work');s=json.loads((c/'memo-ledger-result.json').read_text());base=json.loads((c/'memo-ledger-base-snapshot.json').read_text());assert s['current'] is None and s['source_unchanged'];payload={}
paths=set(base['freeze'])|set(s['freeze'])
freeze={}
for f in sorted(paths):
 b=(r/f).read_bytes();h=hashlib.sha256(b).hexdigest();freeze[f]=h
 if f in s['freeze']:assert h==s['freeze'][f]
 if f.endswith('.sus'):assert h==base['freeze'][f]
 payload['snapshot/'+f]=b
s['freeze']=freeze
extra=['Cargo.toml','Cargo.lock','crates/suss-core/Cargo.toml','crates/suss-reader/Cargo.toml','crates/suss-compile/Cargo.toml','crates/suss-cli/Cargo.toml','runtime/core-import/suss/core.sus','runtime/core-import/manifest.json','runtime/core-import/LICENSE','runtime/numeric/artifact/numeric.wasm','runtime/numeric/artifact/manifest.json','docs/roadmap/wasi-wit-lock.json','vendor/wasi/wasi-wit-0.3.1/cli/cli.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/clocks.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/filesystem.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/random.wit','vendor/wasi/wasi-wit-0.3.1/cli/deps/sockets.wit']
for f in extra:assert (r/f).is_file();payload['snapshot/'+f]=(r/f).read_bytes()
paths=[f for f in s['freeze'] if f=='crates/suss-compile/build.rs' or any(f.startswith('crates/'+n+'/src/') and f.endswith(('.rs','.sus')) for n in ['suss-core','suss-reader','suss-compile'])]+extra[:5]+extra[9:];h=hashlib.sha256()
for f in sorted(set(paths),key=lambda p:tuple(p.split('/'))):
 b=payload['snapshot/'+f];n=f.encode();h.update(len(n).to_bytes(8,'little'));h.update(n);h.update(len(b).to_bytes(8,'little'));h.update(b)
checks={}
for phase in ['macro','runtime']:
 m=json.loads(payload[f'snapshot/runtime/bootstrap/{phase}.json']);checks[phase]={'compiler':h.hexdigest()==m['compiler_source_sha256'],'core':hashlib.sha256(payload['snapshot/runtime/core-import/suss/core.sus']).hexdigest()==m['source_sha256'],'dependencies':hashlib.sha256(payload['snapshot/runtime/core-import/manifest.json']).hexdigest()==m['dependency_graph_sha256'],'wasm':hashlib.sha256(payload[f'snapshot/runtime/bootstrap/{phase}.wasm']).hexdigest()==m['wasm_sha256']}
assert all(all(v.values()) for v in checks.values()),checks

for p in c.glob('memo-ledger-*'):
 if p.is_file() and p.name not in ['memo-ledger-package-result.json']:
  payload['receipts/'+p.name]=p.read_bytes()
for n in ['install-memo-ledger-diagnostic.py','run-memo-ledger-diagnostic.py','summarize-memo-ledger.py','package-memo-ledger-diagnostic.py']:
 payload['receipts/'+n]=(c/n).read_bytes()
payload['diagnostic-vs-8fda18a.patch']=subprocess.check_output(['git','diff','--binary','8fda18a'],cwd=r)
payload['diagnostic-freeze.json']=json.dumps(freeze,indent=2).encode()
payload['audit.json']=json.dumps({'committed_production_base':'8fda18a','base_paths_verified':435,'diagnostic_frozen_paths':len(freeze),'fingerprints':checks,'scope':'Observation only. Optimization rejected for this fixture because zero ineligible registrations. No production change, new guest call or quota change. Source unchanged during diagnostic run. Raw test failure preserved.','support_inputs_capture':'Supporting fingerprint inputs captured after execution, not separately frozen before run. Recomputed fingerprint checks use archived bytes.','review_limits':'Main supplied conditional invariant review of hypothetical omission only, not performance approval or independent artifact audit. Instrumentation limitations in receipts/memo-ledger-limitations.txt.'},indent=2).encode()
manifest={f:hashlib.sha256(b).hexdigest() for f,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode();out=r/'docs/roadmap/evidence/m4-memo-ledger-cost-diagnostic-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f,b in sorted(payload.items()):
  info=tarfile.TarInfo(f);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:assert all(hashlib.sha256(t.extractfile(f).read()).hexdigest()==h for f,h in manifest.items())
report={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'freeze_count':len(freeze),'fingerprints':checks};(c/'memo-ledger-package-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
