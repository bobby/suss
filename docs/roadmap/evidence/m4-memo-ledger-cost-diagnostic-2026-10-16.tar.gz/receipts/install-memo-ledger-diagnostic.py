from pathlib import Path
r=Path('/home/bobby/Work/code/bobby/suss-m4-memo-ledger-diagnostic');p=r/'crates/suss-compile/src/portable_session/memo_bridge.rs';s=p.read_text();s=s.replace('use super::{Session,','mod diagnostic;\nuse super::{Session,',1)
# Every original direct charge in this module keeps the same units and Result.
s=s.replace('Session::consume_host_work(', 'diagnostic::charge(')
needle='''        let mut entries = registry_lock(&self.entries);
        let mut index = 0;'''
s=s.replace('''        let mut entries = registry_lock(&self.entries);
        let mut index = 0;''','''        self.sweep_diagnostic(store, irq, "collect")
    }
    fn sweep_diagnostic(&self, mut store: StoreContextMut<'_, ()>, irq: &AtomicBool, reason: &'static str) -> wasmtime::Result<()> {
        let _diag=diagnostic::Scope::new(self.identity, reason);
        diagnostic::add("sweep.calls",1);
        let mut entries = registry_lock(&self.entries);
        diagnostic::max("sweep.max_len",entries.watches.len() as u64);
        let mut index = 0;''',1)
s=s.replace('''            diagnostic::charge(store.as_context_mut(), 1, irq)?;
            if entries.watches[index].strong_count() == 0 {''','''            diagnostic::add("sweep.attempted",1);
            diagnostic::charge(store.as_context_mut(), 1, irq)?;
            diagnostic::add("sweep.completed",1);
            if entries.watches[index].strong_count() == 0 {
                diagnostic::add("sweep.dead_removed",1);''',1)
s=s.replace('''            } else { index += 1; }
        }
        Ok(())
    }
}''','''            } else { diagnostic::add("sweep.live",1); index += 1; }
        }
        diagnostic::max("max_live_after_sweep",entries.watches.len() as u64);
        diagnostic::add("sweep.finished",1);
        Ok(())
    }
}
impl Drop for Ledger {fn drop(&mut self){diagnostic::dump(self.identity,"ledger-drop");}}
impl Session {pub(crate) fn memo_ledger_diagnostic_dump(&self,label:&str){diagnostic::dump(self.memo_ledger.identity,label);}}
''',1)
s=s.replace('''        if self.phase != Phase::Macro { return Ok(None) }''','''        let _diag=diagnostic::Scope::new(self.identity,"enroll");
        diagnostic::add("requests",1);
        if self.phase != Phase::Macro { return Ok(None) }''',1)
s=s.replace('''        self.charge_host_work((std::mem::size_of::<Watch>() + std::mem::size_of::<Weak<Watch>>()) as u64 + 1)?;''','''        diagnostic::add("registrations_attempted",1);
        diagnostic::add(if eligible_transition {"eligible_true"}else{"eligible_false"},1);
        diagnostic::add(format!("owner.{owner}.eligible.{eligible_transition}"),1);
        let units=(std::mem::size_of::<Watch>() + std::mem::size_of::<Weak<Watch>>()) as u64 + 1;
        let before=if diagnostic::enabled(){self.store.get_fuel().ok()}else{None};
        let result=self.charge_host_work(units);
        diagnostic::record_charge(line!(),units,before,if diagnostic::enabled(){self.store.get_fuel().ok()}else{None},result.is_ok());
        result?;''',1)
s=s.replace('ledger.sweep(scope.as_context_mut(), &irq)?;','ledger.sweep_diagnostic(scope.as_context_mut(), &irq, "enroll")?;',1)
s=s.replace('''        entries.watches.push(Arc::downgrade(&watch));
        Ok(Some(watch))''','''        entries.watches.push(Arc::downgrade(&watch));
        diagnostic::add("registrations_published",1);
        diagnostic::add(if eligible_transition {"published_eligible_true"}else{"published_eligible_false"},1);
        diagnostic::max("max_live_after_publish",entries.watches.len() as u64);
        if diagnostic::enabled() && entries.watches.len()%128==0 {diagnostic::dump(self.identity,"enroll-progress");}
        Ok(Some(watch))''',1)
s=s.replace('''        let mut caller = RootScope::new(&mut caller);
        diagnostic::charge(caller.as_context_mut(), 32, &interrupt)?;''','''        let _diag=diagnostic::Scope::new(ledger.identity,"protected-store");
        diagnostic::add("calls",1);
        let mut caller = RootScope::new(&mut caller);
        diagnostic::charge(caller.as_context_mut(), 32, &interrupt)?;''',1)
s=s.replace('ledger.sweep(caller.as_context_mut(), &interrupt)?;','ledger.sweep_diagnostic(caller.as_context_mut(), &interrupt, "protected-store")?;',1)
s=s.replace('''        let (_, field) = bootstrap::memo_owner_slots().nth(site)''','''        diagnostic::add(format!("site.{site}.calls"),1);
        let (_, field) = bootstrap::memo_owner_slots().nth(site)''',1)
s=s.replace('''            for index in 0..count {
                diagnostic::charge(caller.as_context_mut(), 1, &interrupt)?;''','''            for index in 0..count {
                diagnostic::add("scan.attempted",1);
                diagnostic::charge(caller.as_context_mut(), 1, &interrupt)?;
                diagnostic::add("scan.completed",1);''',1)
s=s.replace('''                if !watch.eligible_transition || watch.site != site || watch.identity != ledger.identity { continue }''','''                diagnostic::add(if watch.eligible_transition {"scan.eligible_true"}else{"scan.eligible_false"},1);
                diagnostic::add(format!("site.{site}.scan"),1);
                if watch.site==site {diagnostic::add("scan.site_match",1);}
                if !watch.eligible_transition || watch.site != site || watch.identity != ledger.identity { continue }
                diagnostic::add("scan.eligible_site_identity_match",1);''',1)
s=s.replace('''                    candidates.push((watch, Receipt { value, bits, source_safe }, false));''','''                    diagnostic::add("candidates",1);
                    candidates.push((watch, Receipt { value, bits, source_safe }, false));''',1)
s=s.replace('''        diagnostic::charge(caller.as_context_mut(), 4, &interrupt)?;
        let mut scope = RootScope::new(&mut caller);
        let mut candidates = Vec::new();''','''        let _diag=diagnostic::Scope::new(ledger.identity,"scoped-store");
        diagnostic::add("calls",1);
        diagnostic::charge(caller.as_context_mut(), 4, &interrupt)?;
        let mut scope = RootScope::new(&mut caller);
        let mut candidates = Vec::new();''',1)
s=s.replace('''        if observer.has_scope() {
            let (authority''','''        if observer.has_scope() {
            diagnostic::add("active_scope",1);
            let (authority''',1)
s=s.replace('''                for index in 0..count {
                    diagnostic::charge(scope.as_context_mut(), 1, &interrupt)?;''','''                for index in 0..count {
                    diagnostic::add("scan.attempted",1);
                    diagnostic::charge(scope.as_context_mut(), 1, &interrupt)?;
                    diagnostic::add("scan.completed",1);''',1)
s=s.replace('''                    if !watch.eligible_transition || watch.identity != ledger.identity { continue }''','''                    diagnostic::add(if watch.eligible_transition {"scan.eligible_true"}else{"scan.eligible_false"},1);
                    diagnostic::add(format!("site.{}.scan",watch.site),1);
                    if !watch.eligible_transition || watch.identity != ledger.identity { continue }
                    diagnostic::add("scan.eligible_identity_match",1);''',1)
s=s.replace('''                    // Do not materialize a receiver root before a physical slot matches.''','''                    diagnostic::add("scan.slot_match",1);
                    // Do not materialize a receiver root before a physical slot matches.''',1)
s=s.replace('''                    candidates.push((watch, Receipt { value, bits, source_safe: true }, false));''','''                    diagnostic::add("candidates",1);
                    candidates.push((watch, Receipt { value, bits, source_safe: true }, false));''',1)
p.write_text(s)
p=r/'crates/suss-compile/src/portable_macros.rs';s=p.read_text().replace('''    if std::env::var_os("SUSS_MACRO_FUEL_TRACE").is_some() {''','''    session.memo_ledger_diagnostic_dump(&format!("{}/{}:{stage}",target.0,target.1));
    if std::env::var_os("SUSS_MACRO_FUEL_TRACE").is_some() {''',1);s=s.replace('''        result.map(Some).map_err(|error| Diagnostic {''','''        self.session.memo_ledger_diagnostic_dump(&format!("{}/{}:result:{stage}:ok={}",target.0,target.1,result.is_ok()));
        result.map(Some).map_err(|error| Diagnostic {''',1);p.write_text(s)
