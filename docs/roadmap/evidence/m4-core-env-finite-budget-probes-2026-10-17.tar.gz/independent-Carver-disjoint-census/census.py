#!/usr/bin/env python3
"""Host-only ordered interval census. No Cargo/guest execution or source edits."""
import argparse, collections, hashlib, json, pathlib, re
parser=argparse.ArgumentParser()
parser.add_argument('log',type=pathlib.Path)
parser.add_argument('output',type=pathlib.Path)
a=parser.parse_args()
stack=[]; stats=collections.defaultdict(collections.Counter); recipes=collections.defaultdict(collections.Counter)
visits=collections.Counter(); roots=collections.Counter(); hashes=collections.Counter(); requests=[]; errors=[]
last=None; entry=None; line_number=0; digest=hashlib.sha256()
def close(typ,key,fuel,partial=False):
    if not stack or (stack[-1]['type'],stack[-1]['key'])!=(typ,key):
        raise ValueError(('interval mismatch',line_number,typ,key,stack[-3:]))
    x=stack.pop(); total=x['start']-fuel; exclusive=total-x['children']
    if exclusive<0:raise ValueError(('negative interval',line_number,x))
    s=stats[(typ,x['kind'])];s['intervals']+=1;s['inclusive_fuel']+=total;s['exclusive_among_logged_intervals']+=exclusive;s['incomplete_intervals']+=int(partial)
    if stack:stack[-1]['children']+=total
    if typ=='dispatch':
        r=recipes[key];r['visits']+=1;r['inclusive_fuel']+=total;r['exclusive_among_logged_intervals']+=exclusive
        r['hash_calls']+=x.get('hash_calls',0);r['hash_fuel']+=x.get('hash_fuel',0)
        r['start_fuel']=x['start'];r['end_fuel']=fuel
    if typ=='call' and key=='hash-invocation-inclusive':
        hashes[total]+=1
        for parent in reversed(stack):
            if parent['type']=='dispatch':
                parent['hash_calls']=parent.get('hash_calls',0)+1
                parent['hash_fuel']=parent.get('hash_fuel',0)+total
                break
with a.log.open('rb') as f:
    for raw in f:
        line_number+=1;digest.update(raw);line=raw.decode(errors='replace')
        if line.startswith('macro-request-budget '):requests.append(line.strip())
        if not line.startswith(('source-materialize ','source-materialize-call ')):continue
        m=re.search(r'remaining=Some\((\d+)\)',line)
        if not m:raise ValueError(('missing balance',line_number,line))
        fuel=int(m[1]);last=fuel
        event=re.search(r'event=(\S+)',line)[1]
        if line.startswith('source-materialize-call '):
            key=re.search(r'label=(\S+)',line)[1]
            if event=='before':stack.append(dict(type='call',key=key,kind=key,start=fuel,children=0))
            elif event=='after':close('call',key,fuel)
            else:raise ValueError(('unknown call event',line_number,event))
        else:
            root=int(re.search(r'root=(\d+)',line)[1])
            if event=='entry':
                if entry is None:entry=fuel
                roots[root]+=1;stack.append(dict(type='root',key=root,kind='materialize',start=fuel,children=0))
            elif event=='return':close('root',root,fuel)
            elif event=='dispatch-before':
                recipe=int(re.search(r'recipe=(\d+)',line)[1]);kind=re.search(r'kind=(\S+)',line)[1]
                visits[recipe]+=1;stack.append(dict(type='dispatch',key=(root,recipe),kind=kind,start=fuel,children=0))
            elif event=='dispatch-after':close('dispatch',(root,int(re.search(r'recipe=(\d+)',line)[1])),fuel)
            else:raise ValueError(('unknown materialize event',line_number,event))
unclosed=[dict(x) for x in stack]
# Bound observed consumption of an unfinished interval at the last logged balance;
# this never declares that interval completed or supplies its future cost.
while stack:close(stack[-1]['type'],stack[-1]['key'],last,True)
rows=[dict(type=k[0],label=k[1],**dict(v)) for k,v in sorted(stats.items(),key=lambda kv:kv[1]['exclusive_among_logged_intervals'],reverse=True)]
observed=sum(v['exclusive_among_logged_intervals'] for v in stats.values())
assert observed==entry-last
out={'schema':1,'diagnostic_commit':'9807858a1d5d619ccff112fdb7c4553a7e333601',
     'input_log':str(a.log.resolve()),'input_log_sha256':digest.hexdigest(),'input_bytes':a.log.stat().st_size,'input_lines':line_number,
     'script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
     'requests_raw':requests,'materialize_entries':sum(roots.values()),'distinct_materialize_root_ids':len(roots),
     'normal_materialize_returns':sum(roots.values())-len(unclosed),'unclosed_at_eof':unclosed,
     'interval_pairing_mismatches':0,'dispatch_visits':sum(visits.values()),'distinct_recipe_ids':len(visits),
     'repeated_recipe_visits_across_materializations':sum(visits.values())-len(visits),
     'most_visited_recipe_ids':visits.most_common(8),'first_materialize_balance':entry,'last_materialize_balance':last,
     'observed_materialize_prefix_fuel':observed,'pre_materialize_request_fuel':1000000000-entry,
     'partition':rows,'terminal_recipe_13_50518':dict(recipes[(13,50518)]),
     'hash_cost_histogram':hashes.most_common(),
     'limits':['Read-only host parsing of existing logs; no new Suss execution.',
       'Exclusive means subtraction of nested intervals logged by these two trace families only. Uninstrumented nested work remains inside its enclosing region.',
       'Root13 is incomplete. Observed consumption through zero is a prefix, not whole completion cost or remaining gap.',
       'Inclusive root/alias/helper totals overlap; sum only exclusive_among_logged_intervals for the disjoint partition.',
       'Repeated recipe IDs across distinct materializations are not proof of redundant work or permission to cache guest results/suppress callbacks.',
       'Result Ok on a helper interval is not whole-request success; terminal enclosing dispatch and test fail with fuel exhaustion.',
       'Pre-materialize request consumption is separate from this partition. Later three intended projections are unexecuted.',
       'Source tuple/2915-input binding and earlier-cap prefix comparisons are supplied by separate producer receipts, not revalidated by this parser.']}
a.output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['input_log_sha256','script_sha256','materialize_entries','normal_materialize_returns','dispatch_visits','distinct_recipe_ids','observed_materialize_prefix_fuel','pre_materialize_request_fuel']},indent=2))
