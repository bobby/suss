from pathlib import Path
import json,hashlib,subprocess,tarfile,io,re
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss-m4-core-env-complete-cost');O=C/'core-env-finite-budget-evidence';H30='fc94e4cdac06241b0fe23ff8d47583e0a0f359aa';H1='9807858a1d5d619ccff112fdb7c4553a7e333601';BASE='5e0d9f273081ec3a5d7c04aa9e949a1a3c08a0f0';PIN='c4295f303100bbf5afac449242d30bca1126f1a1';runs=[('core-env-complete-cost',H30),('core-env-complete-cost-1b',H1)];payload={};blobs={};maps={}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H1
allowed={'docs/roadmap/handoff.md','docs/roadmap/evidence/m4-core-env-finite-budget-probes-2026-10-17.md','docs/roadmap/evidence/m4-core-env-finite-budget-probes-2026-10-17.tar.gz'};assert set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=R,text=True).splitlines())<=allowed
def put(n,b):assert n not in payload,n;payload[n]=b
for rn,head in runs:
 root=C/rn;j=json.loads((root/'receipt.json').read_text());assert j['current'] is None and j['final_changed']==[];assert [(s['name'],s['exit']) for s in j['stages']]==[('bootstrap',0),('core-env',101)]
 for f in root.rglob('*'):
  if f.is_file() and f.relative_to(root).parts[0] not in ['before','after-bootstrap','terminal'] and '__pycache__' not in f.parts:put('runs/'+rn+'/'+str(f.relative_to(root)),f.read_bytes())
 for f in root.glob('*freeze.json'):
  fm=json.loads(f.read_text());assert len(fm)==2915;maps[rn+'/'+f.name]=fm
  for n,h in fm.items():
   if h in blobs:continue
   for stage in ['before','after-bootstrap','terminal']:
    p=root/stage/n
    if p.is_file():
     data=p.read_bytes()
     if hashlib.sha256(data).hexdigest()==h:blobs[h]=data;break
   else:raise AssertionError((rn,f.name,n,h))
 final=json.loads((root/'terminal-freeze.json').read_text());normal=[n for n in final if not n.startswith('clojurescript/')];stream=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=R,input=''.join(head+':'+n+'\n' for n in normal).encode()));checked={}
 for n in normal:
  header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob';data=stream.read(int(header[2]));assert stream.read(1)==b'\n';assert hashlib.sha256(data).hexdigest()==final[n],(head,n);checked[n]=final[n]
 for n in final:
  if not n.startswith('clojurescript/'):continue
  data=subprocess.check_output(['git','show',PIN+':'+n.removeprefix('clojurescript/')],cwd=R/'clojurescript');assert hashlib.sha256(data).hexdigest()==final[n];checked[n]=final[n]
 put('source-bindings/'+head+'.json',(json.dumps({'head':head,'checked':len(checked),'inputs':checked,'pinned_cljs':PIN,'mismatches':[]},indent=2)+'\n').encode())
# Exact published default777-event control, no current/livebaseline data.
default=C/'native-raw-key-scratch-v2'
for n in ['receipt.json','core-env.log','core-env-comparison.json','terminal-freeze.json']:
 put('default5e/'+n,(default/n).read_bytes())
fm=json.loads((default/'terminal-freeze.json').read_text());assert len(fm)==2915
for n,h in fm.items():
 if h not in blobs:
  p=default/'terminal'/n;data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==h;blobs[h]=data
for h,data in blobs.items():put('frozen/sha256/'+h,data)
for d in ['core-env-complete-cost-plan-raw-key-scratch','core-env-complete-cost-1b-source']:
 for f in (C/d).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:put('source-packets/'+d+'/'+str(f.relative_to(C/d)),f.read_bytes())
for n in ['run-core-env-complete-cost.py','run-core-env-complete-cost-1b.py','compare-core-env-complete-cost.py','compare-core-env-complete-cost-1b.py','bind-suss-frozen-source.py']:
 put('commands-and-comparators/'+n,(C/n).read_bytes())
# Exact normalbootstrap equality across fixtureliteral-only source successor.
boots={}
for phase in ['runtime','macro']:
 for ext in ['wasm','json']:
  n=f'runtime/bootstrap/{phase}.{ext}';a=subprocess.check_output(['git','show',H30+':'+n],cwd=R);b=subprocess.check_output(['git','show',H1+':'+n],cwd=R);assert a==b;boots[n]=hashlib.sha256(a).hexdigest()
put('source-equivalence/identical-normal-bootstrap.json',(json.dumps({'heads':[H30,H1],'files':boots,'qualification':'Exactbytes correspondence, not execution/default acceptance'},indent=2)+'\n').encode())
put('source-equivalence/30M-diff-from-production.patch',subprocess.check_output(['git','diff','--binary',BASE,H30],cwd=R));put('source-equivalence/1B-literal-only-diff.patch',subprocess.check_output(['git','diff',H30,H1],cwd=R))
c30=json.loads((C/runs[0][0]/'complete-cost-comparison.json').read_text());c1=json.loads((C/runs[1][0]/'complete-cost-comparison.json').read_text());assert c30['all_original_checkpoints_match_plus_20M'] and c30['metadata_events']==3393 and not c30['complete_original_test_passes'];assert c1['all_777_default_checkpoints_match_plus_990M'] and c1['all_3393_30M_checkpoints_match_plus_970M'] and c1['metadata_events']==6836 and not c1['complete_original_test_passes'];assert c1['outer_requests']==[{'start':1000000000,'end':0,'measured_outer_debit':1000000000}]
put('parent-context.json',(json.dumps({'production_source':BASE,'production_evidence_head':'a259870b2fe4ce3e8da3b267bf73c4d8c558622d','production_archive_sha256':'494aa46df38041286b93c912f7fe008951dcfbf321273daa5a7bc2d6d2babd45','qualification':'Reviewedpublishedparent context; defaultCoreEnvfuelnegative remainsnegative. Focused77passes/defaultsourcechild are differenttests, notCoreEnvacceptance. Livefullbaseline excluded.'},indent=2)+'\n').encode())
summary={'30M_source':H30,'1B_source':H1,'production_parent':BASE,'rust_results_each':{'pass':0,'fail':1,'ignored':0},'30M_metadata_events':3393,'1B_metadata_events':6836,'default_prefix_events':777,'prefix_equivalence':{'30M_vs_default':20000000,'1B_vs_default':990000000,'1B_vs30M':970000000},'1B_outer_attempts_observed':1,'1B_outer_start':1000000000,'1B_outer_end':0,'other_original_requests_unexecuted':3,'full_cost':'UNKNOWN','semantic_acceptance':False,'limits':['Exhaustedbudgetdebit is not completedwholecost','Metadatafinished does notmean projectionfinished','No helper refills/callerallowance changes','Laterassertions/requests unexecuted','No more budgetprobes','No livefullbaseline snapshots/results included']}
censusdir=C/'core-env-complete-cost-1b-disjoint-census';census=json.loads((censusdir/'census.json').read_text());assert census['diagnostic_commit']==H1;assert hashlib.sha256((C/'core-env-complete-cost-1b'/'core-env.log').read_bytes()).hexdigest()==census['input_log_sha256'];assert hashlib.sha256((censusdir/'census.py').read_bytes()).hexdigest()==census['script_sha256'];assert census['observed_materialize_prefix_fuel']==787369731 and census['pre_materialize_request_fuel']==212630269 and sum(x['exclusive_among_logged_intervals'] for x in census['partition'])==787369731
for n in ['census.py','census.json']:put('independent-Carver-disjoint-census/'+n,(censusdir/n).read_bytes())
summary['observed_disjoint_prefix']={'pre_materialization':212630269,'materialize_prefix':787369731,'residual_uninstrumented':440442941,'hash_calls':115943,'hash_region':191613250,'limits':'Residualnotallplanning/provenarray;callbacksretained;openroot13notwholecompletioncost'}
summary['previous_pre_census_archive_sha256']='757495123387e5e1a5268b1a494132a52484d036eb0f24330180f635c2376b7b'
put('summary.json',(json.dumps(summary,indent=2)+'\n').encode());put('assembly/package.py',Path(__file__).read_bytes())
checks=''.join(hashlib.sha256(payload[n]).hexdigest()+'  '+n+'\n' for n in sorted(payload));put('SHA256SUMS',checks.encode())
a=R/'docs/roadmap/evidence/m4-core-env-finite-budget-probes-2026-10-17.tar.gz'
with tarfile.open(a,'w:gz',compresslevel=6) as t:
 for n in sorted(payload):
  data=payload[n];info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
hashes={};freezes={}
with tarfile.open(a,'r|gz') as t:
 for m in t:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts and m.name not in hashes;data=t.extractfile(m).read();assert data==payload[m.name];hashes[m.name]=hashlib.sha256(data).hexdigest()
  if m.name.endswith('freeze.json'):freezes[m.name]=json.loads(data)
for name,fm in freezes.items():
 assert len(fm)==2915
 for n,h in fm.items():assert hashes.get('frozen/sha256/'+h)==h,(name,n,h)
j={'archive':str(a),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'members':len(payload),'manifested_payloads':len(payload)-1,'bytes':a.stat().st_size,'source_30M':H30,'source_1B':H1,'source_bound_each':2915,'self_contained_freeze_maps':len(freezes)};(O/'package-result.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j))
