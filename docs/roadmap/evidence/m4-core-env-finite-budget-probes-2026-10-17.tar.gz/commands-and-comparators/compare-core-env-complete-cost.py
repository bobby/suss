from pathlib import Path
import re,json
c=Path(__file__).parent;r=c/'core-env-complete-cost';state=json.loads((r/'receipt.json').read_text());assert state['current']is None and not state['final_changed']
text=(r/'core-env.log').read_text(errors='replace');control=(c/'native-raw-key-scratch-v2/core-env.log').read_text(errors='replace')
def rows(s):
 return [(m[1],m[2],int(m[3])) for line in s.splitlines()if(m:=re.fullmatch(r'metadata-declaration (\S+) (\S+): (\d+)',line))]
a,b=rows(control),rows(text);assert len(a)==777 and len(b)>=len(a)
for i,(x,y)in enumerate(zip(a,b)):
 assert x[:2]==y[:2] and y[2]-x[2]==20000000,(i,x,y)
stack=[];requests=[]
for line in text.splitlines():
 m=re.search(r'macro-request-budget event=(begin|end) remaining=Ok\((\d+)\)',line)
 if not m:continue
 event,fuel=m[1],int(m[2])
 if event=='begin':stack.append(fuel)
 else:
  assert stack,'unmatched end'
  start=stack.pop()
  if start==30000000:requests.append({'start':start,'end':fuel,'measured_outer_debit':start-fuel})
assert not stack,'unmatched begin'
counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert len(counts)==1 and sum(map(int,counts[0]))==1 and counts[0][2]=='0'
passed=counts[0][0]=='1'
if passed:assert len(requests)==4,'all four original outer requests required'
out={'diagnostic_only':True,'control_checkpoint_count':777,'all_original_checkpoints_match_plus_20M':True,'metadata_events':len(b),'outer_requests':requests,'complete_original_test_passes':passed,'test_counts':dict(zip(['passed','failed','ignored'],map(int,counts[0]))),'limits':'Explicit finite30M macro cap; caller allowances unchanged. No default acceptance credit. If original full test fails, later observations may be unexecuted and recorded outer debits do not establish successful complete semantic requests.'}
(r/'complete-cost-comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
