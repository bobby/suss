from pathlib import Path
import re,json
c=Path(__file__).parent;r=c/'core-env-complete-cost-1b';state=json.loads((r/'receipt.json').read_text());assert state['current']is None and not state['final_changed']
def rows(path):
 result=[]
 with path.open(errors='replace')as f:
  for line in f:
   if(m:=re.fullmatch(r'metadata-declaration (\S+) (\S+): (\d+)\n?',line)):result.append((m[1],m[2],int(m[3])))
 return result
old=rows(c/'core-env-complete-cost/core-env.log');default=rows(c/'native-raw-key-scratch-v2/core-env.log');new=rows(r/'core-env.log');assert len(old)==3393 and len(default)==777
for prior,offset in [(old,970000000),(default,990000000)]:
 assert len(new)>=len(prior)
 for i,(a,b)in enumerate(zip(prior,new)):
  assert a[:2]==b[:2] and b[2]-a[2]==offset,(i,a,b,offset)
stack=[];requests=[];counts=[]
with (r/'core-env.log').open(errors='replace')as f:
 for line in f:
  if(m:=re.search(r'macro-request-budget event=(begin|end) remaining=Ok\((\d+)\)',line)):
   event,fuel=m[1],int(m[2])
   if event=='begin':stack.append(fuel)
   else:
    assert stack,'unmatched end'
    start=stack.pop()
    if start==1000000000:requests.append({'start':start,'end':fuel,'measured_outer_debit':start-fuel})
  if(m:=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)):counts.append(tuple(map(int,m.groups())))
assert not stack and len(counts)==1 and sum(counts[0])==1 and counts[0][2]==0
passed=counts[0][0]==1
if passed:assert len(requests)==4,'four original outer requests required'
out={'diagnostic_only':True,'all_777_default_checkpoints_match_plus_990M':True,'all_3393_30M_checkpoints_match_plus_970M':True,'metadata_events':len(new),'outer_requests':requests,'complete_original_test_passes':passed,'test_counts':dict(zip(['passed','failed','ignored'],counts[0])),'limits':'Fixed1B macro cap, unchanged caller defaults and all original observations. No default acceptance credit. A failing original test leaves later observations unknown/unexecuted; outer debits alone do not establish successful semantic requests.'}
(r/'complete-cost-comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
