# CoreEnv complete-cost diagnostic — UNAPPLIED

Prepared from the exact live raw-key candidate (raw_keys SHA 0825dd2462f6c354649c88193b0f79a58f8674c0aef76bff1dd0356773db54d2). No repository edits, new worktree, Cargo, bootstrap or producer. HEAD at preparation dc5096d excludes the dirty approved raw-key source and regenerated bootstrap; bind the eventual committed candidate and all 2915 inputs before root applies this overlay in an isolated diagnostic leaf. Do not overlay a live baseline.

## Minimal changes

Two files only. Fixture: comment plus macros.set_operation_fuel(30_000_000) after successful macros.define, inside each existing caller-phase iteration. Original caller budgets, setup/definition, sources, assertion order, GC and decoding remain unchanged. The Macro host carries the failing analysis-transport budget; changing caller alone would not do that.

ExpansionHost begin/end: two logs gated by the existing SUSS_MACRO_FUEL_TRACE flag. Begin logs after successful original begin_operation_budget; returns the same mapped Result. Failed begin adds no unmatched event. End logs BEFORE the original end_operation_budget. Remaining-fuel reads are printed as Result with Debug, never propagated via ?, unwrapped, converted to success, or used in control flow. No charges, new fields, request IDs, substage labels or helper refills. As with existing tracing, stderr/host overhead is not metered or timing evidence.

## Request and budget interpretation

Four original projection requests: Runtime identity; Runtime graph-owned; Macro identity; Macro graph-owned. One setter per phase iteration persists as configuration: every original outer expansion request starts a fresh 30M budget, while nested scopes share it. Macro definition/setup precedes the setter and remains default. Caller execution/bridge/decode requests remain separate default budgets. Do not sum them into macro cost or reclassify them as 30M requests.

Pair successful begin/end logs with a stack, not adjacent-line assumptions. Additional nested expansion requests, if present, do not refill or count as independent outer requests; any setup envelopes before the setter must be classified separately. Require exactly the four intended outer projection envelopes, each observed begin Ok(30000000), each paired end Ok(balance), original Rust test PASS and all assertions reached. End is a retirement observation, NOT a success bit; it may also be emitted on error/unwind. If 30M is insufficient or a caller/default operation fails, preserve it and report which later envelopes are unexecuted. Do not silently rerun with a larger cap.

For completed envelopes: cost = 30000000 - end; gap = cost - 10000000 (report signed headroom when below default). Do not substitute macro-fuel start/decoded labels for outer boundaries: they omit reader/analysis and compilation work. No total is established until actual execution.

## Root-owned execution after source commit and target lease

No execution authorized by preparation itself. After root selects an idle exclusive target: freeze exact candidate plus overlay and pinned references, jobs1/RAYON_NUM_THREADS=1/test threads1, no RUSTFLAGS assignment. Normal bootstrap regeneration mandatory; record the four outputs and postboot input closure. Stop and retain any compile/bootstrap failure. Suggested stages:

    cargo test -p suss-compile --locked --lib --no-run
    cargo run --profile test -p suss-cli --bin suss-bootstrap --locked -- runtime/bootstrap
    cargo test -p suss-cli --locked --test compiled_macro_core_environment compiled_macro_core_namespace_keeps_complete_declaration_records -- --exact --test-threads=1 --nocapture

Only final stage uses the same existing four flags as run-raw-key-scratch-v2.py: SUSS_MACRO_FUEL_TRACE=1, SUSS_METADATA_FUEL_TRACE=1, SUSS_SOURCE_MATERIALIZE_FUEL_TRACE=1, SUSS_RAW_KEY_TRACE=1. No additional observer file or sublabels. Before root execution, verify the actual default control log and source tuple rather than relying on filenames.

## Mandatory control and scope limits

Against cache/native-raw-key-scratch-v2/core-env-comparison.json and its actual default raw log, compare every one of the candidate's 777 metadata prefix events in order, retaining phase/occurrence/stage labels and exact +20000000 fuel offset within the corresponding raised macro request. Do not demand +20M for setup or separate default caller scopes. Preserve all previous macro-balance labels with the same applicable offset. New outer boundary records are excluded from the old-label comparison, not normalized away. A missing/different prefix event or balance invalidates causal cost attribution; newly reached tail and later phase observations are diagnostic-only, not previously executed default success. Keep initial odd-map test failure and all default CoreEnv failures durable.

The six previously captured metadata substage labels are NOT added by this patch. If their observer tuple differs from production, keep its partition separate rather than claiming identical source. Existing labels may identify hotspots only where actually emitted. Nested intervals/counters must not be added as disjoint totals.

Completion at 30M is diagnostic, not default-fuel acceptance, quota policy, baseline/CI success, or issue closure. Final artifact/head review remains separate.
