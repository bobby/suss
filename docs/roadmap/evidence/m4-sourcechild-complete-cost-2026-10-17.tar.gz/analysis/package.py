from pathlib import Path
import hashlib,json,subprocess,tarfile,io
cache=Path('/home/bobby/.cache/suss-m4-work'); plan=cache/'sourcechild-complete-cost-plan'; run=cache/'native-sourcechild-complete-cost'; root=Path('/home/bobby/Work/code/bobby/suss-m4-sourcechild-complete-cost')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='db40f82e0e21cb7995cb705391e2e3f57707f70f'
report=plan/'COST-REPORT.md'; text=report.read_text()
if 'Source-bound domain-node growth' not in text:
 text+='''\n## Source-bound domain-node growth, EACH phase\n\nThe record node-growth intervals additionally identify85 actual positive growth events for write_domain::Node (distinct from storage_snapshot::Node136). Accepted debit768725 splits into85 existing growth controls,519040 requested new backing bytes and249600 prepaid relocation bytes. The unchanged charged source formula is `(new_capacity + old_len) * size_of::<Node>() + 1`; Node160 is source-bound from the scalar edge/cut charges and all growth events satisfy the capacity formula. This reconstruction is in domain-node-growth-census.json and domain_growth.py. It is accepted requested backing/copy work, not allocator physical traffic or an extra charge to add to enclosing enrollment. There are930 records but only85 positive growth events; empty/non-growing records are not claimed as allocations.\n'''
 report.write_text(text)
files={}
def add(name,p):
 assert name not in files,name
 files[name]=Path(p).read_bytes()
for p in sorted(plan.iterdir()):
 if p.is_file() and p.name not in ['package-result.json']:
  add('analysis/'+p.name,p)
for p in sorted(run.iterdir()):
 if p.is_file():add('run/'+p.name,p)
add('run/driver.py',cache/'run-sourcechild-complete-cost.py')
neg=cache/'native-prototype-buffer-candidate-3'
for name in ['source-child.log','receipt.json','command-plan.json','after-bootstrap-freeze.json']:
 add('default10M-negative/'+name,neg/name)
# Complete frozen bytes deduplicated by SHA; all paths in each manifest resolve.
blobs={}; indexes={}
for stage,manifest in [('before','before-freeze.json'),('after-bootstrap','after-bootstrap-freeze.json')]:
 index=json.loads((run/manifest).read_text());assert len(index)==2915
 for path,sha in index.items():
  b=(run/stage/path).read_bytes();assert hashlib.sha256(b).hexdigest()==sha,path
  blobs.setdefault(sha,b)
 indexes[stage]=index
for sha,b in blobs.items():files['frozen/sha256/'+sha]=b
binding={'source_commit':head,'parent':'2bc35d1b7964fef711543d5693778f7f0a9de596','fixture_patch_sha256':hashlib.sha256((plan/'diagnostic.patch').read_bytes()).hexdigest(),'frozen_manifest_paths':{'before':'run/before-freeze.json','after-bootstrap':'run/after-bootstrap-freeze.json'},'frozen_count_each':2915,'unique_frozen_blobs':len(blobs),'execution':'compile0/bootstrap0/test1pass fixed30M; default10M remains failed','limits':'Each Runtime/Macro source phase separate30M outer request. No production quota/tariff change. No default-fuel acceptance, CI/full baseline claim or issue closure.'}
for rel,sha in indexes['after-bootstrap'].items():
 b=subprocess.check_output(['git','show',head+':'+rel],cwd=root) if not rel.startswith('clojurescript/') else (run/'after-bootstrap'/rel).read_bytes()
 # Submodule paths verified as pinned external inputs rather than root Git blobs.
 assert hashlib.sha256(b).hexdigest()==sha,rel
binding['committed_input_correspondence']='All root Git input bytes equal after-bootstrap manifest; submodule/external frozen inputs retained by SHA.'
files['source-binding.json']=(json.dumps(binding,indent=2)+'\n').encode()
files['source-commit.patch']=subprocess.check_output(['git','show','--binary','--format=fuller',head],cwd=root)
manifest={name:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for name,b in sorted(files.items())}
files['MANIFEST.json']=(json.dumps({'payload_count':len(manifest),'payloads':manifest},indent=2)+'\n').encode()
archive=root/'docs/roadmap/evidence/m4-sourcechild-complete-cost-2026-10-17.tar.gz';archive.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,b in sorted(files.items()):
  item=tarfile.TarInfo(name);item.size=len(b);item.mtime=0;item.mode=0o644;tar.addfile(item,io.BytesIO(b))
# Verify every payload and archive counts from bytes actually written.
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for name,entry in manifest.items():
  b=tar.extractfile(name).read();assert hashlib.sha256(b).hexdigest()==entry['sha256']
result={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'manifested_payloads':len(manifest),'source_binding':binding,'source_commit':head}
(plan/'package-result.json').write_text(json.dumps(result,indent=2)+'\n')
# Easy to read counterpart; archive contains exact same report.
(root/'docs/roadmap/evidence/m4-sourcechild-complete-cost-2026-10-17.md').write_text(report.read_text())
print(json.dumps(result,indent=2))
