from pathlib import Path
import json,re,collections
c=Path('/home/bobby/.cache/suss-m4-work');r=c/'native-sourcechild-complete-cost';lines=(r/'source-child.log').read_text().splitlines();base=json.loads((r/'complete-cost-census.json').read_text());result={}
phase_re=re.compile(r'source-snapshot phase=(\S+) count=(\d+) event=(before|after).*remaining=Some\((\d+)\)')
a_re=re.compile(r'source-snapshot-allocation type=(\S+) count=(\d+) element_bytes=(\d+) requested_bytes=(\d+)')
call_re=re.compile(r'source-materialize-call label=(\S+) event=(before|after).*remaining=Some\((\d+)\)')
record_re=re.compile(r'source-domain-record domain=\S+ fact=(\S+) phase=(\S+) event=(before|after).*remaining=Some\((\d+)\)')
domain_re=re.compile(r'source-domain domain=\S+ staged=\S+ phase=(\S+) event=(before|after).*remaining=Some\((\d+)\)')
for source,request in base['requests'].items():
 stack=[];allocation=None;allocs=[];events=[];others=collections.defaultdict(list)
 for i in range(request['start_line'],request['last_line']-1):
  line=lines[i]
  m=a_re.search(line)
  if m:
   assert allocation is None
   typ,count,size,n= m.groups();count,size,n=map(int,[count,size,n]);assert n==count*size
   room=next((v for v in reversed(stack) if v['phase'] in ['node-buffer-room','cut-buffer-room']),None)
   if room is not None:
    idx=room.setdefault('allocation_requests',0);room['allocation_requests']=idx+1;assert idx<2;role='new_backing' if idx==0 else 'relocation_work'
   else:role='new_backing'
   allocation={'type':typ,'count':count,'element_bytes':size,'requested_bytes':n,'role':role,'context':stack[-1]['phase'] if stack else 'outside','line':i+1}
  m=phase_re.search(line)
  if m:
   phase,count,event,fuel=m.groups();fuel=int(fuel)
   if event=='before':stack.append({'phase':phase,'count':count,'fuel':fuel,'line':i+1,'outermost':not stack})
   else:
    a=stack.pop();assert (a['phase'],a['count'])==(phase,count)
    spent=a['fuel']-fuel;events.append({'phase':phase,'spent':spent,'outermost':a['outermost']})
    if phase=='allocation-debit':
     assert allocation is not None
     assert 'result=Ok' in line,(i,line)
     assert spent==allocation['requested_bytes'],(i,spent,allocation)
     allocation['accepted_debit']=spent;allocs.append(allocation);allocation=None
  for kind,pattern in [('call',call_re),('record',record_re),('domain',domain_re)]:
   m=pattern.search(line)
   if not m:continue
   if kind=='record':fact,label,event,fuel=m.groups();label=fact+'/'+label
   else:label,event,fuel=m.groups()
   fuel=int(fuel)
   if event=='before':others[kind].append((label,fuel,not others[kind]))
   else:
    old=others[kind].pop();assert old[0]==label;events.append({'kind':kind,'phase':label,'spent':old[1]-fuel,'outermost':old[2]})
   break
 assert not stack and allocation is None and not any(others.values())
 grouped={}
 for a in allocs:
  k=a['type'];g=grouped.setdefault(k,{'element_bytes':a['element_bytes'],'requests':0,'new_backing_requests':0,'new_backing_bytes':0,'relocation_requests':0,'relocation_bytes':0,'accepted_byte_debits':0,'positive_requests':0})
  g['requests']+=1;g['positive_requests']+=a['requested_bytes']>0;g['accepted_byte_debits']+=a['accepted_debit']
  if a['role']=='new_backing':g['new_backing_requests']+=1;g['new_backing_bytes']+=a['requested_bytes']
  else:g['relocation_requests']+=1;g['relocation_bytes']+=a['requested_bytes']
 groups=collections.defaultdict(lambda:{'count':0,'spent':0})
 for e in events:
  k=(e.get('kind','snapshot'),e['phase'],e['outermost']);g=groups[k];g['count']+=1;g['spent']+=e['spent']
 outercalls=sum(v['spent'] for k,v in groups.items() if k[0]=='call' and k[2]);typed=sum(a['accepted_debit'] for a in allocs);result[source]={'request_debit':request['accepted_debit'],'disjoint_outer_calls_spent':outercalls,'outside_call_intervals':request['accepted_debit']-outercalls,'typed_snapshot_buffer_debits':typed,'typed_buffer_types':sorted([{'type':k,**v} for k,v in grouped.items()],key=lambda x:-x['accepted_byte_debits']),'phase_groups':[{'kind':k[0],'phase':k[1],'outermost_same_kind':k[2],**v} for k,v in groups.items()]}
(r/'whole-phase-native-census.json').write_text(json.dumps({'sources':result,'qualification':'Typed allocations are ONLY explicitly traced storage_snapshot::allocation<T> accepted byte charges, not every native allocation. new_backing reflects charged requested capacity, not allocator usable size; relocation is separately prepaid copying work, not another heap allocation. Both fees retained, zero requests kept. TryOrderedMap internal allocations, native Forms/projection/decoder buffers, roots and unlabelled work are NOT fully type-instrumented. Snapshot/domain/record phases nest in call intervals; do not add all categories. No model substituted for observed charges.'},indent=2)+'\n')
for source,j in result.items():
 print(source,'total',j['request_debit'],'calls',j['disjoint_outer_calls_spent'],'outside',j['outside_call_intervals'],'snapshot typed backing+relocation',j['typed_snapshot_buffer_debits'])
 print(json.dumps(j['typed_buffer_types'],indent=2))
 print('OUTER CALLS',[(x['phase'],x['count'],x['spent']) for x in j['phase_groups'] if x['kind']=='call' and x['outermost_same_kind']])
