from pathlib import Path
import json,re,hashlib,collections
c=Path('/home/bobby/.cache/suss-m4-work');run=c/'native-sourcechild-complete-cost';raw=run/'source-child.log';lines=raw.read_text().splitlines();pending={};rows=[];markers=[];requests={};active=None
for line_number,line in enumerate(lines,1):
 m=re.search(r'source-child-fuel source=(\S+) (?:variant=(.*?) )?stage=(.*?) remaining=Some\((\d+)\)',line)
 if not m:continue
 event_source,variant,stage,fuel=m.groups();fuel=int(fuel)
 if stage=='request-start':
  assert not pending,(line_number,pending)
  active=event_source;assert active not in requests;requests[active]={'start_line':line_number,'start_fuel':fuel};assert fuel==30_000_000,(active,fuel)
 assert active is not None
 markers.append({'request_source':active,'event_source':event_source,'variant':variant,'stage':stage,'fuel':fuel,'line':line_number})
 keybase=(active,event_source,variant)
 if stage.endswith(':before'):
  name=stage[:-7];key=keybase+(name,);assert key not in pending,(line_number,key);pending[key]=(fuel,line_number)
 elif stage.endswith(':after'):
  name=stage[:-6];key=keybase+(name,)
  if key in pending:
   before,start=pending.pop(key);rows.append({'request_source':active,'event_source':event_source,'variant':variant,'stage':name,'before':before,'after':fuel,'spent':before-fuel,'line_before':start,'line_after':line_number,'result':'completed marker'})
 elif ' result=' in stage:
  name,result=stage.split(' result=',1);key=keybase+(name,)
  if key in pending:
   before,start=pending.pop(key);rows.append({'request_source':active,'event_source':event_source,'variant':variant,'stage':name,'before':before,'after':fuel,'spent':before-fuel,'line_before':start,'line_after':line_number,'result':result})
 requests[active].update(last_line=line_number,last_fuel=fuel,accepted_debit=requests[active]['start_fuel']-fuel,last_stage=stage)
# Root budget resets only at the next source phase; all intervals within it must
# be monotone. Arbitrary prefix/setup logs are excluded by explicit markers.
for source in requests:
 fuels=[x['fuel'] for x in markers if x['request_source']==source];assert all(a>=b for a,b in zip(fuels,fuels[1:])),source
key_stages={'declarations-layout','doc-certificate','child-batch','expectation','recording-bridge','materialize','finish','physical-child-checks','physical-inputs','physical-normal-bridge','physical-private-bridge','physical-materialize','physical-slot-patch','physical-factory-finalize','final-parent','forged-memo-write','final-validation'}
selected=[x for x in rows if x['stage'] in key_stages];sums=collections.defaultdict(lambda:{'count':0,'spent':0})
for x in selected:
 g=sums[(x['request_source'],x['stage'])];g['count']+=1;g['spent']+=x['spent']
result={'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'requests':requests,'grouped_stage_intervals':[{'request_source':k[0],'stage':k[1],**v} for k,v in sums.items()],'paired_intervals':rows,'unclosed_intervals':[{'key':list(k),'fuel':v[0],'line':v[1]} for k,v in pending.items()],'qualification':'30M diagnostic only, independently per source phase, no acceptance. Expected factory-finalize rejection is retained verbatim and must be distinguished from test failure using final receipt. Parent helper intervals nest inside final-parent; materialize subphases nest inside materialize. Never sum overlapping intervals. Request debit includes unlabelled work between explicit source-child markers, excludes setup before request-start and any untraced cleanup after last marker. Missing phases remain unexecuted.'}
(run/'complete-cost-census.json').write_text(json.dumps(result,indent=2)+'\n');(run/'source-child-markers.json').write_text(json.dumps(markers,indent=2)+'\n');print(json.dumps({'requests':requests,'groups':result['grouped_stage_intervals'],'unclosed':result['unclosed_intervals']},indent=2))
