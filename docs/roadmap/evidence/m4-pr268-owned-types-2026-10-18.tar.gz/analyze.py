from pathlib import Path
import json,re
p=Path(__file__).parent;r=json.loads((p/'receipt.json').read_text())
assert r['terminal'] and not r['final_changed']
tot=[0,0,0];stages=[];names=[]
for stage in r['stages']:
 assert not stage['changed']
 if stage['name']=='identity':
  assert stage['exit']==0
  continue
 log=(p/(stage['name']+'.log')).read_text()
 matches=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',log)
 assert len(matches)==1,stage['name']
 counts=list(map(int,matches[0]));tot=[a+b for a,b in zip(tot,counts)]
 stages.append(dict(name=stage['name'],passed=counts[0],failed=counts[1],ignored=counts[2]))
 # Catch test-name duplicates rather than assuming stage sums are unique.
 names+=re.findall(r'^test ([\w:]+) \.\.\.',log,re.M)
assert tot==[74,4,0],tot
assert len(names)==78 and len(set(names))==78,(len(names),len(set(names)))
receipts={}
for l in (p/'public-identity.log').read_text().splitlines():
 for marker,name in [('CALLABLE_NAMESPACE_IDENTITY ','callable'),('NAMESPACE_IDENTITY ','namespace')]:
  if marker in l:
   obj=json.loads(l.split(marker,1)[1]);(p/(name+'.json')).write_text(json.dumps(obj,indent=2)+'\n');receipts[name]=obj;break
for name,obj in receipts.items():assert obj==json.loads((p/'control'/(name+'.json')).read_text()),name
m=json.loads((p/'map-comparison.json').read_text())
assert m['ordered_ids_match'] and m['counts']=={'pass':62,'guest-judged':7,'fail':0,'not-executed':0,'skipped':0,'namespaces-failed':0}
log=(p/'collection-source.log').read_text()
assert 'span: 851..882' in log and 'span: 510..531' in log
assert 'compiled macro invocation' in log and 'caller &env input transport' in log
binding=json.loads((p/'source-git-binding.json').read_text())
a={'source':binding['source'],'counts':dict(passed=tot[0],failed=tot[1],ignored=tot[2],unique=len(set(names))), 'stages':stages,'tracked_pre_run_files':binding['files_checked'],'all_stage_inputs_unchanged':True,'public_callable_and_namespace_exactly_equal_010e_receipts':True,'pinned_map':m['counts'],'source_child_extra_fuel_per_phase':6777,'limitations':['No new upstream oracle execution','Full workspace baseline unexecuted on this head while focused acceptance fails','No current-head CI result; previous010e CI failed','No issue closure, draft promotion or merge']}
(p/'terminal-analysis.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a,indent=2))
