from pathlib import Path
import json,hashlib,collections
r=Path(__file__).parent;o=r.parent/'current-hash-stacks';mods={};current=None
for line in (r/'wasmparser-raw.tsv').read_text().splitlines():
 a=line.split('\t')
 if a[0]=='MODULE':
  p=Path(a[1]);h=hashlib.sha256(p.read_bytes()).hexdigest();current=mods.setdefault(h,{'sha256':h,'paths':[],'exports':{},'bodies':{}});current['paths'].append(str(p))
 elif a[0]=='EXPORT':current['exports'][int(a[1])]=a[2]
 elif a[0]=='BODY':current['bodies'][int(a[1])]=[int(a[2]),int(a[3])]
names=json.loads((o/'names.json').read_text())
for item in names.values():
 h=item['sha256']
 if h in mods:mods[h]['debug_names']={int(k):v for k,v in item['functions'].items()}
old=r.parent/'hash-profile-macro-runtime.wasm';runtime=r/'macro-runtime.wasm';assert old.read_bytes()==runtime.read_bytes();h=hashlib.sha256(runtime.read_bytes()).hexdigest();oldmap=json.loads((r.parent/'hash-profile-macro-runtime-exports.json').read_text());assert {int(k):v for k,v in oldmap.items()}==mods[h]['exports'];(r/'verified-old-exports.json').write_text(json.dumps(oldmap,indent=2))
ops=json.loads((o/'samples.json').read_text());unresolved=[];stats=[]
for op in ops:
 top=collections.Counter();stacks=collections.Counter()
 for b in op['bins']:
  for sample in b['samples']:
   labels=[]
   for frame in sample['frames']:
    idx=frame['function'];offset=frame['module_offset'];relative=frame['function_offset'];candidates=[]
    for sha,m in mods.items():
     body=m['bodies'].get(idx)
     if body and body[0]<=offset<body[1] and offset-body[0]==relative:
      name=m['exports'].get(idx) or m.get('debug_names',{}).get(idx)
      candidates.append({'module_sha256':sha,'index':idx,'body_range':body,'label':name or f'<unexported function {idx}>','label_kind':'export' if idx in m['exports'] else 'debug_name' if name else 'unexported_index'})
    frame['resolution']=candidates
    if len(candidates)!=1:unresolved.append({'frame':frame,'matches':len(candidates)})
    labels.append(candidates[0]['label'] if len(candidates)==1 else '<ambiguous>')
   top.update(labels[:1]);stacks[tuple(labels)]+=1
 stats.append({'operation':op['operation'],'top_frames':top.most_common(),'full_stacks':[{'count':n,'top_to_root':list(stack)} for stack,n in stacks.most_common()]})
assert not unresolved,unresolved
(r/'module-map.json').write_text(json.dumps(mods,indent=2)+'\n');(r/'resolved-samples.json').write_text(json.dumps(ops,indent=2)+'\n');(r/'resolved-summary.json').write_text(json.dumps({'parent_commit':'9b22bf5','runtime_sha256':h,'old_runtime_hash_matches':True,'resolution':'Every frame uniquely matches function index + code body range + module_offset minus function_offset across saved41 modules and frozen-source-reconstructed Macro ABI. Reconstructed ABI was not captured during guest run. Old map verified by byte equality and freshly parsed exports.','unresolved_frames':len(unresolved),'limitations':'Unexported function indices remain explicit; no invented callee names. Sample frequency and inclusive stacks are not exclusive fuel proof. Original raw preserved.','operations':stats},indent=2)+'\n');print(json.dumps([{k:v for k,v in x.items() if k!='full_stacks'} for x in stats],indent=2))
