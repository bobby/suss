from pathlib import Path
import tarfile,json,hashlib,subprocess,io
r=Path('/home/bobby/Work/code/bobby/suss-m4-current-hash-stacks');o=Path(__file__).parent;parent=r/'docs/roadmap/evidence/m4-current-hash-stacks-2026-10-16.tar.gz'
with tarfile.open(parent) as t:d={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
manifest=json.loads(d['MANIFEST.json']);assert len(manifest)==495;assert all(hashlib.sha256(d[n]).hexdigest()==h for n,h in manifest.items())
checks={}
for n,b in d.items():
 if n.startswith('snapshot/'):
  f=n[9:];assert (r/f).read_bytes()==b;assert subprocess.check_output(['git','show','9b22bf5:'+f],cwd=r)==b;checks[f]=hashlib.sha256(b).hexdigest()
 elif n.startswith('raw/'):
  f=n[4:];assert (o.parent/'current-hash-stacks'/f).read_bytes()==b,f
(o/'snapshot-verification.json').write_text(json.dumps({'parent_archive_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'snapshot_count':len(checks),'snapshots':checks,'all_parent_payloads_valid':True,'all_snapshot_bytes_equal_tested_commit_and_current_before_restore':True,'all_parent_raw_bytes_equal_cache':True},indent=2)+'\n')
payload={}
for p in o.iterdir():
 if p.is_file() and p.name not in ['dump','parse']:payload[p.name]=p.read_bytes()
payload['original-samples.json']=d['raw/samples.json'];payload['original-result.json']=d['raw/result.json'];payload['original-MANIFEST.json']=d['MANIFEST.json'];payload['original-fixture.log']=d['raw/fixture.log'];payload['original-names.json']=d['raw/names.json']
m={n:hashlib.sha256(b).hexdigest() for n,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(m,indent=2).encode();out=r/'docs/roadmap/evidence/m4-current-hash-stacks-resolved-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,b in sorted(payload.items()):
  info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
print(json.dumps({'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(m),'snapshots_verified':len(checks)}))
