//! Construction records collected only by an explicitly recording FormBridge.
//! These audit direct facts; they are not a complete source/storage certificate.
use super::{
    ConstructorInputs, ScalarInputs, Session, SessionError, SessionValue, SourceArrayInputs,
};
use crate::portable::metered_map::{Context, TryOrderedMap};
use std::{cmp::Ordering, collections::hash_map::DefaultHasher, hash::Hasher};
use wasmtime::{AnyRef, RootScope, Rooted};

struct InputIndex<'a> {
    session: &'a mut Session,
    hash_mask: u64,
}
impl Context<u64> for InputIndex<'_> {
    type Error = SessionError;
    fn charge(&mut self, units: u64) -> Result<(), SessionError> {
        self.session.charge_host_work(units)
    }
    fn compare(&mut self, a: &u64, b: &u64) -> Result<Ordering, SessionError> {
        self.charge(1)?;
        Ok(a.cmp(b))
    }
}
impl InputIndex<'_> {
    fn hash(&mut self, value: &SessionValue) -> Result<u64, SessionError> {
        self.session.check(value)?;
        self.charge(1)?;
        let mut scope = RootScope::new(&mut self.session.store);
        let value = value.value.to_rooted(&mut scope);
        let mut hash = DefaultHasher::new();
        value.ref_hash(&scope, &mut hash)?;
        Ok(hash.finish() & self.hash_mask)
    }
    fn same(&mut self, a: &SessionValue, b: &SessionValue) -> Result<bool, SessionError> {
        self.session.check(a)?;
        self.session.check(b)?;
        self.charge(1)?;
        let mut scope = RootScope::new(&mut self.session.store);
        let a = a.value.to_rooted(&mut scope);
        let b = b.value.to_rooted(&mut scope);
        Ok(Rooted::<AnyRef>::ref_eq(&scope, &a, &b)?)
    }
    fn contains(
        &mut self,
        index: &TryOrderedMap<u64, usize>,
        collisions: &[Option<usize>],
        records: &[Record],
        value: &SessionValue,
    ) -> Result<bool, SessionError> {
        let hash = self.hash(value)?;
        let mut cursor = index.get(&hash, self)?.copied();
        while let Some(id) = cursor {
            if self.same(value, &records[id].value)? {
                return Ok(true);
            }
            cursor = collisions[id];
        }
        Ok(false)
    }
}

pub(crate) enum Fact {
    Scalar(ScalarInputs),
    Array(SourceArrayInputs),
    Constructor(ConstructorInputs),
    CanonicalSeed(std::sync::Arc<super::canonical_seeds::CanonicalSeed>),
    ExternalSeed(&'static str),
}
pub(crate) struct Record {
    pub value: SessionValue,
    pub fact: Fact,
}
#[derive(Default)]
pub(crate) struct ConstructionRecords {
    records: Vec<Record>,
}
impl ConstructionRecords {
    // This closes only recorded constructor/array input edges, not all physical
    // storage. Descriptor state, seeds and memo transitions need separate proof.
    pub(crate) fn matches_recorded_inputs(
        &self,
        session: &mut Session,
        root: &SessionValue,
    ) -> Result<bool, SessionError> {
        self.check_recorded_inputs(session, root, u64::MAX)
    }
    fn check_recorded_inputs(
        &self,
        session: &mut Session,
        root: &SessionValue,
        hash_mask: u64,
    ) -> Result<bool, SessionError> {
        let _request = session.operation_budget_scope()?;
        let mut meter = InputIndex { session, hash_mask };
        let mut index = TryOrderedMap::<u64, usize>::default();
        let bytes = self
            .records
            .len()
            .checked_mul(std::mem::size_of::<Option<usize>>())
            .ok_or_else(|| SessionError::Host(wasmtime::Error::msg("Input index overflow")))?;
        meter.charge(bytes as u64)?;
        let mut collisions = Vec::new();
        collisions
            .try_reserve_exact(self.records.len())
            .map_err(|_| {
                SessionError::Host(wasmtime::Error::msg("Input index allocation failed"))
            })?;
        // No guest execution or guest allocation occurs while this ephemeral
        // identity-hash index is live. Collision chains always use ref_eq.
        for (id, record) in self.records.iter().enumerate() {
            let hash = meter.hash(&record.value)?;
            let prior = index.get(&hash, &mut meter)?.copied();
            collisions.push(prior);
            index.insert(hash, id, &mut meter)?;
        }
        let mut valid = meter.contains(&index, &collisions, &self.records, root)?;
        valid &= self.check_input_edges(&mut meter, &index, &collisions)?;
        Ok(valid)
    }
    fn check_input_edges(
        &self,
        meter: &mut InputIndex<'_>,
        index: &TryOrderedMap<u64, usize>,
        collisions: &[Option<usize>],
    ) -> Result<bool, SessionError> {
        let mut valid = true;
        for record in &self.records {
            meter.charge(1)?;
            match &record.fact {
                Fact::Array(fact) => {
                    for value in fact.inputs() {
                        valid &= meter.contains(index, collisions, &self.records, value)?;
                    }
                }
                Fact::Constructor(fact) => {
                    for value in fact.inputs() {
                        valid &= meter.contains(index, collisions, &self.records, value)?;
                    }
                }
                Fact::ExternalSeed(_) => valid = false,
                Fact::Scalar(_) => {}
                Fact::CanonicalSeed(_) => {}
            }
        }
        Ok(valid)
    }
    pub(crate) fn push(
        &mut self,
        session: &mut Session,
        value: SessionValue,
        fact: Fact,
    ) -> Result<(), SessionError> {
        session.charge_host_work(1)?;
        if self.records.len() == self.records.capacity() {
            let count = self
                .records
                .capacity()
                .checked_mul(2)
                .ok_or_else(|| {
                    SessionError::Host(wasmtime::Error::msg(
                        "Construction record capacity overflow",
                    ))
                })?
                .max(4);
            let bytes = count
                .checked_add(self.records.len())
                .and_then(|n| n.checked_mul(std::mem::size_of::<Record>()))
                .ok_or_else(|| {
                    SessionError::Host(wasmtime::Error::msg(
                        "Construction record allocation overflow",
                    ))
                })?;
            session.charge_host_work(bytes as u64)?;
            self.records
                .try_reserve_exact(count - self.records.len())
                .map_err(|_| {
                    SessionError::Host(wasmtime::Error::msg(
                        "Construction record allocation failed",
                    ))
                })?;
        }
        self.records.push(Record { value, fact });
        Ok(())
    }
    pub(crate) fn len(&self) -> usize {
        self.records.len()
    }
    pub(crate) fn external_seeds(&self, session: &mut Session) -> Result<usize, SessionError> {
        let mut count = 0;
        for record in &self.records {
            session.charge_host_work(1)?;
            if let Fact::ExternalSeed(name) = &record.fact {
                session.charge_host_work(name.len() as u64)?;
                count += 1;
            }
        }
        Ok(count)
    }
    pub(crate) fn matches_direct_facts(&self, session: &mut Session) -> Result<bool, SessionError> {
        let _request = session.operation_budget_scope()?;
        let mut valid = true;
        for record in &self.records {
            session.charge_host_work(1)?;
            // Never short-circuit later inspection/budget/interrupt failures.
            valid &= match &record.fact {
                Fact::Scalar(fact) => fact.matches(session, &record.value)?,
                Fact::Array(fact) => fact.matches(session, &record.value)?,
                Fact::Constructor(fact) => fact.matches(session, &record.value)?,
                Fact::CanonicalSeed(fact) => fact.matches(session, &record.value)?,
                Fact::ExternalSeed(_) => false,
            };
        }
        Ok(valid)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn construction_records_missing_root_does_not_skip_later_edge_budget_errors() {
        let mut session = Session::new().unwrap();
        let root = session
            .data_scalar(&crate::portable::hir::Literal::Number(17.0))
            .unwrap();
        let mut records = ConstructionRecords::default();
        records
            .push(&mut session, root.clone(), Fact::ExternalSeed("unverified"))
            .unwrap();
        let index = TryOrderedMap::default();
        for interrupted in [false, true] {
            let request = session.operation_budget_scope().unwrap();
            let mut meter = InputIndex {
                session: &mut session,
                hash_mask: u64::MAX,
            };
            assert!(
                !meter
                    .contains(&index, &[None], &records.records, &root)
                    .unwrap()
            );
            if interrupted {
                meter.session.interrupt_handle().interrupt();
            } else {
                meter.session.store.set_fuel(0).unwrap();
            }
            let error = records
                .check_input_edges(&mut meter, &index, &[None])
                .unwrap_err();
            if interrupted {
                assert!(error.is_interrupt(), "{error:?}");
            } else {
                assert!(
                    matches!(error, SessionError::Trap(ref e) if e.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)),
                    "{error:?}"
                );
            }
            drop(request);
        }
        assert!(
            !records
                .matches_recorded_inputs(&mut session, &root)
                .unwrap()
        );
    }
    #[test]
    fn construction_records_follow_normalized_constructor_fields_not_unused_arguments() {
        for phase in [
            crate::portable::resolve::Phase::Runtime,
            crate::portable::resolve::Phase::Macro,
        ] {
            let mut session = match phase {
                crate::portable::resolve::Phase::Runtime => Session::new_repl().unwrap(),
                crate::portable::resolve::Phase::Macro => Session::new_macro().unwrap(),
            };
            session.eval("(deftype RecordedInputProbe [a b])").unwrap();
            let class = session.eval("RecordedInputProbe").unwrap();
            let unused = session
                .data_scalar(&crate::portable::hir::Literal::Number(7.0))
                .unwrap();
            let (child, fact) = session
                .data_scalar_with_inputs(&crate::portable::hir::Literal::Number(11.0))
                .unwrap();
            let descriptor = session.data_descriptor(&class, true).unwrap();
            session
                .inspect(&descriptor, |mut store, value| {
                    let descriptor = value.unwrap_anyref().unwrap().as_struct(&store)?.unwrap();
                    let schema = descriptor
                        .field(&mut store, 1)?
                        .unwrap_anyref()
                        .unwrap()
                        .as_array(&store)?
                        .unwrap();
                    let name = schema.get(&mut store, 0)?;
                    schema.set(&mut store, 1, name)?;
                    Ok(())
                })
                .unwrap();
            let (parent, inputs) = session
                .data_construct_with_inputs(&class, &[&unused, &child, &unused])
                .unwrap();
            let mut records = ConstructionRecords::default();
            records
                .push(
                    &mut session,
                    parent.clone(),
                    Fact::Constructor(inputs.unwrap()),
                )
                .unwrap();
            assert!(
                !records
                    .matches_recorded_inputs(&mut session, &parent)
                    .unwrap()
            );
            // Last duplicate name wins; neither overwritten nor extra arguments
            // are retained inputs. Padding is the immutable Undefined sentinel.
            records
                .push(&mut session, child, Fact::Scalar(fact))
                .unwrap();
            session.collect().unwrap();
            assert!(
                records
                    .matches_recorded_inputs(&mut session, &parent)
                    .unwrap()
            );
            assert!(records.matches_direct_facts(&mut session).unwrap());
            let (padded, inputs) = session
                .data_construct_with_inputs(&class, &[&unused])
                .unwrap();
            let mut padded_records = ConstructionRecords::default();
            padded_records
                .push(
                    &mut session,
                    padded.clone(),
                    Fact::Constructor(inputs.unwrap()),
                )
                .unwrap();
            assert!(
                padded_records
                    .matches_recorded_inputs(&mut session, &padded)
                    .unwrap()
            );
            assert!(padded_records.matches_direct_facts(&mut session).unwrap());
            session.reset().unwrap();
            assert!(matches!(
                records.matches_recorded_inputs(&mut session, &parent),
                Err(SessionError::ForeignValue)
            ));
        }
    }
    #[test]
    fn construction_records_require_independent_child_facts_and_exact_root() {
        let mut session = Session::new().unwrap();
        let (child, fact) = session
            .data_scalar_with_inputs(&crate::portable::hir::Literal::String(vec![17]))
            .unwrap();
        let (parent, array) = session.data_array_with_inputs(&[&child, &child]).unwrap();
        let mut records = ConstructionRecords::default();
        records
            .push(&mut session, parent.clone(), Fact::Array(array))
            .unwrap();
        session.collect().unwrap();
        assert!(records.matches_direct_facts(&mut session).unwrap());
        assert!(
            !records
                .matches_recorded_inputs(&mut session, &parent)
                .unwrap()
        );
        records
            .push(&mut session, child, Fact::Scalar(fact))
            .unwrap();
        session.collect().unwrap();
        assert!(
            records
                .matches_recorded_inputs(&mut session, &parent)
                .unwrap()
        );
        let other = session
            .data_scalar(&crate::portable::hir::Literal::String(vec![17]))
            .unwrap();
        assert!(
            !records
                .matches_recorded_inputs(&mut session, &other)
                .unwrap()
        );
        // Force distinct references into one bucket: hash equality must never
        // substitute for GC-reference equality, including after collection.
        assert!(
            records
                .check_recorded_inputs(&mut session, &parent, 0)
                .unwrap()
        );
        assert!(
            !records
                .check_recorded_inputs(&mut session, &other, 0)
                .unwrap()
        );
        for interrupted in [false, true] {
            let request = session.operation_budget_scope().unwrap();
            if interrupted {
                session.interrupt_handle().interrupt();
            } else {
                session.store.set_fuel(1).unwrap();
            }
            let error = records
                .matches_recorded_inputs(&mut session, &parent)
                .unwrap_err();
            if interrupted {
                assert!(error.is_interrupt(), "{error:?}");
            } else {
                assert!(
                    matches!(error, SessionError::Trap(ref e) if e.downcast_ref::<wasmtime::Trap>() == Some(&wasmtime::Trap::OutOfFuel)),
                    "{error:?}"
                );
            }
            drop(request);
            assert!(
                records
                    .matches_recorded_inputs(&mut session, &parent)
                    .unwrap()
            );
        }
        let mut foreign = Session::new().unwrap();
        let foreign_root = foreign
            .data_scalar(&crate::portable::hir::Literal::Nil)
            .unwrap();
        assert!(matches!(
            records.matches_recorded_inputs(&mut session, &foreign_root),
            Err(SessionError::ForeignValue)
        ));
        // A present child record is insufficient if its direct facts changed.
        // The low-level test below changes the UTF-16 storage directly; it does
        // not depend on source string indexing adapters or guest equality.
        let child = match &records.records[1].fact {
            Fact::Scalar(_) => &records.records[1].value,
            _ => unreachable!(),
        };
        session
            .inspect(child, |mut store, value| {
                let array = value.unwrap_anyref().unwrap().as_array(&store)?.unwrap();
                array.set(&mut store, 0, wasmtime::Val::I32(99))?;
                Ok(())
            })
            .unwrap();
        assert!(
            records
                .matches_recorded_inputs(&mut session, &parent)
                .unwrap()
        );
        assert!(!records.matches_direct_facts(&mut session).unwrap());
    }
    #[test]
    fn construction_records_false_seed_does_not_hide_later_fuel_error() {
        let mut session = Session::new().unwrap();
        let (value, fact) = session
            .data_scalar_with_inputs(&crate::portable::hir::Literal::Nil)
            .unwrap();
        let mut records = ConstructionRecords::default();
        records
            .push(
                &mut session,
                value.clone(),
                Fact::ExternalSeed("unverified"),
            )
            .unwrap();
        records
            .push(&mut session, value, Fact::Scalar(fact))
            .unwrap();
        let request = session.operation_budget_scope().unwrap();
        session.store.set_fuel(1).unwrap();
        let error = records.matches_direct_facts(&mut session).unwrap_err();
        assert!(
            matches!(error,SessionError::Trap(ref error) if error.downcast_ref::<wasmtime::Trap>()==Some(&wasmtime::Trap::OutOfFuel)),
            "{error:?}"
        );
        drop(request);
        assert!(!records.matches_direct_facts(&mut session).unwrap());
    }
}
