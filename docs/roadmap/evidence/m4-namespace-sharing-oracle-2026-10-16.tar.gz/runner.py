import subprocess,time,pathlib,json,hashlib
p=pathlib.Path(__file__).parent
for attempt in ['run1','run2']:
 before=hashlib.sha256((p/'src/suss_oracle/namespace_sharing.cljs').read_bytes()).hexdigest()
 start=time.time()
 with (p/(attempt+'.log')).open('wb') as log:
  code=subprocess.call(['bash',str(p/'run.sh')],stdout=log,stderr=subprocess.STDOUT)
 receipt={'exit':code,'seconds':time.time()-start,'source_sha256':before,'source_unchanged':before==hashlib.sha256((p/'src/suss_oracle/namespace_sharing.cljs').read_bytes()).hexdigest()}
 (p/(attempt+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(attempt,json.dumps(receipt),flush=True)
 if code:break
 lines=(p/(attempt+'.log')).read_text().splitlines();obs=json.loads(next(x for x in reversed(lines) if x.startswith('{"pin"')))
 (p/(attempt+'-observations.json')).write_text(json.dumps(obs,indent=2)+'\n')
