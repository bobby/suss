import json,pathlib,subprocess,hashlib,tarfile,io
p=pathlib.Path(__file__).parent
xs=[json.loads((p/f'run{i}-observations.json').read_text()) for i in [1,2]]
assert xs[0]==xs[1], 'ordered raw rows/events differ'
x=xs[0];assert len(x['rows'])==5
refs=[{v['name']:v for v in row['references']} for row in x['rows']]
def identity(i,name):
 v=refs[i][name];return v.get('reference',{}).get('id') if v['present'] else None
def same(indices,name):return len({identity(i,name) for i in indices})==1 and identity(indices[0],name) is not None
stable=['raw-watched','raw-callable','watched-meta','watched-audit','callable-meta','callable-method-params','callable-arglists-meta']
assert all(same(list(range(5)),n) for n in stable)
assert same([0,1,2,3],'ns') and same([0,1,2,3],'defs')
assert identity(4,'ns')==identity(2,'live-ns') and identity(4,'ns')!=identity(0,'ns')
assert identity(4,'defs')==identity(2,'live-defs') and identity(4,'defs')!=identity(0,'defs')
lexical=['locals','captured-local','captured-init','captured-info','localfn','localfn-init','localfn-methods','localfn-first-method','localfn-first-params','localfn-first-body']
assert all(same([0,1,2,3],n) for n in lexical)
assert all(not refs[4][n]['present'] for n in lexical if n!='locals')
assert len({identity(i,'env') for i in range(5)})==5
assert len({identity(i,n) for i in range(5) for n in ['resolved-info','second-resolved-info','resolved-callable-info']})==15
assert all(identity(i,'resolved-meta')==identity(i,'watched-meta') and identity(i,'resolved-callable-method-params')==identity(i,'callable-method-params') for i in range(5))
assert all(refs[i]['callable-arglists']['reference']=={'kind':'nil'} for i in range(5))
assert [e['value'] for e in x['selected-numeric-hashes']]==list(range(101,110))
assert all(e['stage']=='read-and-analyze-watched' for e in x['selected-numeric-hashes'])
pin=pathlib.Path('/home/bobby/Work/code/bobby/suss/clojurescript');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=pin,text=True).strip();clean=not subprocess.check_output(['git','status','--porcelain'],cwd=pin,text=True);assert head==x['pin'] and clean
receipt={'pin':head,'pin_clean':clean,'node':subprocess.check_output(['node','--version'],text=True).strip(),'runs':[json.loads((p/f'run{i}-receipt.json').read_text()) for i in [1,2]],'ordered_rows_and_hash_events_identical':True,'macro_invocations_per_run':5,'reference_slots_per_invocation':len(x['rows'][0]['references']),'outer_envs_all_distinct':True,'resolved_infos_all_distinct':True,'persistent_raw_declaration_paths_all_five':stable,'lexical_paths_shared_first_four':lexical,'new_namespace_container_after_unrelated_def':True,'old_lexical_namespace_snapshot_retained':True,'missing_final_scope_paths':[n for n in lexical if n!='locals'],'nil_callable_arglists':True,'selected_metadata_numeric_hashes':list(range(101,110)),'failed_attempts':[],'limits':x['limits'],'additional_limits':'Actual callable :arglists is nil: no positive nonnil arglists identity claim. method-params/arglists-meta object references are recorded without forcing their contents. No direct generic constructor instrumentation: selected hash events plus actual object references are evidence only for this fixture. New final environment intentionally has no prior lexical locals; absent paths are not successes. No tested declaration redefinition/revision mutation; unrelated-def only. No Suss source/storage proof, root mutation, implementation or performance claim.'}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(p/'README.txt').write_text('One bounded pinned CLJS actual-macro namespace/declaration sharing probe.\nTwo exit0 compile+Node runs,5actual macro invocations each; no projected map is used as identity authority. Observer stores actual env/ns/live namespace/defs/raw declarations/callable fields/local initializer ASTs/resolved info references. WeakMap IDs are assigned only after all analyzer activity. Numeric/boolean/nil/missing distinctions retained; complete ordered rows, field-key structures, hash windows and entry/exit markers retained.\nTwo before and two after an unrelated def are inside the same lexical scope; one final invocation uses a fresh top-level environment. Existing lexical env captures remain old snapshots even when live namespace advances. Fresh outer env/source positions and resolved info stay distinct. Actual raw declaration children/method params/metadata retain references; fresh outer info shallowly shares those values.\nCore hash wrapper delegates exact original unary hash; core-cache setup precedes observation. Selected metadata numbers101..109 hash during read/analyze declaration only. All windows include actual surrounding reader/analyzer work and observer lookups/resolution; counts are not exclusive construction counts. Constructors are not replaced; callback/construction policy beyond observed selected hashes remains unknown. Hash var and NS_CACHE contents restored in finally. Unexpected errors escape; missing final lexical paths explicit.\nArgLists is present nil, not a positive object-identity observation; lazy callable subgraphs are not forced by projection. No arbitrary equal-content snapshot interning permission, no declaration revision/redefinition case, no Suss native transport/storage authority/performance/acceptance claim. No production edits, new branch or cache implementation. Cached CLI/JRE/Maven toolchain external prerequisite.\nPinned source citations: analyzer.cljc587get-namespace,725empty-env,1248resolve-default,2092..2172def persistence,4111..4165analyze-symbol,4282macro env pass-through. Source/notices/licenses, generated executable JS/dependencies, exact source/commands/logs/receipts retained.\n')
files=sorted(f for f in p.rglob('*') if f.is_file() and '.cpcache' not in f.parts and 'clj-cache' not in f.parts)
m={'schema':1,'files':{str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
out=p.parent/'m4-namespace-sharing-oracle-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)))
 data=(json.dumps(m,indent=2)+'\n').encode();i=tarfile.TarInfo('MANIFEST.json');i.size=len(data);t.addfile(i,io.BytesIO(data))
with tarfile.open(out,'r:gz') as t:
 assert len(t.getmembers())==len(files)+1
 for n,h in m['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
print(json.dumps({'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(files),'source_sha256':receipt['runs'][0]['source_sha256']},indent=2))
