from pathlib import Path
import hashlib, io, json, subprocess, tarfile

r = Path('/home/bobby/Work/code/bobby/suss-m4-cold-memo-leaves')
c = Path('/home/bobby/.cache/suss-m4-work')
v = json.loads((c/'cold-memo-final-result.json').read_text())
a = json.loads((c/'cold-memo-final-observations.json').read_text())
f = json.loads((c/'cold-memo-ancestors-focused-result.json').read_text())
assert v['current'] is None and v['source_unchanged']
assert len(v['stages']) == 13 and all(s['exit'] == 0 for s in v['stages'])
assert len(a['rows']) == 48 and all(row['actual'] == row['expected'] for row in a['rows'])
assert f['source_unchanged'] and all(s['exit'] == 0 for s in f['stages'][:2])
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest() == h for p,h in v['freeze'].items())
files = {}
for pattern in ['cold-memo-initialization-only-*', 'cold-memo-diag-*', 'cold-memo-ancestors-focused-*', 'cold-memo-final-*']:
    for p in c.glob(pattern):
        if p.is_file(): files['cache/'+p.name] = p.read_bytes()
for name in ['run-cold-memo-leaf.py', 'run-cold-memo-leaf-validation.py', 'run-cold-memo-diag.py', 'run-cold-memo-ancestors-focused.py', 'run-cold-memo-final-validation.py', 'cold-memo-identifier-before-decoder-correction.rs', 'package-cold-memo-final.py']:
    files['cache/'+name] = (c/name).read_bytes()
changed = subprocess.check_output(['git','diff','--name-only','10fb544','--','crates','runtime/bootstrap'],cwd=r,text=True).splitlines()
changed += ['crates/suss-compile/tests/form_bridge_identifier_hash.rs', 'crates/suss-compile/src/portable_macros/memo_leaf_tests.rs', 'tests/oracle/metadata-memo-leaf-observations.json']
for p in sorted(set(changed)): files['source/'+p] = (r/p).read_bytes()
files['implementation.patch'] = subprocess.check_output(['git','diff','--binary','10fb544','--','crates','runtime/bootstrap'],cwd=r)
files['limits.txt'] = b'''Native leaf comparisons cover &env metadata/leaf views in both caller phases, not the oracle's resolve/AST views. No full workspace, final CI, or whole #257 acceptance claim. Captured-original-nonnil eligibility and compiled constant lowering are unchanged. Initialization-only public regression and diagnostic test failure are preserved. Diagnostic driver raised AttributeError during its final exit after writing the native failure receipt/source archive; this is not native success. Focused direct identifier E0308 is preserved; only its decoder was corrected for the final run.\n'''
manifest = {p:hashlib.sha256(b).hexdigest() for p,b in files.items()}
files['manifest.json'] = json.dumps({'base':'10fb544498dc6ac9fd1977f262a0034b61dbfb5c','oracle_head':'69d74d0cd18aeaecfaee158b53ad55de5e4977cf','payloads':manifest},indent=2).encode()
p = r/'docs/roadmap/evidence/m4-cold-memo-ancestors-2026-10-16.tar.gz'
with tarfile.open(p,'w:gz') as t:
    for name,b in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(p) as t:
    for name,h in manifest.items(): assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h
print(hashlib.sha256(p.read_bytes()).hexdigest(),len(files),'entries')
