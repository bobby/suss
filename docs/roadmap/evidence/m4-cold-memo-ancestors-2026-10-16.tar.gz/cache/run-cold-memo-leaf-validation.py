from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-cold-memo-leaves');c=Path('/home/bobby/.cache/suss-m4-work')
env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'cold-memo-leaf-target')
prior=json.loads((c/'cold-memo-leaf-result.json').read_text());assert prior['current'] is None and prior['stages'][-1]['exit']==0
freeze=prior['freeze'];assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
result={'base':'10fb544','freeze':freeze,'stages':[],'current':None,'source_unchanged':True};out=c/'cold-memo-leaf-validation-result.json'
stages=[('public',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_cumulative_fuel','--','--test-threads=2','--nocapture']),('identifier-corpus',['cargo','test','-p','suss-compile','--locked','--test','portable_symbol_conversion','retained_identifier_dependency_matches_shared_pinned_corpus_in_both_phases','--','--test-threads=2']),('identifier-decoder',['cargo','test','-p','suss-compile','--locked','--test','portable_value_decoder','identifier','--','--test-threads=2'])]
for name,selector in [('scoped','scoped_memo_stores_'),('receipts','receipt_tests'),('domain','write_domain::tests'),('identifier-facts','source_storage_invariants_reject_forged_identifier_fqn_after_gc')]:
 stages.append((name,['cargo','test','-p','suss-compile','--lib','--locked',selector,'--','--test-threads=2']))
stages.append(('provenance',['python3','scripts/check_record_macro_provenance.py']))
for name,cmd in stages:
 result['current']=name;out.write_text(json.dumps(result,indent=2));start=time.time()
 with (c/f'cold-memo-leaf-validation-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 result['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start});result['current']=None
 result['source_unchanged']=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in freeze.items());out.write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='freeze'},indent=2))
raise SystemExit(0 if all(x['exit']==0 for x in result['stages']) else 1)
