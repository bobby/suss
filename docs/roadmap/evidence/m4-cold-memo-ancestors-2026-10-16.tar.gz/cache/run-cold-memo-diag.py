from pathlib import Path
import subprocess,time,json,os,hashlib,tarfile
r=Path('/home/bobby/Work/code/bobby/suss-m4-cold-memo-leaves');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'cold-memo-leaf-target')
result={'stages':[],'current':None};out=c/'cold-memo-diag-result.json'
for name,cmd in [('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('native',['cargo','test','-p','suss-compile','--lib','--locked','scoped_memo_stores_cold_canonical_child_inside_custom_parent','--','--test-threads=2','--nocapture'])]:
 if name=='native':env['SUSS_MEMO_DIAG']='1'
 start=time.time();result['current']=name;out.write_text(json.dumps(result,indent=2))
 with (c/f'cold-memo-diag-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 result['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start});result['current']=None;out.write_text(json.dumps(result,indent=2))
 if p.returncode and name=='bootstrap':raise SystemExit(p.returncode)
with tarfile.open(c/'cold-memo-diag-source.tar.gz','w:gz') as t:
 for p in (r/'crates/suss-compile/src').rglob('*.rs'):t.add(p,arcname=str(p.relative_to(r)))
print(json.dumps(result,indent=2));raise SystemExit(p.returncode)
