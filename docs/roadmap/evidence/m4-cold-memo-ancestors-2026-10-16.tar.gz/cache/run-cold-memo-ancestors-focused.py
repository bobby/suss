from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-cold-memo-leaves');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'cold-memo-leaf-target')
result={'stages':[],'current':None};out=c/'cold-memo-ancestors-focused-result.json'
for name,cmd in [('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']),('scoped',['cargo','test','-p','suss-compile','--lib','--locked','scoped_memo_stores_','--','--test-threads=2','--nocapture']),('direct-identifier',['cargo','test','-p','suss-compile','--locked','--test','form_bridge_identifier_hash','--','--test-threads=2'])]:
 if name=='scoped':
  paths=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.sus')]+list((r/'runtime/bootstrap').glob('*'))
  result['freeze']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 result['current']=name;out.write_text(json.dumps(result,indent=2));start=time.time()
 with (c/f'cold-memo-ancestors-focused-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 result['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start});result['current']=None
 if 'freeze' in result:result['source_unchanged']=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in result['freeze'].items())
 out.write_text(json.dumps(result,indent=2))
 if p.returncode:break
print(json.dumps({k:v for k,v in result.items() if k!='freeze'},indent=2));raise SystemExit(p.returncode)
