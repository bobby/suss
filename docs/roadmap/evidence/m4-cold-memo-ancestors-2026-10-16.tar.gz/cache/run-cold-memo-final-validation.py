from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path('/home/bobby/Work/code/bobby/suss-m4-cold-memo-leaves');c=Path('/home/bobby/.cache/suss-m4-work');env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']=str(c/'cold-memo-leaf-target')
paths=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.sus')]+list((r/'runtime/bootstrap').glob('*'));freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
result={'base':'10fb544','stages':[],'freeze':freeze,'source_unchanged':True,'current':None};out=c/'cold-memo-final-result.json'
stages=[('direct-identifier',['cargo','test','-p','suss-compile','--locked','--test','form_bridge_identifier_hash','--','--test-threads=2']),('leaf',['cargo','test','-p','suss-compile','--lib','--locked','native_memo_leaf_','--','--test-threads=2','--nocapture']),('public',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_cumulative_fuel','--','--test-threads=2','--nocapture']),('cross-invocation',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_cross_invocation_identity_probe','--','--test-threads=2','--nocapture']),('identifier-corpus',['cargo','test','-p','suss-compile','--locked','--test','portable_symbol_conversion','retained_identifier_dependency_matches_shared_pinned_corpus_in_both_phases','--','--test-threads=2']),('identifier-decoder',['cargo','test','-p','suss-compile','--locked','--test','portable_value_decoder','identifier','--','--test-threads=2'])]
for name,selector in [('receipts','receipt_tests'),('domain','write_domain::tests'),('identifier-facts','source_storage_invariants_reject_forged_identifier_fqn_after_gc'),('bridge','portable_macro_data::identity_tests'),('observer','ihash_dispatch_boundary_'),('canonical-errors','private_memo_bridge_preserves_')]:
 stages.append((name,['cargo','test','-p','suss-compile','--lib','--locked',selector,'--','--test-threads=2']))
stages.append(('provenance',['python3','scripts/check_record_macro_provenance.py']))
for name,cmd in stages:
 result['current']=name;out.write_text(json.dumps(result,indent=2));start=time.time()
 with (c/f'cold-memo-final-{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 result['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start});result['current']=None
 result['source_unchanged']=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in freeze.items());out.write_text(json.dumps(result,indent=2))
 if name=='direct-identifier' and p.returncode:break
rows=[]
for line in (c/'cold-memo-final-leaf.log').read_text().splitlines() if (c/'cold-memo-final-leaf.log').exists() else []:
 if line.startswith('NATIVE_MEMO_LEAF '):rows.append(json.loads(line[len('NATIVE_MEMO_LEAF '):]))
(c/'cold-memo-final-observations.json').write_text(json.dumps({'rows':rows,'complete_rows':len(rows),'expected_rows':48},indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='freeze'},indent=2));raise SystemExit(0 if all(x['exit']==0 for x in result['stages']) else 1)
