from pathlib import Path
import os,signal,json,datetime,hashlib
b=Path(__file__).parent;run=b/'when-let-d1-full-baseline';out=b/'when-let-d1-baseline-stop-observation';out.mkdir(exist_ok=True);runner=3855333;cargo=3855347
assert b'run-when-let-d1-full-baseline.py' in Path(f'/proc/{runner}/cmdline').read_bytes();assert b'cargo\x00test\x00--workspace' in Path(f'/proc/{cargo}/cmdline').read_bytes()
rows={}
for d in Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:
  st=(d/'stat').read_text();tail=st[st.rindex(')')+2:].split();rows[int(d.name)]={'pid':int(d.name),'ppid':int(tail[1]),'pgid':int(tail[2]),'starttime':tail[19],'cmdline':(d/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
 except (FileNotFoundError,ProcessLookupError,PermissionError):pass
assert rows[cargo]['ppid']==runner;owned={cargo}
while True:
 new=owned|{pid for pid,r in rows.items() if r['ppid'] in owned}
 if new==owned:break
 owned=new
assert all(rows[pid]['pgid']==runner for pid in owned)
root=Path('/home/bobby/Work/code/bobby/suss-m4-when-let-ci-provenance');freeze=json.loads((run/'before-freeze.json').read_text());changed=[k for k,h in freeze.items() if hashlib.sha256((root/k).read_bytes()).hexdigest()!=h];assert len(freeze)==1846 and not changed
for name in ['receipt.json','workspace-baseline.log','before-freeze.json']:(out/('pre-stop-'+name)).write_bytes((run/name).read_bytes())
r={'handle':66647,'driver':runner,'cargo':cargo,'reason':'Explicitly authorized after confirmed entire-Jank reconciliation pass; stale source/test-expectation fixes require final1a85baseline, not timeout','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freeze_count':len(freeze),'changed':changed,'owned_processes':[rows[x] for x in sorted(owned)],'signals':[]}
for pid in sorted(owned,reverse=True):
 try:
  st=Path(f'/proc/{pid}/stat').read_text();tail=st[st.rindex(')')+2:].split();assert tail[19]==rows[pid]['starttime'];os.kill(pid,signal.SIGINT);r['signals'].append({'pid':pid,'signal':'SIGINT'})
 except (FileNotFoundError,ProcessLookupError):r['signals'].append({'pid':pid,'already_exited':True})
(out/'stop-request.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
