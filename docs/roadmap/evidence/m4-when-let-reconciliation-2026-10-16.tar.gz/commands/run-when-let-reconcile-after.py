from pathlib import Path
import os,subprocess,json,hashlib,time,shutil,re
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-when-let-baseline-reconcile');run=cache/'when-let-reconcile-after';run.mkdir(exist_ok=False)
prior=json.loads((cache/'when-let-reconcile-before/before-freeze.json').read_text());expected={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in prior};allowed={'crates/suss-compile/tests/compile_expr.rs','tests/oracle/clojure-test-suite-known-failures.json'};assert {p for p in prior if prior[p]!=expected[p]}==allowed
(run/'before-freeze.json').write_text(json.dumps(expected,indent=2)+'\n')
for rel in expected:
 p=run/'before'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,p)
(run/'candidate.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=root))
packet=json.loads((cache/'when-let-baseline-reconcile/original-regressions.json').read_text());commands=[(t['test'],['cargo','test','-p','suss-compile','--locked','--test','compile_expr',t['test'],'--','--exact','--test-threads=2']) for t in packet['tests']]
commands += [('remaining-unsupported-guard',['cargo','test','-p','suss-compile','--locked','--test','compile_expr','prototype_cases_awaiting_compiled_support','--','--exact','--test-threads=2']),('entire-jank-baseline',['cargo','test','-p','suss-compile','--locked','--test','clojure_test_suite','clojure_test_suite_matches_reviewed_baseline','--','--exact','--test-threads=2','--nocapture'])]
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(cache/'m4-cost-diagnostic-target'),PYTHONDONTWRITEBYTECODE='1',SUSS_CLOJURE_TEST_SUITE_CAPTURE=str(run))
for key in ['SUSS_HIR_COW_TRACE','SUSS_SOURCE_CHILD_FUEL_TRACE','SUSS_SOURCE_MATERIALIZE_FUEL_TRACE','SUSS_INPUT_INDEX_TRACE','SUSS_WHEN_LET_CAPTURE','SUSS_CLOJURE_TEST_SUITE_WRITE']:env.pop(key,None)
state={'head':packet['head'],'current':None,'driver_pid':os.getpid(),'input_count':len(expected),'environment':{'CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':env['CARGO_TARGET_DIR'],'SUSS_CLOJURE_TEST_SUITE_CAPTURE':str(run),'RUSTFLAGS_set_by_driver':False},'stages':[],'scope':'Exact four original bodies re-enabled only after unchanged ignored4pass proof. Exactly4ignore/4unsupported rows/1stale namespace removed. Entire suite expected remaining known failures unchanged; gate success is not blanket conformance.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in expected}
for name,cmd in commands:
 assert freeze()==expected
 state['current']=name;entry={'name':name,'command':cmd,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())};state['stages'].append(entry);start=time.monotonic()
 with (run/(name+'.log')).open('wb') as log:
  child=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);entry['cargo_pid']=child.pid;save();print(json.dumps(entry),flush=True);code=child.wait()
 actual=freeze();entry.update(exit=code,seconds=time.monotonic()-start,changed=[p for p in expected if expected[p]!=actual[p]],summaries=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',(run/(name+'.log')).read_text(errors='replace')));save();print(json.dumps(entry),flush=True)
 if actual!=expected:break
state['current']=None;state['inputs_unchanged']=freeze()==expected;save();(run/'after-freeze.json').write_text(json.dumps(freeze(),indent=2)+'\n');print(json.dumps(state),flush=True)
