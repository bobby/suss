from pathlib import Path
import json,hashlib,tarfile,io
cache=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-when-let-baseline-reconcile')
files={};tuples={}
sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['when-let-reconcile-before','when-let-reconcile-after']:
 directory=cache/name
 frozen=json.loads((directory/'before-freeze.json').read_text());tuples[name]=frozen
 for rel,digest in frozen.items():
  data=(directory/'before'/rel).read_bytes();assert sha(data)==digest
  files['inputs/'+digest]=data
 for path in directory.rglob('*'):
  if path.is_file() and path.relative_to(directory).parts[0]!='before':files['runs/'+name+'/'+str(path.relative_to(directory))]=path.read_bytes()
for name in ['when-let-baseline-reconcile','when-let-d1-baseline-stop-observation']:
 for path in (cache/name).rglob('*'):
  if path.is_file():files['runs/'+name+'/'+str(path.relative_to(cache/name))]=path.read_bytes()
for name in ['run-when-let-reconcile-before.py','run-when-let-reconcile-after.py','stop-when-let-d1-baseline-authorized.py','package-when-let-reconciliation.py']:
 files['commands/'+name]=(cache/name).read_bytes()
manifest={'purpose':'Frozen original four ignored regressions and exact re-enabled tuple, full pinned known-failure comparison, and preserved interrupted stale-source baseline. No full-baseline or final-CI success claim.','tested_source_publication':'1a85c8dbd8a5affac85e6091b0fa30782a75e985','input_storage':'For each tuple relative path and digest below, exact bytes are inputs/<digest>. Duplicate bytes stored once.','tuples':tuples,'payloads':{p:sha(b) for p,b in sorted(files.items())}}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=root/'docs/roadmap/evidence/m4-when-let-reconciliation-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as archive:
 for name,data in sorted(files.items()):
  item=tarfile.TarInfo(name);item.size=len(data);archive.addfile(item,io.BytesIO(data))
with tarfile.open(out) as archive:
 for p,h in manifest['payloads'].items():assert sha(archive.extractfile(p).read())==h
result={'archive':str(out),'sha256':sha(out.read_bytes()),'payloads':len(files),'bytes':out.stat().st_size}
(cache/'when-let-reconciliation-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
