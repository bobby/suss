from pathlib import Path
import os,subprocess,json,hashlib,time,shutil,re
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-when-let-baseline-reconcile');run=cache/'when-let-reconcile-before';run.mkdir(exist_ok=False)
keys=json.loads((cache/'when-let-ci-provenance-gates/final-freeze.json').read_text());keys.update({'tests/oracle/clojure-test-suite-known-failures.json':''})
def freeze():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in keys}
expected=freeze();(run/'before-freeze.json').write_text(json.dumps(expected,indent=2)+'\n')
for rel in expected:
 p=run/'before'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,p)
packet=json.loads((cache/'when-let-baseline-reconcile/original-regressions.json').read_text());assert expected[packet['file']]==packet['file_sha256'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head==packet['head']
cmd=['cargo','test','-p','suss-compile','--locked','--test','compile_expr','destructuring','--','--ignored','--test-threads=2'];env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(cache/'m4-cost-diagnostic-target'),PYTHONDONTWRITEBYTECODE='1')
for key in ['SUSS_HIR_COW_TRACE','SUSS_SOURCE_CHILD_FUEL_TRACE','SUSS_SOURCE_MATERIALIZE_FUEL_TRACE','SUSS_INPUT_INDEX_TRACE','SUSS_WHEN_LET_CAPTURE']:env.pop(key,None)
state={'head':head,'command':cmd,'current':'original-four-ignored','driver_pid':os.getpid(),'input_count':len(expected),'environment':{'CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':env['CARGO_TARGET_DIR'],'RUSTFLAGS_set_by_driver':False},'scope':'Four original ignored regression bodies/assertions unchanged before reconciliation. No feature source/bootstrap changes.'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
start=time.monotonic()
with (run/'original-four.log').open('wb') as log:
 child=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);state['cargo_pid']=child.pid;save();print(json.dumps(state),flush=True);code=child.wait()
s=(run/'original-four.log').read_text(errors='replace');records=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$',s,re.M);wanted={x['test'] for x in packet['tests']};proof=code==0 and len(records)==4 and {n for n,status in records}==wanted and all(status=='ok' for n,status in records)
actual=freeze();state.update(current=None,exit=code,seconds=time.monotonic()-start,individual_records=records,exact_four_pass=proof,changed=[p for p in expected if expected[p]!=actual[p]],inputs_unchanged=expected==actual);save();(run/'after-freeze.json').write_text(json.dumps(actual,indent=2)+'\n');print(json.dumps(state),flush=True)
