# Final reconcile evidence inputs

Publication tuple1a85c8dbd8a5affac85e6091b0fa30782a75e985. The raw receipts
intentionally retain historical head896b9bc04d87ec5058a83f6f9145a688e1855db5.
Before runs exact896 unchanged. After runs896 plus candidate.patch, exactly
matching all1846 frozen inputs at1a85, including pinned CLJS source files.
source-correspondence-1a85.json provides every expected/saved/current/commit hash;
original-test-body-correspondence.json binds all4 original complete functions.
MD changes are outside the declared freeze. No production/bootstrap changes.

Include ALL files under these three cache directories, preserving relative paths:
when-let-reconcile-before/ (raw unchanged ignored4pass proof and1846snapshot),
when-let-reconcile-after/ (raw active4+guard1+wholeJank1, full actual observations,
1846snapshot, candidate patch, both freezes and receipt),
when-let-baseline-reconcile/ (original bodies, removed namespace failure,
prior-d1 capture labelled historical, fresh whole-suite comparison, source
correspondence and final summary). Also include both run-when-let-reconcile-*.py
drivers. packaging-inputs.json hashes these inputs, excluding itself.

Whole Jank gate exit0,568.51s test/571.620242s command. Raw943host pass21fail,
17guest judgments,188namespace failures,4873unexecuted,0skip. Exact remaining
failure catalogue matches; only when-let namespace error removed. All12ordered
when-let assertions from the FRESH WHOLE capture host-pass with no exceptions,
missing/skips/guest judgments. Those12 are a subset of943, never additional.

Original4pass plus after5focused pass plus Jank wrapper1pass are10 Rust
executions across6distinct test names. Original values30,2,30,30 preserved.
No unknown results converted to passes; this is known-failure baseline agreement,
not whole-suite acceptance. m4-cost-diagnostic-target released; no further Cargo.
The new required workspace baseline90784 is separate/main-owned and not included
as a completed result. No source edits or publication by the evidence reviewer.
