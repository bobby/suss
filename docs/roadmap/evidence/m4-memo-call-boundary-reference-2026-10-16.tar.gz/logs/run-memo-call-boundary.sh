#!/bin/sh
set -eu
cd /home/bobby/Work/code/bobby/suss
test "$(git -C clojurescript rev-parse HEAD)" = c4295f303100bbf5afac449242d30bca1126f1a1
test -z "$(git -C clojurescript status --porcelain)"
export PATH=/home/bobby/.cache/suss-m4-oracle-tools/bin:/home/bobby/.cache/suss-m4-oracle-tools/jdk-21.0.8+9-jre/bin:$PATH
cd tests/oracle
CLJ_CONFIG=/tmp/suss-oracle-clojure-config CLJ_CACHE=/tmp/suss-oracle-clojure-cache clojure -J-Xmx1g -J-XX:ActiveProcessorCount=2 -Srepro -Sdeps '{:paths ["src" "out/generated" "/home/bobby/.cache/suss-m4-work/memo-call-boundary-draft/src"]}' -M -m cljs.main -co '{:force true :cache-analysis false :target :nodejs :output-to "/home/bobby/.cache/suss-m4-work/memo-call-boundary-draft/out.js" :output-dir "/home/bobby/.cache/suss-m4-work/memo-call-boundary-draft/out" :optimizations :none :source-map false}' -c suss-oracle.metadata-memo-call-boundary
cd /
node /home/bobby/.cache/suss-m4-work/memo-call-boundary-draft/out.js
