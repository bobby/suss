from pathlib import Path
import io,json,hashlib,tarfile,subprocess
b=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-realized-lazy-object-lookup');out=b/'m4-realized-lazy-object-lookup-2026-10-17.tar.gz';assert not out.exists();files={};tuples={};origins={}
sha=lambda d:hashlib.sha256(d).hexdigest()
def add(n,p):
 d=p.read_bytes();files[n]=d;origins[str(p)]=sha(d)
for i in range(1,5):
 base=b/f'live-lazy-object-diagnostic-{i}'
 for label in ['before','after-bootstrap']:
  f=base/(label+'-freeze.json')
  if not f.exists():continue
  h=json.loads(f.read_text());tuples[f'attempt{i}/{label}']=h
  for rel,digest in h.items():
   p=base/label/rel;data=p.read_bytes();assert sha(data)==digest;files['inputs/'+digest]=data;origins[str(p)]=digest
 for p in base.rglob('*'):
  if p.is_file() and p.relative_to(base).parts[0] not in ['before','after-bootstrap']:add(f'runs/attempt{i}/'+p.relative_to(base).as_posix(),p)
for p in (b/'live-lazy-object-unit-ce88795').iterdir():
 if p.is_file():add('proposal-and-review/'+p.name,p)
for i in range(1,5):
 name='run-live-lazy-object-diagnostic'+('' if i==1 else '-'+str(i))+'.py';add('commands/'+name,b/name)
add('commands/package-live-lazy-object-diagnostic.py',Path(__file__))
final=json.loads((b/'live-lazy-object-diagnostic-4/receipt.json').read_text());assert final['current'] is None and final['final_changed']==[] and all(s['exit']==0 for s in final['stages'])
# Explicit branch diff, exact extra module, no false committed-checkpoint binding yet.
files['source/tracked-diff.patch']=subprocess.check_output(['git','diff','--binary','ce88795','--','crates/suss-compile/src/portable_session.rs','runtime/bootstrap'],cwd=root)
add('source/lazy_object_cost_probe.rs',root/'crates/suss-compile/src/portable_session/lazy_object_cost_probe.rs')
report=dict(base='ce88795e8174937e64de3a8457266d29e8520950',branch='diagnostic/m4-realized-lazy-object-lookup',state='Uncommitted diagnostic candidate; API-only correction awaiting independent review; not issue fix',scope='Matched .call adapters incremental lookup-site control on original already-realized LazySeq. No production API/fixture/allowance changes.',results={'focused':'1pass0fail434filtered','rows':16,'incremental_lookup_site_per_iteration':2156,'dynamic_sval_control':4662,'matched_lookup':5231,'matched_captured':3075,'stored_s_control':19},attempts={'1':'Compile10 API errors; observer driver interrupted after compiler terminal; independent one-pass unchanged hash proof saved','2':'Compile9 reference-layer API errors; final source unchanged','3':'Compile success; expected bootstrap manifest mismatch; no setup executed','4':'Bothphase bootstrap passed; focused probe passed and2916source unchanged'},qualification=['No pure method-get-exclusive claim','No map60M saving or live replacement equivalence claim','Original94acaf probe approved; API-only d477 correction review pending','Allerrors/partialattempts preserved; target released afterterminal'],tuples=tuples,payloads={k:sha(v) for k,v in sorted(files.items())})
files['manifest.json']=(json.dumps(report,indent=2)+'\n').encode()
for p,h in origins.items():assert sha(Path(p).read_bytes())==h
with tarfile.open(out,'w:gz') as t:
 for n,d in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size=len(d);info.mtime=0;t.addfile(info,io.BytesIO(d))
with tarfile.open(out) as t:
 for n,h in report['payloads'].items():assert sha(t.extractfile(n).read())==h
r={'path':str(out),'sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'members':len(files),'tuples':len(tuples)}
out.with_suffix(out.suffix+'.result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
