from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-realized-lazy-object-lookup');run=cache/'live-lazy-object-diagnostic-2';run.mkdir(exist_ok=False)
target=str(cache/'memo-proof-cost-target')
hits=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:
  exe=str((p/'exe').readlink()); env=(p/'environ').read_bytes().split(b'\0')
  if target in exe or ('CARGO_TARGET_DIR='+target).encode() in env:hits.append(p.name)
 except OSError:pass
assert not hits,('Target busy',hits)
base=json.loads((cache/'native-method-pass-candidate/after-bootstrap-freeze.json').read_text());paths=set(base)|{'crates/suss-compile/src/portable_session/lazy_object_cost_probe.rs'}
freeze=lambda:{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def snap(label,h):
 (run/(label+'-freeze.json')).write_text(json.dumps(h,indent=2)+'\n')
 for p in h:
  d=run/label/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,d)
expected=freeze();snap('before',expected)
assert hashlib.sha256((root/'crates/suss-compile/src/portable_session/lazy_object_cost_probe.rs').read_bytes()).hexdigest()==hashlib.sha256((cache/'live-lazy-object-unit-ce88795/api-corrected.rs').read_bytes()).hexdigest()
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',CARGO_TARGET_DIR=target)
for k in list(env):
 if k.startswith('SUSS_') and ('TRACE' in k or 'CAPTURE' in k):env.pop(k)
state={'root':str(root),'base':'ce88795e8174937e64de3a8457266d29e8520950','input_count':len(expected),'current':None,'stages':[],'env_overrides':{k:env[k] for k in ['CARGO_BUILD_JOBS','RAYON_NUM_THREADS','CARGO_TARGET_DIR']},'limits':'Diagnostic only; matched incremental lookup site versus local read; existing10M budget; original callbacks unchanged'}
def save():(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
test=['cargo','test','-p','suss-compile','--locked','--lib','portable_session::lazy_object_cost_probe::realized_lazy_object_lookup_vs_captured_original_cost','--','--exact','--test-threads=2','--nocapture']
commands=[('focused-initial',test)]
for name,cmd in commands:
 state['current']=name;row={'name':name,'command':cmd};state['stages'].append(row);save();print('starting',name,flush=True);start=time.monotonic()
 with (run/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row.update(exit=p.returncode,seconds=time.monotonic()-start);save()
state['current']=None;final=freeze();state['final_changed']=[p for p,h in expected.items() if final[p]!=h];save();print(json.dumps(state),flush=True)
