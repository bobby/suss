//! Test-only diagnostic. Wire ONLY in isolated ce88795 checkout with
//! #[cfg(test)] mod lazy_object_cost_probe; in portable_session.rs.
use super::*;
const FUEL: u64 = 10_000_000;
const SETUP: &str = r#"
(def probe-thunks 0)
(def probe-lazy (new suss.core/LazySeq nil
  (fn* [] (set! probe-thunks (+ probe-thunks 1)) (list 42)) nil nil))
(def probe-expected (.sval probe-lazy))
(def probe-dynamic (fn* [x] (.sval x)))
(if (= probe-thunks 1) true (throw "Warm thunk count not one"))
"#;
#[derive(Clone, Copy, Debug)]
enum Route { SourceWrapper, RawLiveLookup, RawCapturedMethod, StoredS }
#[test]
fn realized_lazy_object_lookup_vs_captured_original_cost() {
    let mut session = Session::new_macro().unwrap();
    assert_eq!(session.options.fuel_per_operation, FUEL);
    session.eval(SETUP).unwrap();
    let receiver = session.eval("probe-lazy").unwrap();
    let expected = session.eval("probe-expected").unwrap();
    let wrapper = session.eval("probe-dynamic").unwrap();
    let name = session.eval("\"sval\"").unwrap();
    // Exact runtime exports selected by existing source Nominal lowering.
    // Prepare handles outside measured loops; do not capture a replacement body.
    let get = session.runtime.get_func(&mut session.store, "named-property-get").unwrap();
    let member_invoke = session.runtime.get_func(&mut session.store, "object-method-invoke").unwrap();
    let invoke = session.runtime.get_func(&mut session.store, "invoke").unwrap();
    let args_new = session.runtime.get_func(&mut session.store, "args-new").unwrap();
    let field_get = session.runtime.get_func(&mut session.store, "object-field-get").unwrap();
    let captured = {
        let _op = session.operation_budget_scope().unwrap();
        let mut scope = RootScope::new(&mut session.store);
        let args = [Val::AnyRef(Some(receiver.rooted(&mut scope))), Val::AnyRef(Some(name.rooted(&mut scope)))];
        // This is the SAME NamedGet used by source .sval; ordinary member
        // dispatch below supplies exact physical receiver. No detached-call bug.
        call(&mut scope, session.runtime, get, &args, session.identity, &session.handles).unwrap()
    };
    session.collect().unwrap();
    for n in [100usize, 200] {
        for (order, routes) in [
            ("forward", [Route::SourceWrapper, Route::RawLiveLookup, Route::RawCapturedMethod, Route::StoredS]),
            ("reverse", [Route::StoredS, Route::RawCapturedMethod, Route::RawLiveLookup, Route::SourceWrapper]),
        ] {
            for route in routes {
                let _op = session.operation_budget_scope().unwrap();
                // All100/200 nested VM calls share THIS sole10M request.
                let mut scope = RootScope::new(&mut session.store);
                let recv = Val::AnyRef(Some(receiver.rooted(&mut scope)));
                let target = Val::AnyRef(Some(captured.rooted(&mut scope)));
                let wrapper_value = Val::AnyRef(Some(wrapper.rooted(&mut scope)));
                let name_value = Val::AnyRef(Some(name.rooted(&mut scope)));
                let expected_value = expected.rooted(&mut scope);
                let before = scope.get_fuel().unwrap();
                let mut completed = 0usize;
                let outcome: wasmtime::Result<()> = (|| {
                    for _ in 0..n {
                        let mut result = [Val::null_any_ref()];
                        match route {
                            Route::StoredS => field_get.call(&mut scope, &[recv.clone(), Val::I32(2)], &mut result)?,
                            Route::SourceWrapper => {
                                let mut array = [Val::null_any_ref()];
                                args_new.call(&mut scope, &[Val::I32(1)], &mut array)?;
                                array[0].unwrap_anyref().unwrap().as_array(&scope)?.unwrap()
                                    .set(&mut scope, 0, recv.clone())?;
                                invoke.call(&mut scope, &[wrapper_value.clone(), array[0].clone()], &mut result)?;
                            }
                            Route::RawLiveLookup | Route::RawCapturedMethod => {
                                let method = if matches!(route, Route::RawLiveLookup) {
                                    let mut found = [Val::null_any_ref()];
                                    get.call(&mut scope, &[recv.clone(), name_value.clone()], &mut found)?;
                                    found[0].clone()
                                } else { target.clone() };
                                // Identical ABI argument allocation/staging for
                                // raw live vs raw captured: empty source arg array.
                                let mut array = [Val::null_any_ref()];
                                args_new.call(&mut scope, &[Val::I32(0)], &mut array)?;
                                member_invoke.call(&mut scope, &[method, recv.clone(), array[0].clone()], &mut result)?;
                            }
                        }
                        let actual = result[0].unwrap_anyref().unwrap();
                        assert!(Rooted::ref_eq(&scope, &actual, &expected_value)?);
                        completed += 1;
                    }
                    Ok(())
                })();
                let after = scope.get_fuel().ok();
                println!("lazy-object-probe route={route:?} order={order} n={n} completed={completed} before={before} after={after:?} delta={:?} success={} error={:?}",
                    after.and_then(|a|before.checked_sub(a)),outcome.is_ok(),outcome.as_ref().err().map(|e|e.to_string()));
                outcome.unwrap();
                assert!(after.is_some());
                drop(scope);
                drop(_op);
                session.eval("(if (= probe-thunks 1) true (throw \"Thunk reran\"))").unwrap();
            }
        }
    }
    session.collect().unwrap();
    session.eval("(if (and (= probe-thunks 1) (identical? (.sval probe-lazy) probe-expected)) true (throw \"Final warm/GC check failed\"))").unwrap();
}
