from pathlib import Path
import re,json,sys,hashlib
p=Path(sys.argv[1]);raw=p.read_text();rows=[]
pattern=r'^lazy-object-probe route=(\w+) order=(\w+) n=(\d+) completed=(\d+) before=(\d+) after=(Some\(\d+\)|None) delta=(Some\(\d+\)|None) success=(true|false) error=(.*)$'
for m in re.finditer(pattern,raw,re.M):
 def opt(v):return int(v[5:-1]) if v.startswith('Some(') else None
 row=dict(route=m[1],order=m[2],n=int(m[3]),completed=int(m[4]),before=int(m[5]),after=opt(m[6]),delta=opt(m[7]),success=m[8]=='true',error=m[9]);rows.append(row)
rest=[dict(route=m[1],order=m[2],n=int(m[3]),success=m[4]=='true',error=m[5]) for m in re.finditer(r'^lazy-object-restoration route=(\w+) order=(\w+) n=(\d+) success=(true|false) error=(.*)$',raw,re.M)]
index={(x['route'],x['order'],x['n']):x for x in rows};paired=[]
for order in ['forward','reverse']:
 for n in [100,200]:
  a=index.get(('MatchedLookupCall',order,n));b=index.get(('MatchedCapturedCall',order,n))
  if a and b and all(x['success'] and x['completed']==n and x['delta'] is not None for x in [a,b]):paired.append(dict(order=order,n=n,lookup_site_increment=a['delta']-b['delta'],per_iteration=(a['delta']-b['delta'])/n))
slopes=[]
for route in sorted(set(x['route'] for x in rows)):
 for order in ['forward','reverse']:
  a=index.get((route,order,100));b=index.get((route,order,200))
  if a and b and a['delta'] is not None and b['delta'] is not None:slopes.append(dict(route=route,order=order,incremental_fuel_per_iteration=(b['delta']-a['delta'])/100))
r=dict(raw=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rows=rows,restoration=rest,paired_lookup_site=paired,slopes=slopes,complete=len(rows)==16 and len(rest)==16 and all(x['success'] and x['completed']==x['n'] for x in rows) and all(x['success'] for x in rest),test_summaries=re.findall(r'test result:.*',raw),limits=['Paired result measures incremental compiled lookup site versus local read, not exclusive method-get','Other controls differ in argument count/entry mechanism; no unrelated60M extrapolation','Raw Func.call error leaves observed physical-this status qualified; original Result propagated first'])
out=p.with_name('attribution.json');out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
