from pathlib import Path
import re,json,collections
c=Path('/home/bobby/.cache/suss-m4-work');lines=(c/'origin-pass-profile.log').read_text().splitlines();runs=[];current=None;stage=None;decl=None;source_stage=None;previous_hit=False
fields=['setup','parse','select','indexed','index_original','index_located','match_original','match_located']
for line in lines:
 m=re.match(r'macro-fuel (\S+) start: (\d+)',line)
 if m:
  current={'macro':m[1],'origin':dict.fromkeys(fields,0),'copies':{'full':0,'root':0},'cold':[],'keys':{'alloc':0,'reloc':0,'count':0,'hit':0,'miss':0,'error':0,'incomplete':0,'preceded_hit_alloc_reloc':0},'first_core_enrichment':[]};runs.append(current);stage=None;decl=None;source_stage=None;previous_hit=False
 if current is None:continue
 m=re.match(r'metadata-graph (\S+)',line)
 if m:stage=m[1]
 m=re.match(r'metadata-declaration (\S+) (\S+):',line)
 if m:decl=m[1];source_stage=m[2]
 if line.startswith('origin-pass '):
  row=dict(re.findall(r'(\w+)=([^ ]+)',line));r={k:int(row[k]) for k in fields};r.update(origin=row['origin'],cold=row['cold'],decl=decl,source_stage=source_stage,ok=row['ok'],span=row['span']);
  for k in fields:current['origin'][k]+=r[k]
  if r['cold']=='true':current['cold'].append(r)
  if decl=='suss.core/*print-dup*' and source_stage=='guarded':current['first_core_enrichment'].append(r)
 if line.startswith('origin-copy '):
  row=dict(re.findall(r'(\w+)=([^ ]+)',line));current['copies'][row['kind']]+=int(row['work'])
  if decl=='suss.core/*print-dup*' and source_stage=='guarded':current['first_core_enrichment'].append(row)
 if line.startswith('key-buffer ') and stage=='start':
  row={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)};k=current['keys'];k['count']+=1;k['alloc']+=row['alloc'];k['reloc']+=row['reloc'];status=row['status'];k[{0:'incomplete',1:'hit',2:'miss',3:'error'}[status]]+=1
  if previous_hit:k['preceded_hit_alloc_reloc']+=row['alloc']+row['reloc']
  previous_hit=status==1
pattern=re.compile(r'^(?:macro-fuel |metadata-(?:graph |declaration |initializer )|raw-key-profile )')
a=[l for l in (c/'plan-capacity-declaration-profile.log').read_text().splitlines() if pattern.match(l)];b=[l for l in lines if pattern.match(l)]
result={'existing_trace_identical':a==b,'before_trace_lines':len(a),'after_trace_lines':len(b),'runs':runs,'limits':['Accepted charges only; rejected requests and partial consumption by a rejected charge are excluded.','Key reserve opportunity counts old charges on keys preceded by a hit, an upper bound before new growth/reset charges, not an executed saving.','Full remaining graph and runtime tail remain unexecuted.']};(c/'origin-pass-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'trace_identical':a==b,'core':runs[-1] if runs else None},indent=2))
