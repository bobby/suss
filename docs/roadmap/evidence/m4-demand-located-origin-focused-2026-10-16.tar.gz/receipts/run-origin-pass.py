from pathlib import Path
import subprocess,os,hashlib,json,time,shutil
r=Path('/home/bobby/Work/code/bobby/suss-m4-definition-initializer-plan');c=Path('/home/bobby/.cache/suss-m4-work');d=c/'origin-pass-snapshot'
for p in ['crates/suss-compile/src/portable_macro_graph/raw_keys.rs','crates/suss-compile/src/portable/origin/form_metadata.rs']+[f'runtime/bootstrap/{a}.{b}' for a in ['macro','runtime'] for b in ['json','wasm']]:
 q=d/'instrumented'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/p,q)
(d/'diagnostic.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=r))
files=[p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']]+list((r/'runtime/bootstrap').glob('*'))
freeze={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(c/'definition-initializer-target'),RAYON_NUM_THREADS='2',SUSS_SOURCE_PASS_TRACE='1',SUSS_RAW_KEY_TRACE='1',SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1')
cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_declaration_metadata','declaration_metadata_merge_and_tag_precedence_match_pinned_analyzer','--','--test-threads=2','--nocapture']
receipt={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'command':cmd,'freeze':freeze,'diagnostic':'Counts successful charge calls only, excluding rejected requests and any partial fuel consumed by them; no allowance changes.'}
start=time.time()
with (c/'origin-pass-profile.log').open('w') as f:run=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
receipt.update(exit=run.returncode,seconds=time.time()-start,source_unchanged=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in freeze.items()))
(c/'origin-pass-profile-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='freeze'},indent=2))
