from pathlib import Path
import re,json
c=Path('/home/bobby/.cache/suss-m4-work');before=(c/'plan-capacity-declaration-profile.log').read_text().splitlines();after=(c/'demand-origin-declaration-profile.log').read_text().splitlines()
labels=['metadata-graph start','metadata-declaration suss.core/*print-dup* start','metadata-declaration suss.core/->ArrayChunk start','metadata-declaration suss.core/->RecordIter definition-origin','metadata-declaration suss.core/->RecordIter finished','metadata-declaration suss.core/->RedNode start']
rows=[]
for label in labels:
 a=[int(l.rsplit(': ',1)[1]) for l in before if l.startswith(label)];b=[int(l.rsplit(': ',1)[1]) for l in after if l.startswith(label)]
 if a and b:rows.append({'boundary':label,'before':a[-1],'after':b[-1],'net_remaining_gain':b[-1]-a[-1]})
previous=None;cliffs=[];active=False
for line in after:
 if line.startswith('macro-fuel user/core-file start:'):active=True
 if active and line.startswith('raw-key-profile '):
  row={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}
  if previous:cliffs.append({'before':previous,'after':row,'intern_delta':row['intern']-previous['intern'],'head_insert_delta':row['head_insert']-previous['head_insert']})
  previous=row
demand=[line for line in after if line.startswith('origin-demand ')]
state={'base':'3055a564','before_log':'plan-capacity-declaration-profile.log','after_log':'demand-origin-declaration-profile.log','matched_boundaries':rows,'origin_demand_events':demand,'event_counts':{label:sum(label in line for line in demand) for label in ['snapshot','late-eager','mode=eager-return','mode=full composite=true','mode=full composite=false','mode=root']},'tail':after[-25:],'limits':['Matched boundaries report actual charged net work against unchanged 3055.','Failure and full remaining deficit must be assessed from raw terminal result, not prefix saving.','No full baseline or acceptance claim.']}
(c/'demand-origin-profile-comparison.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({k:v for k,v in state.items() if k!='origin_demand_events'},indent=2))
