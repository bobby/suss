from pathlib import Path
import shutil
r=Path('/home/bobby/Work/code/bobby/suss-m4-definition-initializer-plan');c=Path('/home/bobby/.cache/suss-m4-work/origin-pass-snapshot');c.mkdir(exist_ok=True)
paths=['crates/suss-compile/src/portable/origin/form_metadata.rs','crates/suss-compile/src/portable_macro_graph/raw_keys.rs']+[f'runtime/bootstrap/{a}.{b}' for a in ['macro','runtime'] for b in ['json','wasm']]
for name in paths:
 q=c/'before'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/name,q)
p=r/paths[0];s=p.read_text();a=s.index('    fn original_form_ref_metered(');b=s.index('\n}\n',a);part=s[a:b];start=part.index('        if self.metadata_forms.get().is_none()');body=part[start:];# body includes closing function brace
body=body[:body.rfind('    }')]
body=body.replace('            let parsed =','            phase.set(1);\n            let parsed =',1).replace('            let original =','            phase.set(2);\n            let original =',1).replace('            let located =','            phase.set(3);\n            let located =',1)
body=body.replace('''            let snapshot = MetadataSnapshot {
                original: IndexedForms::new_metered(original, meter)?,
                located: IndexedForms::new_metered(located, meter)?,
            };''','''            phase.set(4);
            let original = IndexedForms::new_metered(original, meter)?;
            phase.set(5);
            let located = IndexedForms::new_metered(located, meter)?;
            let snapshot = MetadataSnapshot { original, located };''')
body=body.replace('        if snapshot.original.find_metered','        phase.set(6);\n        if snapshot.original.find_metered').replace('        let Some(found) = snapshot.located.find_metered','        phase.set(7);\n        let Some(found) = snapshot.located.find_metered')
head=part[:start]+'''        let cold = self.metadata_forms.get().is_none();
        let phase = std::cell::Cell::new(0usize);
        let accepted = std::cell::Cell::new([0u64; 8]);
        let rejected = std::cell::Cell::new([0u64; 8]);
        let mut counted = |n| {
            let result = meter(n);
            let cell = if result.is_ok() { &accepted } else { &rejected };
            let mut work = cell.get(); work[phase.get()] = work[phase.get()].saturating_add(n); cell.set(work);
            result
        };
        let meter: &mut WorkMeter<'_> = &mut counted;
        let result = (|| {
'''
tail='''        })();
        if std::env::var_os("SUSS_SOURCE_PASS_TRACE").is_some() {
            let w = accepted.get(); let e = rejected.get();
            eprintln!("origin-pass origin={:p} span={}:{} cold={} setup={} parse={} select={} indexed={} index_original={} index_located={} match_original={} match_located={} rejected={:?} ok={}", std::sync::Arc::as_ptr(&self.metadata_forms), form.span.start, form.span.end, cold, w[0], w[1], w[2], w[3], w[4], w[5], w[6], w[7], e, result.is_ok());
        }
        result
    }
'''
s=s[:a]+head+body+tail+s[b:]
# Full clone is disjoint from source lookup's phases.
s=s.replace('''        clone_form_metered(selected, meter)
    }

    /// Root metadata''','''        let mut work = 0u64; let mut rejected = 0u64;
        let result = clone_form_metered(selected, &mut |n| {
            let result = meter(n);
            if result.is_ok() { work = work.saturating_add(n); } else { rejected = rejected.saturating_add(n); }
            result
        });
        if std::env::var_os("SUSS_SOURCE_PASS_TRACE").is_some() {
            eprintln!("origin-copy kind=full span={}:{} work={} rejected={} ok={}", form.span.start, form.span.end, work, rejected, result.is_ok());
        }
        result
    }

    /// Root metadata''')
a=s.index('        let mut metadata = Vec::new();',s.index('fn macro_form_root_metadata_metered'));b=s.index('\n    }\n',a);body=s[a:b]
s=s[:a]+'''        let mut work = 0u64; let mut rejected = 0u64;
        let mut counted = |n| {
            let result = meter(n);
            if result.is_ok() { work = work.saturating_add(n); } else { rejected = rejected.saturating_add(n); }
            result
        };
        let meter: &mut WorkMeter<'_> = &mut counted;
        let result = (|| {
'''+body+'''
        })();
        if std::env::var_os("SUSS_SOURCE_PASS_TRACE").is_some() {
            eprintln!("origin-copy kind=root span={}:{} work={} rejected={} ok={}", form.span.start, form.span.end, work, rejected, result.is_ok());
        }
        result'''+s[b:];p.write_text(s)
p=r/paths[1];s=p.read_text();pos=s.index('fn append<E>');s=s[:pos]+'''// Diagnostic-only per-key observation. No charge requests are added/removed.
thread_local! { static KEY_PROBE: std::cell::Cell<[u64; 5]> = const { std::cell::Cell::new([0; 5]) }; }
struct KeyProbe;
impl KeyProbe { fn new() -> Self { KEY_PROBE.set([0; 5]); Self } }
impl Drop for KeyProbe {
    fn drop(&mut self) {
        if std::env::var_os("SUSS_SOURCE_PASS_TRACE").is_some() {
            let p = KEY_PROBE.get();
            eprintln!("key-buffer alloc={} reloc={} len={} cap={} status={}", p[0],p[1],p[2],p[3],p[4]);
        }
    }
}
fn reserve_key<E>(v: &mut Vec<u8>, extra: usize, charge: &mut impl FnMut(u64) -> Result<(), E>) -> Result<(), E> {
    let growing = extra > v.capacity() - v.len();
    let capacity = v.len().saturating_add(extra).max(v.capacity().saturating_mul(2)).max(4);
    let (a, r) = if growing { (capacity as u64, v.len() as u64) } else { (0,0) };
    reserve(v, extra, &mut |n| {
        charge(n)?;
        if growing && n != 0 { let mut p=KEY_PROBE.get(); p[0]+=a; p[1]+=r; KEY_PROBE.set(p); }
        Ok(())
    })
}
''' +s[pos:]
s=s.replace('reserve(out, chunk.len(), charge)?;', 'reserve_key(out, chunk.len(), charge)?;').replace('reserve(&mut key, v.len().saturating_mul(2), charge)?;', 'reserve_key(&mut key, v.len().saturating_mul(2), charge)?;')
s=s.replace('''                    Work::Finish(form, id) => {
                        let mut key = Vec::new();''','''                    Work::Finish(form, id) => {
                        let _probe = KeyProbe::new();
                        let mut key = Vec::new();''')
s=s.replace('''        let mut work = 0u64;
        let mut comparison_work''','''        let entries_before = self.keys.len();
        let mut p = KEY_PROBE.get(); p[2]=key.len() as u64; p[3]=key.capacity() as u64; KEY_PROBE.set(p);
        let mut work = 0u64;
        let mut comparison_work''',1)
s=s.replace('''        self.profile_calls = self.profile_calls.saturating_add(1);''','''        let mut p = KEY_PROBE.get(); p[4] = if result.is_err() { 3 } else if self.keys.len() == entries_before { 1 } else { 2 }; KEY_PROBE.set(p);
        self.profile_calls = self.profile_calls.saturating_add(1);''',1);p.write_text(s)
