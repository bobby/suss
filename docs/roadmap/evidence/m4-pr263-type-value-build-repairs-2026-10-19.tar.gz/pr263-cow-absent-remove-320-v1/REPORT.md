# Native core-import regression: source diagnosis and bounded COW candidate

Source320 `32077d435c7c7716ceb21108ff684728740c55c2`, parent66 `66a55ce52a495b61007c1cedca347bd7c2ff911a`. Candidate patch `11d208f70bba59543ffb527227fbc86c16e1426d75d06f2084bbd79acbf9d210`, one existing Rust path. This is authoring for independent review, not source GO or an executed repair. All work is cache-only; no source/worktree/index/ref/remote/Cargo/VM changes.

## Actual failures and limits

`pr263-320-native-feedback/integration3.log` contains17/17 core_import failures at unchanged `loaded(): session.eval(CORE)` (line13), exact byte span197856..197860, token `coll`, BlackNode indexOf receiver parameter. Original core_import test source and CORE bytes match parent66 exactly. No criteria/assertions/defaults were trimmed. The native request exhausts cumulatively there: this span is NOT an attribution of the preceding10M work to the parameter or to one new helper. The raw job has no HIR_COW_TRACE bucket census, so dominant work and total required work remain unknown.

New source differences include charged lexical map forks/entry revisions/Form/HIR ownership in `portable/hir/local_bindings.rs`; the first-key type snapshot now also queries source root metadata during native analysis (`nominal.rs512→TypeKeyHistory::finish_type→RetainedHistory::source_info`). Parent66 had neither this source-info snapshot path nor the new COW representation/work accounting. It is incorrect to call the entire parent/current difference a new repeated traversal: some formerly unmetered old copies are now accounted for. Existing conservative rates may not be cut to recover parent behavior.

Foundation raw separately records bootstrap4PASS63.90s, CLI36PASS331.40s, compiler456PASS6FAIL1138.25s. The strict source_child_certificates_reject_wrong_owner_equal_doc_and_forged_parent_memo fixture now reaches its unchanged five-variant operation, but fails at source_roots.rs1584 graph.materialize_using with WASM OutOfFuel (stack functions439/186/390). Other three former selector failures pass. This is a distinct actual stage, not evidence that the native query dominates it. Fixture scope, negative coverage and allowance stay unchanged. Carver owns controller/alias work; this patch touches none of it.

## Concrete sound removal authored

`cow_remove` presently calls cow_map even for an absent key. On a shared/weak-owned SourceLocals map, that stages a complete HashMap allocation, clones every native String key and retains every binding Arc, publishes a new map owner, then removes nothing. The proposed branch:

1. retains the original name/control charge;
2. performs the old ownership check first; a truly private map uses the exact old direct removal and same charges;
3. only for a shared/weak-owned map, prepays an extra native String lookup/branch; an absent key returns None without allocating/copying/publishing a revision;
4. a present key runs the complete original staged map-copy/removal path, including all old actual allocation/rehash/key-copy/retain work and fees. It pays the extra probe/ownership work as well.

No source query/normalization/logical or physical guard is removed. Native String HashMap probes are not guest hash/equality callbacks. No guest state is read or written; all existing entries and their source-owner Arc identities remain intact. This is not a verdict cache and does not authorize memo writes. An absent deletion does not change any lexical fact, so retaining that same immutable revision is intentional. Real deletions still fork before mutation, preserving saved snapshots and failure atomicity.

There is NO demonstrated core17 benefit yet. Actual callers are method-field cleanup (hir.rs1986), catch cleanup (exceptions.rs206), and function-scope self projection (local_bindings.rs307). Method maps may already be private; those cases intentionally receive no savings. Present shared-key removal incurs extra probe work. Therefore this patch must not be portrayed as the dominant/core-completing fix. Its actual frequency and default-budget effect need replay or the existing SUSS_HIR_COW_TRACE facility under main's producer lease.

## Authored controls and checks

Two new exact tests in manifest.json compare actual old/new helper calls (same generic map implementation/rates/hasher) for shared maps with0/1/8/32entries, absent/present keys, unique owners and weak owners. They print measured whole-helper units, preserve return/value Arc identities and assert private-path exact work. Every remaining small callback-meter boundary is injected with unchanged map owner/source entries and full retry. These are authored tests, NOT executed; callback diagnostics do not claim actual Store IRQ coverage. All existing ownership tests are byte-preserved.

Rustfmt parse and GNU patch application to exact cached preimages passed; all postimages match. No Rust typecheck/native execution credit. Exact old helper is retained cfg(test) except its name. New test selection is in manifest; run existing ownership_tests as well before original default core_import17 and unchanged strict SourceRoots test. Normal bootstrap/fingerprint regeneration is needed for integrated source. Do not launch while root owns producer lease.

## Rejected stronger shortcut and fulltype cost

`pr263-retained-source-info-demand-320-v1` is AUTHOR_BLOCKED_NOT_FOR_APPLICATION. Skipping source_info when all three first-key slots are present would avoid unused provenance work, but can suppress malformed SourceOrigin/query errors. Later Graph validation is not proof of analysis-stage diagnostic equivalence. That patch is deliberately NOT endorsed or composed.

Fulltype `143b…`/composition`f486…` is independent and does NOT touch local_bindings.rs. The COW patch preimage matches that source and411; all7main source repairs remain. Fulltype additionally captures full declaration/definition syntax and flat function facts at every completed ordinary native definition, seals latest type input syntax/selected original-origin values, and executes old ordinary writers plus the new shared-value overlay. These are real extra eager traversals/allocations and arena recipes. Even unreachable private recipes can increase native arena/admission work; materialization itself follows the requested dependency closure, so do NOT assume every private map executes guest callbacks. No whole-operation amount or adequacy has been measured. Keep fulltype out of any claimed native acceptance until actual capture+duplicate-writer costs/default core17 and the strict one-scope five-variant fixture are replayed.
