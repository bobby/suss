#!/usr/bin/env python3
"""Run only after remaining preservation producer42764 is terminal and drained."""
import os,subprocess,json,time,pathlib,hashlib
root=pathlib.Path('/home/bobby/Work/code/bobby/suss')
run=pathlib.Path(__file__).resolve().parent
os.chdir(root)
# Guard the known earlier producer; a live process is a refusal, never a restart.
if (run/'launched.json').exists():
    raise SystemExit('One-shot run already launched; inspect receipts instead of restarting')
env=os.environ.copy()
env['TMPDIR']='/home/bobby/.cache/suss-m4-work/workspace-tmp-65e9718-ccpsnhdq'
env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
env['SUSS_CLOJURE_TEST_SUITE_CAPTURE']=str(run/'capture')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
(run/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD']))
new_paths=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
new_hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in new_paths if p.startswith('crates/') and p.endswith('.rs')}
for p in new_hashes:
    dest=run/'untracked-source'/p
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes((root/p).read_bytes())
(run/'launched.json').write_text(json.dumps({'head':head,'pid':os.getpid(),'time':time.time(),'untracked_rust':new_hashes},indent=2)+'\n')
results=[]
for name,argv in json.loads((run/'stages.json').read_text()):
    start=time.time()
    with (run/(name+'.log')).open('w') as log:
        child=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
        (run/'active.json').write_text(json.dumps({'stage':name,'pid':child.pid,'argv':argv,'start':start},indent=2)+'\n')
        code=child.wait()
    if name=='bootstrap' and code==0:
        boot={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'runtime/bootstrap').iterdir() if p.suffix in ['.wasm','.json']}
        (run/'bootstrap-hashes.json').write_text(json.dumps(boot,indent=2)+'\n')
        (run/'source-with-bootstrap.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD']))
    row={'name':name,'argv':argv,'code':code,'seconds':time.time()-start}
    expected={'provenance-3':3,'lazy-result-irq-1':1,'original-generic-case':1,'pinned-map-1':1,'whole-suite-1':1}.get(name,1 if name.startswith('unchanged-') else None)
    if code==0 and expected is not None:
        import re
        log_text=(run/(name+'.log')).read_text()
        observed=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log_text)
        row['expected_passes']=expected
        row['observed_counts']=list(map(int,observed[-1])) if observed else None
        if row['observed_counts'] != [expected,0,0]:
            row['selection_error']='expected exact positive test count'
            code=99
            row['code']=code
    results.append(row)
    (run/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if code and name.startswith('unchanged-'):
        # Retain the failed row and continue the explicit unchanged-test audit.
        # Overall result below remains failed; no assertion is skipped.
        continue
    if code:
        (run/'terminal.json').write_text(json.dumps({'code':code,'failed_stage':name,'results':results},indent=2)+'\n')
        raise SystemExit(code)
overall=next((row['code'] for row in results if row['code']),0)
(run/'terminal.json').write_text(json.dumps({'code':overall,'results':results},indent=2)+'\n')
raise SystemExit(overall)
