"""Read terminal job evidence once; live jobs never receive a success verdict."""
from pathlib import Path
import subprocess,json,re,hashlib,collections,datetime
ROOT=Path('/home/bobby/Work/code/bobby/suss');OUT=Path(__file__).resolve().parent
RUN='39207507722';HEAD='65e97187ff8a9492c9563797cbd291b683190e45'
def gh(*args):return subprocess.check_output(['gh',*args],text=True)
def api(path):return json.loads(gh('api',path))
def tree(commit):
 p=OUT/('commit-'+commit+'.json')
 if not p.exists():p.write_text(json.dumps(api('repos/bobby/suss/git/commits/'+commit),indent=2)+'\n')
 return json.loads(p.read_text())['tree']['sha']
def inspect(job,raw,meta):
 s=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw)
 lines=[re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+Z\s*','',x) for x in s.splitlines()]
 checkouts=[]
 for i,line in enumerate(lines):
  if 'git log -1 --format=%H' in line:
   checkouts.extend(x for x in lines[i+1:i+4] if re.fullmatch('[a-f0-9]{40}',x))
 checkout=checkouts[0] if len(set(checkouts))==1 else None
 local=subprocess.check_output(['git','rev-parse',HEAD+'^{tree}'],cwd=ROOT,text=True).strip()
 binding=bool(checkout and tree(checkout)==tree(HEAD)==local)
 rows=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', '\n'.join(lines),re.M)
 totals=dict(zip(['passed','failed','ignored'],[sum(int(row[i+1]) for row in rows) for i in range(3)]))
 result={'job_id':job['databaseId'],'name':job['name'],'conclusion':meta['conclusion'],'source_head':HEAD,'checkout':checkout,'checkout_head_local_tree_equal':binding,'tree':local,'rust':totals,'rust_summaries':len(rows),'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'this terminal job only; not full workspace or issue acceptance'}
 if job['name'].startswith('integration ('):
  plans=[json.loads(x) for x in lines if x.startswith('{"index":') and '"total_targets"' in x]
  if len(plans)!=1:raise ValueError('missing/ambiguous shard plan')
  plan=plans[0];running=re.findall(r'Running tests/([^ ]+)\.rs','\n'.join(lines))
  expected=collections.Counter(t[1] for t in plan['targets']);seen=collections.Counter(running)
  result.update(planner=plan,started_target_names=running,completed_targets=len(rows),unstarted_targets=list((expected-seen).elements()),all_planned_targets_have_summaries=expected==seen and len(rows)==len(running),failed_targets=re.findall(r'error: test failed, to rerun pass `([^`]+)`',s))
  result['complete_success_verified']=meta['conclusion']=='success' and binding and result['all_planned_targets_have_summaries'] and not totals['failed'] and all(row[0]=='ok' for row in rows)
 elif job['name']=='foundation':
  result['python_test_counts']=list(map(int,re.findall(r'^Ran (\d+) tests? in ', '\n'.join(lines),re.M)))
  result['steps']=[{'name':x['name'],'status':x['status'],'conclusion':x['conclusion']} for x in meta['steps']]
  result['complete_success_verified']=meta['conclusion']=='success' and binding and bool(rows) and not totals['failed'] and bool(result['python_test_counts'])
 else:result['complete_success_verified']=meta['conclusion']=='success' and binding
 (OUT/('job-'+str(job['databaseId'])+'.sanitized.log')).write_text(s)
 return result
if __name__=='__main__':
 run=json.loads(gh('run','view',RUN,'--json','headSha,status,conclusion,jobs'));assert run['headSha']==HEAD
 (OUT/'run.json').write_text(json.dumps(run,indent=2)+'\n');results=[]
 for job in run['jobs']:
  if job['status']!='completed':continue
  dest=OUT/('job-'+str(job['databaseId'])+'-audit.json')
  if dest.exists():results.append(json.loads(dest.read_text()));continue
  meta=api('repos/bobby/suss/actions/jobs/'+str(job['databaseId']));assert meta['status']=='completed'
  raw=gh('api','--allow-escape-sequences','repos/bobby/suss/actions/jobs/'+str(job['databaseId'])+'/logs')
  (OUT/('job-'+str(job['databaseId'])+'.raw.log')).write_text(raw)
  result=inspect(job,raw,meta);dest.write_text(json.dumps(result,indent=2)+'\n');results.append(result)
 expected_dependencies={'foundation'}|{'integration ('+str(i)+')' for i in range(8)}
 by_name={r['name']:r for r in results}
 dependencies_verified=expected_dependencies <= by_name.keys() and all(by_name[n]['complete_success_verified'] and by_name[n]['source_head']==HEAD for n in expected_dependencies)
 coverage_verified=False
 if dependencies_verified:
  plans=[by_name['integration ('+str(i)+')']['planner'] for i in range(8)]
  targets=[tuple(t) for plan in plans for t in plan['targets']]
  coverage_verified=len(set(targets))==len(targets) and all(plan['total_targets']==len(targets) and plan['count']==8 and plan['index']==i for i,plan in enumerate(plans))
 if 'test' in by_name:
  gate=by_name['test']
  gate['scope']='aggregate gate has no checkout by workflow design; source proof comes from all nine verified dependencies and complete disjoint target coverage'
  gate['complete_success_verified']=gate['conclusion']=='success' and dependencies_verified and coverage_verified
  gate['verified_dependency_names']=sorted(expected_dependencies) if gate['complete_success_verified'] else []
  (OUT/('job-'+str(gate['job_id'])+'-audit.json')).write_text(json.dumps(gate,indent=2)+'\n')
 whole_ci_verified=run['status']=='completed' and run['conclusion']=='success' and set(by_name)==expected_dependencies|{'test'} and all(r['complete_success_verified'] for r in results) and coverage_verified
 print(json.dumps({'run_status':run['status'],'run_conclusion':run['conclusion'],'whole_ci_verified':whole_ci_verified,'limits':'CI verdict only; exact local workspace and issue acceptance remain separate','terminal_audits':[{k:r[k] for k in ['job_id','name','conclusion','rust','complete_success_verified']} for r in results],'live_or_queued':[j['name'] for j in run['jobs'] if j['status']!='completed']},indent=2))
