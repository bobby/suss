from pathlib import Path
import json,subprocess,tomllib,hashlib
P=Path(__file__).parent;C=P.parent;HEAD='4f48ea6bd7d2e198b9dd82086e4abf4e118e7a7b';REPO='/home/bobby/Work/code/bobby/suss'
def gitfile(n):return subprocess.check_output(['git','-C',REPO,'show',HEAD+':'+n])
paths=set(subprocess.check_output(['git','-C',REPO,'ls-tree','-r','--name-only',HEAD],text=True).splitlines());ws=tomllib.loads(gitfile('Cargo.toml').decode());targets=[];manifests={};units=[];docs=[]
for member in ws['workspace']['members']:
 path=member+'/Cargo.toml';raw=gitfile(path);m=tomllib.loads(raw.decode());name=m['package']['name'];manifests[path]=hashlib.sha256(raw).hexdigest()
 assert m['package'].get('autotests',True) and not m.get('test'), 'Manual Cargo target configuration requires explicit inventory adaptation'
 for f in sorted(paths):
  if f.startswith(member+'/tests/') and f.endswith('.rs') and '/' not in f[len(member+'/tests/'):]:targets.append([name,Path(f).stem])
  elif f.startswith(member+'/tests/') and f.endswith('/main.rs') and len(Path(f).relative_to(member+'/tests').parts)==2:targets.append([name,Path(f).parent.name])
 lib=m.get('lib',{});libpath=member+'/'+lib.get('path','src/lib.rs')
 if libpath in paths:
  units.append({'package':name,'kind':'library','path':libpath})
  if lib.get('doctest',True):docs.append({'package':name,'target':lib.get('name',name.replace('-','_')),'path':libpath})
 explicit={member+'/'+x.get('path','src/bin/'+x['name']+'.rs'):x['name'] for x in m.get('bin',[])}
 for path,n in explicit.items():
  if path in paths:units.append({'package':name,'kind':'binary','path':path,'name':n})
 if m['package'].get('autobins',True):
  for f in sorted(paths):
   if f in explicit:continue
   if f==member+'/src/main.rs':units.append({'package':name,'kind':'binary','path':f,'name':name})
   elif f.startswith(member+'/src/bin/') and f.endswith('.rs') and '/' not in f[len(member+'/src/bin/'):]:units.append({'package':name,'kind':'binary','path':f,'name':Path(f).stem})
ci=json.loads((C/'pr256-4f48ea6-ci/terminal-audit.json').read_text());assert ci['head']==HEAD and ci['status']=='completed';ci_targets=sorted(t for j in ci['jobs'] if j['name'].startswith('integration') for t in j['plan']['targets']);targets.sort();assert len(targets)==len(set(map(tuple,targets)))==251 and targets==ci_targets
saved=json.loads((C/'pr256-raw-key-scratch-workspace-baseline/integration-target-inventory.json').read_text());assert sorted(saved['targets'])==targets
out={'source':HEAD,'count':len(targets),'targets':targets,'derivation':'ExactGitworkspace/packageTOML + automatic tests/*.rs or tests/*/main.rs targets; no explicit [[test]]/autotests override; equals all8actual4fCIplans. NoCargo launched.','manifest_sha256':manifests,'ci_run':39156456734,'ci_audit_sha256':hashlib.sha256((C/'pr256-4f48ea6-ci/terminal-audit.json').read_bytes()).hexdigest(),'saved_inventory_original_source':saved['source'],'saved_inventory_targetlist_equals_current':True,'unit_binary_targets':units,'doctest_targets':docs}
(P/'integration-target-inventory.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'source':HEAD,'integration':len(targets),'unit_binary':len(units),'doctest':len(docs),'saved_label':saved['source'],'all_ci_plans_match':True},indent=2))
