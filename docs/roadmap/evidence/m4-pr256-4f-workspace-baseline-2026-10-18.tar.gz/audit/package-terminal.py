"""Cache-only; refuses finalization while baseline/driver still live. No Cargo or root writes."""
from pathlib import Path
import json,re,hashlib,subprocess,os,sys,tarfile,io,datetime
C=Path('/home/bobby/.cache/suss-m4-work');D=C/'pr256-raw-key-scratch-workspace-baseline';P=Path(__file__).parent
HEAD='4f48ea6bd7d2e198b9dd82086e4abf4e118e7a7b';REPO='/home/bobby/Work/code/bobby/suss'
L=lambda p:json.loads(p.read_text());H=lambda b:hashlib.sha256(b).hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,indent=2)+'\n')
def live(pid):
 try:os.kill(pid,0);return True
 except ProcessLookupError:return False
r=L(D/'receipt.json');assert r['base']==HEAD
pending={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receipt_terminal':r['terminal'],'cargo_pid':r.get('pid'),'cargo_live':live(r['pid']),'driver_pid':1336348,'driver_live':live(1336348),'finalization':'PENDING'}
if not r['terminal'] or pending['cargo_live'] or pending['driver_live']:
 save('pending-status.json',pending);print(json.dumps(pending,indent=2));sys.exit(0)
assert 'exit' in r and r['changed']==[];assert r['argv']==['cargo','test','--workspace','--locked','--','--test-threads=2']
# Stable terminal inputs, without hashing or reading the mutable source worktree.
rawpaths=[D/n for n in ['workspace.log','receipt.json','manifest.json','source.patch','run.py','integration-target-inventory.json']]
before={f.name:H(f.read_bytes()) for f in rawpaths};freeze=L(D/'manifest.json');inv=L(P/'integration-target-inventory.json');assert inv['source']==HEAD and inv['count']==len(inv['targets'])==251
assert (D/'source.patch').read_bytes()==b''
tree={}
for line in subprocess.check_output(['git','-C',REPO,'ls-tree','-r',HEAD],text=True).splitlines():
 meta,path=line.split('\t',1);mode,typ,oid=meta.split();tree[path]=(typ,oid)
proc=subprocess.Popen(['git','-C',REPO,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);memo={};bindings={}
for path,expected in freeze.items():
 typ,oid=tree[path];assert typ=='blob'
 if oid not in memo:
  proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();assert hdr[1]==b'blob';left=int(hdr[2]);h=hashlib.sha256()
  while left:
   b=proc.stdout.read(min(left,1048576));assert b;h.update(b);left-=len(b)
  assert proc.stdout.read(1)==b'\n';memo[oid]=h.hexdigest()
 assert memo[oid]==expected,path
 bindings[path]={'commit':HEAD,'blob':oid,'sha256':expected}
proc.stdin.close();assert proc.wait()==0;assert len(bindings)==3532
# Parse each actual Running/Doc-tests block; all raw test names and summaries retained.
t=(D/'workspace.log').read_text();blocks=[];cur=None;inventory={tuple(x) for x in inv['targets']};depsproof={}
for line in t.splitlines():
 m=re.search(r'Running (unittests (\S+)|tests/([^\s]+)\.rs) \(([^)]+)\)',line);doc=re.match(r'\s*Doc-tests\s+(\S+)',line)
 if m or doc:
  cur={'label':doc[1] if doc else (m[2] or m[3]),'kind':'doctest' if doc else ('integration' if m[3] else 'unit_or_binary'),'tests':[],'summary':None};blocks.append(cur)
  if m:
   cur['executable']=m[4]
   if m[3]:
    choices=[x for x in inventory if x[1]==m[3]];assert choices,cur
    if len(choices)>1:
     dep=Path(m[4]+'.d');body=dep.read_text();pkgs=set(re.findall(r'/crates/(suss-(?:cli|compile|reader|core))/tests/'+re.escape(m[3])+r'\.rs',body));assert len(pkgs)==1,(cur,pkgs)
     choices=[x for x in choices if x[0] in pkgs];depsproof[dep.name]=body
    assert len(choices)==1;cur['target']=list(choices[0])
  continue
 m=re.match(r'^test (.+) \.\.\. (ok|FAILED|ignored)(?:$|,)',line)
 if m:assert cur is not None;cur['tests'].append({'name':m[1],'status':m[2]})
 m=re.match(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',line)
 if m:
  pending=[b for b in blocks if b['summary'] is None];assert pending
  finished=pending[0];finished['summary']=dict(zip(['pass','fail','ignored','measured','filtered'],map(int,m.groups())))
  assert [finished['summary'][k] for k in ['pass','fail','ignored']]==[sum(x['status']==s for x in finished['tests']) for s in ['ok','FAILED','ignored']],finished
completed=[b for b in blocks if b['summary'] is not None];unfinished=[b for b in blocks if b['summary'] is None]
executed={tuple(b['target']) for b in blocks if b['kind']=='integration'};done={tuple(b['target']) for b in completed if b['kind']=='integration'};assert len(done)==sum(b['kind']=='integration' for b in completed)
unexec=sorted(inventory-executed);counts=lambda bs:{k:sum(b['summary'][k] for b in bs) for k in ['pass','fail','ignored']}
# Failure bodies may carry either a typed Diagnostic span or a printed bytes range.
fs={};chunks=re.split(r'^---- (.*?) stdout ----\s*$',t,flags=re.M)
for i in range(1,len(chunks),2):
 name,body=chunks[i:i+2];body=body.split('\nfailures:',1)[0];stage=re.search(r'Compiled macro expansion failed during ([^:]+):',body);span=re.search(r'span:\s*(\d+\.\.\d+)',body) or re.search(r'at bytes (\d+\.\.\d+)',body)
 fs[name]={'class':'fuel' if 'all fuel consumed' in body else 'unclassified_failure_requires_raw_review','stage':stage[1] if stage else None,'span':span[1] if span else None,'raw_body':body.strip()}
failednames={x['name'] for b in completed for x in b['tests'] if x['status']=='FAILED'};assert failednames==set(fs)
result={'source':HEAD,'terminal_receipt':r,'source_freeze':{'paths':len(bindings),'all_match_git':True,'receipt_changed':[],'live_worktree_hashed':False},'counts_all_completed_harness_executions':counts(completed),'counts_without_doctests':counts([b for b in completed if b['kind']!='doctest']),'unit_binary_counts':counts([b for b in completed if b['kind']=='unit_or_binary']),'integration_counts':counts([b for b in completed if b['kind']=='integration']),'doctests':{'counts':counts([b for b in completed if b['kind']=='doctest']),'completed':sum(b['kind']=='doctest' for b in completed),'planned_targets':inv['doctest_targets'],'planned_count':len(inv['doctest_targets']),'unexecuted_count':len(inv['doctest_targets'])-sum(b['kind']=='doctest' for b in completed),'not_reached':'No inferred doctest pass when Cargo stops before doctest stages.'},'integration':{'planned':251,'executed':len(executed),'completed':len(done),'started_unfinished':sorted(executed-done),'unexecuted_count':len(unexec),'unexecuted':unexec},'completed_harnesses':len(completed),'harnesses':blocks,'started_unfinished':unfinished,'failures':fs,'compile_errors':re.findall(r'^error\[E\d+\]:.*$',t,re.M),'limits':['A terminal fail-fast workspace command does not execute later targets or doctests.','Counts are executions, not deduplicated coverage; prior focused/CI counts not added.','Baseline freeze established by original manifest + receipt.changed[], bound to Git objects. Later mutable worktree state is not baseline evidence.','Only supplied integration inventory supports unexecuted-target totals; no fabricated doctest target inventory.']}
save('terminal-classification.json',result);save('source-git-bindings.json',{'source':HEAD,'bindings':bindings})
for name,body in depsproof.items(): (P/('dependency-proof-'+name)).write_text(body)
report=f"""# PR256 4f workspace baseline\n\nExact source `{HEAD}`. Command: `cargo test --workspace --locked -- --test-threads=2`. Receipt exit {r['exit']}, duration {r['seconds']} seconds; Cargo and driver exited. Original {len(bindings)} frozen files match exact Git blobs; receipt changed[] confirms closure. No live worktree hashes substituted.\n\nCompleted-harness counts: {json.dumps(result['counts_all_completed_harness_executions'])}. {len(completed)} completed harnesses. Integration targets: {len(executed)} executed, {len(done)} completed, {len(executed-done)} started unfinished, {len(unexec)} unexecuted of actual251. Doctests separately: {json.dumps(result['doctests'])}. Unit/binary counts: {json.dumps(result['unit_binary_counts'])}; integration counts: {json.dumps(result['integration_counts'])}. Saved raw inventory labels d38; current251 targetlist independently derived from4f Git manifests/paths and verified against all8actual4fCIplans; original stale label retained, not relabeled. Full per-test names/status, harness summaries and failure stage/span bodies are in terminal-classification.json.\n\nThis packet contains only this baseline tuple; no prior focus/control/CI totals merged. Full-baseline success is claimed only if actual exit0 and no raw failures. Unknown later coverage stays unexecuted. Source evidence uses published 4f objects; root may mutate its worktree after completion.\n""";(P/'REPORT.md').write_text(report)
assert before=={f.name:H(f.read_bytes()) for f in rawpaths}
files={'raw/'+f.name:f for f in rawpaths}
for f in P.iterdir():
 if f.is_file() and f.name not in ['pending-status.json','package-result.json'] and f.suffix in ['.json','.py','.md','.d']:files['audit/'+f.name]=f
manifest={n:{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size} for n,f in files.items()};data=json.dumps({'schema':1,'payloads':manifest},indent=2).encode();out=C/'m4-pr256-4f-workspace-baseline-2026-10-18.tar.gz'
with tarfile.open(out,'w:gz') as tf:
 for n,f in sorted(files.items()):tf.add(f,arcname=n,recursive=False)
 ti=tarfile.TarInfo('MANIFEST.json');ti.size=len(data);tf.addfile(ti,io.BytesIO(data))
with tarfile.open(out) as tf:
 ms=tf.getmembers();assert len(ms)==len(files)+1==len({m.name for m in ms})
 for m in ms:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='MANIFEST.json':assert H(tf.extractfile(m).read())==manifest[m.name]['sha256']
save('package-result.json',{'archive':str(out),'sha256':H(out.read_bytes()),'members':len(files)+1,'payloads':len(files),'bytes':out.stat().st_size,'source':HEAD,'classification':str(P/'terminal-classification.json')});print((P/'package-result.json').read_text())
