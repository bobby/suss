from pathlib import Path
import subprocess as s,json,hashlib,os,time
root=Path('/home/bobby/Work/code/bobby/suss');p=Path(__file__).parent
assert not (root/'crates/suss-cli/tests/compiled_macro_namespace_identity_diagnostic_40m.rs').exists()
files=s.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
def hashes():return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if (root/f).is_file()}
freeze=hashes();(p/'manifest.json').write_text(json.dumps(freeze,indent=2)+'\n');(p/'source.patch').write_bytes(s.check_output(['git','diff','--binary'],cwd=root))
cmd=['cargo','test','--workspace','--locked','--','--test-threads=2'];overrides={'CARGO_TARGET_DIR':'/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target','CARGO_BUILD_JOBS':'1','RAYON_NUM_THREADS':'1'};env=os.environ.copy();env.update(overrides)
r={'base':s.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'argv':cmd,'environment_overrides':overrides,'terminal':False}
def save():(p/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
start=time.monotonic()
with (p/'workspace.log').open('w') as log:
 child=s.Popen(cmd,cwd=root,env=env,stdout=log,stderr=s.STDOUT);r['pid']=child.pid;save();code=child.wait()
r.update(terminal=True,exit=code,seconds=time.monotonic()-start,changed=[f for f,h in freeze.items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h]);save();print(json.dumps(r),flush=True);assert not r['changed']
