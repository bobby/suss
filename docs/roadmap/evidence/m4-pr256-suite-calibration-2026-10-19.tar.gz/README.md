# Evidence for the test-only corpus compilation calibration

`before/` is unchanged c0c9c45 at Macro200M/Runtime200M, terminal101.
`calibrated/` is c0c9c45 plus its retained source.patch at Macro10B/Runtime200M,
terminal101 against the old baseline. `tested-source.patch` also includes the
subsequently reviewed exact known-failure map. Neither capture used WRITE.

`independent-delta/` contains the frozen old known-failure map, reference,
comparator copy, classifiers, complete classifications and independent reports.
Run the read-only classifier with PYTHONPATH pointing to repository scripts,
--capture pointing to the chosen capture/suite-observations.json,
--terminal-receipt pointing to its terminal.json and --output outside this archive.
Its paths identify original source locations; use the extracted files for replay.
The pinned source/reference/comparator copies are retained. `oracle_compare.py`
is imported from the unchanged repository scripts directory.

`update48/` has original expression and caught-message actual CLI outputs,
exit codes, timings and binary hash. `base-ci/` describes only its identified
jobs, not whole CI acceptance. `cancelled-base-baseline/` retains the explicit
exit143 cancellation after53passes. No cancelled/incomplete run is a full pass.

The complete focused harness was still running at publication; no terminal result
from that run is included or credited by this capture archive.
See the adjacent repository evidence report for commands, settings and limits.
