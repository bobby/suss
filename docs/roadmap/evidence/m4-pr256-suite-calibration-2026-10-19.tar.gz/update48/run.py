import pathlib,subprocess,json,time,hashlib,os
r=pathlib.Path(__file__).resolve().parent
binary=pathlib.Path('/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target/debug/suss')
if (r/'launched.json').exists(): raise SystemExit('Already launched: inspect existing receipts')
(r/'launched.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'pid':os.getpid(),'time':time.time()},indent=2)+'\n')
rows=[]
for name,expr in [('original','(apply update [{:k 1} :k inc 1 2 3 4])'),('caught-message','(try (apply update [{:k 1} :k inc 1 2 3 4]) (catch :default e (ex-message e)))')]:
    start=time.time()
    with (r/(name+'.stdout')).open('w') as stdout,(r/(name+'.stderr')).open('w') as stderr:
        child=subprocess.Popen([str(binary),'-e',expr],stdout=stdout,stderr=stderr)
        (r/'active.json').write_text(json.dumps({'pid':child.pid,'expression':expr},indent=2)+'\n')
        code=child.wait()
    rows.append({'name':name,'expr':expr,'code':code,'seconds':time.time()-start})
    (r/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(rows[-1]),flush=True)
(r/'terminal.json').write_text(json.dumps({'results':rows},indent=2)+'\n')
