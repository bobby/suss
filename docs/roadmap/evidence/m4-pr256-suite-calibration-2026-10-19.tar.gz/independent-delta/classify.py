#!/usr/bin/env python3
"""Read-only classifier. Run only against a terminal, source-bound capture."""
import argparse,collections,hashlib,importlib.util,json,pathlib,subprocess
p=argparse.ArgumentParser();p.add_argument('--capture',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--terminal-receipt',type=pathlib.Path,required=True);a=p.parse_args()
here=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pinned_compare',here/'clojure_test_suite.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
load=lambda p:json.loads(p.read_text(),object_pairs_hook=m.unique)
b=load(here/'baseline.json');ref=load(here/'reference.json');obs=load(a.capture);terminal=load(a.terminal_receipt)
counts,new=m.compare(ref,obs);actual={f"{x['test']}#{x['ordinal']}":x for x in obs['assertions']};protected=[];regressed=[];newly=[];oldfailchanges=[]
for e in ref['assertions']:
 i=e['id'];t=e['test'];ns=t.split('/')[0]
 oldblocked=ns in b['namespaces'] or t in b['tests'];oldreason=b['assertions'].get(i)
 if not oldblocked and oldreason is None:
  protected.append(i)
  reason=new['assertions'].get(i)
  if ns in new['namespaces']:reason='namespace:'+new['namespaces'][ns]['stage']
  elif i not in actual:reason='missing'
  if reason:regressed.append({'id':i,'reason':reason})
 elif oldblocked and i in actual:
  newly.append({'id':i,'old_namespace_or_test_blocked':True,'new_reason':new['assertions'].get(i),'kind':actual[i].get('kind'),'raw':actual[i] if i.endswith('#48') and 'update/' in i else None})
 elif oldreason != new['assertions'].get(i):oldfailchanges.append({'id':i,'old':oldreason,'new':new['assertions'].get(i)})
changes={k:[{'id':i,'old':b[k].get(i),'new':new[k].get(i)} for i in sorted(set(b[k])|set(new[k])) if b[k].get(i)!=new[k].get(i)] for k in ['namespaces','tests','assertions']}
skip=lambda x:collections.Counter((s['namespace'],s['symbol'],s['test']) for s in x)
# Old failed namespaces can hide their skip behavior. Global oracle equality is
# still required; exact historical skip drift needs an old raw capture.
result={'scope':'c0 baseline/reference delta, not automatic baseline approval','counts':counts,'changes':changes,'protected_old_pass_or_guest_ids':len(protected),'protected_regressions':regressed,'newly_reachable_assertions':newly,'old_assertion_changes':oldfailchanges,'skip_mismatches':new['skip-mismatches'],'oracle_skip_counter_equal':skip(ref['skips'])==skip(obs['skips']),'old_skip_mismatch_delta':{'old':b['skip-mismatches'],'new':new['skip-mismatches']},'protected_and_skip_check_passed':not regressed and not new['skip-mismatches'] and b['skip-mismatches']==new['skip-mismatches'],'hashes':{str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in [a.capture,a.terminal_receipt,here/'baseline.json',here/'reference.json',here/'clojure_test_suite.py']},'terminal_receipt':terminal,'limits':['Caller must establish terminal producer/freeze/source correspondence; receipt retained verbatim, not inferred from file presence.','Previously namespace-blocked assertion errors are newly reachable, not automatically regressions.','Runtime error cause unknown unless actual capture supplies it; no inference from kind:error alone.','No --write, baseline mutation, fuel change or whole-CI acceptance.','Aggregate baseline cannot recover prior raw assertion order or exact historical skip rows.']}
result['skip_drift_relative_reviewed_baseline'] = b['skip-mismatches'] != new['skip-mismatches']
result['old_pass_preservation_and_no_baseline_skip_drift'] = not regressed and not result['skip_drift_relative_reviewed_baseline']
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'output':str(a.output),'protected_regressions':len(regressed),'namespace_changes':len(changes['namespaces']),'newly_reachable':len(newly),'skip_mismatches':new['skip-mismatches']}))
