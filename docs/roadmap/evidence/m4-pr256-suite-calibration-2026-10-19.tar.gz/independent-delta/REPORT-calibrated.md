# Calibrated terminal corpus — independent refresh recommendation

Actual terminal101,318.968s including build/316.92s execution; no whole-suite success claimed. Source-only Macro10B calibration already reviewed; Runtime200M/Harness::new/pinned-map200M unchanged. No source/baseline/Cargo edits by this audit.

## Complete delta classification

Against pinned known-failure baseline: ALL960 old pass/guest IDs remain present/nonfailing. Eight namespace changes are exactly: contains-qmark, map, update now LOADED; doseq/drop-last/lazy-seq/merge/realized-qmark advance from structural macro rejections to explicit unresolved Runtime doseq/drop-last/assert/any?/promise diagnostics. NO test-failure-map delta. Exactly ONE assertion failure added: update/test-update#48 kind:error, previously hidden behind failed update namespace. Existing assertion failure remains. Existing20 skip-mismatch occurrences across19rows unchanged; no skip drift, not full skip conformance. Newly reachable210 IDs: contains77+map69+update64;209nonfailing,update48error.

Against actual c0-before200M/200M raw capture: ALL1092 old pass/guest IDs preserved. Every existing raw assertion record byte-equivalent as JSON; no removed ID, no changed existing assertion. Raw skip counters identical. ONLY namespace delta: contains-qmark previously Macro fuel-failed now LOADED,77additional nonfailing assertions. Test-failure and assertion-failure dictionaries EXACTLY unchanged. Final totals1144host pass/25guest judged/22fail/4663not-executed/185failed namespaces. These are suite observations, not Rust test counts.

Update48 remains exact same captured opaque `Host error: Unsupported ABI2 value layout`, head=,kind:error,verdict:error. Compilation calibration did not repair it. Underlying thrown exception still not established by this opaque representation; separate direct original+catch probe is authoritative when completed. Do not label fuel or WrongArity from this record alone. Pinned source/expected predicate remains unchanged, including extra-argument inc behavior.

## Recommendation

GO for an EXPLICIT independently reviewed known-failure refresh from this terminal capture, provided exact8namespace/1assertion changes above and unchanged existing failures/skips are the entire baseline diff. Preserve update48 as kind:error and all unresolved namespaces; no skip additions, oracle/reference writes, expected observation changes or broad suppressions. Publish both capture hashes, calibration source review, complete delta receipts and prior raw failures. This recognizes actual formerly blocked execution, not new language support or complete collection conformance. Direct update48 diagnosis/follow-up remains explicit; do not claim its cause fixed or erase it. Final required workspace and final-head CI gates still needed after source/evidence commit.

Machine receipts: calibrated-analysis.json (pinned-baseline comparison) and before-vs-calibrated.json (actual raw-pair comparison), with capture/reference/baseline/comparator/terminal hashes. ClassifierV1 and earlier failed import qualification remain preserved.
