# Terminal c0 whole-suite capture — independent delta audit

Actual unchanged200M Macro/200M Runtime capture:884417bytes, exact test terminal101,405.1647s including build. Raw and terminal in pr252-c0c9c45-suite-before-capture-v1. Classifier initially failed BEFORE analysis on missing Python import oracle_compare; no execution credit. Retried read-only with PYTHONPATH pointing to repository scripts; pinned c0 comparison source unchanged. No Cargo or baseline writes.

## Preservation and newly reachable outcomes

960 previously passing/guest-judged reference IDs (excluding old failed namespace/test/assertion entries) remain present and nonfailing: ZERO regressions/missing. Old baseline.tests is empty. All existing skip-mismatch records are EXACTLY unchanged, not zero: baseline has20 mismatch occurrences across19 rows; no skip drift. Generic classifier's stricter oracle-zero-skip flag is false because these preexisting mismatches remain; qualified JSON distinguishes baseline preservation from complete oracle conformance.

Actual totals1067host pass,25guest judged,22fail,4740not-executed,186failed namespaces,0matched skips. These suite counts are NOT Rust harness counts or whole collection conformance.

Eight namespace changes:
- contains-qmark: old malformed map-count macro diagnostic -> Wasm OutOfFuel during invocation at250..4815.
- doseq: old4096 ceiling -> unresolved Runtime doseq at232..2382.
- drop-last: old bounded map-count diagnostic -> unresolved Runtime drop-last at245..3362.
- lazy-seq: old4096 ceiling -> unresolved Runtime assert at244..4118.
- merge: old4096 ceiling -> unresolved Runtime any? at237..4689.
- realized-qmark: old4096 ceiling -> unresolved Runtime promise at406..3747.
- map: old4096 failure -> LOADED; all69 observations nonfailing.
- update: old4096 failure -> LOADED; all64 observations reached,63nonfailing and#48kind:error. No previous passed update#48 exists to regress.

## Update#48: evidence and limit

Pinned reference form: (= (apply update [{:k 1} :k inc 1 2 3 4]) {:k 2}); expected predicate/pass, two equal map operands. Capture instead kind:error, verdict:error, thrown opaque with reason EXACT `Host error: Unsupported ABI2 value layout`. This is a newly reachable semantic discrepancy, not an established fuel failure. The captured decoder reason alone does not disclose the underlying thrown Runtime object.

Source runtime/core-import/suss/core.sus:114 binds inc as fixed unary fn[x]; update:6042-6056 variadic branch invokes (apply f (get m k) x y z more). Therefore this form calls inc with extra arguments; pinned CLJS observation expects its arbitrary-extra-arguments behavior. This is a concrete compatibility lead, NOT proof the opaque exception is WrongArity: retain actual error decoding/exception provenance before choosing a code repair. Decoder portable_decode.rs:443/502 explicitly emits this generic unsupported layout error; no diagnostic reason may be invented. Keep the pinned observation unchanged; no blanket baseline update.

## Bounded calibration recommendation

GO in principle for compiler-only10B in broad check("suite") under current252 policy, separate from caller Runtime200M. Macro200M is still blocking contains-qmark; a larger compilation allowance can expose the actual downstream diagnostic/observations. It cannot be asserted to fix update#48 or guarantee whole-suite completion.

Preserve Harness::new default200M/200M and the independently passing original pinned-map200M control. Minimal author change: construct mutable harness locally in check, ONLY if suite=="suite" set its macros compilation allowance10B before harness.run; Runtime remains untouched. Because Harness::new loads harness namespace before returning, this placement calibrates corpus compilation only; no retroactive setup-fuel claim. If earlier initialization is intentionally included, use explicit constructor parameter for that route with default constructor behavior identical, separately reviewed. No helper refill, no global default increase, no runtime allowance change, no low-budget control changes. Preserve failure/skip records and compare protected IDs again after actual execution. This is correctness-test calibration, not fuel-cost optimization or default-performance acceptance.

No source change recommended solely to silence eight diagnostics. Fresh calibrated capture, independently reviewed observed changes and explicit follow-up for newly exposed unsupported behavior are needed before any reviewed-baseline maintenance. Full workspace/final CI still unresolved; cancellation143 is not successful baseline.
