from pathlib import Path
import subprocess,os,json,hashlib,time
r=Path('/home/bobby/Work/code/bobby/suss-m4-current-hash-stacks');c=Path('/home/bobby/.cache/suss-m4-work');out=c/'current-hash-stacks';out.mkdir(exist_ok=True);mods=out/'modules';mods.mkdir(exist_ok=True)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(c/'current-hash-stacks-target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2')
s={'base':'8fda18a','stages':[]};receipt=out/'result.json'
def save():receipt.write_text(json.dumps(s,indent=2)+'\n')
def run(name,cmd):
 s['current']=name;save();start=time.time()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 s['stages'].append({'name':name,'command':cmd,'exit':p.returncode,'seconds':time.time()-start});s['current']=None;save();return p.returncode
if run('bootstrap',['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']):raise SystemExit(1)
def leb(b,p):
 n=0;shift=0
 while True:
  v=b[p];p+=1;n|=(v&127)<<shift
  if v<128:return n,p
  shift+=7
def strip(b):
 p=8;result=b[:8]
 while p<len(b):
  start=p;kind=b[p];n,q=leb(b,p+1);p=q+n
  if kind:result+=b[start:p]
 return result
s['operational_wasm']={}
for phase in ['macro','runtime']:
 f='runtime/bootstrap/'+phase+'.wasm';before=subprocess.check_output(['git','show','8fda18a:'+f],cwd=r);after=(r/f).read_bytes();s['operational_wasm'][phase]={'equal':strip(before)==strip(after),'base_stripped_sha256':hashlib.sha256(strip(before)).hexdigest(),'diagnostic_stripped_sha256':hashlib.sha256(strip(after)).hexdigest()}
 (out/(phase+'-base.wasm')).write_bytes(before)
assert all(x['equal'] for x in s['operational_wasm'].values()),s['operational_wasm']
files=sorted([p for p in (r/'crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.sus']]+list((r/'runtime/bootstrap').glob('*')))
s['freeze']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()};save()
env.update(SUSS_HASH_STACK_SAMPLE='1',SUSS_HASH_STACK_MODULES=str(mods),SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1')
run('fixture',['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_source_tags','compiled_source_invocation_tags_distinguish_global_aggregate_and_local_methods','--','--exact','--nocapture','--test-threads=1'])
s['source_unchanged']=all(hashlib.sha256((r/f).read_bytes()).hexdigest()==h for f,h in s['freeze'].items());save()
print(json.dumps({k:v for k,v in s.items() if k!='freeze'},indent=2))
