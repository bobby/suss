from pathlib import Path
import json,hashlib,tarfile,io,re,collections,subprocess
r=Path('/home/bobby/Work/code/bobby/suss-m4-current-hash-stacks');c=Path('/home/bobby/.cache/suss-m4-work');o=c/'current-hash-stacks';s=json.loads((o/'result.json').read_text());assert s['current'] is None and s['source_unchanged']
raw=(o/'fixture.log').read_text();ops=[json.loads(line.split('hash-stack-operation ',1)[1]) for line in raw.splitlines() if line.startswith('hash-stack-operation ')]
balances=[int(x) for x in re.findall(r'macro-fuel user/invocation-tag decoded: (\d+)',raw)];expected=[8354757,6639177,4094597,1538479]
summary={'base':'8fda18a','decoded_remaining':balances,'expected_untraced':expected,'balances_match':balances==expected,'starts':len(re.findall(r'macro-fuel user/invocation-tag start:',raw)),'failure_lines':[x for x in raw.splitlines() if 'caller &env input transport' in x or 'test result:' in x],'operation_count':len(ops),'operations':[],'limitations':['100us requested epoch timer is scheduler dependent; entry/safepoint bias remains.','Fuel timestamps locate samples; sample frequency is not exclusive or proportional fuel evidence.','Fuel strata anchored at first eligible hash tick in each expansion; 64 strata of156250 with8 reservoir samples each.','Deterministic reservoir priorities are not statistically independent from guest entry order.','Up to512 retained samples per expansion and4096 total; exhausted caps do not imply no later work.','Only actual host-observed IHash dynamic extents are sampled; guest-only hashes outside these extents are absent.','Stack names and offsets identify sampled callees; inclusive ancestors are not additive costs.','Host backtrace capture and module saving perturb wall time and sampling; matching fuel boundaries only establishes this fixture fuel equivalence.','Single default-fuel invocation-tag fixture; no compatibility, optimization or issue closure claim.']}
for op in ops:
 rows=[x for b in op['bins'] for x in b['samples']];counts=collections.Counter(x['frames'][0]['name'] if x['frames'] else '<empty>' for x in rows)
 summary['operations'].append({'operation':op['operation'],'target':op['target'],'retained':len(rows),'eligible_ticks':sum(b['seen'] for b in op['bins']),'bins':len(op['bins']),'fuel_min':min((x['fuel'] for x in rows),default=None),'fuel_max':max((x['fuel'] for x in rows),default=None),'hash_depth_on_exit':op['hash_depth_on_exit'],'sampled_top_frames':counts.most_common()})
assert all(x['retained']<=512 for x in summary['operations']);assert sum(x['retained'] for x in summary['operations'])<=4096
(o/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(o/'samples.json').write_text(json.dumps(ops,indent=2)+'\n')
def leb(b,p):
 n=0;shift=0
 while True:
  v=b[p];p+=1;n|=(v&127)<<shift
  if v<128:return n,p
  shift+=7
def string(b,p):
 n,p=leb(b,p);return b[p:p+n].decode(errors='replace'),p+n
maps={}
for p in list((o/'modules').glob('*.wasm'))+[r/'runtime/bootstrap/macro.wasm',r/'runtime/bootstrap/runtime.wasm']:
 b=p.read_bytes();at=8;names={}
 while at<len(b):
  kind=b[at];size,q=leb(b,at+1);end=q+size
  if kind==0:
   name,q=string(b,q)
   if name=='name':
    while q<end:
     sub=b[q];n,start=leb(b,q+1);q=start+n
     if sub==1:
      count,k=leb(b,start)
      for _ in range(count):
       idx,k=leb(b,k);text,k=string(b,k);names[idx]=text
  at=end
 maps[str(p.relative_to(o)) if p.is_relative_to(o) else str(p.relative_to(r))]={'sha256':hashlib.sha256(b).hexdigest(),'functions':names}
(o/'names.json').write_text(json.dumps(maps,indent=2)+'\n')
payload={}
for f,h in s['freeze'].items():
 b=(r/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h;payload['snapshot/'+f]=b
for p in o.rglob('*'):
 if p.is_file():payload['raw/'+str(p.relative_to(o))]=p.read_bytes()
for f in ['run-current-hash-stacks.py','package-current-hash-stacks.py']:payload['runners/'+f]=(c/f).read_bytes()
for f in ['Cargo.toml','Cargo.lock','crates/suss-compile/Cargo.toml','crates/suss-compile/build.rs']:payload['support/'+f]=(r/f).read_bytes()
payload['change.patch']=subprocess.check_output(['git','diff','8fda18a','--','crates'],cwd=r)
manifest={f:hashlib.sha256(b).hexdigest() for f,b in sorted(payload.items())};payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode();out=r/'docs/roadmap/evidence/m4-current-hash-stacks-2026-10-16.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for f,b in sorted(payload.items()):
  m=tarfile.TarInfo(f);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(out) as t:
 for f,h in manifest.items():assert hashlib.sha256(t.extractfile(f).read()).hexdigest()==h
result={'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'payloads':len(manifest),'freeze':len(s['freeze']),'modules':len(maps),'summary':summary};(c/'current-hash-stacks-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
