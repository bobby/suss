fn main() { std::fs::write("/home/bobby/.cache/suss-m4-work/current-hash-stacks/runtime-abi.wasm", suss_compile::runtime_abi::module()).unwrap(); }
