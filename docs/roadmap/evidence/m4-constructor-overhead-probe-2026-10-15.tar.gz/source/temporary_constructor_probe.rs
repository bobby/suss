
    #[test]
    fn compiler_data_constructor_exact_arity_cost_and_field_identity() {
        fn direct(session: &mut Session, class: &SessionValue, arguments: &[&SessionValue]) -> SessionValue {
            let descriptor = session.data_descriptor(class, true).unwrap();
            let mut scope = RootScope::new(&mut session.store);
            let mut output = [Val::null_any_ref()];
            session.runtime.get_func(&mut scope, "args-new").unwrap()
                .call(&mut scope, &[Val::I32(arguments.len() as i32)], &mut output).unwrap();
            let array = output[0].unwrap_anyref().unwrap().as_array(&scope).unwrap().unwrap();
            for (index, value) in arguments.iter().enumerate() {
                let value = Val::AnyRef(Some(value.value.to_rooted(&mut scope)));
                array.set(&mut scope, index as u32, value).unwrap();
            }
            let function = session.runtime.get_func(&mut scope, "object-new").unwrap();
            let descriptor = Val::AnyRef(Some(descriptor.value.to_rooted(&mut scope)));
            call(&mut scope, session.runtime, function, &[descriptor, output[0].clone()], session.identity, &session.handles).unwrap()
        }
        let mut session = Session::new().unwrap();
        session.eval("(deftype BridgeCtorProfile [a b])").unwrap();
        let class = session.eval("BridgeCtorProfile").unwrap();
        let a = session.data_scalar(&crate::portable::hir::Literal::Number(7.0)).unwrap();
        let b = session.data_scalar(&crate::portable::hir::Literal::Number(11.0)).unwrap();
        drop(session.data_construct(&class, &[&a, &b]).unwrap());
        drop(direct(&mut session, &class, &[&a, &b]));
        let mut samples = Vec::new();
        let mut held = Vec::new();
        for use_direct in [false, true, true, false] {
            let request = session.operation_budget_scope().unwrap();
            let before = session.store.get_fuel().unwrap();
            let mut last = None;
            for _ in 0..1000 {
                last = Some(if use_direct { direct(&mut session, &class, &[&a, &b]) }
                    else { session.data_construct(&class, &[&a, &b]).unwrap() });
            }
            samples.push(before - session.store.get_fuel().unwrap());
            held.push(last.unwrap());
            drop(request);
        }
        session.collect().unwrap();
        for value in &held {
            let fields = session.data_fields(value).unwrap();
            assert_eq!(fields.len(), 2);
            for (field, expected) in fields.iter().zip([&a, &b]) {
                assert!(session.inspect(field, |mut store, value| {
                    let expected = expected.value.to_rooted(&mut store);
                    Ok(wasmtime::Rooted::<wasmtime::AnyRef>::ref_eq(&store, value.unwrap_anyref().unwrap(), &expected)?)
                }).unwrap());
            }
        }
        eprintln!("constructor warmed exact-arity probe [legacy,direct,direct,legacy]: {samples:?}");
    }
