from pathlib import Path
import os,json,subprocess,time,hashlib
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');out=cache/'native-method-this-foundation';out.mkdir(exist_ok=False)
expected=json.loads((cache/'native-method-this-candidate/after-bootstrap-freeze.json').read_text())
freeze=lambda:{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in expected}
assert freeze()==expected
prior=json.loads((cache/'native-walker-verification/final-provenance-receipt.json').read_text());receipt=[]
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
for i,item in enumerate(prior):
 start=time.monotonic();cmd=item['command']
 with (out/(str(i)+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt.append({'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-start});(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
actual=freeze();result={'input_count':len(expected),'inputs_unchanged':actual==expected,'changed':[p for p in expected if expected[p]!=actual[p]],'commands':len(receipt),'all_exit0':all(x['exit']==0 for x in receipt)}
(out/'source-correspondence.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
