from pathlib import Path
import json,hashlib,tarfile,io
cache=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');run=cache/'native-method-this-candidate'
state=json.loads((run/'receipt.json').read_text());assert state['current'] is None,'Do not package a live cohort'
assert state['final_changed']==[]
files={};tuples={};sha=lambda b:hashlib.sha256(b).hexdigest()
for label in ['before','after-bootstrap']:
 frozen=json.loads((run/(label+'-freeze.json')).read_text());tuples[label]=frozen
 for rel,digest in frozen.items():
  data=(run/label/rel).read_bytes();assert sha(data)==digest
  files['inputs/'+digest]=data
for directory in ['native-method-this-candidate','native-method-this-foundation','method-this-facts-layout-probe','native-method-this-parent-control','native-method-this-independent-review']:
 base=cache/directory
 for path in base.rglob('*'):
  if (directory!='native-method-this-parent-control' or path.relative_to(base).parts[0]!='before-source') and path.is_file() and path.name not in ['layout','layout.rs'] and (directory!='native-method-this-candidate' or path.relative_to(base).parts[0] not in ['before','after-bootstrap']):
   files['runs/'+directory+'/'+str(path.relative_to(base))]=path.read_bytes()
for name in ['run-native-method-this-candidate.py','run-native-method-this-foundation.py','native-method-this-command-plan.json','compare-native-method-this-map.py','package-native-method-this.py']:
 files['commands/'+name]=(cache/name).read_bytes()
manifest={'parent':'682d2b8262998859c08aae616e170202c99f0d86','source_checkpoint':'4d0c4887831800385ad36b37bf5a7fdd5ed938dc','scope':'Immutable MethodThis facts shared by binding revisions; separately charged new construction owners and COW retains; all raw failures preserved. Full workspace baseline and final-head CI not established by this archive. Custom30M compiler probe is diagnostics only, no user program execution.','input_storage':'Each tuple path/digest maps to exact bytes in inputs/<digest>. Duplicate bytes stored once.','layout_probe':'Direct rustc probe against exact recorded producer rlib; layout evidence only, no guest execution or fuel saving inferred.','tuples':tuples,'payloads':{p:sha(b) for p,b in sorted(files.items())}}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=root/'docs/roadmap/evidence/m4-shared-method-receiver-facts-2026-10-17.tar.gz'
with tarfile.open(out,'w:gz') as archive:
 for name,data in sorted(files.items()):
  item=tarfile.TarInfo(name);item.size=len(data);archive.addfile(item,io.BytesIO(data))
with tarfile.open(out) as archive:
 for name,digest in manifest['payloads'].items():assert sha(archive.extractfile(name).read())==digest
result={'path':str(out),'sha256':sha(out.read_bytes()),'payloads':len(files),'bytes':out.stat().st_size}
(cache/'native-method-this-package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
