#!/usr/bin/env python3
"""Run only after the shared producer ends; pass its exact suss_compile rlib."""
import hashlib, json, pathlib, subprocess, sys
root = pathlib.Path(__file__).resolve().parent
rlib = pathlib.Path(sys.argv[1]).resolve(strict=True)
assert rlib.name.startswith('libsuss_compile-') and rlib.suffix == '.rlib'
source = root / 'layout.rs'
binary = root / 'layout-probe'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
command = ['rustc', '--edition=2024', str(source), '--extern', 'suss_compile='+str(rlib),
           '-L', 'dependency='+str(rlib.parent), '-o', str(binary)]
receipt = {'command': command, 'rlib': str(rlib), 'rlib_sha256_before': sha(rlib),
           'probe_sha256': sha(source), 'parent_reported': {'SourceRole':64, 'LocalBinding':160},
           'qualification':'Direct rlib layout only; no guest execution, fuel savings or acceptance proof.'}
compiled = subprocess.run(command, capture_output=True, text=True)
(root/'compile.stdout').write_text(compiled.stdout)
(root/'compile.stderr').write_text(compiled.stderr)
receipt['compile_exit'] = compiled.returncode
if compiled.returncode == 0:
    run = subprocess.run([str(binary)], capture_output=True, text=True)
    (root/'layout.stdout').write_text(run.stdout)
    (root/'layout.stderr').write_text(run.stderr)
    receipt.update(run_exit=run.returncode, output=run.stdout)
receipt['rlib_sha256_after'] = sha(rlib)
receipt['rlib_unchanged'] = receipt['rlib_sha256_before'] == receipt['rlib_sha256_after']
(root/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
sys.exit(receipt.get('run_exit', receipt['compile_exit']))
