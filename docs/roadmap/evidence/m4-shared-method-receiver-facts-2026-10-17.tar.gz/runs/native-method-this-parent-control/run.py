import os,subprocess,json,hashlib,time,pathlib,shutil
root=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-method-this-parent-682')
out=pathlib.Path('/home/bobby/.cache/suss-m4-work/native-method-this-parent-control')
def git(*args):return subprocess.check_output(['git',*args],cwd=root).decode().strip()
def capture(label,copy=False):
 paths=[p for p in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0') if p and (root/p).is_file()]
 paths += ['clojurescript/'+p for p in subprocess.check_output(['git','ls-files','-z'],cwd=root/'clojurescript').decode().split('\0') if p and (root/'clojurescript'/p).is_file()]
 hashes={}
 for p in sorted(paths):
  data=(root/p).read_bytes();hashes[p]=hashlib.sha256(data).hexdigest()
  if copy:
   dest=out/'before-source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 (out/(label+'-freeze.json')).write_text(json.dumps(hashes,indent=2)+'\n')
 return hashes
before=capture('before',True)
cmd=['cargo','test','-p','suss-cli','--locked','--test','compiled_macro_self_local_methods','--','--test-threads=2']
env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['CARGO_TARGET_DIR']='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target'
r={'head':git('rev-parse','HEAD'),'cwd':str(root),'command':cmd,'env_overrides':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_TARGET_DIR']},'submodule':git('-C','clojurescript','rev-parse','HEAD'),'driver_pid':os.getpid(),'start_time':time.time(),'source_paths':len(before),'status_before':git('status','--porcelain')}
with (out/'command.log').open('wb') as log:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);r['cargo_pid']=p.pid
 (out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 code=p.wait()
after=capture('after');r.update(exit_code=code,elapsed_seconds=time.time()-r['start_time'],unchanged=before==after,changed_paths=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)],status_after=git('status','--porcelain'),log_sha256=hashlib.sha256((out/'command.log').read_bytes()).hexdigest())
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2),flush=True)
