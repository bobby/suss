# Source-derived bit-level witness, NOT a runtime fuel/performance measurement.
import struct,json
hashes=[]
for value in range(128):
    bits=int.from_bytes(struct.pack('<d',float(value)),'little')
    h=0xcbf29ce484222325
    for word in [0,2,bits]: # metadata count, Number tag, exact f64 bits
        h=((h^word)*0x100000001b3)&((1<<64)-1)
    hashes.append(h)
print(json.dumps({'kind':'source-derived hash placement witness, not runtime cost measurement','values':'metadata-free f64 integers 0..127','distinct_full_hashes':len(set(hashes)),'capacity':8192,'distinct_placement_slots':len({h&8191 for h in hashes}),'placement_slots':sorted({h&8191 for h in hashes})},indent=2))
