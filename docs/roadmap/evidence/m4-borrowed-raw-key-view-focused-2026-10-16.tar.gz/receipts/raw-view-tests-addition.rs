    #[test]
    fn borrowed_view_matches_previous_plan_bytes_ids_and_unordered_equivalence() {
        for unordered in [false,true] {
            let mut direct=Interner::default();
            let mut previous=Interner::default();
            for value in corpus() {
                // The legacy raw corpus deliberately includes malformed odd
                // maps. Their existing raw ordered treatment is preserved.
                if unordered && matches!(&value.kind,Kind::Map(v) if v.len()%2!=0) {continue}
                let mut plan=Plan::default();let mut old=Plan::default();
                let root=direct.plan_with_order(&value,&mut plan,unordered,&mut |_|Ok::<_,Error>(())).unwrap();
                let old_root=legacy_plan(&mut previous,&value,&mut old,unordered,&mut |_|Ok::<_,Error>(())).unwrap();
                assert_eq!(root,old_root);
                assert_eq!(plan.nodes.iter().map(|n|n.key).collect::<Vec<_>>(),old.nodes.iter().map(|n|n.key).collect::<Vec<_>>());
                assert_eq!(direct.keys.iter().map(|e|&e.key).collect::<Vec<_>>(),previous.keys.iter().map(|e|&e.key).collect::<Vec<_>>());
                assert_eq!(key(&mut direct,&value),key(&mut direct,&value));
            }
        }
    }
    fn leaf_view(value:&Form)->(Node,Plan) {
        (Node {key:KeyId(0),metadata_count:value.metadata.len(),children:vec![]},Plan::default())
    }
    fn bucket_leaf(table:&mut Interner,value:&Form,bucket:u64,charge:&mut impl FnMut(u64)->Result<(),Error>)->Result<KeyId,Error> {
        assert!(value.metadata.is_empty());
        let (node,plan)=leaf_view(value);
        let view=View {form:value,node:&node,nodes:&plan.nodes,groups:None};
        table.intern_view_bucket(&view,bucket,charge,&mut 0)
    }
    fn prime_borrowed()->Interner {
        let mut table=Interner::default();
        for i in 0..4 {
            let value=form(Kind::String(vec![97,i]));
            assert_eq!(bucket_leaf(&mut table,&value,u64::from(i/2),&mut |_|Ok(())),Ok(KeyId(i as usize)));
        }
        assert_eq!(table.keys.len(),table.keys.capacity());
        table
    }
    fn borrowed_state(table:&mut Interner)->(Vec<(Vec<u8>,Option<usize>)>,Vec<Option<usize>>) {
        (table.keys.iter().map(|e|(e.key.clone(),e.next)).collect(),(0..3).map(|h|table.heads.get(h,&mut |_|Ok::<_,Error>(())).unwrap()).collect())
    }
    #[test]
    fn borrowed_collision_hit_growth_and_every_fuel_irq_cut_are_atomic_and_recover() {
        let candidate=form(Kind::String(vec![97,4]));
        for (value,bucket,is_new) in [(&candidate,0,true),(&candidate,2,true),(&form(Kind::String(vec![97,1])),0,false)] {
            let mut baseline=prime_borrowed();
            let mut total=0;let mut calls=0;
            let expected=bucket_leaf(&mut baseline,value,bucket,&mut |n| {total+=n;calls+=1;Ok(())}).unwrap();
            for fuel in 0..total {
                let mut table=prime_borrowed();let before=borrowed_state(&mut table);let mut remaining=fuel;
                assert_eq!(bucket_leaf(&mut table,value,bucket,&mut |n| {remaining=remaining.checked_sub(n).ok_or(Error::Fuel)?;Ok(())}),Err(Error::Fuel),"fuel {fuel}/{total} bucket {bucket}");
                assert_eq!(borrowed_state(&mut table),before);
                assert_eq!(bucket_leaf(&mut table,value,bucket,&mut |_|Ok(())),Ok(expected));
                assert_eq!(bucket_leaf(&mut table,value,bucket,&mut |_|Ok(())),Ok(expected));
                assert_eq!(table.keys.len(),4+usize::from(is_new));
                for i in 0..4 {assert_eq!(bucket_leaf(&mut table,&form(Kind::String(vec![97,i])),u64::from(i/2),&mut |_|Ok(())),Ok(KeyId(i as usize)));}
            }
            for cut in 1..=calls {
                let mut table=prime_borrowed();let before=borrowed_state(&mut table);let mut call=0;
                assert_eq!(bucket_leaf(&mut table,value,bucket,&mut |_| {call+=1;if call==cut {Err(Error::Cancel)} else {Ok(())}}),Err(Error::Cancel));
                assert_eq!(borrowed_state(&mut table),before);
                assert_eq!(bucket_leaf(&mut table,value,bucket,&mut |_|Ok(())),Ok(expected));
            }
        }
        // A colliding large value must actually enter exact comparison work.
        let mut table=prime_borrowed();let (node,plan)=leaf_view(&candidate);
        let view=View {form:&candidate,node:&node,nodes:&plan.nodes,groups:None};
        let mut compared=0;
        table.intern_view_bucket(&view,0,&mut |_|Ok::<_,Error>(()),&mut compared).unwrap();
        assert!(compared>0);
    }
    #[test]
    fn borrowed_warm_plan_avoids_real_encoding_work_at_the_same_allowance() {
        let value=form(Kind::Vector((0..128).map(|i|form(Kind::Symbol(suss_reader::Symbol {namespace:Some("suss.core".into()),name:format!("long-source-definition-{i}")}))).collect()));
        let mut direct=Interner::default();let mut previous=Interner::default();
        direct.plan(&value,&mut Plan::default(),&mut |_|Ok::<_,Error>(())).unwrap();
        legacy_plan(&mut previous,&value,&mut Plan::default(),false,&mut |_|Ok::<_,Error>(())).unwrap();
        let mut new_plan=Plan::default();let mut old_plan=Plan::default();
        // Equal retained node capacities on both sides, including reset fees.
        direct.plan(&value,&mut new_plan,&mut |_|Ok::<_,Error>(())).unwrap();new_plan.clear_metered(&mut |_|Ok::<_,Error>(())).unwrap();
        legacy_plan(&mut previous,&value,&mut old_plan,false,&mut |_|Ok::<_,Error>(())).unwrap();old_plan.clear_metered(&mut |_|Ok::<_,Error>(())).unwrap();
        let old_keys=direct.keys.iter().map(|e|e.key.clone()).collect::<Vec<_>>();
        let mut optimized=0;let mut legacy=0;
        direct.plan(&value,&mut new_plan,&mut |n| {optimized+=n;Ok::<_,Error>(())}).unwrap();
        legacy_plan(&mut previous,&value,&mut old_plan,false,&mut |n| {legacy+=n;Ok::<_,Error>(())}).unwrap();
        assert!(optimized<legacy,"optimized={optimized} legacy={legacy}");
        assert_eq!(direct.keys.iter().map(|e|e.key.clone()).collect::<Vec<_>>(),old_keys);
        new_plan.clear_metered(&mut |_|Ok::<_,Error>(())).unwrap();old_plan.clear_metered(&mut |_|Ok::<_,Error>(())).unwrap();
        let mut remaining=optimized;
        direct.plan(&value,&mut new_plan,&mut |n| {remaining=remaining.checked_sub(n).ok_or(Error::Fuel)?;Ok(())}).unwrap();
        let mut remaining=optimized;
        assert_eq!(legacy_plan(&mut previous,&value,&mut old_plan,false,&mut |n| {remaining=remaining.checked_sub(n).ok_or(Error::Fuel)?;Ok(())}),Err(Error::Fuel));
        eprintln!("raw-view-warm optimized={optimized} legacy={legacy} same-allowance={optimized}");
    }
