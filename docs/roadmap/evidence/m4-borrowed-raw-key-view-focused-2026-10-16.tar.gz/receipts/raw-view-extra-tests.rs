    #[test]
    fn borrowed_exact_scalar_collisions_reject_every_changed_stored_byte() {
        let mut table=Interner::default();
        let mut reference=Interner::default();
        let mut expected=std::collections::BTreeMap::<Vec<u8>,KeyId>::new();
        for value in corpus().into_iter().filter(|v|v.metadata.is_empty() && matches!(v.kind,Kind::Nil|Kind::Bool(_)|Kind::Number(_)|Kind::String(_)|Kind::Symbol(_)|Kind::Keyword(_))) {
            let (node,plan)=leaf_view(&value);
            let view=View {form:&value,node:&node,nodes:&plan.nodes,groups:None};
            let encoded=view.encode(&mut |_|Ok::<_,Error>(())).unwrap();
            let mut old=Plan::default();
            let root=legacy_plan(&mut reference,&value,&mut old,false,&mut |_|Ok::<_,Error>(())).unwrap();
            assert_eq!(encoded,reference.keys[old.nodes[root].key.0].key);
            let next=KeyId(expected.len());
            let wanted=*expected.entry(encoded.clone()).or_insert(next);
            assert_eq!(table.intern_view_bucket(&view,0,&mut |_|Ok::<_,Error>(()),&mut 0),Ok(wanted));
            assert!(view.matches(&encoded,&mut |_|Ok::<_,Error>(())).unwrap());
            for i in 0..encoded.len() {
                let mut changed=encoded.clone();changed[i]^=1;
                assert!(!view.matches(&changed,&mut |_|Ok::<_,Error>(())).unwrap());
            }
            for end in 0..encoded.len() {assert!(!view.matches(&encoded[..end],&mut |_|Ok::<_,Error>(())).unwrap());}
            let mut extra=encoded.clone();extra.push(0);
            assert!(!view.matches(&extra,&mut |_|Ok::<_,Error>(())).unwrap());
        }
        assert_eq!(table.keys.len(),expected.len());
    }
    #[test]
    fn borrowed_size_decoder_preserves_canonical_boundaries_and_native_maximum() {
        // Synthetic canonical child IDs exercise the pure raw-key codec beyond
        // feasible graph allocation sizes; no source/runtime authority involved.
        let value=form(Kind::Vector(vec![form(Kind::Nil)]));
        for child in [0,127,128,16383,16384,usize::MAX] {
            let nodes=vec![Node {key:KeyId(0),metadata_count:0,children:vec![1]},Node {key:KeyId(child),metadata_count:0,children:vec![]}];
            let view=View {form:&value,node:&nodes[0],nodes:&nodes,groups:None};
            let encoded=view.encode(&mut |_|Ok::<_,Error>(())).unwrap();
            let mut expected=vec![0,7,1];size(&mut expected,child,&mut |_|Ok::<_,Error>(())).unwrap();
            assert_eq!(encoded,expected);
            assert!(view.matches(&encoded,&mut |_|Ok::<_,Error>(())).unwrap());
            for i in 0..encoded.len() {
                let mut changed=encoded.clone();changed[i]^=128;
                assert!(!view.matches(&changed,&mut |_|Ok::<_,Error>(())).unwrap());
            }
            let mut overlong=encoded.clone();*overlong.last_mut().unwrap()|=128;overlong.push(0);
            assert!(!view.matches(&overlong,&mut |_|Ok::<_,Error>(())).unwrap());
            let mut overflow=vec![0,7,1];overflow.extend([255;10]);overflow.push(1);
            assert!(!view.matches(&overflow,&mut |_|Ok::<_,Error>(())).unwrap());
        }
    }
