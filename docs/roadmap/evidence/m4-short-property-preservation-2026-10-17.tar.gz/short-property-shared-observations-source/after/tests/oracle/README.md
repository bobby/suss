# Development ClojureScript oracle

Run `scripts/test-oracle.sh` from any directory with Clojure CLI, Java and Node
installed. The runner requires a clean ClojureScript submodule at
`c4295f303100bbf5afac449242d30bca1126f1a1` (1.12.134); it compiles that source,
not a newer Maven ClojureScript release. Clojure 1.12.1 is explicitly pinned.
`-Srepro` excludes user dependency configuration. Maven/configuration caches use
task-specific `/tmp` directories; output is ignored under `out/`.

The original serializer uses DataView binary64 bits and JavaScript UTF-16 code
units. JSON never carries numbers as decimal floats or strings as scalar Unicode
text. Tagged maps preserve key/value pairs; sets, sequences and vectors retain
their collection kinds. Unknown values fail rather than becoming opaque success.
Transport schema 2 includes ordered effects and either a value or the exact
thrown value plus exception data and message. ExceptionInfo is tagged with data,
message and cause; unknown objects still fail. Schema 1 is rejected. Serialization happens in the observation try block, so a serializer
failure can appear as an exception observation; the strict corpus validator
rejects that substitution for the required value cases.

`cases.json` is the common source corpus. `scripts/oracle_cases.py` generates
development ClojureScript thunks under the ignored output directory; Rust reads
the same expressions and executes compiled core modules. The only different
code is each runner's observation wrapper. The Suss wrapper catches language throws with a separate Boolean discriminator
(so thrown nil/false cannot become a normal return), then returns outcome and trace for independent host GC decoding; it does not call guest equality,
sequence operations or printing to decide a result. Exact prototype integers
are converted to binary64 only if that conversion loses no bits. Inexact
integers and ratios are decoder failures, never silently rounded.

`reference.json` records an actual Node v24.5.0 execution with Java 21.0.2 and
Clojure CLI 1.12.1.1550. It is a reference-side transport fixture, **not a Suss
pass or differential baseline**. `scripts/oracle_transport.py` validates exact
schema, case identities, tags, ordered effects and selected numeric/string
boundaries. Run its malformed transport regressions with the ordinary Python
test suite. Regenerating the snapshot requires reviewing the resulting diff;
the runner writes only `out/observations.json`. The full command uses that fresh
Node result for the Suss differential test; ordinary Cargo/CI tests use the
checked-in reference fixture and need neither Java nor Node.

`scripts/oracle_compare.py` compares tagged values and exact effect order.
Collection kinds remain distinct; map/set iteration order is ignored, with
one-to-one element matching. Numeric bits are exact, including signed zero and
NaN payloads, except the two canonical arithmetic NaN signs are accepted as
permitted by WebAssembly. Raw bits remain in the observations, and storage/
boundary tests require exact NaN bits. This is observation comparison, not guest
numeric equality.
Malformed transport and absent cases fail. `known-failures.json` records reviewed exact failures; a changed failure, new
failure or unexpected pass fails the suite. The migrated native expression
artifact now reports **16 passing, 0 failing, 0 skipped** against both the retained
reference and a fresh pinned compiler/Node execution. The fresh reference exactly
matches the retained JSON values, numeric bits, UTF-16 units and effects. All
original corpus expressions remain unchanged. The host wrapper now uses portable
`(catch :default error ...)` syntax; the prototype wrapper omitted `:default`.
The direct observer reads canonical ABI2 storage, including nominal ExceptionInfo
message/data/cause, without guest printing or equality.

The seven former failures—binary64 rounding, signed zero, surrogate escape forms,
quoted sequence and variadic rest collection kinds, and ExceptionInfo—are resolved
in this bounded corpus. Their original failure records remain in Git at parent
`88abea7` and the migration handoff retains the actual unexpected-pass failure
before baseline reconciliation. An empty current failure file proves this corpus
only; it does not establish full core compatibility or complete M3 acceptance.
Manual observation capture still uses the explicitly ignored `record_observations`
Cargo test with `SUSS_ORACLE_OUTPUT`; it never updates expected failures automatically.

These source files and transport tests are original repository code. The
development compiler uses the existing pinned upstream submodule, whose source
and EPL notices remain intact; no upstream implementation has been copied into
the serializer. Java and Node are development tools, never shipped dependencies.

Caught strings, nil, false, zero and maps now have executing host-decoder
regressions. Their exception data/message are nil according to the pinned
ClojureScript non-Error contract, and their exact thrown values and partial
traces remain intact. Finally cleanup is verified on normal return, body throw,
catch-body throw and cleanup throw. WebAssembly traps remain failures distinct
from caught language throws; fuel/time failures are never language exceptions.

M1-02's bounded evidence-harness acceptance is complete after the merged
implementation audit in [acceptance-m0-m1.md](../../docs/roadmap/acceptance-m0-m1.md).
The historical 9-pass/7-failure result established that evidence harness; it did
not certify compatibility. The native cached expression route now executes the
shared ABI2 pipeline and independently observes all 16 cases successfully,
including ExceptionInfo. Other prototype routes and comprehensive semantic/arity
coverage remain unfinished. See [compiled expression artifacts](../../docs/runtime/compiled-expression-artifacts.md).
On a Wasm trap or failed decoding, the runner cannot recover the partial trace;
that limitation remains explicit. CI checks transport/comparator regressions and
executes the shared Suss corpus against the reference snapshot; it does not build
or run the JVM/Node oracle. The ordinary 201-case baseline retains its original
inputs and expected values and now executes through the native cached bundle API.

## Portable reader boundary

`scripts/test-reader-oracle.sh` executes a separate original 14-case scalar
corpus in the pinned compiler's tools.reader 1.3.6 dependency and Node, comparing
binary64 bits and UTF-16 units exactly. Rust reads the same sources and transfers
parsed scalars into generated ABI runtime objects, inspecting them after GC.
These are reader-boundary observations, not additional compiler compatibility
passes; the shared full-source corpus now has 16 passing/0 failures/0 skips
through the native cached expression route. Remaining prototype compiler routes
still use their EDN reader. See [portable forms](../../docs/runtime/reader-forms.md).

## Portable compiler bootstrap

`scripts/test-portable-pipeline-oracle.sh` compiles and executes the separate
original 259-case `portable-cases.json` corpus in pinned ClojureScript/Node, checks
strict typed observations, then executes generated shared-ABI fragments in Rust.
It uses an ignored generated `.cljc` fixture so reader conditionals are allowed.
This source oracle covers the current scalar/let/do/if/numeric bootstrap only.
The 16-case legacy source corpus and 14-case reader corpus retain their separate
counts and purposes; the 16-case baseline was reconciled only after fresh
pinned agreement, as recorded above. See the
[compiler contract](../../docs/runtime/portable-pipeline.md) for remaining work.

## Primitive numeric helper matrix

`sh scripts/test-numeric-oracle.sh` executes 1,024 unique binary64 bit patterns
through fresh pinned ClojureScript NumberToString/StringToNumber arithmetic, then
executes the embedded Wasm helper through the generated GC runtime and independently
inspects UTF-16 and f64 results. `numeric-cases.json` retains boundary cases and
deterministic sampled inputs with exact tagged expectations. Strict transport
rejects changed pins, duplicate/missing samples, boolean/schema/unit confusion and
wrong value tags. This bounded matrix does not certify every number or core API.
The source corpus additionally checks parsing grammar, whitespace, radix rounding,
UTF-16 concatenation and dynamic arithmetic. No JVM/Node enters the shipped path.
See [numeric build provenance](../../runtime/numeric/README.md).

## Analyzer tag observations

`sh scripts/test-analysis-tags-oracle.sh` force-compiles the original
`analysis_tag_runner.cljs` fixture against the pinned compiler and executes its
Node artifact. The strict checker compares 32 analyzed source observations and
11 actual scalar projections, including field presence, union tags, function
return inference and metadata hints. The fixture deliberately exercises inferred
`number` with string runtime storage; inference and decoded values are separate
facts. This is development-only primary evidence, not a native inference pass or
M3 completion. Java and Node are not shipped dependencies.

## Source macro environment invocation

`sh scripts/test-source-environment-oracle.sh` force-compiles the original
source macro fixture and executes its Node artifact. Three compiler observations
project actual `&form`/`&env` lexical and function-scope facts; four executed scalar
results check initializer effects and returned fact vectors. Native compiled
source macros match the shared projected corpus in both caller phases after GC.
The projection omits symbol metadata and spans. It is not complete portable
AST/inference, metadata or M3 acceptance. The development-only helper adds no
shipped Java/Node dependency.
## Public `reduce-kv` fallback

`sh scripts/test-reduce-kv-fallback-oracle.sh` checks the pinned
ClojureScript source, validates authored fixture and reference hashes, generates
and executes the dedicated five-case oracle corpus, compares its strict tagged
observations, and runs only `portable_reduce_kv_fallback`. The cases exercise the
public fallback for a seqable associative collection without `IKVReduce`, using
real `MapEntry` values. They cover dispatch, empty input, reduced stopping,
throws and left-to-right operand effects, and ordered normal callback traces.
This bounded lane does not invoke the broader reduction suite or establish
complete `reduce-kv` compatibility. The implementation PR links #244 and records
partial roadmap progress with `Refs #19` and `Refs #242`.

## Short literal property lookup

`short-property-cases.json` retains four fresh pinned CLJS observations, with
exact source expressions, nil/boolean/binary64/vector tags and ordered getter
and owner effects. `src/suss_oracle/short_property.cljs` is the original reference
producer. The source/pin/output bindings and both reference attempts are retained
in [the probe evidence](../../docs/roadmap/evidence/m4-short-literal-key-probe-2026-10-17.md).
From this directory, reproduce with the pinned dependencies in `deps.edn`:

```sh
CLJ_CONFIG=/tmp/suss-oracle-clojure-config CLJ_CACHE=/tmp/suss-oracle-clojure-cache \
clojure -J-Xmx1g -J-XX:ActiveProcessorCount=2 -Srepro -M -m cljs.main \
  -co '{:target :nodejs :output-to "out/short-property.js" :output-dir "out/short-property-cljs" :optimizations :none :source-map false :cache-analysis false}' \
  -c suss-oracle.short-property
node out/short-property.js
```

The independent native check is
`cargo test --locked -p suss-cli --test portable_short_property_observations short_property_values_and_getter_effects_match_pinned_cljs_after_gc_in_both_phases -- --exact --test-threads=1`.
It compares the shared expressions in Runtime and Macro sessions after GC and
rejects unsupported observations; it does not use guest printing or equality.
Its execution evidence must be recorded separately from the reference run.
