"""Run only after the worker has frozen the reviewed patch."""
from pathlib import Path
import argparse,fcntl,hashlib,importlib.util,json,os,re,subprocess,time
C=Path(__file__).parent
root=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace')
target=C/'m4-cost-diagnostic-target'
run=C/'short-literal-keys-focused'
BOOT={f'runtime/bootstrap/{p}.{e}' for p in ('macro','runtime') for e in ('wasm','json')}
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def names(path):
    text=(root/path).read_text();assert not re.search(r'#\[ignore',text)
    out=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',text)
    assert out and len(out)==len(set(out));return out
def specs(preservation=False):
    cargo=['cargo','test','--locked'];tail=['--','--test-threads=1','--nocapture']
    out=[{'name':'bootstrap','cmd':['cargo','run','--profile','test','-p','suss-cli','--bin','suss-bootstrap','--locked','--','runtime/bootstrap']}]
    if preservation:
        observed='short_property_values_and_getter_effects_match_pinned_cljs_after_gc_in_both_phases'
        assert observed in names('crates/suss-cli/tests/portable_short_property_observations.rs')
        out.append({'name':'shared-short-property-observations','cmd':cargo+['-p','suss-cli','--test','portable_short_property_observations',observed,'--','--exact','--test-threads=1','--nocapture'],'names':[observed]})
        out.append({'name':'cli-short-property-keys','cmd':cargo+['-p','suss-cli','--test','portable_short_property_keys']+tail,'names':names('crates/suss-cli/tests/portable_short_property_keys.rs')})
        path=C/'run-compact-heads-preservation.py'
        module=importlib.util.spec_from_file_location('preservation_selection',path)
        selected=importlib.util.module_from_spec(module);module.loader.exec_module(selected)
        for stage in selected.stages(root):
            # The unchanged pinned bitwise wrapper already passed in V2.
            if stage['name']=='pinned-bitwise':continue
            out.append({**stage,'cmd':stage['command']})
        for target in ['compiled_macro_namespace_identity','compiled_macro_source_tags']:
            out.append({'name':target,'cmd':cargo+['-p','suss-cli','--test',target]+tail,'names':names('crates/suss-cli/tests/'+target+'.rs')})
        return out
    prefix='portable::emit::short_keys::tests::'
    out.append({'name':'short-key-planning','cmd':cargo+['-p','suss-compile','--lib',prefix]+tail,'names':[prefix+n for n in names('crates/suss-compile/src/portable/emit/short_keys.rs')]})
    for name in ['portable_short_property_keys','runtime_short_property_keys','runtime_abi','portable_closures','portable_primitive_string_access']:
        path=f'crates/suss-compile/tests/{name}.rs'
        out.append({'name':name,'cmd':cargo+['-p','suss-compile','--test',name]+tail,'names':names(path)})
    out.append({'name':'cli-short-property-keys','cmd':cargo+['-p','suss-cli','--test','portable_short_property_keys']+tail,'names':names('crates/suss-cli/tests/portable_short_property_keys.rs')})
    bit='bitwise_hash_match_independently_decoded_primary_observations_after_gc'
    assert bit in names('crates/suss-cli/tests/portable_bitwise_hash.rs')
    out.append({'name':'pinned-bitwise','cmd':cargo+['-p','suss-cli','--test','portable_bitwise_hash',bit,'--','--exact','--test-threads=1','--nocapture'],'names':[bit]})
    core='compiled_macro_core_namespace_keeps_complete_declaration_records'
    assert core in names('crates/suss-cli/tests/compiled_macro_core_environment.rs')
    out.append({'name':'default-core-env','cmd':cargo+['-p','suss-cli','--test','compiled_macro_core_environment',core,'--','--exact','--test-threads=1','--nocapture'],'names':[core],'env':{'SUSS_MACRO_FUEL_TRACE':'1','SUSS_METADATA_FUEL_TRACE':'1'}})
    record=['public_record_nominal_equality_and_predicate_decode_after_gc_in_both_phases','public_records_execute_jank_and_authored_contracts_with_two_nominal_classes']
    reduce='public_reduce_dispatch_and_source_order_match_pinned_cljs_after_gc'
    assert all(n in names('crates/suss-cli/tests/compiled_public_records.rs') for n in record)
    assert reduce in names('crates/suss-cli/tests/portable_reduction_dispatch.rs')
    out.append({'name':'record-reduction','cmd':cargo+['-p','suss-cli','--no-fail-fast','--test','compiled_public_records','--test','portable_reduction_dispatch','--','--exact','--test-threads=1','--nocapture']+record+[reduce],'names':record+[reduce], 'env':{'SUSS_MACRO_FUEL_TRACE':'1','SUSS_METADATA_FUEL_TRACE':'1','SUSS_SOURCE_MATERIALIZE_FUEL_TRACE':'1','SUSS_RAW_KEY_TRACE':'1'}})
    return out
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--packet',type=Path);ap.add_argument('--packet-sha256');ap.add_argument('--run',type=Path,default=C/'short-literal-keys-focused');ap.add_argument('--seed-freeze',type=Path,default=C/'compact-heads-focused/terminal-freeze.json');ap.add_argument('--stages',nargs='+');ap.add_argument('--preservation',action='store_true');args=ap.parse_args()
    stages=specs(args.preservation)
    if args.stages:
        assert len(args.stages)==len(set(args.stages)) and set(args.stages)<={s['name'] for s in stages}
        stages=[s for s in stages if s['name']=='bootstrap' or s['name'] in args.stages]
    output=args.run
    if not args.execute:
        print(json.dumps({s['name']:s.get('names',[]) for s in stages},indent=2));return
    assert args.packet and args.packet_sha256 and sha(args.packet.read_bytes())==args.packet_sha256
    packet=json.loads(args.packet.read_text())
    assert git('rev-parse','HEAD').decode().strip()==packet['base']
    assert git('-C','clojurescript','rev-parse','HEAD').decode().strip()=='c4295f303100bbf5afac449242d30bca1126f1a1'
    assert not git('-C','clojurescript','status','--porcelain').strip()
    seed=json.loads(args.seed_freeze.read_text());assert len(seed) in (2989,2993)
    paths=sorted(set(seed)|set(packet['files']))
    def freeze():return {p:sha((root/p).read_bytes()) for p in paths}
    initial=freeze()
    assert all(initial[p]==h for p,h in packet['files'].items())
    assert all(initial[p]==h for p,h in seed.items() if p not in packet['files'])
    changed=set(git('diff','--name-only').decode().splitlines())
    untracked=set(git('ls-files','--others','--exclude-standard').decode().splitlines())
    assert (changed|untracked)-BOOT==set(packet['files'])
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
        try:envbytes=(proc/'environ').read_bytes();exe=str((proc/'exe').resolve())
        except OSError:continue
        assert b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' not in envbytes and not exe.startswith(str(target)+'/'),('Target occupied',proc.name)
    leases=[]
    for name in ['.typed-scalar-witness.lease','.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease']:
        f=open(target/name,'a+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
    run=output
    run.mkdir(exist_ok=False);(run/'driver.py').write_bytes(Path(__file__).read_bytes());dump(run/'reviewed-source-manifest.json',packet)
    helper=None
    if args.preservation:
        helperpath=C/'run-boxed-integer-bits-preservation.py'
        assert sha(helperpath.read_bytes())=='2812482fb55a8e0ebd2532e9942f7ea638afead76d9605709abefbbebd5646a4'
        module=importlib.util.spec_from_file_location('preservation_comparators',helperpath)
        helper=importlib.util.module_from_spec(module);module.loader.exec_module(helper)
        (run/'host-comparison-helper.py').write_bytes(helperpath.read_bytes())
        (run/'selection-helper.py').write_bytes((C/'run-compact-heads-preservation.py').read_bytes())
    dump(run/'before-freeze.json',initial);dump(run/'source-derived-selection.json',{s['name']:s.get('names',[]) for s in stages})
    state={'driver_pid':os.getpid(),'root':str(root),'base':git('rev-parse','HEAD').decode().strip(),'target':str(target),'input_count':len(paths),'current':None,'stages':[], 'planned_stages':[s['name'] for s in stages], 'limits':'Focused candidate experiment. Default fixtures and allowances unchanged. Failed or missing test observations retained. No full baseline, final-head CI, closure or whole-M4 acceptance claim.'}
    env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1',CARGO_TARGET_DIR=str(target))
    for k in list(env):
        if k.startswith('SUSS_') and (k.endswith('TRACE') or 'CAPTURE' in k):env.pop(k)
    expected=initial
    try:
        for spec in stages:
            assert freeze()==expected
            row={'name':spec['name'],'command':spec['cmd'],'selected_names':spec.get('names',[]),'execution':'UNEXECUTED'};state['stages'].append(row);state['current']=spec['name'];dump(run/'receipt.json',state)
            stageenv=env.copy();stageenv.update(spec.get('env',{}));start=time.monotonic()
            if spec.get('capture'):stageenv['SUSS_CLOJURE_TEST_SUITE_CAPTURE']=str(run/'map-capture')
            with (run/(spec['name']+'.log')).open('w') as out:
                proc=subprocess.Popen(spec['cmd'],cwd=root,env=stageenv,stdout=out,stderr=subprocess.STDOUT);row['pid']=proc.pid;dump(run/'receipt.json',state);code=proc.wait()
            after=freeze();delta=[p for p in paths if after[p]!=expected[p]];row.update(exit=code,seconds=time.monotonic()-start,changed=delta)
            if spec['name']=='bootstrap':
                row['execution']='PASS' if code==0 else 'FAIL'
                if code==0:assert set(delta)<=BOOT;expected=after;dump(run/'after-bootstrap-freeze.json',expected)
                else:dump(run/'receipt.json',state);break
            else:
                assert not delta
                text=(run/(spec['name']+'.log')).read_text(errors='replace')
                starts=re.findall(r'^test (\S+) \.\.\.',text,re.M)
                sums=[tuple(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
                # Integration files can contain nested modules. Their source
                # basenames are required unique by names(); retain full harness
                # names and require a bijection rather than losing that scope.
                observed=starts if any('::' in n for n in row['selected_names']) else [n.rsplit('::',1)[-1] for n in starts]
                row['observed_full_names']=starts
                if len(starts)!=len(set(starts)) or len(observed)!=len(set(observed)) or sorted(observed)!=sorted(row['selected_names']) or sum(sum(x) for x in sums)!=len(starts) or any(x[2] for x in sums):
                    row['execution']='UNESTABLISHED: missing exact selected execution';dump(run/'receipt.json',state);break
                row['execution']='COMPLETE';row['counts']={'pass':sum(x[0] for x in sums),'fail':sum(x[1] for x in sums),'ignore':sum(x[2] for x in sums)}
                if helper and spec['name']=='source-domain-raw-key':
                    row['sourcechild']=helper.sourcechild_compare(run,C/'compact-heads-preservation/source-domain-raw-key.log')
                    if code==0:assert row['sourcechild']['candidate_markers']==row['sourcechild']['control_markers']==220 and row['sourcechild']['ordered_labels_results_match']
                if helper and spec['name']=='map':
                    if code==0:helper.map_compare(root,run)
                    else:row['map_comparison']='UNEXECUTED after Rust failure; raw partial capture retained'
            dump(run/'receipt.json',state)
    finally:
        final=freeze();state['current']=None;state['final_changed']=[p for p in paths if final[p]!=expected[p]];state['unexecuted_stages']=[s['name'] for s in stages if s['name'] not in {r['name'] for r in state['stages']}];dump(run/'terminal-freeze.json',final);dump(run/'receipt.json',state)
    print(json.dumps({'base':state['base'],'current':state['current'],'stages':[{'name':s['name'],'exit':s.get('exit'),'execution':s.get('execution'),'counts':s.get('counts')} for s in state['stages']], 'final_changed':state['final_changed'],'unexecuted_stages':state['unexecuted_stages']}))
if __name__=='__main__':main()
