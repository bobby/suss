from pathlib import Path
import subprocess,hashlib,os,json,fcntl,re,time
C=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-native-fuel-hotspots');target=C/'memo-proof-cost-target';run=C/'namespace-identity-parent-f156df8'
head='f156df883187aee4281f703e853155fcd2e4ad51';sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
paths=[p.decode() for p in subprocess.check_output(['git','ls-files','--recurse-submodules','-z'],cwd=root).split(b'\0') if p]
freeze=lambda:{p:sha((root/p).read_bytes()) for p in paths};before=freeze()
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:env=(p/'environ').read_bytes();exe=str((p/'exe').resolve())
 except OSError:continue
 assert b'CARGO_TARGET_DIR='+str(target).encode()+b'\0' not in env and not exe.startswith(str(target)+'/'),('target occupied',p.name)
leases=[]
for name in ['.sourcechild-target.lease','.native-validation-observer.lease','.sourcechild-complete-cost.lock','.reachable-workspace.lease','.namespace-parent-control.lease']:
 f=open(target/name,'a+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(f)
command=['cargo','test','--locked','-p','suss-cli','--test','compiled_macro_namespace_identity','--','--test-threads=1','--nocapture']
selected=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(', (root/'crates/suss-cli/tests/compiled_macro_namespace_identity.rs').read_text());assert len(selected)==2
run.mkdir(exist_ok=False);(run/'driver.py').write_bytes(Path(__file__).read_bytes());(run/'before-freeze.json').write_text(json.dumps(before,indent=2)+'\n')
state={'driver_pid':os.getpid(),'root':str(root),'target':str(target),'head':head,'inputs':len(paths),'selected_names':selected,'command':command,'current':'namespace-parent-control','execution':'UNEXECUTED','limits':'Matched existing default-budget namespace pair on published pre-probe source. Inherited exact parent bootstrap; no quota/fixture/assertion change. Semantic mismatch is distinct from fuel and missing observations.'}
save=lambda:(run/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
for k in list(env):
 if k.startswith('SUSS_') and ('TRACE' in k or 'OUTPUT' in k or 'CAPTURE' in k):env.pop(k)
save();start=time.monotonic()
try:
 with (run/'raw.log').open('w') as out:
  proc=subprocess.Popen(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT);state['pid']=proc.pid;save();state['exit']=proc.wait()
 state['seconds']=time.monotonic()-start
 raw=(run/'raw.log').read_text(errors='replace');names=re.findall(r'^test (\S+) \.\.\.',raw,re.M);summaries=[tuple(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)];state['observed_names']=names
 if sorted(names)==sorted(selected) and len(summaries)==1 and sum(summaries[0])==2 and summaries[0][2]==0:
  state['execution']='COMPLETE';state['counts']=dict(zip(['pass','fail','ignore'],summaries[0]))
 else:state['execution']='UNESTABLISHED: compile/selection failure; raw retained'
 for marker in ['NAMESPACE_IDENTITY','CALLABLE_NAMESPACE_IDENTITY']:
  rows=re.findall(r'(?<![A-Z_])'+marker+r' (\{[^\n]*\})',raw)
  if len(rows)==1:(run/(marker.lower()+'.json')).write_text(json.dumps(json.loads(rows[0]),indent=2)+'\n')
  state[marker+'_observed']=len(rows)
finally:
 after=freeze();(run/'terminal-freeze.json').write_text(json.dumps(after,indent=2)+'\n');state['changed']=[p for p in paths if before[p]!=after[p]];state['current']=None;save()
print(json.dumps({k:v for k,v in state.items() if k not in ['command','selected_names','observed_names']},indent=2))
