from pathlib import Path
import json,hashlib,subprocess,tarfile,io,importlib.util,re
C=Path(__file__).parent;root=Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace');sha=lambda b:hashlib.sha256(b).hexdigest()
spec=importlib.util.spec_from_file_location('bindings',C/'short-literal-key-probe-publication-preparation/package-v5.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.REPO=root
run=C/'short-property-observations-preservation';parent=C/'namespace-identity-parent-f156df8';r=json.loads((run/'receipt.json').read_text());p=json.loads((parent/'receipt.json').read_text());assert r['current'] is None and not r['final_changed'] and not r['unexecuted_stages'];assert p['current'] is None and not p['changed'] and p['counts']=={'pass':0,'fail':2,'ignore':0}
assert sum(s.get('counts',{}).get('pass',0) for s in r['stages'])==77;assert sum(s.get('counts',{}).get('fail',0) for s in r['stages'])==3
idle_parent=dict(p,stages=[{'pid':p['pid']}]);h.check_idle([r,idle_parent])
source='59fdbad98c5da13d8098e3624863d6403e780365';maps={f:json.loads((run/f).read_text()) for f in ['before-freeze.json','after-bootstrap-freeze.json','terminal-freeze.json']};assert maps['after-bootstrap-freeze.json']==maps['terminal-freeze.json'];bindings=h.git_bindings(maps,source,r['base'])
pmaps={f:json.loads((parent/f).read_text()) for f in ['before-freeze.json','terminal-freeze.json']};assert pmaps['before-freeze.json']==pmaps['terminal-freeze.json'];pbindings=h.git_bindings(pmaps,p['head'],p['head'])
payload={}
for folder in [run,parent,C/'short-property-shared-observations-source']:
 for f in folder.rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:payload[str(f.relative_to(C))]=f.read_bytes()
for name in ['short-property-shared-observations-source-review.json','short-property-observations-preservation-independent-review.json','callable-namespace-retention-independent-diagnosis.json']:
 payload[name]=(C/name).read_bytes()
payload['candidate-git-bindings.json']=(json.dumps(bindings,indent=2)+'\n').encode();payload['parent-git-bindings.json']=(json.dumps(pbindings,indent=2)+'\n').encode();payload['packager.py']=Path(__file__).read_bytes();payload['binding-helper.py']=(C/'short-literal-key-probe-publication-preparation/package-v5.py').read_bytes()
summary={'source':source,'parent':p['head'],'candidate_counts':{'pass':77,'fail':3,'ignore':0},'candidate_input_count':2996,'parent_counts':p['counts'],'parent_input_count':4026,'candidate_failures':{'compiler_namespace_and_declaration_aliases_match_pinned_five_call_observations':'both phase projections unexecuted: fuel during compiled macro invocation184..224','resolved_callable_info_keeps_raw_declaration_children_across_macro_invocations':'six returned rows, no request errors, later4 identity mismatches indices5/7/8; inherited: parent complete observations identical','compiled_source_inference_matches_pinned_tags_without_changing_executed_storage_or_effects':'caller-env fuel382..414 before required32row/storage/effect assertions'},'sourcechild':{'markers':220,'ordered_labels_results_match':True,'candidate_final_remaining_each_phase':149643,'control_final_remaining_each_phase':132163,'delta_each_phase':17480},'map':{'ordered_ids':69,'host_pass':62,'guest_judged':7,'fail':0,'skip':0,'missing':0,'unchanged_allowance':200000000},'limits':['Counts are separate executions, not a unique-test union with earlier runs.','Input map scopes differ: candidate2996 component inputs; parent4026 complete tracked files. Both fully bound to explicit Git refs.','First namespace whole cost/progress unknown beyond matching failure stage/span.','Record/CoreEnv four failures remain separately reported on4541 source; no acceptance from this packet.','No full baseline/final CI/issue closure/readiness/merge.']}
payload['publication-summary.json']=(json.dumps(summary,indent=2)+'\n').encode()
index={n:{'sha256':sha(b),'bytes':len(b)} for n,b in sorted(payload.items())};payload['MANIFEST.json']=(json.dumps({'schema':1,'files':index},indent=2)+'\n').encode();h.check_idle([r,idle_parent]);out=C/'m4-short-property-preservation-2026-10-17.tar.gz';assert not out.exists()
with out.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz') as t:
  for n,b in sorted(payload.items()):
   ti=tarfile.TarInfo(n);ti.mode=0o644;ti.mtime=0;ti.size=len(b);t.addfile(ti,io.BytesIO(b))
with tarfile.open(out,'r:gz') as t:
 assert len(t.getnames())==len(set(t.getnames()))==len(payload)
 for n,d in index.items():assert sha(t.extractfile(n).read())==d['sha256']
result={'archive':str(out),'sha256':sha(out.read_bytes()),'members':len(payload),'payloads':len(index),'candidate_inputs':2996,'parent_inputs':4026,'source':source};out.with_suffix(out.suffix+'.result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
