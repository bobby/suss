DRAFT ONLY; no compiler/Node execution performed. Source file:
  suss_oracle/metadata_memo_boundary.cljs
Use existing pinned oracle runner conventions, adding this external directory to
CLJS classpath (:paths or -Sdeps :paths) and selecting this namespace. Keep exact
CLJS revision/clean-tree checks, isolated external output and source/runner/log
hashes. Do not write expectations before inspecting successful terminal JSON.

Existing evidence: delegated and constant-return91 replacements preserve
identity in the order probe, but constant91 does NOT write a new memo. No existing
pinned observation establishes direct arbitrary memo writes or poison/restore.
This draft adds macro-executed custom IHash write91 vs direct write991, each with
source healthy and transient99 restored17, plus unrestored99 negative control.
The replacement changes only the subject's computation; other ArrayMaps delegate
original, avoiding accidental global analyzer hashing corruption.

Interpretation: identity and stored memo outcomes are observations, not asserted
success targets. If CLJS retains direct991 or poison/restored memo, that reveals
an integrity-policy difference, NOT permission to weaken #257 source rejection.
Unrestored99 checks whether analyzer storage itself remains mutable rather than
assuming it reconstructs immutable source. Initial declaration text/value is17;
a fully independent new-state source-control arm can be added before publication
if claiming explicit reexecution as distinct from the known input assertion.

Follow-up needed for dynamic-dispatch authorization proposal: add nested callback
which writes subject memo while IHash is active, and healthy write followed by
poison/restore later in same method. These distinguish mere ambient dynamic scope
from the intended exact execution/return boundary. This draft does not yet cover
those cases or raw boxed-number identity (CLJS numbers are JS primitives).
