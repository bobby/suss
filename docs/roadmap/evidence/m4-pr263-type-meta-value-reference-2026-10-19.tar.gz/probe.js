'use strict';
const path = require('path');
const base = '/home/bobby/.cache/suss-m4-work/memo-call-boundary-draft/out';
require(path.join(base,'goog/bootstrap/nodejs.js'));
require(path.join(base,'cljs_deps.js'));
goog.global.CLOSURE_UNCOMPILED_DEFINES = {'cljs.core._STAR_target_STAR_':'nodejs'};
for (const ns of ['cljs.core','cljs.analyzer','cljs.env','cljs.js','cljs.tools.reader','cljs.nodejs']) goog.require(ns);
cljs.nodejs.enable_util_print_BANG_();
const c=cljs.core,a=cljs.analyzer;
const kw=s=>c.keyword(s), vec=xs=>c.vec(xs), keys=m=>m==null?[]:c.into_array(c.keys(m));
const key=(m,name)=>keys(m).find(x=>x.fqn===name);
const cases=[
 ['fresh-type-no-meta',['(deftype* watched [] nil nil)']],
 ['prior-shorthand-meta',['(def ^number watched 17)','(deftype* watched [] nil nil)']],
 ['prior-doc-function',['(def watched "prior doc" (fn* [] 17))','(deftype* watched [] nil nil)']],
 ['current-nil-tag-false-doc',['(def watched "prior doc" (fn* [] 17))','(deftype* ^{:tag nil :doc false} watched [] nil nil)']],
 ['current-tag-doc',['(def watched "prior doc" (fn* [] 17))','(deftype* ^{:tag current-tag :doc "current doc"} watched [] nil nil)']],
 ['explicit-current-meta-map',['(def ^number watched 17)','(deftype* ^{:meta {:marker :current}} watched [] nil nil)']],
 ['explicit-current-meta-false',['(def ^number watched 17)','(deftype* ^{:meta false} watched [] nil nil)']],
 ['repeat-retained-explicit-meta',['(def ^{:tag prior-tag :doc "old"} watched 17)','(deftype* ^{:meta {:marker :first}} watched [] nil nil)','(deftype* ^{:doc "later"} watched [field] nil nil)']]
];
const rows=[];
if(c.NS_CACHE==null)c.NS_CACHE=c.atom(c.PersistentArrayMap.EMPTY);
const originalCache=c.deref(c.NS_CACHE);
for(const [label,source] of cases){
 const state=cljs.js.empty_state(), target=c.symbol('suss-oracle.declaration-key-origin');
 const nsPath=vec([kw('cljs.analyzer/namespaces'),target]);
 c.swap_BANG_(state,c.assoc_in,nsPath,c.hash_map(kw('name'),target,kw('defs'),c.PersistentArrayMap.EMPTY));
 const saved=[cljs.env._STAR_compiler_STAR_,a._STAR_cljs_ns_STAR_,a._STAR_analyze_deps_STAR_,a._STAR_load_macros_STAR_];
 const proto=c.Keyword.prototype,slot='cljs$core$IHash$_hash$arity$1',original=proto[slot],events=[];
 let restored=false;
 try{
  cljs.env._STAR_compiler_STAR_=state;a._STAR_cljs_ns_STAR_=target;a._STAR_analyze_deps_STAR_=false;a._STAR_load_macros_STAR_=false;
  const forms=source.map(x=>cljs.tools.reader.read_string(x)),form=forms[forms.length-1],sym=c.second(form),meta=c.meta(sym);
  const originalRawKeys=forms.flatMap(f=>keys(c.meta(c.second(f))).map(k=>({ref:k,name:k.fqn,memo:k._hash})));
  let previousKeys=[],previous=null,previousMeta=null;
  const rawKeys=keys(meta).map(k=>({ref:k,name:k.fqn,memo:k._hash}));
  const top=c.get(meta,kw('top-fn')),topKeys=keys(top).map(k=>({ref:k,name:k.fqn,memo:k._hash}));
  proto[slot]=function(coll){events.push({ref:this,name:this.fqn,memo:this._hash});return this._hash==null?original.call(this,coll):this._hash;};
  const env=c.assoc(a.empty_env(),kw('ns'),a.get_namespace(target));
  let ast=null;
  for(let i=0;i<forms.length;i++){
    const prior=c.get_in(c.deref(state),vec([kw('cljs.analyzer/namespaces'),target,kw('defs'),c.symbol('watched')]));
    previous=prior; previousMeta=c.get(prior,kw('meta'));
    previousKeys=keys(prior).map(k=>({ref:k,name:k.fqn,memo:k._hash}));
    ast=a.analyze(c.assoc(a.empty_env(),kw('ns'),a.get_namespace(target)),forms[i]);
  }
  const decl=c.get_in(c.deref(state),vec([kw('cljs.analyzer/namespaces'),target,kw('defs'),c.symbol('watched')]));
  if(!decl)throw Error('missing actual declaration');
  const macroNs=c.symbol('suss-oracle.declaration-origin-macros$macros');
  let macroEntries=0,observedDecl=null,observedMeta=null;
  const observer=function(macroForm,macroEnv){macroEntries++;observedDecl=c.get_in(macroEnv,vec([kw('ns'),kw('defs'),c.symbol('watched')]));observedMeta=c.get(observedDecl,kw('meta'));return 17;};
  observer.cljs$lang$macro=true;
  c.swap_BANG_(state,c.assoc_in,vec([kw('cljs.analyzer/namespaces'),macroNs]),c.hash_map(kw('name'),macroNs,kw('defs'),c.hash_map(c.symbol('observe'),c.hash_map(kw('name'),c.symbol('suss-oracle.declaration-origin-macros$macros/observe'),kw('macro'),true,kw('method-params'),vec([vec([c.symbol('&form'),c.symbol('&env')])]),kw('max-fixed-arity'),2))));
  c.swap_BANG_(c.NS_CACHE,c.assoc,macroNs,c.create_ns(macroNs,{observe:observer}));
  const analysisEvents=events.slice();
  const macroAst=a.analyze(c.assoc(a.empty_env(),kw('ns'),a.get_namespace(target)),cljs.tools.reader.read_string('(suss-oracle.declaration-origin-macros/observe)'));
  if(macroEntries!==1||observedDecl!==decl||c.get(macroAst,kw('val'))!==17)throw Error('actual macro env/result mismatch');
  const captured=keys(observedDecl).map(k=>({name:k.fqn,memo:k._hash,raw:rawKeys.some(x=>x.ref===k),top:topKeys.some(x=>x.ref===k),rawInitial:(rawKeys.find(x=>x.name===k.fqn)||{}).memo,topInitial:(topKeys.find(x=>x.name===k.fqn)||{}).memo,fromPrevious:previousKeys.some(x=>x.ref===k),fromOriginalMetadata:originalRawKeys.some(x=>x.ref===k),originalMetadataMemo:(originalRawKeys.find(x=>x.ref===k)||{}).memo,firstHash:(analysisEvents.find(x=>x.ref===k)||{}).memo,hashCount:analysisEvents.filter(x=>x.ref===k).length,value:['name','doc','tag','ret-tag','fn-var','variadic?','max-fixed-arity','meta','type','num-fields','record'].includes(k.fqn)?c.pr_str(c.get(observedDecl,k)):undefined}));
  const selected=['name','tag','ret-tag','doc','fn-var','type','num-fields','record','meta'];
  const fields=m=>Object.fromEntries(selected.map(name=>[name,{present:!!c.contains_QMARK_(m,kw(name)),value:c.pr_str(c.get(m,kw(name)))}]));
  const metaMap=!!c.map_QMARK_(observedMeta),previousMap=!!c.map_QMARK_(previousMeta);
  const currentRawMeta=c.get(meta,kw('meta'));
  const outerTag=key(observedDecl,'tag'),innerTag=metaMap?key(observedMeta,'tag'):null;
  rows.push({label,source,macroEntries,actualMacroSameDeclaration:observedDecl===decl,
    actualMacroSameMeta:observedMeta===c.get(decl,kw('meta')),macroResult:c.get(macroAst,kw('val')),
    astOp:c.str(c.get(ast,kw('op'))),fields:fields(observedDecl),previousFields:fields(previous),
    metaIsMap:metaMap,metaSamePreviousMap:metaMap&&previousMap&&observedMeta===previousMeta,
    metaSameCurrentRawMap:metaMap&&!!c.map_QMARK_(currentRawMeta)&&observedMeta===currentRawMeta,
    previousMeta:c.pr_str(previousMeta),currentRawMeta:c.pr_str(currentRawMeta),meta:c.pr_str(observedMeta),
    outerMetaKeySamePrevious:!!key(observedDecl,'meta')&&key(observedDecl,'meta')===key(previous,'meta'),
    innerTagPresent:!!innerTag,innerTagValue:innerTag?c.pr_str(c.get(observedMeta,innerTag)):null,
    outerTagKeySameInner:!!outerTag&&!!innerTag&&outerTag===innerTag,keys:captured});
 }finally{
  proto[slot]=original;restored=proto[slot]===original;
  [cljs.env._STAR_compiler_STAR_,a._STAR_cljs_ns_STAR_,a._STAR_analyze_deps_STAR_,a._STAR_load_macros_STAR_]=saved;
  c.reset_BANG_(c.NS_CACHE,originalCache);
  if(c.deref(c.NS_CACHE)!==originalCache)throw Error('NS cache restore failed');
  if(!restored)throw Error('restore failed');
 }
}
console.log(JSON.stringify({scope:'retained pinned analyzer: actual macro declaration/meta references, shallow type metadata/value updates; not fresh CLJS build/native Suss acceptance',cases:rows},null,2));
