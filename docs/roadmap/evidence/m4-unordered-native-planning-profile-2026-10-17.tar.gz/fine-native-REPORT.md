# Fine native attribution, exact unordered default test

All1067 original checkpoints match exactly:1063 declaration +3 macro +1 graph start.0PASS1FAIL, unchanged freeze. New diagnostic labels do not change observed old fuel balances.

Completed1127 form plans: raw-plan4,546,273; recipe-walk429,607; clear108,484. These are disjoint within the form path. Last open plan starts with98 remaining and has no finish; no zero or completed cost assigned.

Completed declaration tails partition as definition-origin→completed-tag97,300; completed-tag→definition-plan4,255,829; definition-plan→finished1,432,318. Their sum5,785,447 includes one additional definition-plan checkpoint for the unfinished PersistentHashMap declaration; the former5,695,320 total counted only fully finished old tails. Do not add form totals to declaration totals.

Definition helper nested partition: full guard136,538; initializer correspondence6,657; correspondence→definition-recipes4,112,458 (includes raw planning/recipe/reset/control). Neither guard nor correspondence is dominant.

Last periodic interner snapshot, not exact final totals:25600intern calls3252entries/22348hits; intern2,303,515 includes comparisons456,516, headlookup276,272, headinsert385,576 and entry storage bookkeeping. The unsampled tail means this is a checkpoint subtotal, not a full root-plan partition. Traversal/encoding/scratch outside interning are not independently instrumented by these counters. No pure hashing claim.

Strongest measured target is definition-form raw planning before recipe lookup, not getter/hash runtime, metadata normalization, AST jobs, guard omission or initializer correspondence. A genuine retained catalog DefinitionInfo-owned field plan could remove cold encoding/traversal and repeated interning only if bound to the actual immutable field owner and loaded/translated into graph-local keys with complete guards preserved. Equal content, origin pointer, symbol name or source span cannot authorize a hit. Existing owner-bound catalog/cold transport proof is relevant; current trace alone does not authorize coverage or net savings. Required first implementation proof is exact byte/ID-equivalent originalPlan export/import plus actual binding/load/seed work on this unchanged unordered fixture, with generated/unmatched fields on the existing planner. No global guest identity/cache, prewarming, callback bypass, quota or tariff change.

A generic graph-local root cache without demonstrated repeated exact owners would miss the cold traversal and is not justified by25600calls alone: interner hits are structural subkeys, not proof of repeated Form owners. Previously rejected flat-edge/word/buffer designs must not be republished as this repair.
