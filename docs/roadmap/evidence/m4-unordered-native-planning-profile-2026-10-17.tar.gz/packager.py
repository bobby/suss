from pathlib import Path
import hashlib,json,subprocess,shutil,tarfile
C=Path('/home/bobby/.cache/suss-m4-work');O=C/'pr268-unordered-native-profile-publication-v1';R=Path('/home/bobby/Work/code/bobby/suss');base='96bc8d70ae447d0dba1e89a3c03e97ce0a0f84bb';old=C/'pr268-unordered-acceptance-profile-v1';run=C/'pr268-unordered-native-plan-profile-v1';packet=C/'pr268-unordered-native-plan-diagnostic-source-v1';analysis=C/'pr268-unordered-acceptance-analysis'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
assert not O.exists();O.mkdir();payload=O/'payload';payload.mkdir()
a=read(old/'receipt.json');b=read(run/'receipt.json');assert a['execution']=='TERMINAL' and a['exit']==101 and a['changed']==[];assert b['current'] is None and b['final_changed']==[] and not b.get('unexecuted_stages')
freeze=read(run/'terminal.json');assert len(freeze)==4044 and freeze==read(run/'after-bootstrap.json');assert read(old/'before.json')==read(old/'terminal.json')
census=read(analysis/'fine-native-census.json');assert census['old_rows_exact']==1067
m=read(packet/'manifest.json');assert m['base']==base
private={m['path']:(packet/'after.rs').read_bytes()};assert sha(private[m['path']])==m['after_sha256']
for phase in ['macro','runtime']:
 for ext in ['wasm','json']:
  f=f'runtime/bootstrap/{phase}.{ext}';private[f]=(run/'bootstrap'/f).read_bytes()
# Resolve immutable full source maps using Git base/submodule, NEVER the author worktree.
pin='c4295f303100bbf5afac449242d30bca1126f1a1';sub=Path('/home/bobby/Work/code/bobby/suss-m4-pr268-sparse-setter/clojurescript')
procs={False:subprocess.Popen(['git','-C',str(R),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE),True:subprocess.Popen(['git','-C',str(sub),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)}
def blob(f):
 issub=f.startswith('clojurescript/');q=procs[issub];path=f[len('clojurescript/'):] if issub else f;rev=pin if issub else base
 q.stdin.write((rev+':'+path+'\n').encode());q.stdin.flush();header=q.stdout.readline().split();assert len(header)==3 and header[1]==b'blob',(f,header)
 data=q.stdout.read(int(header[2]));assert q.stdout.read(1)==b'\n';return data
bindings=[]
for label,fmap in [('baseline',read(old/'terminal.json')),('diagnostic-before',read(run/'before.json')),('diagnostic-terminal',freeze)]:
 mismatch=[]
 for f,h in fmap.items():
  data=private[f] if f in private and label=='diagnostic-terminal' else ((packet/'after.rs').read_bytes() if f==m['path'] and label=='diagnostic-before' else blob(f))
  if sha(data)!=h:mismatch.append(f)
 assert not mismatch,(label,mismatch)
 bindings.append({'tuple':label,'checked':len(fmap),'mismatches':mismatch,'base':base,'private_overrides':list(private) if label=='diagnostic-terminal' else ([m['path']] if label=='diagnostic-before' else []),'pin':pin})
for q in procs.values():q.stdin.close();q.wait()
for label,path in [('baseline-run',old),('diagnostic-run',run),('diagnostic-source-packet',packet)]:shutil.copytree(path,payload/label)
for name in ['fine-native.py','fine-native-census.json','fine-native-REPORT.md','native-preparation.py','native-preparation-census.json','native-preparation-REPORT.md','source-correspondence.json']:
 shutil.copy2(analysis/name,payload/name)
shutil.copy2(Path(__file__),payload/'packager.py');shutil.copy2(C/'create-experiment-snapshot.py',payload/'create-experiment-snapshot.py')
(payload/'immutable-source-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
report='''# Unordered native planning diagnostic\n\nBase96bc8d70; unchanged unordered default10M test. Baseline and normally regenerated diagnostic each0PASS/1typedfuelFAIL during caller &env transport, span510..531. Each4044-input tuple bound using immutable Git base/pinnedCLJS plus the frozen Graph delta/captured BOOT; no changing author-worktree bytes included.\n\nAll1067 old checkpoints/balances match:1063 declaration,3macro,1graph. Failure inside finish_recipes namespace declaration loop before materialization. Graph start9,986,612; last old checkpoint PersistentHashMap definition-origin90,680. New markers reach definition recipe completion554 and next rawplan-start98; no completed graph or materialization.\n\nCompleted1127 form scopes: raw planning4,546,273; recipe walk429,607; clear108,484. Definition guard136,538 and correspondence6,657 are nested, not additive. Broad tail split97,300 before completed-tag;4,255,829 definition-plan;1,432,318 after definition-plan. Last periodic interner snapshot25600calls/3252entries/intern2,303,515; subtotals nested and unsampled tail unknown.\n\nNo whole-request savings or successful graph claim. This is diagnostic evidence only, not a shipping prefix/template, acceptance pass, full baseline or CI outcome. Existing40M collection projection test is a different fixture; this exact unordered fixture remains default10M.\n\nExact commands, flags, raw failures, controllers, approvals and full freezes are retained in both run directories. Diagnostic normalbootstrap precedes its exact unchanged libtest. Future artifact proof code is separate/unexecuted here.\n'''
(O/'REPORT.md').write_text(report)
handoff='''\n\nNative unordered planning diagnostic: base96bc8d70, normalbootstrap then cargo test --locked -p suss-cli --test compiled_macro_collection_source_asts unordered_literal_ast_edges_and_runtime_effects_preserve_textual_order -- --exact --test-threads=1 --nocapture. Flags SUSS_MACRO_FUEL_TRACE/SUSS_METADATA_FUEL_TRACE/SUSS_SOURCE_MATERIALIZE_FUEL_TRACE and diagnostic SUSS_RAW_KEY_TRACE retained in driver. Baseline and diagnostic0PASS1typedfuelFAIL; all1067prior checkpoints equal. Completed rawplan4,546,273/recipes429,607/reset108,484 are nested against declaration totals; no whole-request saving/graph completion. Snapshot contains only Graph diagnostic+its normalBOOT4+this handoff append. Native-field artifact proof is separate work.\n'''
paths={}
for f,data in private.items():
 dst=payload/'snapshot'/f;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);paths[f]={'payload':str(dst.relative_to(payload)),'sha256':sha(data)}
f='docs/roadmap/handoff.md';data=subprocess.check_output(['git','-C',str(R),'show',base+':'+f])+handoff.encode();dst=payload/'snapshot'/f;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);paths[f]={'payload':str(dst.relative_to(payload)),'sha256':sha(data)}
files={str(f.relative_to(payload)):sha(f.read_bytes()) for f in sorted(payload.rglob('*')) if f.is_file()};(payload/'MANIFEST.json').write_text(json.dumps(files,indent=2)+'\n');archive=O/'m4-unordered-native-planning-profile-2026-10-17.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(payload.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(payload)),recursive=False)
result={'archive':str(archive),'sha256':sha(archive.read_bytes()),'report_sha256':sha((O/'REPORT.md').read_bytes()),'members':len(files)+1,'manifested_payloads':len(files),'base':base,'snapshot_paths':paths,'bindings':bindings,'limits':'Diagnostic snapshot only; no native-field artifact code or CI claims.'};(O/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='snapshot_paths'},indent=2))
