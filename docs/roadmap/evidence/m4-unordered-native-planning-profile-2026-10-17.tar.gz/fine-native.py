from pathlib import Path
import re,json,collections
C=Path('/home/bobby/.cache/suss-m4-work');old=(C/'pr268-unordered-acceptance-profile-v1/raw.log').read_text().splitlines();new=(C/'pr268-unordered-native-plan-profile-v1/unordered-profile.log').read_text().splitlines()
def legacy(lines):
 out=[]
 for line in lines:
  if m:=re.search(r'(metadata-declaration \S+ (?:start|guarded|declaration-origin|metadata|definition-origin|finished): \d+|macro-fuel \S+ \S+: \d+|metadata-graph \S+ recipes=\d+ sources=\d+: \d+)',line):out.append(m[1])
 return out
A=legacy(old);B=legacy(new);assert A==B,(len(A),len(B));print('EXACT OLD ROWS',len(A),flush=True)
sums=collections.Counter();counts=collections.Counter();stack=[];defs=[];defsum=collections.Counter();decls={};tail=collections.Counter();profiles=[];an=[]
for i,line in enumerate(new,1):
 if m:=re.search(r'metadata-declaration (\S+) ([\w-]+): (\d+)',line):
  g,stage,f=m[1],m[2],int(m[3]);prev=decls.get(g)
  if prev and stage in ('completed-tag','definition-plan','finished'):
   tail[prev[0]+' -> '+stage]+=prev[1]-f
  decls[g]=(stage,f)
 if m:=re.search(r'native-preparation phase=([\w-]+) span=(\S+) remaining=Some\((\d+)\)',line):
  stage,span,f=m[1],m[2],int(m[3])
  if stage=='raw-plan-start':stack.append({'span':span,'stage':stage,'fuel':f,'start_fuel':f,'line':i,'children':0})
  elif stage in ('raw-plan-finished','form-recipes','form-reset'):
   assert stack and stack[-1]['span']==span,(i,stage,span,stack[-1] if stack else None)
   r=stack[-1];key={'raw-plan-finished':'raw-plan','form-recipes':'recipe-walk','form-reset':'clear'}[stage]
   debit=r['fuel']-f;sums[key]+=debit-r['children'];counts[key]+=1;r.update(stage=stage,fuel=f,children=0)
   if stage=='form-reset':
    done=stack.pop()
    if stack:stack[-1]['children']+=done['start_fuel']-f
  elif stage=='definition-start':defs.append({'span':span,'stage':stage,'fuel':f})
  elif stage in ('definition-guarded','initializer-correspondence','definition-recipes'):
   r=defs[-1];assert r['span']==span
   defsum[r['stage']+' -> '+stage]+=r['fuel']-f;r.update(stage=stage,fuel=f)
   if stage=='definition-recipes':defs.pop()
 if m:=re.search(r'raw-key-profile calls=(\d+) entries=(\d+) intern=(\d+) comparison=(\d+) head_lookup=(\d+) head_insert=(\d+)',line):profiles.append(dict(zip(['calls','entries','intern','comparison','head_lookup','head_insert'],map(int,m.groups()))))
result={'old_rows_exact':len(A),'native_form_disjoint_completed':dict(sums),'counts':dict(counts),'definition_intervals_nested':dict(defsum),'declaration_tail_intervals':dict(tail),'unfinished_forms':stack,'unfinished_definitions':defs,'last_raw_key_snapshot':profiles[-1] if profiles else None,'limits':'Completed form raw-plan/recipe/clear scopes. Definition intervals overlap these: not additive. Last periodic raw-key snapshot not full totals; comparison and head costs nested within intern. Open scopes not assigned invented zero.'}
(C/'pr268-unordered-acceptance-analysis/fine-native-census.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
