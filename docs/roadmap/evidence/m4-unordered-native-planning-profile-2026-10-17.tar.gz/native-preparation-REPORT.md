# Unordered default acceptance: native recipe preparation failure

Exact head96bc8d70; 4044 frozen inputs unchanged; exact test0PASS/1typed fuelFAIL, no ignored tests. Failure line291, span510..531, caller &env input transport. This is the default10M unordered test; the separate collection-projection fixture's existing40M allowance is not this run.

Macro starts9,993,493; provenance9,987,844; caller-form9,987,843. `metadata-graph start` recipes17/sources0 at9,986,612. No `metadata-graph recipes` checkpoint, no source-materialize entry, no source-materialize-call hook. Setup snapshot traces precede this macro and must not be attributed to its failing graph.

## Disjoint observed native preparation prefix

180 declaration starts /179 finished /1063 declaration rows. Observed graph-start to last checkpoint debit9,895,932.

|Adjacent checkpoint region|Actual units|
|---|---:|
|Graph entry to first declaration|1,485|
|start → guarded|158,407|
|guarded → declaration-origin|2,183,959|
|declaration-origin → metadata|977,183|
|metadata → definition-origin|475,629|
|definition-origin → finished|5,695,320|
|between declarations|403,773|
|start → finished (no intermediate checkpoints)|176|

These add exactly to9,895,932, without nested double counting. The outstanding PersistentHashMap tail starts after definition-origin at90,680 remaining. No later checkpoint/zero exists: remaining failing debit/work is unknown, not an invented completed interval.

Largest single completed region: conj guarded→declaration-origin2,127,856, enclosing explicit cold `origin-demand snapshot bytes=276925 eager=false`. This includes source snapshot/enrichment work; not all repeated declaration copying. Largest broad completed tails: ->PersistentVector432,581; ->BitmapIndexedNode400,660; IndexedSeq351,838; -write264,295; ->HashCollisionNode230,132; ->ArrayNode228,036.

## Exact control flow / pending work

`reuse.rs:330–342`: graph start → finish_recipes → recipes checkpoint. Thus failure is before placement/controller construction/bridge/materialization.

`portable_macro_graph.rs:561–573`: FIFO jobs dispatch Namespace/Local/Field/Scope/Callable/Ast/Lowering. Current execution is Namespace(suss.core): `namespace_record:1721–1725` synchronously loops identities and calls declaration. The namespace task cannot complete, nor can subsequently queued jobs be popped, until this declaration loop returns. Trace does not expose exact pending queue identities/counts; recipes17 is not a pending-job count. Do not infer all other task categories never previously ran.

`declaration:1800–1831`: full definition/declaration guards, origin-enriched declaration. `:1892–1910` metadata map recipe. `:1913–1934` root-origin metadata/position recipes. `:1935–2238` broad tail: file policy, completed tag, definition_with_initializer, declaration/initializer forms, source-callable scheduling, argument/signature metadata, captures and final record publication. This5.695M observed aggregate is NOT an isolated AST, clone, or raw-key figure.

`definition_with_initializer:1065–1084` performs full guard, initializer correspondence, form_data_selected. `form_data_selected:1086–1103` takes reusable Plan, builds, clears. `form_data_planned:1161–1178` runs ORIGINAL byte raw_keys.plan BEFORE recipe memo lookup, followed by recipe walk. These are concrete nested work inside the broad tail, but current labels do not partition their actual costs. Queued AST projection work is not established as this barrier.

Last trace: PersistentHashMap start103,168 → guarded99,154 → declaration-origin98,473 → metadata95,833 → definition-origin90,680; then actual typed all-fuel-consumed diagnostic. No initializer-reused/finished row for that declaration.

Next attribution boundary, if authorized: split definition-origin→finished into completed-tag/definition guard/correspondence/rootplan/recipe/reset and later record fields. Existing evidence establishes broad native tail dominance, not which substep is recoverable. No optimization or guest/hash proxy follows from this report.
