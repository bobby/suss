from pathlib import Path
import subprocess,os,json,hashlib,time,fcntl
C=Path('/home/bobby/.cache/suss-m4-work');R=Path('/home/bobby/Work/code/bobby/suss-m4-pr268-sparse-setter');T=C/'m4-cost-diagnostic-target';O=C/'pr268-unordered-acceptance-profile-v1';HEAD='96bc8d70ae447d0dba1e89a3c03e97ce0a0f84bb'
def git(*a,root=R):return subprocess.check_output(['git','-C',str(root),*a])
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n')
def freeze():
 out={}
 for prefix,repo in [('',R),('clojurescript/',R/'clojurescript')]:
  for x in git('ls-files','-z','--cached','--others','--exclude-standard',root=repo).split(b'\0'):
   if not x:continue
   f=os.fsdecode(x)
   if prefix=='' and f=='clojurescript':continue
   out[prefix+f]=sha((repo/f).read_bytes())
 return out
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain').strip()
assert git('rev-parse','HEAD',root=R/'clojurescript').decode().strip()=='c4295f303100bbf5afac449242d30bca1126f1a1'
assert not git('status','--porcelain',root=R/'clojurescript').strip()
leases=[]
for p in sorted(T.iterdir()):
 if p.is_file() and p.name.endswith(('.lease','.lock')) and p.name!='.cargo-lock':
  h=p.open('a+');fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(h)
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=str((p/'exe').resolve());env=(p/'environ').read_bytes()
 except OSError:continue
 assert not exe.startswith(str(T)+'/') and b'CARGO_TARGET_DIR='+str(T).encode()+b'\0' not in env, p.name
assert not O.exists();O.mkdir();before=freeze();dump('before.json',before);(O/'driver.py').write_bytes(Path(__file__).read_bytes())
cmd=['cargo','test','--locked','-p','suss-cli','--test','compiled_macro_collection_source_asts','unordered_literal_ast_edges_and_runtime_effects_preserve_textual_order','--','--exact','--test-threads=1','--nocapture']
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
for k in list(env):
 if k.startswith('SUSS_') and (k.endswith('TRACE') or 'CAPTURE' in k):env.pop(k)
env.update(SUSS_MACRO_FUEL_TRACE='1',SUSS_METADATA_FUEL_TRACE='1',SUSS_SOURCE_MATERIALIZE_FUEL_TRACE='1')
state={'head':HEAD,'command':cmd,'input_count':len(before),'flags':['SUSS_MACRO_FUEL_TRACE','SUSS_METADATA_FUEL_TRACE','SUSS_SOURCE_MATERIALIZE_FUEL_TRACE'],'limits':'One unchanged exact default-budget test. No bootstrap/source changes, quota changes, fixture cuts or success inference from incomplete intervals.','execution':'RUNNING'};dump('receipt.json',state);start=time.monotonic()
with (O/'raw.log').open('wb') as log:
 proc=subprocess.Popen(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT);state['pid']=proc.pid;dump('receipt.json',state);code=proc.wait()
after=freeze();dump('terminal.json',after);state.update(exit=code,seconds=time.monotonic()-start,execution='TERMINAL',changed=[f for f in before.keys()|after.keys() if before.get(f)!=after.get(f)]);dump('receipt.json',state);print(json.dumps({k:v for k,v in state.items() if k not in ('command','flags','limits')}));raise SystemExit(code)
