from pathlib import Path
import re,json,collections,hashlib,subprocess
C=Path('/home/bobby/.cache/suss-m4-work');R=C/'pr268-unordered-acceptance-profile-v1';out=Path(__file__).parent
receipt=json.loads((R/'receipt.json').read_text());assert receipt['execution']=='TERMINAL' and receipt['changed']==[]
assert json.loads((R/'before.json').read_text())==json.loads((R/'terminal.json').read_text())
b=(R/'raw.log').read_bytes();text=b.decode(errors='replace');lines=text.splitlines()
rows=[];graphs=[];macros=[]
for i,line in enumerate(lines,1):
 if m:=re.search(r'metadata-declaration (\S+) ([\w-]+): (\d+)',line):rows.append({'line':i,'global':m[1],'stage':m[2],'fuel':int(m[3])})
 if m:=re.search(r'metadata-graph (\S+) recipes=(\d+) sources=(\d+): (\d+)',line):graphs.append({'line':i,'stage':m[1],'recipes':int(m[2]),'sources':int(m[3]),'fuel':int(m[4])})
 if m:=re.search(r'macro-fuel (\S+) ([\w-]+): (\d+)',line):macros.append({'line':i,'macro':m[1],'stage':m[2],'fuel':int(m[3])})
assert len(graphs)==1 and graphs[0]['stage']=='start'
assert not re.search(r'\bsource-materialize root=',text)
sums=collections.Counter();parts=[]
for prev,row in zip(rows,rows[1:]):
 label=prev['stage']+' -> '+row['stage'] if prev['global']==row['global'] else 'between-declarations'
 units=prev['fuel']-row['fuel'];assert units>=0
 sums[label]+=units;parts.append({'global':prev['global'],'from':prev['stage'],'to':row['stage'],'units':units,'line_start':prev['line'],'line_end':row['line']})
starts=[r for r in rows if r['stage']=='start'];finished=[r for r in rows if r['stage']=='finished']
observed=graphs[0]['fuel']-rows[-1]['fuel'];pre=graphs[0]['fuel']-rows[0]['fuel'];assert sum(sums.values())+pre==observed
result={'head':receipt['head'],'raw_sha256':hashlib.sha256(b).hexdigest(),'input_count':receipt['input_count'],'macro_rows':macros,'graph_rows':graphs,'metadata_rows':len(rows),'declarations_started':len(starts),'declarations_finished':len(finished),'unfinished':starts[-1],'last_row':rows[-1],'graph_to_first_declaration':pre,'observed_graph_prefix_units':observed,'stage_transition_sums':dict(sums),'largest_observed_intervals':sorted(parts,key=lambda x:-x['units'])[:20],'source_materialization_entries':0,'source_call_hook_rows':len(re.findall(r'\bsource-materialize-call\b',text)),'last_metadata_rows':rows[-18:],'limits':'Adjacent existing checkpoint intervals, disjoint observed-prefix partition only. Untraced remaining/failing debit UNKNOWN, not fabricated zero. metadata->definition-origin includes origin-root enrichment; definition-origin->finished is broad native tail, not pure planning/copying. No queued job counts exposed by this trace; AST/callable not inferred executed. No guest hash/materializer attribution.'}
(out/'native-preparation-census.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('last_metadata_rows','largest_observed_intervals')},indent=2));print(json.dumps(result['largest_observed_intervals'][:8],indent=2))
