# PR256 final4f terminal CI

Run39156456734, exact head4f48ea6bd7d2e198b9dd82086e4abf4e118e7a7b, terminalFAILURE. FoundationSUCCESS:400Rust pass executions/0fail/1ignore;353Python passes. Inventory/provenance, bootstrap reproduction/execution, libraries/binaries/examples/documentation steps passed. All8integration shardsFAIL:124PASS18fuelFAIL0ignored. Actual all8CIplans jointly251targets;31completed/executed,220unexecuted,0startedunfinished. Aggregate test gate red because integrations fail.

All18failed names/class/stage/span match d38CI39149952174; no previouslyobserved passing name nowfailed, no observed semantic/provenance/compile regression. Exact testnames/stages/spans/bodies are in independent-review.json. Unknown tests remain unknown. No fixed-name or wholecompatibility claim.

Actual nine checkouts use syntheticb640a385e470f8a4f9e4617a1ed243b8932c472c, complete treecb9bfd42df2a492bfa37ff3ceea4f5e1f92a893d equals4f tree. Checkout SHA is not headline4f, and tree equality is NOT a CI input freeze. GitHub commit/tree APIobjects retained.

Parsercorrected stderr/stdout interleaving: namespace-command4PASSsummary follows next Running line; initial30completed+1unfinished was a parserartifact. Actual31completed. Multiline authored-record trap is fuel453..489, not a semantic assertion. Initial audit preserved.

No source/baseline/focus totals combined. Local baseline and2B/slot controllers untouched. No build/sourcewrite/cancel/rerun.
