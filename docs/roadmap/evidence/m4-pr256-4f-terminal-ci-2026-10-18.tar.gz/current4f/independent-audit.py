from pathlib import Path
import json,re,hashlib,datetime,tarfile,io
P=Path(__file__).parent;C=P.parent;D=C/'pr256-d38b59c-ci';L=lambda p:json.loads(p.read_text());H=lambda b:hashlib.sha256(b).hexdigest()
a=L(P/'terminal-audit.json');prev=L(D/'independent-terminal-review.json');assert a['run']==39156456734 and a['head']=='4f48ea6bd7d2e198b9dd82086e4abf4e118e7a7b' and a['status']=='completed' and len(a['jobs'])==10
clean=lambda p:re.sub(r'^\S+Z ?', '',re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',p.read_text(encoding='utf-8-sig')),flags=re.M)
def failures(t):
 c=re.split(r'^---- (.*?) stdout ----\s*$',t,flags=re.M);out={}
 for i in range(1,len(c),2):
  n,b=c[i:i+2];b=b.split('\nfailures:',1)[0];s=re.search(r'Compiled macro expansion failed during ([^:]+):',b);sp=re.search(r'span:\s*(\d+\.\.\d+)',b) or re.search(r'at bytes (\d+\.\.\d+)',b)
  out[n]={'fuel':'all fuel consumed by WebAssembly' in b,'stage':s[1] if s else None,'span':sp[1] if sp else None,'raw_body':b.strip()}
 return out
rows=[];nf={};currentpass=set();plans=[];done=[];proofs=[]
for j in a['jobs']:
 f=P/f"{j['id']}.log";assert H(f.read_bytes())==j['log_sha256'];t=clean(f);blocks=[];cur=None
 for line in t.splitlines():
  m=re.search(r'Running (tests/(\S+)\.rs|unittests (\S+))',line)
  if m:cur={'harness':m[2] or 'unittests:'+m[3],'tests':[],'counts':None};blocks.append(cur)
  doc=re.match(r'\s*Doc-tests\s+(\S+)',line)
  if doc:cur={'harness':'doctest:'+doc[1],'tests':[],'counts':None};blocks.append(cur)
  m=re.match(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:$|,)',line)
  if m and cur:cur['tests'].append({'name':m[1],'status':m[2]})
  m=re.match(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)
  if m:
   # stderr Running may precede previous stdout summary. Complete the earliest pending block.
   counts=list(map(int,m.groups()));pending=[b for b in blocks if b['counts'] is None]
   if pending:
    b=pending[0];b['counts']=counts
    assert counts==[sum(x['status']==s for x in b['tests']) for s in ['ok','FAILED','ignored']],(j['name'],b)
   else:
    # Zero-test doc suites in foundation may have no Running heading; preserve explicit summary.
    assert counts==[0,0,0],(j['name'],counts,line);blocks.append({'harness':'unlabelled-zero-test-summary','tests':[],'counts':counts})
 sums=[tuple(map(int,x)) for x in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t,re.M)];counts=[sum(x[i] for x in sums) for i in range(3)];assert counts==j['completed_summary_counts']
 fs=failures(t);assert set(fs)==set(re.findall(r'^test (\S+) \.\.\. FAILED$',t,re.M));nf.update(fs)
 currentpass.update(x['name'] for b in blocks for x in b['tests'] if x['status']=='ok')
 if j['name'].startswith('integration'):
  plan=j['plan'];assert plan['total_targets']==251;plans+=list(map(tuple,plan['targets']));assert all(b['counts'] is not None for b in blocks)
  for b in blocks:
   matches=[x for x in plan['targets'] if x[1]==b['harness']];assert len(matches)==1;done.append(tuple(matches[0]))
 assert not j['compile_errors'];proofs+=j['checkout_proofs'];rows.append({'name':j['name'],'id':j['id'],'conclusion':j['conclusion'],'counts':counts,'python':j.get('Python_execution_count',0),'harnesses':blocks,'failures':fs,'sha256':H(f.read_bytes()),'step_outcomes':j.get('step_outcomes')})
assert len(plans)==len(set(plans))==251 and len(done)==len(set(done))==31 and len(proofs)==9 and all(p['tree_equal_head'] for p in proofs)
unexecuted=sorted(set(plans)-set(done));assert len(unexecuted)==220 and len(nf)==18 and all(v['fuel'] for v in nf.values())
oldf={n:v for j in prev['jobs'] for n,v in j['failures'].items()};oldpass=set()
for j in prev['jobs']:oldpass.update(re.findall(r'^test (\S+) \.\.\. ok$',clean(D/f"{j['id']}.log"),re.M))
comparison={'same_failed_names':set(nf)==set(oldf),'new_failed_names':sorted(set(nf)-set(oldf)),'previous_failed_not_failed_now':sorted(set(oldf)-set(nf)),'changed_class_stage_span':{n:{'current':nf[n],'previous':oldf[n]} for n in set(nf)&set(oldf) if any(nf[n][k]!=oldf[n][k] for k in ['fuel','stage','span'])},'previous_pass_now_fail':sorted(set(nf)&oldpass),'previous_fail_now_pass':sorted(set(oldf)&currentpass),'limits':'Observed names only; unexecuted tests unknown. Equal stage/span is not full trace identity or absence of all regressions.'}
assert comparison['same_failed_names'] and not comparison['changed_class_stage_span'] and not comparison['previous_pass_now_fail']
integrations=[j for j in rows if j['name'].startswith('integration')];counts=[sum(j['counts'][i] for j in integrations) for i in range(3)];assert counts==[124,18,0];foundation=next(j for j in rows if j['name']=='foundation');assert foundation['counts']==[400,0,1] and foundation['python']==353
result={'run':a['run'],'source':a['head'],'status':'completed','conclusion':'failure','foundation':foundation,'integration':{'counts':counts,'planned':251,'completed':31,'executed':31,'started_unfinished':[],'unexecuted_count':220,'unexecuted':unexecuted,'planned_targets_from_all_eight_ci_logs':sorted(plans)},'jobs':rows,'checkout_proofs':proofs,'comparison_to_d38':comparison,'parser_corrections':['Summary assigned to earliest pending Running block: compiled_aot_namespace_command4PASS summary arrives after next Running line; actual31completed, not initial30+1unfinished. Original initial audit retained.','Multiline public_records authored-contract error explicitly is fuel453..489 despite Semantic error wrapper.'],'limits':['Nine synthetic checkout tree proofs establish complete tree equality, NOT a post-checkout source freeze.','All counts are actual executions; foundation includes bootstrap verifier repeats. No full workspace pass claim.','Baseline27798,2B9793,slot65163 untouched; no local Cargo/source/signals/reruns.']}
(P/'independent-review.json').write_text(json.dumps(result,indent=2)+'\n')
p=proofs[0];report=f"""# PR256 final4f terminal CI\n\nRun39156456734, exact head{a['head']}, terminalFAILURE. FoundationSUCCESS:400Rust pass executions/0fail/1ignore;353Python passes. Inventory/provenance, bootstrap reproduction/execution, libraries/binaries/examples/documentation steps passed. All8integration shardsFAIL:124PASS18fuelFAIL0ignored. Actual all8CIplans jointly251targets;31completed/executed,220unexecuted,0startedunfinished. Aggregate test gate red because integrations fail.\n\nAll18failed names/class/stage/span match d38CI39149952174; no previouslyobserved passing name nowfailed, no observed semantic/provenance/compile regression. Exact testnames/stages/spans/bodies are in independent-review.json. Unknown tests remain unknown. No fixed-name or wholecompatibility claim.\n\nActual nine checkouts use synthetic{p['sha']}, complete tree{p['tree']} equals4f tree. Checkout SHA is not headline4f, and tree equality is NOT a CI input freeze. GitHub commit/tree APIobjects retained.\n\nParsercorrected stderr/stdout interleaving: namespace-command4PASSsummary follows next Running line; initial30completed+1unfinished was a parserartifact. Actual31completed. Multiline authored-record trap is fuel453..489, not a semantic assertion. Initial audit preserved.\n\nNo source/baseline/focus totals combined. Local baseline and2B/slot controllers untouched. No build/sourcewrite/cancel/rerun.\n""";(P/'REPORT.md').write_text(report)
files={'current4f/'+f.name:f for f in P.iterdir() if f.is_file() and f.suffix in ['.json','.log','.py','.md'] and f.name!='package-result.json'}
for f in D.iterdir():
 if f.is_file() and (f.suffix=='.log' or f.name in ['independent-terminal-review.json','terminal-audit.json','run-terminal.json','jobs-terminal.json'] or f.name.startswith('git-commit-')):files['control-d38/'+f.name]=f
manifest={n:{'sha256':H(f.read_bytes()),'bytes':f.stat().st_size} for n,f in files.items()};data=json.dumps({'schema':1,'payloads':manifest},indent=2).encode();out=C/'m4-pr256-4f-terminal-ci-2026-10-18.tar.gz'
with tarfile.open(out,'w:gz') as tf:
 for n,f in sorted(files.items()):tf.add(f,arcname=n,recursive=False)
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(data);tf.addfile(info,io.BytesIO(data))
with tarfile.open(out) as tf:
 ms=tf.getmembers();assert len(ms)==len(files)+1==len({m.name for m in ms})
 for m in ms:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='MANIFEST.json':assert H(tf.extractfile(m).read())==manifest[m.name]['sha256']
r={'archive':str(out),'sha256':H(out.read_bytes()),'members':len(files)+1,'payloads':len(files),'bytes':out.stat().st_size,'report':str(P/'REPORT.md'),'independent_review':str(P/'independent-review.json')};(P/'package-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
