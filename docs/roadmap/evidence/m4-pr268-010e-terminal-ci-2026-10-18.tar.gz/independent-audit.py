import pathlib,json,re,hashlib,subprocess
P=pathlib.Path(__file__).parent;C=P.parent;head='010e8d100f98060daf106536c8f7d637ea77c9bb';r=json.loads((P/'run-terminal.json').read_text());jobs=json.loads((P/'jobs-terminal.json').read_text())['jobs'];assert r['head_sha']==head and r['status']=='completed' and r['conclusion']=='failure';assert len(jobs)==10 and all(j['status']=='completed' for j in jobs)
def clean(s):
 s=re.sub(r'\\u001b\[[0-?]*[ -/]*[@-~]','',s);s=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',s);return re.sub(r'^\d{4}-\S+Z ?','',s,flags=re.M)
def failures(s):
 ms=list(re.finditer(r'^---- (.*?) stdout ----$',s,re.M));out={}
 for i,m in enumerate(ms):
  b=s[m.end():ms[i+1].start() if i+1<len(ms) else len(s)];st=re.search(r'Compiled macro expansion failed during ([^:]+):',b);sp=re.search(r'span:\s*(\d+\.\.\d+)',b);out[m[1]]={'stage':st[1] if st else None,'span':sp[1] if sp else None,'fuel':'all fuel consumed' in b}
 return out
old={}
for p in (C/'pr268-b846-ci/39100487687').glob('job-*.log'):old.update(failures(clean(p.read_text())))
rows=[];plans=[];completed=[];allfails={};py=0
for j in jobs:
 name=j['name'];m=re.fullmatch(r'integration \((\d)\)',name);p=P/(f'integration-{m[1]}.log' if m and int(m[1])<3 else f"job-{j['id']}.log");s=clean(p.read_text());ss=[list(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',s)];count=[sum(x[i] for x in ss) for i in range(3)];proof=re.findall(r'\[command\].*git log -1 --format=%H\n([^\n]+)',s);fs=failures(s);allfails.update(fs);row={'job':name,'id':j['id'],'conclusion':j['conclusion'],'checkout_head':proof,'counts':count,'failed':fs,'raw_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 if name!='test':assert proof==[head]
 if m:
  plan=json.loads(re.search(r'(\{"index": \d+, "count": 8, "total_targets": \d+, "targets": .*\})',s)[1]);plans+=list(map(tuple,plan['targets']));bins=re.findall(r'Running tests/([^\s.]+)\.rs',s);assert len(bins)==len(ss);completed+=bins;row['completed_targets']=bins;assert j['conclusion']=='failure'
 if name=='foundation':
  assert j['conclusion']=='success';py=sum(map(int,re.findall(r'Ran (\d+) tests? in ',s)));row['python_tests']=py;assert 'Run scripts/verify-bootstrap.sh' in s and 'compiled build-script identity:' in s and 'compiled_bootstrap_images_are_reproducible_and_phase_specific ... ok' in s
 rows.append(row)
f=next(x for x in rows if x['job']=='foundation');ints=[x for x in rows if x['job'].startswith('integration')];it=[sum(x['counts'][i] for x in ints) for i in range(3)];assert f['counts']==[541,0,1] and py==353 and it==[111,14,0];assert len(set(plans))==259 and len(completed)==len(set(completed))==30;assert len(allfails)==14 and set(allfails)==set(old);assert all(v==old[k] and v['fuel'] for k,v in allfails.items())
o={'verdict':'VERIFIED_TERMINAL_CI_FAILURE_LIMITED_EXECUTED_SCOPE','run':r['id'],'head':head,'foundation_rust':f['counts'],'foundation_python':py,'integration':it,'nine_actual_checkout_git_log_proofs':True,'jobs':rows,'target_scope':{'planned_unique':259,'completed_harnesses':30,'unexecuted':229,'planned_targets':sorted(set(plans)),'completed_names':completed},'same14names_stage_span_fuel_as_b846':True,'failure_comparison':{k:{'current':v,'b846':old[k]} for k,v in allfails.items()},'bootstrap':'Foundation verify-bootstrap.sh step, identity output and reproducible/bootstrap test outcomes present; foundation successful. No fabricated per-integration JSON source proof.','limits':['229targets unexecuted; same14failed names/stages does not prove global regression absence.','No local fullbaseline, finalheadCI success, promotion or closure.','CIhead010 is production boxedfacts, not coherent/native-owned-type experiment.'],'reviewer_actions':'Read-only downloaded raw logs/metadata audit; host parser/cache receipt only, no Cargo or CI restart.'};(P/'independent-review.json').write_text(json.dumps(o,indent=2)+'\n');print(P/'independent-review.json')
