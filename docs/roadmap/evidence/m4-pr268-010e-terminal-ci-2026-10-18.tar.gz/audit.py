from pathlib import Path
import re,json,hashlib,collections
p=Path(__file__).parent;old=p/'control-b846';head='010e8d100f98060daf106536c8f7d637ea77c9bb';run=json.loads((p/'run-terminal.json').read_text());assert run['head_sha']==head and run['status']=='completed'
def clean(s):return re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',s)
def fails(text):
 out={};matches=list(re.finditer(r'---- (.*?) stdout ----',text))
 for i,m in enumerate(matches):
  body=text[m.end():matches[i+1].start() if i+1<len(matches) else len(text)];stage=re.search(r'Compiled macro expansion failed during ([^:]+):',body);span=re.search(r'span:\s*(\d+\.\.\d+)',body)
  out[m[1]]=dict(stage=stage[1] if stage else None,span=span[1] if span else None,fuel='all fuel consumed' in body)
 return out
before={}
for f in old.glob('job-*.log'):before.update(fails(clean(f.read_text())))
rows=[];allfails={};plans=[];started=[]
for j in json.loads((p/'jobs-terminal.json').read_text())['jobs']:
 name=j['name'];f=p/(('integration-'+re.search(r'\((\d+)\)',name)[1]+'.log') if name in ['integration (0)','integration (1)','integration (2)'] else 'job-'+str(j['id'])+'.log');raw=f.read_text();text=clean(raw);counts=[list(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)];fs=fails(text);allfails.update(fs)
 proof=bool(re.search(r'^\S+Z '+head+r'\s*$',text,re.M))
 row=dict(name=name,id=j['id'],status=j['status'],conclusion=j['conclusion'],counts=[sum(c[i] for c in counts) for i in range(3)],checkout_proof=proof,failed=fs,log_sha256=hashlib.sha256(f.read_bytes()).hexdigest())
 if name.startswith('integration'):
  found=re.search(r'(\{"index": \d+, "count": 8, "total_targets": \d+, "targets": .*\})',text);assert found,name;plan=json.loads(found[1]);plans.extend(map(tuple,plan['targets']));bins=re.findall(r'Running tests/([^\s.]+)\.rs',text);row.update(planned=len(plan['targets']),started=bins,completed_target_summaries=len(counts));assert len(bins)==len(counts),name;started.extend(bins)
 if name=='foundation':row['python_tests']=sum(map(int,re.findall(r'Ran (\d+) tests? in ',text)));assert re.search(r'\bOK\b',text)
 rows.append(row)
integ=[x for x in rows if x['name'].startswith('integration')];foundation=next(x for x in rows if x['name']=='foundation');comparison={n:dict(current=v,previous=before.get(n),same_stage_and_span=n in before and v['stage']==before[n]['stage'] and v['span']==before[n]['span']) for n,v in allfails.items()}
assert len(set(plans))==259;assert len(started)==30;assert len(allfails)==14;assert all(x['checkout_proof'] for x in rows if x['name']!='test')
summary=dict(head=head,run=run['id'],conclusion=run['conclusion'],foundation=foundation['counts'],foundation_python=foundation['python_tests'],integration=[sum(x['counts'][i] for x in integ) for i in range(3)],planned_targets=len(plans),completed_targets=len(started),unexecuted_targets=len(plans)-len(started),failed_names_match_previous=set(allfails)==set(before),all14_fuel=all(x['fuel'] for x in allfails.values()),all_same_failure_stage_and_span=all(x['same_stage_and_span'] for x in comparison.values()),jobs=rows,failure_comparison=comparison,limits='Same completed scope and failure names/stages do not prove absence of regressions in229unexecuted targets. No local full baseline, CI success, promotion or issue closure.')
(p/'terminal-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['jobs','failure_comparison']},indent=2))
