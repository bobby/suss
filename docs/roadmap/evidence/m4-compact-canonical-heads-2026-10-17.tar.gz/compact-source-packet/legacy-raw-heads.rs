//! Metered native hash-to-chain heads for exact raw reader keys.
//! Native keys only. Generic charging errors are propagated unchanged.
//! Allocation follows parent reserve's infallible Vec policy: capacity overflow
//! panics explicitly; allocator OOM is NOT newly recoverable. To recover these
//! errors requires an explicit error-construction contract at raw_keys callers.
use super::reserve;

#[derive(Default)]
pub(super) struct RawHeads {
    slots: Vec<Option<(u64, usize)>>,
    len: usize, // DISTINCT full hashes, not raw key entries
}
impl RawHeads {
    fn checked_capacity(current: usize) -> usize {
        let capacity = if current == 0 { 4 } else {
            current.checked_mul(2).expect("Raw heads capacity overflow")
        };
        assert!(capacity.is_power_of_two(), "Raw heads invalid capacity");
        let bytes = capacity.checked_mul(std::mem::size_of::<Option<(u64, usize)>>())
            .expect("Raw heads allocation overflow");
        assert!(bytes <= isize::MAX as usize, "Raw heads allocation exceeds isize");
        capacity
    }
    fn allocate<E>(capacity: usize, charge: &mut impl FnMut(u64) -> Result<(), E>) -> Result<Self, E> {
        let mut slots = Vec::new();
        // Parent reserve charges requested capacity + previous live relocation.
        // Here previous live length is zero; the old table remains untouched.
        reserve(&mut slots, capacity, charge)?;
        for _ in 0..capacity {
            charge(1)?;
            slots.push(None);
        }
        Ok(Self { slots, len: 0 })
    }
    // Returns matching or empty slot. Tables are always <=half occupied.
    fn position<E>(&self, hash: u64, charge: &mut impl FnMut(u64) -> Result<(), E>) -> Result<Option<usize>, E> {
        if self.slots.is_empty() { charge(1)?; return Ok(None); }
        charge(3)?;
        let mask = self.slots.len() - 1;
        let mut index = hash as usize & mask;
        for _ in 0..self.slots.len() {
            charge(4)?; // slot read, full hash compare, probe/wrap work
            match self.slots[index] {
                None => return Ok(Some(index)),
                Some((key, _)) if key == hash => return Ok(Some(index)),
                _ => index = (index + 1) & mask,
            }
        }
        unreachable!("Raw heads half-load invariant violated")
    }
    pub(super) fn get<E>(&self, hash: u64, charge: &mut impl FnMut(u64) -> Result<(), E>) -> Result<Option<usize>, E> {
        let Some(index) = self.position(hash, charge)? else { return Ok(None); };
        charge(2)?;
        Ok(self.slots[index].map(|(_, head)| head))
    }
    pub(super) fn get_or_insert<E>(&mut self, hash: u64, head: usize,
        charge: &mut impl FnMut(u64) -> Result<(), E>,
    ) -> Result<usize, E> {
        let position = self.position(hash, charge)?;
        if let Some(index) = position {
            charge(2)?;
            if let Some((_, prior)) = self.slots[index] { return Ok(prior); }
        }
        // Only a new full hash can trigger growth. Head values never replace
        // existing heads; raw_keys maintains exact-byte Entry.next tail chains.
        charge(2)?; // occupancy/next-length decision
        let next_len = self.len.checked_add(1).expect("Raw heads length overflow");
        if self.slots.is_empty() || next_len > self.slots.len() / 2 {
            let capacity = Self::checked_capacity(self.slots.len());
            let mut staged = Self::allocate(capacity, charge)?;
            for slot in &self.slots {
                charge(1)?; // inspect EVERY old slot, including empties
                if let Some((key, value)) = *slot {
                    let index = staged.position(key, charge)?.expect("allocated table");
                    charge(3)?; // write tuple and update staged occupancy
                    staged.slots[index] = Some((key, value));
                    staged.len += 1;
                }
            }
            let index = staged.position(hash, charge)?.expect("allocated table");
            charge(3)?;
            staged.slots[index] = Some((hash, head));
            staged.len = next_len;
            charge(2)?; // final table/len publication, BEFORE swap
            std::mem::swap(self, &mut staged);
        } else {
            let index = position.expect("nonempty table");
            charge(3)?;
            self.slots[index] = Some((hash, head));
            self.len = next_len;
        }
        Ok(head)
    }
}

