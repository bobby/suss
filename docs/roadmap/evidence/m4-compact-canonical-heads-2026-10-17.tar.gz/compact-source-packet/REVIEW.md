# Compact canonical heads — review before Cargo

Clean base4c6545f78c23c15bba4219a142f69b01ed54e539 on local
portable/m4-compact-canonical-heads. Exactly3 existing Rust files changed; no new
source files. Expected source closure2989 is informational until root freezes it.
No flat-edge Plan, leaf encoder or experimental fee changes are carried forward.
Before/after bytes, complete patch and exact source-derived test names retained.
Source frozen; no Cargo/bootstrap/guest/native benchmark execution by agent.

## Genuine storage domain and ownership

RawHeads slots are Option<(u64,HeadIndex)>, with transparent HeadIndex wrapping
NonZeroUsize. It stores canonical index+1, never a pointer/source authority.
Production construction occurs ONLY through Entries::prepare and its Prepared
owner. Existing checked next_len and Entry byte extent execute first; then paid
NonZero conversion. Prepared.next_len changes usize->NonZeroUsize, no new field.
Its typed getter reads that immutable prepared value before head publication.
RawHeads private production API accepts/returns HeadIndex, not arbitrary usize;
all u64 hashes including0/MAX remain representable. There is no new guest bound.

After head lookup, decode is prepaid before canonical-entry access. Collision
chains still use unchanged native Entry.next indices, exact raw bytes and same
canonical publication order. Rehash copies typed heads directly with no encode/
decode. New entries can allocate/stage but cannot publish before all fallible
work succeeds. No fallible work added after successful head publication.

## Fees/counters — no rate reductions

- Original slot allocation/extent checks now use actual compact slot type; expected
  x86_64 layout16 versus24 is verified/printed INSIDE an execution/work test, not
  asserted as an already measured outcome. Same sizes drive existing reserve fees.
- Same hashes/probes/half-load/growth/scan/init/copy/publication rates remain.
- Entries.prepare pays extra staging1 BEFORE NonZero conversion. Prepared typed
  read pays staging1 before use, only when a new hash head is needed. Conversion
  into type does not add a separate heap owner or a Prepared payload field.
- Publication prepays an additional conservative1 for next_len.get() before the
  eventual infallible write. Entries publication subtotal9 per new canonical key;
  plus existing raw publication3 means total12 (OLD ledger11 applies ONLY to old
  diagnostic tuples). No update/reinterpretation of historical13f results.
- Accepted lookup decode1 is recorded IN profile_head_lookup_work, nested within
  profile_work. No duplicate EntryStats allocation/access attribution. Getter and
  conversion appear in EntryStats.staging. Every subtotal changes only after its
  charge succeeds; failed requests excluded exactly as before.
- Existing native allocator overflow/OOM policy unchanged (not newly recoverable
  via arbitrary generic meter errors). No quota/rate cuts or Java/runtime ABI change.

## Existing and new tests (NOT RUN)

All original raw key/collision/page/fuel+IRQ recovery assertions remain. Existing
RawHeads numeric test fixtures use a test-only paid encode/decode adapter; there
is no arbitrary-usize production API. Its checked overflow is explicit, not None
or truncation, and it cannot fail after publishing (return decode prepaid).

Three added tests:
1. Compact heads vs exact old4c table algorithm and 24-byte usize slot oracle.
   Same257 hashes/indices, clustered placement/wrap collisions,0/MAX, full-hash
   hits with different proposed heads, every table slot/length and all queried
   values agree through the SAME capacity transitions. Measure actual called
   table charges INCLUDING test adapter encode/decode; require lower total work
   and smaller real slots. This is isolated table work, not full Entry preparation
   or source request savings. Old oracle body unchanged except type/field naming.
2. Encoding zero/max representable/overflow test, distinguished from canonical
   owner validity. Test-only MAX-1 encoding does not authorize a production owner:
   canonical extent remains stricter and is tested separately. Oversized actual
   Entry preparation still panics before publication; exact maximal valid extent
   and next invalid extent are covered without allocating giant tables.
3. Actual Prepared owners across index0..129/page boundary: typed head equals the
   actual published index; Fuel/Irq errors on typed read leave logical entries
   unchanged and do NOT increment accepted staging; full retry/publish succeeds.

Existing all-charge canonical interner tests include the new production getter/
conversion/decode paths as part of original atomicity checks. RawHeads tests keep
first allocation, no-growth, hit and growth interruption sweeps. Those native
injected Irq tests alone are not claims about live Session cancellation.

Source-derived focus51: ALL raw_keys24 (direct+raw_heads+canonical_entries),
sharing20,async3,defaultCoreEnv1,record/reduce3. No repeat scratch5 (Plan unchanged).
Preservation other46 +CORE17 +map1 +bitwise1 +graph11=76, avoiding duplicates.
The parent source59 includes13 raw-direct tests; 59-13=46. Earlier42/72 prose
was a planning error; neither rejected flat-edge trial ran preservation.
Actual production4c default comparison decides benefit; V3/V4 regressions remain
separate experiments. No readiness/acceptance/performance claim before execution.
