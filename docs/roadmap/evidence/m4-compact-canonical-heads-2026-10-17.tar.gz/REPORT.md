# Compact canonical head storage evidence

Source `4a5919da8b1a0c5d98f99fdc84fbc0b911b3affe`, based on production4c6545f78c23c15bba4219a142f69b01ed54e539.
This draft is rendered only after both terminal cohorts, unchanged freezes and
an exact2,989-path final source-commit binding. Commands, source-derived selections,
raw errors, receipts, source review packet and freeze maps are retained.

Exactly three native Rust modules change. RawHeads stores a transparent nonzero
canonical index+1 beside its full64-bit hash, in actual smaller slots. Typed heads
come from the checked Entries::prepare owner; Prepared keeps its existing length
as NonZeroUsize with no new payload field. Full hash0/MAX, byte equality, collision
chains, stable canonical IDs and all publication/rollback ordering remain.
No flat-edge/leaf-encoder code or fee-only experimental changes are incorporated.

## Commands and actual results

Normal bootstrap generation: exit0. Focus51 selected tests: {"pass": 47, "fail": 4, "ignore": 0}.
Preservation76 selected tests:46 source/domain tests, CORE17, complete map1,
pinned bitwise1 and analysis graph11. All preservation gates must pass before
this assembly; no duplicate raw-direct or unchanged scratch5 selections.
Combined127 unique selected results: {"ok": 123, "FAILED": 4}.

The table test compares the exact legacy4c algorithm and usize-backed layout
against compact slots through the same capacity/placement transitions,257 hashes,
clustered/wrapping collisions, fullhash hits retaining prior heads,0/MAX and
queried absence. Actual isolated table measurement: {"old_slot": 24, "new_slot": 16, "capacity": 1024, "old_work": 762356, "new_work": 748317}.
The isolated table fixture measured762,356 versus748,317 units:14,039 removed.
It includes real test-adapter encode/decode work; it is not full Entry preparation
or a whole-source request cost. Representation encoding maximum is tested
separately from the stricter checked native canonical-entry extent. Existing
all-charge atomicity tests and actual Prepared owner cancellation/retry remain.

Counter accounting is source-bound: accepted NonZero conversion1 and typed read1
are staging; lookup decode1 is included inside head-lookup work. Publication is
now12 per new canonical key (canonical publication8+next_len.get() prepayment1+
raw publication3). Old diagnostic ledger11 remains valid only for its old source.
Backing fees follow actual compact storage; existing operation rates/quotas are
not lowered. No guest hash callback, schema guard, source authority or runtime ABI
is bypassed. No Java shipping dependency added.

Actual default CoreEnv comparison: {"parent": {"run": "borrowed-metadata-validation-focused", "log_sha256": "5f452daaa4414c734cedac4a8d3485daa55253333653f6275ed342d8d4fdbdaa", "started": 137, "completed": 136, "pop_finished": 155099, "last": [["suss.core/-rseq", "declaration-origin", "21658"], ["suss.core/-rseq", "metadata", "5324"], ["suss.core/-rseq", "definition-origin", "3102"]]}, "candidate": {"run": "compact-heads-focused", "log_sha256": "56c6ec33def6ee0faf53ad78168c74d2a633facb6662ba10950cdbdf5b32724c", "started": 151, "completed": 150, "pop_finished": 384029, "last": [["suss.core/ASeq", "guarded", "5418"], ["suss.core/ASeq", "declaration-origin", "5253"], ["suss.core/ASeq", "metadata", "969"]]}, "common_prefix_units_removed": 228930, "limits": "Same unchanged default10M criterion and existing metadata/macro trace flags. Partial common-prefix difference only; complete criterion stillFAIL and observationsunexecuted. Not whole operation saving or issue closure."}.
This remains a failed first projection with criterion observations unexecuted.
The measured common -pop finished balance384029 versus155099 is228930 fewer
prefix units;151 declarations started/150 completed versus137/136 at control.
The candidate reaches ASeq metadata969 before failure. This is NOT completed
CoreEnv savings, full cost, or issue closure. Partial tail measurements are not
silently added to these balances.

Actual default sourcechild result: {"Runtime": {"candidate_start": 10000000, "candidate_final_stage": "final-validation", "candidate_final_result": "Ok(())", "candidate_remaining": 132163, "control_remaining": 131281, "net_removed_at_final_marker": 882}, "Macro": {"candidate_start": 10000000, "candidate_final_stage": "final-validation", "candidate_final_result": "Ok(())", "candidate_remaining": 132163, "control_remaining": 131281, "net_removed_at_final_marker": 882}}.
Both original10M requests start at10,000,000 and finish Ok with132,163 remaining
versus production4c131,281: actual882 units removed EACH phase. All220 ordered
labels/results match. This is complete fixture-request evidence, not whole-CoreEnv
savings or an extrapolation from slot layout. Record/reduction outcomes are retained from the actual focus
receipts; they do not inherit success from this table unit test.

## Provenance and limitations

The archive is Git-resolved and NOT standalone. GIT-SOURCE-RESOLUTION.json names
exact Suss base/new commits, their pinned ClojureScript commit(s), and every frozen
path's Git blob/SHA256. Resolve all2,989 entries per freeze using those immutable
objects; repeated CAS/Wasm archives are excluded. Review-packet uncommitted
before/after Rust bytes and the exact test-only legacy table are included.

Rejected flat-edge V3/V4 source/evidence is separately published on experiment
860e2ce; it is referenced, not duplicated or counted as current acceptance. The
current proposal must be assessed against production4c, not rescued by comparison
only with those regressions. Historical preservation42/72 prose was corrected
externally; neither rejected trial ran that followup. Current selection is76.

Separate exact-parent4c terminal CI only: {"verified_utc": "2026-10-17T20:43:53.003179+00:00", "head": "4c6545f78c23c15bba4219a142f69b01ed54e539", "run": 39066209035, "conclusion": "failure", "all10_logs_verified": true, "checkout_proofs": [{"checkout": "4c6545f78c23c15bba4219a142f69b01ed54e539", "tree_equals_head": true}, {"checkout": "4c6545f78c23c15bba4219a142f69b01ed54e539", "tree_equals_head": true}, {"checkout": "4c6545f78c23c15bba4219a142f69b01ed54e539", "tree_equals_head": true}, {"checkout": "4c6545f78c23c15bba4219a142f69b01ed54e539", "tree_equals_head": true}, {"checkout": "4c6545f78c23c15bba4219a142f69b01ed54e539", "tree_equals_head": true}, {"checkout": "4c6545f78c23c15bba4219a142f69b01ed54e539", "tree_equals_head": true}, {"checkout": "4c6545f78c23c15bba4219a142f69b01ed54e539", "tree_equals_head": true}, {"checkout": "4c6545f78c23c15bba4219a142f69b01ed54e539", "tree_equals_head": true}, {"checkout": "4c6545f78c23c15bba4219a142f69b01ed54e539", "tree_equals_head": true}], "foundation": {"conclusion": "success", "Rust_execution_counts": {"pass": 531, "fail": 0, "ignore": 1}, "Python_summaries": [["351", "31.316"]]}, "integration": {"pass": 111, "fail": 14, "ignore": 0, "planned_targets": 255, "completed_targets": 30, "unexecuted_targets": 225, "failed_tests": [{"target": "tests/compiled_macro_source_tags.rs", "name": "compiled_source_inference_matches_pinned_tags_without_changing_executed_storage_or_effects", "status": "FAILED", "job": "integration (4)"}, {"target": "tests/compiled_macro_control_source_asts.rs", "name": "control_source_nodes_match_genuine_primary_children_and_forms_after_gc", "status": "FAILED", "job": "integration (1)"}, {"target": "tests/compiled_macro_quote_asts.rs", "name": "quote_and_literal_child_records_match_pinned_without_datum_analysis", "status": "FAILED", "job": "integration (3)"}, {"target": "tests/compiled_macro_constructor_source_asts.rs", "name": "constructor_source_nodes_match_pinned_children_tags_and_class_facts_after_gc", "status": "FAILED", "job": "integration (0)"}, {"target": "tests/compiled_macro_compiler_catalog.rs", "name": "compiled_wrapper_serializes_only_the_genuine_native_object_fact_in_both_phases", "status": "FAILED", "job": "integration (6)"}, {"target": "tests/compiled_macro_compiler_catalog.rs", "name": "compiler_catalog_policy_is_opt_in_and_invalid_metadata_keeps_old_macro", "status": "FAILED", "job": "integration (6)"}, {"target": "tests/compiled_macro_compiler_catalog.rs", "name": "failed_script_staging_restores_callable_and_catalog_policy_after_gc", "status": "FAILED", "job": "integration (6)"}, {"target": "tests/compiled_macro_compiler_catalog.rs", "name": "failed_macro_reload_keeps_published_policy_then_successful_reload_recovers", "status": "FAILED", "job": "integration (6)"}, {"target": "tests/compiled_macro_compiler_catalog.rs", "name": "source_macro_consumes_actual_other_namespace_and_protocol_revisions_after_gc", "status": "FAILED", "job": "integration (6)"}, {"target": "tests/compiled_macro_declaration_metadata.rs", "name": "declaration_metadata_merge_and_tag_precedence_match_pinned_analyzer", "status": "FAILED", "job": "integration (7)"}, {"target": "tests/compiled_macro_declaration_metadata.rs", "name": "compiled_declaration_records_match_actual_primary_snapshot_and_catalog_fields", "status": "FAILED", "job": "integration (7)"}, {"target": "tests/compiled_macro_collection_source_asts.rs", "name": "collection_source_nodes_retain_original_children_before_factory_lowering", "status": "FAILED", "job": "integration (5)"}, {"target": "tests/compiled_macro_collection_source_asts.rs", "name": "unordered_literal_ast_edges_and_runtime_effects_preserve_textual_order", "status": "FAILED", "job": "integration (5)"}, {"target": "tests/compiled_macro_core_environment.rs", "name": "compiled_macro_core_namespace_keeps_complete_declaration_records", "status": "FAILED", "job": "integration (2)"}]}, "comparison_vs_0acd": {"same_failed_names": true, "new_failed_names": [], "resolved_failed_names": [], "new_failed_previously_passing": [], "observed_failure_class": "All observed failed-test panics guest Wasm fuel; no compiler errors."}, "logs": [{"file": "job-117494317914.log", "sha256": "92ab8066e8bb53d203b91645ea461e1c9a36d2d06eb9fa8071403ce56aefe5e2", "job": "foundation", "conclusion": "success"}, {"file": "job-117494318087.log", "sha256": "88d4d1e0685879b4051dc1d7a76e422b4c3d5afecc090d8047b2f0d96312237b", "job": "integration (4)", "conclusion": "failure"}, {"file": "job-117494318160.log", "sha256": "58dcf9743b6ca98e9be55f4cb6a1cfde3d126ef6afbff83e9b351b0c1b58d2c4", "job": "integration (1)", "conclusion": "failure"}, {"file": "job-117494318162.log", "sha256": "d39fd6575befb1e0c1ee2e0e4d919be480f0b70f19e61ae199012a64eb0ad139", "job": "integration (3)", "conclusion": "failure"}, {"file": "job-117494318173.log", "sha256": "1b46f65835cb99c7746e960ff4327fac8d833f391c6db91e578a45bd6811a90d", "job": "integration (0)", "conclusion": "failure"}, {"file": "job-117494318179.log", "sha256": "72ad50559a7876a08b9a0170674acd3856e688d94a4616c96a726a8cf8ddfe5d", "job": "integration (6)", "conclusion": "failure"}, {"file": "job-117494318185.log", "sha256": "eba5a70546cd06f96a0fef1387efda1c7709ce7f2099b6daf2f4d58c68cd7fce", "job": "integration (7)", "conclusion": "failure"}, {"file": "job-117494318223.log", "sha256": "76ad197bdf5b69f2acef2f82c9c8b6696569f1e098b23e1198a70d6332cc06a1", "job": "integration (5)", "conclusion": "failure"}, {"file": "job-117494318257.log", "sha256": "4e0d5ca070db2154cdaccbb150e4d246fb8340e7a6b9796d082b41d1b529cabd", "job": "integration (2)", "conclusion": "failure"}, {"file": "job-117498430974.log", "sha256": "f4f026086b91f0bb55ca9df9abb85b6b3ade9550a1fb67d648d394fa4cf899a1", "job": "test", "conclusion": "failure"}], "limits": ["Execution totals, not a whole-workspace baseline.", "Later integration targets unexecuted; aggregate job adds no tests.", "V3experimental and c75/c7/13f diagnostic tuples separate."]}. Not a candidate CI verdict.
No candidate full-workspace verdict, final-head CI success, issue acceptance or
milestone completion is claimed. Independent source/archive review precedes any
repository publication. No unrelated new PR or further diagnostic producer.
