#!/usr/bin/env python3
"""Cache-only Git-resolved evidence; no Cargo, checkout, index or repository writes."""
import argparse, collections, gzip, hashlib, io, json, pathlib, re, shutil, subprocess, tarfile
C = pathlib.Path('/home/bobby/.cache/suss-m4-work')
HERE = pathlib.Path(__file__).resolve().parent
BASE = '4c6545f78c23c15bba4219a142f69b01ed54e539'
RUNS = ['compact-heads-focused','compact-heads-preservation']
def read(p): return json.loads(p.read_bytes())
def sha(b): return hashlib.sha256(b).hexdigest()
def git(root,*args): return subprocess.check_output(['git','-C',str(root),*args])
def resolve(root,head): return git(root,'rev-parse','--verify',head+'^{commit}').decode().strip()
def tree(root,head):
    out={}
    for record in git(root,'ls-tree','-r','-z',head).split(b'\0'):
        if not record: continue
        fields,path=record.split(b'\t',1); mode,kind,oid=fields.decode().split()
        out[path.decode()] = (kind,oid)
    return out

def blobs(root,oids):
    # communicate drains stdout while writing requests; no per-blob subprocesses.
    oids=list(dict.fromkeys(oids))
    data=subprocess.run(['git','-C',str(root),'cat-file','--batch'],input=('\n'.join(oids)+'\n').encode(),stdout=subprocess.PIPE,check=True).stdout
    offset=0;out={}
    for expected in oids:
        end=data.index(b'\n',offset);oid,kind,size=data[offset:end].decode().split()
        assert oid==expected and kind=='blob'
        size=int(size);offset=end+1;raw=data[offset:offset+size];offset+=size
        assert data[offset:offset+1]==b'\n';offset+=1
        out[oid]=raw
    assert offset==len(data)
    return out

def copy_tree(source,dest):
    for f in sorted(source.rglob('*')):
        assert not f.is_symlink(),f
        parts=f.relative_to(source).parts
        if not f.is_file() or 'input-blobs' in parts or ('frozen' in parts and 'sha256' in parts): continue
        target=dest/f.relative_to(source);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(f.read_bytes())

def terminal(name):
    p=C/name/'receipt.json'
    if not p.is_file(): return False
    r=read(p)
    return r.get('current') is None and (C/name/'terminal-freeze.json').is_file() and all(isinstance(s.get('exit'),int) for s in r['stages'])

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=pathlib.Path,default=pathlib.Path('/home/bobby/Work/code/bobby/suss-m4-reachable-materialization-workspace'))
    ap.add_argument('--assemble',action='store_true')
    ap.add_argument('--source-commit')
    ap.add_argument('--binding',type=pathlib.Path)
    ap.add_argument('--extra-review',type=pathlib.Path,action='append',default=[])
    ap.add_argument('--parent-ci',type=pathlib.Path)
    a=ap.parse_args()
    plan={'base':BASE,'runs':{n:{'terminal':terminal(n)} for n in RUNS},'inputs_per_map':2989,
          'source':'Exact Suss Git commits plus their pinned ClojureScript Git commits; SHA256 proof per path per freeze. No repeated source CAS/Wasm archives; NOT standalone.',
          'scope':'focus51 and preservation76 selections [46,17,1,1,11], actual outcomes only; before/after3-file source packet included',
          'diagnostic':'Rejected flat-edge V3/V4 published experiment860e2ce referenced only, no duplicate data/acceptance credit; no extra diagnostics added',
          'assembly_requires':'Both runs terminal/unchanged; eventual full source commit and 2989-path Git binding; independent review before repository staging/publication',
          'no_execution':'No tests/bootstrap/Cargo/repository writes; plan mode does not assemble.'}
    (HERE/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
    if not a.assemble: print(json.dumps(plan,indent=2));return
    assert all(terminal(n) for n in RUNS),'Wait for both cohorts to be terminal'
    assert a.source_commit and a.binding
    head=resolve(a.root,a.source_commit);binding=read(a.binding)
    assert binding['head']==head and binding['checked']==2989 and binding['mismatches']==[]
    assert read(pathlib.Path(binding['freeze']))==read(C/RUNS[0]/'terminal-freeze.json')
    stage=HERE/'payload';assert not stage.exists(),'Preserve prior assembly before replacing any reviewed bytes'
    stage.mkdir()
    for name in RUNS:
        receipt=read(C/name/'receipt.json');assert receipt['final_changed']==[]
        copy_tree(C/name,stage/name)
    copy_tree(C/'compact-canonical-heads-source',stage/'compact-source-packet')
    shutil.copyfile(a.binding,stage/'candidate-source-commit-binding.json')
    shutil.copyfile(__file__,stage/'package-compact-heads.py')
    for i,p in enumerate(a.extra_review):
        d=stage/'independent-reviews'/f'{i}-{p.name}';d.parent.mkdir(exist_ok=True);d.write_bytes(p.read_bytes())
    freezes={}
    for name in RUNS:
        for f in (C/name).glob('*freeze*.json'):
            m=read(f);assert len(m)==2989 and all(re.fullmatch('[0-9a-f]{64}',h) for h in m.values())
            freezes[name+'/'+f.name]=m
    # Resolve ONLY requested paths, avoiding large evidence blobs elsewhere in tree.
    wanted={(path,h) for m in freezes.values() for path,h in m.items()}
    unresolved=set(wanted);resolution={};required=[]
    for commit in [BASE,head]:
        root_tree=tree(a.root,commit)
        candidates={p:root_tree[p][1] for p,h in unresolved if p in root_tree and root_tree[p][0]=='blob'}
        if candidates:
            raw=blobs(a.root,candidates.values())
            for path,h in list(unresolved):
                oid=candidates.get(path)
                if oid and sha(raw[oid])==h:
                    resolution[path+'@'+h]={'repository':'suss','commit':commit,'path':path,'git_blob':oid,'sha256':h,'bytes':len(raw[oid])};unresolved.remove((path,h))
        pin=root_tree.get('clojurescript')
        if pin and pin[0]=='commit':
            cljs=a.root/'clojurescript';st=tree(cljs,pin[1])
            candidates={p:st[p[len('clojurescript/'):]][1] for p,h in unresolved if p.startswith('clojurescript/') and p[len('clojurescript/'):] in st and st[p[len('clojurescript/'):]][0]=='blob'}
            if candidates:
                raw=blobs(cljs,candidates.values())
                for path,h in list(unresolved):
                    oid=candidates.get(path)
                    if oid and sha(raw[oid])==h:
                        resolution[path+'@'+h]={'repository':'clojurescript','commit':pin[1],'path':path[len('clojurescript/'):],'git_blob':oid,'sha256':h,'bytes':len(raw[oid])};unresolved.remove((path,h))
            required.append({'repository':'clojurescript','commit':pin[1]})
        required.append({'repository':'suss','commit':commit})
    assert not unresolved, ('No uncommitted-byte substitution permitted',sorted(unresolved)[:10])
    source={'standalone':False,'required_git_objects':required,'frozen_inputs_per_map':2989,'freeze_maps':freezes,'resolution':resolution,
            'reproduction':'Fetch exact commits in the named repositories; git cat-file blob COMMIT:PATH and SHA256 must reproduce every freeze entry. No dependency tarball required.'}
    (stage/'GIT-SOURCE-RESOLUTION.json').write_text(json.dumps(source,indent=2)+'\n')
    summaries={};union={}
    for n in RUNS:
        r=read(C/n/'receipt.json');selection=read(C/n/'source-derived-selection.json');counts=collections.Counter()
        for s in r['stages']:
            rows=s.get('records',[]);actual=collections.Counter(x['name'].split('::')[-1] if n==RUNS[1] else x['name'] for x in rows)
            if s['name'] in selection: assert actual==collections.Counter(selection[s['name']]),(n,s['name'])
            bystatus=collections.Counter(x['status'] for x in rows)
            reported={k:sum(v[k] for v in s.get('summaries',[])) for k in ['pass','fail','ignore']}
            assert reported=={'pass':bystatus['ok'],'fail':bystatus['FAILED'],'ignore':bystatus['ignored']},(n,s['name'])
            counts.update(reported)
            for row in rows:
                union.setdefault(row['name'],[]).append({'run':n,'stage':s['name'],'status':row['status']})
        summaries[n]={'counts':dict(counts),'stages':r['stages']}
    focus_counts=summaries[RUNS[0]]['counts']
    assert focus_counts['pass']+focus_counts['fail']==51 and focus_counts['ignore']==0
    assert summaries[RUNS[1]]['counts']=={'pass':76,'fail':0,'ignore':0}
    assert len(union)==127 and all(len(v)==1 for v in union.values()),'No duplicate raw/scratch credit'
    unique=collections.Counter(v[0]['status'] for v in union.values())
    assert unique['ok']+unique['FAILED']==127 and unique['ignored']==0
    comparison=read(C/RUNS[1]/'sourcechild-comparison.json')
    assert comparison['candidate_markers']==comparison['control_markers']==220 and comparison['ordered_labels_results_match'] is True
    assert set(comparison['phase_results'])=={'Runtime','Macro'}
    for p in comparison['phase_results'].values():
        assert p['candidate_start']==10000000 and p['candidate_final_result']=='Ok(())'
    # Verify these observed source-bound outcomes, not a model prediction.
    for phase in comparison['phase_results'].values():
        assert phase['candidate_remaining']==132163 and phase['control_remaining']==131281
        assert phase['net_removed_at_final_marker']==882
    results={'source_commit':head,'attempts':summaries,'unique':dict(unique),'selected_records':union,'sourcechild_actual':comparison['phase_results']}
    (stage/'TERMINAL-RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
    parent='No candidate full workspace/CI verdict. Parent4c CI not included.'
    if a.parent_ci:
        ci=read(a.parent_ci/'independent-terminal-summary.json');assert ci['head']==BASE and ci['conclusion'] in ['success','failure']
        assert ci['foundation']['Rust_execution_counts']=={'pass':531,'fail':0,'ignore':1}
        assert ci['integration']['pass']==111 and ci['integration']['fail']==14 and ci['integration']['unexecuted_targets']==225
        copy_tree(a.parent_ci,stage/'parent-ci-4c');parent='Separate exact-parent4c terminal CI only: '+json.dumps(ci)+'. Not a candidate CI verdict.'
    prefix=read(C/RUNS[0]/'core-env-prefix-comparison.json')
    assert prefix['candidate']['log_sha256']==sha((C/RUNS[0]/'default-core-env.log').read_bytes())
    control=C/'borrowed-metadata-validation-focused/default-core-env.log'
    assert prefix['parent']['log_sha256']==sha(control.read_bytes())
    target=stage/'production4c-control-core-env.log';target.write_bytes(control.read_bytes())
    unit_log=(C/RUNS[0]/'raw-key-plan.log').read_text()
    unit_rows=re.findall(r'compact-head-table slots_old=(\d+) slots_new=(\d+) capacity=(\d+) old_work=(\d+) new_work=(\d+)',unit_log)
    assert len(unit_rows)==1
    old_slot,new_slot,capacity,old_work,new_work=map(int,unit_rows[0])
    assert (old_slot,new_slot)==(24,16) and (old_work,new_work)==(762356,748317)
    replacements={'{{SOURCE_COMMIT}}':head,'{{PHASE_RESULTS}}':json.dumps(comparison['phase_results']),'{{PARENT_CI}}':parent,
                  '{{FOCUS_RESULTS}}':json.dumps(focus_counts),'{{UNIQUE_RESULTS}}':json.dumps(dict(unique)),
                  '{{CORE_PREFIX}}':json.dumps(prefix),'{{TABLE_WORK}}':json.dumps({'old_slot':old_slot,'new_slot':new_slot,'capacity':capacity,'old_work':old_work,'new_work':new_work})}

    for name in ['evidence','handoff']:
        text=(HERE/(name+'.proposed.md')).read_text()
        for key,value in replacements.items():text=text.replace(key,value)
        (HERE/(name+'.ready.md')).write_text(text)
        if name=='evidence':(stage/'REPORT.md').write_text(text)
    manifest={p.relative_to(stage).as_posix():{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(stage.rglob('*')) if p.is_file()}
    (stage/'MANIFEST.json').write_text(json.dumps({'source_commit':head,'payloads':manifest,'payload_count':len(manifest)},indent=2)+'\n')
    archive=HERE/'m4-compact-canonical-heads-2026-10-17.tar.gz';assert not archive.exists()
    with archive.open('wb') as out,gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for p in sorted(stage.rglob('*')):
                if not p.is_file():continue
                b=p.read_bytes();info=tarfile.TarInfo(p.relative_to(stage).as_posix());info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
    result={'source_commit':head,'archive':str(archive),'sha256':sha(archive.read_bytes()),'members':len(manifest)+1,'manifested_payloads':len(manifest),'unique':dict(unique),'publication':'CACHE ONLY; independent review before any repository publication','standalone':False,'source_resolution':'Exact Git objects; source CAS/Wasm payloads excluded except required uncommitted source-review snapshots'}
    (HERE/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
