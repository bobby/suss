#!/usr/bin/env python3
"""Cache-only terminal-gated assembly; never runs Cargo or edits repository files."""
from pathlib import Path,PurePosixPath
import argparse,json,hashlib,re,subprocess,tarfile,gzip,io,os
P=Path(__file__).resolve().parent;C=P.parent;trace=C/'pr271-cert-component-trace';run=C/'pr271-delegated-memo-validation';repo='/home/bobby/Work/code/bobby/suss';head='53b206a7ab2e20356b52c817cae98c3328d31f05';H=lambda b:hashlib.sha256(b).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('--assemble',action='store_true');args=parser.parse_args()
r=json.loads((run/'receipt.json').read_text())
if not args.assemble:
 print(json.dumps({'state':'PREPARED_NO_ARCHIVE','source':head,'validation_terminal':r.get('terminal'),'current':r.get('current'),'next':'Run this script --assemble only after validation terminal/current=null.'}));raise SystemExit()
assert r.get('terminal') is True and r.get('current') is None and r['base']==head,'Validation not terminal at exact source'
# Do not package while the recorded cargo/test process is still active. No signaling.
pid=r.get('pid');proc=Path('/proc')/str(pid)
if pid and proc.exists():
 cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace');assert not any(x in cmd for x in ['cargo test','debug/deps/','suss-bootstrap']),('Recorded producer still active',pid)
review=json.loads((trace/'positive-terminal-independent-review.json').read_text());assert review['source_head']==head
changes=subprocess.check_output(['git','-C',repo,'diff-tree','--no-commit-id','--name-only','-r',head],text=True).splitlines();assert len(changes)==6
blobs={f:subprocess.check_output(['git','-C',repo,'show',head+':'+f]) for f in changes};assert {f:H(b) for f,b in blobs.items()}==review['source_commit_changed_six']
for st in r['stages']:assert not st['changed']
manifest=json.loads((run/'source-manifest.json').read_text());assert all(manifest[f]==H(b) for f,b in blobs.items())
inputs=[f for f in manifest if (f.endswith(('.rs','.sus','.clj','.cljs','.cljc','.wat')) or Path(f).name in ('Cargo.toml','Cargo.lock')) and f not in blobs]
raw=subprocess.run(['git','-C',repo,'cat-file','--batch'],input=('\n'.join(head+':'+f for f in inputs)+'\n').encode(),capture_output=True,check=True).stdout;pos=0
for f in inputs:
 end=raw.index(b'\n',pos);a=raw[pos:end].split();assert a[1]==b'blob';n=int(a[2]);assert H(raw[end+1:end+1+n])==manifest[f],f;pos=end+2+n
D=P/'payload';assert not D.exists(),'Use a fresh publication directory or independently inspect previous payload; do not silently overwrite an assembled packet'
def put(n,b):
 d=D/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
def js(n,x):put(n,(json.dumps(x,indent=2)+'\n').encode())
for f,b in blobs.items():put('source/'+f,b)
for src in sorted(trace.iterdir()):
 if src.is_file() and src.suffix in ('.log','.json','.patch','.rs'):put('trace/'+src.name,src.read_bytes())
for src in sorted(run.rglob('*')):
 if src.is_file():put('validation/'+str(src.relative_to(run)),src.read_bytes())
put('assemble.py',Path(__file__).read_bytes());put('REPORT.template.md',(P/'REPORT.template.md').read_bytes())
counts=[];selected={};unknown=[]
for name,file in [('mechanism-standalone',trace/'delegate-after.log'),('keyword-original',trace/'keyword-after.log')]+[(st['name'],run/(st['name']+'.log')) for st in r['stages'] if st['name']!='identity']:
 text=file.read_text();summary=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);starts=re.findall(r'^test (\S+) \.\.\.',text,re.M)
 if len(summary)!=1 or len(starts)!=sum(map(int,summary[0])):
  unknown.append(name);counts.append({'stage':name,'status':'UNESTABLISHED_COMPILE_SETUP_OR_SELECTION','starts':starts,'summary':summary});continue
 trip=list(map(int,summary[0]));counts.append({'stage':name,'counts':trip,'names':starts})
 for t in starts:selected.setdefault(t,[]).append(name)
completed=[s['name'] for s in r['stages']];unexecuted=[n for n in r['planned'] if n not in completed];assert r.get('unexecuted',unexecuted)==unexecuted
terminal_review=json.loads((run/'terminal-independent-review.json').read_text());assert terminal_review['source']==head and set(selected)==set(terminal_review['unique_tests'])
summary={'source':head,'unique_outcomes':terminal_review['unique'],'execution_outcomes':terminal_review['executions'],'unique_executed_test_names':len(selected),'stage_results':counts,'unestablished':unknown,'unexecuted':unexecuted,'duplicates':{k:v for k,v in selected.items() if len(v)>1},'note':'Per-stage passing/failing executions are not summed as distinct passing tests when the new regression repeats in the scoped group. Raw failures retained; no full-readiness verdict.'}
js('assembly-summary.json',summary)
js('source-binding.json',{'source':head,'six_source_boot_hashes':{f:H(b) for f,b in blobs.items()},'unchanged_compiler_oracle_git_checked':len(inputs),'full_freeze_count':len(manifest),'inputs':{f:{'git':head+':'+f,'sha256':manifest[f]} for f in inputs},'limits':'Git-dependent source archive; remaining full repository files represented by original driver manifest. No independent prebootstrap/final-freeze capture invented.'})
table=['| Stage | PASS | FAIL | ignored |','|---|---:|---:|---:|']
for s in counts:
 if 'counts' in s:table.append('| '+s['stage']+' | '+' | '.join(map(str,s['counts']))+' |')
 else:table.append('| '+s['stage']+' | UNESTABLISHED | — | — |')
body='\n'.join(table)+'\n\nUnique executed names: '+str(len(selected))+'. Repeated names are listed in assembly-summary.json. Unexecuted: '+(', '.join(unexecuted) or 'none in this driver')+'. Unestablished stages: '+(', '.join(unknown) or 'none')+'.'
put('REPORT.md',(P/'REPORT.template.md').read_text().replace('{{VALIDATION_RESULTS}}',body).encode())
items=sorted(f for f in D.rglob('*') if f.is_file());put('MANIFEST.sha256',('\n'.join(H(f.read_bytes())+'  '+str(f.relative_to(D)) for f in items)+'\n').encode())
archive=P/'m4-delegated-canonical-memo-routing-2026-10-18.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as z:
  with tarfile.open(fileobj=z,mode='w',format=tarfile.PAX_FORMAT) as t:
   for f in sorted(D.rglob('*')):
    if f.is_file():
     b=f.read_bytes();i=tarfile.TarInfo(str(f.relative_to(D)));i.size=len(b);i.mtime=0;i.uid=i.gid=0;i.uname=i.gname='';i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len({m.name for m in members})==len(members)
 for m in members:assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
 hashes={l.split('  ',1)[1]:l.split('  ',1)[0] for l in t.extractfile('MANIFEST.sha256').read().decode().splitlines()};assert set(hashes)=={m.name for m in members}-{'MANIFEST.sha256'}
 for f,h in hashes.items():assert H(t.extractfile(f).read())==h
result={'archive':str(archive),'sha256':H(archive.read_bytes()),'members':len(members),'payloads':len(hashes),'source':head,'all_manifest_payload_hashes_verified':True,'report':str(D/'REPORT.md'),'summary':summary}
(P/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='summary'}))
