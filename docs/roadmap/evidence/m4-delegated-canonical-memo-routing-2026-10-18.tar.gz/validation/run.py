from pathlib import Path
import subprocess as s, os, json, hashlib, time, datetime
root=Path('/home/bobby/Work/code/bobby/suss-m4-coherent-identity-acceptance');p=Path(__file__).parent
base=s.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/bobby/.cache/suss-m4-work/m4-cost-diagnostic-target',CARGO_BUILD_JOBS='1',RAYON_NUM_THREADS='1')
cargo=['cargo','test','--locked'];tail=['--','--test-threads=1','--nocapture']
stages=[('identity',['python3','scripts/verify_bootstrap_identity.py'],{}),('scoped-stores',cargo+['-p','suss-compile','--lib','memo_bridge::scoped_tests::']+tail,{}),('remaining-memo',cargo+['-p','suss-compile','--lib','--','portable_macros::memo_leaf_tests::native_memo_leaf_symbol_forcewrite','portable_macros::memo_leaf_tests::native_memo_leaf_symbol_nil_aware','portable_macros::memo_leaf_tests::native_memo_leaf_keyword_nil_aware','--exact','--test-threads=1','--nocapture'],{}),('analyzer-effects',cargo+['-p','suss-compile','--lib','portable_macros::analyzer_literal_effect_tests::analyzer_literal_actual_env_pre_dispatch_memo_effects_survive_gc_and_restoration','--','--exact','--test-threads=1','--nocapture'],{}),('replaced-hash',cargo+['-p','suss-cli','--test','compiled_macro_cumulative_fuel','--','source_metadata_keeps_identity_with_a_replaced_hash_method','source_metadata_keeps_canonically_warmed_identity_after_hash_replacement','--exact','--test-threads=1','--nocapture'],{}),('pinned-map',cargo+['-p','suss-compile','--test','clojure_test_suite','pinned_map_declaration_executes_without_transport_loss','--','--exact','--test-threads=1','--nocapture'],{'SUSS_CLOJURE_TEST_SUITE_CAPTURE':str(p/'map-capture')}),('cljs-observations',cargo+['-p','suss-cli','--test','portable_short_property_observations']+tail,{})]
files=s.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
def hashes():return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if (root/f).is_file()}
freeze=hashes();(p/'source-manifest.json').write_text(json.dumps(freeze,indent=2)+'\n')
receipt={'base':base,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal':False,'stages':[],'current':None,'planned':[n for n,_,_ in stages]}
def save():(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name,cmd,extra in stages:
 assert hashes()==freeze
 receipt['current']=name;save();runenv=env.copy();runenv.update(extra);start=time.monotonic()
 with (p/(name+'.log')).open('w') as log:
  child=s.Popen(cmd,cwd=root,env=runenv,stdout=log,stderr=s.STDOUT);receipt['pid']=child.pid;save();code=child.wait()
 changed=[f for f,h in freeze.items() if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h]
 row={'name':name,'argv':cmd,'environment_overrides':extra,'exit':code,'seconds':round(time.monotonic()-start,3),'changed':changed};receipt['stages'].append(row);receipt['current']=None;save();print(json.dumps(row),flush=True)
 assert not changed
 if code:break
receipt['terminal']=True;receipt['unexecuted']=[n for n,_,_ in stages if n not in [t['name'] for t in receipt['stages']]];receipt['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
