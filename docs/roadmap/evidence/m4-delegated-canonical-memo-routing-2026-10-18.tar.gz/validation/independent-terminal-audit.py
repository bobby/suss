from pathlib import Path
import re,json,hashlib
p=Path(__file__).parent;t=p.parent/'pr271-cert-component-trace';r=json.loads((p/'receipt.json').read_text());assert r['terminal'] and r['current'] is None and all(not s['changed'] for s in r['stages'])
H=lambda b:hashlib.sha256(b).hexdigest();executions=[];unique={}
for stage,file in [('mechanism-standalone',t/'delegate-after.log'),('keyword-forcewrite',t/'keyword-after.log'),('scoped-stores',p/'scoped-stores.log'),('remaining-memo',p/'remaining-memo.log')]:
 text=file.read_text();sums=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert len(sums)==1;counts=list(map(int,sums[0]));names=re.findall(r'^test (\S+) \.\.\.',text,re.M);assert len(names)==sum(counts)
 failures=set(re.findall(r"thread '([^']+)'[^\n]*panicked at",text));assert len(failures)==counts[1];assert counts[2]==0
 for name in names:
  status='FAIL' if name in failures else 'PASS'
  if name in unique:assert unique[name]['status']==status;unique[name]['stages'].append(stage)
  else:unique[name]={'status':status,'stages':[stage]}
 executions.append({'stage':stage,'counts':counts,'names':names,'failed_names':sorted(failures),'log_sha256':H(file.read_bytes())})
assert len(unique)==18 and sum(x['status']=='PASS' for x in unique.values())==16
keyword=[];symbols=[];summaries=[]
for file in [t/'keyword-after.log',p/'remaining-memo.log']:
 for line in file.read_text().splitlines():
  if 'NATIVE_MEMO_LEAF {' in line:
   row=json.loads(line.split('NATIVE_MEMO_LEAF ',1)[1]);assert len(row['fields'])==len(row['actual'])==len(row['expected'])==13 and row['actual']==row['expected'];(keyword if row['case'].startswith('keyword/') else symbols).append(row)
  if 'NATIVE_MEMO_LEAF_SUMMARY {' in line:summaries.append(json.loads(line.split('NATIVE_MEMO_LEAF_SUMMARY ',1)[1]))
assert len(keyword)==24 and len({(x['case'],x['stage']) for x in keyword})==24
assert len(symbols)==8 and {x['stage'] for x in symbols}=={'baseline'}
syms=[s for s in summaries if s['kind']=='symbol'];assert len(syms)==2 and all(s['rows']==4 and len(s['differences'])==4 for s in syms)
for s in syms:
 for d in s['differences']:assert '/custom-write: execution error' in d and 'Fresh coherent source failed certification' in d and 'caller &env input transport' in d
assert r['unexecuted']==['analyzer-effects','replaced-hash','pinned-map','cljs-observations']
result={'verdict':'VERIFIED_PARTIAL_ROUTING_RECOVERY_WITH_TWO_REMAINING_SYMBOL_CERTIFICATION_FAILURES','source':r['base'],'unique':{'total':18,'pass':16,'fail':2,'ignored':0},'executions':{'total':19,'pass':17,'fail':2,'ignored':0},'stage_results':executions,'unique_tests':unique,'keyword':{'complete_rows':24,'fields_per_row':13,'all_actual_equal_expected':True,'nil_aware_variants':[False,True],'phases':['Runtime','Macro'],'warming':[False,True],'stages':['baseline','custom-write','restored-method']},'symbol':{'baseline_only_rows':8,'fields_per_row':13,'baseline_actual_equal_expected':True,'custom_write_certification_failures':8,'restoration_rows':'UNEXECUTED for all eight Symbol cases','summaries':syms},'unexecuted_stages':r['unexecuted'],'freeze':'Recorded unchanged after every validation stage; positive manifests match six committed source/BOOT images per earlier positive-terminal-independent-review.json. Packaging independently checks validation compiler/oracle inputs against53b.','limitations':['Symbol failures are semantic/source-certification errors, not fuel failures or setup/compile failures.','Standalone mechanism test repeats in scoped group; counted once among18 unique, twice among19executions.','Before/fact diagnostic sources remain separate from final source tuple; historical positive review still describes then-pending validation.','No analyzer/replacement/map/CLJS/current fullbaseline/CI/readiness/issue acceptance conclusion. No test or tracked edit by reviewer.']}
(p/'terminal-independent-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'counts':result['unique'],'keyword_rows':24,'symbol_baseline_rows':8,'symbol_custom_failures':8,'unexecuted':r['unexecuted']}))
