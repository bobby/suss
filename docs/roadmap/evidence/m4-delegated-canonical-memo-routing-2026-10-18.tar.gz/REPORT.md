# Delegated canonical memo writes: bounded routing correction

Source: `53b206a7ab2e20356b52c817cae98c3328d31f05` (two Rust paths and four normally regenerated bootstrap outputs). This is partial Draft #271 progress, not readiness, closure, full-baseline or passing-CI evidence.

The canonical store bridge retains its qualifying watch checks and canonical pre/post publication. When canonical inspection fails under a genuine active IHash observer scope, and there are no competing canonical candidates, it invokes the ordinary physical setter whose existing scoped hook must prove exact receiver, layout, write-time domain and post-store validity. It does not mint authority merely from delegation or scope presence. Additional route work is prepaid. The new test confirms two accepted in-extent cases and rejection for poisoned-at-write/restored-later and out-of-extent writes, while asserting that the actual store and payload restoration still occur.

Two completed positive tests are independently source-bound: the new mechanism regression passes; the unchanged original Keyword forcewrite test passes all 12 rows (two caller phases × cold/warm × three stages), with each row's 13 actual fields exactly equal to expected. The new test is Macro-only; the original Keyword observation spans both phases. The new regression's later repetition inside scoped-stores counts once in the final distinct union.

The earlier diagnostic baseline is distinct: the test failed its direct-fact assertion; the Keyword component trace logged four certification failures with direct=false and other examined certificate predicates true. Before/fact source manifests include transient diagnostics and do not equal the final six-image tuple. These runs explain the failure; they are not untouched-final-source acceptance runs or additional passing tests.

The completed source-53b union is **18 distinct tests: 16 PASS, 2 source-certification FAIL, 0 ignored**. There are 19 executions (17 passing, two failing): the standalone new mechanism regression overlaps the 14-test scoped group. Identity verification passes separately and is not a Rust test.

The 14 scoped tests all pass. Original Keyword forcewrite and nil-aware both pass: **24 complete observations × 13 fields**, actual=expected, covering both caller phases, cold/warm, and baseline/custom-write/restored-method. Original Symbol forcewrite and nil-aware fail. Their eight baseline rows match all 13 fields, but **all eight custom-write cases fail fresh coherent source certification during caller-&env transport** (cold bytes0..22, warm bytes0..21); all Symbol restoration observations are unexecuted. These are certification errors, not fuel failures, compiler errors or missing tests.

The driver stops after remaining-memo returns101. **analyzer-effects, replaced-hash, pinned-map and cljs-observations are UNEXECUTED**. No map/oracle result is transferred from older source.

Failed tests:

- `portable_macros::memo_leaf_tests::native_memo_leaf_symbol_forcewrite`
- `portable_macros::memo_leaf_tests::native_memo_leaf_symbol_nil_aware`

| Stage | PASS | FAIL | ignored |
|---|---:|---:|---:|
| mechanism-standalone | 1 | 0 | 0 |
| keyword-original | 1 | 0 | 0 |
| scoped-stores | 14 | 0 | 0 |
| remaining-memo | 1 | 2 | 0 |

Unique executed names: 18. Repeated names are listed in assembly-summary.json. Unexecuted: analyzer-effects, replaced-hash, pinned-map, cljs-observations. Unestablished stages: none.

This is a bounded recovery of the delegated mechanism and both Keyword variants, with the Symbol failures still visible. It is not a claim that all memo routing or original acceptance is fixed. `terminal-independent-review.json` is the current terminal review; the earlier positive review is retained unchanged as a historical review issued while validation was pending.

The assembly retains all raw failures and explicit unexecuted stages, source manifests and patches, source reviews, positive independent review, and six immutable source/BOOT images read from the source commit. It never reads active author source for those images. Standard normal bootstrap and identity logs are retained; identity also executes in the validation driver. No reviewer runs Cargo. No quota/rate changes or semantic assertions are relaxed.

The validation receipt is terminal/current=null; every planned stage is either executed or explicitly unexecuted. The assembler requires that terminal state. Its per-stage changed=[] claims are retained as driver evidence, not upgraded into a missing independent final freeze or a prebootstrap unchanged claim. The packet's full manifest hashes are inventories; compiler/oracle inputs are independently checked against explicit source commit:path dependencies, not a standalone repository source archive. Any map/CLJS comparator results beyond Rust harness outcomes require the retained actual comparison artifacts; no 69-host-pass claim is inferred from one Rust PASS.

The earlier packed V2 57-pass/13-fuel-failure cohort, public zero-row reach loss, six candidate guard failures, unexecuted baseline and final-head CI remain separate evidence. This routing cohort does not rerun or erase those failures, establish #264 acceptance, or authorize promotion/merge/closure.
