import hashlib, io, json, re, subprocess, sys, tarfile
from pathlib import Path
root=Path('/home/bobby/Work/code/bobby/suss-m4-callable-hash')
# Invoke only after the authoritative exec handle reports a terminal exit code.
if len(sys.argv)!=2:
    raise SystemExit('Requires terminal exit code from exec handle59990')
code=int(sys.argv[1])
log=Path('/tmp/suss-m4-callable-exclusive-baseline.log').read_bytes()
rows=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log.decode())
assert rows, 'No completed test suites'
suites=[]
started=[]
current=None
for line in log.decode().splitlines():
    if line.startswith('     Running ') or line.startswith('   Doc-tests '):
        current=line.strip()
        started.append(current)
    match=re.match(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',line)
    if match:
        assert current is not None, 'Summary without target'
        suites.append({'target':current,'outcome':match[1],**{name:int(match[i]) for i,name in enumerate(['passed','failed','ignored','measured','filtered-out'],2)}})
        current=None
assert len(suites)==len(rows)
current_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert current_head.startswith('7b9df04')
assert not subprocess.check_output(['git','diff','936da38e65b24837155511a3fda0ec17576b0764','HEAD','--','.',':!docs'],cwd=root,text=True).strip(), 'Non-documentation changes since tested code'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all','--','.',':!docs'],cwd=root,text=True).strip(), 'Source/manifest changes outside documentation'
counts={name:sum(int(row[i]) for row in rows) for i,name in enumerate(['passed','failed','ignored','measured','filtered-out'],1)}
if code==0:
    assert counts['failed']==0 and all(row[0]=='ok' for row in rows)
    assert suites[-1]['target']=='Doc-tests suss_reader' and current is None, 'Final workspace doctest target not completed'
    assert len(started)==len(suites), 'Started target lacks terminal summary'
    assert {row['target'] for row in suites if row['target'].startswith('Doc-tests ')}=={'Doc-tests suss_cli','Doc-tests suss_compile','Doc-tests suss_core','Doc-tests suss_reader'}
receipt={'schema':1,'issue':258,'tested-code':'936da38e65b24837155511a3fda0ec17576b0764','baseline-head':current_head,'terminal-session':59990,'exit-code':code,'command':'cargo test --workspace --locked -- --test-threads=2','environment':{'PATH-prefix':'/home/bobby/.cargo/bin','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/bobby/Work/code/bobby/suss/target','SUSS_CLOJURE_TEST_SUITE_CAPTURE':'/tmp/suss-m4-callable-exclusive-suite'},'completed-suites':len(rows),'counts':counts,'suites':suites,'incomplete-target':current,'execution-completeness':('terminal successful workspace command; every started target completed' if code==0 else 'failed command; later targets may be unexecuted and incomplete-target outcomes are not included in totals'),'started-targets':started,'limitations':['The initial full baseline failed at an async startup timeout; retain baseline-failure archive and unchanged positive rechecks. Cause remains unexplained.','Earlier shared-target baseline failed loading suss_compile in doctests; retain failed and exclusive-recheck archives. Scratch collision reproduces the mechanism but does not replay the exact failed process.','Passing reviewed Jank baseline is not full conformance. Jank raw failures and unexecuted outcomes remain in the separate jank-evidence archive.','This receipt does not establish metadata integrity, cumulative fuel acceptance, final-head CI, or completion of M4.']}
files={'raw/full-workspace.log':log,'receipt.json':(json.dumps(receipt,indent=2)+'\n').encode()}
files['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
out=root/'docs/compatibility/caching-hash-callable/baseline-exclusive-2026-10-15.tar.gz'
with tarfile.open(out,'w:gz') as archive:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name); info.size=len(data); info.mtime=0
        archive.addfile(info,io.BytesIO(data))
with tarfile.open(out) as archive:
    for line in archive.extractfile('SHA256SUMS').read().decode().splitlines():
        checksum,name=line.split('  ',1)
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==checksum
print(json.dumps({'archive':str(out.relative_to(root)),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'receipt':receipt},indent=2))
