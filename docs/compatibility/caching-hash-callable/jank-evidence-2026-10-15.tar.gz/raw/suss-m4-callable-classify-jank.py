import collections,hashlib,importlib.util,json,sys
from pathlib import Path
sys.path.insert(0,str(Path('scripts').resolve()))
spec=importlib.util.spec_from_file_location('jank_suite', 'scripts/clojure_test_suite.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
selection_path=Path('docs/compatibility/caching-hash-callable/jank-selection.json');selection=json.loads(selection_path.read_text())
reference_path=Path('tests/oracle/clojure-test-suite-observations.json');reference=json.loads(reference_path.read_text())
assert hashlib.sha256(reference_path.read_bytes()).hexdigest()==selection['reference-sha256']
observed_path=Path('/tmp/suss-m4-callable-isolated-suite-recheck/suite-observations.json');observed=json.loads(observed_path.read_text())
counts,failures=m.compare(reference,observed)
assert failures==json.loads(m.SUITES['suite']['baseline'].read_text()), 'full reviewed baseline changed'
actual={f"{r['test']}#{r['ordinal']}":r for r in observed['assertions']}
expected={r['id']:r for r in reference['assertions']}
actual_test_counts=collections.Counter(r['test'] for r in observed['assertions'])
expected_test_counts=collections.Counter(r['test'] for r in reference['assertions'])
namespace_rows={r['namespace']:r for r in observed['namespaces']}
selected_counts=collections.Counter();results=[]
for entry in selection['assertions']:
 identity=entry['id'];want=expected[identity];found=actual.get(identity);test=entry['test'];namespace=test.split('/')[0]
 assert {k:want.get(k) for k in ['id','test','ordinal','form','line','column']}==entry
 if namespace_rows[namespace]['status']!='loaded': status,reason='not-executed',namespace_rows[namespace]
 elif found is None:status,reason='not-executed','missing'
 elif actual_test_counts[test]!=expected_test_counts[test]:status,reason='fail','test assertion-count mismatch'
 else:
  reason,judged=m.decide(want,found)
  status='fail' if reason else ('guest-judged' if judged else 'pass')
 selected_counts[status]+=1
 results.append({'id':identity,'status':status,'reason':reason,'reference':want,'actual':found})
assert len(results)==19
record={'schema':1,'issue':258,'suite':selection['suite'],'code-head':'936da38e65b24837155511a3fda0ec17576b0764','reference-sha256':hashlib.sha256(reference_path.read_bytes()).hexdigest(),'actual-observations-sha256':hashlib.sha256(observed_path.read_bytes()).hexdigest(),'selection-sha256':hashlib.sha256(selection_path.read_bytes()).hexdigest(),'comparison-script-sha256':hashlib.sha256(Path('scripts/clojure_test_suite.py').read_bytes()).hexdigest(),'known-failure-baseline-sha256':hashlib.sha256(m.SUITES['suite']['baseline'].read_bytes()).hexdigest(),'full-reviewed-baseline-matched':True,'full-suite-counts':counts,'selected-counts':dict(selected_counts),'coverage-limit':selection['coverage-limit'],'selected-namespaces':[namespace_rows[n] for n in ['clojure.core-test.hash-map','clojure.core-test.hash-set']],'assertions':results}
Path('docs/compatibility/caching-hash-callable/jank-results.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'selected':record['selected-counts'],'full-suite':counts,'baseline-matched':True}))
