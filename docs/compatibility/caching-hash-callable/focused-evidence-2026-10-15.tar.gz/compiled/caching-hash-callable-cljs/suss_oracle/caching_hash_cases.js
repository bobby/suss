// Compiled by ClojureScript 0.0.365323148 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('suss_oracle.caching_hash_cases');
goog.require('cljs.core');
suss_oracle.caching_hash_cases.observations = (function suss_oracle$caching_hash_cases$observations(encode){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [({"id": "callable-hash-function-miss-and-hit", "value": encode.call(null,(function (){
suss_oracle.caching_hash_cases.memo_call_count = (0);

suss_oracle.caching_hash_cases.memo_call_cache = null;


/**
* @constructor
 * @implements {cljs.core.IFn}
*/
suss_oracle.caching_hash_cases.MemoCallable = (function (){
this.cljs$lang$protocol_mask$partition0$ = 1;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(suss_oracle.caching_hash_cases.MemoCallable.prototype.call = (function (self__,value){
var self__ = this;
var self____$1 = this;
var this$ = self____$1;
(suss_oracle.caching_hash_cases.memo_call_count = (suss_oracle.caching_hash_cases.memo_call_count + (1)));

return (value + (62));
}));

(suss_oracle.caching_hash_cases.MemoCallable.prototype.apply = (function (self__,args16418){
var self__ = this;
var self____$1 = this;
var args__11732__auto__ = cljs.core.aclone.call(null,args16418);
return self____$1.call.apply(self____$1,[self____$1].concat((((args__11732__auto__.length > (20)))?(function (){var G__16419 = args__11732__auto__.slice((0),(20));
G__16419.push(args__11732__auto__.slice((20)));

return G__16419;
})():args__11732__auto__)));
}));

(suss_oracle.caching_hash_cases.MemoCallable.prototype.cljs$core$IFn$_invoke$arity$1 = (function (value){
var self__ = this;
var this$ = this;
(suss_oracle.caching_hash_cases.memo_call_count = (suss_oracle.caching_hash_cases.memo_call_count + (1)));

return (value + (62));
}));

(suss_oracle.caching_hash_cases.MemoCallable.getBasis = (function (){
return cljs.core.PersistentVector.EMPTY;
}));

(suss_oracle.caching_hash_cases.MemoCallable.cljs$lang$type = true);

(suss_oracle.caching_hash_cases.MemoCallable.cljs$lang$ctorStr = "suss-oracle.caching-hash-cases/MemoCallable");

(suss_oracle.caching_hash_cases.MemoCallable.cljs$lang$ctorPrWriter = (function (this__11806__auto__,writer__11807__auto__,opt__11808__auto__){
return cljs.core._write.call(null,writer__11807__auto__,"suss-oracle.caching-hash-cases/MemoCallable");
}));

/**
 * Positional factory function for suss-oracle.caching-hash-cases/MemoCallable.
 */
suss_oracle.caching_hash_cases.__GT_MemoCallable = (function suss_oracle$caching_hash_cases$observations_$___GT_MemoCallable(){
return (new suss_oracle.caching_hash_cases.MemoCallable());
});


suss_oracle.caching_hash_cases.memo_call_ordinary = (new suss_oracle.caching_hash_cases.MemoCallable()).call(null,(9));

(suss_oracle.caching_hash_cases.memo_call_count = (0));

suss_oracle.caching_hash_cases.memo_call_first = (function (){var h__11583__auto__ = suss_oracle.caching_hash_cases.memo_call_cache;
if((!((h__11583__auto__ == null)))){
return h__11583__auto__;
} else {
var h__11583__auto____$1 = (new suss_oracle.caching_hash_cases.MemoCallable()).call(null,(9));
(suss_oracle.caching_hash_cases.memo_call_cache = h__11583__auto____$1);

return h__11583__auto____$1;
}
})();

suss_oracle.caching_hash_cases.memo_call_hit = (function (){var h__11583__auto__ = suss_oracle.caching_hash_cases.memo_call_cache;
if((!((h__11583__auto__ == null)))){
return h__11583__auto__;
} else {
var h__11583__auto____$1 = (function(){throw (37)})().call(null,(function(){throw (31)})());
(suss_oracle.caching_hash_cases.memo_call_cache = h__11583__auto____$1);

return h__11583__auto____$1;
}
})();

return (new cljs.core.PersistentVector(null,4,(5),cljs.core.PersistentVector.EMPTY_NODE,[suss_oracle.caching_hash_cases.memo_call_ordinary,suss_oracle.caching_hash_cases.memo_call_first,suss_oracle.caching_hash_cases.memo_call_hit,suss_oracle.caching_hash_cases.memo_call_count],null));
})()
)})], null);
});
