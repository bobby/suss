// Compiled by ClojureScript 0.0.365323148 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('suss_oracle.caching_hash');
goog.require('cljs.core');
goog.require('suss_oracle.main');
goog.require('suss_oracle.caching_hash_cases');
suss_oracle.caching_hash._main = (function suss_oracle$caching_hash$_main(){
return cljs.core.println.call(null,JSON.stringify(({"schema": (1), "upstream": "c4295f303100bbf5afac449242d30bca1126f1a1", "cases": cljs.core.into_array.call(null,suss_oracle.caching_hash_cases.observations.call(null,suss_oracle.main.encode))})));
});
(cljs.core._STAR_main_cli_fn_STAR_ = suss_oracle.caching_hash._main);
