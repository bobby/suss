#!/usr/bin/env python3
"""Development-only Caching hash observations against pinned ClojureScript."""
import json
import sys
import portable_oracle as oracle


def generate():
    corpus = oracle.load()
    target = oracle.ROOT / 'tests/oracle/out/generated/suss_oracle/caching_hash_cases.cljs'
    target.parent.mkdir(parents=True, exist_ok=True)
    entries = '\n'.join(f'    #js {{:id {json.dumps(case["id"])} :value (encode {case["source"]})}}'
                        for case in corpus['cases'])
    target.write_text('(ns suss-oracle.caching-hash-cases)\n(defn observations [encode]\n [\n' + entries + '\n ])\n')


if __name__ == '__main__':
    oracle.CORPUS = oracle.ROOT / 'tests/oracle/caching-hash-cases.json'
    oracle.OBSERVATIONS = oracle.ROOT / 'tests/oracle/out/caching-hash-observations.json'
    arguments = sys.argv[1:]
    if len(arguments) == 2 and arguments[1] == 'callable':
        oracle.CORPUS = oracle.ROOT / 'tests/oracle/caching-hash-callable-case.json'
        oracle.OBSERVATIONS = oracle.ROOT / 'tests/oracle/out/caching-hash-callable-observations.json'
        arguments = arguments[:1]
    if arguments == ['generate']:
        generate()
    elif arguments == ['compare']:
        oracle.compare()
    else:
        raise SystemExit('usage: caching_hash_oracle.py generate|compare [callable]')
