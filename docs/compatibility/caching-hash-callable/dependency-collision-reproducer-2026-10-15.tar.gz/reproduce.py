import json,os,shutil,subprocess
from pathlib import Path
root=Path('/tmp/suss-m4-doctest-collision')
env=dict(os.environ,PATH='/home/bobby/.cargo/bin:'+os.environ['PATH'],CARGO_TARGET_DIR=str(root/'target'),CARGO_BUILD_JOBS='2')
# Deliberately preserve environment-managed compiler options.
for checkout in ['a','b']:
 p=root/checkout
 (p/'reader/src').mkdir(parents=True,exist_ok=True)
 (p/'compiler/src').mkdir(parents=True,exist_ok=True)
 (p/'cli/src').mkdir(parents=True,exist_ok=True)
 (p/'Cargo.toml').write_text('[workspace]\nmembers=["reader","compiler","cli"]\nresolver="2"\n')
 for name in ['reader','compiler','cli']:
  text=f'[package]\nname="collision_{name}"\nversion="0.1.0"\nedition="2024"\n'
  if name=='reader':text+='[lib]\ncrate-type=["cdylib","rlib"]\n'
  if name=='compiler':text+='[dependencies]\ncollision_reader={path="../reader"}\n'
  if name=='cli':text+='[dependencies]\ncollision_compiler={path="../compiler"}\n'
  (p/name/'Cargo.toml').write_text(text)
 (p/'reader/src/lib.rs').write_text('pub struct Form(pub u32);\n')
 (p/'compiler/src/lib.rs').write_text('pub use collision_reader::Form;\n')
 (p/'cli/src/lib.rs').write_text('pub use collision_compiler::Form;\n')
def run(args,cwd,label):
 result=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (root/(label+'.log')).write_bytes(result.stdout)
 return result
first=run(['cargo','build','--workspace','--message-format=json'],root/'a','a-build')
assert first.returncode==0
artifacts={}
for line in first.stdout.decode().splitlines():
 try:record=json.loads(line)
 except ValueError:continue
 if record.get('reason')=='compiler-artifact':
  name=record['target']['name']
  for file in record['filenames']:
   if file.endswith('.rlib'):artifacts[name]=file
rustdoc=['rustdoc','--edition=2024','--crate-name','collision_cli','--test','cli/src/lib.rs','--extern','collision_compiler='+artifacts['collision_compiler'],'-L','dependency='+str(root/'target/debug/deps')]
control=run(rustdoc,root/'a','a-rustdoc-before')
assert control.returncode==0
(root/'b/reader/src/lib.rs').write_text('pub struct Form(pub u64); pub fn changed_reader() {}\n')
other=run(['cargo','build','-p','collision_reader'],root/'b','b-reader-build')
assert other.returncode==0
failure=run(rustdoc,root/'a','a-rustdoc-after')
assert failure.returncode!=0 and "can't find crate for `collision_compiler`" in failure.stdout.decode()
rebuild=run(['cargo','build','--workspace'],root/'a','a-recovery-build')
assert rebuild.returncode==0
recovery=run(rustdoc,root/'a','a-rustdoc-recovery')
assert recovery.returncode==0
print(json.dumps({'before':control.returncode,'after':failure.returncode,'recovery':recovery.returncode,'exact-missing-crate':"can't find crate for `collision_compiler`" in failure.stdout.decode(),'artifacts':artifacts},indent=2))
print(failure.stdout.decode())
