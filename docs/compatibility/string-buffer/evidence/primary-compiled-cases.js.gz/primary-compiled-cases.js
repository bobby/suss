// Compiled by ClojureScript 0.0.365323148 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('suss_oracle.string_field_cases');
goog.require('cljs.core');
goog.require('goog.string.StringBuffer');
suss_oracle.string_field_cases.make_buffer = (function (){var convert = cljs.core.to_array;
return (function() { 
var G__12888__delegate = function (xs){
return Reflect.construct(goog.string.StringBuffer,convert.call(null,xs));
};
var G__12888 = function (var_args){
var xs = null;
if (arguments.length > 0) {
var G__12889__i = 0, G__12889__a = new Array(arguments.length -  0);
while (G__12889__i < G__12889__a.length) {G__12889__a[G__12889__i] = arguments[G__12889__i + 0]; ++G__12889__i;}
  xs = new cljs.core.IndexedSeq(G__12889__a,0,null);
} 
return G__12888__delegate.call(this,xs);};
G__12888.cljs$lang$maxFixedArity = 0;
G__12888.cljs$lang$applyTo = (function (arglist__12890){
var xs = cljs.core.seq(arglist__12890);
return G__12888__delegate(xs);
});
G__12888.cljs$core$IFn$_invoke$arity$variadic = G__12888__delegate;
return G__12888;
})()
;
})();
suss_oracle.string_field_cases.observations = (function suss_oracle$string_field_cases$observations(encode){
return new cljs.core.PersistentVector(null, 29, 5, cljs.core.PersistentVector.EMPTY_NODE, [({"id": "str-empty", "value": encode.call(null,(""))}),({"id": "str-scalars", "value": encode.call(null,new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [(""),(""+false),(""+true),(""+(17)),(""+"\u03BB")], null))}),({"id": "str-many", "value": encode.call(null,(""+"a"+false+(17)+"z"))}),({"id": "str-raw-number-return", "value": encode.call(null,(function (){var f = cljs.core.str;
return f.call(null,(function (){var obj12892 = ({"toString":(function (){
return (23);
})});
return obj12892;
})());
})())}),({"id": "str-raw-nil-return", "value": encode.call(null,(function (){var f = cljs.core.str;
return f.call(null,(function (){var obj12894 = ({"toString":(function (){
return null;
})});
return obj12894;
})());
})())}),({"id": "str-conversion-order", "value": encode.call(null,(function (){var t = cljs.core.atom.call(null,cljs.core.PersistentVector.EMPTY);
var a = (function (){var obj12896 = ({"toString":(function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(1));

return "a";
})});
return obj12896;
})();
var b = (function (){var obj12898 = ({"toString":(function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(2));

return "b";
})});
return obj12898;
})();
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(a)+cljs.core.str.cljs$core$IFn$_invoke$arity$1(b)),cljs.core.deref.call(null,t)], null);
})())}),({"id": "str-conversion-throw", "value": encode.call(null,(function (){var t = cljs.core.atom.call(null,cljs.core.PersistentVector.EMPTY);
var a = (function (){var obj12900 = ({"toString":(function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(1));

throw (73);
})});
return obj12900;
})();
var b = (function (){var obj12902 = ({"toString":(function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(2));

return "b";
})});
return obj12902;
})();
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(function (){try{return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(a)+cljs.core.str.cljs$core$IFn$_invoke$arity$1(b));
}catch (e12903){var e = e12903;
return e;
}})(),cljs.core.deref.call(null,t)], null);
})())}),({"id": "buffer-zero-nil-first", "value": encode.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [suss_oracle.string_field_cases.make_buffer.call(null).toString(),suss_oracle.string_field_cases.make_buffer.call(null,null,"ignored").toString()], null))}),({"id": "buffer-second-nil-suppresses-rest", "value": encode.call(null,(function (){var b = suss_oracle.string_field_cases.make_buffer.call(null,"a",null,"ignored");
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [b.toString(),b.getLength()], null);
})())}),({"id": "buffer-append-empty", "value": encode.call(null,(function (){var b = suss_oracle.string_field_cases.make_buffer.call(null,"a");
b.append();

return b.toString();
})())}),({"id": "buffer-append-self", "value": encode.call(null,(function (){var b = suss_oracle.string_field_cases.make_buffer.call(null);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(b === b.append("a","b","c")),b.toString()], null);
})())}),({"id": "buffer-clear-set", "value": encode.call(null,(function (){var b = suss_oracle.string_field_cases.make_buffer.call(null,"ab");
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [b.getLength(),(void 0 === b.clear()),b.toString(),(void 0 === b.set((17))),b.toString()], null);
})())}),({"id": "buffer-first-string-later-default-hints", "value": encode.call(null,(function (){var t = cljs.core.atom.call(null,cljs.core.PersistentVector.EMPTY);
var o = (function (){var obj12905 = ({"toString":(function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(1));

return "s";
}),"valueOf":(function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(2));

return "v";
})});
return obj12905;
})();
var b = suss_oracle.string_field_cases.make_buffer.call(null,o,o);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [b.toString(),cljs.core.deref.call(null,t)], null);
})())}),({"id": "buffer-set-default-hint", "value": encode.call(null,(function (){var t = cljs.core.atom.call(null,cljs.core.PersistentVector.EMPTY);
var o = (function (){var obj12907 = ({"toString":(function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(1));

return "s";
}),"valueOf":(function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(2));

return (7);
})});
return obj12907;
})();
var b = suss_oracle.string_field_cases.make_buffer.call(null);
b.set(o);

return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [b.toString(),cljs.core.deref.call(null,t)], null);
})())}),({"id": "buffer-conversion-mutation-captured-left", "value": encode.call(null,(function (){var b = suss_oracle.string_field_cases.make_buffer.call(null,"old");
var o = (function (){var obj12909 = ({"toString":(function (){
b.set("mutated");

return "x";
})});
return obj12909;
})();
b.append(o);

return b.toString();
})())}),({"id": "field-collision-constructor-read-write", "value": encode.call(null,(function (){

/**
* @constructor
 * @implements {suss_oracle.string_field_cases.Object}
*/
suss_oracle.string_field_cases.Collision = (function (x_y,x_y){
this.x_y = x_y;
this.x_y = x_y;
});
(suss_oracle.string_field_cases.Collision.prototype.readBoth = (function (){
var self__ = this;
var this$ = this;
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [self__.x_y,self__.x_y], null);
}));

(suss_oracle.string_field_cases.Collision.prototype.writeFirst = (function (v){
var self__ = this;
var this$ = this;
(self__.x_y = v);

return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [self__.x_y,self__.x_y], null);
}));

(suss_oracle.string_field_cases.Collision.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"x-y","x-y",-1271922527,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null)),cljs.core.with_meta(new cljs.core.Symbol(null,"x_y","x_y",1611353777,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null))], null);
}));

(suss_oracle.string_field_cases.Collision.cljs$lang$type = true);

(suss_oracle.string_field_cases.Collision.cljs$lang$ctorStr = "suss-oracle.string-field-cases/Collision");

(suss_oracle.string_field_cases.Collision.cljs$lang$ctorPrWriter = (function (this__11806__auto__,writer__11807__auto__,opt__11808__auto__){
return cljs.core._write.call(null,writer__11807__auto__,"suss-oracle.string-field-cases/Collision");
}));

/**
 * Positional factory function for suss-oracle.string-field-cases/Collision.
 */
suss_oracle.string_field_cases.__GT_Collision = (function suss_oracle$string_field_cases$observations_$___GT_Collision(x_y,x_y){
return (new suss_oracle.string_field_cases.Collision(x_y,x_y));
});


var t = cljs.core.atom.call(null,cljs.core.PersistentVector.EMPTY);
var a = (new suss_oracle.string_field_cases.Collision((function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(1));

return (7);
})()
,(function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(2));

return (9);
})()
));
var before = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [a.readBoth(),a.x_y], null);
var via_method = a.writeFirst((17));
(a.x_y = (23));

return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [before,via_method,a.readBoth(),a.x_y,cljs.core.deref.call(null,t)], null);
})()
)}),({"id": "field-hyphen-callback", "value": encode.call(null,(function (){

/**
* @constructor
 * @implements {suss_oracle.string_field_cases.Object}
*/
suss_oracle.string_field_cases.Hyphen = (function (some_field){
this.some_field = some_field;
});
(suss_oracle.string_field_cases.Hyphen.prototype.read = (function (){
var self__ = this;
var this$ = this;
return self__.some_field;
}));

(suss_oracle.string_field_cases.Hyphen.prototype.write = (function (v){
var self__ = this;
var this$ = this;
return (self__.some_field = v);
}));

(suss_oracle.string_field_cases.Hyphen.getBasis = (function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"some-field","some-field",-1844139151,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null))], null);
}));

(suss_oracle.string_field_cases.Hyphen.cljs$lang$type = true);

(suss_oracle.string_field_cases.Hyphen.cljs$lang$ctorStr = "suss-oracle.string-field-cases/Hyphen");

(suss_oracle.string_field_cases.Hyphen.cljs$lang$ctorPrWriter = (function (this__11806__auto__,writer__11807__auto__,opt__11808__auto__){
return cljs.core._write.call(null,writer__11807__auto__,"suss-oracle.string-field-cases/Hyphen");
}));

/**
 * Positional factory function for suss-oracle.string-field-cases/Hyphen.
 */
suss_oracle.string_field_cases.__GT_Hyphen = (function suss_oracle$string_field_cases$observations_$___GT_Hyphen(some_field){
return (new suss_oracle.string_field_cases.Hyphen(some_field));
});


var a = (new suss_oracle.string_field_cases.Hyphen((7)));
(a.some_field = (11));

return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [a.read(),a.some_field], null);
})()
)}),({"id": "object-variadic-receiver-rest", "value": encode.call(null,(function (){

/**
* @constructor
 * @implements {suss_oracle.string_field_cases.Object}
*/
suss_oracle.string_field_cases.Variadic = (function (){
});
(suss_oracle.string_field_cases.Variadic.prototype.collect = (function() { 
var G__12912__delegate = function (xs){
var self__ = this;
var this$ = this;
return cljs.core.vec.call(null,xs);
};
var G__12912 = function (var_args){
var self__ = this;
var xs = null;
if (arguments.length > 0) {
var G__12913__i = 0, G__12913__a = new Array(arguments.length -  0);
while (G__12913__i < G__12913__a.length) {G__12913__a[G__12913__i] = arguments[G__12913__i + 0]; ++G__12913__i;}
  xs = new cljs.core.IndexedSeq(G__12913__a,0,null);
} 
return G__12912__delegate.call(this,xs);};
G__12912.cljs$lang$maxFixedArity = 0;
G__12912.cljs$lang$applyTo = (function (arglist__12914){
var xs = cljs.core.seq(arglist__12914);
return G__12912__delegate(xs);
});
G__12912.cljs$core$IFn$_invoke$arity$variadic = G__12912__delegate;
return G__12912;
})()
);

(suss_oracle.string_field_cases.Variadic.getBasis = (function (){
return cljs.core.PersistentVector.EMPTY;
}));

(suss_oracle.string_field_cases.Variadic.cljs$lang$type = true);

(suss_oracle.string_field_cases.Variadic.cljs$lang$ctorStr = "suss-oracle.string-field-cases/Variadic");

(suss_oracle.string_field_cases.Variadic.cljs$lang$ctorPrWriter = (function (this__11806__auto__,writer__11807__auto__,opt__11808__auto__){
return cljs.core._write.call(null,writer__11807__auto__,"suss-oracle.string-field-cases/Variadic");
}));

/**
 * Positional factory function for suss-oracle.string-field-cases/Variadic.
 */
suss_oracle.string_field_cases.__GT_Variadic = (function suss_oracle$string_field_cases$observations_$___GT_Variadic(){
return (new suss_oracle.string_field_cases.Variadic());
});


var a = (new suss_oracle.string_field_cases.Variadic());
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [a.collect(),a.collect((1),(2),(3))], null);
})()
)}),({"id": "field-borrowed-callback", "value": encode.call(null,(function (){

/**
* @constructor
 * @implements {suss_oracle.string_field_cases.Object}
*/
suss_oracle.string_field_cases.Borrowed = (function (x_y){
this.x_y = x_y;
});
(suss_oracle.string_field_cases.Borrowed.prototype.read = (function (){
var self__ = this;
var this$ = this;
return self__.x_y;
}));

(suss_oracle.string_field_cases.Borrowed.getBasis = (function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"x-y","x-y",-1271922527,null)], null);
}));

(suss_oracle.string_field_cases.Borrowed.cljs$lang$type = true);

(suss_oracle.string_field_cases.Borrowed.cljs$lang$ctorStr = "suss-oracle.string-field-cases/Borrowed");

(suss_oracle.string_field_cases.Borrowed.cljs$lang$ctorPrWriter = (function (this__11806__auto__,writer__11807__auto__,opt__11808__auto__){
return cljs.core._write.call(null,writer__11807__auto__,"suss-oracle.string-field-cases/Borrowed");
}));

/**
 * Positional factory function for suss-oracle.string-field-cases/Borrowed.
 */
suss_oracle.string_field_cases.__GT_Borrowed = (function suss_oracle$string_field_cases$observations_$___GT_Borrowed(x_y){
return (new suss_oracle.string_field_cases.Borrowed(x_y));
});


var a = (new suss_oracle.string_field_cases.Borrowed((7)));
var other = (function (){var obj12911 = ({"x_y":(29)});
return obj12911;
})();
return a.read.call(other);
})()
)}),({"id": "str-live-recursive-var", "value": encode.call(null,(function (){var saved = cljs.core.str;
var body = cljs.core.str.cljs$core$IFn$_invoke$arity$variadic;
try{(cljs.core.str = (function() {
var G__12915 = null;
var G__12915__1 = (function (x){
return "X";
});
var G__12915__2 = (function() { 
var G__12916__delegate = function (x,xs){
return "X";
};
var G__12916 = function (x,var_args){
var xs = null;
if (arguments.length > 1) {
var G__12917__i = 0, G__12917__a = new Array(arguments.length -  1);
while (G__12917__i < G__12917__a.length) {G__12917__a[G__12917__i] = arguments[G__12917__i + 1]; ++G__12917__i;}
  xs = new cljs.core.IndexedSeq(G__12917__a,0,null);
} 
return G__12916__delegate.call(this,x,xs);};
G__12916.cljs$lang$maxFixedArity = 1;
G__12916.cljs$lang$applyTo = (function (arglist__12918){
var x = cljs.core.first(arglist__12918);
var xs = cljs.core.rest(arglist__12918);
return G__12916__delegate(x,xs);
});
G__12916.cljs$core$IFn$_invoke$arity$variadic = G__12916__delegate;
return G__12916;
})()
;
G__12915 = function(x,var_args){
var xs = var_args;
switch(arguments.length){
case 1:
return G__12915__1.call(this,x);
default:
var G__12919 = null;
if (arguments.length > 1) {
var G__12920__i = 0, G__12920__a = new Array(arguments.length -  1);
while (G__12920__i < G__12920__a.length) {G__12920__a[G__12920__i] = arguments[G__12920__i + 1]; ++G__12920__i;}
G__12919 = new cljs.core.IndexedSeq(G__12920__a,0,null);
}
return G__12915__2.cljs$core$IFn$_invoke$arity$variadic(x, G__12919);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
G__12915.cljs$lang$maxFixedArity = 1;
G__12915.cljs$lang$applyTo = G__12915__2.cljs$lang$applyTo;
G__12915.cljs$core$IFn$_invoke$arity$1 = G__12915__1;
G__12915.cljs$core$IFn$_invoke$arity$variadic = G__12915__2.cljs$core$IFn$_invoke$arity$variadic;
return G__12915;
})()
);

return body.call(null,"a",(new cljs.core.List(null,"b",null,(1),null)));
}finally {(cljs.core.str = saved);
}})())}),({"id": "str-immutable-nil-macro", "value": encode.call(null,(function (){var saved = cljs.core.nil_QMARK_;
var f = cljs.core.str;
try{(cljs.core.nil_QMARK_ = (function (x){
return true;
}));

return f.call(null,(17));
}finally {(cljs.core.nil_QMARK_ = saved);
}})())}),({"id": "buffer-captured-to-array", "value": encode.call(null,(function (){var saved = cljs.core.to_array;
try{(cljs.core.to_array = (function (xs){
return ["bad"];
}));

return suss_oracle.string_field_cases.make_buffer.call(null,"a","b").toString();
}finally {(cljs.core.to_array = saved);
}})())}),({"id": "field-collision-protocol-read-write", "value": encode.call(null,(function (){

/**
 * @interface
 */
suss_oracle.string_field_cases.CollisionProtocol = function(){};

var suss_oracle$string_field_cases$CollisionProtocol$collision_read$dyn_12921 = (function (this$){
var x__11878__auto__ = (((this$ == null))?null:this$);
var m__11879__auto__ = (suss_oracle.string_field_cases.collision_read[goog.typeOf(x__11878__auto__)]);
if((!((m__11879__auto__ == null)))){
return m__11879__auto__.call(null,this$);
} else {
var m__11877__auto__ = (suss_oracle.string_field_cases.collision_read["_"]);
if((!((m__11877__auto__ == null)))){
return m__11877__auto__.call(null,this$);
} else {
throw cljs.core.missing_protocol.call(null,"CollisionProtocol.collision-read",this$);
}
}
});
suss_oracle.string_field_cases.collision_read = (function suss_oracle$string_field_cases$observations_$_collision_read(this$){
if((((!((this$ == null)))) && ((!((this$.suss_oracle$string_field_cases$CollisionProtocol$collision_read$arity$1 == null)))))){
return this$.suss_oracle$string_field_cases$CollisionProtocol$collision_read$arity$1(this$);
} else {
return suss_oracle$string_field_cases$CollisionProtocol$collision_read$dyn_12921.call(null,this$);
}
});

var suss_oracle$string_field_cases$CollisionProtocol$collision_write$dyn_12922 = (function (this$,v){
var x__11878__auto__ = (((this$ == null))?null:this$);
var m__11879__auto__ = (suss_oracle.string_field_cases.collision_write[goog.typeOf(x__11878__auto__)]);
if((!((m__11879__auto__ == null)))){
return m__11879__auto__.call(null,this$,v);
} else {
var m__11877__auto__ = (suss_oracle.string_field_cases.collision_write["_"]);
if((!((m__11877__auto__ == null)))){
return m__11877__auto__.call(null,this$,v);
} else {
throw cljs.core.missing_protocol.call(null,"CollisionProtocol.collision-write",this$);
}
}
});
suss_oracle.string_field_cases.collision_write = (function suss_oracle$string_field_cases$observations_$_collision_write(this$,v){
if((((!((this$ == null)))) && ((!((this$.suss_oracle$string_field_cases$CollisionProtocol$collision_write$arity$2 == null)))))){
return this$.suss_oracle$string_field_cases$CollisionProtocol$collision_write$arity$2(this$,v);
} else {
return suss_oracle$string_field_cases$CollisionProtocol$collision_write$dyn_12922.call(null,this$,v);
}
});



/**
* @constructor
 * @implements {suss_oracle.string_field_cases.CollisionProtocol}
*/
suss_oracle.string_field_cases.ProtocolCollision = (function (x_y,x_y){
this.x_y = x_y;
this.x_y = x_y;
});
(suss_oracle.string_field_cases.ProtocolCollision.prototype.suss_oracle$string_field_cases$CollisionProtocol$ = cljs.core.PROTOCOL_SENTINEL);

(suss_oracle.string_field_cases.ProtocolCollision.prototype.suss_oracle$string_field_cases$CollisionProtocol$collision_read$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [self__.x_y,self__.x_y], null);
}));

(suss_oracle.string_field_cases.ProtocolCollision.prototype.suss_oracle$string_field_cases$CollisionProtocol$collision_write$arity$2 = (function (this$,v){
var self__ = this;
var this$__$1 = this;
return (self__.x_y = v);
}));

(suss_oracle.string_field_cases.ProtocolCollision.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"x-y","x-y",-1271922527,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null)),cljs.core.with_meta(new cljs.core.Symbol(null,"x_y","x_y",1611353777,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"mutable","mutable",875778266),true], null))], null);
}));

(suss_oracle.string_field_cases.ProtocolCollision.cljs$lang$type = true);

(suss_oracle.string_field_cases.ProtocolCollision.cljs$lang$ctorStr = "suss-oracle.string-field-cases/ProtocolCollision");

(suss_oracle.string_field_cases.ProtocolCollision.cljs$lang$ctorPrWriter = (function (this__11806__auto__,writer__11807__auto__,opt__11808__auto__){
return cljs.core._write.call(null,writer__11807__auto__,"suss-oracle.string-field-cases/ProtocolCollision");
}));

/**
 * Positional factory function for suss-oracle.string-field-cases/ProtocolCollision.
 */
suss_oracle.string_field_cases.__GT_ProtocolCollision = (function suss_oracle$string_field_cases$observations_$___GT_ProtocolCollision(x_y,x_y){
return (new suss_oracle.string_field_cases.ProtocolCollision(x_y,x_y));
});


var a = (new suss_oracle.string_field_cases.ProtocolCollision((7),(9)));
var before = suss_oracle.string_field_cases.collision_read.call(null,a);
suss_oracle.string_field_cases.collision_write.call(null,a,(17));

return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [before,suss_oracle.string_field_cases.collision_read.call(null,a),a.x_y], null);
})()
)}),({"id": "object-fixed-rest-overlap", "value": encode.call(null,(function (){

/**
* @constructor
 * @implements {suss_oracle.string_field_cases.Object}
*/
suss_oracle.string_field_cases.Overlap = (function (){
});
(suss_oracle.string_field_cases.Overlap.prototype.collect = (function() {
var G__12923 = null;
var G__12923__1 = (function (x){
var self__ = this;
var this$ = this;
return (10);
});
var G__12923__2 = (function() { 
var G__12924__delegate = function (x,xs){
var self__ = this;
var this$ = this;
return (20);
};
var G__12924 = function (x,var_args){
var self__ = this;
var xs = null;
if (arguments.length > 1) {
var G__12925__i = 0, G__12925__a = new Array(arguments.length -  1);
while (G__12925__i < G__12925__a.length) {G__12925__a[G__12925__i] = arguments[G__12925__i + 1]; ++G__12925__i;}
  xs = new cljs.core.IndexedSeq(G__12925__a,0,null);
} 
return G__12924__delegate.call(this,x,xs);};
G__12924.cljs$lang$maxFixedArity = 1;
G__12924.cljs$lang$applyTo = (function (arglist__12926){
var x = cljs.core.first(arglist__12926);
var xs = cljs.core.rest(arglist__12926);
return G__12924__delegate(x,xs);
});
G__12924.cljs$core$IFn$_invoke$arity$variadic = G__12924__delegate;
return G__12924;
})()
;
G__12923 = function(x,var_args){
var xs = var_args;
switch(arguments.length){
case 1:
return G__12923__1.call(this,x);
default:
var G__12927 = null;
if (arguments.length > 1) {
var G__12928__i = 0, G__12928__a = new Array(arguments.length -  1);
while (G__12928__i < G__12928__a.length) {G__12928__a[G__12928__i] = arguments[G__12928__i + 1]; ++G__12928__i;}
G__12927 = new cljs.core.IndexedSeq(G__12928__a,0,null);
}
return G__12923__2.cljs$core$IFn$_invoke$arity$variadic(x, G__12927);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
G__12923.cljs$lang$maxFixedArity = 1;
G__12923.cljs$lang$applyTo = G__12923__2.cljs$lang$applyTo;
G__12923.cljs$core$IFn$_invoke$arity$1 = G__12923__1;
G__12923.cljs$core$IFn$_invoke$arity$variadic = G__12923__2.cljs$core$IFn$_invoke$arity$variadic;
return G__12923;
})()
);

(suss_oracle.string_field_cases.Overlap.getBasis = (function (){
return cljs.core.PersistentVector.EMPTY;
}));

(suss_oracle.string_field_cases.Overlap.cljs$lang$type = true);

(suss_oracle.string_field_cases.Overlap.cljs$lang$ctorStr = "suss-oracle.string-field-cases/Overlap");

(suss_oracle.string_field_cases.Overlap.cljs$lang$ctorPrWriter = (function (this__11806__auto__,writer__11807__auto__,opt__11808__auto__){
return cljs.core._write.call(null,writer__11807__auto__,"suss-oracle.string-field-cases/Overlap");
}));

/**
 * Positional factory function for suss-oracle.string-field-cases/Overlap.
 */
suss_oracle.string_field_cases.__GT_Overlap = (function suss_oracle$string_field_cases$observations_$___GT_Overlap(){
return (new suss_oracle.string_field_cases.Overlap());
});


var a = (new suss_oracle.string_field_cases.Overlap());
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [a.collect((1)),a.collect((1),(2))], null);
})()
)}),({"id": "reserved-field-storage", "value": encode.call(null,(function (){

/**
* @constructor
*/
suss_oracle.string_field_cases.Reserved = (function (null$){
this.null$ = null$;
});

(suss_oracle.string_field_cases.Reserved.getBasis = (function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"null","null",1460393818,null)], null);
}));

(suss_oracle.string_field_cases.Reserved.cljs$lang$type = true);

(suss_oracle.string_field_cases.Reserved.cljs$lang$ctorStr = "suss-oracle.string-field-cases/Reserved");

(suss_oracle.string_field_cases.Reserved.cljs$lang$ctorPrWriter = (function (this__11806__auto__,writer__11807__auto__,opt__11808__auto__){
return cljs.core._write.call(null,writer__11807__auto__,"suss-oracle.string-field-cases/Reserved");
}));

/**
 * Positional factory function for suss-oracle.string-field-cases/Reserved.
 */
suss_oracle.string_field_cases.__GT_Reserved = (function suss_oracle$string_field_cases$observations_$___GT_Reserved(null$){
return (new suss_oracle.string_field_cases.Reserved(null$));
});



/**
* @constructor
*/
suss_oracle.string_field_cases.Punctuation = (function (some_field){
this.some_field = some_field;
});

(suss_oracle.string_field_cases.Punctuation.getBasis = (function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"some-field","some-field",-1844139151,null)], null);
}));

(suss_oracle.string_field_cases.Punctuation.cljs$lang$type = true);

(suss_oracle.string_field_cases.Punctuation.cljs$lang$ctorStr = "suss-oracle.string-field-cases/Punctuation");

(suss_oracle.string_field_cases.Punctuation.cljs$lang$ctorPrWriter = (function (this__11806__auto__,writer__11807__auto__,opt__11808__auto__){
return cljs.core._write.call(null,writer__11807__auto__,"suss-oracle.string-field-cases/Punctuation");
}));

/**
 * Positional factory function for suss-oracle.string-field-cases/Punctuation.
 */
suss_oracle.string_field_cases.__GT_Punctuation = (function suss_oracle$string_field_cases$observations_$___GT_Punctuation(some_field){
return (new suss_oracle.string_field_cases.Punctuation(some_field));
});


var a = (new suss_oracle.string_field_cases.Reserved((7)));
var b = (new suss_oracle.string_field_cases.Punctuation((9)));
var absent = (void 0 === a.null);
var old = a.null$;
(a.null$ = (11));

return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [absent,old,a.null$,a.null$,b.some_field], null);
})()
)}),({"id": "buffer-append-nil", "value": encode.call(null,(function (){var b = suss_oracle.string_field_cases.make_buffer.call(null);
b.append(null);

return b.toString();
})())}),({"id": "buffer-undefined-second-suppresses-rest", "value": encode.call(null,(function (){var b = suss_oracle.string_field_cases.make_buffer.call(null);
b.append("a",([][(0)]),"ignored");

return b.toString();
})())}),({"id": "buffer-set-missing", "value": encode.call(null,(function (){var b = suss_oracle.string_field_cases.make_buffer.call(null);
b.set();

return b.toString();
})())}),({"id": "buffer-utf16-length-and-ignored-effects", "value": encode.call(null,(function (){var t = cljs.core.atom.call(null,cljs.core.PersistentVector.EMPTY);
var b = suss_oracle.string_field_cases.make_buffer.call(null,"\u03BB\uD83D\uDE42");
var len = b.getLength((function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(1));

return null;
})()
);
var text = b.toString((function (){
cljs.core.swap_BANG_.call(null,t,cljs.core.conj,(2));

return false;
})()
);
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [len,text,cljs.core.deref.call(null,t)], null);
})())})], null);
});
