// Compiled by ClojureScript 0.0.365323148 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('suss_oracle.string_direct_macro_cases');
goog.require('cljs.core');
goog.require('goog.string.StringBuffer');
suss_oracle.string_direct_macro_cases.make_buffer = (function (){var convert = cljs.core.to_array;
return (function() { 
var G__16418__delegate = function (xs){
return Reflect.construct(goog.string.StringBuffer,convert.call(null,xs));
};
var G__16418 = function (var_args){
var xs = null;
if (arguments.length > 0) {
var G__16419__i = 0, G__16419__a = new Array(arguments.length -  0);
while (G__16419__i < G__16419__a.length) {G__16419__a[G__16419__i] = arguments[G__16419__i + 0]; ++G__16419__i;}
  xs = new cljs.core.IndexedSeq(G__16419__a,0,null);
} 
return G__16418__delegate.call(this,xs);};
G__16418.cljs$lang$maxFixedArity = 0;
G__16418.cljs$lang$applyTo = (function (arglist__16420){
var xs = cljs.core.seq(arglist__16420);
return G__16418__delegate(xs);
});
G__16418.cljs$core$IFn$_invoke$arity$variadic = G__16418__delegate;
return G__16418;
})()
;
})();
suss_oracle.string_direct_macro_cases.observations = (function suss_oracle$string_direct_macro_cases$observations(encode){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [({"id": "direct-str-raw-number-return", "value": encode.call(null,(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var obj16424 = ({"toString":(function (){
return (23);
})});
return obj16424;
})())))}),({"id": "direct-str-raw-nil-return", "value": encode.call(null,(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var obj16428 = ({"toString":(function (){
return null;
})});
return obj16428;
})())))})], null);
});
